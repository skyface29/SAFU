import SwiftUI
import UIKit

// MARK: - Разработчик и «О приложении»

enum Developer {
    static let telegram = "skf29"
    static let name = "@skf29"
    static let role = "Студент САФУ"
    static var telegramURL: URL { URL(string: "https://t.me/\(telegram)")! }

    static var version: String {
        let v = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
        let b = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? ""
        return b.isEmpty ? v : "\(v) (\(b))"
    }
}

struct ChangelogEntry: Identifiable {
    let version: String
    let items: [String]
    var id: String { version }

    static let all: [ChangelogEntry] = [
        ChangelogEntry(version: "7.4", items: [
            "Пасхалки перепрятаны. Ищи заново — одна теперь очень громкая",
            "Мини-игра стала круче: день и ночь, лоси, турбо, комбо и северное сияние",
            "Убран лишний пункт «Поддержка» из профиля",
        ]),
        ChangelogEntry(version: "7.3", items: [
            "БРС подтягивается сама: журнал оценок Sakai и Личный кабинет",
            "Live Activity висит всегда: нет пар — показывает следующую с днём недели",
            "Фоновое обновление Live Activity",
            "Расписание картинкой — красиво отправить в чат группы",
            "Пасхалки и мини-игра. Найдёшь все?",
        ]),
        ChangelogEntry(version: "7.2", items: [
            "БРС: баллы, прогноз оценки, сколько не хватает до «4», «5» и автомата",
            "Режим сессии: отсчёт, билеты «знаю / повторить», случайный билет, итоги",
            "Опросы группы: отправил в чат — отметил ответы — готовые итоги",
            "Фон и цвет по сезону: снег, цветение, лето, листопад",
            "Праздничные анимации: конец пар, конец недели, задачи, экзамены, праздники",
            "Статистика: «прошло из всех» по каждому предмету",
            "Приложение стало заметно быстрее: кеш расписания, фон на паузе вне экрана",
        ]),
        ChangelogEntry(version: "7.1", items: [
            "Свои автобусы и обмен маршрутами с группой",
            "Крестик на Live Activity автобуса",
            "Оформление: стили, фоны, карточки, шрифты, листопад",
        ]),
    ]
}

struct DeveloperView: View {
    @Environment(\.openURL) private var openURL
    @State private var taps = 0
    @State private var versionTaps = 0
    @State private var spin = false
    @State private var nuke: NukeShot?
    @State private var eggsRev = 0

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                hero
                links
                eggs
                about
                changelog
                Text("Сделано с ❤️ между Северодвинском и Архангельском")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 4)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Разработчик")
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $nuke, onDismiss: nukeDone) { NukeView(snapshot: $0.image) }
    }

    private var eggs: some View {
        let _ = eggsRev
        let found = Egg.allCases.filter { Eggs.has($0) }.count
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Пасхалки").font(.system(.headline, design: .rounded))
                Spacer()
                Text("\(found) из \(Egg.allCases.count)")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Color.brand)
            }
            ForEach(Egg.allCases, id: \.self) { e in
                let has = Eggs.has(e)
                HStack(spacing: 12) {
                    Image(systemName: has ? e.icon : "questionmark")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(has ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary))
                        .frame(width: 34, height: 34)
                        .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    VStack(alignment: .leading, spacing: 1) {
                        Text(has ? e.title : "???").font(.subheadline.weight(.semibold))
                        Text(e.hint).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func nukeDone() {
        let first = Eggs.mark(.nuke)
        eggsRev += 1
        CelebrationCenter.shared.fire(Celebration(title: first ? "Пасхалка найдена ☢️" : "Ты снова выжил ☢️",
                                                  subtitle: first ? "Ядерный гриб. Разработчик просил не трогать" : "Приложение собрано обратно. Почти",
                                                  style: .emoji(["☢️", "💥", "🍄", "🔥"]), force: true))
    }

    private var hero: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(brandGradient)
                    .shadow(color: Color.brand.opacity(0.45), radius: 18, y: 6)
                Image(systemName: "chevron.left.forwardslash.chevron.right")
                    .font(.system(size: 36, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 110, height: 110)
            .rotation3DEffect(.degrees(spin ? 360 : 0), axis: (x: 0, y: 1, z: 0))
            .onTapGesture {
                taps += 1
                Haptics.tap()
                withAnimation(.spring(response: 0.7, dampingFraction: 0.7)) { spin.toggle() }
                if taps == 7 {
                    taps = 0
                    // снимок экрана — его и разнесёт; без анимации появления, чтобы взрывалось само приложение
                    let shot = Nuke.snapshot()
                    var tr = Transaction()
                    tr.disablesAnimations = true
                    withTransaction(tr) { nuke = NukeShot(image: shot) }
                }
            }
            VStack(spacing: 4) {
                Text(Developer.name)
                    .font(.system(.title2, design: .rounded).weight(.heavy))
                Text("Разработчик приложения")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.brand)
                Text(Developer.role)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
        .glass(28)
    }

    private var links: some View {
        VStack(spacing: 10) {
            Button { openURL(Developer.telegramURL) } label: {
                HStack {
                    Image(systemName: "paperplane.fill")
                    Text("Написать в Telegram")
                    Spacer()
                    Text("@\(Developer.telegram)").fontWeight(.bold)
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(16)
                .background(LinearGradient(colors: [Color(red: 0.16, green: 0.62, blue: 0.92), Color(red: 0.13, green: 0.50, blue: 0.85)],
                                           startPoint: .leading, endPoint: .trailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(PressableStyle())

            HStack(spacing: 10) {
                smallLink("ladybug.fill", "Нашёл баг", "Привет! Нашёл баг в САФУ \(Developer.version): ")
                smallLink("lightbulb.fill", "Есть идея", "Привет! Идея для САФУ: ")
            }
        }
    }

    private func smallLink(_ icon: String, _ title: String, _ text: String) -> some View {
        Button {
            UIPasteboard.general.string = text
            Haptics.success()
            openURL(Developer.telegramURL)
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title3).foregroundStyle(brandGradient)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .glass(18)
        }
        .buttonStyle(PressableStyle())
    }

    private var about: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("О приложении").font(.system(.headline, design: .rounded))
            Text("«САФУ» собирает в одном месте расписание из РУЗ, сайты университета, задачи, файлы по предметам, БРС, сессию и дорогу до универа. Без рекламы и лишних разрешений: пароли и данные хранятся только на телефоне.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Divider()
            row("Версия", Developer.version)
                .contentShape(Rectangle())
                .onTapGesture {
                    versionTaps += 1
                    if versionTaps >= 5 {
                        versionTaps = 0
                        HackerMode.toggle()
                        eggsRev += 1
                    }
                }
            row("Платформа", "iOS 17+, SwiftUI")
            row("Для кого", "Студенты САФУ")
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func row(_ a: String, _ b: String) -> some View {
        HStack {
            Text(a).foregroundStyle(.secondary)
            Spacer()
            Text(b).fontWeight(.semibold)
        }
        .font(.subheadline)
    }

    private var changelog: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Что нового").font(.system(.headline, design: .rounded))
            ForEach(ChangelogEntry.all) { e in
                VStack(alignment: .leading, spacing: 6) {
                    Text("Версия \(e.version)")
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(Color.brand)
                    ForEach(e.items, id: \.self) { i in
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Circle().fill(Color.brand).frame(width: 5, height: 5)
                            Text(i).font(.subheadline)
                        }
                    }
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }
}
