import SwiftUI
import UIKit

// MARK: - Разработчик и «О приложении»

enum Developer {
    static let telegram = "skf29"
    static let name = "@skf29"
    static let role = "Студент САФУ"
    static var telegramURL: URL { URL(string: "https://t.me/\(telegram)")! }

    static var version: String {
        let v = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
        let b = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? ""
        return b.isEmpty ? v : "\(v) (\(b))"
    }
}

struct ChangelogEntry: Identifiable {
    let version: String
    let items: [String]
    var id: String { version }

    static let all: [ChangelogEntry] = [
        ChangelogEntry(version: "8.0", items: [
            "Лекции: кнопка «Проверить подключение» — видно, работает ли GigaChat, ИИ Apple и Claude, и что не так",
            "10 строгих цветов: тёмно-синий, САФУ, бордо, хвоя, петроль, сланец, олива, кофе, слива, чернила",
            "Конспекты от GigaChat и ИИ Apple разбираются надёжнее, новый ключ GigaChat применяется сразу",
        ]),
        ChangelogEntry(version: "7.9", items: [
            "Конспекты лекций бесплатно и без VPN: GigaChat от Сбера, ИИ Apple прямо на телефоне или Claude — на выбор",
            "Конспект без ИИ стал лучше: разбивка лекции по 10 минут, важное и термины",
        ]),
        ChangelogEntry(version: "7.8", items: [
            "Лекции: запись → текст (Whisper прямо на телефоне) → красивый конспект от Claude. ⭐ Важно — отметить главное",
            "Конспект сохраняется: читай, переписывай своими словами, отправляй в заметки",
        ]),
        ChangelogEntry(version: "7.7", items: [
            "Доска → текст: фото доски само выпрямляется, текст распознаётся, по нему работает поиск",
            "Умный подъём: будильник под первую пару с учётом автобуса, сборов и мороза, «пора спать» по циклам сна",
        ]),
        ChangelogEntry(version: "7.6.2", items: [
            "Исправлено: поиск свободных аудиторий мог подменить твоё расписание чужой группой. Память РУЗ очищена и загружена заново",
            "Machinarium: живая картина свалки — горы хлама в смоге, дирижабль, туман",
        ]),
        ChangelogEntry(version: "7.6", items: [
            "Темы: Ясный, iOS 6 и Machinarium — меняют всё сразу, со своими иконками",
            "Заметки по-взрослому: много заметок, чек-листы, цвет, предмет, закрепление, поиск",
            "Свободные аудитории: полное название из РУЗ, твой корпус — первым",
            "БРС: оценки из Sakai читаются и со страницы журнала, подробный отчёт «Что нашлось»",
            "«Что нового» сворачивается — видна только последняя версия",
        ]),
        ChangelogEntry(version: "7.5", items: [
            "БРС: вход в Sakai и Личный кабинет прямо на экране БРС, видно, где вход есть",
            "«Где пара»: тап по аудитории — корпус, этаж, своя подсказка «как найти», маршрут",
            "Свободные аудитории: где посидеть в окно, по расписанию всех групп школы",
            "Замены и отмены приходят уведомлением, даже когда приложение закрыто",
            "Погода к автобусу: мороз, снег, ветер — и совет, как одеться",
            "Секретные иконки. Одна — за сессию на «5»",
            "Приложение быстрее: меньше лишних вычислений при каждой отрисовке, быстрее запуск",
        ]),
        ChangelogEntry(version: "7.4", items: [
            "Пасхалки перепрятаны. Ищи заново — одна теперь очень громкая",
            "Мини-игра стала круче: день и ночь, лоси, турбо, комбо и северное сияние",
            "Убран лишний пункт «Поддержка» из профиля",
        ]),
        ChangelogEntry(version: "7.3", items: [
            "БРС подтягивается сама: журнал оценок Sakai и Личный кабинет",
            "Live Activity висит всегда: нет пар — показывает следующую с днём недели",
            "Фоновое обновление Live Activity",
            "Расписание картинкой — красиво отправить в чат группы",
            "Пасхалки и мини-игра. Найдёшь все?",
        ]),
        ChangelogEntry(version: "7.2", items: [
            "БРС: баллы, прогноз оценки, сколько не хватает до «4», «5» и автомата",
            "Режим сессии: отсчёт, билеты «знаю / повторить», случайный билет, итоги",
            "Опросы группы: отправил в чат — отметил ответы — готовые итоги",
            "Фон и цвет по сезону: снег, цветение, лето, листопад",
            "Праздничные анимации: конец пар, конец недели, задачи, экзамены, праздники",
            "Статистика: «прошло из всех» по каждому предмету",
            "Приложение стало заметно быстрее: кеш расписания, фон на паузе вне экрана",
        ]),
        ChangelogEntry(version: "7.1", items: [
            "Свои автобусы и обмен маршрутами с группой",
            "Крестик на Live Activity автобуса",
            "Оформление: стили, фоны, карточки, шрифты, листопад",
        ]),
    ]
}

struct DeveloperView: View {
    @Environment(\.openURL) private var openURL
    @State private var taps = 0
    @State private var versionTaps = 0
    @State private var spin = false
    @State private var nuke: NukeShot?
    @State private var askCode = false
    @State private var code = ""
    @State private var wrongCode = false
    @State private var allVersions = false
    @State private var eggsRev = 0

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                hero
                links
                eggs
                about
                changelog
                Text("Сделано с ❤️ между Северодвинском и Архангельском")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 4)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Разработчик")
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $nuke, onDismiss: nukeDone) { NukeView(snapshot: $0.image) }
        .alert("Код", isPresented: $askCode) {
            SecureField("Код", text: $code)
            Button("Открыть") { checkCode() }
            Button("Отмена", role: .cancel) {}
        }
        .alert("Неверный код", isPresented: $wrongCode) {
            Button("Ок", role: .cancel) {}
        }
    }

    private var eggs: some View {
        let _ = eggsRev
        let found = Egg.allCases.filter { Eggs.has($0) }.count
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Пасхалки").font(.system(.headline, design: .rounded))
                Spacer()
                Text("\(found) из \(Egg.allCases.count)")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Color.brand)
            }
            ForEach(Egg.allCases, id: \.self) { e in
                let has = Eggs.has(e)
                HStack(spacing: 12) {
                    Image(systemName: has ? e.icon : "questionmark")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(has ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary))
                        .frame(width: 34, height: 34)
                        .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    VStack(alignment: .leading, spacing: 1) {
                        Text(has ? e.title : "???").font(.subheadline.weight(.semibold))
                        Text(e.hint).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func checkCode() {
        let ok = VipIcons.tryUnlock(code)
        code = ""
        guard ok else {
            wrongCode = true
            return
        }
        Haptics.success()
        CelebrationCenter.shared.fire(Celebration(title: "Эксклюзив открыт 💎",
                                                  subtitle: "Бриллиант, Зачётка, Сталь, Значок и Билет — в разделе «Иконка»",
                                                  style: .emoji(["💎", "👑", "✨", "🔐"]), force: true))
    }

    private func nukeDone() {
        let first = Eggs.mark(.nuke)
        eggsRev += 1
        CelebrationCenter.shared.fire(Celebration(title: first ? "Пасхалка найдена ☢️" : "Ты снова выжил ☢️",
                                                  subtitle: first ? "Ядерный гриб. Разработчик просил не трогать" : "Приложение собрано обратно. Почти",
                                                  style: .emoji(["☢️", "💥", "🍄", "🔥"]), force: true))
    }

    private var hero: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(brandGradient)
                    .shadow(color: Color.brand.opacity(0.45), radius: 18, y: 6)
                Image(systemName: "chevron.left.forwardslash.chevron.right")
                    .font(.system(size: 36, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 110, height: 110)
            .rotation3DEffect(.degrees(spin ? 360 : 0), axis: (x: 0, y: 1, z: 0))
            .onTapGesture {
                taps += 1
                Haptics.tap()
                withAnimation(.spring(response: 0.7, dampingFraction: 0.7)) { spin.toggle() }
                if taps == 7 {
                    taps = 0
                    // снимок экрана — его и разнесёт; без анимации появления, чтобы взрывалось само приложение
                    let shot = Nuke.snapshot()
                    var tr = Transaction()
                    tr.disablesAnimations = true
                    withTransaction(tr) { nuke = NukeShot(image: shot) }
                }
            }
            VStack(spacing: 4) {
                Text(Developer.name)
                    .font(.system(.title2, design: .rounded).weight(.heavy))
                    // секрет: держать ник 3 секунды → поле для кода
                    .onLongPressGesture(minimumDuration: 3) {
                        code = ""
                        Haptics.tap()
                        askCode = true
                    }
                Text("Разработчик приложения")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.brand)
                Text(Developer.role)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
        .glass(28)
    }

    private var links: some View {
        VStack(spacing: 10) {
            Button { openURL(Developer.telegramURL) } label: {
                HStack {
                    Image(systemName: "paperplane.fill")
                    Text("Написать в Telegram")
                    Spacer()
                    Text("@\(Developer.telegram)").fontWeight(.bold)
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(16)
                .background(LinearGradient(colors: [Color(red: 0.16, green: 0.62, blue: 0.92), Color(red: 0.13, green: 0.50, blue: 0.85)],
                                           startPoint: .leading, endPoint: .trailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(PressableStyle())

            HStack(spacing: 10) {
                smallLink("ladybug.fill", "Нашёл баг", "Привет! Нашёл баг в САФУ \(Developer.version): ")
                smallLink("lightbulb.fill", "Есть идея", "Привет! Идея для САФУ: ")
            }
        }
    }

    private func smallLink(_ icon: String, _ title: String, _ text: String) -> some View {
        Button {
            UIPasteboard.general.string = text
            Haptics.success()
            openURL(Developer.telegramURL)
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title3).foregroundStyle(brandGradient)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .glass(18)
        }
        .buttonStyle(PressableStyle())
    }

    private var about: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("О приложении").font(.system(.headline, design: .rounded))
            Text("«САФУ» собирает в одном месте расписание из РУЗ, сайты университета, задачи, файлы по предметам, БРС, сессию и дорогу до универа. Без рекламы и лишних разрешений: пароли и данные хранятся только на телефоне.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Divider()
            row("Версия", Developer.version)
                .contentShape(Rectangle())
                .onTapGesture {
                    versionTaps += 1
                    if versionTaps >= 5 {
                        versionTaps = 0
                        HackerMode.toggle()
                        eggsRev += 1
                    }
                }
            row("Платформа", "iOS 17+, SwiftUI")
            row("Для кого", "Студенты САФУ")
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func row(_ a: String, _ b: String) -> some View {
        HStack {
            Text(a).foregroundStyle(.secondary)
            Spacer()
            Text(b).fontWeight(.semibold)
        }
        .font(.subheadline)
    }

    private var changelog: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Что нового").font(.system(.headline, design: .rounded))
            ForEach(allVersions ? ChangelogEntry.all : Array(ChangelogEntry.all.prefix(1))) { e in
                VStack(alignment: .leading, spacing: 6) {
                    Text("Версия \(e.version)")
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(Color.brand)
                    ForEach(e.items, id: \.self) { i in
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Circle().fill(Color.brand).frame(width: 5, height: 5)
                            Text(i).font(.subheadline)
                        }
                    }
                }
            }
            if ChangelogEntry.all.count > 1 {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { allVersions.toggle() }
                } label: {
                    HStack(spacing: 6) {
                        Text(allVersions ? "Скрыть прошлые версии" : "Прошлые версии (\(ChangelogEntry.all.count - 1))")
                        Image(systemName: "chevron.down")
                            .rotationEffect(.degrees(allVersions ? 180 : 0))
                    }
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.brand)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(Color.brand.opacity(0.10), in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }
}
