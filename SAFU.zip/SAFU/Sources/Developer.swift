import SwiftUI
import UIKit

// MARK: - Разработчик и «О приложении»

enum Developer {
    static let name = "Кирилл Зарубин"
    static let telegram = "skf29"
    static let role = "Студент САФУ · Информационная безопасность"
    static var telegramURL: URL { URL(string: "https://t.me/\(telegram)")! }

    static var version: String {
        let v = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
        let b = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? ""
        return b.isEmpty ? v : "\(v) (\(b))"
    }
}

struct ChangelogEntry: Identifiable {
    let version: String
    let items: [String]
    var id: String { version }

    static let all: [ChangelogEntry] = [
        ChangelogEntry(version: "7.2", items: [
            "БРС: баллы, прогноз оценки, сколько не хватает до «4», «5» и автомата",
            "Режим сессии: отсчёт, билеты «знаю / повторить», случайный билет, итоги",
            "Опросы группы: отправил в чат — отметил ответы — готовые итоги",
            "Фон и цвет по сезону: снег, цветение, лето, листопад",
            "Праздничные анимации: конец пар, конец недели, задачи, экзамены, праздники",
            "Статистика: «прошло из всех» по каждому предмету",
            "Приложение стало заметно быстрее: кеш расписания, фон на паузе вне экрана",
        ]),
        ChangelogEntry(version: "7.1", items: [
            "Свои автобусы и обмен маршрутами с группой",
            "Крестик на Live Activity автобуса",
            "Оформление: стили, фоны, карточки, шрифты, листопад",
        ]),
    ]
}

struct DeveloperView: View {
    @Environment(\.openURL) private var openURL
    @State private var taps = 0
    @State private var spin = false

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                hero
                links
                about
                changelog
                Text("Сделано с ❤️ между Северодвинском и Архангельском")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.top, 4)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Разработчик")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var hero: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle().fill(brandGradient)
                    .shadow(color: Color.brand.opacity(0.45), radius: 18, y: 6)
                Text("КЗ")
                    .font(.system(size: 38, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
            }
            .frame(width: 110, height: 110)
            .rotation3DEffect(.degrees(spin ? 360 : 0), axis: (x: 0, y: 1, z: 0))
            .onTapGesture {
                taps += 1
                Haptics.tap()
                withAnimation(.spring(response: 0.7, dampingFraction: 0.7)) { spin.toggle() }
                if taps == 7 {
                    taps = 0
                    CelebrationCenter.shared.fire(Celebration(title: "Пасхалка найдена 🥚",
                                                              subtitle: "Привет от @\(Developer.telegram)!",
                                                              style: .emoji(["🥚", "🐣", "✨", "🔐"])))
                }
            }
            VStack(spacing: 4) {
                Text(Developer.name)
                    .font(.system(.title2, design: .rounded).weight(.heavy))
                Text("Автор и разработчик приложения")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.brand)
                Text(Developer.role)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
        .glass(28)
    }

    private var links: some View {
        VStack(spacing: 10) {
            Button { openURL(Developer.telegramURL) } label: {
                HStack {
                    Image(systemName: "paperplane.fill")
                    Text("Написать в Telegram")
                    Spacer()
                    Text("@\(Developer.telegram)").fontWeight(.bold)
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .padding(16)
                .background(LinearGradient(colors: [Color(red: 0.16, green: 0.62, blue: 0.92), Color(red: 0.13, green: 0.50, blue: 0.85)],
                                           startPoint: .leading, endPoint: .trailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(PressableStyle())

            HStack(spacing: 10) {
                smallLink("ladybug.fill", "Нашёл баг", "Привет! Нашёл баг в САФУ \(Developer.version): ")
                smallLink("lightbulb.fill", "Есть идея", "Привет! Идея для САФУ: ")
            }
        }
    }

    private func smallLink(_ icon: String, _ title: String, _ text: String) -> some View {
        Button {
            UIPasteboard.general.string = text
            Haptics.success()
            openURL(Developer.telegramURL)
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title3).foregroundStyle(brandGradient)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .glass(18)
        }
        .buttonStyle(PressableStyle())
    }

    private var about: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("О приложении").font(.system(.headline, design: .rounded))
            Text("«САФУ» собирает в одном месте расписание из РУЗ, сайты университета, задачи, файлы по предметам, БРС, сессию и дорогу до универа. Без рекламы и лишних разрешений: пароли и данные хранятся только на телефоне.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Divider()
            row("Версия", Developer.version)
            row("Платформа", "iOS 17+, SwiftUI")
            row("Для кого", "Студенты САФУ")
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func row(_ a: String, _ b: String) -> some View {
        HStack {
            Text(a).foregroundStyle(.secondary)
            Spacer()
            Text(b).fontWeight(.semibold)
        }
        .font(.subheadline)
    }

    private var changelog: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Что нового").font(.system(.headline, design: .rounded))
            ForEach(ChangelogEntry.all) { e in
                VStack(alignment: .leading, spacing: 6) {
                    Text("Версия \(e.version)")
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(Color.brand)
                    ForEach(e.items, id: \.self) { i in
                        HStack(alignment: .firstTextBaseline, spacing: 8) {
                            Circle().fill(Color.brand).frame(width: 5, height: 5)
                            Text(i).font(.subheadline)
                        }
                    }
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }
}
