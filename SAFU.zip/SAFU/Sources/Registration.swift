import SwiftUI
import UserNotifications
import WidgetKit

// MARK: - Регистрация
// Первый запуск: имя → высшая школа → группа из РУЗ (по курсам, с поиском) → роль и дорога →
// приложение само загружает расписание, создаёт папки предметов, ставит уведомления и виджет.

// MARK: высшие школы

struct HigherSchool: Identifiable, Hashable {
    let id: Int          // номер института в РУЗ
    let short: String
    let full: String
    let about: String
    let icon: String

    static let all: [HigherSchool] = [
        HigherSchool(id: 3, short: "ВШИТАС", full: "Высшая школа информационных технологий и автоматизированных систем",
                     about: "ИТ, программирование, автоматизация, связь", icon: "cpu"),
        HigherSchool(id: 15, short: "ВИШ", full: "Высшая инженерная школа",
                     about: "Строительство, транспорт, машиностроение", icon: "gearshape.2.fill"),
        HigherSchool(id: 1, short: "ВШЕНиТ", full: "Высшая школа естественных наук и технологий",
                     about: "Биология, химия, география, экология", icon: "leaf.fill"),
        HigherSchool(id: 4, short: "ВШСГНиМК", full: "Высшая школа социально-гуманитарных наук и международной коммуникации",
                     about: "Филология, история, языки, журналистика", icon: "globe.europe.africa.fill"),
        HigherSchool(id: 28, short: "ВШЭУиП", full: "Высшая школа экономики, управления и права",
                     about: "Экономика, менеджмент, юриспруденция", icon: "chart.line.uptrend.xyaxis"),
        HigherSchool(id: 12, short: "ВШЭНиГ", full: "Высшая школа энергетики, нефти и газа",
                     about: "Энергетика, нефтегазовое дело", icon: "bolt.fill"),
        HigherSchool(id: 13, short: "ВШППиФК", full: "Высшая школа психологии, педагогики и физической культуры",
                     about: "Психология, педагогика, спорт", icon: "figure.run"),
        HigherSchool(id: 36, short: "ВШ рыболовства", full: "Высшая школа рыболовства",
                     about: "Рыболовство, водные биоресурсы", icon: "fish.fill"),
    ]

    static func by(_ id: Int) -> HigherSchool? { all.first { $0.id == id } }
}

// MARK: группы из РУЗ

struct RuzGroup: Identifiable, Hashable, Codable {
    let id: String       // номер группы в ссылке РУЗ (group=…)
    let number: String   // номер, который знают студенты: 151621
    let title: String    // направление
    let course: Int?
}

enum RuzDirectory {
    private static func cacheKey(_ inst: Int) -> String { "ruz.groups.\(inst)" }

    /// Группы высшей школы. Список кешируется на неделю — он меняется раз в год
    static func groups(institution: Int, force: Bool = false) async throws -> [RuzGroup] {
        let d = UserDefaults.standard
        if !force, let raw = d.data(forKey: cacheKey(institution)),
           let box = try? JSONDecoder().decode(Box.self, from: raw),
           Date().timeIntervalSince(box.at) < 7 * 86_400, !box.groups.isEmpty {
            return box.groups
        }
        guard let url = URL(string: "\(RuzClient.base)?groups&institution=\(institution)") else { return [] }
        let html = try await RuzClient.fetch(url)
        let list = parse(html)
        if !list.isEmpty, let raw = try? JSONEncoder().encode(Box(at: Date(), groups: list)) {
            d.set(raw, forKey: cacheKey(institution))
        }
        return list
    }

    private struct Box: Codable {
        let at: Date
        let groups: [RuzGroup]
    }

    /// Разбор страницы групп: ссылки «group=ID» с номером и направлением, курс — по ближайшему заголовку «N курс»
    static func parse(_ html: String) -> [RuzGroup] {
        let ns = html as NSString
        // заголовки курсов в тексте («1 курс») и в разметке (id="course_1")
        var heads: [(pos: Int, course: Int)] = []
        for pattern in ["(\\d)\\s*курс", "course[_-]?(\\d)"] {
            for m in html.rx(pattern, [.caseInsensitive]) {
                if let c = Int(html.sub(m.range(at: 1))), (1...6).contains(c) { heads.append((m.range.location, c)) }
            }
        }
        heads.sort { $0.pos < $1.pos }

        let links = html.rx("group=(\\d+)")
        var seen = Set<String>()
        var out: [RuzGroup] = []
        for (i, m) in links.enumerated() {
            let id = html.sub(m.range(at: 1))
            guard !seen.contains(id) else { continue }
            let from = m.range.location + m.range.length
            let to = i + 1 < links.count ? links[i + 1].range.location : min(ns.length, from + 600)
            guard to > from else { continue }
            var raw = ns.substring(with: NSRange(location: from, length: min(to - from, 600)))
            // остаток атрибутов ссылки до «>» и всё после «</a>» не нужно
            if let gt = raw.firstIndex(of: ">") { raw = String(raw[raw.index(after: gt)...]) }
            if let end = raw.range(of: "</a>", options: .caseInsensitive) { raw = String(raw[..<end.lowerBound]) }
            let text = RuzClient.decodeEntities(RuzClient.stripTags(raw))
                .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard let nm = text.rx("\\b(\\d{6})\\b").first ?? text.rx("\\b(\\d{4,7})\\b").first else { continue }
            let number = text.sub(nm.range(at: 1))
            let title = text.replacingOccurrences(of: number, with: "")
                .trimmingCharacters(in: CharacterSet(charactersIn: " -–—,.:()").union(.whitespacesAndNewlines))
            let course = heads.last(where: { $0.pos < m.range.location })?.course
            seen.insert(id)
            out.append(RuzGroup(id: id, number: number, title: title, course: course))
        }
        return out.sorted { ($0.course ?? 9, $0.number) < ($1.course ?? 9, $1.number) }
    }
}

// MARK: - Экран регистрации

struct RegistrationView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    /// Показан из профиля повторно — можно закрыть без изменений
    var canClose = false
    let onDone: () -> Void

    private enum Step: Int, CaseIterable { case welcome, name, school, group, extras, setup }

    @State private var step: Step = .welcome
    @State private var forward = true

    // имя
    @State private var first = ""
    @State private var last = ""
    @State private var middle = ""
    // учёба
    @State private var school: HigherSchool?
    @State private var groups: [RuzGroup] = []
    @State private var loadingGroups = false
    @State private var groupsError: String?
    @State private var query = ""
    @State private var course: Int?
    @State private var picked: RuzGroup?
    @State private var manual = ""
    @State private var manualMode = false
    // роль и дорога
    @State private var role = 0
    @State private var farAway = false
    // настройка
    @State private var tasks: [SetupTask] = []
    @State private var finished = false
    @State private var showMore = false
    // восстановление из копии прямо с приветствия (новый телефон)
    @State private var picker = false
    @State private var restoring: String?
    @State private var restoreDone: String?

    @FocusState private var focus: Field?
    private enum Field { case first, last, middle, manual }

    private var groupNumber: String {
        (manualMode ? manual : (picked?.number ?? "")).trimmingCharacters(in: .whitespaces)
    }

    private var canContinue: Bool {
        switch step {
        case .welcome: return true
        case .name: return !first.trimmingCharacters(in: .whitespaces).isEmpty
        case .school: return school != nil
        case .group: return groupNumber.count >= 4
        case .extras: return true
        case .setup: return finished
        }
    }

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 0) {
                topBar
                ZStack {
                    page(step)
                        .id(step)
                        .transition(.asymmetric(
                            insertion: .move(edge: forward ? .trailing : .leading).combined(with: .opacity),
                            removal: .move(edge: forward ? .leading : .trailing).combined(with: .opacity)))
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                bottomBar
            }
            CelebrationOverlay()
        }
        .onAppear(perform: prefill)
        .interactiveDismissDisabled(!canClose)
        .onChange(of: role) { v in UserDefaults.standard.set(v, forKey: "user.role") }
        .onChange(of: farAway) { v in
            UserDefaults.standard.set(v, forKey: "commute.enabled")
            if finished { schedule.refreshSideEffects() }
        }
        .alert("Не получилось восстановить", isPresented: Binding(get: { failText != nil }, set: { if !$0 { failText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(failText ?? "")
        }
    }

    // MARK: верх и низ

    private var topBar: some View {
        HStack(spacing: 12) {
            if step != .welcome && step != .setup {
                Button { go(-1) } label: {
                    Image(systemName: "chevron.left").font(.system(size: 16, weight: .bold))
                        .frame(width: 38, height: 38).glass(19)
                }
                .buttonStyle(PressableStyle())
            } else {
                Color.clear.frame(width: 38, height: 38)
            }
            // прогресс по шагам
            HStack(spacing: 5) {
                ForEach(1..<Step.allCases.count, id: \.self) { i in
                    Capsule()
                        .fill(i <= step.rawValue ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.12)))
                        .frame(height: 5)
                }
            }
            .opacity(step == .welcome ? 0 : 1)
            if canClose && step != .setup {
                Button { onDone() } label: {
                    Image(systemName: "xmark").font(.system(size: 15, weight: .bold))
                        .frame(width: 38, height: 38).glass(19)
                }
                .buttonStyle(PressableStyle())
            } else {
                Color.clear.frame(width: 38, height: 38)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 8)
        .animation(.spring(response: 0.4, dampingFraction: 0.85), value: step)
    }

    private var bottomBar: some View {
        Button {
            Haptics.tap()
            if step == .setup { onDone() } else { go(1) }
        } label: {
            Text(buttonTitle)
                .font(.system(.headline, design: .rounded))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 17)
                .background(brandGradient, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .opacity(canContinue ? 1 : 0.4)
        }
        .buttonStyle(PressableStyle())
        .disabled(!canContinue)
        .padding(.horizontal, 20)
        .padding(.bottom, 12)
        .opacity(step == .setup && !finished ? 0 : 1)
    }

    private var buttonTitle: String {
        switch step {
        case .welcome: return "Начать"
        case .extras: return "Настроить всё"
        case .setup: return "Поехали 🚀"
        default: return "Дальше"
        }
    }

    private func go(_ delta: Int) {
        focus = nil
        guard let next = Step(rawValue: step.rawValue + delta) else { return }
        forward = delta > 0
        withAnimation(.spring(response: 0.45, dampingFraction: 0.88)) { step = next }
        if next == .group { loadGroups() }
        if next == .setup { runSetup() }
    }

    // MARK: страницы

    @ViewBuilder private func page(_ s: Step) -> some View {
        switch s {
        case .welcome: welcomePage
        case .name: namePage
        case .school: schoolPage
        case .group: groupPage
        case .extras: extrasPage
        case .setup: setupPage
        }
    }

    private func header(_ title: String, _ text: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(size: 32, weight: .heavy, design: .rounded))
                .foregroundStyle(LinearGradient(colors: [.primary, .primary.opacity(0.75)], startPoint: .top, endPoint: .bottom))
            Text(text).font(.subheadline).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .modifier(AppearIn(delay: 0))
    }

    @State private var glow = false

    @State private var wave = false

    private var welcomePage: some View {
        ZStack {
            WelcomeFlakes()
                .ignoresSafeArea()
                .allowsHitTesting(false)
            VStack(spacing: 26) {
                Spacer()
                ZStack {
                    // мягкое свечение
                    Circle()
                        .fill(RadialGradient(colors: [Color.brand.opacity(0.5), .clear], center: .center, startRadius: 0, endRadius: 120))
                        .frame(width: 240, height: 240)
                        .scaleEffect(glow ? 1.1 : 0.9)
                    // вращающееся кольцо
                    Circle()
                        .trim(from: 0, to: 0.72)
                        .stroke(AngularGradient(colors: [Color.brand, Color.brand2, .clear], center: .center),
                                style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .frame(width: 146, height: 146)
                        .rotationEffect(.degrees(glow ? 360 : 0))
                    Circle()
                        .fill(brandGradient)
                        .frame(width: 116, height: 116)
                        .shadow(color: Color.brand.opacity(0.55), radius: 26, y: 10)
                    Image(systemName: "snowflake")
                        .font(.system(size: 58, weight: .semibold))
                        .foregroundStyle(.white)
                        .rotationEffect(.degrees(glow ? 30 : -30))
                }
                .modifier(AppearIn(delay: 0.05, scale: 0.6))
                .onAppear {
                    withAnimation(.easeInOut(duration: 3).repeatForever(autoreverses: true)) { glow = true }
                    withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true).delay(0.8)) { wave = true }
                }
                VStack(spacing: 10) {
                    HStack(spacing: 8) {
                        Text("Привет!")
                        Text("👋").rotationEffect(.degrees(wave ? 18 : -8), anchor: .bottomTrailing)
                    }
                    .font(.system(size: 42, weight: .heavy, design: .rounded))
                    .modifier(AppearIn(delay: 0.25))
                    Text("Твои пары, файлы и оценки САФУ —\nв одном красивом месте")
                        .font(.system(.body, design: .rounded))
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .modifier(AppearIn(delay: 0.4))
                }
                HStack(spacing: 10) {
                    pill("calendar", "Пары").modifier(AppearIn(delay: 0.55, scale: 0.8))
                    pill("camera.viewfinder", "Доска").modifier(AppearIn(delay: 0.65, scale: 0.8))
                    pill("bell.badge.fill", "Замены").modifier(AppearIn(delay: 0.75, scale: 0.8))
                }
                Spacer()
                Button {
                    picker = true
                } label: {
                    Label("У меня есть резервная копия", systemImage: "arrow.uturn.backward.circle")
                        .font(.subheadline.weight(.semibold))
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color.brand)
                .modifier(AppearIn(delay: 0.95))
            }
            .padding(.horizontal, 24)
        }
        .sheet(isPresented: $picker) {
            DocumentPicker { urls in
                picker = false
                guard let u = urls.first else { return }
                restoreFrom(u)
            }
            .ignoresSafeArea()
        }
        .overlay {
            if let restoring { ProgressOverlay(text: restoring) }
        }
        .alert("Копия восстановлена", isPresented: Binding(get: { restoreDone != nil }, set: { if !$0 { restoreDone = nil } })) {
            Button("Отлично") { onDone() }
        } message: {
            Text(restoreDone ?? "")
        }
    }

    private func pill(_ icon: String, _ title: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(.subheadline, design: .rounded).weight(.semibold))
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .glass(18)
    }

    private func restoreFrom(_ url: URL) {
        restoring = "Восстанавливаю…"
        DispatchQueue.global(qos: .userInitiated).async {
            let result = Result {
                try BackupManager.restore(from: url) { n in
                    DispatchQueue.main.async { restoring = "Восстанавливаю… файлов: \(n)" }
                }
            }
            DispatchQueue.main.async {
                restoring = nil
                switch result {
                case .success(let n):
                    schedule.reloadFromDisk()
                    schedule.refreshSideEffects()
                    restoreDone = "Вернулись настройки, расписание и файлы (\(n)). Для полного применения закрой приложение смахиванием и открой снова."
                    Haptics.success()
                case .failure(let e):
                    restoreDone = nil
                    groupsError = nil
                    restoring = nil
                    failText = e.localizedDescription
                }
            }
        }
    }

    @State private var failText: String?

    private func feature(_ icon: String, _ text: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundStyle(brandGradient).frame(width: 26)
            Text(text).font(.subheadline.weight(.medium))
            Spacer(minLength: 0)
        }
    }

    private var namePage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                header("Как тебя зовут?", "Так приложение будет с тобой здороваться.")
                HStack {
                    Spacer()
                    AvatarEditor(size: 96)
                    Spacer()
                }
                field("Имя", text: $first, focus: .first)
                if showMore || !last.isEmpty {
                    VStack(spacing: 12) {
                        field("Фамилия", text: $last, focus: .last)
                        field("Отчество", text: $middle, focus: .middle)
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                } else {
                    Button {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showMore = true }
                        focus = .last
                    } label: {
                        Label("Фамилия и отчество — для титульников", systemImage: "plus.circle")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(Color.brand)
                }
                Text("Всё хранится только на твоём телефоне.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(24)
        }
        .scrollDismissesKeyboard(.interactively)
        .onAppear { if first.isEmpty { focus = .first } }
    }

    private func field(_ title: String, text: Binding<String>, focus f: Field) -> some View {
        TextField(title, text: text)
            .textInputAutocapitalization(.words)
            .autocorrectionDisabled()
            .textContentType(f == .first ? .givenName : (f == .last ? .familyName : .middleName))
            .focused($focus, equals: f)
            .submitLabel(.next)
            .onSubmit {
                switch f {
                case .first: focus = .last
                case .last: focus = .middle
                default: focus = nil
                }
            }
            .font(.system(.title3, design: .rounded).weight(.semibold))
            .padding(.horizontal, 18)
            .padding(.vertical, 15)
            .glass(18)
    }

    private var schoolPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header("Твоя высшая школа", "По ней подтянутся группы из РУЗ.")
                VStack(spacing: 10) {
                    ForEach(Array(HigherSchool.all.enumerated()), id: \.element.id) { idx, s in
                        Button {
                            Haptics.tap()
                            if school != s { picked = nil; groups = []; course = nil; query = "" }
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { school = s }
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: s.icon)
                                    .font(.system(size: 20, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .frame(width: 46, height: 46)
                                    .background(school == s ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.18)),
                                                in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(s.short).font(.system(.headline, design: .rounded)).foregroundStyle(.primary)
                                    Text(s.full).font(.caption).foregroundStyle(.secondary).lineLimit(2).multilineTextAlignment(.leading)
                                    Text(s.about).font(.caption2).foregroundStyle(.tertiary).lineLimit(1)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: school == s ? "checkmark.circle.fill" : "circle")
                                    .font(.title3)
                                    .symbolEffect(.bounce, value: school == s)
                                    .foregroundStyle(school == s ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary.opacity(0.5)))
                            }
                            .padding(12)
                            .glass(20)
                            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous)
                                .strokeBorder(Color.brand.opacity(school == s ? 0.7 : 0), lineWidth: 2))
                            .scaleEffect(school == s ? 1.02 : 1)
                        }
                        .buttonStyle(PressableStyle())
                        .modifier(AppearIn(delay: 0.05 + Double(idx) * 0.045))
                    }
                }
            }
            .padding(24)
        }
    }

    // MARK: группа

    private var courses: [Int] { Array(Set(groups.compactMap(\.course))).sorted() }

    private var filteredGroups: [RuzGroup] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        return groups.filter { g in
            (course == nil || g.course == course)
                && (q.isEmpty || g.number.contains(q) || g.title.lowercased().contains(q))
        }
    }

    private var groupPage: some View {
        VStack(alignment: .leading, spacing: 14) {
            header("Твоя группа", school.map { "\($0.short): выбери группу — расписание подтянется само." } ?? "")
                .padding(.horizontal, 24)
            if manualMode {
                manualEntry.padding(.horizontal, 24)
                Spacer()
            } else if loadingGroups {
                VStack(spacing: 12) {
                    ProgressView().controlSize(.large)
                    Text("Загружаю группы из РУЗ…").font(.subheadline).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let groupsError {
                VStack(spacing: 14) {
                    Image(systemName: "wifi.exclamationmark").font(.system(size: 40)).foregroundStyle(.secondary)
                    Text(groupsError).font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    Button("Попробовать ещё раз") { loadGroups(force: true) }.font(.headline)
                    Button("Ввести номер группы вручную") { manualMode = true; focus = .manual }.font(.subheadline)
                }
                .padding(24)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                    TextField("Номер или направление", text: $query)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(.horizontal, 14).padding(.vertical, 11)
                .glass(16)
                .padding(.horizontal, 24)
                if courses.count > 1 {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            chip("Все", course == nil) { course = nil }
                            ForEach(courses, id: \.self) { c in chip("\(c) курс", course == c) { course = c } }
                        }
                        .padding(.horizontal, 24)
                    }
                }
                ScrollView {
                    LazyVStack(spacing: 8) {
                        ForEach(filteredGroups) { g in groupRow(g) }
                        if filteredGroups.isEmpty {
                            Text(query.isEmpty ? "В РУЗ нет групп этой школы" : "Ничего не нашлось по «\(query)»")
                                .font(.subheadline).foregroundStyle(.secondary).padding(.top, 20)
                        }
                        Button {
                            manualMode = true
                            manual = query.filter(\.isNumber)
                            focus = .manual
                        } label: {
                            Label("Нет в списке — ввести номер", systemImage: "keyboard")
                                .font(.subheadline.weight(.semibold))
                        }
                        .padding(.vertical, 14)
                    }
                    .padding(.horizontal, 24)
                }
                .scrollDismissesKeyboard(.interactively)
            }
        }
    }

    private func chip(_ title: String, _ on: Bool, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            withAnimation(.easeOut(duration: 0.2)) { action() }
        } label: {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(on ? Color.white : Color.primary)
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.08)), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func groupRow(_ g: RuzGroup) -> some View {
        let on = picked?.id == g.id
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { picked = g }
        } label: {
            HStack(spacing: 12) {
                Text(g.number)
                    .font(.system(.headline, design: .rounded).monospacedDigit())
                    .foregroundStyle(on ? Color.white : Color.primary)
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.08)),
                                in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(g.title.isEmpty ? "Группа \(g.number)" : g.title)
                        .font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                        .lineLimit(2).multilineTextAlignment(.leading)
                    if let c = g.course { Text("\(c) курс").font(.caption).foregroundStyle(.secondary) }
                }
                Spacer(minLength: 0)
                if on { Image(systemName: "checkmark.circle.fill").font(.title3).foregroundStyle(brandGradient) }
            }
            .padding(12)
            .glass(18)
        }
        .buttonStyle(PressableStyle())
    }

    private var manualEntry: some View {
        VStack(alignment: .leading, spacing: 12) {
            TextField("Например, 151621", text: $manual)
                .keyboardType(.numberPad)
                .focused($focus, equals: .manual)
                .font(.system(.title2, design: .rounded).weight(.bold).monospacedDigit())
                .padding(.horizontal, 18).padding(.vertical, 15)
                .glass(18)
            Text("Номер группы — на студенческом или в РУЗ. Приложение найдёт её само, даже если она в другой высшей школе.")
                .font(.caption).foregroundStyle(.secondary)
            if !groups.isEmpty {
                Button("← Вернуться к списку групп") { manualMode = false; focus = nil }.font(.subheadline.weight(.semibold))
            }
        }
    }

    private func loadGroups(force: Bool = false) {
        guard let school, force || groups.isEmpty else { return }
        loadingGroups = true
        groupsError = nil
        Task {
            do {
                let list = try await RuzDirectory.groups(institution: school.id, force: force)
                groups = list
                if list.isEmpty {
                    groupsError = "Не получилось прочитать список групп из РУЗ. Можно ввести номер группы вручную."
                } else if picked == nil, !manual.isEmpty, let g = list.first(where: { $0.number == manual }) {
                    picked = g
                }
            } catch {
                groupsError = "Нет связи с РУЗ. Проверь интернет — или введи номер группы вручную."
            }
            loadingGroups = false
        }
    }

    // MARK: роль и дорога

    @ObservedObject private var buses = BusRouteStore.shared
    @State private var busEditing: BusRoute?
    @State private var busMessage: String?

    private var extrasPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                header("Роль и дорога", "Можно поменять потом в Профиле.")
                    .modifier(AppearIn(delay: 0))
                VStack(alignment: .leading, spacing: 10) {
                    Text("Кто ты в группе").font(.headline)
                    HStack(spacing: 8) {
                        roleCard(0, "Студент", "person.fill")
                        roleCard(1, "Староста", "star.fill")
                        roleCard(2, "Зам", "star.leadinghalf.filled")
                    }
                    Text(role == 0 ? "Всё для учёбы: пары, файлы, оценки." : "Откроется «Посещаемость»: отметки ребят на каждой паре и рассылка группе.")
                        .font(.caption).foregroundStyle(.secondary)
                        .contentTransition(.opacity)
                }
                .modifier(AppearIn(delay: 0.08))
                VStack(alignment: .leading, spacing: 10) {
                    Text("Как добираешься").font(.headline)
                    optionRow(!farAway, "Живу рядом", "Хожу пешком или езжу по городу", "figure.walk") { farAway = false }
                    optionRow(farAway, "Езжу на автобусе", "Выбери свой — подскажу, когда выезжать, чтобы успеть к паре", "bus.fill") { farAway = true }
                    if farAway { busPicker.transition(.opacity.combined(with: .move(edge: .top))) }
                }
                .modifier(AppearIn(delay: 0.16))
            }
            .padding(24)
        }
        .sheet(item: $busEditing) { r in
            BusRouteEditor(route: r) { saved in
                buses.upsert(saved)
                buses.activate(saved)
            }
        }
        .alert("Автобус", isPresented: Binding(get: { busMessage != nil }, set: { if !$0 { busMessage = nil } })) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text(busMessage ?? "")
        }
    }

    private var busPicker: some View {
        VStack(spacing: 8) {
            ForEach(buses.routes) { r in
                let on = r.id == buses.activeID
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { buses.activate(r) }
                } label: {
                    HStack(spacing: 12) {
                        Text(r.number.isEmpty ? "?" : r.number)
                            .font(.system(size: r.number.count > 3 ? 13 : 16, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1).minimumScaleFactor(0.6)
                            .frame(width: 50, height: 40)
                            .background(r.color.gradient, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(r.routeText).font(.subheadline.weight(.semibold)).foregroundStyle(.primary).lineLimit(1)
                            Text("в пути \(r.travelMinutes) мин").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: on ? "checkmark.circle.fill" : "circle")
                            .font(.title3)
                            .foregroundStyle(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary.opacity(0.5)))
                            .symbolEffect(.bounce, value: on)
                    }
                    .padding(10)
                    .glass(18)
                }
                .buttonStyle(PressableStyle())
            }
            HStack(spacing: 8) {
                Button {
                    var r = BusRoute()
                    r.colorHex = BusPalette.hexes.randomElement() ?? "3B82F6"
                    busEditing = r
                } label: {
                    Label("Свой автобус", systemImage: "plus.circle.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .glass(16)
                }
                .buttonStyle(PressableStyle())
                Button {
                    if let text = UIPasteboard.general.string, let r = BusRoute.fromShareCode(text) {
                        buses.upsert(r)
                        buses.activate(r)
                        Haptics.success()
                        busMessage = "\(r.title) добавлен и выбран."
                    } else {
                        busMessage = "В буфере нет кода автобуса. Попроси одногруппника нажать «Поделиться» в его автобусе и скопируй код."
                    }
                } label: {
                    Label("Код от друга", systemImage: "doc.on.clipboard")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 11)
                        .glass(16)
                }
                .buttonStyle(PressableStyle())
            }
        }
    }

    private func roleCard(_ r: Int, _ title: String, _ icon: String) -> some View {
        Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { role = r }
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 20, weight: .semibold))
                Text(title).font(.subheadline.weight(.semibold))
            }
            .foregroundStyle(role == r ? Color.white : Color.primary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(role == r ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.07)),
                        in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(PressableStyle())
    }

    private func optionRow(_ on: Bool, _ title: String, _ text: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { action() }
        } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(on ? Color.white : Color.primary)
                    .frame(width: 44, height: 44)
                    .background(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.08)),
                                in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text(text).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: on ? "checkmark.circle.fill" : "circle").font(.title3)
                    .foregroundStyle(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary.opacity(0.5)))
            }
            .padding(12)
            .glass(20)
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: автонастройка

    struct SetupTask: Identifiable {
        enum Phase { case waiting, running, done, warn }
        let id: Int
        let title: String
        var detail = ""
        var state: Phase = .waiting
    }

    private var setupPage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                header(finished ? "Готово, \(first.trimmingCharacters(in: .whitespaces))! 🎉" : "Настраиваю всё…",
                       finished ? "Приложение настроено под группу \(groupNumber)." : "Это займёт несколько секунд.")
                VStack(spacing: 0) {
                    ForEach(tasks) { t in
                        HStack(alignment: .top, spacing: 12) {
                            Group {
                                switch t.state {
                                case .waiting: Image(systemName: "circle").foregroundStyle(.tertiary)
                                case .running: ProgressView().controlSize(.small)
                                case .done: Image(systemName: "checkmark.circle.fill").foregroundStyle(.green)
                                case .warn: Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.orange)
                                }
                            }
                            .font(.title3)
                            .frame(width: 26)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(t.title).font(.subheadline.weight(.semibold))
                                if !t.detail.isEmpty { Text(t.detail).font(.caption).foregroundStyle(.secondary) }
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(.vertical, 10)
                        .transition(.opacity)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 6)
                .glass(22)
                if finished, let next = nextLesson {
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Ближайшая пара", systemImage: "clock.fill").font(.caption.weight(.bold)).foregroundStyle(Color.brand)
                        Text(next.lesson.subject).font(.headline)
                        Text("\(Fmt.formatter("EEEE, d MMMM, HH:mm").string(from: next.start))\(next.lesson.room.isEmpty ? "" : " · ауд. \(next.lesson.room)")")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .glass(22)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                }
                if finished {
                    Text("Виджет: зажми экран «Домой» → «+» → САФУ. Пара на экране блокировки появится сама.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(24)
        }
    }

    private var nextLesson: LessonSlot? {
        ScheduleQuery.slots(schedule.data, days: 14).first { $0.end > Date() }
    }

    private func setTask(_ id: Int, _ state: SetupTask.Phase, _ detail: String = "") {
        guard let i = tasks.firstIndex(where: { $0.id == id }) else { return }
        withAnimation(.easeOut(duration: 0.25)) {
            tasks[i].state = state
            if !detail.isEmpty { tasks[i].detail = detail }
        }
    }

    private func runSetup() {
        finished = false
        tasks = [
            SetupTask(id: 0, title: "Профиль"),
            SetupTask(id: 1, title: "Расписание группы \(groupNumber) из РУЗ"),
            SetupTask(id: 2, title: "Папки предметов"),
            SetupTask(id: 3, title: "Уведомления о парах и заменах"),
            SetupTask(id: 4, title: "Виджет и экран блокировки"),
        ]
        Task {
            // 1. профиль
            setTask(0, .running)
            saveProfile()
            try? await Task.sleep(nanoseconds: 250_000_000)
            setTask(0, .done, [first, last].filter { !$0.isEmpty }.joined(separator: " ") + (school.map { " · \($0.short)" } ?? ""))

            // 2. расписание
            setTask(1, .running)
            var d = schedule.data
            d.teacherPrefs = [:]           // подгруппы каждый выберет сам на странице предмета
            schedule.data = d
            let inst = school?.id ?? 3
            schedule.connectRuz(number: groupNumber, institution: inst, id: manualMode ? "" : (picked?.id ?? ""))
            await schedule.sync(force: true)
            let count = schedule.data.ruzEvents.count
            if count > 0 {
                setTask(1, .done, "Загружено пар: \(count)")
            } else {
                setTask(1, .warn, schedule.syncMessage ?? "Пока пусто — попробую ещё раз позже, при открытии приложения")
            }

            // 3. папки предметов
            setTask(2, .running)
            let subjects = ScheduleQuery.subjects(schedule.data)
            SubjectFolders.ensureAll(subjects)
            setTask(2, subjects.isEmpty ? .warn : .done,
                    subjects.isEmpty ? "Появятся вместе с расписанием" : "Предметов: \(subjects.count) — для файлов, фото доски и заметок")

            // 4. уведомления
            setTask(3, .running)
            let granted = (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])) ?? false
            schedule.refreshSideEffects()
            Celebrations.scheduleNotifications(data: schedule.data)
            setTask(3, granted ? .done : .warn,
                    granted ? "Напомню о парах, заменах и отменах" : "Выключены — можно включить в Настройках iPhone")

            // 5. виджет
            setTask(4, .running)
            WidgetCenter.shared.reloadAllTimelines()
            try? await Task.sleep(nanoseconds: 300_000_000)
            setTask(4, .done, "Пара с таймером — на экране блокировки и в Dynamic Island")

            Haptics.success()
            withAnimation(.spring(response: 0.5, dampingFraction: 0.85)) { finished = true }
            CelebrationCenter.shared.fire(Celebration(title: "Всё готово! 🎉", subtitle: "Добро пожаловать в САФУ",
                                                      style: .fireworks(big: false), force: true))
        }
    }

    private func saveProfile() {
        let d = UserDefaults.standard
        let f = first.trimmingCharacters(in: .whitespaces)
        let l = last.trimmingCharacters(in: .whitespaces)
        let m = middle.trimmingCharacters(in: .whitespaces)
        d.set([f, l].filter { !$0.isEmpty }.joined(separator: " "), forKey: "user.name")
        d.set(f, forKey: "user.first")
        d.set(l, forKey: "user.last")
        d.set(m, forKey: "user.middle")
        d.set(groupNumber, forKey: "group")
        d.set(role, forKey: "user.role")
        d.set(farAway, forKey: "commute.enabled")
        // для титульника: полное ФИО и высшая школа
        let fio = [l, f, m].filter { !$0.isEmpty }.joined(separator: " ")
        if !fio.isEmpty { d.set(fio, forKey: "report.student") }
        if let school { d.set(school.full, forKey: "report.school") }
    }

    /// Повторная регистрация — подставляем то, что уже знаем
    private func prefill() {
        let d = UserDefaults.standard
        first = d.string(forKey: "user.first") ?? (d.string(forKey: "user.name")?.split(separator: " ").first.map(String.init) ?? "")
        last = d.string(forKey: "user.last") ?? ""
        middle = d.string(forKey: "user.middle") ?? ""
        role = d.integer(forKey: "user.role")
        farAway = d.object(forKey: "commute.enabled") as? Bool ?? false
        if schedule.data.usesRuz {
            school = HigherSchool.by(schedule.data.ruzInstitution)
            manual = schedule.data.ruzGroupNumber
        }
    }
}

// MARK: - Анимации регистрации

/// Плавное появление: снизу вверх, с задержкой — элементы выезжают по очереди
struct AppearIn: ViewModifier {
    let delay: Double
    var scale: CGFloat = 0.97
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 18)
            .scaleEffect(shown ? 1 : scale)
            .onAppear {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.78).delay(delay)) { shown = true }
            }
    }
}

/// Медленно падающие снежинки на приветствии
private struct WelcomeFlakes: View {
    private struct Flake { let x: Double; let y: Double; let size: Double; let speed: Double; let drift: Double; let spin: Double }

    private static let flakes: [Flake] = {
        var seed: UInt64 = 7
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        return (0..<26).map { _ in
            Flake(x: rnd(), y: rnd(), size: 8 + rnd() * 14, speed: 0.02 + rnd() * 0.03, drift: rnd() * 6.28, spin: (rnd() - 0.5) * 1.2)
        }
    }()

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 10_000)
            Canvas { g, size in
                var flake = g.resolve(Image(systemName: "snowflake"))
                flake.shading = .color(Color.brand)
                for f in Self.flakes {
                    let p = (f.y + t * f.speed).truncatingRemainder(dividingBy: 1.1) - 0.05
                    let x = f.x * size.width + sin(t * 0.5 + f.drift) * 18
                    let y = p * size.height
                    var c = g
                    c.opacity = 0.18 + f.size / 60
                    c.translateBy(x: x, y: y)
                    c.rotate(by: .radians(t * f.spin))
                    c.draw(flake, in: CGRect(x: -f.size / 2, y: -f.size / 2, width: f.size, height: f.size))
                }
            }
        }
    }
}
