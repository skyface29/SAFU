import SwiftUI
import UIKit

// MARK: - Mac-версия (Mac Catalyst)
// Интерфейс тот же, что на iPhone: окно узкое, как телефон, но его можно растянуть.
// Компактные размеры экрана держим всегда — раскладка, анимации и заставка остаются iPhone-овскими.

#if targetEnvironment(macCatalyst)

enum MacWindow {
    /// Размеры окна в точках интерфейса (на экране Mac они масштабируются ×0,77)
    static let minSize = CGSize(width: 390, height: 680)
    static let maxSize = CGSize(width: 900, height: 4000)
    static let firstSize = CGSize(width: 480, height: 980)
    @MainActor private static var shrinking = false

    @MainActor
    static func configure() {
        SmokeTour.log("configure scenes=\(UIApplication.shared.connectedScenes.count)")
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            scene.sizeRestrictions?.minimumSize = minSize
            // первый запуск: окно размером с телефон. Дальше macOS сама помнит размер, который выбрал человек
            if !UserDefaults.standard.bool(forKey: "mac.windowSized") {
                UserDefaults.standard.set(true, forKey: "mac.windowSized")
                shrinking = true
                scene.sizeRestrictions?.maximumSize = firstSize
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    shrinking = false
                    scene.sizeRestrictions?.maximumSize = maxSize
                }
            } else if !shrinking {
                scene.sizeRestrictions?.maximumSize = maxSize
            }
            scene.sizeRestrictions?.allowsFullScreen = true
            // раскладка iPhone при любой ширине окна. На уровне сцены тоже: иначе панель вкладок
            // считает окно «широким» и дублирует вкладки в заголовке окна
            scene.traitOverrides.horizontalSizeClass = .compact
            for w in scene.windows {
                w.traitOverrides.horizontalSizeClass = .compact
            }
            hideToolbar(scene)
        }
        // вкладки могут вернуть панель в заголовок уже после первого кадра — убираем ещё раз
        for delay in [0.3, 1.0, 2.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { hideToolbar(scene) }
            }
        }
    }

    /// Без панели в заголовке: приложение во всё окно, как в Telegram для Mac
    /// Своя пустая панель. Если оставить заголовок без панели, вкладки (iOS 18+) ставят туда
    /// свою — со списком вкладок, который дублирует нижнюю панель. Занятое место они не трогают
    @MainActor private static let emptyToolbar: NSToolbar = {
        let t = NSToolbar(identifier: "ru.student.safuhub.empty")
        t.displayMode = .iconOnly
        t.isVisible = false
        return t
    }()

    @MainActor
    static func hideToolbar(_ scene: UIWindowScene) {
        guard let bar = scene.titlebar else { return }
        bar.titleVisibility = .hidden
        bar.toolbarStyle = .unifiedCompact
        if bar.toolbar !== emptyToolbar {
            SmokeTour.log("toolbar replaced")
            bar.toolbar = emptyToolbar
        }
    }
}

/// Проверка сборки в GitHub (запуск с --smoke-tour): приложение само проходит по вкладкам,
/// а сборка снимает скриншоты окна. Без этого флага ничего не происходит
enum SmokeTour {
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("--smoke-tour") }

    @MainActor private static var started = false

    /// В stderr — без буфера, строки видны в журнале сборки сразу
    static func log(_ s: String) {
        guard enabled else { return }
        fputs("SMOKE \(s)\n", stderr)
    }

    @MainActor
    static func run() {
        guard enabled, !started else { return }
        started = true
        let tabs = AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw)
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            for t in tabs {
                UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID")
                log("tab \(t.rawValue)")
                try? await Task.sleep(nanoseconds: 6_000_000_000)
            }
            log("done")
        }
    }
}

/// Подключается к корню приложения: настраивает окно, когда оно появилось
struct MacWindowSetup: ViewModifier {
    @AppStorage("memory.tabID") private var tab = "home"

    func body(content: Content) -> some View {
        content
            .onAppear { MacWindow.configure(); SmokeTour.run() }
            .onReceive(NotificationCenter.default.publisher(for: UIScene.didActivateNotification)) { _ in
                MacWindow.configure()
            }
            .onChange(of: tab) { _ in
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { MacWindow.hideToolbar(scene) }
            }
    }
}

/// Меню «Вид» и горячие клавиши: ⌘1…⌘9 — вкладки в том порядке, в каком они стоят в панели
struct MacCommands: Commands {
    var body: some Commands {
        CommandGroup(replacing: .newItem) { }
        CommandMenu("Разделы") {
            ForEach(Array(AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw).prefix(9).enumerated()),
                    id: \.element.id) { i, t in
                Button(t.title) { UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID") }
                    .keyboardShortcut(KeyEquivalent(Character("\(i + 1)")), modifiers: .command)
            }
        }
    }
}

#else

struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View { content }
}

#endif
