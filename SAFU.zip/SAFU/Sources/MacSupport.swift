import SwiftUI
import UIKit

// MARK: - Mac-версия (Mac Catalyst)
// Интерфейс тот же, что на iPhone: окно узкое, как телефон, но его можно растянуть.
// Компактные размеры экрана держим всегда — раскладка, анимации и заставка остаются iPhone-овскими.

#if targetEnvironment(macCatalyst)

enum MacWindow {
    /// Размеры окна в точках интерфейса (на экране Mac они масштабируются ×0,77)
    static let minSize = CGSize(width: 390, height: 680)
    static let maxSize = CGSize(width: 900, height: 4000)

    @MainActor
    static func configure() {
        SmokeTour.log("configure scenes=\(UIApplication.shared.connectedScenes.count)")
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            scene.sizeRestrictions?.minimumSize = minSize
            scene.sizeRestrictions?.maximumSize = maxSize
            scene.sizeRestrictions?.allowsFullScreen = true
            // без полосы заголовка: приложение во всё окно, как в Telegram для Mac
            if let bar = scene.titlebar {
                bar.titleVisibility = .hidden
                bar.toolbar = nil
            }
            for w in scene.windows {
                // раскладка iPhone при любой ширине окна
                w.traitOverrides.horizontalSizeClass = .compact
            }
        }
    }
}

/// Проверка сборки в GitHub (запуск с --smoke-tour): приложение само проходит по вкладкам,
/// а сборка снимает скриншоты окна. Без этого флага ничего не происходит
enum SmokeTour {
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("--smoke-tour") }

    @MainActor private static var started = false

    /// В stderr — без буфера, строки видны в журнале сборки сразу
    static func log(_ s: String) {
        guard enabled else { return }
        fputs("SMOKE \(s)\n", stderr)
    }

    @MainActor
    static func run() {
        guard enabled, !started else { return }
        started = true
        let tabs = AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw)
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            for t in tabs {
                UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID")
                log("tab \(t.rawValue)")
                try? await Task.sleep(nanoseconds: 6_000_000_000)
            }
            log("done")
        }
    }
}

/// Подключается к корню приложения: настраивает окно, когда оно появилось
struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View {
        content
            .onAppear { MacWindow.configure(); SmokeTour.run() }
            .onReceive(NotificationCenter.default.publisher(for: UIScene.didActivateNotification)) { _ in
                MacWindow.configure()
            }
    }
}

/// Меню «Вид» и горячие клавиши: ⌘1…⌘9 — вкладки в том порядке, в каком они стоят в панели
struct MacCommands: Commands {
    var body: some Commands {
        CommandGroup(replacing: .newItem) { }
        CommandMenu("Разделы") {
            ForEach(Array(AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw).prefix(9).enumerated()),
                    id: \.element.id) { i, t in
                Button(t.title) { UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID") }
                    .keyboardShortcut(KeyEquivalent(Character("\(i + 1)")), modifiers: .command)
            }
        }
    }
}

#else

struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View { content }
}

#endif
