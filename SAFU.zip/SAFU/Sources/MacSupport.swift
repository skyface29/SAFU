import SwiftUI
import UIKit

// MARK: - Mac-версия (Mac Catalyst)
// Окно как у обычного приложения для Mac: слева боковая панель с разделами, справа открытый раздел.
// Сами экраны те же, что на iPhone (компактная ширина держится всегда), поэтому на широком окне
// содержимое стоит колонкой по центру, а фон раздела тянется на всё окно. Окно тянется как угодно,
// во весь экран тоже; в узком окне боковая панель сжимается до значков.

#if targetEnvironment(macCatalyst)

enum MacWindow {
    /// Размеры окна в точках macOS (интерфейс «Оптимизировать для Mac», масштаб 1:1)
    static let minSize = CGSize(width: 640, height: 600)
    static let maxSize = CGSize(width: 8000, height: 8000)
    /// Первое окно: боковая панель и колонка раздела помещаются целиком
    static let firstSize = CGSize(width: 1180, height: 800)
    @MainActor private static var sizing = false

    @MainActor
    static func configure() {
        SmokeTour.log("configure scenes=\(UIApplication.shared.connectedScenes.count)")
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            // первый запуск с боковой панелью: окно нормального размера, даже если раньше было узким, как телефон.
            // Дальше macOS сама помнит размер, который выбрал человек
            if !UserDefaults.standard.bool(forKey: "mac.windowSized.v3") {
                UserDefaults.standard.set(true, forKey: "mac.windowSized.v3")
                sizing = true
                // нижняя и верхняя граница одновременно — окно встаёт ровно в этот размер
                scene.sizeRestrictions?.minimumSize = firstSize
                scene.sizeRestrictions?.maximumSize = firstSize
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    sizing = false
                    scene.sizeRestrictions?.minimumSize = minSize
                    scene.sizeRestrictions?.maximumSize = maxSize
                }
            } else if !sizing {
                scene.sizeRestrictions?.minimumSize = minSize
                scene.sizeRestrictions?.maximumSize = maxSize
            }
            scene.sizeRestrictions?.allowsFullScreen = true
            // экраны свёрстаны под iPhone — компактная ширина при любом окне, но только у самих разделов.
            // Не у сцены и не у окна: тогда листы поверх приложения растягиваются на всё широкое окно,
            // а так открываются карточкой по центру, как на iPad
            for w in scene.windows {
                w.rootViewController?.traitOverrides.horizontalSizeClass = .compact
            }
            hideToolbar(scene)
        }
        // вкладки могут вернуть панель в заголовок уже после первого кадра — убираем ещё раз
        for delay in [0.3, 1.0, 2.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { hideToolbar(scene) }
            }
        }
    }

    /// Без полосы заголовка: приложение во всё окно, кнопки окна (закрыть, свернуть, во весь экран)
    /// стоят прямо над боковой панелью, как в Заметках, Telegram и Finder. Панели вкладок на Mac нет
    /// (вместо неё MacShell), поэтому подставлять пустую панель, как раньше, больше не нужно
    @MainActor
    static func hideToolbar(_ scene: UIWindowScene) {
        guard let bar = scene.titlebar else { return }
        bar.titleVisibility = .hidden
        bar.separatorStyle = .none
        if bar.toolbar != nil {
            SmokeTour.log("toolbar removed")
            bar.toolbar = nil
        }
    }
}

/// Проверка сборки в GitHub (запуск с --smoke-tour): приложение само проходит по вкладкам,
/// а сборка снимает скриншоты окна. Без этого флага ничего не происходит
enum SmokeTour {
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("--smoke-tour") }

    @MainActor private static var started = false

    /// В stderr — без буфера, строки видны в журнале сборки сразу
    static func log(_ s: String) {
        guard enabled else { return }
        fputs("SMOKE \(s)\n", stderr)
    }

    @MainActor
    static func run() {
        guard enabled, !started else { return }
        started = true
        let tabs = AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw)
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            for t in tabs {
                UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID")
                log("tab \(t.rawValue)")
                try? await Task.sleep(nanoseconds: 6_000_000_000)
            }
            log("done")
        }
    }
}

/// Подключается к корню приложения: настраивает окно, когда оно появилось
struct MacWindowSetup: ViewModifier {
    @AppStorage("memory.tabID") private var tab = "home"

    func body(content: Content) -> some View {
        content
            .onAppear { MacWindow.configure(); SmokeTour.run() }
            .onReceive(NotificationCenter.default.publisher(for: UIScene.didActivateNotification)) { _ in
                MacWindow.configure()
            }
            .onChange(of: tab) { _ in
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { MacWindow.hideToolbar(scene) }
            }
    }
}

/// Меню «Вид» и горячие клавиши: ⌘1…⌘9 — вкладки в том порядке, в каком они стоят в панели
struct MacCommands: Commands {
    var body: some Commands {
        CommandGroup(replacing: .newItem) { }
        CommandMenu("Разделы") {
            Button("Поиск…") { NotificationCenter.default.post(name: .macPalette, object: nil) }
                .keyboardShortcut("k", modifiers: .command)
            Divider()
            ForEach(Array(AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw).prefix(9).enumerated()),
                    id: \.element.id) { i, t in
                Button(t.title) { UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID") }
                    .keyboardShortcut(KeyEquivalent(Character("\(i + 1)")), modifiers: .command)
            }
        }
    }
}

// MARK: - Боковая панель и колонка раздела

enum MacLayout {
    static let sidebarWidth: CGFloat = 220
    /// В узком окне от панели остаются только значки
    static let railWidth: CGFloat = 64
    static let railBelow: CGFloat = 940
    /// Колонка обычного раздела: экраны свёрстаны под iPhone, шире они только расползаются
    static let column: CGFloat = 760
    /// С этой ширины раздела главная встаёт в две колонки, а пары — неделей, как в Арктике для Windows
    static let wideFrom: CGFloat = 900
    /// Раздел «Инструменты» в боковой панели (на iPhone это блок главной, отдельной вкладки нет)
    static let toolsID = "tools"

    /// Ширина колонки раздела: главная и пары на широком окне занимают его почти целиком
    static func column(for tab: String, wide: Bool) -> CGFloat {
        guard wide else { return column }
        switch tab {
        case AppTab.home.rawValue: return 1240
        case AppTab.schedule.rawValue: return 1320
        case toolsID: return 1100
        default: return column
        }
    }
}

extension Notification.Name {
    /// ⌘K: поиск по разделам, инструментам, сайтам и предметам
    static let macPalette = Notification.Name("mac.palette")
}

/// Корень окна на Mac вместо панели вкладок. Открыт один раздел, как вкладка на iPhone:
/// при переходе экран появляется заново, и живой фон с подписками включаются вместе с ним
struct MacShell<Content: View>: View {
    let tabs: [AppTab]
    @Binding var tab: String
    let homeworkBadge: Int
    @ViewBuilder let content: (AppTab) -> Content

    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var attendance: AttendanceStore
    @State private var palette = false
    @State private var tool: Tool?
    @State private var subject: SubjectRef?

    /// Раздел может быть и не из панели вкладок iPhone: на Mac в боковой панели есть ещё «Задачи» и «Предметы»
    private var current: AppTab {
        AppTab(rawValue: tab) ?? tabs.first ?? .home
    }

    var body: some View {
        GeometryReader { geo in
            let rail = geo.size.width < MacLayout.railBelow
            let side = rail ? MacLayout.railWidth : MacLayout.sidebarWidth
            let wide = geo.size.width - side >= MacLayout.wideFrom
            HStack(spacing: 0) {
                MacSidebar(tabs: tabs, tab: $tab, homeworkBadge: homeworkBadge, rail: rail) { palette = true }
                    .frame(width: side)
                Rectangle()
                    .fill(Color(.separator).opacity(0.6))
                    .frame(width: 0.5)
                    .ignoresSafeArea()
                section
                    .environment(\.macWide, wide)
                    .modifier(MacColumn(maxWidth: MacLayout.column(for: tab, wide: wide)))
                    // в интерфейсе Mac меню «+» и «…» иначе становятся широкими выпадающими полосами
                    // на всю строку, а простые кнопки — кнопками в рамке. Оставляем вид, под который свёрстаны экраны
                    .menuStyle(.button)
                    .menuIndicator(.hidden)
                    .buttonStyle(.borderless)
                    // iPhone просит связку без QR-кода — окно «Разрешить» поверх любого раздела
                    .modifier(MacSyncAskModifier())
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .macPalette)) { _ in palette = true }
        .sheet(isPresented: $palette) {
            MacPalette(tabs: tabs,
                       onTab: { tab = $0 },
                       onTool: { tool = $0 },
                       onSubject: { subject = SubjectRef(name: $0) },
                       onSite: { QuickOpen.open($0, store: store) })
                .environmentObject(store)
                .environmentObject(schedule)
        }
        .sheet(item: $tool) { t in
            ToolSheet(tool: t)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $subject) { ref in
            SubjectSheet(subject: ref.name)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
    }

    @ViewBuilder
    private var section: some View {
        if tab == MacLayout.toolsID {
            MacToolsPage { tool = $0 }
        } else {
            content(current)
                .id(current)
        }
    }
}

/// Экран колонкой по центру широкого окна. Поля по бокам — безопасной зоной, а не отступом:
/// фон и прокрутка тянутся на всё окно, а карточки, списки и заголовки стоят по центру
struct MacColumn: ViewModifier {
    var maxWidth: CGFloat = MacLayout.column

    func body(content: Content) -> some View {
        GeometryReader { area in
            content
                .safeAreaPadding(.horizontal, max(0, (area.size.width - maxWidth) / 2))
                .frame(width: area.size.width, height: area.size.height)
        }
    }
}

private struct MacSidebar: View {
    let tabs: [AppTab]
    @Binding var tab: String
    let homeworkBadge: Int
    let rail: Bool
    let onSearch: () -> Void
    @EnvironmentObject private var store: ResourceStore
    @AppStorage("user.name") private var userName = ""
    @AppStorage("group") private var group = ""

    /// Разделы панели: вкладки человека (без профиля — он карточкой внизу) и то, чего на iPhone
    /// во вкладках обычно нет, а на большом экране место есть: задачи и предметы
    private var sections: [AppTab] {
        var list = tabs.filter { $0 != .profile }
        for extra in [AppTab.tasks, .subjects] where !list.contains(extra) { list.append(extra) }
        return list
    }

    /// ⌘1…⌘9 — как в меню «Разделы»: по порядку вкладок человека
    private func shortcut(for t: AppTab) -> String? {
        guard let i = tabs.firstIndex(of: t), i < 9 else { return nil }
        return "⌘\(i + 1)"
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: rail ? .center : .leading, spacing: 2) {
                header
                    .padding(.bottom, 14)

                searchRow
                    .padding(.bottom, 10)

                ForEach(sections) { t in
                    let on = t.rawValue == tab
                    MacSidebarRow(title: t.title, selected: on,
                                  badge: t == .homework ? homeworkBadge : 0,
                                  shortcut: shortcut(for: t), rail: rail) {
                        tab = t.rawValue
                    } icon: {
                        Image(systemName: t.icon)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(on ? Color.brand : Color.secondary)
                    }
                }

                let toolsOn = tab == MacLayout.toolsID
                MacSidebarRow(title: "Инструменты", selected: toolsOn, rail: rail) {
                    tab = MacLayout.toolsID
                } icon: {
                    Image(systemName: "wrench.and.screwdriver.fill")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(toolsOn ? Color.brand : Color.secondary)
                }

                // Sakai, почта и другие главные кнопки: на iPhone они над вкладками или на главной
                let quick = Array(store.quick.prefix(6))
                if !quick.isEmpty {
                    sectionTitle("Сайты")
                    ForEach(quick) { r in
                        let key = "mac:" + r.id.uuidString
                        MacSidebarRow(title: r.title, rail: rail) {
                            QuickOpen.open(r, store: store, origin: key, radius: 10)
                        } icon: {
                            SiteIcon(resource: r, size: 18)
                                .background(OriginProbe(key: key))
                        }
                    }
                }
            }
            .padding(.horizontal, rail ? 8 : 12)
            // сверху — место под кнопки окна (закрыть, свернуть, во весь экран): полосы заголовка нет
            .padding(.top, 44)
            .padding(.bottom, 16)
        }
        // профиль — карточкой внизу панели, как в Арктике для Windows и в Telegram
        .safeAreaInset(edge: .bottom, spacing: 0) { profileCard }
        .background(MacSidebarBackground().ignoresSafeArea())
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 9, style: .continuous).fill(brandGradient)
                Image(systemName: "snowflake")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 28, height: 28)
            .shadow(color: Color.brand.opacity(0.3), radius: 4, y: 2)
            if !rail {
                VStack(alignment: .leading, spacing: 1) {
                    Text(AppInfo.name)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                    Text("пары и учёба")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, rail ? 0 : 8)
        .accessibilityElement(children: .combine)
    }

    /// Поиск по всему приложению: выглядит как поле, открывает окно поиска (⌘K)
    private var searchRow: some View {
        let shape = RoundedRectangle(cornerRadius: 8, style: .continuous)
        return Button(action: onSearch) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.secondary)
                if !rail {
                    Text("Поиск")
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                    Spacer(minLength: 4)
                    Text("⌘K")
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, rail ? 0 : 10)
            .frame(maxWidth: .infinity, alignment: rail ? .center : .leading)
            .frame(height: 30)
            .background(shape.fill(Color.primary.opacity(0.06)))
            .overlay(shape.strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
            .contentShape(shape)
        }
        .buttonStyle(.plain)
        .help("Поиск: разделы, инструменты, сайты, предметы (⌘K)")
        .accessibilityLabel("Поиск")
    }

    private var profileCard: some View {
        let on = tab == AppTab.profile.rawValue
        let shape = RoundedRectangle(cornerRadius: 10, style: .continuous)
        return Button { tab = AppTab.profile.rawValue } label: {
            HStack(spacing: 10) {
                AvatarView(size: 30)
                if !rail {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(userName.isEmpty ? "Профиль" : userName)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                        Text(group.isEmpty ? "Настройки" : "Группа \(group) · настройки")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "gearshape")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.horizontal, rail ? 0 : 8)
            .frame(maxWidth: .infinity, alignment: rail ? .center : .leading)
            .frame(height: 46)
            .background {
                if on { shape.fill(Color.brand.opacity(0.15)) }
            }
            .contentShape(shape)
        }
        .buttonStyle(.plain)
        .padding(.horizontal, rail ? 8 : 12)
        .padding(.top, 8)
        .padding(.bottom, 10)
        .background(MacSidebarBackground())
        .overlay(alignment: .top) {
            Rectangle().fill(Color(.separator).opacity(0.5)).frame(height: 0.5)
        }
        .help("Профиль и настройки")
        .accessibilityLabel("Профиль и настройки")
        .accessibilityAddTraits(on ? .isSelected : [])
    }

    @ViewBuilder
    private func sectionTitle(_ s: String) -> some View {
        if rail {
            Divider()
                .padding(.vertical, 10)
                .padding(.horizontal, 12)
        } else {
            Text(s)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.horizontal, 10)
                .padding(.top, 18)
                .padding(.bottom, 4)
        }
    }
}

// MARK: - Инструменты отдельным разделом

/// Все инструменты списком с описаниями: на iPhone это значки на главной, на Mac под них есть целый раздел
struct MacToolsPage: View {
    let onOpen: (Tool) -> Void
    @AppStorage("user.role") private var role = 0

    private var tools: [Tool] {
        Tool.allCases.filter { t in
            // перенос «на компьютер» — про iPhone: Mac сам компьютер
            if t == .computer { return false }
            if role == 0 && (t == .attendance || t == .broadcast) { return false }
            if TeacherMode.isOn && [.session, .grades, .report, .lectures, .wake].contains(t) { return false }
            return true
        }
    }

    var body: some View {
        ZStack {
            AmbientBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    ScreenHeader(caption: "Всё для учёбы", title: "Инструменты") { EmptyView() }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 230), spacing: 12)], spacing: 12) {
                        ForEach(tools) { t in
                            Button { onOpen(t) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: t.icon)
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundStyle(.white)
                                        .frame(width: 40, height: 40)
                                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(t.title)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.primary)
                                            .lineLimit(1)
                                        Text(t.subtitle)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(1)
                                    }
                                    Spacer(minLength: 0)
                                }
                                .padding(12)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .glassRow(16)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
        }
    }
}

// MARK: - Поиск по всему приложению (⌘K)

struct MacPalette: View {
    let tabs: [AppTab]
    let onTab: (String) -> Void
    let onTool: (Tool) -> Void
    let onSubject: (String) -> Void
    let onSite: (Resource) -> Void
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @AppStorage("user.role") private var role = 0
    @State private var query = ""
    @FocusState private var focused: Bool

    private struct Hit: Identifiable {
        let id: String
        let icon: String
        let title: String
        let kind: String
        let run: () -> Void
    }

    private var all: [Hit] {
        var out: [Hit] = []
        var sections = tabs
        for extra in [AppTab.tasks, .subjects] where !sections.contains(extra) { sections.append(extra) }
        for t in sections {
            let raw = t.rawValue
            out.append(Hit(id: "tab." + raw, icon: t.icon, title: t.title, kind: "Раздел") { onTab(raw) })
        }
        out.append(Hit(id: "tab.tools", icon: "wrench.and.screwdriver.fill", title: "Инструменты", kind: "Раздел") {
            onTab(MacLayout.toolsID)
        })
        for t in Tool.allCases {
            if t == .computer { continue }
            if role == 0 && (t == .attendance || t == .broadcast) { continue }
            out.append(Hit(id: "tool." + t.rawValue, icon: t.icon, title: t.title, kind: t.subtitle) { onTool(t) })
        }
        for r in store.items {
            out.append(Hit(id: "site." + r.id.uuidString, icon: "globe", title: r.title, kind: "Сайт") { onSite(r) })
        }
        for s in ScheduleQuery.subjects(schedule.data) {
            out.append(Hit(id: "subject." + s, icon: "books.vertical.fill", title: s, kind: "Предмет") { onSubject(s) })
        }
        return out
    }

    private var hits: [Hit] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return Array(all.prefix(60)) }
        return all.filter { $0.title.lowercased().contains(q) || $0.kind.lowercased().contains(q) }
    }

    /// Сначала закрываем окно поиска, потом открываем найденное: два окна разом система не покажет
    private func run(_ h: Hit) {
        dismiss()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { h.run() }
    }

    var body: some View {
        let list = hits
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(.secondary)
                TextField("Разделы, инструменты, сайты, предметы", text: $query)
                    .textFieldStyle(.plain)
                    .font(.title3)
                    .focused($focused)
                    .onSubmit { if let first = list.first { run(first) } }
                Button("Закрыть") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }
            .padding(16)
            Divider()
            ScrollView {
                LazyVStack(spacing: 2) {
                    ForEach(list) { h in
                        Button { run(h) } label: {
                            HStack(spacing: 12) {
                                Image(systemName: h.icon)
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundStyle(Color.brand)
                                    .frame(width: 24)
                                Text(h.title)
                                    .font(.body)
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                Spacer(minLength: 8)
                                Text(h.kind)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                            .padding(.horizontal, 12)
                            .frame(height: 36)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    if list.isEmpty {
                        Text("Ничего не нашлось")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .padding(.top, 40)
                    }
                }
                .padding(8)
            }
        }
        .frame(minWidth: 520, minHeight: 460)
        .onAppear { focused = true }
    }
}

private struct MacSidebarRow<Icon: View>: View {
    let title: String
    var selected = false
    var badge = 0
    var shortcut: String? = nil
    let rail: Bool
    let action: () -> Void
    @ViewBuilder let icon: () -> Icon
    @State private var hover = false

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 7, style: .continuous)
        Button(action: action) {
            HStack(spacing: 10) {
                icon()
                    .frame(width: 20, height: 20)
                    .overlay(alignment: .topTrailing) {
                        // в узкой панели числа не помещаются — точка, как на значке приложения
                        if rail && badge > 0 {
                            Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 3, y: -2)
                        }
                    }
                if !rail {
                    Text(title)
                        .font(.system(size: 13, weight: selected ? .semibold : .regular))
                        .foregroundStyle(selected ? Color.primary : Color.primary.opacity(0.8))
                        .lineLimit(1)
                    Spacer(minLength: 4)
                    if badge > 0 {
                        Text("\(badge)")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 7)
                            .frame(minWidth: 22, minHeight: 20)
                            .background(Capsule().fill(Color.red))
                    } else if hover, let s = shortcut {
                        Text(s)
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
            }
            .padding(.horizontal, rail ? 0 : 10)
            .frame(maxWidth: .infinity, alignment: rail ? .center : .leading)
            .frame(height: 30)
            .background {
                if selected {
                    shape.fill(Color.brand.opacity(0.15))
                } else if hover {
                    shape.fill(Color.primary.opacity(0.06))
                }
            }
            .contentShape(shape)
        }
        .buttonStyle(.plain)
        .onHover { hover = $0 }
        .help(title)
        .accessibilityLabel(badge > 0 ? "\(title), \(badge)" : title)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

/// Фон панели: спокойный серый, как у боковых панелей macOS, с лёгким оттенком темы сверху
private struct MacSidebarBackground: View {
    var body: some View {
        ZStack {
            Color.dyn(0xF2F3F7, 0x16181D)
            LinearGradient(colors: [Color.brand.opacity(0.10), .clear], startPoint: .top, endPoint: .center)
        }
    }
}

#else

struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View { content }
}

struct MacColumn: ViewModifier {
    var maxWidth: CGFloat = 760
    func body(content: Content) -> some View { content }
}

#endif

// MARK: - Широкое окно

/// Раздел стоит в широком окне Mac: главная раскладывается в две колонки, пары — неделей.
/// На iPhone всегда false
private struct MacWideKey: EnvironmentKey {
    static let defaultValue = false
}

extension EnvironmentValues {
    var macWide: Bool {
        get { self[MacWideKey.self] }
        set { self[MacWideKey.self] = newValue }
    }
}

/// «Сегодня» в правой колонке главной на Mac: все пары дня списком, как в Арктике для Windows
struct MacTodayCard: View {
    let data: ScheduleData
    let onOpen: () -> Void

    var body: some View {
        TimelineView(.periodic(from: .now, by: 60)) { ctx in
            card(now: ctx.date)
        }
    }

    private func card(now: Date) -> some View {
        let slots = ScheduleEngine.slots(on: now, data: data)
        let f = Fmt.formatter("H:mm")
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                SectionTitle(text: "Сегодня")
                Spacer()
                Button(action: onOpen) {
                    HStack(spacing: 4) {
                        Text("Все пары")
                        Image(systemName: "chevron.right")
                    }
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
            if slots.isEmpty {
                Text("Сегодня пар нет")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .padding(.vertical, 6)
            }
            ForEach(slots, id: \.key) { s in
                let st = KindStyle.of(s.lesson.kind)
                let live = s.start <= now && now < s.end
                HStack(alignment: .top, spacing: 10) {
                    Capsule().fill(st.color).frame(width: 3)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(f.string(from: s.start))
                            .font(.subheadline.weight(.bold))
                            .monospacedDigit()
                        Text(f.string(from: s.end))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                    }
                    .frame(width: 44, alignment: .leading)
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 6) {
                            KindBadge(kind: s.lesson.kind, size: 9, filled: false)
                            if live {
                                Text("ИДЁТ")
                                    .font(.system(size: 9, weight: .heavy))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.green, in: Capsule())
                            }
                        }
                        Text(s.lesson.subject)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(2)
                            .fixedSize(horizontal: false, vertical: true)
                        if !s.place.isEmpty {
                            Text(s.place)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.primary.opacity(live ? 0.09 : 0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay {
                    if live {
                        RoundedRectangle(cornerRadius: 14, style: .continuous).strokeBorder(Color.brand.opacity(0.7), lineWidth: 1)
                    }
                }
                .opacity(s.end < now ? 0.55 : 1)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }
}
