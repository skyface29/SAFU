import SwiftUI
import UIKit

// MARK: - Mac-версия (Mac Catalyst)
// Интерфейс тот же, что на iPhone: окно узкое, как телефон, но его можно растянуть.
// Компактные размеры экрана держим всегда — раскладка, анимации и заставка остаются iPhone-овскими.

#if targetEnvironment(macCatalyst)

enum MacWindow {
    /// Размеры окна в точках интерфейса (на экране Mac они масштабируются ×0,77)
    static let minSize = CGSize(width: 390, height: 680)
    static let maxSize = CGSize(width: 900, height: 4000)

    @MainActor
    static func configure() {
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            scene.sizeRestrictions?.minimumSize = minSize
            scene.sizeRestrictions?.maximumSize = maxSize
            scene.sizeRestrictions?.allowsFullScreen = true
            // без полосы заголовка: приложение во всё окно, как в Telegram для Mac
            if let bar = scene.titlebar {
                bar.titleVisibility = .hidden
                bar.toolbar = nil
            }
            for w in scene.windows {
                // раскладка iPhone при любой ширине окна
                w.traitOverrides.horizontalSizeClass = .compact
            }
        }
    }
}

/// Подключается к корню приложения: настраивает окно, когда оно появилось
struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View {
        content
            .onAppear { MacWindow.configure() }
            .onReceive(NotificationCenter.default.publisher(for: UIScene.didActivateNotification)) { _ in
                MacWindow.configure()
            }
    }
}

/// Меню «Вид» и горячие клавиши: ⌘1…⌘9 — вкладки в том порядке, в каком они стоят в панели
struct MacCommands: Commands {
    var body: some Commands {
        CommandGroup(replacing: .newItem) { }
        CommandMenu("Разделы") {
            ForEach(Array(AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw).prefix(9).enumerated()),
                    id: \.element.id) { i, t in
                Button(t.title) { UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID") }
                    .keyboardShortcut(KeyEquivalent(Character("\(i + 1)")), modifiers: .command)
            }
        }
    }
}

#else

struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View { content }
}

#endif
