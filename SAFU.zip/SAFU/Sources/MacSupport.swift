import SwiftUI
import UIKit

// MARK: - Mac-версия (Mac Catalyst)
// Окно как у обычного приложения для Mac: слева боковая панель с разделами, справа открытый раздел.
// Сами экраны те же, что на iPhone (компактная ширина держится всегда), поэтому на широком окне
// содержимое стоит колонкой по центру, а фон раздела тянется на всё окно. Окно тянется как угодно,
// во весь экран тоже; в узком окне боковая панель сжимается до значков.

#if targetEnvironment(macCatalyst)

enum MacWindow {
    /// Размеры окна в точках macOS (интерфейс «Оптимизировать для Mac», масштаб 1:1)
    static let minSize = CGSize(width: 640, height: 600)
    static let maxSize = CGSize(width: 8000, height: 8000)
    /// Первое окно: боковая панель и колонка раздела помещаются целиком
    static let firstSize = CGSize(width: 1180, height: 800)
    @MainActor private static var sizing = false

    @MainActor
    static func configure() {
        SmokeTour.log("configure scenes=\(UIApplication.shared.connectedScenes.count)")
        for case let scene as UIWindowScene in UIApplication.shared.connectedScenes {
            // первый запуск с боковой панелью: окно нормального размера, даже если раньше было узким, как телефон.
            // Дальше macOS сама помнит размер, который выбрал человек
            if !UserDefaults.standard.bool(forKey: "mac.windowSized.v3") {
                UserDefaults.standard.set(true, forKey: "mac.windowSized.v3")
                sizing = true
                // нижняя и верхняя граница одновременно — окно встаёт ровно в этот размер
                scene.sizeRestrictions?.minimumSize = firstSize
                scene.sizeRestrictions?.maximumSize = firstSize
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                    sizing = false
                    scene.sizeRestrictions?.minimumSize = minSize
                    scene.sizeRestrictions?.maximumSize = maxSize
                }
            } else if !sizing {
                scene.sizeRestrictions?.minimumSize = minSize
                scene.sizeRestrictions?.maximumSize = maxSize
            }
            scene.sizeRestrictions?.allowsFullScreen = true
            // экраны свёрстаны под iPhone — компактная ширина при любом окне, но только у самих разделов.
            // Не у сцены и не у окна: тогда листы поверх приложения растягиваются на всё широкое окно,
            // а так открываются карточкой по центру, как на iPad
            for w in scene.windows {
                w.rootViewController?.traitOverrides.horizontalSizeClass = .compact
            }
            hideToolbar(scene)
        }
        // вкладки могут вернуть панель в заголовок уже после первого кадра — убираем ещё раз
        for delay in [0.3, 1.0, 2.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { hideToolbar(scene) }
            }
        }
    }

    /// Без полосы заголовка: приложение во всё окно, кнопки окна (закрыть, свернуть, во весь экран)
    /// стоят прямо над боковой панелью, как в Заметках, Telegram и Finder. Панели вкладок на Mac нет
    /// (вместо неё MacShell), поэтому подставлять пустую панель, как раньше, больше не нужно
    @MainActor
    static func hideToolbar(_ scene: UIWindowScene) {
        guard let bar = scene.titlebar else { return }
        bar.titleVisibility = .hidden
        bar.separatorStyle = .none
        if bar.toolbar != nil {
            SmokeTour.log("toolbar removed")
            bar.toolbar = nil
        }
    }
}

/// Проверка сборки в GitHub (запуск с --smoke-tour): приложение само проходит по вкладкам,
/// а сборка снимает скриншоты окна. Без этого флага ничего не происходит
enum SmokeTour {
    static var enabled: Bool { ProcessInfo.processInfo.arguments.contains("--smoke-tour") }

    @MainActor private static var started = false

    /// В stderr — без буфера, строки видны в журнале сборки сразу
    static func log(_ s: String) {
        guard enabled else { return }
        fputs("SMOKE \(s)\n", stderr)
    }

    @MainActor
    static func run() {
        guard enabled, !started else { return }
        started = true
        let tabs = AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw)
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            for t in tabs {
                UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID")
                log("tab \(t.rawValue)")
                try? await Task.sleep(nanoseconds: 6_000_000_000)
            }
            log("done")
        }
    }
}

/// Подключается к корню приложения: настраивает окно, когда оно появилось
struct MacWindowSetup: ViewModifier {
    @AppStorage("memory.tabID") private var tab = "home"

    func body(content: Content) -> some View {
        content
            .onAppear { MacWindow.configure(); SmokeTour.run() }
            .onReceive(NotificationCenter.default.publisher(for: UIScene.didActivateNotification)) { _ in
                MacWindow.configure()
            }
            .onChange(of: tab) { _ in
                for case let scene as UIWindowScene in UIApplication.shared.connectedScenes { MacWindow.hideToolbar(scene) }
            }
    }
}

/// Меню «Вид» и горячие клавиши: ⌘1…⌘9 — вкладки в том порядке, в каком они стоят в панели
struct MacCommands: Commands {
    var body: some Commands {
        CommandGroup(replacing: .newItem) { }
        CommandMenu("Разделы") {
            ForEach(Array(AppTab.parse(UserDefaults.standard.string(forKey: "tabs.order") ?? AppTab.defaultRaw).prefix(9).enumerated()),
                    id: \.element.id) { i, t in
                Button(t.title) { UserDefaults.standard.set(t.rawValue, forKey: "memory.tabID") }
                    .keyboardShortcut(KeyEquivalent(Character("\(i + 1)")), modifiers: .command)
            }
        }
    }
}

// MARK: - Боковая панель и колонка раздела

enum MacLayout {
    static let sidebarWidth: CGFloat = 220
    /// В узком окне от панели остаются только значки
    static let railWidth: CGFloat = 64
    static let railBelow: CGFloat = 940
    /// Самая широкая колонка раздела: экраны свёрстаны под iPhone, шире они только расползаются
    static let column: CGFloat = 760
}

/// Корень окна на Mac вместо панели вкладок. Открыт один раздел, как вкладка на iPhone:
/// при переходе экран появляется заново, и живой фон с подписками включаются вместе с ним
struct MacShell<Content: View>: View {
    let tabs: [AppTab]
    @Binding var tab: String
    let homeworkBadge: Int
    @ViewBuilder let content: (AppTab) -> Content

    private var current: AppTab {
        tabs.first { $0.rawValue == tab } ?? tabs.first ?? .home
    }

    var body: some View {
        GeometryReader { geo in
            let rail = geo.size.width < MacLayout.railBelow
            HStack(spacing: 0) {
                MacSidebar(tabs: tabs, tab: $tab, homeworkBadge: homeworkBadge, rail: rail)
                    .frame(width: rail ? MacLayout.railWidth : MacLayout.sidebarWidth)
                Rectangle()
                    .fill(Color(.separator).opacity(0.6))
                    .frame(width: 0.5)
                    .ignoresSafeArea()
                content(current)
                    .id(current)
                    .modifier(MacColumn())
                    // в интерфейсе Mac меню «+» и «…» иначе становятся широкими выпадающими полосами
                    // на всю строку, а простые кнопки — кнопками в рамке. Оставляем вид, под который свёрстаны экраны
                    .menuStyle(.button)
                    .menuIndicator(.hidden)
                    .buttonStyle(.borderless)
            }
        }
    }
}

/// Экран колонкой по центру широкого окна. Поля по бокам — безопасной зоной, а не отступом:
/// фон и прокрутка тянутся на всё окно, а карточки, списки и заголовки стоят по центру
struct MacColumn: ViewModifier {
    func body(content: Content) -> some View {
        GeometryReader { area in
            content
                .safeAreaPadding(.horizontal, max(0, (area.size.width - MacLayout.column) / 2))
                .frame(width: area.size.width, height: area.size.height)
        }
    }
}

private struct MacSidebar: View {
    let tabs: [AppTab]
    @Binding var tab: String
    let homeworkBadge: Int
    let rail: Bool
    @EnvironmentObject private var store: ResourceStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: rail ? .center : .leading, spacing: 2) {
                header
                    .padding(.bottom, 18)

                ForEach(Array(tabs.enumerated()), id: \.element.id) { i, t in
                    let on = t.rawValue == tab
                    MacSidebarRow(title: t.title, selected: on,
                                  badge: t == .homework ? homeworkBadge : 0,
                                  shortcut: i < 9 ? "⌘\(i + 1)" : nil, rail: rail) {
                        tab = t.rawValue
                    } icon: {
                        Image(systemName: t.icon)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(on ? Color.brand : Color.secondary)
                    }
                }

                // Sakai, почта и другие главные кнопки: на iPhone они над вкладками или на главной
                let quick = Array(store.quick.prefix(6))
                if !quick.isEmpty {
                    sectionTitle("Сайты")
                    ForEach(quick) { r in
                        let key = "mac:" + r.id.uuidString
                        MacSidebarRow(title: r.title, rail: rail) {
                            QuickOpen.open(r, store: store, origin: key, radius: 10)
                        } icon: {
                            SiteIcon(resource: r, size: 18)
                                .background(OriginProbe(key: key))
                        }
                    }
                }
            }
            .padding(.horizontal, rail ? 8 : 12)
            // сверху — место под кнопки окна (закрыть, свернуть, во весь экран): полосы заголовка нет
            .padding(.top, 44)
            .padding(.bottom, 16)
        }
        .background(MacSidebarBackground().ignoresSafeArea())
    }

    private var header: some View {
        HStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 9, style: .continuous).fill(brandGradient)
                Image(systemName: "snowflake")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 28, height: 28)
            .shadow(color: Color.brand.opacity(0.3), radius: 4, y: 2)
            if !rail {
                VStack(alignment: .leading, spacing: 1) {
                    Text(AppInfo.name)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                    Text("пары и учёба")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
        }
        .padding(.horizontal, rail ? 0 : 8)
        .accessibilityElement(children: .combine)
    }

    @ViewBuilder
    private func sectionTitle(_ s: String) -> some View {
        if rail {
            Divider()
                .padding(.vertical, 10)
                .padding(.horizontal, 12)
        } else {
            Text(s)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.horizontal, 10)
                .padding(.top, 18)
                .padding(.bottom, 4)
        }
    }
}

private struct MacSidebarRow<Icon: View>: View {
    let title: String
    var selected = false
    var badge = 0
    var shortcut: String? = nil
    let rail: Bool
    let action: () -> Void
    @ViewBuilder let icon: () -> Icon
    @State private var hover = false

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: 7, style: .continuous)
        Button(action: action) {
            HStack(spacing: 10) {
                icon()
                    .frame(width: 20, height: 20)
                    .overlay(alignment: .topTrailing) {
                        // в узкой панели числа не помещаются — точка, как на значке приложения
                        if rail && badge > 0 {
                            Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 3, y: -2)
                        }
                    }
                if !rail {
                    Text(title)
                        .font(.system(size: 13, weight: selected ? .semibold : .regular))
                        .foregroundStyle(selected ? Color.primary : Color.primary.opacity(0.8))
                        .lineLimit(1)
                    Spacer(minLength: 4)
                    if badge > 0 {
                        Text("\(badge)")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 7)
                            .frame(minWidth: 22, minHeight: 20)
                            .background(Capsule().fill(Color.red))
                    } else if hover, let s = shortcut {
                        Text(s)
                            .font(.caption)
                            .foregroundStyle(.tertiary)
                    }
                }
            }
            .padding(.horizontal, rail ? 0 : 10)
            .frame(maxWidth: .infinity, alignment: rail ? .center : .leading)
            .frame(height: 30)
            .background {
                if selected {
                    shape.fill(Color.brand.opacity(0.15))
                } else if hover {
                    shape.fill(Color.primary.opacity(0.06))
                }
            }
            .contentShape(shape)
        }
        .buttonStyle(.plain)
        .onHover { hover = $0 }
        .help(title)
        .accessibilityLabel(badge > 0 ? "\(title), \(badge)" : title)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

/// Фон панели: спокойный серый, как у боковых панелей macOS, с лёгким оттенком темы сверху
private struct MacSidebarBackground: View {
    var body: some View {
        ZStack {
            Color.dyn(0xF2F3F7, 0x16181D)
            LinearGradient(colors: [Color.brand.opacity(0.10), .clear], startPoint: .top, endPoint: .center)
        }
    }
}

#else

struct MacWindowSetup: ViewModifier {
    func body(content: Content) -> some View { content }
}

struct MacColumn: ViewModifier {
    func body(content: Content) -> some View { content }
}

#endif
