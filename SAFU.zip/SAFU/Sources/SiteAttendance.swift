import SwiftUI
import CryptoKit

// MARK: - Связка с сайтом старост arktika-app.ru/otmetki/
// Те же группы, пары и отметки, что на сайте: отметил здесь — видно на сайте, у зама, куратора
// и у студентов по их ссылкам. Протокол и шифрование один в один как в site/otmetki/index.html
// (HKDF-SHA256 + AES-GCM, ключ из кода группы). Код группы на сервер не уходит.

enum SiteMark: String, CaseIterable, Identifiable {
    case p, l, e, a, r
    var id: String { rawValue }
    var symbol: String {
        switch self { case .p: return "+"; case .l: return "О"; case .e: return "У"; case .a: return "−"; case .r: return "П" }
    }
    var title: String {
        switch self { case .p: return "Был"; case .l: return "Опоздал"; case .e: return "Уваж."; case .a: return "Нет"; case .r: return "Перезачёт" }
    }
    var color: Color {
        switch self {
        case .p: return Color(red: 0.16, green: 0.75, blue: 0.42)
        case .l: return Color(red: 0.36, green: 0.52, blue: 1.0)
        case .e: return Color(red: 1.0, green: 0.62, blue: 0.10)
        case .a: return Color(red: 0.95, green: 0.28, blue: 0.30)
        case .r: return Color(red: 0.61, green: 0.42, blue: 1.0)
        }
    }
}

enum OtmetkiCrypto {
    static let codeABC = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
    static let idABC = Array("abcdefghjklmnpqrstuvwxyz23456789")

    static func normCode(_ c: String) -> String {
        let up = c.uppercased().replacingOccurrences(of: "0", with: "O").replacingOccurrences(of: "1", with: "I")
        return String(up.filter { codeABC.contains($0) })
    }
    static func fmtCode(_ c: String) -> String {
        let a = Array(c)
        guard a.count == 15 else { return c }
        return String(a[0..<5]) + "-" + String(a[5..<10]) + "-" + String(a[10..<15])
    }

    static func hkdf(_ secret: String, _ info: String, _ len: Int) -> Data {
        let k = HKDF<SHA256>.deriveKey(inputKeyMaterial: SymmetricKey(data: Data(secret.utf8)),
                                       salt: Data("arktika-otmetki-v1".utf8), info: Data(info.utf8), outputByteCount: len)
        return k.withUnsafeBytes { Data($0) }
    }
    static func b32(_ bytes: Data, _ n: Int) -> String {
        var bits = 0, val: UInt32 = 0, out = ""
        for b in bytes {
            val = (val << 8) | UInt32(b); bits += 8
            while bits >= 5 { out.append(idABC[Int((val >> UInt32(bits - 5)) & 31)]); bits -= 5 }
            val &= (UInt32(1) << UInt32(bits)) - 1
        }
        return String(out.prefix(n))
    }
    static func b64u(_ d: Data) -> String {
        d.base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
    static func unb64u(_ s: String) -> Data? {
        var t = s.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while t.count % 4 != 0 { t += "=" }
        return Data(base64Encoded: t)
    }

    struct GroupKeys { let code: String; let gid: String; let w: String; let key: SymmetricKey }
    static func groupKeys(_ code: String) -> GroupKeys {
        let c = normCode(code)
        return GroupKeys(code: c, gid: b32(hkdf(c, "gid", 10), 16), w: b64u(hkdf(c, "write", 24)),
                         key: SymmetricKey(data: hkdf(c, "key", 32)))
    }
    static func studentKeys(gid: String, token: String) -> (tag: String, key: SymmetricKey) {
        let s = gid + ":" + token
        return (b32(hkdf(s, "tag", 10), 16), SymmetricKey(data: hkdf(s, "skey", 32)))
    }
    static func enc(_ key: SymmetricKey, _ obj: Any) throws -> String {
        let json = try JSONSerialization.data(withJSONObject: obj)
        let box = try AES.GCM.seal(json, using: key)
        guard let combined = box.combined else { throw OtmetkiError.message("Не получилось зашифровать") }
        return b64u(combined)
    }
    static func dec(_ key: SymmetricKey, _ s: String) throws -> Any {
        guard let d = unb64u(s) else { throw OtmetkiError.message("Битые данные") }
        let plain = try AES.GCM.open(AES.GCM.SealedBox(combined: d), using: key)
        return try JSONSerialization.jsonObject(with: plain)
    }
    static func shortHash(_ s: String) -> String { b32(Data(SHA256.hash(data: Data(s.utf8))), 8) }
    static func lessonKey(date: String, t: String, subj: String, kind: String, sub: String) -> String {
        "l/" + date + "T" + t.replacingOccurrences(of: ":", with: "") + "-" + shortHash([subj, kind, sub].joined(separator: "|"))
    }
}

enum OtmetkiError: LocalizedError {
    case message(String), http(Int, String), offline
    var errorDescription: String? {
        switch self {
        case .message(let m): return m
        case .http(_, let m): return m
        case .offline: return "Нет связи с сервером отметок"
        }
    }
    var status: Int { if case .http(let s, _) = self { return s }; return 0 }
}

enum OtmetkiAPI {
    static let bases = ["https://functions.yandexcloud.net/d4e8m5ak49b1ggo0cbkh",   // функция Yandex
                        "https://otmetki-api.zarubin-kirillcka.workers.dev/"]         // тот же сервер напрямую
    static let siteURL = URL(string: "https://arktika-app.ru/otmetki/")!
    static let ruzURL = "https://arktika-app.ru/raspisanie/data/web/"
    private static var current = 0

    static func call(_ op: String, _ params: [String: String] = [:], body: [String: Any]? = nil) async throws -> [String: Any] {
        var last: Error = OtmetkiError.offline
        for n in 0..<bases.count {
            let i = (current + n) % bases.count
            var comps = URLComponents(string: bases[i])!
            comps.queryItems = [URLQueryItem(name: "op", value: op)] + params.sorted { $0.key < $1.key }.map { URLQueryItem(name: $0.key, value: $0.value) }
            var req = URLRequest(url: comps.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: body == nil ? 9 : 15)
            if let body {
                req.httpMethod = "POST"
                req.setValue("text/plain", forHTTPHeaderField: "Content-Type")
                req.httpBody = try JSONSerialization.data(withJSONObject: body)
            }
            do {
                let (data, resp) = try await URLSession.shared.data(for: req)
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                let j = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
                if code >= 200 && code < 300 { current = i; return j }
                let err = OtmetkiError.http(code, (j["error"] as? String) ?? "ошибка \(code)")
                if code >= 500 { last = err; continue }
                throw err
            } catch let e as OtmetkiError {
                throw e
            } catch {
                last = OtmetkiError.offline
            }
        }
        throw last
    }

    static func getJSON(_ url: String) async throws -> Any {
        guard let u = URL(string: url) else { throw OtmetkiError.offline }
        let (data, resp) = try await URLSession.shared.data(from: u)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw OtmetkiError.offline }
        return try JSONSerialization.jsonObject(with: data)
    }
}

// MARK: - Данные

struct SiteStudent: Identifiable, Hashable { let id: String; let n: String; let t: String }

/// Одна пара: что в расписании и что уже сохранено на сайте (словарь как есть, чтобы не терять поля сайта)
struct SiteLessonItem: Identifiable, Hashable {
    let key: String
    let date: String
    var t: String, e: String, subj: String, kind: String, teacher: String, sub: String
    var saved: [String: SiteMark]?
    var savedBy: String?
    var id: String { key }
}

@MainActor
final class SiteAttendanceModel: ObservableObject {
    @Published var code: String = UserDefaults.standard.string(forKey: "otmetki.code") ?? "" {
        didSet { UserDefaults.standard.set(code, forKey: "otmetki.code") }
    }
    @Published var who: String = UserDefaults.standard.string(forKey: "otmetki.who") ?? "Староста" {
        didSet { UserDefaults.standard.set(who, forKey: "otmetki.who") }
    }

    @Published var meta: [String: Any] = [:]
    @Published var roster: [SiteStudent] = []
    @Published var items: [SiteLessonItem]?
    @Published var error: String?
    @Published var loading = false
    private var keys: OtmetkiCrypto.GroupKeys?
    private var lessons: [String: [String: Any]] = [:]     // ключ пары → расшифрованный объект сайта

    var name: String { meta["name"] as? String ?? "Группа" }
    var credits: [String: [String]] { meta["credits"] as? [String: [String]] ?? [:] }
    private var subs: [String: [String]] { meta["subs"] as? [String: [String]] ?? [:] }
    private var ruz: (num: String, inst: Int)? {
        guard let r = meta["ruz"] as? [String: Any] else { return nil }
        let num = (r["num"] as? String) ?? (r["num"] as? NSNumber)?.stringValue
        let inst = (r["inst"] as? NSNumber)?.intValue ?? Int(r["inst"] as? String ?? "")
        guard let num, let inst else { return nil }
        return (num, inst)
    }

    static let msk = TimeZone(secondsFromGMT: 3 * 3600)!
    static func mskString(_ d: Date, _ f: String) -> String {
        let df = DateFormatter(); df.locale = Locale(identifier: "en_US_POSIX"); df.timeZone = msk; df.dateFormat = f
        return df.string(from: d)
    }

    /// Подключение: проверяем код, читаем список группы
    func connect(_ raw: String, who w: String) async throws {
        let c = OtmetkiCrypto.normCode(raw)
        guard c.count == 15 else { throw OtmetkiError.message("В коде группы 15 символов, сейчас \(c.count)") }
        let k = OtmetkiCrypto.groupKeys(c)
        _ = try await readMeta(k)
        code = c; who = w
        await load()
    }

    func disconnect() { code = ""; keys = nil; meta = [:]; roster = []; items = nil; lessons = [:] }

    private func readMeta(_ k: OtmetkiCrypto.GroupKeys) async throws -> [String: Any] {
        do {
            let r = try await OtmetkiAPI.call("get", ["g": k.gid, "k": "meta"])
            guard let d = r["d"] as? String, let m = try OtmetkiCrypto.dec(k.key, d) as? [String: Any] else { throw OtmetkiError.message("Не получилось прочитать группу") }
            return m
        } catch let e as OtmetkiError where e.status == 404 {
            throw OtmetkiError.message("Группа с таким кодом не найдена. Проверь код у старосты")
        }
    }

    func load() async {
        guard !code.isEmpty else { return }
        loading = true; error = nil
        defer { loading = false }
        do {
            let k = OtmetkiCrypto.groupKeys(code)
            let m = try await readMeta(k)
            keys = k; meta = m
            roster = (m["roster"] as? [[String: Any]] ?? []).compactMap {
                guard let id = $0["id"] as? String, let n = $0["n"] as? String, let t = $0["t"] as? String else { return nil }
                return SiteStudent(id: id, n: n, t: t)
            }
            // неделя назад + сегодня, по Москве — как на сайте
            let now = Date()
            let days = (0...7).map { Self.mskString(now.addingTimeInterval(Double($0 - 7) * 86400), "yyyy-MM-dd") }
            let months = Array(Set(days.map { String($0.prefix(7)) }))
            var all: [String: [String: Any]] = [:]
            for mo in months {
                let r = try await OtmetkiAPI.call("month", ["g": k.gid, "m": mo])
                for (key, v) in r["items"] as? [String: String] ?? [:] {
                    guard let wrap = try? JSONSerialization.jsonObject(with: Data(v.utf8)) as? [String: Any],
                          let g = wrap["g"] as? String, let les = try? OtmetkiCrypto.dec(k.key, g) as? [String: Any] else { continue }
                    all[key] = les
                }
            }
            lessons = all
            let today = days.last!, soon = Self.mskString(now.addingTimeInterval(3600), "HH:mm")
            var out: [SiteLessonItem] = []
            for d in days {
                for x in await dayItems(d) where x.saved != nil || d < today || x.t <= soon { out.append(x) }
            }
            items = out.reversed()
        } catch {
            self.error = error.localizedDescription
            if items == nil { items = [] }
        }
    }

    private func item(key: String, date: String, from les: [String: Any]) -> SiteLessonItem {
        SiteLessonItem(key: key, date: date, t: les["t"] as? String ?? "", e: les["e"] as? String ?? "",
                       subj: les["subj"] as? String ?? "", kind: les["kind"] as? String ?? "",
                       teacher: les["teacher"] as? String ?? "", sub: les["sub"] as? String ?? "",
                       saved: Self.marks(les), savedBy: les["by"] as? String)
    }
    private static func marks(_ les: [String: Any]) -> [String: SiteMark] {
        var out: [String: SiteMark] = [:]
        for (id, v) in les["marks"] as? [String: String] ?? [:] { if let m = SiteMark(rawValue: v) { out[id] = m } }
        return out
    }

    private func dayItems(_ date: String) async -> [SiteLessonItem] {
        var out: [SiteLessonItem] = [], seen = Set<String>()
        for l in await ruzLessons(date) {
            let k = OtmetkiCrypto.lessonKey(date: date, t: l.t, subj: l.subj, kind: l.kind, sub: l.sub)
            if seen.contains(k) { continue }
            seen.insert(k)
            if let s = lessons[k] { out.append(item(key: k, date: date, from: s)) }
            else { out.append(SiteLessonItem(key: k, date: date, t: l.t, e: l.e, subj: l.subj, kind: l.kind, teacher: l.teacher, sub: l.sub, saved: nil, savedBy: nil)) }
        }
        for (k, s) in lessons where (s["d"] as? String) == date && !seen.contains(k) { out.append(item(key: k, date: date, from: s)) }
        return out.sorted { $0.t < $1.t }
    }

    // зеркало РУЗ — то же, что берёт сайт: от названия, типа и подгруппы зависит ключ пары
    private static var ruzCache: [String: Any] = [:]
    private func ruzLessons(_ date: String) async -> [(t: String, e: String, subj: String, kind: String, teacher: String, sub: String)] {
        guard let ruz else { return [] }
        do {
            let m: [String: Any]
            if let c = Self.ruzCache["m"] as? [String: Any] { m = c } else {
                m = try await OtmetkiAPI.getJSON(OtmetkiAPI.ruzURL + "m.json") as? [String: Any] ?? [:]; Self.ruzCache["m"] = m
            }
            guard let file = (m["s"] as? [String: String])?[String(ruz.inst)] else { return [] }
            let d: [String: Any]
            if let c = Self.ruzCache[file] as? [String: Any] { d = c } else {
                d = try await OtmetkiAPI.getJSON(OtmetkiAPI.ruzURL + file) as? [String: Any] ?? [:]; Self.ruzCache[file] = d
            }
            let S = d["S"] as? [String] ?? [], G = d["G"] as? [[Any]] ?? [], L = d["L"] as? [[NSNumber]] ?? []
            let base = (d["base"] as? NSNumber)?.doubleValue ?? 0
            guard let gi = G.firstIndex(where: { g in
                guard let f = g.first else { return false }
                return ((f as? String) ?? (f as? NSNumber)?.stringValue) == ruz.num
            }) else { return [] }
            func s(_ i: Int) -> String { i >= 0 && i < S.count ? S[i] : "" }
            var out: [(t: String, e: String, subj: String, kind: String, teacher: String, sub: String)] = [], seen = Set<String>()
            for r in L where r.count > 9 && r[9...].contains(where: { $0.intValue == gi }) {
                let st = Date(timeIntervalSince1970: (base + r[0].doubleValue) * 60)
                guard Self.mskString(st, "yyyy-MM-dd") == date else { continue }
                let l = (t: Self.mskString(st, "HH:mm"), e: Self.mskString(st.addingTimeInterval(r[1].doubleValue * 60), "HH:mm"),
                         subj: s(r[2].intValue), kind: s(r[3].intValue), teacher: s(r[4].intValue), sub: s(r[8].intValue))
                let k = [l.t, l.subj, l.kind, l.sub].joined(separator: "|")
                if seen.insert(k).inserted { out.append(l) }
            }
            return out
        } catch { return [] }
    }

    /// Отметки для новой пары: перезачёт с сайта ставится сам (кроме чужой подгруппы)
    func startMarks(_ x: SiteLessonItem) -> [String: SiteMark] {
        var m = x.saved ?? [:]
        let sg = subs[x.sub]
        for st in roster where m[st.id] == nil && (credits[st.id] ?? []).contains(x.subj) && (sg == nil || sg!.contains(st.id)) { m[st.id] = .r }
        return m
    }

    /// Сохранить пару так же, как сайт: шифр для старост + часть каждого студента + подгруппа в meta
    func save(_ x: SiteLessonItem, marks: [String: SiteMark]) async throws {
        guard let k = keys else { throw OtmetkiError.message("Группа не открыта") }
        var les = lessons[x.key] ?? ["d": x.date, "t": x.t, "e": x.e, "subj": x.subj, "kind": x.kind, "teacher": x.teacher, "sub": x.sub]
        les.removeValue(forKey: "_k")
        les["marks"] = marks.mapValues { $0.rawValue }
        les["by"] = who
        les["at"] = Int(Date().timeIntervalSince1970 * 1000)
        let all = try OtmetkiCrypto.enc(k.key, les)
        var parts: [String: String] = [:]
        for st in roster {
            guard let m = marks[st.id] else { continue }
            let sk = OtmetkiCrypto.studentKeys(gid: k.gid, token: st.t)
            parts[sk.tag] = try OtmetkiCrypto.enc(sk.key, ["d": x.date, "t": x.t, "subj": x.subj, "kind": x.kind, "m": m.rawValue])
        }
        let wrap = try JSONSerialization.data(withJSONObject: ["g": all, "s": parts])
        var items: [[String: Any]] = [["k": x.key, "d": String(decoding: wrap, as: UTF8.self)]]
        let was0 = subs[x.sub] ?? []
        let ids = marks.filter { $0.value != .r || was0.contains($0.key) }.map { $0.key }.sorted()
        var newMeta: [String: Any]?
        if !x.sub.isEmpty && !ids.isEmpty && ids.count < roster.count && was0.sorted() != ids {
            var m = meta, s = subs
            s[x.sub] = ids; m["subs"] = s
            m["updated"] = Int(Date().timeIntervalSince1970 * 1000)
            let md = try OtmetkiCrypto.enc(k.key, m)
            items.append(["k": "meta", "d": md])
            newMeta = m
        }
        _ = try await OtmetkiAPI.call("put", body: ["g": k.gid, "w": k.w, "items": items])
        lessons[x.key] = les
        if let newMeta { meta = newMeta }
        if let i = items_index(x.key) { self.items?[i].saved = marks; self.items?[i].savedBy = who }
    }

    func delete(_ x: SiteLessonItem) async throws {
        guard let k = keys else { return }
        _ = try await OtmetkiAPI.call("del", body: ["g": k.gid, "w": k.w, "k": x.key])
        lessons[x.key] = nil
        if let i = items_index(x.key) { self.items?[i].saved = nil; self.items?[i].savedBy = nil }
    }

    private func items_index(_ key: String) -> Int? { items?.firstIndex { $0.key == key } }

    func report(_ x: SiteLessonItem, _ marks: [String: SiteMark]) -> String {
        func by(_ m: SiteMark) -> [String] { roster.filter { marks[$0.id] == m }.map(\.n) }
        let on = by(.p).count + by(.l).count, tot = on + by(.a).count + by(.e).count
        var out = ["\(name), \(x.date)", "\(x.t) \(x.subj)\(x.kind.isEmpty ? "" : " (\(x.kind.lowercased()))"): на паре \(on) из \(tot)"]
        if !by(.a).isEmpty { out.append("Нет: " + by(.a).joined(separator: ", ")) }
        if !by(.l).isEmpty { out.append("Опоздали: " + by(.l).joined(separator: ", ")) }
        if !by(.e).isEmpty { out.append("Уважительная: " + by(.e).joined(separator: ", ")) }
        if !by(.r).isEmpty { out.append("Перезачёт: " + by(.r).joined(separator: ", ")) }
        if by(.a).isEmpty && by(.l).isEmpty && by(.e).isEmpty { out.append("Все на месте") }
        return out.joined(separator: "\n")
    }
}

// MARK: - Экран

struct SiteAttendanceView: View {
    @StateObject private var model = SiteAttendanceModel()
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var codeInput = ""
    @State private var whoInput = "Староста"
    @State private var busy = false
    @State private var connectError: String?
    @State private var selected: String?
    @State private var draft: [String: SiteMark] = [:]
    @State private var base: [String: SiteMark] = [:]
    @State private var confirmUnlink = false
    private let roles = ["Староста", "Зам старосты", "Куратор"]

    var body: some View {
        Group {
            if model.code.isEmpty { connectForm } else { groupView }
        }
        .navigationTitle(model.code.isEmpty ? "Сайт старост" : model.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Готово") { dismiss() } }
            if !model.code.isEmpty {
                ToolbarItem(placement: .primaryAction) {
                    Menu {
                        Button { Task { await model.load() } } label: { Label("Обновить", systemImage: "arrow.clockwise") }
                        Button { openURL(OtmetkiAPI.siteURL) } label: { Label("Открыть сайт", systemImage: "safari") }
                        Button(role: .destructive) { confirmUnlink = true } label: { Label("Отключить сайт", systemImage: "link.badge.plus") }
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
        }
        .confirmationDialog("Отключить сайт?", isPresented: $confirmUnlink, titleVisibility: .visible) {
            Button("Отключить", role: .destructive) { model.disconnect(); selected = nil }
        } message: {
            Text("Отметки на сайте останутся. Посещаемость в приложении снова будет только на этом телефоне.")
        }
        .task { if !model.code.isEmpty && model.items == nil { await model.load() } }
    }

    // MARK: подключение

    private var connectForm: some View {
        Form {
            Section {
                Text("Отметки будут общими с сайтом arktika-app.ru/otmetki: отметил здесь — сразу видно на сайте, у зама, куратора и у студентов по их ссылкам. Код группы есть на сайте во вкладке «Группа». Всё шифруется этим кодом, на сервер он не уходит.")
                    .font(.subheadline).foregroundStyle(.secondary)
            }
            Section("Код группы") {
                TextField("XXXXX-XXXXX-XXXXX", text: $codeInput)
                    .font(.system(.title3, design: .monospaced))
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
            }
            Section("Кто ты в группе") {
                Picker("Роль", selection: $whoInput) { ForEach(roles, id: \.self) { Text($0 == "Зам старосты" ? "Зам" : $0).tag($0) } }
                    .pickerStyle(.segmented)
            }
            if let connectError { Section { Text(connectError).foregroundStyle(.red) } }
            Section {
                Button {
                    busy = true; connectError = nil
                    Task {
                        do { try await model.connect(codeInput, who: whoInput); Haptics.success() }
                        catch { connectError = error.localizedDescription }
                        busy = false
                    }
                } label: {
                    HStack { Spacer(); Text(busy ? "Подключаю…" : "Подключить").bold(); Spacer() }
                }
                .disabled(busy || codeInput.isEmpty)
                Button { openURL(OtmetkiAPI.siteURL) } label: { Label("Группы ещё нет — создать на сайте", systemImage: "safari") }
            } footer: {
                Text("Отметки, сделанные в приложении раньше, никуда не денутся.")
            }
        }
    }

    // MARK: группа

    private var current: SiteLessonItem? { model.items?.first { $0.key == selected } ?? model.items?.first }

    private var groupView: some View {
        List {
            if let e = model.error {
                Section { Label(e, systemImage: "exclamationmark.triangle.fill").foregroundStyle(.orange) }
            }
            Section("Пары за неделю") {
                if model.items == nil { HStack { ProgressView(); Text("Загружаю…").foregroundStyle(.secondary) } }
                else if model.items?.isEmpty == true { Text("За неделю пар нет. Пару можно добавить на сайте вручную.").foregroundStyle(.secondary) }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(model.items ?? []) { x in
                            let on = current?.key == x.key
                            Button { pick(x) } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack(spacing: 4) {
                                        Text(shortDay(x.date) + ", " + x.t).font(.caption2.weight(.bold))
                                        Spacer(minLength: 0)
                                        if x.saved != nil { Image(systemName: "checkmark.circle.fill").font(.caption2) }
                                    }
                                    Text(x.subj.isEmpty ? "Пара" : x.subj).font(.caption.weight(.semibold)).lineLimit(1)
                                }
                                .foregroundStyle(on ? Color.white : Color.primary)
                                .padding(.horizontal, 10).padding(.vertical, 8)
                                .frame(width: 160, alignment: .leading)
                                .background(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.07)),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
            }
            if let x = current {
                lessonSection(x)
            }
        }
        .refreshable { await model.load() }
        .onChange(of: model.items) { _ in if let x = current, selected == nil || draft.isEmpty { reset(x) } }
    }

    private func pick(_ x: SiteLessonItem) { selected = x.key; reset(x) }
    private func reset(_ x: SiteLessonItem) { draft = model.startMarks(x); base = draft }

    @ViewBuilder
    private func lessonSection(_ x: SiteLessonItem) -> some View {
        let on = model.roster.filter { draft[$0.id] == .p || draft[$0.id] == .l }.count
        let tot = on + model.roster.filter { draft[$0.id] == .a || draft[$0.id] == .e }.count
        let unsaved = draft != (x.saved ?? [:])
        Section {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(x.subj.isEmpty ? "Пара" : x.subj).font(.headline).lineLimit(2)
                    Text([shortDay(x.date) + ", " + x.t, x.kind, subName(x.sub)].filter { !$0.isEmpty }.joined(separator: " · "))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(spacing: 0) {
                    Text("\(on)/\(tot)").font(.title2.weight(.heavy)).monospacedDigit()
                    Text("на паре").font(.caption2).foregroundStyle(.secondary)
                }
            }
            HStack(spacing: 14) {
                Button { Haptics.success(); for st in model.roster where draft[st.id] == nil { draft[st.id] = .p } } label: {
                    Label("Остальные были", systemImage: "checkmark.circle.fill")
                }
                Spacer()
                ShareLink(item: model.report(x, draft)) { Image(systemName: "square.and.arrow.up") }
                Button(role: .destructive) { draft = model.startMarks(SiteLessonItem(key: x.key, date: x.date, t: x.t, e: x.e, subj: x.subj, kind: x.kind, teacher: x.teacher, sub: x.sub, saved: nil, savedBy: nil)) } label: {
                    Image(systemName: "arrow.counterclockwise")
                }
            }
            .buttonStyle(.borderless)
            .font(.subheadline.weight(.semibold))
            Button {
                busy = true
                Task {
                    do { try await model.save(x, marks: draft); base = draft; Haptics.success() }
                    catch { model.error = "Не сохранилось: " + error.localizedDescription }
                    busy = false
                }
            } label: {
                HStack {
                    Spacer()
                    Label(busy ? "Сохраняю…" : (x.saved == nil ? "Сохранить на сайт" : (unsaved ? "Сохранить изменения" : "Сохранено")),
                          systemImage: unsaved || x.saved == nil ? "icloud.and.arrow.up" : "checkmark.icloud")
                        .font(.headline).foregroundStyle(.white)
                    Spacer()
                }
                .padding(.vertical, 11)
                .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .opacity(busy || (!unsaved && x.saved != nil) ? 0.5 : 1)
            }
            .buttonStyle(.plain)
            .disabled(busy || (!unsaved && x.saved != nil))
            .listRowInsets(EdgeInsets(top: 6, leading: 12, bottom: 6, trailing: 12))
        } footer: {
            if let by = x.savedBy { Text("Отметил: \(by.lowercased())") }
        }

        Section {
            ForEach(model.roster) { st in
                HStack(spacing: 6) {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(st.n).font(.subheadline.weight(.semibold)).lineLimit(1)
                        if (model.credits[st.id] ?? []).contains(x.subj) {
                            Text("перезачёт").font(.caption2.weight(.bold)).foregroundStyle(SiteMark.r.color)
                        }
                    }
                    Spacer(minLength: 4)
                    ForEach(SiteMark.allCases) { m in
                        let isOn = draft[st.id] == m
                        Button {
                            Haptics.tap()
                            if isOn { draft[st.id] = nil } else { draft[st.id] = m }
                        } label: {
                            Text(m.symbol)
                                .font(.system(size: 15, weight: .black))
                                .frame(width: 34, height: 30)
                                .foregroundStyle(isOn ? .white : m.color)
                                .background(isOn ? m.color : Color.clear, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 9, style: .continuous).stroke(isOn ? m.color : Color.primary.opacity(0.15), lineWidth: 1.5))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(m.title)
                    }
                }
            }
        } footer: {
            Text("+ был, О опоздал, У уважительная, − нет, П перезачёт. Повторное нажатие снимает отметку. Без отметки — не на паре (другая подгруппа). Перезачёты по предметам настраиваются на сайте во вкладке «Группа».")
        }

        if x.saved != nil {
            Section {
                Button(role: .destructive) {
                    Task { do { try await model.delete(x); reset(x) } catch { model.error = error.localizedDescription } }
                } label: { Label("Удалить пару из журнала", systemImage: "trash") }
            }
        }
    }

    private func shortDay(_ d: String) -> String {
        let p = d.split(separator: "-")
        guard p.count == 3 else { return d }
        return "\(Int(p[2]) ?? 0).\(p[1])"
    }
    private func subName(_ x: String) -> String {
        var s = x.replacingOccurrences(of: #"^\d{6}\s*[_\-–.,]*\s*"#, with: "", options: .regularExpression).trimmingCharacters(in: .whitespaces)
        if !s.isEmpty && s.allSatisfy(\.isNumber) { s = "подгруппа " + s }
        return s
    }
}
