import SwiftUI
import UIKit
import PDFKit
import WebKit

// MARK: - Какое окно приложения главное
// На iPhone окно одно. На Mac файлы открываются отдельными окнами, и «первая активная сцена»
// может оказаться окном файла: замок Touch ID, алерты сайтов и «Поделиться» уезжали бы туда.
// Поэтому главное окно запоминаем явно

enum AppScenes {
    private static weak var mainScene: UIWindowScene?
    private static let fileScenes = NSHashTable<UIWindowScene>.weakObjects()

    static func setMain(_ s: UIWindowScene) {
        guard !fileScenes.contains(s) else { return }
        mainScene = s
    }

    static func markFile(_ s: UIWindowScene) { fileScenes.add(s) }
    static func isFile(_ s: UIWindowScene) -> Bool { fileScenes.contains(s) }

    /// Окно приложения (не окно файла). Если ещё не знаем — активное, как раньше
    static var main: UIWindowScene? {
        if let mainScene, mainScene.activationState != .unattached { return mainScene }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .filter { !fileScenes.contains($0) }
        return scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
    }

    /// Главное окно сцены, сверху его открытых листов — для алертов и «Поделиться»
    static var topController: UIViewController? {
        guard let scene = main,
              var top = (scene.windows.first(where: { $0.isKeyWindow }) ?? scene.windows.first)?.rootViewController
        else { return nil }
        while let p = top.presentedViewController { top = p }
        return top
    }
}

/// Сообщает, в какой сцене оказался вид (SwiftUI сам этого не говорит)
struct SceneProbe: UIViewRepresentable {
    let found: (UIWindowScene) -> Void

    func makeUIView(context: Context) -> ProbeView {
        let v = ProbeView()
        v.found = found
        v.isUserInteractionEnabled = false
        return v
    }

    func updateUIView(_ v: ProbeView, context: Context) { v.found = found }

    final class ProbeView: UIView {
        var found: ((UIWindowScene) -> Void)?
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if let s = window?.windowScene { found?(s) }
        }
    }
}

#if targetEnvironment(macCatalyst)

// MARK: - Файлы отдельными окнами (Mac)
// Раньше файл (PDF с Sakai, методичка из папки предмета) открывался карточкой поверх приложения:
// она занимала всё окно, и его нельзя было ни уменьшить, ни увеличить, ни поставить рядом с сайтом.
// Теперь у каждого файла своё обычное окно Mac: тянется за край, во весь экран, ⌘W закрывает,
// ⌘+ и ⌘− меняют масштаб, ⌘0 — по ширине окна

struct MacFileRef: Codable, Hashable {
    var path: String
    /// Куда положить файл кнопкой «Сохранить» (папка предмета для файлов с курса Sakai)
    var saveFolder: String?
    var url: URL { URL(fileURLWithPath: path) }
}

enum MacFiles {
    static let windowID = "file"

    /// Ставит главное окно (MacWindowSetup): у SwiftUI открыть окно можно только из вида
    static var opener: ((MacFileRef) -> Void)?

    /// false — окна открывать некому (приложение ещё не нарисовало главное окно): пусть откроется карточкой
    @discardableResult
    static func open(_ url: URL, saveFolder: URL? = nil) -> Bool {
        guard let opener else { return false }
        opener(MacFileRef(path: url.standardizedFileURL.path, saveFolder: saveFolder?.path))
        return true
    }

    /// Временная папка для файлов, открытых с сайта просто посмотреть (в «Файлы» они не попадают, пока не сохранишь)
    static var viewerDir: URL {
        let d = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Открытые файлы", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }

    /// Файл с сайта, который открывают в окне: документы, а не страницы и не картинки внутри страницы
    static func opensInWindow(mime: String, url: URL) -> Bool {
        let m = mime.lowercased()
        if m == "application/pdf" { return true }
        let ext = url.pathExtension.lowercased()
        // архивы смотреть нечем — они скачиваются, как раньше
        if m.contains("zip") || m.contains("rar") || ["zip", "rar", "7z"].contains(ext) { return false }
        return WebFile.isDocument(mime: m, url: url) && !m.hasPrefix("text/") && !m.hasPrefix("image/") && !m.isEmpty
    }

    /// Старые временные копии (больше недели) — убираем, чтобы кэш не рос
    static func cleanViewer() {
        let fm = FileManager.default
        guard let list = try? fm.contentsOfDirectory(at: viewerDir, includingPropertiesForKeys: [.contentModificationDateKey]) else { return }
        let old = Date().addingTimeInterval(-7 * 86_400)
        for u in list {
            let d = (try? u.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
            if d < old { try? fm.removeItem(at: u) }
        }
    }
}

/// То, что умеет менять масштаб (PDF и HTML; QuickLook масштабируется щипком сам)
protocol MacZoomable: AnyObject {
    func macZoom(by factor: CGFloat)
    func macZoomToFit()
}

/// Держит просмотр файла, пока открыто окно
final class MacFileBox: ObservableObject {
    private(set) var holder: FilePreviewHolder?
    private(set) var url: URL?

    func holder(for url: URL) -> FilePreviewHolder {
        if let holder, self.url == url { return holder }
        let h = FilePreviewHolder(url: url)
        holder = h
        self.url = url
        return h
    }
}

/// Корень окна файла
struct MacFileWindow: View {
    let ref: MacFileRef?
    @StateObject private var box = MacFileBox()
    @ObservedObject private var lock = AppLock.shared
    @SceneStorage("mac.file.sized") private var sized = false
    @State private var saved = false
    @State private var scene: UIWindowScene?

    private var exists: Bool {
        guard let ref else { return false }
        return FileManager.default.fileExists(atPath: ref.path)
    }

    var body: some View {
        VStack(spacing: 0) {
            if let ref, exists {
                let holder = box.holder(for: ref.url)
                bar(ref, zoom: holder.controller as? MacZoomable)
                Divider()
                FileControllerHost(holder: holder)
                    .ignoresSafeArea(edges: .bottom)
            } else {
                missing
            }
        }
        .background(Color(.secondarySystemBackground).ignoresSafeArea())
        .overlay {
            // включён вход по Touch ID и приложение закрыто замком — файл тоже не виден
            if lock.locked { lockCover }
        }
        .background(SceneProbe { s in
            AppScenes.markFile(s)
            setup(s)
        })
        .tint(Color.brand)
    }

    private func setup(_ s: UIWindowScene) {
        guard scene !== s else { return }
        scene = s
        s.title = ref.map { $0.url.lastPathComponent } ?? "Файл"
        s.titlebar?.titleVisibility = .visible
        s.titlebar?.toolbar = nil
        s.sizeRestrictions?.allowsFullScreen = true
        let minSize = CGSize(width: 360, height: 300)
        let maxSize = CGSize(width: 8000, height: 8000)
        // новое окно — удобного размера (A4 по высоте); дальше размер выбирает человек, и macOS его помнит
        if !sized {
            sized = true
            let isPDF = ref.map { FileLook.ext($0.url) == "pdf" } ?? false
            let first = isPDF ? CGSize(width: 820, height: 1000) : CGSize(width: 960, height: 760)
            s.sizeRestrictions?.minimumSize = first
            s.sizeRestrictions?.maximumSize = first
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                s.sizeRestrictions?.minimumSize = minSize
                s.sizeRestrictions?.maximumSize = maxSize
            }
        } else {
            s.sizeRestrictions?.minimumSize = minSize
            s.sizeRestrictions?.maximumSize = maxSize
        }
    }

    // MARK: панель

    private func bar(_ ref: MacFileRef, zoom: MacZoomable?) -> some View {
        let url = ref.url
        return HStack(spacing: 6) {
            Image(systemName: FileLook.ext(url) == "pdf" ? "doc.richtext" : "doc")
                .foregroundStyle(Color.brand)
            Text(url.lastPathComponent)
                .font(.system(size: 13, weight: .semibold))
                .lineLimit(1)
                .truncationMode(.middle)
            Spacer(minLength: 8)

            if let zoom {
                barButton("minus.magnifyingglass", "Уменьшить (⌘−)") { zoom.macZoom(by: 1 / 1.2) }
                    .keyboardShortcut("-", modifiers: .command)
                barButton("arrow.up.left.and.down.right.magnifyingglass", "По размеру окна (⌘0)") { zoom.macZoomToFit() }
                    .keyboardShortcut("0", modifiers: .command)
                barButton("plus.magnifyingglass", "Увеличить (⌘+)") { zoom.macZoom(by: 1.2) }
                    .keyboardShortcut("=", modifiers: .command)
                // ⌘+ на русской и английской раскладке приходит по-разному — ловим оба
                Button("") { zoom.macZoom(by: 1.2) }
                    .keyboardShortcut("+", modifiers: .command)
                    .frame(width: 0, height: 0).opacity(0).accessibilityHidden(true)
                Divider().frame(height: 18).padding(.horizontal, 4)
            }

            if let folder = ref.saveFolder {
                barButton(saved ? "checkmark.circle.fill" : "square.and.arrow.down",
                          saved ? "Сохранено в «\(URL(fileURLWithPath: folder).lastPathComponent)»" : "Сохранить в «Файлы» (⌘S)") {
                    save(url, to: URL(fileURLWithPath: folder))
                }
                .keyboardShortcut("s", modifiers: .command)
                .disabled(saved)
            }
            barButton("folder", "Показать в Finder") {
                UIApplication.shared.open(url.deletingLastPathComponent())
            }
            barButton("square.and.arrow.up", "Поделиться") { share(url) }
        }
        .padding(.horizontal, 12)
        .frame(height: 40)
        .background(.bar)
    }

    private func barButton(_ icon: String, _ help: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .medium))
                .frame(width: 30, height: 28)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .help(help)
        .accessibilityLabel(help)
    }

    private func save(_ url: URL, to folder: URL) {
        let fm = FileManager.default
        try? fm.createDirectory(at: folder, withIntermediateDirectories: true)
        let dest = FileService.uniqueURL(in: folder, name: url.lastPathComponent)
        do {
            try fm.copyItem(at: url, to: dest)
            WebDownloads.shared.add(dest, source: nil)
            Haptics.success()
            saved = true
        } catch {
            saved = false
        }
    }

    private func share(_ url: URL) {
        guard let scene, var top = scene.keyWindow?.rootViewController ?? scene.windows.first?.rootViewController else { return }
        while let p = top.presentedViewController { top = p }
        let vc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let pop = vc.popoverPresentationController {
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.maxX - 30, y: 30, width: 1, height: 1)
        }
        top.present(vc, animated: true)
    }

    // MARK: состояния

    private var missing: some View {
        VStack(spacing: 10) {
            Image(systemName: "doc.questionmark")
                .font(.system(size: 40))
                .foregroundStyle(.secondary)
            Text("Файл не найден")
                .font(.headline)
            Text("Его переместили или удалили. Закрой окно (⌘W) и открой файл заново.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(30)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var lockCover: some View {
        ZStack {
            Rectangle().fill(.ultraThickMaterial).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(Color.brand)
                Text("Арктика закрыта")
                    .font(.headline)
                Button("Открыть по \(AppLock.biometryName)") { AppLock.shared.authenticate() }
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

/// Встраивает просмотр (PDFKit, страница или QuickLook) в окно
private struct FileControllerHost: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .secondarySystemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {
        holder.attach(to: box)
    }
}

#endif
