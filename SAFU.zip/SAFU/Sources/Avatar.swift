import SwiftUI
import UIKit
import PhotosUI

// MARK: - Свой аватар
// Фото обрезается по центру в квадрат 600×600 и хранится только на телефоне.

enum Avatar {
    private static var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("avatar.jpg")
    }

    /// Уже загруженная картинка — чтобы не читать файл на каждой отрисовке
    private static var cached: (rev: Int, image: UIImage?)?

    static func image(rev: Int) -> UIImage? {
        if let c = cached, c.rev == rev { return c.image }
        let img = UIImage(contentsOfFile: fileURL.path)
        cached = (rev, img)
        return img
    }

    static func save(_ image: UIImage) {
        let side = min(image.size.width, image.size.height)
        let target: CGFloat = 600
        let scale = target / max(side, 1)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let square = UIGraphicsImageRenderer(size: CGSize(width: target, height: target), format: format).image { _ in
            let w = image.size.width * scale, h = image.size.height * scale
            image.draw(in: CGRect(x: (target - w) / 2, y: (target - h) / 2, width: w, height: h))
        }
        if let d = square.jpegData(compressionQuality: 0.85) { try? d.write(to: fileURL, options: .atomic) }
        bump()
    }

    static func remove() {
        try? FileManager.default.removeItem(at: fileURL)
        bump()
    }

    private static func bump() {
        let d = UserDefaults.standard
        d.set(d.integer(forKey: "avatar.rev") + 1, forKey: "avatar.rev")
    }
}

/// Круглый аватар: своё фото, иначе инициалы на цвете темы
struct AvatarView: View {
    var size: CGFloat = 44
    @AppStorage("avatar.rev") private var rev = 0
    @AppStorage("user.name") private var userName = ""

    private var initials: String {
        let parts = userName.split(separator: " ").prefix(2)
        return parts.compactMap { $0.first.map(String.init) }.joined().uppercased()
    }

    var body: some View {
        ZStack {
            if let img = Avatar.image(rev: rev) {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                Circle().fill(brandGradient)
                if initials.isEmpty {
                    Image(systemName: "snowflake")
                        .font(.system(size: size * 0.42, weight: .semibold))
                        .foregroundStyle(.white)
                } else {
                    Text(initials)
                        .font(.system(size: size * 0.38, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
        .overlay(Circle().strokeBorder(Color.white.opacity(0.18), lineWidth: 1))
        .accessibilityLabel("Аватар")
    }
}

/// Аватар с меню: выбрать фото, сфоткаться, убрать
struct AvatarEditor: View {
    var size: CGFloat = 64
    @AppStorage("avatar.rev") private var rev = 0
    @State private var menu = false
    @State private var picker = false
    @State private var camera = false
    @State private var item: PhotosPickerItem?

    var body: some View {
        Button {
            Haptics.tap()
            menu = true
        } label: {
            AvatarView(size: size)
                .overlay(alignment: .bottomTrailing) {
                    Image(systemName: "camera.fill")
                        .font(.system(size: size * 0.17, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: size * 0.34, height: size * 0.34)
                        .background(Color.brand, in: Circle())
                        .overlay(Circle().strokeBorder(Color(.systemBackground), lineWidth: 2))
                }
        }
        .buttonStyle(.borderless)
        .confirmationDialog("Аватар", isPresented: $menu, titleVisibility: .visible) {
            Button("Выбрать из фото") { picker = true }
            Button("Сфоткаться") { camera = true }
            if Avatar.image(rev: rev) != nil {
                Button("Убрать фото", role: .destructive) { Avatar.remove() }
            }
        }
        .photosPicker(isPresented: $picker, selection: $item, matching: .images)
        .onChange(of: item) { new in
            guard let new else { return }
            Task {
                if let data = try? await new.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                    await MainActor.run {
                        Avatar.save(img)
                        Haptics.success()
                    }
                }
                await MainActor.run { item = nil }
            }
        }
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { image in
                camera = false
                if let image { Avatar.save(image); Haptics.success() }
            }
            .ignoresSafeArea()
        }
    }
}
