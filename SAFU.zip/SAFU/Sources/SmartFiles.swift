import Foundation
import PDFKit

// MARK: - Понятные имена файлов
// Из Sakai, почты и мессенджеров файлы часто приходят с именем-хешем вроде «cb397392846e…4f4dce42.pdf».
// Такое имя ничего не говорит, поэтому приложение подбирает название по содержимому:
// у PDF это заголовок документа или первая осмысленная строка текста.

enum SmartName {
    /// Имя ничего не говорит: хеш, UUID, «document», «IMG_1234», одни цифры
    static func isJunk(_ base: String) -> Bool {
        let s = base.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if s.isEmpty { return true }
        if s.allSatisfy({ $0.isNumber || $0 == "_" || $0 == "-" || $0 == " " }) { return true }
        // хеш или UUID: длинная строка только из 0-9, a-f и дефисов
        let hex = s.filter { $0.isHexDigit || $0 == "-" || $0 == "_" }
        if s.count >= 12, hex.count == s.count { return true }
        // случайная строка: без пробелов, длинная, много цифр вперемешку с латиницей
        if s.count >= 16, !s.contains(" "),
           s.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "-" || $0 == "_") }),
           Double(s.filter(\.isNumber).count) / Double(s.count) > 0.25 { return true }
        let generic = ["document", "file", "doc", "download", "scan", "untitled", "noname", "attachment",
                       "документ", "файл", "без названия", "вложение", "image", "img", "photo", "dsc", "pxl", "scan"]
        for g in generic where s.hasPrefix(g) {
            let rest = s.dropFirst(g.count)
            if rest.allSatisfy({ $0.isNumber || " _-().".contains($0) }) { return true }
        }
        return false
    }

    /// Название по содержимому файла (nil — подобрать не вышло)
    static func suggest(for url: URL) -> String? {
        guard url.pathExtension.lowercased() == "pdf", let doc = PDFDocument(url: url) else { return nil }
        if let t = doc.documentAttributes?[PDFDocumentAttribute.titleAttribute] as? String,
           let clean = tidy(t), !isJunk(clean) {
            return clean
        }
        // первая осмысленная строка на первых двух страницах
        for i in 0..<min(doc.pageCount, 2) {
            guard let text = doc.page(at: i)?.string else { continue }
            for line in text.components(separatedBy: .newlines) {
                if let t = tidy(line), good(t) { return t }
            }
        }
        return nil
    }

    /// Запасное имя, если по содержимому ничего не нашлось
    static func fallback(subject: String?, ext: String, date: Date = Date()) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "d MMM"
        let kind: String
        switch ext.lowercased() {
        case "pdf", "doc", "docx", "rtf", "odt", "txt": kind = "Документ"
        case "xls", "xlsx", "csv", "ods": kind = "Таблица"
        case "ppt", "pptx", "key", "odp": kind = "Презентация"
        case "jpg", "jpeg", "png", "heic": kind = "Фото"
        default: kind = "Файл"
        }
        if let subject, !subject.isEmpty { return "\(kind) · \(subject) · \(f.string(from: date))" }
        return "\(kind) от \(f.string(from: date))"
    }

    /// Переименовывает файл с «мусорным» именем. Возвращает новый адрес (или старый, если менять не стали)
    @discardableResult
    static func fix(_ url: URL, subject: String? = nil) -> URL {
        let base = url.deletingPathExtension().lastPathComponent
        guard isJunk(base) else { return url }
        let ext = url.pathExtension
        let date = (try? url.resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date()
        let title = suggest(for: url) ?? fallback(subject: subject, ext: ext, date: date)
        let name = FileService.sanitize(title) + (ext.isEmpty ? "" : ".\(ext)")
        let dest = FileService.uniqueURL(in: url.deletingLastPathComponent(), name: name)
        guard (try? FileManager.default.moveItem(at: url, to: dest)) != nil else { return url }
        return dest
    }

    // MARK: - Разбор строки

    private static func tidy(_ raw: String) -> String? {
        var s = raw.replacingOccurrences(of: "\u{00A0}", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines.union(.punctuationCharacters.subtracting(CharacterSet(charactersIn: "«»()№"))))
        for prefix in ["Microsoft Word - ", "Microsoft PowerPoint - ", "Microsoft Excel - "] where s.hasPrefix(prefix) {
            s = String(s.dropFirst(prefix.count))
        }
        for ext in [".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".pdf"] where s.lowercased().hasSuffix(ext) {
            s = String(s.dropLast(ext.count))
        }
        while s.contains("  ") { s = s.replacingOccurrences(of: "  ", with: " ") }
        guard !s.isEmpty else { return nil }
        if s.count > 70 {
            let cut = s.prefix(70)
            s = (cut.lastIndex(of: " ").map { String(cut[..<$0]) } ?? String(cut)) + "…"
        }
        return s
    }

    /// Строка похожа на заголовок: в ней есть слова, а не только номера страниц и даты
    private static func good(_ s: String) -> Bool {
        let letters = s.filter(\.isLetter).count
        guard letters >= 4, s.count >= 5 else { return false }
        guard Double(letters) / Double(s.count) > 0.55 else { return false }
        let low = s.lowercased()
        // служебные строки шапки документа
        for skip in ["министерство", "федеральное государственное", "федеральный", "университет имени", "страница", "page "]
        where low.hasPrefix(skip) { return false }
        return true
    }
}

extension FileItem {
    /// Описание одного файла с диска — для превью и размера
    static func of(_ url: URL) -> FileItem {
        let v = try? url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
        return FileItem(url: url, isDirectory: v?.isDirectory ?? false, size: Int64(v?.fileSize ?? 0),
                        modified: v?.contentModificationDate ?? Date())
    }
}
