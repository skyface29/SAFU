import SwiftUI
import UIKit

// MARK: - Фото доски в папку предмета

struct CameraPicker: UIViewControllerRepresentable {
    let onImage: (UIImage?) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onImage: onImage) }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let vc = UIImagePickerController()
        vc.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onImage: (UIImage?) -> Void
        init(onImage: @escaping (UIImage?) -> Void) { self.onImage = onImage }

        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onImage(info[.originalImage] as? UIImage)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            onImage(nil)
        }
    }
}

enum BoardPhoto {
    private static let nameFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        // секунды в названии — чтобы фото одной пары шли строго по порядку съёмки
        f.dateFormat = "dd.MM HH-mm-ss"
        return f
    }()

    /// Сохраняет снимок в «Файлы › Предметы › <предмет>» с датой в названии.
    /// Сжатие 12-Мп снимка и запись идут в фоне: камера закрывается сразу, без подвисания
    @discardableResult
    static func save(_ image: UIImage, subject: String) -> URL? {
        let dir = SubjectFolders.url(subject)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let now = Date()
        let url = FileService.uniqueURL(in: dir, name: "Доска \(nameFormatter.string(from: now)).jpg")
        // место под файл занимаем сразу: второй снимок в ту же секунду получит «(2)», а не перезапишет первый
        guard FileManager.default.createFile(atPath: url.path, contents: nil) else { return nil }
        BoardScan.store(image, at: url, subject: subject, date: now)   // записать, выпрямить, распознать текст
        BoardReminder.schedule(subject: subject)                        // после пары — «отправь ребятам»
        return url
    }
}

extension Notification.Name {
    /// Фото доски записано на диск — списки фото обновляются
    static let boardPhotoWritten = Notification.Name("safu.boardPhotoWritten")
}
