import SwiftUI
import UIKit

// MARK: - Фото доски в папку предмета

struct CameraPicker: UIViewControllerRepresentable {
    let onImage: (UIImage?) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onImage: onImage) }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let vc = UIImagePickerController()
        vc.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    final class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onImage: (UIImage?) -> Void
        init(onImage: @escaping (UIImage?) -> Void) { self.onImage = onImage }

        func imagePickerController(_ picker: UIImagePickerController,
                                   didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            onImage(info[.originalImage] as? UIImage)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            onImage(nil)
        }
    }
}

enum BoardPhoto {
    /// Сохраняет снимок в «Файлы › Предметы › <предмет>» с датой в названии
    @discardableResult
    static func save(_ image: UIImage, subject: String) -> URL? {
        guard let data = image.jpegData(compressionQuality: 0.85) else { return nil }
        let dir = SubjectFolders.url(subject)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let f = DateFormatter()
        // секунды в названии — чтобы фото одной пары шли строго по порядку съёмки
        f.dateFormat = "dd.MM HH-mm-ss"
        let now = Date()
        let url = FileService.uniqueURL(in: dir, name: "Доска \(f.string(from: now)).jpg")
        do {
            try data.write(to: url)
            BoardScan.process(fileAt: url, subject: subject, date: now)   // выпрямить + распознать текст для поиска
            BoardReminder.schedule(subject: subject)                        // после пары — «отправь ребятам»
            return url
        } catch {
            return nil
        }
    }
}
