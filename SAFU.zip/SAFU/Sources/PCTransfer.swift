import SwiftUI
import AVFoundation
import CryptoKit
import UIKit

// MARK: - Перенос на компьютер по QR-коду
//
// На компьютере (Арктика для Windows) открывается экран с QR-кодом. Телефон сканирует его — камерой
// iPhone или прямо здесь — и сам присылает файлы предметов, фото доски, записи лекций и данные (ДЗ,
// задачи, заметки, оценки, настройки) по Wi‑Fi, напрямую, без интернета, облаков и кабеля.
//
// В коде — адрес компьютера в домашней сети и одноразовый ключ. Всё, что идёт по сети, зашифровано
// AES-256-GCM этим ключом, к шифру привязан адрес запроса: подсмотреть или подменить файлы в общей
// сети нельзя. Связь оборвалась — компьютер помнит, сколько принял, и перенос продолжится с того же места.
// Повторный перенос шлёт только новое.

// MARK: ссылка из QR

struct PCLink: Identifiable, Equatable {
    let hosts: [String]
    let port: Int
    let session: String
    let keyData: Data
    let name: String
    var id: String { session }
    var key: SymmetricKey { SymmetricKey(data: keyData) }

    init?(string: String) {
        guard let u = URL(string: string.trimmingCharacters(in: .whitespacesAndNewlines)) else { return nil }
        self.init(url: u)
    }

    init?(url: URL) {
        guard url.scheme?.lowercased() == "arktika", url.host?.lowercased() == "pc",
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems else { return nil }
        func value(_ n: String) -> String? { items.first { $0.name == n }?.value }
        guard let h = value("h"), let p = value("p").flatMap({ Int($0) }), (1...65535).contains(p),
              let s = value("s"), !s.isEmpty, s.count < 64,
              let k = value("k"), let key = Data(base64URL: k), key.count == 32 else { return nil }
        // только адреса домашней сети: код с чужим адресом в интернете не уведёт файлы наружу
        let list = h.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }.filter(Self.isLocal)
        guard !list.isEmpty else { return nil }
        hosts = Array(list.prefix(4))
        port = p
        session = s
        keyData = key
        let n = (value("n") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        name = n.isEmpty ? "Компьютер" : String(n.prefix(40))
    }

    static func isLocal(_ s: String) -> Bool {
        let p = s.split(separator: ".").compactMap { Int($0) }
        guard p.count == 4, p.allSatisfy({ (0...255).contains($0) }) else { return false }
        return p[0] == 10 || (p[0] == 172 && (16...31).contains(p[1])) || (p[0] == 192 && p[1] == 168)
    }
}

extension Data {
    /// base64url без «=» в конце (так ключ записан в QR)
    init?(base64URL s: String) {
        var b = s.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while b.count % 4 != 0 { b += "=" }
        self.init(base64Encoded: b)
    }
}

/// Открыть перенос из ссылки (камера iPhone открыла приложение по QR-коду)
final class PCTransferRouter: ObservableObject {
    static let shared = PCTransferRouter()
    @Published var link: PCLink?
}

// MARK: шифр и сеть

enum PCTransferError: LocalizedError {
    case unreachable, expired, rejected(Int), broken

    var errorDescription: String? {
        switch self {
        case .unreachable:
            return "Не вижу компьютер. Проверь, что телефон и компьютер в одной сети Wi‑Fi и на компьютере открыт экран с QR-кодом. Если iPhone спрашивал про устройства в локальной сети — разреши: Настройки → Арктика → Локальная сеть."
        case .expired:
            return "Этот QR-код уже не действует. Нажми на компьютере «Новый код» и отсканируй его."
        case .rejected(let code):
            return "Компьютер не принял данные (ошибка \(code)). Обнови Арктику на компьютере и попробуй ещё раз."
        case .broken:
            return "Ответ компьютера повреждён. Попробуй ещё раз."
        }
    }
}

enum PCCrypto {
    /// AES-256-GCM: nonce (12 байт) + шифр + метка (16 байт). К шифру привязан метод и адрес запроса
    static func seal(_ data: Data, key: SymmetricKey, aad: String) throws -> Data {
        let box = try AES.GCM.seal(data, using: key, nonce: AES.GCM.Nonce(), authenticating: Data(aad.utf8))
        guard let combined = box.combined else { throw PCTransferError.broken }
        return combined
    }

    static func open(_ data: Data, key: SymmetricKey, aad: String) throws -> Data {
        try AES.GCM.open(AES.GCM.SealedBox(combined: data), using: key, authenticating: Data(aad.utf8))
    }
}

final class PCClient {
    let link: PCLink
    private(set) var base: URL?
    private let session: URLSession

    struct Hello { let pc: String; let app: String }

    init(link: PCLink) {
        self.link = link
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 25
        c.timeoutIntervalForResource = 600
        c.waitsForConnectivity = false
        c.httpMaximumConnectionsPerHost = 2
        c.urlCache = nil
        session = URLSession(configuration: c)
    }

    deinit { session.invalidateAndCancel() }

    private enum Outcome { case ok(URL, Hello), rejected(Int), failed }

    /// Найти компьютер: пробуем все его адреса сразу, повторяем, пока iPhone спрашивает разрешение на локальную сеть
    func hello(device: String, app: String) async throws -> Hello {
        let deadline = Date().addingTimeInterval(30)
        let body = try JSONSerialization.data(withJSONObject: ["device": device, "app": app])
        while true {
            try Task.checkCancellation()
            let outcomes: [Outcome] = await withTaskGroup(of: Outcome.self) { group in
                for h in link.hosts {
                    guard let base = URL(string: "http://\(h):\(link.port)") else { continue }
                    group.addTask { [self] in
                        do {
                            let (code, j) = try await self.call("POST", "/v1/hello", body: body, base: base, timeout: 4)
                            guard code == 200 else { return .rejected(code) }
                            return .ok(base, Hello(pc: j["pc"] as? String ?? link.name, app: j["app"] as? String ?? ""))
                        } catch PCTransferError.rejected(let code) {
                            return .rejected(code)
                        } catch {
                            return .failed
                        }
                    }
                }
                var all: [Outcome] = []
                for await r in group {
                    if case .ok = r {
                        group.cancelAll()
                        return [r]
                    }
                    all.append(r)
                }
                return all
            }
            for o in outcomes { if case .ok(let b, let h) = o { base = b; return h } }
            // компьютер ответил, но не принял ключ — это старый код
            if outcomes.contains(where: { if case .rejected(let c) = $0 { return c == 403 || c == 400 } else { return false } }) {
                throw PCTransferError.expired
            }
            if let code = outcomes.compactMap({ o -> Int? in if case .rejected(let c) = o { return c } else { return nil } }).first {
                throw PCTransferError.rejected(code)
            }
            guard Date() < deadline else { throw PCTransferError.unreachable }
            try await Task.sleep(nanoseconds: 1_200_000_000)
        }
    }

    /// Запрос с зашифрованным телом. Ответ 200 или 409 — расшифрованный JSON
    func call(_ method: String, _ path: String, body: Data, base: URL? = nil, timeout: TimeInterval = 25) async throws -> (Int, [String: Any]) {
        let sealed = try PCCrypto.seal(body, key: link.key, aad: "\(method) \(path)")
        return try await send(method, path, sealed: sealed, base: base, timeout: timeout)
    }

    /// Уже зашифрованное тело (куски файлов шифруются заранее, не на главном потоке)
    func send(_ method: String, _ path: String, sealed: Data, base: URL? = nil, timeout: TimeInterval = 25) async throws -> (Int, [String: Any]) {
        guard let b = base ?? self.base, let url = URL(string: b.absoluteString + path) else { throw PCTransferError.unreachable }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        req.httpMethod = method
        req.setValue(link.session, forHTTPHeaderField: "X-Arktika-Session")
        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        req.httpBody = sealed
        let (data, resp) = try await session.data(for: req)
        guard let http = resp as? HTTPURLResponse else { throw PCTransferError.broken }
        let type = http.value(forHTTPHeaderField: "Content-Type") ?? ""
        guard type.hasPrefix("application/octet-stream") else { throw PCTransferError.rejected(http.statusCode) }
        let plain = try PCCrypto.open(data, key: link.key, aad: "R \(method) \(path)")
        let json = (try? JSONSerialization.jsonObject(with: plain)) as? [String: Any] ?? [:]
        return (http.statusCode, json)
    }

    /// Кусок файла с диска, сразу зашифрованный
    static func sealedChunk(_ url: URL, offset: Int64, length: Int, key: SymmetricKey, aad: String) throws -> Data {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        try h.seek(toOffset: UInt64(offset))
        let data = try h.read(upToCount: length) ?? Data()
        return try PCCrypto.seal(data, key: key, aad: aad)
    }
}

// MARK: что переносим

struct PCItem {
    enum Kind { case file, board, lecture }
    let rel: String
    let url: URL
    let size: Int64
    /// Дата изменения, мс с 1970 — на компьютере у файла будет та же дата
    let mtime: Double
    let kind: Kind
    var name: String { (rel as NSString).lastPathComponent }
    var ext: String { String((rel as NSString).pathExtension.uppercased().prefix(4)) }
}

enum PCInventory {
    private static let boardRegex = try? NSRegularExpression(pattern: "^Предметы/[^/]+/Доска .+\\.(jpe?g|png|heic)$", options: [.caseInsensitive])

    static func collect() -> [PCItem] {
        let fm = FileManager.default
        let root = FileService.root.resolvingSymlinksInPath()
        let base = root.path.hasSuffix("/") ? root.path : root.path + "/"
        let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        guard let e = fm.enumerator(at: root, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles]) else { return [] }
        var out: [PCItem] = []
        while let u = e.nextObject() as? URL {
            let full = u.resolvingSymlinksInPath().path
            guard full.hasPrefix(base) else { continue }
            let rel = String(full.dropFirst(base.count))
            if BackupManager.skip(rel) {
                if (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true { e.skipDescendants() }
                continue
            }
            guard let v = try? u.resourceValues(forKeys: Set(keys)), v.isRegularFile == true else { continue }
            let range = NSRange(rel.startIndex..., in: rel)
            let kind: PCItem.Kind = boardRegex?.firstMatch(in: rel, range: range) != nil ? .board
                : rel.hasPrefix("Лекции/") ? .lecture : .file
            out.append(PCItem(rel: rel, url: u, size: Int64(v.fileSize ?? 0),
                              mtime: (v.contentModificationDate ?? Date()).timeIntervalSince1970 * 1000, kind: kind))
        }
        return out
    }

    /// ДЗ, задачи, заметки, оценки, расписание и настройки — тот же набор, что в резервной копии
    static func settingsPlist() -> Data? {
        let id = Bundle.main.bundleIdentifier ?? "ru.student.safuhub"
        let domain = UserDefaults.standard.persistentDomain(forName: id) ?? [:]
        return try? PropertyListSerialization.data(fromPropertyList: domain, format: .binary, options: 0)
    }
}

// MARK: - Модель экрана

@MainActor
final class PCTransferModel: ObservableObject {
    enum Phase: Equatable { case scanning, connecting, ready, sending, done, failed(String) }

    struct Flying: Identifiable { let id = UUID(); let ext: String; let dx: CGFloat }

    @Published var phase: Phase
    @Published private(set) var link: PCLink?
    @Published private(set) var pcName = ""
    @Published private(set) var items: [PCItem] = []
    @Published private(set) var counting = false
    @Published var sendFiles = true
    @Published var sendBoards = true
    @Published var sendLectures = true
    @Published var sendData = true

    @Published private(set) var sentBytes: Int64 = 0
    @Published private(set) var totalBytes: Int64 = 0
    @Published private(set) var sentFiles = 0
    @Published private(set) var totalFiles = 0
    @Published private(set) var skipped = 0
    @Published private(set) var current = ""
    @Published private(set) var speed: Double = 0
    @Published private(set) var flying: [Flying] = []
    @Published private(set) var seconds = 0
    /// Обрыв посреди переноса: «Продолжить» докачает с того же места
    @Published private(set) var resumable = false

    private var client: PCClient?
    private var task: Task<Void, Never>?
    private var started = Date()
    private var speedMark = (t: Date(), bytes: Int64(0))
    private var lastFly = Date.distantPast
    private var lastName = Date.distantPast
    private var bg: UIBackgroundTaskIdentifier = .invalid
    private let chunk = 4 * 1024 * 1024

    init(link: PCLink?) {
        self.link = link
        phase = link == nil ? .scanning : .connecting
    }

    func appear() {
        if let link, phase == .connecting, client == nil { connect(link) }
    }

    func leave() {
        // ушли с экрана посреди переноса — дадим ему доделаться в фоне, остальное закрываем
        if phase != .sending { task?.cancel() }
    }

    func scanned(_ text: String) -> Bool {
        guard phase == .scanning, let l = PCLink(string: text) else { return false }
        Haptics.success()
        connect(l)
        return true
    }

    func rescan() {
        task?.cancel()
        client = nil
        link = nil
        phase = .scanning
    }

    func connect(_ l: PCLink) {
        task?.cancel()
        link = l
        pcName = l.name
        phase = .connecting
        let c = PCClient(link: l)
        client = c
        task = Task { [weak self] in
            do {
                let first = UserDefaults.standard.string(forKey: "user.first") ?? ""
                let device = first.isEmpty ? UIDevice.current.model : "\(UIDevice.current.model) · \(first)"
                let version = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? ""
                let hello = try await c.hello(device: device, app: version)
                guard let self else { return }
                self.pcName = hello.pc
                withAnimation(.spring(response: 0.45, dampingFraction: 0.82)) { self.phase = .ready }
                Haptics.success()
                await self.count()
            } catch is CancellationError {
            } catch {
                guard let self else { return }
                self.phase = .failed(error.localizedDescription)
            }
        }
    }

    private func count() async {
        counting = true
        let found = await Task.detached(priority: .userInitiated) { PCInventory.collect() }.value
        items = found
        counting = false
    }

    // сводка для переключателей
    func stats(_ kind: PCItem.Kind) -> (n: Int, bytes: Int64) {
        let list = items.filter { $0.kind == kind }
        return (list.count, list.reduce(0) { $0 + $1.size })
    }

    var chosen: [PCItem] {
        items.filter {
            switch $0.kind {
            case .file: return sendFiles
            case .board: return sendBoards
            case .lecture: return sendLectures
            }
        }
    }

    var canSend: Bool { !counting && (sendData || !chosen.isEmpty) }

    func cancel() {
        task?.cancel()
        endBackground()
        phase = .ready
    }

    // MARK: перенос

    func send() {
        guard let client else { return }
        let list = chosen
        let data = sendData ? PCInventory.settingsPlist() : nil
        sentBytes = 0; totalBytes = 0; sentFiles = 0; totalFiles = 0; skipped = 0; current = ""; speed = 0; seconds = 0
        resumable = false
        started = Date()
        speedMark = (Date(), 0)
        withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) { phase = .sending }
        UIApplication.shared.isIdleTimerDisabled = true
        bg = UIApplication.shared.beginBackgroundTask(withName: "pc-transfer") { [weak self] in
            Task { @MainActor in self?.endBackground() }
        }
        task = Task { [weak self] in
            do {
                try await self?.run(client: client, list: list, data: data)
            } catch is CancellationError {
            } catch {
                guard let self else { return }
                self.resumable = true
                self.phase = .failed(error.localizedDescription)
            }
            self?.endBackground()
        }
    }

    private func endBackground() {
        UIApplication.shared.isIdleTimerDisabled = false
        if bg != .invalid {
            UIApplication.shared.endBackgroundTask(bg)
            bg = .invalid
        }
    }

    /// Запрос с повтором: на миг пропал Wi‑Fi — не страшно
    private func retrying<T>(_ op: () async throws -> T) async throws -> T {
        var delay: UInt64 = 600_000_000
        for attempt in 0..<4 {
            do { return try await op() } catch let e as PCTransferError { throw e } catch is CancellationError { throw CancellationError() } catch {
                if attempt == 3 { throw PCTransferError.unreachable }
                try await Task.sleep(nanoseconds: delay)
                delay *= 2
            }
        }
        throw PCTransferError.unreachable
    }

    private func run(client: PCClient, list: [PCItem], data: Data?) async throws {
        // 1. план: компьютер говорит, что у него уже есть и с какого места докачивать
        let files = list.map { ["p": $0.rel, "s": $0.size, "m": $0.mtime] as [String: Any] }
        let planBody = try JSONSerialization.data(withJSONObject: ["files": files, "data": data != nil])
        let (_, plan) = try await retrying { try await client.call("POST", "/v1/plan", body: planBody, timeout: 60) }
        var offsets: [Int: Int64] = [:]
        for f in plan["files"] as? [[String: Any]] ?? [] {
            if let i = (f["i"] as? NSNumber)?.intValue, let o = (f["o"] as? NSNumber)?.int64Value { offsets[i] = o }
        }
        var todo: [(Int, PCItem, Int64)] = []
        for (i, item) in list.enumerated() {
            guard let o = offsets[i], o >= 0, o <= item.size else { continue }
            todo.append((i, item, o))
        }
        totalFiles = todo.count
        skipped = list.count - todo.count
        totalBytes = todo.reduce(0) { $0 + ($1.1.size - $1.2) }

        // 2. файлы по кускам по 4 МБ: читаются и шифруются не на главном потоке
        let key = client.link.key
        for (i, item, start) in todo {
            try Task.checkCancellation()
            var off = start
            note(item.name)
            while off < item.size {
                try Task.checkCancellation()
                let len = Int(min(Int64(chunk), item.size - off))
                let path = "/v1/file?i=\(i)&o=\(off)"
                let url = item.url
                let at = off
                let sealed = try await Task.detached(priority: .userInitiated) {
                    try PCClient.sealedChunk(url, offset: at, length: len, key: key, aad: "PUT \(path)")
                }.value
                let (code, j) = try await retrying { try await client.send("PUT", path, sealed: sealed, timeout: 60) }
                if code != 200 && code != 409 { throw PCTransferError.rejected(code) }
                // 409: у компьютера другое число принятых байт (например, ответ потерялся и кусок уже дошёл) —
                // продолжаем ровно с его места
                let now = min(item.size, max(0, (j["o"] as? NSNumber)?.int64Value ?? (off + Int64(len))))
                if now == off || (code == 200 && now < off) { throw PCTransferError.broken }
                sentBytes += now - off
                off = now
                tickSpeed()
            }
            sentFiles += 1
            fly(item.ext)
        }

        // 3. данные и конец
        if let data {
            current = "ДЗ, задачи, заметки и настройки"
            _ = try await retrying { try await client.call("POST", "/v1/data", body: data, timeout: 60) }
        }
        let doneBody = try JSONSerialization.data(withJSONObject: [String: Any]())
        _ = try await retrying { try await client.call("POST", "/v1/done", body: doneBody) }
        seconds = max(1, Int(Date().timeIntervalSince(started)))
        withAnimation(.spring(response: 0.5, dampingFraction: 0.75)) { phase = .done }
        Haptics.success()
        let what = sentFiles > 0 ? "\(sentFiles) \(Self.filesWord(sentFiles))" : "Новых файлов не было"
        CelebrationCenter.shared.fire(Celebration(title: "На компьютере! 🎉",
                                                  subtitle: "\(what)\(data != nil ? " и все данные" : "") — уже в Арктике на «\(pcName)»",
                                                  style: .confetti, force: true))
    }

    private func note(_ name: String) {
        // имя файла на экране меняется не чаще 8 раз в секунду — сотни мелких файлов не мельтешат
        guard Date().timeIntervalSince(lastName) > 0.12 else { return }
        lastName = Date()
        current = name
    }

    private func tickSpeed() {
        let dt = Date().timeIntervalSince(speedMark.t)
        guard dt > 0.8 else { return }
        let inst = Double(sentBytes - speedMark.bytes) / dt
        speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4
        speedMark = (Date(), sentBytes)
    }

    private func fly(_ ext: String) {
        guard Date().timeIntervalSince(lastFly) > 0.14, flying.count < 6 else { return }
        lastFly = Date()
        let f = Flying(ext: ext.isEmpty ? "FILE" : ext, dx: CGFloat.random(in: -70...70))
        flying.append(f)
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 1_100_000_000)
            self?.flying.removeAll { $0.id == f.id }
        }
    }

    static func filesWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "файл" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "файла" }
        return "файлов"
    }

    static func bytes(_ n: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: n, countStyle: .file)
    }
}

// MARK: - Экран

struct PCTransferView: View {
    @StateObject private var model: PCTransferModel
    @Environment(\.dismiss) private var dismiss

    init(link: PCLink? = nil) {
        _model = StateObject(wrappedValue: PCTransferModel(link: link))
    }

    var body: some View {
        ZStack {
            Color(.systemGroupedBackground).ignoresSafeArea()
            switch model.phase {
            case .scanning:
                PCScanStage(model: model)
                    .transition(.opacity)
            case .connecting:
                PCConnectingStage(name: model.pcName)
                    .transition(.opacity.combined(with: .scale(scale: 0.96)))
            case .ready:
                PCReadyStage(model: model)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            case .sending:
                PCSendingStage(model: model)
                    .transition(.opacity.combined(with: .scale(scale: 0.96)))
            case .done:
                PCDoneStage(model: model) { dismiss() }
                    .transition(.opacity.combined(with: .scale(scale: 0.9)))
            case .failed(let message):
                PCFailedStage(model: model, message: message)
                    .transition(.opacity)
            }
        }
        .animation(.spring(response: 0.45, dampingFraction: 0.85), value: model.phase)
        .navigationTitle("На компьютер")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { model.appear() }
        .onDisappear { model.leave() }
    }
}

/// Значок компьютера с телефоном — шапка всех шагов
private struct PCDevicesBadge: View {
    var pulse = false
    @State private var on = false

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "iphone")
                .font(.system(size: 30, weight: .semibold))
                .foregroundStyle(.secondary)
            HStack(spacing: 4) {
                ForEach(0..<3) { i in
                    Circle()
                        .fill(Color.brand)
                        .frame(width: 6, height: 6)
                        .opacity(pulse ? (on ? 1 : 0.25) : 0.6)
                        .animation(pulse ? .easeInOut(duration: 0.6).repeatForever().delay(Double(i) * 0.2) : .default, value: on)
                }
            }
            Image(systemName: "laptopcomputer")
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
        }
        .onAppear { on = true }
    }
}

// MARK: шаг 1 — сканер

private struct PCScanStage: View {
    @ObservedObject var model: PCTransferModel
    @State private var access = AVCaptureDevice.authorizationStatus(for: .video)
    @State private var wrong = false

    var body: some View {
        VStack(spacing: 18) {
            ZStack {
                if access == .authorized {
                    QRScannerView { text in
                        if !model.scanned(text) && !wrong {
                            wrong = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { wrong = false }
                        }
                    }
                } else if access == .notDetermined {
                    Color.black.onAppear {
                        AVCaptureDevice.requestAccess(for: .video) { _ in
                            DispatchQueue.main.async { access = AVCaptureDevice.authorizationStatus(for: .video) }
                        }
                    }
                } else {
                    VStack(spacing: 12) {
                        Image(systemName: "camera.fill").font(.system(size: 34)).foregroundStyle(.white.opacity(0.7))
                        Text("Нужен доступ к камере, чтобы отсканировать код")
                            .font(.subheadline.weight(.semibold)).foregroundStyle(.white).multilineTextAlignment(.center)
                        Button("Открыть настройки") {
                            if let u = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(u) }
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding(24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.black)
                }
                // рамка видоискателя
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .strokeBorder(wrong ? Color.orange : Color.white.opacity(0.9), style: StrokeStyle(lineWidth: 3, dash: [26, 14]))
                    .frame(width: 230, height: 230)
                    .allowsHitTesting(false)
                if wrong {
                    Text("Это не код Арктики")
                        .font(.footnote.weight(.bold))
                        .padding(.horizontal, 12).padding(.vertical, 7)
                        .background(.ultraThinMaterial, in: Capsule())
                        .offset(y: 140)
                        .transition(.opacity)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 380)
            .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            .padding(.horizontal, 16)
            .animation(.easeOut(duration: 0.2), value: wrong)

            VStack(spacing: 8) {
                Text("Наведи на QR-код на компьютере")
                    .font(.title3.weight(.bold))
                Text("На компьютере: Арктика для Windows → Профиль → «Перенос с iPhone». Код можно отсканировать и обычной камерой iPhone.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.horizontal, 24)

            Label("Шифрование AES‑256, напрямую по Wi‑Fi", systemImage: "lock.shield.fill")
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
        .padding(.top, 12)
    }
}

/// Камера, которая ищет QR-коды
private struct QRScannerView: UIViewControllerRepresentable {
    let onCode: (String) -> Void

    func makeUIViewController(context: Context) -> QRScannerController {
        let c = QRScannerController()
        c.onCode = onCode
        return c
    }

    func updateUIViewController(_ c: QRScannerController, context: Context) {
        c.onCode = onCode
    }
}

final class QRScannerController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCode: ((String) -> Void)?
    private let session = AVCaptureSession()
    private var preview: AVCaptureVideoPreviewLayer?
    private var lastCode = ""
    private var lastAt = Date.distantPast

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: device), session.canAddInput(input) else { return }
        session.addInput(input)
        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else { return }
        session.addOutput(output)
        output.setMetadataObjectsDelegate(self, queue: .main)
        output.metadataObjectTypes = [.qr]
        let p = AVCaptureVideoPreviewLayer(session: session)
        p.videoGravity = .resizeAspectFill
        view.layer.addSublayer(p)
        preview = p
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview?.frame = view.bounds
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let s = session
        DispatchQueue.global(qos: .userInitiated).async { if !s.isRunning { s.startRunning() } }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        let s = session
        DispatchQueue.global(qos: .userInitiated).async { if s.isRunning { s.stopRunning() } }
    }

    nonisolated func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard let code = (metadataObjects.first as? AVMetadataMachineReadableCodeObject)?.stringValue else { return }
        // делегат вызывается на главной очереди (так задано выше)
        MainActor.assumeIsolated { self.found(code) }
    }

    private func found(_ code: String) {
        // один и тот же код не дёргаем чаще раза в 2 секунды
        if code == lastCode && Date().timeIntervalSince(lastAt) < 2 { return }
        lastCode = code
        lastAt = Date()
        onCode?(code)
    }
}

// MARK: шаг 2 — поиск компьютера

private struct PCConnectingStage: View {
    let name: String
    @State private var slow = false

    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            PCDevicesBadge(pulse: true)
            VStack(spacing: 8) {
                Text("Подключаюсь к «\(name)»")
                    .font(.title3.weight(.bold))
                    .multilineTextAlignment(.center)
                Text(slow ? "Телефон и компьютер должны быть в одной сети Wi‑Fi. Если iPhone спросит про устройства в локальной сети — разреши." : "Напрямую по Wi‑Fi, без интернета")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .animation(.easeOut, value: slow)
            }
            .padding(.horizontal, 28)
            ProgressView()
            Spacer()
            Spacer()
        }
        .task {
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            slow = true
        }
    }
}

// MARK: шаг 3 — что переносим

private struct PCReadyStage: View {
    @ObservedObject var model: PCTransferModel

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 12) {
                    PCDevicesBadge()
                    VStack(spacing: 4) {
                        HStack(spacing: 6) {
                            Circle().fill(Color.green).frame(width: 8, height: 8)
                            Text(model.pcName).font(.title3.weight(.bold)).lineLimit(1)
                        }
                        Label("Связь зашифрована AES‑256", systemImage: "lock.fill")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.top, 20)

                VStack(spacing: 0) {
                    row(icon: "folder.fill", color: .blue, title: "Файлы предметов и документы", kind: .file, isOn: $model.sendFiles)
                    Divider().padding(.leading, 58)
                    row(icon: "camera.viewfinder", color: .teal, title: "Фото доски", kind: .board, isOn: $model.sendBoards)
                    Divider().padding(.leading, 58)
                    row(icon: "waveform", color: .purple, title: "Записи лекций", kind: .lecture, isOn: $model.sendLectures)
                    Divider().padding(.leading, 58)
                    Toggle(isOn: $model.sendData) {
                        HStack(spacing: 12) {
                            icon("checklist", .orange)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("ДЗ, задачи, заметки, оценки").font(.body.weight(.semibold))
                                Text("И расписание, и настройки").font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    .padding(.horizontal, 14).padding(.vertical, 10)
                }
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .padding(.horizontal, 16)

                Text("На компьютере ничего не перезапишется: если там уже есть такой же файл — его пропустим, другой файл с тем же именем — положим рядом. Повторный перенос шлёт только новое.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)

                Button {
                    Haptics.tap()
                    model.send()
                } label: {
                    HStack(spacing: 10) {
                        if model.counting { ProgressView().tint(.white) } else { Image(systemName: "arrow.up.forward.app.fill") }
                        Text(model.counting ? "Считаю файлы…" : "Перенести · \(PCTransferModel.bytes(model.chosen.reduce(0) { $0 + $1.size }))")
                    }
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .opacity(model.canSend ? 1 : 0.5)
                }
                .buttonStyle(PressableStyle())
                .disabled(!model.canSend)
                .padding(.horizontal, 16)

                Button("Другой компьютер") { model.rescan() }
                    .font(.subheadline.weight(.semibold))
                    .padding(.bottom, 24)
            }
        }
    }

    private func icon(_ name: String, _ color: Color) -> some View {
        Image(systemName: name)
            .font(.system(size: 15, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: 32, height: 32)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
    }

    private func row(icon name: String, color: Color, title: String, kind: PCItem.Kind, isOn: Binding<Bool>) -> some View {
        let s = model.stats(kind)
        return Toggle(isOn: isOn) {
            HStack(spacing: 12) {
                icon(name, color)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.body.weight(.semibold))
                    Text(model.counting ? "Считаю…" : s.n == 0 ? "Нет" : "\(s.n) \(PCTransferModel.filesWord(s.n)) · \(PCTransferModel.bytes(s.bytes))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                }
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .disabled(!model.counting && s.n == 0)
    }
}

// MARK: шаг 4 — летят

private struct PCSendingStage: View {
    @ObservedObject var model: PCTransferModel

    private var fraction: Double {
        model.totalBytes > 0 ? min(1, Double(model.sentBytes) / Double(model.totalBytes)) : 0
    }

    var body: some View {
        VStack(spacing: 22) {
            Spacer(minLength: 10)
            // файлы улетают с телефона наверх, в компьютер
            ZStack(alignment: .bottom) {
                VStack {
                    Image(systemName: "laptopcomputer")
                        .font(.system(size: 54, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .scaleEffect(model.flying.isEmpty ? 1 : 1.06)
                        .animation(.spring(response: 0.3, dampingFraction: 0.5), value: model.flying.count)
                    Text(model.pcName).font(.caption.weight(.semibold)).foregroundStyle(.secondary).lineLimit(1)
                    Spacer()
                    Image(systemName: "iphone")
                        .font(.system(size: 40, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
                ForEach(model.flying) { f in
                    PCFlyingDoc(ext: f.ext, dx: f.dx)
                        .padding(.bottom, 40)
                }
            }
            .frame(height: 230)

            ZStack {
                Circle().stroke(Color.primary.opacity(0.08), lineWidth: 12)
                Circle()
                    .trim(from: 0, to: fraction)
                    .stroke(brandGradient, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .animation(.easeOut(duration: 0.3), value: fraction)
                VStack(spacing: 2) {
                    Text("\(Int(fraction * 100))%")
                        .font(.system(size: 34, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                        .contentTransition(.numericText())
                    Text(PCTransferModel.bytes(model.sentBytes))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                }
            }
            .frame(width: 150, height: 150)

            VStack(spacing: 6) {
                Text(model.totalFiles > 0 ? "\(model.sentFiles) из \(model.totalFiles) · \(PCTransferModel.bytes(model.sentBytes)) из \(PCTransferModel.bytes(model.totalBytes))" : "Готовлю список…")
                    .font(.subheadline.weight(.semibold))
                    .monospacedDigit()
                if model.speed > 0 {
                    let left = Double(model.totalBytes - model.sentBytes) / model.speed
                    Text("\(PCTransferModel.bytes(Int64(model.speed)))/с · осталось ≈ \(left < 60 ? "\(max(1, Int(left))) с" : "\(Int(left / 60)) мин")")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                }
                if model.skipped > 0 {
                    Text("Уже на компьютере: \(model.skipped)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(model.current)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .padding(.horizontal, 30)
            }
            Spacer()
            Text("Не закрывай приложение, пока идёт перенос")
                .font(.footnote)
                .foregroundStyle(.secondary)
            Button("Остановить", role: .destructive) { model.cancel() }
                .padding(.bottom, 20)
        }
    }
}

private struct PCFlyingDoc: View {
    let ext: String
    let dx: CGFloat
    @State private var gone = false

    private var color: Color {
        switch ext {
        case "JPG", "JPEG", "PNG", "HEIC": return .teal
        case "PDF": return .red
        case "DOC", "DOCX", "TXT", "RTF": return .blue
        case "XLS", "XLSX": return .green
        case "PPT", "PPTX", "KEY": return .orange
        case "M4A", "MP3", "WAV", "CAF": return .purple
        default: return .gray
        }
    }

    var body: some View {
        RoundedRectangle(cornerRadius: 6, style: .continuous)
            .fill(color.gradient)
            .frame(width: 28, height: 34)
            .overlay(alignment: .bottom) {
                Text(ext).font(.system(size: 7, weight: .black)).foregroundStyle(.white).padding(.bottom, 4)
            }
            .shadow(color: .black.opacity(0.2), radius: 4, y: 2)
            .offset(x: gone ? 0 : dx, y: gone ? -150 : 0)
            .scaleEffect(gone ? 0.5 : 1)
            .opacity(gone ? 0 : 1)
            .onAppear { withAnimation(.easeIn(duration: 0.95)) { gone = true } }
    }
}

// MARK: шаг 5 — готово

private struct PCDoneStage: View {
    @ObservedObject var model: PCTransferModel
    let close: () -> Void
    @State private var shown = false

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            ZStack {
                Circle().fill(LinearGradient(colors: [.green, .mint], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 110, height: 110)
                    .shadow(color: .green.opacity(0.4), radius: 20, y: 8)
                Image(systemName: "checkmark")
                    .font(.system(size: 50, weight: .heavy))
                    .foregroundStyle(.white)
            }
            .scaleEffect(shown ? 1 : 0.3)
            .rotationEffect(.degrees(shown ? 0 : -30))
            .animation(.spring(response: 0.5, dampingFraction: 0.55), value: shown)
            Text("Всё на компьютере").font(.title2.weight(.heavy))
            Text(summary)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)
            Spacer()
            Button(action: close) {
                Text("Готово")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 54)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .padding(.horizontal, 16)
            .padding(.bottom, 24)
        }
        .onAppear { shown = true }
    }

    private var summary: String {
        var parts: [String] = []
        if model.sentFiles > 0 {
            parts.append("\(model.sentFiles) \(PCTransferModel.filesWord(model.sentFiles)), \(PCTransferModel.bytes(model.sentBytes)) — за \(model.seconds < 60 ? "\(model.seconds) с" : "\(model.seconds / 60) мин").")
        } else {
            parts.append("Новых файлов не было — всё уже лежало на компьютере.")
        }
        if model.skipped > 0 { parts.append("Ещё \(model.skipped) уже были там — их не трогали.") }
        if model.sendData { parts.append("ДЗ, задачи, заметки, оценки и настройки — тоже: на компьютере нажми «Перезапустить и открыть».") }
        return parts.joined(separator: " ")
    }
}

// MARK: не получилось

private struct PCFailedStage: View {
    @ObservedObject var model: PCTransferModel
    let message: String

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 52, weight: .semibold))
                .foregroundStyle(.orange)
            Text(model.resumable ? "Связь прервалась" : "Не получилось").font(.title3.weight(.bold))
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)
            Spacer()
            if model.resumable {
                Button {
                    model.send()
                } label: {
                    Label("Продолжить с того же места", systemImage: "arrow.clockwise")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .buttonStyle(PressableStyle())
                .padding(.horizontal, 16)
            } else if let link = model.link {
                Button {
                    model.connect(link)
                } label: {
                    Label("Попробовать снова", systemImage: "arrow.clockwise")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 54)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .buttonStyle(PressableStyle())
                .padding(.horizontal, 16)
            }
            Button("Сканировать код заново") { model.rescan() }
                .font(.subheadline.weight(.semibold))
                .padding(.bottom, 24)
        }
    }
}
