import SwiftUI
import UserNotifications
import BackgroundTasks
import WidgetKit

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()
    @StateObject private var tasks = TaskStore()
    @StateObject private var schedule = ScheduleStore()
    @StateObject private var attendance = AttendanceStore()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
        MemoryGuard.install()
        ThemeChrome.apply()   // панели темы (iOS 6, Machinarium) — до первого экрана
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        // Фоновое обновление: iOS иногда будит приложение, и Live Activity
        // переключается на следующую пару даже без открытия приложения
        .backgroundTask(.appRefresh(BackgroundRefresh.id)) {
            await BackgroundRefresh.run()
        }
    }
}

/// Бережём память: небольшой сетевой кэш, а при нехватке памяти сбрасываем всё, что можно пересоздать
enum MemoryGuard {
    static func install() {
        URLCache.shared = URLCache(memoryCapacity: 4 * 1024 * 1024, diskCapacity: 40 * 1024 * 1024)
        NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification,
                                               object: nil, queue: .main) { _ in
            ThumbCache.shared.removeAllObjects()
            URLCache.shared.removeAllCachedResponses()
            Task { @MainActor in SakaiWeb.shared.release() }
        }
        // ушли в фон — миниатюры не нужны, iOS реже выгрузит приложение
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { _ in
            ThumbCache.shared.removeAllObjects()
        }
    }
}

enum BackgroundRefresh {
    static let id = "ru.student.safuhub.refresh"

    static func schedule() {
        let req = BGAppRefreshTaskRequest(identifier: id)
        req.earliestBeginDate = Date().addingTimeInterval(20 * 60)
        try? BGTaskScheduler.shared.submit(req)
    }

    static func run() async {
        schedule()
        await ScheduleStore.backgroundSync()   // замены и отмены — уведомлением, даже если приложение закрыто
        let data = SharedSchedule.load()
        Celebrations.scheduleNotifications(data: data)
        LiveActivityManager.update(data: data)
        BusLiveManager.auto(data: data)
        try? await Task.sleep(nanoseconds: 2_000_000_000)   // даём ActivityKit применить обновление
    }
}

struct ContentView: View {
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("theme.seasonal") private var seasonalTheme = false
    @AppStorage("look.pack") private var lookPack = ""
    @State private var showSplash = true
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("onboarded") private var onboarded = false
    /// Регистрацию попросили пройти заново из Профиля
    @AppStorage("onboarding.again") private var onboardingAgain = false
    /// Идёт первая регистрация. Отдельный флаг: во время настройки расписание уже подключено,
    /// и окно не должно закрыться раньше, чем человек нажмёт «Поехали»
    @State private var registering = false
    @AppStorage("ui.appearanceOpen") private var appearanceOpen = false
    @ObservedObject private var boardRouter = BoardRouter.shared
    @AppStorage("privacy.shield") private var privacyShield = true
    @State private var showBoards = false
    /// Когда последний раз обновлялись при возвращении в приложение
    @State private var lastActiveRefresh = Date()

    private var shielded: Bool { privacyShield && scenePhase != .active && !showSplash }
    /// Меняется, когда меняется конец сегодняшних пар или приложение уходит/возвращается
    private var finishKey: String {
        "\(Celebrations.nextFinish(data: schedule.data)?.timeIntervalSince1970 ?? 0)|\(scenePhase == .active)"
    }

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                ForEach(AppTab.parse(tabsRaw)) { t in
                    tabContent(t)
                        .tabItem { Label(t.title, systemImage: t.icon) }
                        .tag(t.rawValue)
                }
            }
            .modifier(TabBarMinimize())
            .tint(Color.brand)
            .id(theme + tabsRaw + (seasonalTheme ? "s" : "") + lookPack)

            CelebrationOverlay()
                .zIndex(2)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }

            // в переключателе приложений не видно оценок, паролей и файлов
            if shielded {
                PrivacyShield()
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .modifier(AppearanceRoot())
        .sheet(isPresented: $appearanceOpen) {
            AppearanceSheet()
        }
        .onReceive(NotificationCenter.default.publisher(for: .deviceDidShake)) { _ in Oracle.fire() }
        .onChange(of: tab) { _ in Haptics.tap() }
        .task(id: finishKey) {
            // ждём конца последней пары и запускаем салют прямо на экране
            guard scenePhase == .active, let end = Celebrations.nextFinish(data: schedule.data) else { return }
            let wait = end.timeIntervalSinceNow + 1
            if wait > 0 { try? await Task.sleep(nanoseconds: UInt64(wait * 1_000_000_000)) }
            guard !Task.isCancelled else { return }
            Celebrations.checkOnOpen(data: schedule.data)
        }
        .task {
            // виджет забирает группу и пары при каждом запуске приложения
            WidgetBridge.publish(schedule.data)
            let d = UserDefaults.standard
            WidgetBridge.publishLook(theme: d.string(forKey: "widget.theme") ?? WidgetTheme.night.rawValue,
                                     showTeacher: d.object(forKey: "widget.teacher") as? Bool ?? true)
            WidgetCenter.shared.reloadAllTimelines()
            LessonPhotosPDF.cleanTemp()
            Notifier.requestAuthorization()
            Celebrations.checkOnOpen(data: schedule.data)
            await schedule.sync()
            schedule.refreshSideEffects()
            Celebrations.scheduleNotifications(data: schedule.data)
            await SakaiSync.autoImport(tasks)
            // тяжёлая проверка БРС (невидимый браузер) — позже, чтобы не тормозить первые секунды
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            await GradeSync.autoRun(subjects: ScheduleQuery.subjects(schedule.data))
        }
        .onChange(of: scenePhase) { phase in
            if phase == .background { BackgroundRefresh.schedule() }
            if phase == .active {
                // салют, если пары кончились, пока приложение было свёрнуто (показывается один раз)
                Celebrations.checkOnOpen(data: schedule.data)
                // Пункт управления, шторка уведомлений, Face ID тоже дают «active» —
                // полностью обновляемся не чаще раза в 2 минуты
                guard Date().timeIntervalSince(lastActiveRefresh) > 120 else { return }
                lastActiveRefresh = Date()
                schedule.reloadFromDisk()
                Task {
                    await schedule.sync()
                    schedule.refreshSideEffects()
                    await SakaiSync.autoImport(tasks)
                }
            }
        }
        // регистрация: первый запуск или «пройти заново» из Профиля
        .fullScreenCover(isPresented: Binding(get: { !showSplash && (registering || onboardingAgain) },
                                              set: { if !$0 { registering = false; onboardingAgain = false } })) {
            RegistrationView(canClose: onboardingAgain && !registering) {
                onboarded = true
                registering = false
                onboardingAgain = false
            }
            .environmentObject(schedule)
        }
        .onOpenURL { url in
            // safu://schedule, safu:schedule, safu:///schedule — всё открывает нужную вкладку
            let target = (url.host ?? url.path.replacingOccurrences(of: "/", with: "")).lowercased()
            // safu://board — камера для текущей пары (удобно на «Действие» или в Команды), safu://boards — все фото
            if target == "board" {
                if LessonPhotos.currentSlot(schedule.data) != nil { boardRouter.camera = true } else { showBoards = true }
                return
            }
            if target == "boards" { showBoards = true; return }
            let dest: AppTab? = target.hasPrefix("schedule") ? .schedule
                : target.hasPrefix("tasks") ? .tasks
                : target.hasPrefix("files") ? .files
                : target.hasPrefix("home") ? .home : nil
            if let dest {
                // если вкладки нет в панели — всё равно показываем расписание через главную
                let list = AppTab.parse(tabsRaw)
                tab = list.contains(dest) ? dest.rawValue : (list.first?.rawValue ?? "home")
                Haptics.tap()
            }
        }
        .sheet(item: $boardRouter.target) { t in
            NavigationStack {
                BoardBatchView(batch: boardBatch(t))
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { boardRouter.target = nil } }
                    }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showBoards) {
            NavigationStack {
                BoardBatchesList(subject: nil)
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { showBoards = false } }
                    }
            }
            .environmentObject(schedule)
        }
        .fullScreenCover(isPresented: $boardRouter.camera) {
            CameraPicker { image in
                boardRouter.camera = false
                if let image, let slot = LessonPhotos.currentSlot(schedule.data),
                   BoardPhoto.save(image, subject: slot.lesson.subject) != nil {
                    Haptics.success()
                }
            }
            .ignoresSafeArea()
        }
        .onAppear {
            if !onboarded && !schedule.isConfigured { registering = true }
            // если открытая вкладка убрана из панели — на первую
            let list = AppTab.parse(tabsRaw)
            if !list.contains(where: { $0.rawValue == tab }) { tab = list.first?.rawValue ?? "home" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                withAnimation(.easeOut(duration: 0.5)) { showSplash = false }
            }
        }
    }

    /// Пара с фото для уведомления «отправь ребятам»
    private func boardBatch(_ t: BoardRouter.Target) -> BoardBatch {
        let list = LessonPhotos.batches(subject: t.subject, data: schedule.data)
        if let start = t.start, let b = list.first(where: { abs($0.start.timeIntervalSince(start)) < 120 }) { return b }
        return list.first ?? BoardBatch(subject: t.subject, slot: nil, day: Date(), shots: [])
    }

    @ViewBuilder
    private func tabContent(_ t: AppTab) -> some View {
        switch t {
        case .home: ResourcesView()
        case .schedule: ScheduleView()
        case .tasks: TasksView()
        case .files: FilesTab()
        case .subjects: NavigationStack { SubjectsView() }
        case .attendance: NavigationStack { AttendanceView() }
        case .developer: NavigationStack { DeveloperView() }
        case .profile: ProfileView()
        }
    }
}

/// Шторка поверх приложения, когда оно не на экране (снимок для переключателя приложений)
struct PrivacyShield: View {
    var body: some View {
        ZStack {
            // плотное «матовое стекло» — ничего не прочитать (без размытия всего приложения: оно дорогое)
            Rectangle().fill(.thickMaterial).ignoresSafeArea()
            VStack(spacing: 10) {
                Image(systemName: "snowflake")
                    .font(.system(size: 52, weight: .semibold))
                    .foregroundStyle(brandGradient)
                Text("САФУ").font(.system(.title3, design: .rounded).weight(.heavy))
            }
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text("САФУ")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
                Text("by @\(Developer.telegram)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(Color.brand)
                    .opacity(pop ? 0.9 : 0)
                Text("версия \((Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "")")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        if notification.request.identifier.hasPrefix("fx.end.") {
            // приложение открыто — салют уже на экране, баннер не нужен
            DispatchQueue.main.async { Celebrations.checkOnOpen(data: SharedSchedule.load()) }
            completionHandler([])
            return
        }
        completionHandler([.banner, .sound])
    }

    /// Нажали на уведомление: «фото с пары» открывает экран отправки
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        if let subject = info[BoardReminder.subjectKey] as? String {
            let start = (info[BoardReminder.startKey] as? Double).map { Date(timeIntervalSince1970: $0) }
            DispatchQueue.main.async {
                BoardRouter.shared.target = BoardRouter.Target(subject: subject, start: start)
            }
        }
        completionHandler()
    }
}
