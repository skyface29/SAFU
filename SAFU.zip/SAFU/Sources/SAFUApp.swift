import SwiftUI

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .tint(Color.safuBlue)
        }
    }
}

extension Color {
    static let safuBlue = Color(red: 0.05, green: 0.36, blue: 0.70)
}

struct ContentView: View {
    var body: some View {
        TabView {
            ResourcesView()
                .tabItem { Label("Ресурсы", systemImage: "square.grid.2x2.fill") }
            FilesTab()
                .tabItem { Label("Файлы", systemImage: "folder.fill") }
            InfoView()
                .tabItem { Label("Инфо", systemImage: "info.circle.fill") }
        }
    }
}
