import SwiftUI
import UserNotifications
import BackgroundTasks

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()
    @StateObject private var tasks = TaskStore()
    @StateObject private var schedule = ScheduleStore()
    @StateObject private var attendance = AttendanceStore()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
        ThemeChrome.apply()   // панели темы (iOS 6, Machinarium) — до первого экрана
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        // Фоновое обновление: iOS иногда будит приложение, и Live Activity
        // переключается на следующую пару даже без открытия приложения
        .backgroundTask(.appRefresh(BackgroundRefresh.id)) {
            await BackgroundRefresh.run()
        }
    }
}

enum BackgroundRefresh {
    static let id = "ru.student.safuhub.refresh"

    static func schedule() {
        let req = BGAppRefreshTaskRequest(identifier: id)
        req.earliestBeginDate = Date().addingTimeInterval(20 * 60)
        try? BGTaskScheduler.shared.submit(req)
    }

    static func run() async {
        schedule()
        await ScheduleStore.backgroundSync()   // замены и отмены — уведомлением, даже если приложение закрыто
        let data = SharedSchedule.load()
        LiveActivityManager.update(data: data)
        BusLiveManager.auto(data: data)
        try? await Task.sleep(nanoseconds: 2_000_000_000)   // даём ActivityKit применить обновление
    }
}

struct ContentView: View {
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("theme.seasonal") private var seasonalTheme = false
    @AppStorage("look.pack") private var lookPack = ""
    @State private var showSplash = true
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("onboarded") private var onboarded = false
    @AppStorage("ui.appearanceOpen") private var appearanceOpen = false
    @ObservedObject private var boardRouter = BoardRouter.shared
    @State private var showBoards = false

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                ForEach(AppTab.parse(tabsRaw)) { t in
                    tabContent(t)
                        .tabItem { Label(t.title, systemImage: t.icon) }
                        .tag(t.rawValue)
                }
            }
            .modifier(TabBarMinimize())
            .tint(Color.brand)
            .id(theme + tabsRaw + (seasonalTheme ? "s" : "") + lookPack)

            CelebrationOverlay()
                .zIndex(2)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .modifier(AppearanceRoot())
        .sheet(isPresented: $appearanceOpen) {
            AppearanceSheet()
        }
        .onReceive(NotificationCenter.default.publisher(for: .deviceDidShake)) { _ in Oracle.fire() }
        .onChange(of: tab) { _ in Haptics.tap() }
        .task {
            Notifier.requestAuthorization()
            Celebrations.checkOnOpen(data: schedule.data)
            await schedule.sync()
            schedule.refreshSideEffects()
            await SakaiSync.autoImport(tasks)
            // тяжёлая проверка БРС (невидимый браузер) — позже, чтобы не тормозить первые секунды
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            await GradeSync.autoRun(subjects: ScheduleQuery.subjects(schedule.data))
        }
        .onChange(of: scenePhase) { phase in
            if phase == .background { BackgroundRefresh.schedule() }
            if phase == .active {
                schedule.reloadFromDisk()
                Celebrations.checkOnOpen(data: schedule.data)
                Task {
                    await schedule.sync()
                    schedule.refreshSideEffects()
                    await SakaiSync.autoImport(tasks)
                }
            }
        }
        .sheet(isPresented: Binding(get: { !onboarded && !showSplash && !schedule.isConfigured },
                                    set: { if !$0 { onboarded = true } })) {
            OnboardingView { onboarded = true }
                .environmentObject(schedule)
                .interactiveDismissDisabled()
        }
        .onOpenURL { url in
            // safu://schedule, safu:schedule, safu:///schedule — всё открывает нужную вкладку
            let target = (url.host ?? url.path.replacingOccurrences(of: "/", with: "")).lowercased()
            // safu://board — камера для текущей пары (удобно на «Действие» или в Команды), safu://boards — все фото
            if target == "board" {
                if LessonPhotos.currentSlot(schedule.data) != nil { boardRouter.camera = true } else { showBoards = true }
                return
            }
            if target == "boards" { showBoards = true; return }
            let dest: AppTab? = target.hasPrefix("schedule") ? .schedule
                : target.hasPrefix("tasks") ? .tasks
                : target.hasPrefix("files") ? .files
                : target.hasPrefix("home") ? .home : nil
            if let dest {
                // если вкладки нет в панели — всё равно показываем расписание через главную
                let list = AppTab.parse(tabsRaw)
                tab = list.contains(dest) ? dest.rawValue : (list.first?.rawValue ?? "home")
                Haptics.tap()
            }
        }
        .sheet(item: $boardRouter.target) { t in
            NavigationStack {
                BoardBatchView(batch: boardBatch(t))
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { boardRouter.target = nil } }
                    }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showBoards) {
            NavigationStack {
                BoardBatchesList(subject: nil)
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { showBoards = false } }
                    }
            }
            .environmentObject(schedule)
        }
        .fullScreenCover(isPresented: $boardRouter.camera) {
            CameraPicker { image in
                boardRouter.camera = false
                if let image, let slot = LessonPhotos.currentSlot(schedule.data),
                   BoardPhoto.save(image, subject: slot.lesson.subject) != nil {
                    Haptics.success()
                }
            }
            .ignoresSafeArea()
        }
        .onAppear {
            // если открытая вкладка убрана из панели — на первую
            let list = AppTab.parse(tabsRaw)
            if !list.contains(where: { $0.rawValue == tab }) { tab = list.first?.rawValue ?? "home" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                withAnimation(.easeOut(duration: 0.5)) { showSplash = false }
            }
        }
    }

    /// Пара с фото для уведомления «отправь ребятам»
    private func boardBatch(_ t: BoardRouter.Target) -> BoardBatch {
        let list = LessonPhotos.batches(subject: t.subject, data: schedule.data)
        if let start = t.start, let b = list.first(where: { abs($0.start.timeIntervalSince(start)) < 120 }) { return b }
        return list.first ?? BoardBatch(subject: t.subject, slot: nil, day: Date(), shots: [])
    }

    @ViewBuilder
    private func tabContent(_ t: AppTab) -> some View {
        switch t {
        case .home: ResourcesView()
        case .schedule: ScheduleView()
        case .tasks: TasksView()
        case .files: FilesTab()
        case .subjects: NavigationStack { SubjectsView() }
        case .attendance: NavigationStack { AttendanceView() }
        case .developer: NavigationStack { DeveloperView() }
        case .profile: ProfileView()
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text("САФУ")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
                Text("by @\(Developer.telegram)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(Color.brand)
                    .opacity(pop ? 0.9 : 0)
                Text("версия \((Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "")")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }

    /// Нажали на уведомление: «фото с пары» открывает экран отправки
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        if let subject = info[BoardReminder.subjectKey] as? String {
            let start = (info[BoardReminder.startKey] as? Double).map { Date(timeIntervalSince1970: $0) }
            DispatchQueue.main.async {
                BoardRouter.shared.target = BoardRouter.Target(subject: subject, start: start)
            }
        }
        completionHandler()
    }
}
