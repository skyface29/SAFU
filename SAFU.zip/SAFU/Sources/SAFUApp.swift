import SwiftUI
import UserNotifications

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()
    @StateObject private var tasks = TaskStore()
    @StateObject private var schedule = ScheduleStore()
    @StateObject private var attendance = AttendanceStore()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
    }
}

struct ContentView: View {
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("theme.seasonal") private var seasonalTheme = false
    @State private var showSplash = true
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("onboarded") private var onboarded = false
    @AppStorage("ui.appearanceOpen") private var appearanceOpen = false

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                ForEach(AppTab.parse(tabsRaw)) { t in
                    tabContent(t)
                        .tabItem { Label(t.title, systemImage: t.icon) }
                        .tag(t.rawValue)
                }
            }
            .modifier(TabBarMinimize())
            .tint(Color.brand)
            .id(theme + tabsRaw + (seasonalTheme ? "s" : ""))

            CelebrationOverlay()
                .zIndex(2)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .modifier(AppearanceRoot())
        .sheet(isPresented: $appearanceOpen) {
            AppearanceSheet()
        }
        .onChange(of: tab) { _ in Haptics.tap() }
        .task {
            Notifier.requestAuthorization()
            Celebrations.checkOnOpen(data: schedule.data)
            await schedule.sync()
            schedule.refreshSideEffects()
            await SakaiSync.autoImport(tasks)
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                Celebrations.checkOnOpen(data: schedule.data)
                Task {
                    await schedule.sync()
                    schedule.refreshSideEffects()
                    await SakaiSync.autoImport(tasks)
                }
            }
        }
        .sheet(isPresented: Binding(get: { !onboarded && !showSplash && !schedule.isConfigured },
                                    set: { if !$0 { onboarded = true } })) {
            OnboardingView { onboarded = true }
                .environmentObject(schedule)
                .interactiveDismissDisabled()
        }
        .onOpenURL { url in
            // safu://schedule, safu:schedule, safu:///schedule — всё открывает нужную вкладку
            let target = (url.host ?? url.path.replacingOccurrences(of: "/", with: "")).lowercased()
            let dest: AppTab? = target.hasPrefix("schedule") ? .schedule
                : target.hasPrefix("tasks") ? .tasks
                : target.hasPrefix("files") ? .files
                : target.hasPrefix("home") ? .home : nil
            if let dest {
                // если вкладки нет в панели — всё равно показываем расписание через главную
                let list = AppTab.parse(tabsRaw)
                tab = list.contains(dest) ? dest.rawValue : (list.first?.rawValue ?? "home")
                Haptics.tap()
            }
        }
        .onAppear {
            // если открытая вкладка убрана из панели — на первую
            let list = AppTab.parse(tabsRaw)
            if !list.contains(where: { $0.rawValue == tab }) { tab = list.first?.rawValue ?? "home" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) {
                withAnimation(.easeOut(duration: 0.5)) { showSplash = false }
            }
        }
    }

    @ViewBuilder
    private func tabContent(_ t: AppTab) -> some View {
        switch t {
        case .home: ResourcesView()
        case .schedule: ScheduleView()
        case .tasks: TasksView()
        case .files: FilesTab()
        case .subjects: NavigationStack { SubjectsView() }
        case .attendance: NavigationStack { AttendanceView() }
        case .developer: NavigationStack { DeveloperView() }
        case .profile: ProfileView()
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text("САФУ")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
                Text("by @\(Developer.telegram)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(Color.brand)
                    .opacity(pop ? 0.9 : 0)
                Text("версия \((Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "")")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}
