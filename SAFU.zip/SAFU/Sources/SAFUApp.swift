import SwiftUI
import UserNotifications
import BackgroundTasks
import WidgetKit

@main
struct SAFUApp: App {
    /// Хранилища появляются только когда данные телефона доступны (см. LaunchGuard)
    @StateObject private var boot = Boot()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
        HWNotifier.registerCategory()
        MemoryGuard.install()
    }

    var body: some Scene {
        WindowGroup {
            if let s = boot.stores {
                ContentView(stores: s)
                    .environmentObject(s.store)
                    .environmentObject(s.tasks)
                    .environmentObject(s.schedule)
                    .environmentObject(s.attendance)
                    .modifier(MacWindowSetup())
            } else {
                // телефон ещё не разблокирован после перезагрузки — ждём, ничего не трогая
                Color(.systemBackground)
                    .ignoresSafeArea()
                    .onAppear { boot.startIfReady() }
            }
        }
        // Фоновое обновление: iOS иногда будит приложение, и Live Activity
        // переключается на следующую пару даже без открытия приложения
        .backgroundTask(.appRefresh(BackgroundRefresh.id)) {
            await BackgroundRefresh.run()
        }
        #if targetEnvironment(macCatalyst)
        .commands { MacCommands() }
        #endif
    }
}

/// Бережём память: небольшой сетевой кэш, а при нехватке памяти сбрасываем всё, что можно пересоздать
enum MemoryGuard {
    static func install() {
        URLCache.shared = URLCache(memoryCapacity: 4 * 1024 * 1024, diskCapacity: 40 * 1024 * 1024)
        NotificationCenter.default.addObserver(forName: UIApplication.didReceiveMemoryWarningNotification,
                                               object: nil, queue: .main) { _ in
            ThumbCache.shared.removeAllObjects()
            URLCache.shared.removeAllCachedResponses()
            Task { @MainActor in SakaiWeb.shared.release() }
        }
        // ушли в фон — миниатюры не нужны, iOS реже выгрузит приложение
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { _ in
            ThumbCache.shared.removeAllObjects()
        }
    }
}

enum BackgroundRefresh {
    static let id = "ru.student.safuhub.refresh"

    static func schedule() {
        let req = BGAppRefreshTaskRequest(identifier: id)
        // с уведомлениями о почте просим будить почаще (iOS всё равно решает сама)
        req.earliestBeginDate = Date().addingTimeInterval((MailWatch.enabled ? 15 : 20) * 60)
        try? BGTaskScheduler.shared.submit(req)
    }

    static func run() async {
        schedule()
        // после перезагрузки телефон ещё не разблокировали — данные зашифрованы, ничего не трогаем
        guard LaunchGuard.dataAvailable() else { return }
        MailWatch.noteBackgroundRun()
        // почта — сразу и параллельно: у фоновой задачи ~30 секунд, а раньше почта ждала конца загрузки РУЗ
        // и часто не успевала вовсе
        async let mail: Void = MailWatch.checkIfEnabled(background: true)
        // ДЗ, задачи и заметки — с компьютером, если он в этой же сети
        async let pc: Void = PCSync.shared.backgroundSync()
        await ScheduleStore.backgroundSync()   // замены и отмены — уведомлением, даже если приложение закрыто
        let data = SharedSchedule.load()
        Celebrations.scheduleNotifications(data: data)
        AttendanceReminder.schedule(data: data)
        LiveActivityManager.update(data: data)
        BusLiveManager.auto(data: data)
        await mail
        await pc
        try? await Task.sleep(nanoseconds: 1_000_000_000)   // даём ActivityKit применить обновление
    }
}

struct ContentView: View {
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("theme.seasonal") private var seasonalTheme = false
    @AppStorage("look.pack") private var lookPack = ""
    @State private var showSplash = true
    /// Главная собирается, когда анимация заставки уже отыграла: раньше они делили кадры и заставка дёргалась
    @State private var contentReady = false
    /// Хранилища — простыми ссылками, без подписки. Раньше любое их изменение (синхронизация с РУЗ,
    /// «Недавние», правка задачи) пересобирало корень приложения со всеми вкладками и окнами.
    /// Экраны, которым нужны данные, подписаны на них сами
    let stores: Boot.Stores
    private var schedule: ScheduleStore { stores.schedule }
    private var tasks: TaskStore { stores.tasks }
    private var store: ResourceStore { stores.store }
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("onboarded") private var onboarded = false
    /// Регистрацию попросили пройти заново из Профиля
    @AppStorage("onboarding.again") private var onboardingAgain = false
    /// Идёт первая регистрация. Отдельный флаг: во время настройки расписание уже подключено,
    /// и окно не должно закрыться раньше, чем человек нажмёт «Поехали»
    @State private var registering = false
    @AppStorage("ui.appearanceOpen") private var appearanceOpen = false
    @ObservedObject private var boardRouter = BoardRouter.shared
    /// Перенос на компьютер: камера iPhone открыла приложение по QR-коду с экрана компьютера
    @ObservedObject private var pcRouter = PCTransferRouter.shared
    /// Посещаемость: перекличка из уведомления и файл с отметками от старосты или зама
    @ObservedObject private var attRouter = AttendanceRouter.shared
    /// Связали с компьютером кодом синхронизации из камеры iPhone — показываем экран синхронизации
    @State private var showSync = false
    /// Ссылка связки пришла извне (камера, чат, сайт): связываем только после «Связать»
    @State private var pendingSyncLink: SyncLink?

    private func syncLinkMessage(_ link: SyncLink) -> String {
        var text = "ДЗ, задачи, заметки и файлы предметов станут общими с Арктикой на этом компьютере"
        if let host = link.hosts.first { text += " (\(host))" }
        text += " — по Wi‑Fi, с шифрованием."
        if let old = PCSync.shared.pairing { text += "\nСвязка с «\(old.name)» заменится." }
        text += "\nСвязывай, только если сам открыл этот код на своём компьютере."
        return text
    }
    @AppStorage("privacy.shield") private var privacyShield = true
    @State private var showBoards = false
    /// Когда последний раз обновлялись при возвращении в приложение
    @State private var lastActiveRefresh = Date()
    /// Только число на значке «ДЗ», а не все записи — правка домашки больше не пересобирает корень со всеми вкладками
    @ObservedObject private var hwBadge = HomeworkBadge.shared
    @AppStorage("hw.badge") private var homeworkBadge = true
    @AppStorage("home.quickPlace") private var quickPlace = QuickPlace.standard

    private var shielded: Bool {
        #if targetEnvironment(macCatalyst)
        // на Mac окно неактивно, пока работаешь в другом приложении, — прячем только свёрнутое
        privacyShield && scenePhase == .background && !showSplash
        #else
        privacyShield && scenePhase != .active && !showSplash
        #endif
    }

    var body: some View {
        ZStack {
            if contentReady {
                TabView(selection: $tab) {
                    ForEach(AppTab.parse(tabsRaw)) { t in
                        tabContent(t)
                            .tabItem { Label(t.title, systemImage: t.icon) }
                            .badge(t == .homework && homeworkBadge ? HomeworkStore.shared.badgeCount : 0)
                            .tag(t.rawValue)
                    }
                }
                .modifier(TabBarMinimize())
                // Sakai, почта и другие главные кнопки — стеклянной полосой над вкладками (iOS 26)
                .modifier(QuickAccessory(enabled: quickPlace == "bar"))
                .tint(Color.brand)
                .id(theme + tabsRaw + (seasonalTheme ? "s" : "") + lookPack)
                // открыт сайт или файл — приложение под карточкой отъезжает назад, как в Telegram
                .modifier(SiteBackdrop())
            }

            // сайты-«мини-приложения»: развёрнутый сайт, плашка свёрнутых и их стопка
            // живут в отдельном окне поверх всего приложения — открываются и сворачиваются откуда угодно,
            // даже из листов и окон
            SiteOverlayInstaller(bottomExtra: quickPlace == "bar" ? 54 : (tab == AppTab.home.rawValue && quickPlace == "dock" ? 80 : 0),
                                 followsBar: quickPlace == "bar",
                                 hidden: !contentReady || showSplash || shielded,
                                 store: store,
                                 schedule: schedule)
                .frame(width: 0, height: 0)
                .allowsHitTesting(false)
                .accessibilityHidden(true)

            // салют и конфетти — в своём окне поверх всего (см. FXLayer)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }

            // в переключателе приложений не видно оценок, паролей и файлов
            if shielded {
                PrivacyShield()
                    .transition(.opacity)
                    .zIndex(3)
            }
        }
        .modifier(AppearanceRoot())
        .sheet(isPresented: $appearanceOpen) {
            AppearanceSheet()
        }
        .onReceive(NotificationCenter.default.publisher(for: .deviceDidShake)) { _ in Oracle.fire() }
        // ДЗ: редактор отовсюду, подстройка сроков под расписание
        .modifier(HomeworkRoot(tab: $tab, tabsRaw: tabsRaw))
        .modifier(TourHost())
        .onChange(of: tab) { _ in
            Haptics.tap()
            // другая вкладка — панель снова развёрнута, плашка свёрнутых сайтов возвращается
            SiteTabs.shared.setScrolledDown(false)
        }
        .background(FinishWatcher())
        .task {
            // запись пролагов включали перед перезапуском — продолжаем её до конца получаса
            HitchMonitor.resumeIfNeeded()
            // Face ID или Touch ID — узнаём в фоне заранее, чтобы Профиль не ждал системного ответа
            Task.detached(priority: .utility) { _ = AppLock.biometryName }
            // сначала даём нарисоваться первому экрану — остальное потом и в фоне (раньше это давало микролаги при входе)
            try? await Task.sleep(nanoseconds: 1_600_000_000)
            let snapshot = schedule.data
            let d = UserDefaults.standard
            let theme = d.string(forKey: "widget.theme") ?? WidgetTheme.night.rawValue
            let teacher = d.object(forKey: "widget.teacher") as? Bool ?? true
            Task.detached(priority: .utility) {
                // виджет забирает группу и пары при каждом запуске приложения
                WidgetBridge.publish(snapshot)
                WidgetBridge.publishLook(theme: theme, showTeacher: teacher)
                WidgetCenter.shared.reloadAllTimelines()
                LessonPhotosPDF.cleanTemp()
            }
            Notifier.requestAuthorization()
            Celebrations.checkOnOpen(data: schedule.data)
            HomeworkStore.shared.migrate(from: tasks)
            HomeworkStore.shared.cleanupFinished()
            await schedule.sync()
            // напоминания и Live Activity — одним пересчётом: если пары обновились, он уже назначен
            schedule.scheduleSideEffects()
            HomeworkStore.shared.reconcile(schedule.data)
            HWAsk.schedule(schedule.data)
            Celebrations.scheduleNotifications(data: schedule.data)
            AttendanceReminder.schedule(data: schedule.data)
            await SakaiSync.autoImport(tasks)
            // тяжёлая проверка БРС (невидимый браузер) — позже, чтобы не тормозить первые секунды
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            await GradeSync.autoRun(subjects: ScheduleQuery.subjects(schedule.data))
        }
        .onAppear {
            AppTab.addHomeworkOnce()
            HomeSection.addHomeworkOnce()
            HomeSection.quickFirstOnce()
            HomeSection.leanOnce()
            HomeSection.migrateQuickPlace()
            AppLock.shared.lock()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { AppLock.shared.authenticate(auto: true) }
        }
        // почта: пока приложение открыто — проверяем каждую минуту
        .task(id: scenePhase == .active) {
            guard scenePhase == .active else { return }
            while !Task.isCancelled {
                await MailWatch.checkIfEnabled()
                try? await Task.sleep(nanoseconds: 60_000_000_000)
            }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .background {
                BackgroundRefresh.schedule()
                AppLock.shared.lock()
            }
            if phase == .active {
                AppLock.shared.authenticate(auto: true)
                // запасная копия регистрации (переживёт сбой настроек и переустановку) — в фоне, связка ключей не быстрая
                let snapshot = schedule.data
                DispatchQueue.global(qos: .utility).async { RegistrationBackup.save(snapshot) }
                // салют, если пары кончились, пока приложение было свёрнуто (показывается один раз)
                Celebrations.checkOnOpen(data: schedule.data)
                // Пункт управления, шторка уведомлений, Face ID тоже дают «active» —
                // полностью обновляемся не чаще раза в 2 минуты
                guard Date().timeIntervalSince(lastActiveRefresh) > 120 else { return }
                lastActiveRefresh = Date()
                // сначала приложение плавно возвращается на экран, обновление — следом
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                    schedule.reloadFromDisk()
                    Task {
                        await schedule.sync()
                        schedule.scheduleSideEffects()
                        await SakaiSync.autoImport(tasks)
                    }
                }
            }
        }
        // регистрация: первый запуск или «пройти заново» из Профиля
        .fullScreenCover(isPresented: Binding(get: { !showSplash && (registering || onboardingAgain) },
                                              set: { if !$0 { registering = false; onboardingAgain = false } })) {
            RegistrationView(canClose: onboardingAgain && !registering) {
                // первая регистрация — потом короткая инструкция (один раз)
                if registering { TourRouter.shared.requestOnce() }
                onboarded = true
                RegistrationBackup.save(schedule.data)
                registering = false
                onboardingAgain = false
            }
            .environmentObject(schedule)
        }
        .onOpenURL { url in
            // файл .arkmarks — отметки от старосты или зама (из Telegram, Файлов, AirDrop)
            if attRouter.open(url) { return }
            // arktika://pc?… — QR-код с экрана компьютера: перенос файлов и данных на компьютер
            if let link = PCLink(url: url) {
                pcRouter.link = link
                return
            }
            // arktika://sync?… — код синхронизации: ДЗ, задачи и заметки будут общими с компьютером
            if let link = SyncLink(url: url) {
                pendingSyncLink = link
                return
            }
            // safu://schedule, safu:schedule, safu:///schedule — всё открывает нужную вкладку
            let target = (url.host ?? url.path.replacingOccurrences(of: "/", with: "")).lowercased()
            // safu://board — камера для текущей пары (удобно на «Действие» или в Команды), safu://boards — все фото
            if target == "board" {
                if LessonPhotos.currentSlot(schedule.data) != nil { boardRouter.camera = true } else { showBoards = true }
                return
            }
            if target == "boards" { showBoards = true; return }
            // safu://homework — раздел ДЗ, safu://hw — сразу записать ДЗ с текущей пары
            if target == "hw" || target == "homework-new" {
                HomeworkRouter.shared.new(slot: HWPlanner.suggestedSlot(schedule.data))
                return
            }
            if target.hasPrefix("homework") {
                HomeworkRouter.shared.openTab = true
                return
            }
            // из виджета: safu://pair?subject=… — предмет с материалами, safu://photo?subject=… — фото доски в его папку
            let subject = URLComponents(url: url, resolvingAgainstBaseURL: false)?
                .queryItems?.first { $0.name == "subject" }?.value ?? ""
            if target == "pair", !subject.isEmpty {
                boardRouter.subject = BoardRouter.SubjectLink(name: subject)
                return
            }
            if target == "photo", !subject.isEmpty {
                boardRouter.cameraSubject = subject
                boardRouter.camera = true
                return
            }
            let dest: AppTab? = target.hasPrefix("schedule") ? .schedule
                : target.hasPrefix("tasks") ? .tasks
                : target.hasPrefix("files") ? .files
                : target.hasPrefix("home") ? .home : nil
            if let dest {
                // если вкладки нет в панели — всё равно показываем расписание через главную
                let list = AppTab.parse(tabsRaw)
                tab = list.contains(dest) ? dest.rawValue : (list.first?.rawValue ?? "home")
                Haptics.tap()
            }
        }
        .sheet(item: $boardRouter.target) { t in
            NavigationStack {
                BoardBatchView(batch: boardBatch(t))
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { boardRouter.target = nil } }
                    }
            }
            .environmentObject(schedule)
        }
        .fullScreenCover(item: $attRouter.rollCall) { t in
            AttendanceRollCallHost(target: t)
                .environmentObject(stores.attendance)
                .environmentObject(schedule)
        }
        .sheet(item: $attRouter.incoming) { f in
            NavigationStack { AttendanceImportView(file: f) }
                .environmentObject(stores.attendance)
        }
        .sheet(item: $pcRouter.link) { link in
            NavigationStack {
                PCTransferView(link: link)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { pcRouter.link = nil } }
                    }
            }
        }
        // рядом компьютер с Арктикой, а телефон не связан — предложить связаться
        .background(SyncOfferHost(showSync: $showSync))
        // ссылку arktika://sync может прислать кто угодно — без вопроса телефон бы отдал ДЗ, заметки и файлы чужому компьютеру
        .alert(pendingSyncLink.map { "Связать с «\($0.name)»?" } ?? "",
               isPresented: Binding(get: { pendingSyncLink != nil }, set: { if !$0 { pendingSyncLink = nil } }),
               presenting: pendingSyncLink) { link in
            Button("Отмена", role: .cancel) { pendingSyncLink = nil }
            Button("Связать") {
                PCSync.shared.pair(link)
                pendingSyncLink = nil
                showSync = true
            }
        } message: { link in
            Text(syncLinkMessage(link))
        }
        .sheet(isPresented: $showSync) {
            NavigationStack {
                PCSyncView()
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { showSync = false } }
                    }
            }
        }
        .sheet(isPresented: $showBoards) {
            NavigationStack {
                BoardSearchView()
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { showBoards = false } }
                    }
            }
            .environmentObject(schedule)
        }
        .fullScreenCover(isPresented: $boardRouter.camera) {
            CameraPicker { image in
                boardRouter.camera = false
                let chosen = boardRouter.cameraSubject
                boardRouter.cameraSubject = nil
                if let image, let subject = chosen ?? LessonPhotos.currentSlot(schedule.data)?.lesson.subject,
                   BoardPhoto.save(image, subject: subject) != nil {
                    Haptics.success()
                }
            }
            .ignoresSafeArea()
        }
        // отдельным фоновым элементом: несколько окон на одном экране спорят между собой
        .background(
            Color.clear.sheet(item: $boardRouter.subject) { ref in
                SubjectSheet(subject: ref.name)
                    .environmentObject(store)
                    .environmentObject(tasks)
                    .environmentObject(schedule)
            }
        )
        .onAppear {
            if !onboarded && !schedule.isConfigured { registering = true }
            // если открытая вкладка убрана из панели — на первую
            let list = AppTab.parse(tabsRaw)
            if !list.contains(where: { $0.rawValue == tab }) { tab = list.first?.rawValue ?? "home" }
            // сначала плавно отыгрывает заставка, потом под ней собирается главная, потом заставка уходит
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) { contentReady = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                withAnimation(.easeOut(duration: 0.45)) { showSplash = false }
            }
        }
    }

    /// Пара с фото для уведомления «отправь ребятам»
    private func boardBatch(_ t: BoardRouter.Target) -> BoardBatch {
        let list = LessonPhotos.batches(subject: t.subject, data: schedule.data)
        if let start = t.start, let b = list.first(where: { abs($0.start.timeIntervalSince(start)) < 120 }) { return b }
        return list.first ?? BoardBatch(subject: t.subject, slot: nil, day: Date(), shots: [])
    }

    @ViewBuilder
    private func tabContent(_ t: AppTab) -> some View {
        switch t {
        case .home: ResourcesView()
        case .schedule: ScheduleView()
        case .homework: HomeworkView()
        case .tasks: TasksView()
        case .files: FilesTab()
        case .subjects: NavigationStack { SubjectsView() }
        case .attendance: NavigationStack { AttendanceView() }
        case .developer: NavigationStack { DeveloperView() }
        case .profile: ProfileView()
        }
    }
}

/// Ждёт конца последней пары и запускает салют прямо на экране.
/// Отдельным невидимым элементом: на расписание подписан только он, а не весь корень приложения
private struct FinishWatcher: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.scenePhase) private var scenePhase

    /// Меняется, когда меняется конец сегодняшних пар или приложение уходит/возвращается
    private var finishKey: String {
        "\(Celebrations.nextFinish(data: schedule.data)?.timeIntervalSince1970 ?? 0)|\(scenePhase == .active)"
    }

    var body: some View {
        Color.clear
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .task(id: finishKey) {
                guard scenePhase == .active, let end = Celebrations.nextFinish(data: schedule.data) else { return }
                let wait = end.timeIntervalSinceNow + 1
                if wait > 0 { try? await Task.sleep(nanoseconds: UInt64(wait * 1_000_000_000)) }
                guard !Task.isCancelled else { return }
                Celebrations.checkOnOpen(data: schedule.data)
            }
    }
}

/// Шторка поверх приложения, когда оно не на экране (снимок для переключателя приложений)
struct PrivacyShield: View {
    var body: some View {
        ZStack {
            // плотное «матовое стекло» — ничего не прочитать (без размытия всего приложения: оно дорогое)
            Rectangle().fill(.thickMaterial).ignoresSafeArea()
            VStack(spacing: 10) {
                Image(systemName: "snowflake")
                    .font(.system(size: 52, weight: .semibold))
                    .foregroundStyle(brandGradient)
                Text(AppInfo.name).font(.system(.title3, design: .rounded).weight(.heavy))
            }
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            // неподвижное свечение вместо живого фона с частицами: заставка не дёргается
            Color(.systemBackground)
                .overlay(RadialGradient(colors: [Color.brand.opacity(0.22), .clear], center: .init(x: 0.6, y: 0.35),
                                        startRadius: 0, endRadius: 360))
                .overlay(RadialGradient(colors: [Color.brand2.opacity(0.12), .clear], center: .init(x: 0.3, y: 0.8),
                                        startRadius: 0, endRadius: 300))
                .ignoresSafeArea()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text(AppInfo.name)
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
                Text("by @\(Developer.telegram)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(Color.brand)
                    .opacity(pop ? 0.9 : 0)
                Text("версия \((Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "")")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.62)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        if notification.request.identifier.hasPrefix("fx.end.") {
            // приложение открыто — салют уже на экране, баннер не нужен
            DispatchQueue.main.async { Celebrations.checkOnOpen(data: SharedSchedule.load()) }
            completionHandler([])
            return
        }
        completionHandler([.banner, .sound])
    }

    /// Нажали на уведомление: «фото с пары» открывает экран отправки
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let info = response.notification.request.content.userInfo
        if info[MailRouter.key] != nil {
            DispatchQueue.main.async {
                UserDefaults.standard.set(AppTab.home.rawValue, forKey: "memory.tabID")
                MailRouter.shared.pending = true
            }
        }
        // ДЗ: «Сделано» прямо из уведомления, нажатие — открыть задание
        if let raw = info[HWNotifier.idKey] as? String, let id = UUID(uuidString: raw) {
            let action = response.actionIdentifier
            DispatchQueue.main.async {
                if action == HWNotifier.doneAction {
                    HomeworkStore.shared.markDone(id: id)
                } else if let h = HomeworkStore.shared.item(id) {
                    HomeworkRouter.shared.show(h)
                }
            }
        }
        // «Что задали?» после пары — запись ДЗ сразу с этой парой
        if let subject = info[HWAsk.subjectKey] as? String {
            let start = (info[HWAsk.startKey] as? Double).map { Date(timeIntervalSince1970: $0) }
            DispatchQueue.main.async {
                let data = SharedSchedule.load()
                let slot = start.flatMap { HWPlanner.slot(subject: subject, start: $0, data: data) }
                HomeworkRouter.shared.new(slot: slot, subject: slot == nil ? subject : nil)
            }
        }
        // «Отметь, кто на паре» — сразу перекличка этой пары
        if let subject = info[AttendanceReminder.subjectKey] as? String,
           let start = info[AttendanceReminder.startKey] as? Double {
            DispatchQueue.main.async {
                AttendanceRouter.shared.rollCall = AttendanceRouter.Target(subject: subject, start: Date(timeIntervalSince1970: start))
            }
        }
        if let subject = info[BoardReminder.subjectKey] as? String {
            let start = (info[BoardReminder.startKey] as? Double).map { Date(timeIntervalSince1970: $0) }
            DispatchQueue.main.async {
                BoardRouter.shared.target = BoardRouter.Target(subject: subject, start: start)
            }
        }
        completionHandler()
    }
}


/// Оформление по умолчанию для новых студентов: тёмно-синее, как в первых версиях приложения.
/// Ставится один раз при самом первом запуске; у тех, кто уже пользуется, ничего не меняется.
enum FirstLook {
    static func applyIfNew() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "look.firstDefault") else { return }
        d.set(true, forKey: "look.firstDefault")
        guard !d.bool(forKey: "onboarded"), d.object(forKey: "theme") == nil else { return }
        d.set(AccentTheme.blue.rawValue, forKey: "theme")
        d.set(BackdropStyle.glow.rawValue, forKey: "bg.style")
        d.set(CardStyle.glass.rawValue, forKey: "cardStyle")
        d.set(AppFont.rounded.rawValue, forKey: "ui.font")
        d.set(1.0, forKey: "ui.radius")
        d.set(false, forKey: "ui.gradTitle")
        d.set(false, forKey: "theme.seasonal")
        d.set(SchemePref.dark.rawValue, forKey: "ui.scheme")
        d.set("", forKey: "look.pack")
    }
}
