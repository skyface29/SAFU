import SwiftUI
import UserNotifications

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()
    @StateObject private var tasks = TaskStore()
    @StateObject private var schedule = ScheduleStore()
    @StateObject private var attendance = AttendanceStore()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
    }
}

struct ContentView: View {
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @State private var showSplash = true
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                ForEach(AppTab.parse(tabsRaw)) { t in
                    tabContent(t)
                        .tabItem { Label(t.title, systemImage: t.icon) }
                        .tag(t.rawValue)
                }
            }
            .modifier(TabBarMinimize())
            .tint(Color.brand)
            .id(theme + tabsRaw)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .onChange(of: tab) { _ in Haptics.tap() }
        .task {
            Notifier.requestAuthorization()
            await schedule.sync()
            schedule.refreshSideEffects()
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                Task {
                    await schedule.sync()
                    schedule.refreshSideEffects()
                }
            }
        }
        .onOpenURL { url in
            if url.host == "schedule" { tab = AppTab.schedule.rawValue }
            if url.host == "tasks" { tab = AppTab.tasks.rawValue }
        }
        .onAppear {
            // если открытая вкладка убрана из панели — на первую
            let list = AppTab.parse(tabsRaw)
            if !list.contains(where: { $0.rawValue == tab }) { tab = list.first?.rawValue ?? "home" }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) {
                withAnimation(.easeOut(duration: 0.5)) { showSplash = false }
            }
        }
    }

    @ViewBuilder
    private func tabContent(_ t: AppTab) -> some View {
        switch t {
        case .home: ResourcesView()
        case .schedule: ScheduleView()
        case .tasks: TasksView()
        case .files: FilesTab()
        case .subjects: NavigationStack { SubjectsView() }
        case .attendance: NavigationStack { AttendanceView() }
        case .profile: ProfileView()
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text("САФУ")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
                Text("версия \((Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "")")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}
