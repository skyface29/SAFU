import SwiftUI

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .tint(Color.safuBlue)
        }
    }
}

struct ContentView: View {
    // Память: приложение открывается на той вкладке, где ты был
    @AppStorage("memory.tab") private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            ResourcesView()
                .tabItem { Label("Главная", systemImage: "square.grid.2x2.fill") }
                .tag(0)
            FilesTab()
                .tabItem { Label("Файлы", systemImage: "folder.fill") }
                .tag(1)
            InfoView()
                .tabItem { Label("Инфо", systemImage: "info.circle.fill") }
                .tag(2)
        }
        .onChange(of: tab) { _ in Haptics.tap() }
    }
}
