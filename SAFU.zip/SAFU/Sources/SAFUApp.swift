import SwiftUI
import UserNotifications

@main
struct SAFUApp: App {
    @StateObject private var store = ResourceStore()
    @StateObject private var tasks = TaskStore()

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(tasks)
        }
    }
}

struct ContentView: View {
    @AppStorage("memory.tab") private var tab = 0
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @State private var showSplash = true

    var body: some View {
        ZStack {
            TabView(selection: $tab) {
                ResourcesView()
                    .tabItem { Label("Главная", systemImage: "house.fill") }
                    .tag(0)
                TasksView()
                    .tabItem { Label("Задачи", systemImage: "checklist") }
                    .tag(1)
                FilesTab()
                    .tabItem { Label("Файлы", systemImage: "folder.fill") }
                    .tag(2)
                ProfileView()
                    .tabItem { Label("Профиль", systemImage: "person.crop.circle.fill") }
                    .tag(3)
            }
            .modifier(TabBarMinimize())
            .tint(Color.brand)
            .id(theme)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .onChange(of: tab) { _ in Haptics.tap() }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) {
                withAnimation(.easeOut(duration: 0.5)) { showSplash = false }
            }
        }
    }
}

struct SplashView: View {
    @State private var pop = false

    var body: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "snowflake")
                    .font(.system(size: 72, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .scaleEffect(pop ? 1 : 0.4)
                    .rotationEffect(.degrees(pop ? 0 : -120))
                Text("САФУ")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .opacity(pop ? 1 : 0)
                    .offset(y: pop ? 0 : 12)
                Text("всё для учёбы в одном месте")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .opacity(pop ? 1 : 0)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.6)) { pop = true }
        }
    }
}

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}
