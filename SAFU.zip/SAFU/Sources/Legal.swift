import SwiftUI
import WebKit
import UserNotifications

// MARK: - Конфиденциальность, статус приложения и удаление данных
// Требования App Store: политика конфиденциальности внутри приложения и по ссылке,
// понятно, что приложение неофициальное, и возможность стереть свои данные.

/// Название приложения — одно на всё приложение
enum AppInfo {
    static let name = L("Арктика")
    /// Полное название в App Store
    static let storeName = L("Арктика — пары и учёба")
}

enum Legal {
    /// Политика конфиденциальности в открытом репозитории (эту же ссылку указываем в App Store Connect)
    static let policyURL = URL(string: "https://github.com/skyface29/SAFU/blob/main/PRIVACY.md")!
    /// Условия Яндекс Карт: ссылку на них требуют условия MapKit (п. 4.1.3.2) в разделе «О программе»
    static let yandexMapsTermsURL = URL(string: "https://yandex.ru/legal/maps_termsofuse")!

    static let disclaimer = L("«Арктика» — неофициальное приложение. Сделано студентом САФУ и не связано с Северным (Арктическим) федеральным университетом имени М. В. Ломоносова. Расписание берётся из открытого РУЗ САФУ; сайты университета открываются как в обычном браузере.")

    /// Стереть всё, что приложение хранит на этом телефоне
    @MainActor
    static func eraseEverything() async {
        // файлы: предметы, фото доски, лекции, отчёты
        let fm = FileManager.default
        for dir in [fm.urls(for: .documentDirectory, in: .userDomainMask).first,
                    fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first,
                    fm.urls(for: .cachesDirectory, in: .userDomainMask).first].compactMap({ $0 }) {
            for item in (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? [] {
                try? fm.removeItem(at: item)
            }
        }
        // пароли и ключи ИИ из связки ключей
        for account in Keychain.accounts() { Keychain.delete(account) }
        // вход на сайты
        await WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                                      modifiedSince: .distantPast)
        HTTPCookieStorage.shared.removeCookies(since: .distantPast)
        URLCache.shared.removeAllCachedResponses()
        // уведомления и цифра на иконке
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
        try? await center.setBadgeCount(0)
        // настройки — в самом конце
        if let id = Bundle.main.bundleIdentifier { UserDefaults.standard.removePersistentDomain(forName: id) }
        SharedSchedule.shared.removePersistentDomain(forName: SharedSchedule.groupID)
    }
}

struct LegalView: View {
    @State private var confirmErase = false
    @State private var erasing = false
    @State private var erased = false

    var body: some View {
        List {
            Section {
                Label {
                    Text(Legal.disclaimer).font(.subheadline)
                } icon: {
                    Image(systemName: "info.circle.fill").foregroundStyle(Color.brand)
                }
                Link(destination: Legal.yandexMapsTermsURL) {
                    Label(L("Условия использования сервиса Яндекс.Карты"), systemImage: "map.fill")
                }
            } header: {
                Text(L("О приложении"))
            }

            Section {
                row("iphone", L("Всё хранится только на этом телефоне: расписание, заметки, файлы, фото доски, лекции."))
                row("key.fill", L("Пароли от сайтов и ключи ИИ — в связке ключей только этого iPhone: не синхронизируются и не переносятся на другие устройства."))
                row("hand.raised.fill", L("Нет рекламы, аналитики, трекеров и своих серверов. Разработчик не получает никаких твоих данных."))
                row("network", L("Приложение обращается к РУЗ САФУ, сайтам вуза, которые ты открываешь, почте САФУ (если включишь уведомления о письмах), погоде Open-Meteo и Яндекс Картам."))
                row("chart.bar.fill", L("Баллы БРС приложение само подтягивает из Sakai и личного кабинета, если ты уже вошёл туда в приложении. Выключить: БРС → «Сами при открытии»."))
                row("waveform", L("Модель распознавания речи для лекций один раз скачивается с Hugging Face. Сама запись распознаётся на телефоне и никуда не отправляется."))
                row("sparkles", L("ИИ-конспект лекций: текст расшифровки уходит в GigaChat или Claude только с твоего разрешения и только если ты сам вписал свой ключ. Аудио не отправляется."))
                row("location.fill", L("Геопозиция — чтобы понять город для автобуса и показать твою точку на карте транспорта. Приложение координаты не хранит и само никуда не отправляет; карту транспорта показывают Яндекс Карты, и Яндекс обрабатывает данные по своим правилам."))
                Link(destination: Legal.policyURL) {
                    Label(L("Политика конфиденциальности полностью"), systemImage: "doc.text.fill")
                }
            } header: {
                Text(L("Конфиденциальность"))
            }

            Section {
                Button(role: .destructive) {
                    confirmErase = true
                } label: {
                    HStack {
                        Label(L("Удалить все мои данные"), systemImage: "trash.fill")
                        if erasing { Spacer(); ProgressView() }
                    }
                }
                .disabled(erasing || erased)
                if erased {
                    Text(L("Готово. Закрой приложение полностью (смахни его вверх в переключателе) и открой заново — начнёшь с чистого листа."))
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            } footer: {
                Text(L("Сотрёт расписание, файлы предметов, фото доски, лекции, заметки, задачи, сохранённые пароли, вход на сайты и все настройки. Отменить нельзя — сначала сделай резервную копию, если она нужна."))
            }
        }
        .navigationTitle(L("Конфиденциальность"))
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog(L("Удалить все данные приложения?"), isPresented: $confirmErase, titleVisibility: .visible) {
            Button(L("Удалить всё"), role: .destructive) {
                erasing = true
                Task {
                    await Legal.eraseEverything()
                    erasing = false
                    erased = true
                    Haptics.success()
                }
            }
        } message: {
            Text(L("Это нельзя отменить."))
        }
    }

    private func row(_ icon: String, _ text: String) -> some View {
        Label {
            Text(text).font(.subheadline)
        } icon: {
            Image(systemName: icon).foregroundStyle(Color.brand)
        }
    }
}
