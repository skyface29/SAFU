import SwiftUI
import WebKit
import UserNotifications

// MARK: - Конфиденциальность, статус приложения и удаление данных
// Требования App Store: политика конфиденциальности внутри приложения и по ссылке,
// понятно, что приложение неофициальное, и возможность стереть свои данные.

enum Legal {
    /// Политика конфиденциальности в открытом репозитории (эту же ссылку указываем в App Store Connect)
    static let policyURL = URL(string: "https://github.com/skyface29/SAFU/blob/main/PRIVACY.md")!

    static let disclaimer = "Неофициальное приложение. Сделано студентом САФУ и не связано с Северным (Арктическим) федеральным университетом имени М. В. Ломоносова. Расписание берётся из открытого РУЗ САФУ; сайты университета открываются как в обычном браузере."

    /// Стереть всё, что приложение хранит на этом телефоне
    @MainActor
    static func eraseEverything() async {
        // файлы: предметы, фото доски, лекции, отчёты
        let fm = FileManager.default
        for dir in [fm.urls(for: .documentDirectory, in: .userDomainMask).first,
                    fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first,
                    fm.urls(for: .cachesDirectory, in: .userDomainMask).first].compactMap({ $0 }) {
            for item in (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? [] {
                try? fm.removeItem(at: item)
            }
        }
        // пароли и ключи ИИ из связки ключей
        for account in Keychain.accounts() { Keychain.delete(account) }
        // вход на сайты
        await WKWebsiteDataStore.default().removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                                                      modifiedSince: .distantPast)
        HTTPCookieStorage.shared.removeCookies(since: .distantPast)
        URLCache.shared.removeAllCachedResponses()
        // уведомления и цифра на иконке
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
        try? await center.setBadgeCount(0)
        // настройки — в самом конце
        if let id = Bundle.main.bundleIdentifier { UserDefaults.standard.removePersistentDomain(forName: id) }
        SharedSchedule.shared.removePersistentDomain(forName: SharedSchedule.groupID)
    }
}

struct LegalView: View {
    @State private var confirmErase = false
    @State private var erasing = false
    @State private var erased = false

    var body: some View {
        List {
            Section {
                Label {
                    Text(Legal.disclaimer).font(.subheadline)
                } icon: {
                    Image(systemName: "info.circle.fill").foregroundStyle(Color.brand)
                }
            } header: {
                Text("О приложении")
            }

            Section {
                row("iphone", "Всё хранится только на этом телефоне: расписание, заметки, файлы, фото доски, лекции.")
                row("key.fill", "Пароли от сайтов — в связке ключей iPhone, без синхронизации и резервных копий.")
                row("hand.raised.fill", "Нет рекламы, аналитики, трекеров и своих серверов. Разработчик не получает никаких твоих данных.")
                row("network", "Приложение обращается к РУЗ САФУ, сайтам вуза, которые ты открываешь, почте САФУ (если включишь уведомления о письмах), погоде Open-Meteo и Яндекс Картам.")
                row("sparkles", "ИИ-конспект лекций: текст расшифровки уходит в GigaChat или Claude только с твоего разрешения и только если ты сам вписал свой ключ. Аудио не отправляется.")
                row("location.fill", "Геопозиция — только чтобы понять город для автобуса. Не сохраняется и никуда не уходит.")
                Link(destination: Legal.policyURL) {
                    Label("Политика конфиденциальности полностью", systemImage: "doc.text.fill")
                }
            } header: {
                Text("Конфиденциальность")
            }

            Section {
                Button(role: .destructive) {
                    confirmErase = true
                } label: {
                    HStack {
                        Label("Удалить все мои данные", systemImage: "trash.fill")
                        if erasing { Spacer(); ProgressView() }
                    }
                }
                .disabled(erasing || erased)
                if erased {
                    Text("Готово. Закрой приложение полностью (смахни его вверх в переключателе) и открой заново — начнёшь с чистого листа.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            } footer: {
                Text("Сотрёт расписание, файлы предметов, фото доски, лекции, заметки, задачи, сохранённые пароли, вход на сайты и все настройки. Отменить нельзя — сначала сделай резервную копию, если она нужна.")
            }
        }
        .navigationTitle("Конфиденциальность")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Удалить все данные приложения?", isPresented: $confirmErase, titleVisibility: .visible) {
            Button("Удалить всё", role: .destructive) {
                erasing = true
                Task {
                    await Legal.eraseEverything()
                    erasing = false
                    erased = true
                    Haptics.success()
                }
            }
        } message: {
            Text("Это нельзя отменить.")
        }
    }

    private func row(_ icon: String, _ text: String) -> some View {
        Label {
            Text(text).font(.subheadline)
        } icon: {
            Image(systemName: icon).foregroundStyle(Color.brand)
        }
    }
}
