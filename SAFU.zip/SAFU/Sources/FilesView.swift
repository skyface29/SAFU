import SwiftUI
import PhotosUI
import QuickLook
import UniformTypeIdentifiers
import QuickLookThumbnailing

struct FilesTab: View {
    var body: some View {
        NavigationStack {
            LockGate {
                FolderView(url: FileService.root, title: "Файлы")
            }
        }
    }
}

struct FolderView: View {
    let url: URL
    let title: String

    @State private var items: [FileItem] = []
    @State private var query = ""

    private var filtered: [FileItem] {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return items }
        return items.filter { $0.name.localizedCaseInsensitiveContains(q) }
    }
    @State private var preview: URL?

    @State private var showImporter = false
    @State private var showPhotos = false
    @State private var photoItems: [PhotosPickerItem] = []

    @State private var showNewFolder = false
    @State private var newFolderName = ""

    @State private var renaming: FileItem?
    @State private var renameText = ""
    @State private var moving: FileItem?
    @State private var deleting: FileItem?

    @State private var errorText: String?
    @State private var isImporting = false

    var body: some View {
        List {
            if items.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray")
                        .font(.system(size: 40))
                        .foregroundStyle(.secondary)
                    Text("Пока пусто")
                        .font(.headline)
                    Text("Нажми «+», чтобы добавить файлы, фото или папку.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 40)
                .listRowBackground(Color.clear)
            }

            ForEach(filtered) { item in
                Group {
                    if item.isDirectory {
                        NavigationLink {
                            FolderView(url: item.url, title: item.name)
                        } label: {
                            FileRow(item: item)
                        }
                    } else {
                        Button { preview = item.url } label: { FileRow(item: item) }
                    }
                }
                .contextMenu { menu(for: item) }
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) { deleting = item } label: {
                        Label("Удалить", systemImage: "trash")
                    }
                    Button { moving = item } label: {
                        Label("Переместить", systemImage: "folder")
                    }
                    .tint(.orange)
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AmbientBackground())
        .searchable(text: $query, prompt: "Поиск в папке")
        .navigationTitle(title)
        .overlay {
            if isImporting { ProgressView().controlSize(.large) }
        }
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Menu {
                    Button { showImporter = true } label: { Label("Файлы", systemImage: "doc.badge.plus") }
                    Button { showPhotos = true } label: { Label("Фото и видео", systemImage: "photo.on.rectangle") }
                    Divider()
                    Button {
                        newFolderName = ""
                        showNewFolder = true
                    } label: { Label("Новая папка", systemImage: "folder.badge.plus") }
                } label: {
                    Image(systemName: "plus.circle.fill").font(.title3)
                }
            }
        }
        .onAppear(perform: reload)
        .refreshable { reload() }
        .quickLookPreview($preview)
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: [.item],
                      allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls):
                var failed = 0
                for u in urls {
                    do { try FileService.importFile(from: u, to: url) } catch { failed += 1 }
                }
                if failed > 0 { errorText = "Не удалось добавить файлов: \(failed)" }
                reload()
            case .failure(let error):
                errorText = error.localizedDescription
            }
        }
        .photosPicker(isPresented: $showPhotos, selection: $photoItems,
                      matching: .any(of: [.images, .videos]))
        .onChange(of: photoItems) { newItems in
            guard !newItems.isEmpty else { return }
            importPhotos(newItems)
        }
        .alert("Новая папка", isPresented: $showNewFolder) {
            TextField("Название", text: $newFolderName)
            Button("Создать") {
                perform { try FileService.createFolder(named: newFolderName, in: url) }
            }
            Button("Отмена", role: .cancel) {}
        }
        .alert("Переименовать", isPresented: Binding(
            get: { renaming != nil },
            set: { if !$0 { renaming = nil } })) {
            TextField("Новое имя", text: $renameText)
            Button("Готово") {
                if let item = renaming {
                    perform { try FileService.rename(item, to: renameText) }
                }
                renaming = nil
            }
            Button("Отмена", role: .cancel) { renaming = nil }
        }
        .confirmationDialog(deleteTitle, isPresented: Binding(
            get: { deleting != nil },
            set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let item = deleting { perform { try FileService.delete(item) } }
                deleting = nil
            }
        }
        .sheet(item: $moving) { item in
            MoveSheet(item: item) { dest in
                perform { try FileService.move(item, to: dest) }
            }
        }
        .alert("Ошибка", isPresented: Binding(
            get: { errorText != nil },
            set: { if !$0 { errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorText ?? "")
        }
    }

    private var deleteTitle: String {
        guard let d = deleting else { return "" }
        return d.isDirectory ? "Удалить папку «\(d.name)» со всем содержимым?" : "Удалить «\(d.name)»?"
    }

    @ViewBuilder
    private func menu(for item: FileItem) -> some View {
        if !item.isDirectory {
            Button { preview = item.url } label: { Label("Открыть", systemImage: "eye") }
            ShareLink(item: item.url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
        }
        Button {
            renameText = item.isDirectory ? item.name : (item.name as NSString).deletingPathExtension
            renaming = item
        } label: { Label("Переименовать", systemImage: "pencil") }
        Button { moving = item } label: { Label("Переместить", systemImage: "folder") }
        Button(role: .destructive) { deleting = item } label: { Label("Удалить", systemImage: "trash") }
    }

    private func reload() {
        items = FileService.list(url)
    }

    private func perform(_ action: () throws -> Void) {
        do { try action() } catch { errorText = error.localizedDescription }
        reload()
    }

    private func importPhotos(_ selection: [PhotosPickerItem]) {
        isImporting = true
        Task {
            var failed = 0
            for item in selection {
                do {
                    if let data = try await item.loadTransferable(type: Data.self) {
                        let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "jpg"
                        try FileService.save(data, ext: ext, to: url)
                    } else { failed += 1 }
                } catch { failed += 1 }
            }
            await MainActor.run {
                photoItems = []
                isImporting = false
                if failed > 0 { errorText = "Не удалось добавить: \(failed)" }
                reload()
            }
        }
    }
}

struct FileRow: View {
    let item: FileItem

    var body: some View {
        HStack(spacing: 12) {
            FileThumb(item: item)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(details)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }

    private var details: String {
        let date = item.modified.formatted(date: .abbreviated, time: .omitted)
        if item.isDirectory {
            let count = FileService.list(item.url).count
            return "\(count) шт. · \(date)"
        }
        let size = ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)
        return "\(size) · \(date)"
    }
}

struct FileThumb: View {
    let item: FileItem
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                RoundedRectangle(cornerRadius: 11, style: .continuous)
                    .fill(Color.brand.opacity(item.isDirectory ? 0.16 : 0.08))
                Image(systemName: FileService.icon(for: item))
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(item.isDirectory ? Color.brand : Color.secondary)
            }
        }
        .frame(width: 44, height: 44)
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
        .task(id: item.url) { await load() }
    }

    private func load() async {
        guard !item.isDirectory else { return }
        let request = QLThumbnailGenerator.Request(fileAt: item.url,
                                                   size: CGSize(width: 88, height: 88),
                                                   scale: 2,
                                                   representationTypes: .thumbnail)
        if let rep = try? await QLThumbnailGenerator.shared.generateBestRepresentation(for: request) {
            image = rep.uiImage
        }
    }
}

struct MoveSheet: View {
    let item: FileItem
    let onPick: (URL) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(FileService.allFolders(excluding: item.isDirectory ? item.url : nil)) { folder in
                let isCurrent = FileService.path(folder.url) ==
                    FileService.path(item.url.deletingLastPathComponent())
                Button {
                    onPick(folder.url)
                    dismiss()
                } label: {
                    HStack(spacing: 10) {
                        Color.clear.frame(width: CGFloat(folder.depth) * 18, height: 1)
                        Image(systemName: folder.depth == 0 ? "house.fill" : "folder.fill")
                            .foregroundStyle(Color.brand)
                        Text(folder.depth == 0 ? "Мои файлы" : folder.url.lastPathComponent)
                            .foregroundStyle(isCurrent ? Color.secondary : Color.primary)
                        if isCurrent {
                            Spacer()
                            Text("сейчас здесь").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .disabled(isCurrent)
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Куда переместить «\(item.name)»")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
            }
        }
    }
}
