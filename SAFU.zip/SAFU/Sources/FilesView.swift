import SwiftUI
import PhotosUI
import QuickLook
import UniformTypeIdentifiers
import QuickLookThumbnailing
import VisionKit

struct FilesTab: View {
    var body: some View {
        NavigationStack {
            LockGate {
                FolderView(url: FileService.root, title: "Файлы")
            }
        }
    }
}

struct FolderView: View {
    let url: URL
    let title: String

    @AppStorage("files.grid.v2") private var grid = false
    @AppStorage("files.sort") private var sortMode = 0

    @State private var items: [FileItem] = []
    @State private var recent: [FileItem] = []
    @State private var summary = FileService.Summary()
    @State private var query = ""
    @State private var filter: FileService.Kind = .all
    @State private var preview: URL?

    @State private var showImporter = false
    @State private var showPhotos = false
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showScanner = false

    @State private var showNewFolder = false
    @State private var newFolderName = ""
    @State private var showNote = false

    @State private var renaming: FileItem?
    @State private var renameText = ""
    @State private var moving: FileItem?
    @State private var deleting: FileItem?
    @State private var selecting = false
    @State private var selected: Set<URL> = []
    @State private var confirmBulkDelete = false

    @State private var errorText: String?
    @State private var isImporting = false
    @State private var toast: String?

    private var isRoot: Bool { FileService.isRoot(url) }
    @EnvironmentObject private var schedule: ScheduleStore

    /// Папка «Предметы» показывается особым списком: значок, преподаватель, файлы, ближайшая пара
    private var isSubjectsBase: Bool { FileService.path(url) == FileService.path(SubjectFolders.base) }

    /// Показываем окна с небольшой задержкой: если открывать их прямо из меню,
    /// iOS иногда молча их не показывает (меню ещё закрывается) — из-за этого «не добавлялись файлы»
    private func later(_ action: @escaping () -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35, execute: action)
    }

    private var visible: [FileItem] {
        let q = query.trimmingCharacters(in: .whitespaces)
        let base = items.filter { FileService.matches($0, filter) }
        let searched = q.isEmpty ? base : base.filter { $0.name.localizedCaseInsensitiveContains(q) }
        return FileService.sorted(searched, by: sortMode)
    }

    private let gridColumns = [GridItem(.adaptive(minimum: 104), spacing: 12)]

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    if isRoot {
                        Text("\(ByteCountFormatter.string(fromByteCount: summary.bytes, countStyle: .file)) · файлов: \(summary.files)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    actionBar
                    if filter != .all {
                        Button { filter = .all } label: {
                            Label("Показаны: \(filter.title) — сбросить", systemImage: "line.3.horizontal.decrease.circle.fill")
                                .font(.caption.weight(.semibold))
                        }
                    }
                    content
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.4, dampingFraction: 0.85), value: grid)
                .animation(.spring(response: 0.4, dampingFraction: 0.85), value: filter)
                .animation(.spring(response: 0.4, dampingFraction: 0.85), value: sortMode)
            }
            .refreshable { reload() }

            if isImporting {
                ProgressView("Добавляю…")
                    .padding(20)
                    .glass(20)
            }
        }
        .overlay(alignment: .bottom) {
            if let toast {
                Label(toast, systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .glass(22)
                    .padding(.bottom, 16)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .searchable(text: $query, prompt: "Поиск в «\(title)»")
        .navigationTitle(title)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(selecting ? "Готово" : "Выбрать") {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                        selecting.toggle()
                        selected = []
                    }
                }
                .fontWeight(selecting ? .bold : .regular)
                .disabled(items.isEmpty && !selecting)
            }
            if !selecting {
                ToolbarItem(placement: .navigationBarTrailing) { viewMenu }
                ToolbarItem(placement: .navigationBarTrailing) { addMenu }
            }
        }
        .safeAreaInset(edge: .bottom) {
            if selecting { selectionBar.transition(.move(edge: .bottom).combined(with: .opacity)) }
        }
        .confirmationDialog(bulkTitle, isPresented: $confirmBulkDelete, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { deleteSelected() }
        }
        .onAppear(perform: reload)
        .quickLookPreview($preview)
        .sheet(isPresented: $showImporter) {
            DocumentPicker { urls in
                showImporter = false
                guard !urls.isEmpty else { return }
                var failed = 0
                for u in urls {
                    do { try FileService.importFile(from: u, to: url) } catch { failed += 1 }
                }
                if failed > 0 { errorText = "Не удалось добавить файлов: \(failed)" }
                else { showToast("Добавлено: \(urls.count)") }
                reload()
            }
            .ignoresSafeArea()
        }
        .photosPicker(isPresented: $showPhotos, selection: $photoItems, matching: .any(of: [.images, .videos]))
        .onChange(of: photoItems) { newItems in
            guard !newItems.isEmpty else { return }
            importPhotos(newItems)
        }
        .fullScreenCover(isPresented: $showScanner) {
            DocumentScanner { images in
                showScanner = false
                guard !images.isEmpty else { return }
                perform { try FileService.savePDF(ScanPDF.make(images), in: url) }
                showToast("Скан сохранён в PDF")
            } onCancel: {
                showScanner = false
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showNote) {
            NoteEditor { name, text in
                perform { try FileService.createTextFile(named: name, text: text, in: url) }
                showToast("Заметка сохранена")
            }
        }
        .alert("Новая папка", isPresented: $showNewFolder) {
            TextField("Название", text: $newFolderName)
            Button("Создать") {
                perform { try FileService.createFolder(named: newFolderName, in: url) }
            }
            Button("Отмена", role: .cancel) {}
        }
        .alert("Переименовать", isPresented: Binding(get: { renaming != nil },
                                                     set: { if !$0 { renaming = nil } })) {
            TextField("Новое имя", text: $renameText)
            Button("Готово") {
                if let item = renaming { perform { try FileService.rename(item, to: renameText) } }
                renaming = nil
            }
            Button("Отмена", role: .cancel) { renaming = nil }
        }
        .confirmationDialog(deleteTitle, isPresented: Binding(get: { deleting != nil },
                                                              set: { if !$0 { deleting = nil } }),
                            titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let item = deleting {
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
                        perform { try FileService.delete(item) }
                    }
                    showToast("Удалено")
                }
                deleting = nil
            }
        }
        .sheet(item: $moving) { item in
            MoveSheet(item: item) { dest in
                perform { try FileService.move(item, to: dest) }
                showToast("Перемещено")
            }
        }
        .alert("Ошибка", isPresented: Binding(get: { errorText != nil },
                                              set: { if !$0 { errorText = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(errorText ?? "")
        }
    }

    // MARK: меню

    private var addMenu: some View {
        Menu {
            if VNDocumentCameraViewController.isSupported {
                Button { later { showScanner = true } } label: { Label("Сканировать документ", systemImage: "doc.viewfinder") }
            }
            Button { later { showImporter = true } } label: { Label("Из «Файлов»", systemImage: "doc.badge.plus") }
            Button { later { showPhotos = true } } label: { Label("Фото и видео", systemImage: "photo.on.rectangle") }
            Divider()
            Button { later { showNote = true } } label: { Label("Текстовая заметка", systemImage: "square.and.pencil") }
            Button {
                newFolderName = ""
                later { showNewFolder = true }
            } label: { Label("Новая папка", systemImage: "folder.badge.plus") }
        } label: {
            Image(systemName: "plus.circle.fill").font(.title3)
        }
    }

    /// Всегда видимые кнопки добавления (без меню — надёжнее)
    private var actionBar: some View {
        HStack(spacing: 8) {
            if VNDocumentCameraViewController.isSupported {
                actionChip("Скан", icon: "doc.viewfinder") { showScanner = true }
            }
            actionChip("Файл", icon: "doc.badge.plus") { showImporter = true }
            actionChip("Фото", icon: "photo") { showPhotos = true }
            actionChip("Папка", icon: "folder.badge.plus") {
                newFolderName = ""
                showNewFolder = true
            }
        }
    }

    private func actionChip(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Label(title, systemImage: icon)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background(Color.primary.opacity(0.06), in: Capsule())
        }
        .buttonStyle(PressableStyle())
    }

    private var viewMenu: some View {
        Menu {
            Picker("Вид", selection: $grid) {
                Label("Плитка", systemImage: "square.grid.2x2").tag(true)
                Label("Список", systemImage: "list.bullet").tag(false)
            }
            Picker("Показать", selection: $filter) {
                ForEach(FileService.Kind.allCases, id: \.rawValue) { k in
                    Label(k.title, systemImage: k.icon).tag(k)
                }
            }
            Picker("Сортировка", selection: $sortMode) {
                Label("По имени", systemImage: "textformat").tag(0)
                Label("Сначала новые", systemImage: "clock").tag(1)
                Label("По размеру", systemImage: "arrow.up.arrow.down").tag(2)
                Label("По типу", systemImage: "doc.on.doc").tag(3)
            }
        } label: {
            Image(systemName: grid ? "square.grid.2x2" : "list.bullet")
        }
    }

    // MARK: сводка

    private var storageCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(ByteCountFormatter.string(fromByteCount: summary.bytes, countStyle: .file))
                        .font(.system(.title2, design: .rounded).weight(.bold))
                    Text("\(summary.files) файлов · \(summary.folders) папок")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "externaldrive.fill")
                    .font(.title2)
                    .foregroundStyle(brandGradient)
            }
            GeometryReader { geo in
                HStack(spacing: 2) {
                    ForEach(barKinds, id: \.rawValue) { k in
                        let part = summary.bytes > 0 ? Double(summary.byKind[k] ?? 0) / Double(summary.bytes) : 0
                        if part > 0 {
                            Rectangle()
                                .fill(color(for: k))
                                .frame(width: max(4, geo.size.width * part))
                        }
                    }
                    if summary.bytes == 0 {
                        Rectangle().fill(Color.primary.opacity(0.1))
                    }
                }
                .clipShape(Capsule())
            }
            .frame(height: 8)
            HStack(spacing: 12) {
                ForEach(barKinds, id: \.rawValue) { k in
                    HStack(spacing: 4) {
                        Circle().fill(color(for: k)).frame(width: 7, height: 7)
                        Text(k.title).font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .padding(16)
        .glass(24)
    }

    private var barKinds: [FileService.Kind] { [.docs, .pdf, .images, .video] }

    private func color(for k: FileService.Kind) -> Color {
        switch k {
        case .docs: return .blue
        case .pdf: return .red
        case .images: return .green
        case .video: return .orange
        default: return .gray
        }
    }

    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(FileService.Kind.allCases, id: \.rawValue) { k in
                    Button {
                        Haptics.tap()
                        filter = k
                    } label: {
                        Label(k.title, systemImage: k.icon)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(filter == k ? Color.white : Color.primary)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background {
                                if filter == k {
                                    Capsule().fill(brandGradient)
                                } else {
                                    Capsule().fill(Color.primary.opacity(0.07))
                                }
                            }
                    }
                    .buttonStyle(PressableStyle())
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.horizontal, -20)
    }

    private var recentStrip: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Недавние")
                .font(.system(.headline, design: .rounded))
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(recent) { item in
                        Button { preview = item.url } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                FileThumb(item: item, size: 84)
                                Text(item.name)
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .frame(width: 84, alignment: .leading)
                            }
                        }
                        .buttonStyle(PressableStyle())
                        .contextMenu { menu(for: item) }
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.horizontal, -20)
        }
    }

    // MARK: содержимое

    @ViewBuilder private var content: some View {
        let list = visible
        if items.isEmpty {
            VStack(spacing: 14) {
                EmptyState(icon: "tray", title: "Пока пусто",
                           text: "Отсканируй документ, добавь файлы или фото. Можно создавать папки по предметам.")
                HStack(spacing: 10) {
                    if VNDocumentCameraViewController.isSupported {
                        quickButton("Скан", icon: "doc.viewfinder") { showScanner = true }
                    }
                    quickButton("Файлы", icon: "doc.badge.plus") { showImporter = true }
                    quickButton("Фото", icon: "photo") { showPhotos = true }
                }
            }
        } else if list.isEmpty {
            Text("Ничего не найдено")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 30)
        } else if isSubjectsBase && filter == .all {
            VStack(spacing: 10) {
                ForEach(Array(list.enumerated()), id: \.element.id) { index, item in
                    Group {
                        if item.isDirectory && selecting {
                            cell(item) {
                                SubjectRow(subject: item.name, data: schedule.data)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .glass(18)
                            }
                        } else if item.isDirectory {
                            NavigationLink {
                                FolderView(url: item.url, title: item.name)
                            } label: {
                                HStack {
                                    SubjectRow(subject: item.name, data: schedule.data)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.bold))
                                        .foregroundStyle(.secondary)
                                }
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .glass(18)
                            }
                            .buttonStyle(PressableStyle())
                        } else {
                            cell(item) { FileRow(item: item) }
                        }
                    }
                    .contextMenu { menu(for: item) }
                    .staggerIn(min(index, 12))
                }
            }
        } else if grid {
            LazyVGrid(columns: gridColumns, spacing: 14) {
                ForEach(Array(list.enumerated()), id: \.element.id) { index, item in
                    cell(item) { FileTile(item: item) }
                        .staggerIn(min(index, 12))
                }
            }
        } else {
            VStack(spacing: 8) {
                ForEach(Array(list.enumerated()), id: \.element.id) { index, item in
                    cell(item) { FileRow(item: item) }
                        .staggerIn(min(index, 12))
                }
            }
        }
    }

    @ViewBuilder
    private func cell<Content: View>(_ item: FileItem, @ViewBuilder label: () -> Content) -> some View {
        if selecting {
            let on = selected.contains(item.url)
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                    if on { selected.remove(item.url) } else { selected.insert(item.url) }
                }
            } label: {
                label()
                    .overlay {
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(on ? Color.brand : Color.clear, lineWidth: 2.5)
                    }
                    .overlay(alignment: .topTrailing) {
                        Image(systemName: on ? "checkmark.circle.fill" : "circle")
                            .font(.title3.weight(.semibold))
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(on ? Color.white : Color.secondary, on ? Color.brand : Color.clear)
                            .background(Circle().fill(.ultraThinMaterial))
                            .padding(6)
                    }
                    .scaleEffect(on ? 0.97 : 1)
            }
            .buttonStyle(.plain)
        } else {
            normalCell(item, label: label)
        }
    }

    @ViewBuilder
    private func normalCell<Content: View>(_ item: FileItem, @ViewBuilder label: () -> Content) -> some View {
        Group {
            if item.isDirectory {
                NavigationLink {
                    FolderView(url: item.url, title: item.name)
                } label: {
                    label()
                }
                .buttonStyle(PressableStyle())
            } else {
                Button { preview = item.url } label: { label() }
                    .buttonStyle(PressableStyle())
            }
        }
        .contextMenu { menu(for: item) }
    }

    private func quickButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.title3).foregroundStyle(brandGradient)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .glass(18, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }

    private var deleteTitle: String {
        guard let d = deleting else { return "" }
        return d.isDirectory ? "Удалить папку «\(d.name)» со всем содержимым?" : "Удалить «\(d.name)»?"
    }

    @ViewBuilder
    private func menu(for item: FileItem) -> some View {
        if !item.isDirectory {
            Button { preview = item.url } label: { Label("Открыть", systemImage: "eye") }
            ShareLink(item: item.url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
        }
        Button {
            renameText = item.isDirectory ? item.name : (item.name as NSString).deletingPathExtension
            renaming = item
        } label: { Label("Переименовать", systemImage: "pencil") }
        Button { moving = item } label: { Label("Переместить", systemImage: "folder") }
        Button {
            withAnimation { selecting = true; selected = [item.url] }
        } label: { Label("Выбрать несколько", systemImage: "checkmark.circle") }
        Divider()
        Button(role: .destructive) { deleting = item } label: { Label("Удалить", systemImage: "trash") }
    }

    // MARK: выбор и удаление

    private var selectionBar: some View {
        let all = visible
        let allOn = !all.isEmpty && all.allSatisfy { selected.contains($0.url) }
        return HStack(spacing: 12) {
            Button {
                Haptics.tap()
                withAnimation { selected = allOn ? [] : Set(all.map(\.url)) }
            } label: {
                Text(allOn ? "Снять всё" : "Выбрать всё").font(.subheadline.weight(.semibold))
            }
            Spacer()
            Text(selected.isEmpty ? "Ничего не выбрано" : "Выбрано: \(selected.count)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Spacer()
            Button(role: .destructive) {
                confirmBulkDelete = true
            } label: {
                Label("Удалить", systemImage: "trash.fill")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(selected.isEmpty ? Color.gray.opacity(0.5) : Color.red, in: Capsule())
            }
            .disabled(selected.isEmpty)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .glass(26)
        .padding(.horizontal, 16)
        .padding(.bottom, 6)
    }

    private var bulkTitle: String {
        let chosen = items.filter { selected.contains($0.url) }
        let folders = chosen.filter(\.isDirectory).count
        let files = chosen.count - folders
        var parts: [String] = []
        if files > 0 { parts.append("файлов: \(files)") }
        if folders > 0 { parts.append("папок: \(folders) (со всем содержимым)") }
        return "Удалить " + parts.joined(separator: ", ") + "?"
    }

    private func deleteSelected() {
        var failed = 0
        for item in items where selected.contains(item.url) {
            do { try FileService.delete(item) } catch { failed += 1 }
        }
        let count = selected.count - failed
        selected = []
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            reload()
            if items.isEmpty { selecting = false }
        }
        if failed > 0 { errorText = "Не удалось удалить: \(failed)" } else { showToast("Удалено: \(count)") }
    }

    // MARK: действия

    /// Список папки читается сразу (это быстро), а тяжёлые обходы всего хранилища
    /// (сводка, недавние) — в фоне, чтобы папка открывалась мгновенно
    private func reload() {
        items = FileService.list(url)
        guard isRoot else { return }
        Task.detached(priority: .userInitiated) {
            let r = FileService.recentFiles()
            let s = FileService.summary()
            await MainActor.run {
                recent = r
                summary = s
            }
        }
    }

    private func perform(_ action: () throws -> Void) {
        do { try action() } catch { errorText = error.localizedDescription }
        reload()
    }

    private func showToast(_ text: String) {
        Haptics.success()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            withAnimation(.easeOut(duration: 0.3)) { toast = nil }
        }
    }

    private func importPhotos(_ selection: [PhotosPickerItem]) {
        isImporting = true
        Task {
            var failed = 0
            for item in selection {
                do {
                    if let data = try await item.loadTransferable(type: Data.self) {
                        let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "jpg"
                        try FileService.save(data, ext: ext, to: url)
                    } else { failed += 1 }
                } catch { failed += 1 }
            }
            await MainActor.run {
                let count = selection.count
                photoItems = []
                isImporting = false
                if failed > 0 { errorText = "Не удалось добавить: \(failed)" } else { showToast("Добавлено: \(count)") }
                reload()
            }
        }
    }
}

// MARK: - Плитка и строка

struct FileTile: View {
    let item: FileItem

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            FileThumb(item: item, size: nil)
                .aspectRatio(1, contentMode: .fit)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2, reservesSpace: true)
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(8)
        .glass(18)
    }

    private var detail: String {
        if item.isDirectory { return "\(item.childCount) шт." }
        return ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)
    }
}

struct FileRow: View {
    let item: FileItem

    var body: some View {
        HStack(spacing: 12) {
            FileThumb(item: item, size: 46)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(details)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            if item.isDirectory {
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(10)
        .glass(18)
    }

    private var details: String {
        let date = item.modified.formatted(date: .abbreviated, time: .omitted)
        if item.isDirectory {
            return "\(item.childCount) шт. · \(date)"
        }
        let size = ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)
        return "\(size) · \(date)"
    }
}

struct FileThumb: View {
    let item: FileItem
    var size: CGFloat? = 44
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            if let image = image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else if item.isDirectory {
                FolderIcon(name: item.name)
                    .padding((size ?? 90) * 0.04)
            } else {
                let tint = FileTint.color(for: item)
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(LinearGradient(colors: [tint.opacity(0.22), tint.opacity(0.10)],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: FileService.icon(for: item))
                    .font(.system(size: (size ?? 90) * 0.4, weight: .semibold))
                    .foregroundStyle(tint.gradient)
                    .shadow(color: tint.opacity(0.35), radius: 4, y: 2)
            }
        }
        .frame(width: size, height: size)
        .frame(maxWidth: size == nil ? .infinity : nil, maxHeight: size == nil ? .infinity : nil)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .task(id: item.url) { await load() }
    }

    private func load() async {
        guard !item.isDirectory else { return }
        // размер в точках, масштаб экрана отдельно (раньше просили в 4 раза больше пикселей, чем нужно)
        let side = size ?? 120
        let key = "\(item.url.path)|\(item.modified.timeIntervalSince1970)|\(Int(side))" as NSString
        if let hit = ThumbCache.shared.object(forKey: key) { image = hit; return }
        let request = QLThumbnailGenerator.Request(fileAt: item.url,
                                                   size: CGSize(width: side, height: side),
                                                   scale: UIScreen.main.scale,
                                                   representationTypes: .thumbnail)
        if let rep = try? await QLThumbnailGenerator.shared.generateBestRepresentation(for: request) {
            ThumbCache.shared.setObject(rep.uiImage, forKey: key)
            image = rep.uiImage
        }
    }
}

// MARK: - Выбор файлов (системный UIKit-пикер — надёжнее, чем fileImporter)

struct DocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // asCopy: файлы сразу копируются к нам, без проблем с доступом
        let vc = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        vc.allowsMultipleSelection = true
        vc.shouldShowFileExtensions = true
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        init(onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onPick([])
        }
    }
}

// MARK: - Сканер документов

struct DocumentScanner: UIViewControllerRepresentable {
    let onFinish: ([UIImage]) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let vc = VNDocumentCameraViewController()
        vc.delegate = context.coordinator
        return vc
    }

    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}

    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let parent: DocumentScanner
        init(_ parent: DocumentScanner) { self.parent = parent }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFinishWith scan: VNDocumentCameraScan) {
            var images: [UIImage] = []
            for i in 0..<scan.pageCount { images.append(scan.imageOfPage(at: i)) }
            parent.onFinish(images)
        }

        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            parent.onCancel()
        }

        func documentCameraViewController(_ controller: VNDocumentCameraViewController,
                                          didFailWithError error: Error) {
            parent.onCancel()
        }
    }
}

enum ScanPDF {
    static func make(_ images: [UIImage]) -> Data {
        let page = CGRect(x: 0, y: 0, width: 595, height: 842)
        let renderer = UIGraphicsPDFRenderer(bounds: page)
        return renderer.pdfData { ctx in
            for img in images {
                ctx.beginPage()
                let s = img.size
                guard s.width > 0, s.height > 0 else { continue }
                let scale = min(page.width / s.width, page.height / s.height)
                let w = s.width * scale, h = s.height * scale
                img.draw(in: CGRect(x: (page.width - w) / 2, y: (page.height - h) / 2, width: w, height: h))
            }
        }
    }
}

// MARK: - Заметка

struct NoteEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var text = ""
    let onSave: (String, String) -> Void

    var body: some View {
        NavigationStack {
            Form {
                TextField("Название", text: $name)
                    .font(.headline)
                TextEditor(text: $text)
                    .frame(minHeight: 260)
            }
            .navigationTitle("Заметка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        onSave(name, text)
                        dismiss()
                    }
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

struct MoveSheet: View {
    let item: FileItem
    let onPick: (URL) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List(FileService.allFolders(excluding: item.isDirectory ? item.url : nil)) { folder in
                let isCurrent = FileService.path(folder.url) ==
                    FileService.path(item.url.deletingLastPathComponent())
                Button {
                    onPick(folder.url)
                    dismiss()
                } label: {
                    HStack(spacing: 10) {
                        Color.clear.frame(width: CGFloat(folder.depth) * 18, height: 1)
                        Image(systemName: folder.depth == 0 ? "house.fill" : "folder.fill")
                            .foregroundStyle(Color.brand)
                        Text(folder.depth == 0 ? "Мои файлы" : folder.url.lastPathComponent)
                            .foregroundStyle(isCurrent ? Color.secondary : Color.primary)
                        if isCurrent {
                            Spacer()
                            Text("сейчас здесь").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .disabled(isCurrent)
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Куда переместить «\(item.name)»")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
            }
        }
    }
}


// MARK: - Цвета файлов по типу

enum FileTint {
    static func color(for item: FileItem) -> Color {
        guard let t = UTType(filenameExtension: item.url.pathExtension.lowercased()) else { return .gray }
        if t.conforms(to: .pdf) { return Color(red: 0.93, green: 0.26, blue: 0.24) }
        if t.conforms(to: .image) { return Color(red: 0.20, green: 0.72, blue: 0.40) }
        if t.conforms(to: .movie) { return Color(red: 0.98, green: 0.55, blue: 0.12) }
        if t.conforms(to: .audio) { return Color(red: 0.93, green: 0.30, blue: 0.62) }
        if t.conforms(to: .presentation) { return Color(red: 0.95, green: 0.45, blue: 0.20) }
        if t.conforms(to: .spreadsheet) { return Color(red: 0.13, green: 0.62, blue: 0.35) }
        if t.conforms(to: .archive) { return Color(red: 0.55, green: 0.45, blue: 0.35) }
        if t.conforms(to: .sourceCode) { return Color(red: 0.45, green: 0.40, blue: 0.95) }
        if t.conforms(to: .text) { return Color(red: 0.25, green: 0.52, blue: 1.0) }
        let ext = item.url.pathExtension.lowercased()
        if ["doc", "docx", "odt", "rtf", "pages"].contains(ext) { return Color(red: 0.20, green: 0.45, blue: 0.95) }
        return Color(red: 0.45, green: 0.50, blue: 0.60)
    }
}

// MARK: - Объёмная папка

/// Папка «как настоящая»: задняя стенка с ушком, выглядывающие листы, передняя крышка с бликом.
/// Цвет стабильно зависит от названия, чтобы разные папки отличались.
struct FolderIcon: View {
    let name: String

    private static let palette: [(Color, Color)] = [
        (Color(red: 0.45, green: 0.72, blue: 1.00), Color(red: 0.18, green: 0.45, blue: 0.96)),  // синий
        (Color(red: 0.42, green: 0.88, blue: 0.72), Color(red: 0.10, green: 0.62, blue: 0.52)),  // мятный
        (Color(red: 1.00, green: 0.74, blue: 0.36), Color(red: 0.96, green: 0.48, blue: 0.14)),  // оранжевый
        (Color(red: 0.72, green: 0.58, blue: 1.00), Color(red: 0.46, green: 0.30, blue: 0.92)),  // фиолетовый
        (Color(red: 1.00, green: 0.56, blue: 0.70), Color(red: 0.90, green: 0.26, blue: 0.46)),  // розовый
        (Color(red: 0.40, green: 0.84, blue: 0.95), Color(red: 0.08, green: 0.58, blue: 0.78))   // бирюзовый
    ]

    private var colors: (Color, Color) {
        let sum = name.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return Self.palette[abs(sum) % Self.palette.count]
    }

    var body: some View {
        GeometryReader { g in
            let s = min(g.size.width, g.size.height)
            let c = colors
            let light = c.0
            let dark = c.1
            ZStack {
                // задняя стенка с ушком
                FolderBackShape()
                    .fill(LinearGradient(colors: [dark.opacity(0.95), dark], startPoint: .top, endPoint: .bottom))
                    .frame(width: s * 0.86, height: s * 0.64)
                    .position(x: s * 0.5, y: s * 0.48)

                // листы внутри
                RoundedRectangle(cornerRadius: s * 0.04, style: .continuous)
                    .fill(Color(white: 0.90))
                    .frame(width: s * 0.62, height: s * 0.42)
                    .rotationEffect(.degrees(-5))
                    .position(x: s * 0.48, y: s * 0.46)
                RoundedRectangle(cornerRadius: s * 0.04, style: .continuous)
                    .fill(Color.white)
                    .overlay(alignment: .top) {
                        VStack(spacing: s * 0.035) {
                            ForEach(0..<3, id: \.self) { i in
                                Capsule().fill(Color.black.opacity(0.10))
                                    .frame(width: s * (i == 2 ? 0.30 : 0.44), height: s * 0.022)
                            }
                        }
                        .padding(.top, s * 0.06)
                    }
                    .frame(width: s * 0.64, height: s * 0.42)
                    .rotationEffect(.degrees(4))
                    .position(x: s * 0.53, y: s * 0.44)
                    .shadow(color: .black.opacity(0.12), radius: s * 0.02, y: s * 0.01)

                // передняя крышка
                RoundedRectangle(cornerRadius: s * 0.09, style: .continuous)
                    .fill(LinearGradient(colors: [light, dark], startPoint: .top, endPoint: .bottom))
                    .overlay {
                        RoundedRectangle(cornerRadius: s * 0.09, style: .continuous)
                            .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.55), Color.white.opacity(0.05)],
                                                         startPoint: .top, endPoint: .bottom),
                                          lineWidth: max(1, s * 0.012))
                    }
                    .overlay(alignment: .top) {
                        Capsule().fill(Color.white.opacity(0.35))
                            .frame(width: s * 0.5, height: s * 0.018)
                            .padding(.top, s * 0.05)
                    }
                    .frame(width: s * 0.86, height: s * 0.46)
                    .position(x: s * 0.5, y: s * 0.59)
                    .shadow(color: dark.opacity(0.45), radius: s * 0.05, y: s * 0.03)
            }
            .frame(width: s, height: s)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .aspectRatio(1, contentMode: .fit)
    }
}

private struct FolderBackShape: Shape {
    func path(in r: CGRect) -> Path {
        let tabW = r.width * 0.42
        let tabH = r.height * 0.16
        let rad = r.width * 0.09
        var p = Path()
        p.addRoundedRect(in: CGRect(x: r.minX, y: r.minY + tabH, width: r.width, height: r.height - tabH),
                         cornerSize: CGSize(width: rad, height: rad), style: .continuous)
        p.addRoundedRect(in: CGRect(x: r.minX, y: r.minY, width: tabW, height: tabH * 2.2),
                         cornerSize: CGSize(width: rad * 0.7, height: rad * 0.7), style: .continuous)
        return p
    }
}
