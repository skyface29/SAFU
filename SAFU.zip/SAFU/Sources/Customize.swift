import SwiftUI

// MARK: - Нижняя панель (вкладки)

enum AppTab: String, CaseIterable, Identifiable {
    case home, schedule, homework, tasks, files, subjects, attendance, developer, profile

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home: return L("Главная")
        case .schedule: return L("Пары")
        case .homework: return L("ДЗ")
        case .tasks: return L("Задачи")
        case .files: return L("Файлы")
        case .subjects: return L("Предметы")
        case .attendance: return L("Посещаемость")
        case .developer: return L("Автор")
        case .profile: return L("Профиль")
        }
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .schedule: return "calendar"
        case .homework: return "book.closed.fill"
        case .tasks: return "checklist"
        case .files: return "folder.fill"
        case .subjects: return "books.vertical.fill"
        case .attendance: return "person.crop.circle.badge.checkmark"
        case .developer: return "chevron.left.forwardslash.chevron.right"
        case .profile: return "person.crop.circle.fill"
        }
    }

    static let defaultRaw = "home,schedule,homework,files,profile"

    /// Раздел ДЗ появился в 14.0 — один раз добавляем его в панель тем, у кого уже настроены вкладки
    static func addHomeworkOnce() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "tabs.homeworkAdded") else { return }
        d.set(true, forKey: "tabs.homeworkAdded")
        guard let raw = d.string(forKey: "tabs.order") else { return }
        var list = parse(raw)
        guard !list.contains(.homework) else { return }
        if let i = list.firstIndex(of: .schedule) { list.insert(.homework, at: i + 1) } else { list.insert(.homework, at: min(1, list.count)) }
        d.set(join(list), forKey: "tabs.order")
    }

    /// Порядок вкладок из настроек. Профиль всегда есть — иначе не попасть в настройки.
    static func parse(_ raw: String) -> [AppTab] {
        var list: [AppTab] = []
        for part in raw.split(separator: ",") {
            if let t = AppTab(rawValue: String(part)), !list.contains(t) { list.append(t) }
        }
        if !list.contains(.profile) { list.append(.profile) }
        return list
    }

    static func join(_ list: [AppTab]) -> String { list.map(\.rawValue).joined(separator: ",") }
}

struct TabsEditor: View {
    @AppStorage("tabs.order") private var raw = AppTab.defaultRaw
    @State private var tabs: [AppTab] = []

    private var hidden: [AppTab] { AppTab.allCases.filter { !tabs.contains($0) } }

    var body: some View {
        List {
            Section {
                ForEach(tabs) { t in
                    Label(t.title, systemImage: t.icon)
                        .deleteDisabled(t == .profile)
                }
                .onMove { from, to in
                    tabs.move(fromOffsets: from, toOffset: to)
                    save()
                }
                .onDelete { idx in
                    tabs.remove(atOffsets: idx)
                    save()
                }
            } header: {
                Text(L("В панели"))
            } footer: {
                Text(L("Перетаскивай за ≡, чтобы поменять порядок, смахни влево, чтобы убрать. Если вкладок больше пяти, лишние уйдут в «Ещё». Профиль убрать нельзя: там настройки."))
            }

            if !hidden.isEmpty {
                Section(L("Можно добавить")) {
                    ForEach(hidden) { t in
                        Button {
                            if let i = tabs.firstIndex(of: .profile) { tabs.insert(t, at: i) } else { tabs.append(t) }
                            save()
                            Haptics.tap()
                        } label: {
                            HStack {
                                Label(t.title, systemImage: t.icon).foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "plus.circle.fill").foregroundStyle(.green)
                            }
                        }
                    }
                }
            }

            Section {
                Button(L("Вернуть как было")) {
                    raw = AppTab.defaultRaw
                    tabs = AppTab.parse(raw)
                }
            }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle(L("Нижняя панель"))
        .onAppear { tabs = AppTab.parse(raw) }
    }

    private func save() {
        if !tabs.contains(.profile) { tabs.append(.profile) }
        raw = AppTab.join(tabs)
    }
}

// MARK: - Главный экран (блоки)

enum HomeSection: String, CaseIterable, Identifiable {
    case now, homework, commute, session, quick, subjects, tools, recents, sites, today, board, tiles, weather, teacher

    var id: String { rawValue }

    var title: String {
        switch self {
        case .now: return L("Сейчас / следующая пара")
        case .homework: return L("Домашка")
        case .commute: return L("Дорога (мой автобус)")
        case .session: return L("Отсчёт до сессии")
        case .quick: return L("Быстрые кнопки")
        case .subjects: return L("Предметы")
        case .tools: return L("Инструменты")
        case .recents: return L("Недавние сайты")
        case .sites: return L("Все сайты")
        case .today: return L("Неделя и дедлайны")
        case .board: return L("Фото доски")
        case .tiles: return L("Мои плитки")
        case .weather: return L("Погода и что надеть")
        case .teacher: return L("Преподавателю")
        }
    }

    var icon: String {
        switch self {
        case .now: return "clock.fill"
        case .homework: return "book.closed.fill"
        case .commute: return "bus.fill"
        case .session: return "graduationcap.fill"
        case .quick: return "circle.grid.2x2.fill"
        case .subjects: return "books.vertical.fill"
        case .tools: return "wrench.and.screwdriver.fill"
        case .recents: return "clock.arrow.circlepath"
        case .sites: return "globe"
        case .today: return "calendar.badge.clock"
        case .board: return "camera.viewfinder"
        case .tiles: return "square.grid.3x2.fill"
        case .weather: return "cloud.sun.fill"
        case .teacher: return "person.crop.rectangle.stack.fill"
        }
    }

    /// Блок «Преподавателю» студенту не показываем вообще
    var available: Bool { self != .teacher || TeacherMode.isOn }

    /// Погода и автобус новичкам не показываем — их добавляют сами в «Настроить главную»
    static let defaultRaw = "now,homework,tools,sites"

    /// Разгрузка главной (один раз): убираем блоки, которые повторяют другие места приложения.
    /// «Недавние» и «Быстрые кнопки» дублируют панель с Sakai и почтой, «Предметы» и «Фото доски» —
    /// инструменты «Предметы» и «Доски». Вернуть любой блок — «Настроить главную»
    static func leanOnce() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "home.lean.v1") else { return }
        d.set(true, forKey: "home.lean.v1")
        guard let raw = d.string(forKey: "home.order") else { return }
        var drop: Set<String> = ["recents", "subjects", "board"]
        // быстрые кнопки убираем, только если они и так живут в панели над вкладками
        if (d.string(forKey: "home.quickPlace") ?? QuickPlace.standard) == "bar" { drop.insert("quick") }
        var list = raw.split(separator: ",").map(String.init).filter { !drop.contains($0) }
        // сайты — в самый низ: это справочник, а не то, что нужно каждое утро
        if let i = list.firstIndex(of: "sites") { list.remove(at: i); list.append("sites") }
        if list.isEmpty { list = defaultRaw.split(separator: ",").map(String.init) }
        d.set(list.joined(separator: ","), forKey: "home.order")
    }

    /// Sakai, почта и другие главные кнопки — на самый верх, чтобы не листать (один раз)
    static func quickFirstOnce() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "home.quickFirst") else { return }
        d.set(true, forKey: "home.quickFirst")
        guard let raw = d.string(forKey: "home.order") else { return }
        var list = raw.split(separator: ",").map(String.init).filter { $0 != "quick" }
        list.insert("quick", at: 0)
        d.set(list.joined(separator: ","), forKey: "home.order")
    }

    /// Старый переключатель «кнопки внизу» → новый выбор места (один раз)
    static func migrateQuickPlace() {
        let d = UserDefaults.standard
        if d.string(forKey: "home.quickPlace") == nil, let old = d.object(forKey: "home.quickDock") as? Bool {
            d.set(old ? QuickPlace.standard : "top", forKey: "home.quickPlace")
        }
        // 15.1: на iOS 26 плавающий док меняем на системную панель над вкладками (один раз)
        if !d.bool(forKey: "home.quickBar.v1") {
            d.set(true, forKey: "home.quickBar.v1")
            if d.string(forKey: "home.quickPlace") == "dock", QuickPlace.barAvailable { d.set("bar", forKey: "home.quickPlace") }
        }
        // 18.4: Sakai, почта и остальные — блоком под «Домашкой» (один раз у всех; переставить можно в «Настроить главную»)
        if !d.bool(forKey: "home.quickHomework.v184") {
            d.set(true, forKey: "home.quickHomework.v184")
            d.set("homework", forKey: "home.quickPlace")
        }
    }

    /// Показать или убрать блок «Домашка» на главной
    static func setHomework(_ on: Bool) {
        let d = UserDefaults.standard
        var list = (d.string(forKey: "home.order") ?? defaultRaw).split(separator: ",").map(String.init)
        list.removeAll { $0 == "homework" }
        if on {
            if let i = list.firstIndex(of: "now") { list.insert("homework", at: i + 1) } else { list.insert("homework", at: 0) }
        }
        d.set(list.joined(separator: ","), forKey: "home.order")
    }

    /// Блок «Домашка» — один раз ставим на главную сразу под карточкой пары
    static func addHomeworkOnce() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "home.homeworkAdded") else { return }
        d.set(true, forKey: "home.homeworkAdded")
        guard let raw = d.string(forKey: "home.order") else { return }
        var list = raw.split(separator: ",").map(String.init)
        guard !list.contains("homework") else { return }
        if let i = list.firstIndex(of: "now") { list.insert("homework", at: i + 1) } else { list.insert("homework", at: 0) }
        d.set(list.joined(separator: ","), forKey: "home.order")
    }

    static func parse(_ raw: String) -> [HomeSection] {
        var list: [HomeSection] = []
        for part in raw.split(separator: ",") {
            if let s = HomeSection(rawValue: String(part)), !list.contains(s), s.available { list.append(s) }
        }
        return list
    }
}

struct HomeEditor: View {
    @EnvironmentObject private var store: ResourceStore
    @AppStorage("home.order") private var raw = HomeSection.defaultRaw
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("home.quickPlace") private var quickPlace = QuickPlace.standard
    @AppStorage("quick.ids") private var quickRaw = ""
    @State private var sections: [HomeSection] = []
    @ObservedObject private var tileStore = TileStore.shared
    @State private var tileDraft: HomeTile?
    @State private var tileIsNew = false

    private var hidden: [HomeSection] { HomeSection.allCases.filter { $0.available && !sections.contains($0) } }
    private var quickIDs: [String] { quickRaw.split(separator: ",").map(String.init) }

    var body: some View {
        List {
            Section {
                Picker(selection: $quickPlace) {
                    if QuickPlace.barAvailable {
                        Text(L("В панели вкладок")).tag("bar")
                    }
                    Text(L("Под домашкой")).tag("homework")
                    Text(L("Закреплены внизу главной")).tag("dock")
                    Text(L("Под погодой и автобусом")).tag("bottom")
                    Text(L("Наверху главной")).tag("top")
                } label: {
                    Label(L("Главные кнопки"), systemImage: "hand.tap.fill")
                }
            } footer: {
                Text(L("Sakai, почта, РУЗ и другие быстрые кнопки. «В панели вкладок» — стеклянная полоса над вкладками на всех экранах: когда вкладки сжимаются при прокрутке, кнопки уезжают вправо. «Под домашкой» и «Под погодой и автобусом» — блоком на главной, прокручиваются вместе с ней."))
            }
            Section {
                ForEach(sections) { s in
                    Label(s.title, systemImage: s.icon)
                }
                .onMove { from, to in
                    sections.move(fromOffsets: from, toOffset: to)
                    raw = sections.map(\.rawValue).joined(separator: ",")
                }
                .onDelete { idx in
                    sections.remove(atOffsets: idx)
                    raw = sections.map(\.rawValue).joined(separator: ",")
                }
            } header: {
                Text(L("На главной"))
            } footer: {
                Text(L("Перетаскивай за ≡ для порядка, смахни влево, чтобы убрать блок."))
            }

            if !hidden.isEmpty {
                Section(L("Можно добавить")) {
                    ForEach(hidden) { s in
                        Button {
                            sections.append(s)
                            raw = sections.map(\.rawValue).joined(separator: ",")
                            Haptics.tap()
                        } label: {
                            HStack {
                                Label(s.title, systemImage: s.icon).foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "plus.circle.fill").foregroundStyle(.green)
                            }
                        }
                    }
                }
            }

            Section {
                ForEach(tileStore.tiles) { t in
                    Button {
                        tileIsNew = false
                        tileDraft = t
                    } label: {
                        HStack {
                            Label(t.title, systemImage: t.icon).foregroundStyle(.primary)
                            Spacer()
                            Circle().fill(t.theme.color).frame(width: 12, height: 12)
                        }
                    }
                }
                .onMove { from, to in tileStore.tiles.move(fromOffsets: from, toOffset: to) }
                .onDelete { idx in tileStore.tiles.remove(atOffsets: idx) }
                Button {
                    tileIsNew = true
                    tileDraft = HomeTile(title: "", icon: "star.fill", color: AccentTheme.current.rawValue, kind: .link, value: "https://")
                } label: {
                    Label(L("Добавить плитку"), systemImage: "plus.circle.fill")
                }
            } header: {
                Text(L("Мои плитки"))
            } footer: {
                Text(L("Сайт, инструмент, предмет, вкладка, камера на доску, фото с пар или стикер. Цвет, значок и размер — любые. На главной удерживай плитку, чтобы изменить."))
            }

            Section {
                ForEach(store.items) { r in
                    Button {
                        toggleQuick(r)
                    } label: {
                        HStack {
                            Label(r.title, systemImage: r.icon).foregroundStyle(.primary)
                            Spacer()
                            if quickIDs.contains(r.id.uuidString) || (quickIDs.isEmpty && store.quick.contains(r)) {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.brand)
                            }
                        }
                    }
                }
            } header: {
                Text(L("Быстрые кнопки (до 5)"))
            } footer: {
                Text(L("Отметь сайты, которые должны быть круглыми кнопками сверху."))
            }

            Section(L("Плитки сайтов")) {
                Picker(L("В ряд"), selection: $columnsCount) {
                    Text("2").tag(2)
                    Text("3").tag(3)
                }
                .pickerStyle(.segmented)
            }

            Section {
                Button(L("Вернуть как было")) {
                    raw = HomeSection.defaultRaw
                    quickRaw = ""
                    sections = HomeSection.parse(raw)
                }
            }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle(L("Главный экран"))
        .onAppear { sections = HomeSection.parse(raw) }
        .onChange(of: raw) { v in sections = HomeSection.parse(v) }
        .sheet(item: $tileDraft) { t in
            NavigationStack { TileEditor(tile: t, isNew: tileIsNew) }
        }
    }

    private func toggleQuick(_ r: Resource) {
        var ids = quickIDs.isEmpty ? store.quick.map { $0.id.uuidString } : quickIDs
        if let i = ids.firstIndex(of: r.id.uuidString) {
            ids.remove(at: i)
        } else if ids.count < 5 {
            ids.append(r.id.uuidString)
        }
        quickRaw = ids.joined(separator: ",")
        Haptics.tap()
    }
}




/// Где стоят главные кнопки (Sakai, почта…)
enum QuickPlace {
    /// Системная панель над вкладками есть с iOS 26
    static var barAvailable: Bool {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) { return true }
        #endif
        return false
    }

    /// По умолчанию — блоком прямо под «Домашкой»: стоит на месте и прокручивается вместе с главной
    static var standard: String { "homework" }
}
