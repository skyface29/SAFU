import SwiftUI

// MARK: - Нижняя панель (вкладки)

enum AppTab: String, CaseIterable, Identifiable {
    case home, schedule, tasks, files, subjects, attendance, profile

    var id: String { rawValue }

    var title: String {
        switch self {
        case .home: return "Главная"
        case .schedule: return "Пары"
        case .tasks: return "Задачи"
        case .files: return "Файлы"
        case .subjects: return "Предметы"
        case .attendance: return "Посещаемость"
        case .profile: return "Профиль"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .schedule: return "calendar"
        case .tasks: return "checklist"
        case .files: return "folder.fill"
        case .subjects: return "books.vertical.fill"
        case .attendance: return "person.crop.circle.badge.checkmark"
        case .profile: return "person.crop.circle.fill"
        }
    }

    static let defaultRaw = "home,schedule,tasks,files,profile"

    /// Порядок вкладок из настроек. Профиль всегда есть — иначе не попасть в настройки.
    static func parse(_ raw: String) -> [AppTab] {
        var list: [AppTab] = []
        for part in raw.split(separator: ",") {
            if let t = AppTab(rawValue: String(part)), !list.contains(t) { list.append(t) }
        }
        if !list.contains(.profile) { list.append(.profile) }
        return list
    }

    static func join(_ list: [AppTab]) -> String { list.map(\.rawValue).joined(separator: ",") }
}

struct TabsEditor: View {
    @AppStorage("tabs.order") private var raw = AppTab.defaultRaw
    @State private var tabs: [AppTab] = []

    private var hidden: [AppTab] { AppTab.allCases.filter { !tabs.contains($0) } }

    var body: some View {
        List {
            Section {
                ForEach(tabs) { t in
                    Label(t.title, systemImage: t.icon)
                        .deleteDisabled(t == .profile)
                }
                .onMove { from, to in
                    tabs.move(fromOffsets: from, toOffset: to)
                    save()
                }
                .onDelete { idx in
                    tabs.remove(atOffsets: idx)
                    save()
                }
            } header: {
                Text("В панели")
            } footer: {
                Text("Перетаскивай за ≡, чтобы поменять порядок, смахни влево, чтобы убрать. Если вкладок больше пяти, лишние уйдут в «Ещё». Профиль убрать нельзя: там настройки.")
            }

            if !hidden.isEmpty {
                Section("Можно добавить") {
                    ForEach(hidden) { t in
                        Button {
                            if let i = tabs.firstIndex(of: .profile) { tabs.insert(t, at: i) } else { tabs.append(t) }
                            save()
                            Haptics.tap()
                        } label: {
                            HStack {
                                Label(t.title, systemImage: t.icon).foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "plus.circle.fill").foregroundStyle(.green)
                            }
                        }
                    }
                }
            }

            Section {
                Button("Вернуть как было") {
                    raw = AppTab.defaultRaw
                    tabs = AppTab.parse(raw)
                }
            }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle("Нижняя панель")
        .onAppear { tabs = AppTab.parse(raw) }
    }

    private func save() {
        if !tabs.contains(.profile) { tabs.append(.profile) }
        raw = AppTab.join(tabs)
    }
}

// MARK: - Главный экран (блоки)

enum HomeSection: String, CaseIterable, Identifiable {
    case now, quick, subjects, tools, recents, sites, today

    var id: String { rawValue }

    var title: String {
        switch self {
        case .now: return "Сейчас / следующая пара"
        case .quick: return "Быстрые кнопки"
        case .subjects: return "Предметы"
        case .tools: return "Инструменты"
        case .recents: return "Недавние сайты"
        case .sites: return "Все сайты"
        case .today: return "Неделя и дедлайны"
        }
    }

    var icon: String {
        switch self {
        case .now: return "clock.fill"
        case .quick: return "circle.grid.2x2.fill"
        case .subjects: return "books.vertical.fill"
        case .tools: return "wrench.and.screwdriver.fill"
        case .recents: return "clock.arrow.circlepath"
        case .sites: return "globe"
        case .today: return "calendar.badge.clock"
        }
    }

    static let defaultRaw = "now,quick,subjects,tools,recents,sites"

    static func parse(_ raw: String) -> [HomeSection] {
        var list: [HomeSection] = []
        for part in raw.split(separator: ",") {
            if let s = HomeSection(rawValue: String(part)), !list.contains(s) { list.append(s) }
        }
        return list
    }
}

struct HomeEditor: View {
    @EnvironmentObject private var store: ResourceStore
    @AppStorage("home.order") private var raw = HomeSection.defaultRaw
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("quick.ids") private var quickRaw = ""
    @State private var sections: [HomeSection] = []

    private var hidden: [HomeSection] { HomeSection.allCases.filter { !sections.contains($0) } }
    private var quickIDs: [String] { quickRaw.split(separator: ",").map(String.init) }

    var body: some View {
        List {
            Section {
                ForEach(sections) { s in
                    Label(s.title, systemImage: s.icon)
                }
                .onMove { from, to in
                    sections.move(fromOffsets: from, toOffset: to)
                    raw = sections.map(\.rawValue).joined(separator: ",")
                }
                .onDelete { idx in
                    sections.remove(atOffsets: idx)
                    raw = sections.map(\.rawValue).joined(separator: ",")
                }
            } header: {
                Text("На главной")
            } footer: {
                Text("Перетаскивай за ≡ для порядка, смахни влево, чтобы убрать блок.")
            }

            if !hidden.isEmpty {
                Section("Можно добавить") {
                    ForEach(hidden) { s in
                        Button {
                            sections.append(s)
                            raw = sections.map(\.rawValue).joined(separator: ",")
                            Haptics.tap()
                        } label: {
                            HStack {
                                Label(s.title, systemImage: s.icon).foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "plus.circle.fill").foregroundStyle(.green)
                            }
                        }
                    }
                }
            }

            Section {
                ForEach(store.items) { r in
                    Button {
                        toggleQuick(r)
                    } label: {
                        HStack {
                            Label(r.title, systemImage: r.icon).foregroundStyle(.primary)
                            Spacer()
                            if quickIDs.contains(r.id.uuidString) || (quickIDs.isEmpty && store.quick.contains(r)) {
                                Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.brand)
                            }
                        }
                    }
                }
            } header: {
                Text("Быстрые кнопки (до 5)")
            } footer: {
                Text("Отметь сайты, которые должны быть круглыми кнопками сверху.")
            }

            Section("Плитки сайтов") {
                Picker("В ряд", selection: $columnsCount) {
                    Text("2").tag(2)
                    Text("3").tag(3)
                }
                .pickerStyle(.segmented)
            }

            Section {
                Button("Вернуть как было") {
                    raw = HomeSection.defaultRaw
                    quickRaw = ""
                    sections = HomeSection.parse(raw)
                }
            }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle("Главный экран")
        .onAppear { sections = HomeSection.parse(raw) }
    }

    private func toggleQuick(_ r: Resource) {
        var ids = quickIDs.isEmpty ? store.quick.map { $0.id.uuidString } : quickIDs
        if let i = ids.firstIndex(of: r.id.uuidString) {
            ids.remove(at: i)
        } else if ids.count < 5 {
            ids.append(r.id.uuidString)
        }
        quickRaw = ids.joined(separator: ",")
        Haptics.tap()
    }
}
