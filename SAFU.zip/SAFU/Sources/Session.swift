import SwiftUI

// MARK: - Режим сессии
// Экзамены и зачёты из РУЗ + добавленные вручную, обратный отсчёт, билеты «знаю / повторить»,
// итоги. Включается сам за N дней до первого экзамена (или вручную).

struct SessionExam: Identifiable, Hashable, Codable {
    var id: String
    var subject: String
    var kind: String
    var start: Date
    var room: String = ""
    var address: String = ""
    var manual: Bool = false

    var isConsult: Bool { kind.lowercased().contains("консульт") }
    var daysLeft: Int {
        let cal = Calendar.current
        return cal.dateComponents([.day], from: cal.startOfDay(for: Date()), to: cal.startOfDay(for: start)).day ?? 0
    }
}

struct TicketSet: Codable, Hashable {
    var total: Int = 30
    /// номер билета → 1 «повторить», 2 «знаю»
    var states: [Int: Int] = [:]
    var learned: Int { states.values.filter { $0 == 2 }.count }
    var shaky: Int { states.values.filter { $0 == 1 }.count }
    var ratio: Double { total > 0 ? Double(learned) / Double(total) : 0 }
}

final class SessionStore: ObservableObject {
    static let shared = SessionStore()

    @Published var manual: [SessionExam] = [] { didSet { save() } }
    @Published var tickets: [String: TicketSet] = [:] { didSet { save() } }
    @Published var results: [String: String] = [:] { didSet { save() } }

    private let key = "session.v1"
    private struct Blob: Codable {
        var manual: [SessionExam] = []
        var tickets: [String: TicketSet] = [:]
        var results: [String: String] = [:]
    }
    private var loading = true

    private init() {
        if let raw = UserDefaults.standard.data(forKey: key), let b = try? JSONDecoder().decode(Blob.self, from: raw) {
            manual = b.manual; tickets = b.tickets; results = b.results
        }
        loading = false
    }

    private func save() {
        guard !loading else { return }
        let b = Blob(manual: manual, tickets: tickets, results: results)
        if let raw = try? JSONEncoder().encode(b) { UserDefaults.standard.set(raw, forKey: key) }
    }

    func ticketSet(_ subject: String) -> TicketSet { tickets[subject] ?? TicketSet() }

    func cycle(_ n: Int, subject: String) {
        var t = ticketSet(subject)
        let v = ((t.states[n] ?? 0) + 1) % 3
        if v == 0 { t.states[n] = nil } else { t.states[n] = v }
        tickets[subject] = t
    }
}

enum SessionMode {
    /// 0 — сам, 1 — всегда, 2 — выключен
    static var mode: Int { UserDefaults.standard.object(forKey: "session.mode") as? Int ?? 0 }
    static var window: Int { UserDefaults.standard.object(forKey: "session.window") as? Int ?? 21 }

    static func isExamKind(_ k: String) -> Bool {
        let l = k.lowercased()
        return l.contains("экзам") || l.contains("зач") || l.contains("консульт") || l.contains("курсов")
    }

    /// Все экзамены: из РУЗ (на 150 дней вперёд) + свои
    static func exams(_ data: ScheduleData, includePast: Bool = false) -> [SessionExam] {
        var list = ScheduleQuery.slots(data, from: includePast ? -30 : 0, days: includePast ? 180 : 150)
            .filter { isExamKind($0.lesson.kind) }
            .map { s in
                SessionExam(id: "ruz-\(Int(s.start.timeIntervalSince1970))-\(s.lesson.subject)",
                            subject: s.lesson.subject, kind: KindStyle.of(s.lesson.kind).label,
                            start: s.start, room: s.lesson.room, address: s.address)
            }
        list += SessionStore.shared.manual
        let now = Date()
        if !includePast { list = list.filter { $0.start.addingTimeInterval(4 * 3600) > now } }
        return list.sorted { $0.start < $1.start }
    }

    static func isActive(_ data: ScheduleData) -> Bool {
        switch mode {
        case 1: return true
        case 2: return false
        default:
            guard let first = exams(data).first(where: { !$0.isConsult }) else { return false }
            return first.daysLeft <= window
        }
    }
}

// MARK: - Экран сессии

struct SessionView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = SessionStore.shared
    @AppStorage("session.mode") private var mode = 0
    @AppStorage("session.window") private var window = 21
    @State private var open: SessionExam?
    @State private var adding = false

    private var exams: [SessionExam] { SessionMode.exams(schedule.data) }
    private var mainExams: [SessionExam] { exams.filter { !$0.isConsult } }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let next = mainExams.first {
                    hero(next)
                } else {
                    EmptyState(icon: "graduationcap", title: "Экзаменов пока нет",
                               text: "Как только их выложат в РУЗ, они появятся здесь. Можно добавить свой экзамен кнопкой «+».")
                }
                if !mainExams.isEmpty { overall }
                ForEach(Array(exams.enumerated()), id: \.element.id) { i, e in
                    Button { Haptics.tap(); open = e } label: { row(e) }
                        .buttonStyle(PressableStyle())
                        .staggerIn(i)
                }
                settings
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Сессия")
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { adding = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(item: $open) { e in
            NavigationStack { ExamDetailView(exam: e) }
        }
        .sheet(isPresented: $adding) {
            NavigationStack { AddExamView() }.environmentObject(schedule)
        }
    }

    private func hero(_ e: SessionExam) -> some View {
        let d = e.daysLeft
        return VStack(alignment: .leading, spacing: 8) {
            Text("БЛИЖАЙШИЙ \(e.kind.uppercased())")
                .font(.caption.weight(.heavy))
                .foregroundStyle(.secondary)
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(d <= 0 ? "Сегодня" : "\(d)")
                    .font(.system(size: d <= 0 ? 40 : 64, weight: .heavy, design: .rounded))
                    .foregroundStyle(brandGradient)
                    .contentTransition(.numericText())
                if d > 0 {
                    Text(daysWord(d)).font(.title3.weight(.bold)).foregroundStyle(.secondary)
                }
            }
            Text(e.subject).font(.system(.title3, design: .rounded).weight(.bold))
            Text(e.start.formatted(.dateTime.weekday(.wide).day().month(.wide).hour().minute())
                 + (e.room.isEmpty ? "" : " · ауд. \(e.room)"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
            let t = store.ticketSet(e.subject)
            if !t.states.isEmpty {
                ProgressView(value: t.ratio).tint(.green)
                Text("Билеты: знаю \(t.learned) из \(t.total)" + (t.shaky > 0 ? " · повторить \(t.shaky)" : ""))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(26)
    }

    private var overall: some View {
        let all = SessionMode.exams(schedule.data, includePast: true).filter { !$0.isConsult }
        let done = all.filter { store.results[$0.id] != nil && store.results[$0.id] != "пересдача" }.count
        let last = all.last
        return HStack(spacing: 12) {
            stat("\(done)/\(all.count)", "сдано")
            stat(last.map { "\(Swift.max(0, $0.daysLeft))" } ?? "—", "дн. до конца")
            stat("\(all.filter { store.ticketSet($0.subject).ratio >= 0.8 }.count)", "готов на 80%+")
        }
    }

    private func stat(_ v: String, _ t: String) -> some View {
        VStack(spacing: 2) {
            Text(v).font(.system(size: 22, weight: .heavy, design: .rounded)).foregroundStyle(brandGradient)
            Text(t).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .glass(18)
    }

    private func row(_ e: SessionExam) -> some View {
        let d = e.daysLeft
        let t = store.ticketSet(e.subject)
        let res = store.results[e.id]
        return HStack(spacing: 14) {
            VStack(spacing: 0) {
                Text(d <= 0 ? "!" : "\(d)")
                    .font(.system(.title2, design: .rounded).weight(.heavy))
                Text(d <= 0 ? "сегодня" : "дн.").font(.caption2).foregroundStyle(.secondary)
            }
            .frame(width: 56, height: 56)
            .background(SubjectColor.color(for: e.subject).opacity(0.18), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(e.kind.uppercased())
                        .font(.caption2.weight(.heavy))
                        .foregroundStyle(e.isConsult ? Color.secondary : Color.brand)
                    if e.manual { Image(systemName: "pencil").font(.caption2).foregroundStyle(.secondary) }
                    if let res {
                        Text(res).font(.caption2.weight(.heavy)).foregroundStyle(.white)
                            .padding(.horizontal, 6).padding(.vertical, 1)
                            .background(res == "пересдача" ? Color.orange : Color.green, in: Capsule())
                    }
                }
                Text(e.subject).font(.subheadline.weight(.bold)).foregroundStyle(.primary).lineLimit(2)
                    .multilineTextAlignment(.leading)
                Text(e.start.formatted(.dateTime.day().month().hour().minute()) + (e.room.isEmpty ? "" : " · ауд. \(e.room)"))
                    .font(.caption).foregroundStyle(.secondary)
                if !e.isConsult && !t.states.isEmpty {
                    ProgressView(value: t.ratio).tint(.green)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .glass(20)
    }

    private var settings: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("Режим сессии", selection: $mode) {
                Text("Сам").tag(0)
                Text("Включён").tag(1)
                Text("Выключен").tag(2)
            }
            .pickerStyle(.segmented)
            if mode == 0 {
                Stepper("Включать за \(window) дн. до экзамена", value: $window, in: 3...60, step: 1)
                    .font(.subheadline)
            }
            Text("В режиме сессии блок «Сессия» поднимается наверх главной и показывает билеты.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .glass(20)
    }

    private func daysWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "день" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "дня" }
        return "дней"
    }
}

// MARK: - Экзамен: билеты и итог

struct ExamDetailView: View {
    let exam: SessionExam
    @ObservedObject private var store = SessionStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var random: Int?

    private var set: TicketSet { store.ticketSet(exam.subject) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(exam.kind.uppercased()).font(.caption.weight(.heavy)).foregroundStyle(Color.brand)
                    Text(exam.subject).font(.system(.title2, design: .rounded).weight(.bold))
                    Text(exam.start.formatted(.dateTime.weekday(.wide).day().month(.wide).hour().minute()))
                        .foregroundStyle(.secondary)
                    if !exam.room.isEmpty || !exam.address.isEmpty {
                        Text([exam.room.isEmpty ? "" : "ауд. \(exam.room)", AddressFormat.full(exam.address)]
                                .filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }

                if !exam.isConsult {
                    tickets
                    result
                }

                if exam.manual {
                    Button("Удалить экзамен", role: .destructive) {
                        store.manual.removeAll { $0.id == exam.id }
                        dismiss()
                    }
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() }.fontWeight(.semibold) }
        }
        .alert("Твой билет", isPresented: Binding(get: { random != nil }, set: { if !$0 { random = nil } })) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text("№ \(random ?? 0) — удачи!")
        }
    }

    private var tickets: some View {
        let s = set
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Билеты").font(.system(.headline, design: .rounded))
                Spacer()
                Text("знаю \(s.learned) · повторить \(s.shaky)")
                    .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            }
            ProgressView(value: s.ratio).tint(.green)
            Stepper("Всего: \(s.total)", value: Binding(get: { set.total }, set: { v in
                var t = set; t.total = v; t.states = t.states.filter { $0.key <= v }; store.tickets[exam.subject] = t
            }), in: 1...150)
            .font(.subheadline)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 44), spacing: 8)], spacing: 8) {
                ForEach(1...Swift.max(1, s.total), id: \.self) { n in
                    let st = s.states[n] ?? 0
                    Button {
                        Haptics.tap()
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.7)) { store.cycle(n, subject: exam.subject) }
                    } label: {
                        Text("\(n)")
                            .font(.system(.subheadline, design: .rounded).weight(.bold))
                            .frame(maxWidth: .infinity, minHeight: 40)
                            .foregroundStyle(st == 0 ? Color.primary : Color.white)
                            .background(st == 2 ? Color.green : (st == 1 ? Color.orange : Color.primary.opacity(0.07)),
                                        in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
            Text("Тап: серый → оранжевый «повторить» → зелёный «знаю» → снова серый.")
                .font(.caption2).foregroundStyle(.secondary)
            Button {
                let pool = (1...Swift.max(1, s.total)).filter { (s.states[$0] ?? 0) != 2 }
                random = (pool.isEmpty ? Array(1...Swift.max(1, s.total)) : pool).randomElement()
                Haptics.success()
            } label: {
                Label("Вытянуть билет (из невыученных)", systemImage: "dice.fill")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PressableStyle())
        }
        .padding(16)
        .glass(22)
    }

    private var result: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Итог").font(.system(.headline, design: .rounded))
            HStack(spacing: 8) {
                ForEach(["5", "4", "3", "зачёт", "пересдача"], id: \.self) { r in
                    let on = store.results[exam.id] == r
                    Button {
                        Haptics.tap()
                        if on {
                            store.results[exam.id] = nil
                        } else {
                            store.results[exam.id] = r
                            if r != "пересдача" { Celebrations.examPassed(subject: exam.subject, grade: r) }
                        }
                    } label: {
                        Text(r)
                            .font(.caption.weight(.bold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.7)
                            .frame(maxWidth: .infinity, minHeight: 34)
                            .foregroundStyle(on ? Color.white : Color.primary)
                            .background(on ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.07)),
                                        in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .padding(16)
        .glass(22)
    }
}

// MARK: - Свой экзамен

struct AddExamView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = SessionStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var subject = ""
    @State private var kind = "Экзамен"
    @State private var date = Calendar.current.date(byAdding: .day, value: 14, to: Date()) ?? Date()
    @State private var room = ""

    var body: some View {
        Form {
            Section("Предмет") {
                TextField("Название", text: $subject)
                let subjects = ScheduleQuery.subjects(schedule.data)
                if !subjects.isEmpty {
                    Menu("Выбрать из расписания") {
                        ForEach(subjects, id: \.self) { s in Button(s) { subject = s } }
                    }
                }
            }
            Section {
                Picker("Тип", selection: $kind) {
                    ForEach(["Экзамен", "Зачёт", "Консультация", "Курсовая"], id: \.self) { Text($0).tag($0) }
                }
                DatePicker("Когда", selection: $date)
                TextField("Аудитория", text: $room)
            }
        }
        .navigationTitle("Свой экзамен")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Добавить") {
                    store.manual.append(SessionExam(id: "man-\(UUID().uuidString)", subject: subject.trimmingCharacters(in: .whitespaces),
                                                    kind: kind, start: date, room: room, manual: true))
                    Haptics.success()
                    dismiss()
                }
                .fontWeight(.semibold)
                .disabled(subject.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
}

// MARK: - Карточка на главной

struct SessionCard: View {
    let data: ScheduleData
    @ObservedObject private var store = SessionStore.shared
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var show = false

    var body: some View {
        let exams = SessionMode.exams(data).filter { !$0.isConsult }
        if let e = exams.first {
            let d = e.daysLeft
            let t = store.ticketSet(e.subject)
            let active = SessionMode.isActive(data)
            Button { Haptics.tap(); show = true } label: {
                VStack(alignment: .leading, spacing: 10) {
                    if active {
                        HStack(spacing: 6) {
                            Image(systemName: "graduationcap.fill")
                            Text("РЕЖИМ СЕССИИ")
                            Spacer()
                            Text("\(exams.count) впереди").foregroundStyle(.secondary)
                        }
                        .font(.caption.weight(.heavy))
                        .foregroundStyle(Color.brand)
                    }
                    HStack(spacing: 14) {
                        VStack(spacing: 0) {
                            Text(d <= 0 ? "!" : "\(d)")
                                .font(.system(size: 30, weight: .heavy, design: .rounded))
                                .foregroundStyle(brandGradient)
                            Text(d <= 0 ? "сегодня" : "дн.").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
                        }
                        .frame(width: 64)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(e.kind.uppercased())
                                .font(.caption2.weight(.heavy))
                                .foregroundStyle(KindStyle.of(e.kind).color)
                            Text(e.subject)
                                .font(.system(.headline, design: .rounded))
                                .foregroundStyle(.primary)
                                .lineLimit(2)
                                .multilineTextAlignment(.leading)
                            Text(e.start.formatted(.dateTime.day().month(.wide).hour().minute()) +
                                 (e.room.isEmpty ? "" : " · ауд. \(e.room)"))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        if active && !t.states.isEmpty {
                            ProgressRing(value: t.ratio, color: .green, lineWidth: 4) {
                                Text("\(Int(t.ratio * 100))%").font(.system(size: 10, weight: .heavy, design: .rounded))
                            }
                            .frame(width: 40, height: 40)
                        }
                    }
                }
                .padding(16)
                .glass(24)
            }
            .buttonStyle(PressableStyle())
            .sheet(isPresented: $show) {
                NavigationStack {
                    SessionView()
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) { Button("Готово") { show = false }.fontWeight(.semibold) }
                        }
                }
                .environmentObject(schedule)
            }
        }
    }
}
