import Foundation
import WebKit
import UIKit

// MARK: - Автоматическая БРС
// Баллы подтягиваются сами, из двух мест, где у студента уже есть вход в приложении:
// 1) Sakai — журнал оценок (gradebook) каждого курса через стандартный API Sakai;
// 2) Личный кабинет lk.narfu.ru — страница открывается невидимо, приложение читает таблицы
//    и ответы сервера и ищет строки с названиями твоих предметов и баллами.
// Названия курсов сопоставляются с предметами из расписания автоматически.

struct FoundGrade: Hashable {
    let subject: String      // как называется на сайте
    let item: String         // за что (лаба, тест, итог)
    let points: Double
    let outOf: Double
    let source: String       // "Sakai" / "ЛК"
}

enum GradeSync {
    enum Failure: LocalizedError {
        case notLoggedIn(String)
        var errorDescription: String? {
            switch self {
            case .notLoggedIn(let s): return "Нет входа в \(s). Открой \(s) на главной, войди один раз — дальше всё само."
            }
        }
    }

    static var auto: Bool { UserDefaults.standard.object(forKey: "brs.auto") as? Bool ?? true }
    static var lastRun: Date? {
        let v = UserDefaults.standard.double(forKey: "brs.last")
        return v == 0 ? nil : Date(timeIntervalSinceReferenceDate: v)
    }

    /// Отчёт последней синхронизации — чтобы можно было скинуть разработчику
    static var report: String {
        get { UserDefaults.standard.string(forKey: "brs.report") ?? "" }
        set { UserDefaults.standard.set(String(newValue.prefix(20_000)), forKey: "brs.report") }
    }

    // MARK: запуск

    @MainActor
    static func run(subjects: [String]) async -> String {
        var found: [FoundGrade] = []
        var notes: [String] = []
        var log = "БРС \(Date().formatted())\n"

        do {
            let s = try await sakai()
            found += s
            notes.append("Sakai: \(s.count)")
            log += "Sakai: вход есть, оценок найдено \(s.count)\n" + sakaiLog
        } catch {
            notes.append("Sakai: нет входа")
            log += "Sakai: \(error.localizedDescription)\n"
        }

        let lk = await PersonalCabinet.shared.scrape()
        UserDefaults.standard.set(lk.loggedIn, forKey: "brs.lk.ok")
        found += lk.grades
        log += lk.log
        notes.append(lk.loggedIn ? "ЛК: \(lk.grades.count)" : "ЛК: нет входа")

        let applied = GradesStore.shared.apply(found, subjects: subjects)
        log += "\nСопоставлено: \(applied.matched), не нашлось предмета: \(applied.unmatched.count)\n"
        for u in applied.unmatched.prefix(40) { log += "  ? \(u)\n" }
        report = log
        UserDefaults.standard.set(Date().timeIntervalSinceReferenceDate, forKey: "brs.last")

        if found.isEmpty {
            return "Баллов не нашлось (\(notes.joined(separator: ", "))). Войди через кнопки «Войти» выше."
        }
        return "Обновлено: \(applied.matched) \(applied.matched == 1 ? "предмет" : "предметов") · " + notes.joined(separator: ", ")
    }

    /// Тихо, не чаще раза в 3 часа
    @MainActor
    static func autoRun(subjects: [String]) async {
        guard auto else { return }
        if let l = lastRun, Date().timeIntervalSince(l) < 3 * 3600 { return }
        _ = await run(subjects: subjects)
    }

    // MARK: Sakai

    private static let sakaiBase = "https://sakai.narfu.ru"

    private static func sakaiHeaders() async -> [String: String] {
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            DispatchQueue.main.async {
                SessionKeeper.restore(into: WKWebsiteDataStore.default().httpCookieStore) { cont.resume() }
            }
        }
        return await withCheckedContinuation { (cont: CheckedContinuation<[String: String], Never>) in
            DispatchQueue.main.async {
                WKWebsiteDataStore.default().httpCookieStore.getAllCookies { cookies in
                    let host = "sakai.narfu.ru"
                    let mine = cookies.filter {
                        let d = $0.domain.trimmingCharacters(in: CharacterSet(charactersIn: "."))
                        return host == d || host.hasSuffix("." + d)
                    }
                    cont.resume(returning: HTTPCookie.requestHeaderFields(with: mine))
                }
            }
        }
    }

    private static func json(_ path: String, _ headers: [String: String]) async -> Any? {
        guard let url = URL(string: sakaiBase + path) else { return nil }
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        // куки подставляем сами (из браузера приложения) — системные не должны их перетирать
        req.httpShouldHandleCookies = false
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        guard let pair = try? await URLSession.shared.data(for: req),
              (pair.1 as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return try? JSONSerialization.jsonObject(with: pair.0)
    }

    /// JSON с Sakai: сначала через невидимый браузер (ровно та сессия, в которой ты входил),
    /// если не вышло — прямым запросом с куками
    private static func sakaiJSON(_ path: String, _ headers: [String: String]) async -> Any? {
        if let v = await SakaiWeb.shared.json(path) { return v }
        guard !headers.isEmpty else { return nil }
        return await json(path, headers)
    }

    /// Логин, под которым открыт Sakai, или nil, если входа нет
    static func sakaiUser() async -> String? {
        defer { Task { @MainActor in SakaiWeb.shared.release() } }
        let headers = await sakaiHeaders()
        guard let s = await sakaiJSON("/direct/session/current.json", headers) as? [String: Any] else { return nil }
        for k in ["userEid", "userDisplayId", "userId"] {
            if let v = s[k] as? String, !v.isEmpty { return v }
        }
        return nil
    }

    /// Личный кабинет открылся без запроса пароля при последней проверке
    static var lkLoggedIn: Bool { UserDefaults.standard.bool(forKey: "brs.lk.ok") }

    /// Подробности последней проверки Sakai — для отчёта «Что нашлось»
    private(set) static var sakaiLog = ""

    static func sakai() async throws -> [FoundGrade] {
        defer { Task { @MainActor in SakaiWeb.shared.release() } }
        let headers = await sakaiHeaders()
        guard let sites = await sakaiJSON("/direct/site.json?_limit=200", headers) as? [String: Any],
              let list = sites["site_collection"] as? [[String: Any]] else { throw Failure.notLoggedIn("Sakai") }

        var lines: [String] = ["  курсов в Sakai: \(list.count)"]
        var out: [FoundGrade] = []
        await withTaskGroup(of: (String, [FoundGrade]).self) { group in
            for site in list.prefix(30) {
                guard let id = site["id"] as? String, !id.hasPrefix("~") else { continue }
                let title = (site["title"] as? String) ?? id
                group.addTask {
                    // 1) API журнала оценок
                    if let gb = await sakaiJSON("/direct/gradebook/site/\(id).json", headers) {
                        let g = JSONGrades.extract(gb, subject: title, source: "Sakai")
                        if !g.isEmpty { return ("  • \(title): журнал API — \(g.count)", g) }
                    }
                    // 2) страница инструмента «Оценки» в курсе — читаем таблицу
                    let page = await SakaiWeb.shared.gradebookRows(siteID: id)
                    let g = SakaiTable.extract(page.rows, subject: title)
                    return ("  • \(title): \(page.note), найдено \(g.count)", g)
                }
            }
            for await (line, part) in group {
                lines.append(line)
                out += part
            }
        }
        sakaiLog = lines.prefix(40).joined(separator: "\n") + "\n"
        return out
    }
}

// MARK: - Sakai через невидимый браузер
// Запросы идут изнутри страницы sakai.narfu.ru — с теми же куками и сессией, что при входе.

@MainActor
final class SakaiWeb: NSObject, WKNavigationDelegate {
    static let shared = SakaiWeb()
    private static let base = "https://sakai.narfu.ru"

    private var web: WKWebView?
    private var ready = false
    private var finished: CheckedContinuation<Void, Never>?
    private var loadID = 0
    private var users = 0
    private var preparing: Task<WKWebView?, Never>?

    /// Один браузер на все параллельные запросы
    private func prepare() async -> WKWebView? {
        if let w = web, ready { return w }
        if let p = preparing { return await p.value }
        let t = Task { await self.makeWeb() }
        preparing = t
        let w = await t.value
        preparing = nil
        return w
    }

    private func makeWeb() async -> WKWebView? {
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            SessionKeeper.restore(into: WKWebsiteDataStore.default().httpCookieStore) { c.resume() }
        }
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 390, height: 800), configuration: config)
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1"
        wv.navigationDelegate = self
        web = wv
        guard let url = URL(string: Self.base + "/direct/session/current.json") else { return nil }
        loadID += 1
        let id = loadID
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            finished = c
            wv.load(URLRequest(url: url, timeoutInterval: 20))
            DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
                if self?.loadID == id { self?.finish() }
            }
        }
        // страница должна остаться на sakai.narfu.ru, иначе запросы не пройдут
        guard wv.url?.host?.contains("sakai.narfu.ru") == true else {
            web = nil
            return nil
        }
        ready = true
        return wv
    }

    func json(_ path: String) async -> Any? {
        users += 1
        defer { users -= 1 }
        guard let wv = await prepare() else { return nil }
        let js = """
        try {
          const ctl = new AbortController();
          setTimeout(() => ctl.abort(), 20000);
          const r = await fetch(url, { credentials: 'include', headers: { 'Accept': 'application/json' }, signal: ctl.signal });
          if (!r.ok) return null;
          return await r.text();
        } catch (e) { return null; }
        """
        guard let any = try? await wv.callAsyncJavaScript(js, arguments: ["url": Self.base + path], contentWorld: .page),
              let text = any as? String,
              let data = text.data(using: .utf8) else { return nil }
        return try? JSONSerialization.jsonObject(with: data)
    }

    /// Таблица оценок со страницы инструмента «Оценки» (Gradebook) в курсе
    func gradebookRows(siteID: String) async -> (rows: [[String]], note: String) {
        users += 1
        defer { users -= 1 }
        guard let wv = await prepare() else { return ([], "нет браузера") }
        let js = """
        try {
          const ctl = new AbortController();
          setTimeout(() => ctl.abort(), 25000);
          const pr = await fetch(base + '/direct/site/' + site + '/pages.json', { credentials: 'include', signal: ctl.signal });
          if (!pr.ok) return JSON.stringify({ note: 'страницы курса: HTTP ' + pr.status, rows: [] });
          const pages = await pr.json();
          let tool = null;
          for (const p of pages) for (const t of (p.tools || [])) {
            const tid = (t.toolId || '').toLowerCase();
            if (tid.indexOf('gradebook') >= 0 || tid.indexOf('grade') >= 0) { tool = t; break; }
          }
          if (!tool) return JSON.stringify({ note: 'нет инструмента оценок', rows: [] });
          const r = await fetch(base + '/portal/tool/' + tool.id, { credentials: 'include', signal: ctl.signal });
          if (!r.ok) return JSON.stringify({ note: 'оценки: HTTP ' + r.status, rows: [] });
          const html = await r.text();
          const doc = new DOMParser().parseFromString(html, 'text/html');
          const rows = [];
          doc.querySelectorAll('tr').forEach(tr => {
            const cells = [];
            tr.querySelectorAll('th,td').forEach(c => cells.push((c.innerText || c.textContent || '').replace(/\\s+/g, ' ').trim()));
            if (cells.length > 1) rows.push(cells);
          });
          return JSON.stringify({ note: 'таблица ' + (tool.toolId || '') + ', строк ' + rows.length, rows: rows.slice(0, 200) });
        } catch (e) { return JSON.stringify({ note: 'ошибка ' + e, rows: [] }); }
        """
        guard let any = try? await wv.callAsyncJavaScript(js, arguments: ["base": Self.base, "site": siteID], contentWorld: .page),
              let text = any as? String,
              let data = text.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return ([], "не прочиталось") }
        return ((obj["rows"] as? [[String]]) ?? [], (obj["note"] as? String) ?? "")
    }

    /// Отпускаем браузер, когда он больше никому не нужен
    func release() {
        guard users == 0 else { return }
        web = nil
        ready = false
    }

    private func finish() {
        finished?.resume()
        finished = nil
    }

    nonisolated func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Task { @MainActor in self.finish() }
    }

    nonisolated func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in self.finish() }
    }

    nonisolated func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in self.finish() }
    }
}

// MARK: - Разбор JSON любого вида

enum JSONGrades {
    private static let nameKeys = ["itemName", "name", "title", "discipline", "disciplineName", "subject", "subjectName",
                                   "courseName", "course", "caption", "label"]
    private static let scoreKeys = ["grade", "score", "actualScore", "pointsEarned", "earned", "mark", "points_earned",
                                    "totalScore", "sumScore", "rating", "ball", "balls"]
    private static let maxKeys = ["pointsPossible", "maxPoints", "maxScore", "max", "possible", "outOf", "points"]

    static func number(_ v: Any?) -> Double? {
        if let d = v as? Double { return d }
        if let i = v as? Int { return Double(i) }
        if let s = v as? String {
            let t = s.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespaces)
            return Double(t)
        }
        return nil
    }

    /// Ищет объекты вида {название, баллы[, максимум]} на любой глубине
    static func extract(_ obj: Any, subject: String?, source: String, depth: Int = 0) -> [FoundGrade] {
        guard depth < 8 else { return [] }
        var out: [FoundGrade] = []
        if let dict = obj as? [String: Any] {
            let name = nameKeys.lazy.compactMap { dict[$0] as? String }.first { !$0.isEmpty }
            var scoreKey: String?
            var score: Double?
            for k in scoreKeys {
                if let v = number(dict[k]) { score = v; scoreKey = k; break }
            }
            if let name, let score, (0...200).contains(score) {
                let mx = maxKeys.lazy.filter { $0 != scoreKey }.compactMap { number(dict[$0]) }.first ?? 0
                out.append(FoundGrade(subject: subject ?? name, item: subject == nil ? "Итог" : name,
                                      points: score, outOf: mx, source: source))
            }
            // внутри курса название курса знаем — передаём дальше
            let inner = subject ?? name.flatMap { n in dict.values.contains { $0 is [Any] } ? n : nil }
            for v in dict.values where v is [Any] || v is [String: Any] {
                out += extract(v, subject: inner, source: source, depth: depth + 1)
            }
        } else if let arr = obj as? [Any] {
            for v in arr.prefix(500) { out += extract(v, subject: subject, source: source, depth: depth + 1) }
        }
        return out
    }
}

// MARK: - Личный кабинет (невидимый браузер)

@MainActor
final class PersonalCabinet: NSObject, WKNavigationDelegate {
    static let shared = PersonalCabinet()

    struct Result {
        var grades: [FoundGrade] = []
        var loggedIn = false
        var log = ""
    }

    private var web: WKWebView?
    private var finished: CheckedContinuation<Void, Never>?
    private var loadID = 0

    private static let hook = """
    (function(){
      if (window.__safuHooked) return; window.__safuHooked = true;
      window.__safuJSON = [];
      function keep(t){ try{ if(t && t.length < 400000 && (t[0]=='{'||t[0]=='[')) window.__safuJSON.push(t); }catch(e){} }
      var of = window.fetch;
      if (of) window.fetch = function(){ return of.apply(this, arguments).then(function(r){
        try{ r.clone().text().then(keep); }catch(e){} return r; }); };
      var oo = XMLHttpRequest.prototype.open;
      XMLHttpRequest.prototype.open = function(){ this.addEventListener('load', function(){
        try{ keep(this.responseText); }catch(e){} }); return oo.apply(this, arguments); };
    })();
    """

    private static let collect = """
    (function(){
      var rows = [];
      document.querySelectorAll('tr').forEach(function(tr){
        var cells = []; tr.querySelectorAll('th,td').forEach(function(c){ cells.push((c.innerText||'').trim()); });
        if (cells.length > 1) rows.push(cells);
      });
      var links = [];
      document.querySelectorAll('a').forEach(function(a){
        var t = (a.innerText||'').toLowerCase();
        if (/успеваем|зач[её]т|оценк|рейтинг|брс|балл|ведомост/.test(t) && a.href) links.push(a.href);
      });
      var body = (document.body && document.body.innerText) || '';
      return JSON.stringify({ url: location.href, rows: rows.slice(0, 600),
                              json: (window.__safuJSON||[]).slice(-40), links: links.slice(0, 10),
                              pw: !!document.querySelector('input[type=password]'),
                              title: document.title || '', len: body.length,
                              text: body.replace(/\\s+/g, ' ').slice(0, 400) });
    })();
    """

    func scrape() async -> Result {
        var result = Result()
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.userContentController.addUserScript(WKUserScript(source: Self.hook, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 390, height: 800), configuration: config)
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1"
        wv.navigationDelegate = self
        web = wv
        defer { web = nil }

        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            SessionKeeper.restore(into: WKWebsiteDataStore.default().httpCookieStore) { c.resume() }
        }

        var pages = [URL(string: "https://lk.narfu.ru")!]
        var visited = Set<String>()
        var guessed = false
        while let url = pages.first, visited.count < 6 {
            pages.removeFirst()
            guard visited.insert(url.absoluteString).inserted else { continue }
            await load(url, in: wv)
            // ЛК — одностраничное приложение: ждём, пока появятся данные (до ~12 с)
            var loaded: [String: Any]?
            for attempt in 0..<6 {
                try? await Task.sleep(nanoseconds: 2_000_000_000)
                if let raw = try? await wv.evaluateJavaScript(Self.collect) as? String,
                   let data = raw.data(using: .utf8),
                   let p = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    loaded = p
                    let rows = (p["rows"] as? [[String]])?.count ?? 0
                    let jsons = (p["json"] as? [String])?.count ?? 0
                    let len = (p["len"] as? Int) ?? 0
                    if rows > 0 || jsons > 0 || (len > 1500 && attempt >= 1) { break }
                }
            }
            guard let page = loaded else {
                result.log += "ЛК: страница \(url.absoluteString) не прочиталась\n"
                continue
            }
            let here = (page["url"] as? String) ?? ""
            let pw = (page["pw"] as? Bool) ?? false
            let low = here.lowercased()
            if pw || low.contains("login") || low.contains("auth") || low.contains("sso") {
                result.log += "ЛК: просит вход (\(here))\n"
                continue
            }
            result.loggedIn = true
            let rows = (page["rows"] as? [[String]]) ?? []
            let jsons = (page["json"] as? [String]) ?? []
            var got = TableGrades.extract(rows)
            for j in jsons {
                if let d = j.data(using: .utf8), let o = try? JSONSerialization.jsonObject(with: d) {
                    got += JSONGrades.extract(o, subject: nil, source: "ЛК")
                }
            }
            result.grades += got
            result.log += "ЛК \(here): строк \(rows.count), ответов \(jsons.count), найдено \(got.count)\n"
            for r in rows.prefix(15) { result.log += "  | " + String(r.joined(separator: " | ").prefix(160)) + "\n" }
            if rows.isEmpty {
                let title = (page["title"] as? String) ?? ""
                let text = (page["text"] as? String) ?? ""
                result.log += "  заголовок: \(title)\n  текст: \(text)\n"
                for j in jsons.prefix(3) { result.log += "  json: " + String(j.prefix(200)) + "\n" }
            }
            // идём по ссылкам «Успеваемость», «Зачётная книжка»…
            let links = (page["links"] as? [String]) ?? []
            for l in links {
                if let u = URL(string: l), !visited.contains(u.absoluteString) { pages.append(u) }
            }
            // ссылок не нашлось — пробуем типовые разделы
            if links.isEmpty && got.isEmpty && !guessed {
                guessed = true
                for path in ["/record-book", "/recordbook", "/grades", "/performance", "/progress"] {
                    if let u = URL(string: "https://lk.narfu.ru" + path) { pages.append(u) }
                }
            }
        }
        return result
    }

    private func load(_ url: URL, in wv: WKWebView) async {
        loadID += 1
        let id = loadID
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            finished = c
            wv.load(URLRequest(url: url, timeoutInterval: 20))
            // страховка от зависания — только для этой загрузки
            DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
                if self?.loadID == id { self?.finish() }
            }
        }
    }

    private func finish() {
        finished?.resume()
        finished = nil
    }

    nonisolated func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        Task { @MainActor in self.finish() }
    }

    nonisolated func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in self.finish() }
    }

    nonisolated func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        Task { @MainActor in self.finish() }
    }
}

// MARK: - Таблица оценок Sakai: «Лабораторная 1 | 8/10 | …»

enum SakaiTable {
    static func extract(_ rows: [[String]], subject: String) -> [FoundGrade] {
        var out: [FoundGrade] = []
        for r in rows {
            guard let name = r.first(where: { $0.rangeOfCharacter(from: .letters) != nil && $0.count >= 2 }) else { continue }
            let low = name.lowercased()
            if ["название", "задание", "title", "item", "оценка", "grade"].contains(where: { low == $0 }) { continue }
            var points: Double?
            var outOf: Double = 0
            for c in r where c != name {
                let t = c.replacingOccurrences(of: ",", with: ".").replacingOccurrences(of: " ", with: "")
                if let m = t.range(of: "^(\\d+(?:\\.\\d+)?)/(\\d+(?:\\.\\d+)?)$", options: .regularExpression) {
                    let parts = t[m].split(separator: "/")
                    points = Double(parts[0])
                    outOf = Double(parts[1]) ?? 0
                    break
                }
                if let v = Double(t), (0...200).contains(v) {
                    points = v
                    break
                }
            }
            guard let p = points else { continue }
            out.append(FoundGrade(subject: subject, item: name, points: p, outOf: outOf, source: "Sakai"))
        }
        return out
    }
}

// MARK: - Разбор таблиц

enum TableGrades {
    /// Строка таблицы: [название предмета, …, число] → итоговый балл.
    static func extract(_ rows: [[String]]) -> [FoundGrade] {
        var out: [FoundGrade] = []
        for r in rows {
            // название — самая длинная ячейка с буквами
            guard let name = r.filter({ $0.rangeOfCharacter(from: .letters) != nil && $0.count >= 4 })
                .max(by: { $0.count < $1.count }) else { continue }
            let nums = r.compactMap { cell -> Double? in
                let t = cell.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespaces)
                guard let v = Double(t), (0...100).contains(v) else { return nil }
                return v
            }
            guard let last = nums.last else { continue }
            out.append(FoundGrade(subject: name, item: "Итог", points: last, outOf: 100, source: "ЛК"))
        }
        return out
    }
}

// MARK: - Сопоставление названий

enum SubjectMatch {
    private static func tokens(_ s: String) -> Set<String> {
        Set(s.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { $0.count >= 3 }
            .map { String($0.prefix(6)) })     // «математический» и «математика» → «матема»
    }

    /// Лучший предмет из расписания для названия с сайта (или nil)
    static func best(_ raw: String, in subjects: [String]) -> String? {
        let low = raw.lowercased()
        if let exact = subjects.first(where: { low.contains($0.lowercased()) || $0.lowercased().contains(low) }) { return exact }
        let a = tokens(raw)
        guard !a.isEmpty else { return nil }
        var best: (String, Double)?
        for s in subjects {
            let b = tokens(s)
            guard !b.isEmpty else { continue }
            let score = Double(a.intersection(b).count) / Double(min(a.count, b.count))
            if score >= 0.6, score > (best?.1 ?? 0) { best = (s, score) }
        }
        return best?.0
    }
}

extension GradesStore {
    /// Кладёт найденное: автоматические записи предмета заменяются свежими, свои — остаются.
    func apply(_ found: [FoundGrade], subjects: [String]) -> (matched: Int, unmatched: [String]) {
        var bySubject: [String: [FoundGrade]] = [:]
        var unmatched = Set<String>()
        for g in found {
            if let s = SubjectMatch.best(g.subject, in: subjects) {
                bySubject[s, default: []].append(g)
            } else {
                unmatched.insert("\(g.source): \(g.subject) — \(BRSFormat.num(g.points))")
            }
        }
        var list = items
        for (subject, grades) in bySubject {
            // из одного источника — без повторов
            var seen = Set<String>()
            let unique = grades.filter { seen.insert("\($0.source)|\($0.item)|\($0.points)").inserted }
            let entries = unique.map {
                GradeEntry(title: $0.item, points: $0.points, outOf: $0.outOf, date: Date(), source: $0.source)
            }
            if let i = list.firstIndex(where: { $0.subject == subject }) {
                list[i].entries = list[i].entries.filter { $0.source.isEmpty } + entries
            } else {
                var g = SubjectGrades(subject: subject)
                g.entries = entries
                list.append(g)
            }
        }
        items = list
        return (bySubject.count, unmatched.sorted())
    }
}
