import Foundation
import UniformTypeIdentifiers

struct FileItem: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

struct FolderEntry: Identifiable {
    let url: URL
    let depth: Int
    var id: URL { url }
}

enum FileService {
    static var root: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static func path(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    static func isRoot(_ url: URL) -> Bool { path(url) == path(root) }

    static func list(_ dir: URL) -> [FileItem] {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])) ?? []
        let items = urls.map { u -> FileItem in
            let v = try? u.resourceValues(forKeys: Set(keys))
            return FileItem(url: u,
                            isDirectory: v?.isDirectory ?? false,
                            size: Int64(v?.fileSize ?? 0),
                            modified: v?.contentModificationDate ?? Date())
        }
        return items.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    static func uniqueURL(in dir: URL, name: String) -> URL {
        var candidate = dir.appendingPathComponent(name)
        let ext = (name as NSString).pathExtension
        let base = (name as NSString).deletingPathExtension
        var n = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            let newName = ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)"
            candidate = dir.appendingPathComponent(newName)
            n += 1
        }
        return candidate
    }

    static func createFolder(named name: String, in dir: URL) throws {
        let clean = sanitize(name)
        guard !clean.isEmpty else { return }
        try FileManager.default.createDirectory(at: uniqueURL(in: dir, name: clean),
                                                withIntermediateDirectories: false)
    }

    static func importFile(from src: URL, to dir: URL) throws {
        let access = src.startAccessingSecurityScopedResource()
        defer { if access { src.stopAccessingSecurityScopedResource() } }
        try FileManager.default.copyItem(at: src, to: uniqueURL(in: dir, name: src.lastPathComponent))
    }

    static func save(_ data: Data, ext: String, to dir: URL) throws {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH-mm-ss"
        let name = "Фото \(f.string(from: Date())).\(ext)"
        try data.write(to: uniqueURL(in: dir, name: name))
    }

    static func rename(_ item: FileItem, to newName: String) throws {
        var name = sanitize(newName)
        guard !name.isEmpty, name != item.name else { return }
        let oldExt = item.url.pathExtension
        if !item.isDirectory, !oldExt.isEmpty, (name as NSString).pathExtension.isEmpty {
            name += ".\(oldExt)"
        }
        let dir = item.url.deletingLastPathComponent()
        try FileManager.default.moveItem(at: item.url, to: uniqueURL(in: dir, name: name))
    }

    static func move(_ item: FileItem, to dir: URL) throws {
        // нельзя переместить папку саму в себя
        if item.isDirectory, path(dir).hasPrefix(path(item.url)) { return }
        if path(dir) == path(item.url.deletingLastPathComponent()) { return }
        try FileManager.default.moveItem(at: item.url, to: uniqueURL(in: dir, name: item.name))
    }

    static func delete(_ item: FileItem) throws {
        try FileManager.default.removeItem(at: item.url)
    }

    static func allFolders(excluding excluded: URL?) -> [FolderEntry] {
        var result = [FolderEntry(url: root, depth: 0)]
        func walk(_ dir: URL, depth: Int) {
            for item in list(dir) where item.isDirectory {
                if let ex = excluded, path(item.url) == path(ex) { continue }
                result.append(FolderEntry(url: item.url, depth: depth))
                walk(item.url, depth: depth + 1)
            }
        }
        walk(root, depth: 1)
        return result
    }

    static func icon(for item: FileItem) -> String {
        if item.isDirectory { return "folder.fill" }
        guard let t = UTType(filenameExtension: item.url.pathExtension.lowercased()) else { return "doc" }
        if t.conforms(to: .pdf) { return "doc.richtext.fill" }
        if t.conforms(to: .image) { return "photo.fill" }
        if t.conforms(to: .movie) { return "film.fill" }
        if t.conforms(to: .audio) { return "waveform" }
        if t.conforms(to: .presentation) { return "rectangle.on.rectangle.angled" }
        if t.conforms(to: .spreadsheet) { return "tablecells.fill" }
        if t.conforms(to: .archive) { return "doc.zipper" }
        if t.conforms(to: .sourceCode) { return "chevron.left.forwardslash.chevron.right" }
        if t.conforms(to: .text) { return "doc.text.fill" }
        return "doc.fill"
    }

    private static func sanitize(_ s: String) -> String {
        s.replacingOccurrences(of: "/", with: "-")
         .replacingOccurrences(of: ":", with: "-")
         .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
