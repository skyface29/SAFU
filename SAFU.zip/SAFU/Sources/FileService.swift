import Foundation
import UniformTypeIdentifiers

struct FileItem: Identifiable, Hashable {
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date
    /// Сколько внутри (для папок) — считается один раз при чтении списка, а не при каждой отрисовке
    var childCount: Int = 0
    var id: URL { url }
    var name: String { url.lastPathComponent }
}

struct FolderEntry: Identifiable {
    let url: URL
    let depth: Int
    var id: URL { url }
}

enum FileService {
    static var root: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    static func path(_ url: URL) -> String {
        url.standardizedFileURL.resolvingSymlinksInPath().path
    }

    static func isRoot(_ url: URL) -> Bool { path(url) == path(root) }

    static func list(_ dir: URL) -> [FileItem] {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: keys, options: [.skipsHiddenFiles])) ?? []
        let fm = FileManager.default
        let items = urls.map { u -> FileItem in
            let v = try? u.resourceValues(forKeys: Set(keys))
            let isDir = v?.isDirectory ?? false
            var count = 0
            if isDir {
                count = ((try? fm.contentsOfDirectory(atPath: u.path)) ?? []).filter { !$0.hasPrefix(".") }.count
            }
            return FileItem(url: u,
                            isDirectory: isDir,
                            size: Int64(v?.fileSize ?? 0),
                            modified: v?.contentModificationDate ?? Date(),
                            childCount: count)
        }
        return items.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    static func uniqueURL(in dir: URL, name: String) -> URL {
        var candidate = dir.appendingPathComponent(name)
        let ext = (name as NSString).pathExtension
        let base = (name as NSString).deletingPathExtension
        var n = 2
        while FileManager.default.fileExists(atPath: candidate.path) {
            let newName = ext.isEmpty ? "\(base) (\(n))" : "\(base) (\(n)).\(ext)"
            candidate = dir.appendingPathComponent(newName)
            n += 1
        }
        return candidate
    }

    static func createFolder(named name: String, in dir: URL) throws {
        let clean = sanitize(name)
        guard !clean.isEmpty else { return }
        try FileManager.default.createDirectory(at: uniqueURL(in: dir, name: clean),
                                                withIntermediateDirectories: false)
    }

    static func importFile(from src: URL, to dir: URL) throws {
        let access = src.startAccessingSecurityScopedResource()
        defer { if access { src.stopAccessingSecurityScopedResource() } }
        try FileManager.default.copyItem(at: src, to: uniqueURL(in: dir, name: src.lastPathComponent))
    }

    static func save(_ data: Data, ext: String, to dir: URL) throws {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH-mm-ss"
        let name = "Фото \(f.string(from: Date())).\(ext)"
        try data.write(to: uniqueURL(in: dir, name: name))
    }

    static func rename(_ item: FileItem, to newName: String) throws {
        var name = sanitize(newName)
        guard !name.isEmpty, name != item.name else { return }
        let oldExt = item.url.pathExtension
        if !item.isDirectory, !oldExt.isEmpty, (name as NSString).pathExtension.isEmpty {
            name += ".\(oldExt)"
        }
        let dir = item.url.deletingLastPathComponent()
        try FileManager.default.moveItem(at: item.url, to: uniqueURL(in: dir, name: name))
    }

    static func move(_ item: FileItem, to dir: URL) throws {
        // нельзя переместить папку саму в себя
        if item.isDirectory, path(dir).hasPrefix(path(item.url)) { return }
        if path(dir) == path(item.url.deletingLastPathComponent()) { return }
        try FileManager.default.moveItem(at: item.url, to: uniqueURL(in: dir, name: item.name))
    }

    static func delete(_ item: FileItem) throws {
        try FileManager.default.removeItem(at: item.url)
    }

    static func allFolders(excluding excluded: URL?) -> [FolderEntry] {
        var result = [FolderEntry(url: root, depth: 0)]
        func walk(_ dir: URL, depth: Int) {
            for item in list(dir) where item.isDirectory {
                if let ex = excluded, path(item.url) == path(ex) { continue }
                result.append(FolderEntry(url: item.url, depth: depth))
                walk(item.url, depth: depth + 1)
            }
        }
        walk(root, depth: 1)
        return result
    }

    static func icon(for item: FileItem) -> String {
        if item.isDirectory { return "folder.fill" }
        guard let t = UTType(filenameExtension: item.url.pathExtension.lowercased()) else { return "doc" }
        if t.conforms(to: .pdf) { return "doc.richtext.fill" }
        if t.conforms(to: .image) { return "photo.fill" }
        if t.conforms(to: .movie) { return "film.fill" }
        if t.conforms(to: .audio) { return "waveform" }
        if t.conforms(to: .presentation) { return "rectangle.on.rectangle.angled" }
        if t.conforms(to: .spreadsheet) { return "tablecells.fill" }
        if t.conforms(to: .archive) { return "doc.zipper" }
        if t.conforms(to: .sourceCode) { return "chevron.left.forwardslash.chevron.right" }
        if t.conforms(to: .text) { return "doc.text.fill" }
        return "doc.fill"
    }

    // MARK: категории, сводка, недавние

    enum Kind: Int, CaseIterable {
        case all, folders, docs, pdf, images, video

        var title: String {
            switch self {
            case .all: return "Все"
            case .folders: return "Папки"
            case .docs: return "Документы"
            case .pdf: return "PDF"
            case .images: return "Фото"
            case .video: return "Видео"
            }
        }

        var icon: String {
            switch self {
            case .all: return "square.grid.2x2"
            case .folders: return "folder"
            case .docs: return "doc.text"
            case .pdf: return "doc.richtext"
            case .images: return "photo"
            case .video: return "film"
            }
        }
    }

    static func kind(of item: FileItem) -> Kind {
        if item.isDirectory { return .folders }
        let ext = item.url.pathExtension.lowercased()
        guard let t = UTType(filenameExtension: ext) else { return .docs }
        if t.conforms(to: .pdf) { return .pdf }
        if t.conforms(to: .image) { return .images }
        if t.conforms(to: .movie) || t.conforms(to: .video) { return .video }
        return .docs
    }

    static func matches(_ item: FileItem, _ k: Kind) -> Bool {
        k == .all || kind(of: item) == k
    }

    struct Summary {
        var files = 0
        var folders = 0
        var bytes: Int64 = 0
        var byKind: [Kind: Int64] = [:]
    }

    static func summary() -> Summary {
        var s = Summary()
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        guard let e = FileManager.default.enumerator(at: root, includingPropertiesForKeys: keys,
                                                     options: [.skipsHiddenFiles]) else { return s }
        for case let u as URL in e {
            let v = try? u.resourceValues(forKeys: Set(keys))
            if v?.isDirectory == true {
                s.folders += 1
            } else {
                let size = Int64(v?.fileSize ?? 0)
                s.files += 1
                s.bytes += size
                let item = FileItem(url: u, isDirectory: false, size: size, modified: v?.contentModificationDate ?? Date())
                s.byKind[kind(of: item), default: 0] += size
            }
        }
        return s
    }

    static func recentFiles(limit: Int = 10) -> [FileItem] {
        let keys: [URLResourceKey] = [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey]
        guard let e = FileManager.default.enumerator(at: root, includingPropertiesForKeys: keys,
                                                     options: [.skipsHiddenFiles]) else { return [] }
        var all: [FileItem] = []
        for case let u as URL in e {
            let v = try? u.resourceValues(forKeys: Set(keys))
            if v?.isDirectory == true { continue }
            all.append(FileItem(url: u, isDirectory: false, size: Int64(v?.fileSize ?? 0),
                                modified: v?.contentModificationDate ?? Date()))
        }
        return Array(all.sorted { $0.modified > $1.modified }.prefix(limit))
    }

    static func sorted(_ items: [FileItem], by mode: Int) -> [FileItem] {
        items.sorted { a, b in
            if a.isDirectory != b.isDirectory { return a.isDirectory }
            switch mode {
            case 1: return a.modified > b.modified
            case 2: return a.size > b.size
            case 3:
                let ea = a.url.pathExtension.lowercased(), eb = b.url.pathExtension.lowercased()
                return ea == eb ? a.name.localizedStandardCompare(b.name) == .orderedAscending : ea < eb
            default: return a.name.localizedStandardCompare(b.name) == .orderedAscending
            }
        }
    }

    static func createTextFile(named name: String, text: String, in dir: URL) throws {
        var clean = sanitize(name)
        if clean.isEmpty { clean = "Заметка" }
        if (clean as NSString).pathExtension.isEmpty { clean += ".txt" }
        try text.write(to: uniqueURL(in: dir, name: clean), atomically: true, encoding: .utf8)
    }

    static func savePDF(_ data: Data, in dir: URL) throws {
        let f = DateFormatter()
        f.dateFormat = "dd.MM HH-mm"
        try data.write(to: uniqueURL(in: dir, name: "Скан \(f.string(from: Date())).pdf"))
    }

    private static func sanitize(_ s: String) -> String {
        s.replacingOccurrences(of: "/", with: "-")
         .replacingOccurrences(of: ":", with: "-")
         .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
