import SwiftUI

struct ResourcesView: View {
    @EnvironmentObject private var store: ResourceStore
    @Environment(\.openURL) private var openURL

    @State private var opened: Resource?
    @State private var editing: Resource?
    @State private var confirmReset = false

    private let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    ForEach(store.categories, id: \.self) { category in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(category)
                                .font(.title3.bold())
                            LazyVGrid(columns: columns, spacing: 12) {
                                ForEach(store.items(in: category)) { r in
                                    Button { opened = r } label: { ResourceCard(resource: r) }
                                        .buttonStyle(.plain)
                                        .contextMenu {
                                            Button {
                                                if let u = URL(string: r.url) { openURL(u) }
                                            } label: { Label("Открыть в Safari", systemImage: "safari") }
                                            Button { editing = r } label: {
                                                Label("Изменить", systemImage: "pencil")
                                            }
                                            Button(role: .destructive) { store.delete(r) } label: {
                                                Label("Удалить", systemImage: "trash")
                                            }
                                        }
                                }
                            }
                        }
                    }
                    Text("Удерживай плитку, чтобы изменить или удалить её.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("САФУ")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            editing = Resource(title: "", subtitle: "", url: "https://",
                                               icon: "link", category: "Мои ссылки")
                        } label: { Label("Добавить ссылку", systemImage: "plus") }
                        Button(role: .destructive) { confirmReset = true } label: {
                            Label("Сбросить к стандартным", systemImage: "arrow.counterclockwise")
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill").font(.title3)
                    }
                }
            }
            .fullScreenCover(item: $opened) { r in
                WebScreen(resource: r)
            }
            .sheet(item: $editing) { r in
                EditResourceView(resource: r) { store.upsert($0) }
            }
            .confirmationDialog("Вернуть стандартный список? Свои ссылки удалятся.",
                                isPresented: $confirmReset, titleVisibility: .visible) {
                Button("Сбросить", role: .destructive) { store.resetToDefaults() }
            }
        }
    }
}

struct ResourceCard: View {
    let resource: Resource

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: resource.icon)
                .font(.title2)
                .foregroundStyle(.white)
                .frame(width: 44, height: 44)
                .background(Color.safuBlue, in: RoundedRectangle(cornerRadius: 12))
            Text(resource.title)
                .font(.headline)
                .lineLimit(1)
            Text(resource.subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(2, reservesSpace: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
        .contentShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct EditResourceView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var resource: Resource
    private let onSave: (Resource) -> Void

    private let icons = ["link", "globe", "book.fill", "doc.fill", "calendar", "envelope.fill",
                         "graduationcap.fill", "person.fill", "folder.fill", "star.fill",
                         "cpu", "building.columns.fill"]

    init(resource: Resource, onSave: @escaping (Resource) -> Void) {
        _resource = State(initialValue: resource)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Например, Библиотека", text: $resource.title)
                    TextField("Короткое описание", text: $resource.subtitle)
                }
                Section("Адрес") {
                    TextField("https://", text: $resource.url)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Раздел") {
                    TextField("Раздел", text: $resource.category)
                }
                Section("Иконка") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 12) {
                        ForEach(icons, id: \.self) { name in
                            Image(systemName: name)
                                .frame(width: 40, height: 40)
                                .foregroundStyle(resource.icon == name ? .white : Color.safuBlue)
                                .background(resource.icon == name ? Color.safuBlue : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .onTapGesture { resource.icon = name }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Ссылка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        var r = resource
                        r.url = r.url.trimmingCharacters(in: .whitespaces)
                        if r.category.trimmingCharacters(in: .whitespaces).isEmpty {
                            r.category = "Мои ссылки"
                        }
                        onSave(r)
                        dismiss()
                    }
                    .disabled(!resource.isValid)
                }
            }
        }
    }
}
