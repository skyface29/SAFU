import SwiftUI

struct ResourcesView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.openURL) private var openURL
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("home.order") private var homeOrder = HomeSection.defaultRaw
    @AppStorage("home.columns") private var columnsCount = 2

    @State private var opened: Resource?
    @State private var editing: Resource?
    @State private var confirmReset = false
    @State private var appeared = false
    @State private var query = ""
    @State private var activeTool: Tool?
    @State private var openSubject: SubjectRef?
    @State private var photoSubject: SubjectRef?
    @State private var photoToast: String?
    @AppStorage("home.collapsed") private var collapsedRaw = ""

    private var collapsed: Set<String> {
        Set(collapsedRaw.split(separator: "|").map(String.init))
    }

    private func toggleCollapsed(_ category: String) {
        var set = collapsed
        if set.contains(category) { set.remove(category) } else { set.insert(category) }
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            collapsedRaw = set.sorted().joined(separator: "|")
        }
    }

    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12), count: max(2, min(columnsCount, 3)))
    }

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 28) {
                    ScreenHeader(caption: Fmt.today(), title: greetingTitle) {
                        addMenu
                    }
                    .opacity(appeared ? 1 : 0)
                    .offset(y: appeared ? 0 : -10)

                    ForEach(HomeSection.parse(homeOrder)) { sec in
                        homeBlock(sec)
                            .opacity(appeared ? 1 : 0)
                            .offset(y: appeared ? 0 : 16)
                    }

                    if HomeSection.parse(homeOrder).isEmpty {
                        Text("Главная пустая. Добавь блоки: Профиль → «Главный экран».")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.recentIDs)
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.items)
                .animation(.easeOut(duration: 0.5), value: appeared)
            }
        }
        .onAppear {
            appeared = true
            // новый блок «Дорога» — один раз добавляем после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.commute.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.commute) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.commute, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.commute.added")
            }
        }
        .fullScreenCover(item: $photoSubject) { ref in
            CameraPicker { image in
                photoSubject = nil
                if let image, BoardPhoto.save(image, subject: ref.name) != nil {
                    Haptics.success()
                    withAnimation { photoToast = "Фото сохранено в «\(ref.name)»" }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { withAnimation { photoToast = nil } }
                }
            }
            .ignoresSafeArea()
        }
        .overlay(alignment: .bottom) {
            if let photoToast {
                Label(photoToast, systemImage: "camera.fill")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 11)
                    .glass(20)
                    .padding(.bottom, 90)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .fullScreenCover(item: $opened) { r in
            WebScreen(resource: r)
                .environmentObject(store)
                .environmentObject(schedule)
        }
        .sheet(item: $openSubject) { ref in
            SubjectSheet(subject: ref.name)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $activeTool) { tool in
            ToolSheet(tool: tool)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $editing) { r in
            EditResourceView(resource: r) { store.upsert($0) }
        }
        .confirmationDialog("Вернуть стандартный список и очистить память?",
                            isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Сбросить", role: .destructive) { store.resetToDefaults() }
        }
    }

    @AppStorage("user.name") private var userName = "Кирилл"

    @ViewBuilder
    private func homeBlock(_ sec: HomeSection) -> some View {
        switch sec {
        case .now:
            if schedule.isConfigured {
                NowCard(data: schedule.data,
                        onOpen: { tab = AppTab.schedule.rawValue },
                        onMap: { address in
                            if let u = Maps.url(for: address) { openURL(u) }
                        },
                        onPhoto: { slot in photoSubject = SubjectRef(name: slot.lesson.subject) })
            } else {
                schedulePrompt
            }
        case .today:
            todayCard
        case .commute:
            if CommuteSettings.enabled && schedule.isConfigured {
                CommuteCard(data: schedule.data) {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
                        homeOrder = HomeSection.parse(homeOrder).filter { $0 != .commute }
                            .map(\.rawValue).joined(separator: ",")
                    }
                }
            }
        case .quick:
            if !store.quick.isEmpty { quickActions }
        case .subjects:
            SubjectsStrip { openSubject = SubjectRef(name: $0) }
        case .tools:
            ToolsGrid { activeTool = $0 }
        case .recents:
            if !store.recents.isEmpty { recentsSection }
        case .sites:
            sitesSection
        }
    }

    private var greetingTitle: String {
        let first = userName.split(separator: " ").first.map(String.init) ?? ""
        return first.isEmpty ? Fmt.greeting : "\(Fmt.greeting), \(first)"
    }

    // MARK: сайты

    @ViewBuilder private var sitesSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                SectionTitle(text: "Сайты")
                Spacer()
                Text("\(store.items.count)")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(Color.primary.opacity(0.08), in: Capsule())
            }

            searchField

            if !query.trimmingCharacters(in: .whitespaces).isEmpty {
                let results = store.search(query)
                if results.isEmpty {
                    Text("Ничего не найдено")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                } else {
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(results) { r in card(r) }
                    }
                }
            } else {
                if !store.pinnedItems.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Избранное", systemImage: "pin.fill")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(Color.brand)
                        LazyVGrid(columns: columns, spacing: 14) {
                            ForEach(store.pinnedItems) { r in card(r) }
                        }
                    }
                }
                ForEach(store.visibleCategories, id: \.self) { category in
                    categoryBlock(category)
                }
                Text("Удерживай плитку: закрепить, изменить или удалить")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
            }
        }
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)
            TextField("Поиск по сайтам", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            if !query.isEmpty {
                Button { withAnimation { query = "" } } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .glass(16)
        .animation(.easeInOut(duration: 0.2), value: query.isEmpty)
    }

    private func categoryBlock(_ category: String) -> some View {
        let isCollapsed = collapsed.contains(category)
        let list = store.items(in: category)
        return VStack(alignment: .leading, spacing: 12) {
            Button { toggleCollapsed(category) } label: {
                HStack(spacing: 8) {
                    Text(category)
                        .font(.system(.headline, design: .rounded))
                        .foregroundStyle(.primary)
                    Text("\(list.count)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isCollapsed ? -90 : 0))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if !isCollapsed {
                LazyVGrid(columns: columns, spacing: 14) {
                    ForEach(list) { r in card(r) }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    private var addMenu: some View {
        Menu {
            Button {
                editing = Resource(title: "", subtitle: "", url: "https://",
                                   icon: "link", category: "Мои ссылки")
            } label: { Label("Добавить ссылку", systemImage: "plus") }
            if !store.recents.isEmpty {
                Button { withAnimation { store.clearMemory() } } label: {
                    Label("Очистить недавние", systemImage: "clock.arrow.circlepath")
                }
            }
            Button(role: .destructive) { confirmReset = true } label: {
                Label("Сбросить ссылки", systemImage: "arrow.counterclockwise")
            }
        } label: {
            CircleIconButton(icon: "plus")
        }
    }

    // MARK: сегодня

    private var weekText: String {
        guard let w = Academic.week(from: schedule.data.semesterStart) else {
            return "Вне семестра"
        }
        return "Неделя \(w) · \(w % 2 == 0 ? "чётная" : "нечётная")"
    }

    private var schedulePrompt: some View {
        Button { tab = AppTab.schedule.rawValue } label: {
            HStack(spacing: 14) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Какая сейчас пара?")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text("Подключи расписание из РУЗ, и здесь будет текущая пара, аудитория и адрес")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
            .padding(16)
            .glass(26, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }

    private var todayCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                pill(icon: "calendar", text: weekText)
                pill(icon: "checklist", text: "Задач: \(tasks.active.count)")
            }
            Divider().opacity(0.5)
            if let next = tasks.nextOpen {
                HStack(spacing: 12) {
                    Image(systemName: "flag.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Ближайший дедлайн")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(next.title)
                            .font(.headline)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    Text(Fmt.relative(next.due))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(next.due < Date() ? Color.red : Color.brand)
                }
            } else {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    Text("Дедлайнов нет, можно выдохнуть")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(18)
        .glass(28)
    }

    private func pill(icon: String, text: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.brand)
            Text(text)
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.brand.opacity(0.12), in: Capsule())
    }

    // MARK: быстрые кнопки

    /// Быстрые кнопки: нажми — открыть, зажми и перетащи на другую — поменять местами
    private var quickActions: some View {
        HStack(spacing: 0) {
            ForEach(store.quick) { r in
                Button { open(r) } label: {
                    VStack(spacing: 8) {
                        Image(systemName: r.icon)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(brandGradient)
                            .bounce(on: store.openTicks[r.id] ?? 0)
                            .frame(width: 58, height: 58)
                            .glass(29, interactive: true)
                        Text(r.title)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(PressableStyle())
                .draggable(r.id.uuidString) {
                    Image(systemName: r.icon)
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 60, height: 60)
                        .background(brandGradient, in: Circle())
                }
                .dropDestination(for: String.self) { items, _ in
                    guard let dragged = items.first else { return false }
                    moveQuick(dragged, to: r.id.uuidString)
                    return true
                }
            }
        }
    }

    private func moveQuick(_ draggedID: String, to targetID: String) {
        var ids = store.quick.map { $0.id.uuidString }
        guard draggedID != targetID, let from = ids.firstIndex(of: draggedID),
              let to = ids.firstIndex(of: targetID) else { return }
        ids.remove(at: from)
        ids.insert(draggedID, at: to)
        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
            UserDefaults.standard.set(ids.joined(separator: ","), forKey: "quick.ids")
            store.objectWillChange.send()
        }
        Haptics.success()
    }

    // MARK: недавние (память)

    private var recentsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Недавние")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(store.recents) { r in
                        Button { open(r) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(Color.brand)
                                Text(r.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                if store.lastURL(for: r) != nil {
                                    Circle().fill(Color.brand).frame(width: 5, height: 5)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .glass(18, interactive: true)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 4)
            }
            .padding(.horizontal, -20)
        }
    }

    // MARK: карточка

    private func card(_ r: Resource) -> some View {
        let i = store.index(of: r)
        return Button { open(r) } label: {
            VStack(alignment: .leading, spacing: 0) {
                Image(systemName: r.icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .bounce(on: store.openTicks[r.id] ?? 0)
                Spacer(minLength: 22)
                Text(r.title)
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                if columnsCount < 3 {
                    Text(r.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, minHeight: columnsCount < 3 ? 104 : 84, alignment: .leading)
            .padding(columnsCount < 3 ? 16 : 13)
            .glass(24, interactive: true)
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .overlay(alignment: .topTrailing) {
            if r.pinned {
                Image(systemName: "pin.fill")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color.brand)
                    .padding(10)
            }
        }
        .contextMenu {
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { store.togglePin(r) }
            } label: {
                Label(r.pinned ? "Открепить" : "Закрепить в избранном", systemImage: r.pinned ? "pin.slash" : "pin")
            }
            Button {
                if let u = URL(string: r.url) { openURL(u) }
            } label: { Label("Открыть в Safari", systemImage: "safari") }
            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }
            Button(role: .destructive) { withAnimation { store.delete(r) } } label: {
                Label("Удалить", systemImage: "trash")
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 24)
        .scaleEffect(appeared ? 1 : 0.96)
        .animation(.spring(response: 0.55, dampingFraction: 0.8).delay(0.04 * Double(i) + 0.15),
                   value: appeared)
    }

    private func open(_ r: Resource) {
        Haptics.tap()
        store.markOpened(r)
        opened = r
    }
}

struct EditResourceView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var resource: Resource
    private let onSave: (Resource) -> Void

    private let icons = ["link", "globe", "book.fill", "doc.fill", "calendar", "envelope.fill",
                         "graduationcap.fill", "person.fill", "folder.fill", "star.fill",
                         "cpu", "building.columns.fill"]

    init(resource: Resource, onSave: @escaping (Resource) -> Void) {
        _resource = State(initialValue: resource)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Например, Библиотека", text: $resource.title)
                    TextField("Короткое описание", text: $resource.subtitle)
                }
                Section("Адрес") {
                    TextField("https://", text: $resource.url)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Раздел") {
                    TextField("Раздел", text: $resource.category)
                }
                Section("Иконка") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 12) {
                        ForEach(icons, id: \.self) { name in
                            Image(systemName: name)
                                .frame(width: 40, height: 40)
                                .foregroundStyle(resource.icon == name ? .white : Color.brand)
                                .background(resource.icon == name ? Color.brand : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .onTapGesture { resource.icon = name }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Ссылка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        var r = resource
                        r.url = r.url.trimmingCharacters(in: .whitespaces)
                        if r.category.trimmingCharacters(in: .whitespaces).isEmpty {
                            r.category = "Мои ссылки"
                        }
                        onSave(r)
                        dismiss()
                    }
                    .disabled(!resource.isValid)
                }
            }
        }
    }
}
