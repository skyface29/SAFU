import SwiftUI

struct ResourcesView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.openURL) private var openURL
    @AppStorage("memory.tabID") private var tab = "home"
    @AppStorage("home.order") private var homeOrder = HomeSection.defaultRaw
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw

    @State private var opened: Resource?
    @State private var editing: Resource?
    @State private var confirmReset = false
    @State private var appeared = false
    @State private var query = ""
    @State private var activeTool: Tool?
    @State private var openSubject: SubjectRef?
    @State private var photoSubject: SubjectRef?
    @State private var photoToast: String?
    @State private var place: PlaceRef?
    @State private var boardOpen: BoardBatch?
    @State private var showBoards = false
    @State private var showHomeEditor = false
    @State private var showProfile = false
    @AppStorage("home.collapsed") private var collapsedRaw = ""

    private var collapsed: Set<String> {
        Set(collapsedRaw.split(separator: "|").map(String.init))
    }

    private func toggleCollapsed(_ category: String) {
        var set = collapsed
        if set.contains(category) { set.remove(category) } else { set.insert(category) }
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            collapsedRaw = set.sorted().joined(separator: "|")
        }
    }

    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12), count: max(2, min(columnsCount, 3)))
    }

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    ScreenHeader(caption: Fmt.today(), title: greetingTitle) {
                        HStack(spacing: 10) {
                            addMenu
                            // аватар — переход в профиль
                            Button {
                                Haptics.tap()
                                if AppTab.parse(tabsRaw).contains(.profile) { tab = AppTab.profile.rawValue } else { showProfile = true }
                            } label: {
                                AvatarView(size: 40)
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }
                    .opacity(appeared ? 1 : 0)
                    .offset(y: appeared ? 0 : -10)

                    ForEach(homeSections) { sec in
                        homeBlock(sec)
                            .opacity(appeared ? 1 : 0)
                            .offset(y: appeared ? 0 : 16)
                            // удержал любой блок — тащи вверх или вниз
                            .draggable("home:" + sec.rawValue) {
                                Label(sec.title, systemImage: sec.icon)
                                    .font(.subheadline.weight(.semibold))
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .dropDestination(for: String.self) { items, _ in
                                guard let raw = items.first, raw.hasPrefix("home:"),
                                      let moved = HomeSection(rawValue: String(raw.dropFirst(5))) else { return false }
                                moveSection(moved, to: sec)
                                return true
                            } isTargeted: { on in
                                if on { Haptics.tap() }
                            }
                    }

                    if HomeSection.parse(homeOrder).isEmpty {
                        Text("Главная пустая. Добавь блоки кнопкой ниже.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Button {
                        Haptics.tap()
                        showHomeEditor = true
                    } label: {
                        Label("Настроить главную", systemImage: "slider.horizontal.3")
                            .font(.footnote.weight(.medium))
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.plain)
                    Text("Удержи любой блок или плитку и перетащи, чтобы поменять порядок")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                        .frame(maxWidth: .infinity)
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.recentIDs)
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.items)
                .animation(.easeOut(duration: 0.5), value: appeared)
            }
        }
        .onAppear {
            appeared = true
            StrictLook.applyOnce()
            // 9.9: главная разгружена — «Недавние» и «Предметы» убраны (вернуть можно в «Настроить главную»)
            if !UserDefaults.standard.bool(forKey: "home.slim.99") {
                homeOrder = HomeSection.parse(homeOrder).filter { $0 != .recents && $0 != .subjects }
                    .map(\.rawValue).joined(separator: ",")
                UserDefaults.standard.set(true, forKey: "home.slim.99")
            }
            // новый блок «Дорога» — один раз добавляем после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.commute.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.commute) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.commute, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.commute.added")
            }
            // новый блок «Погода» — один раз добавляем сразу после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.weather.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.weather) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.weather, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.weather.added")
            }
            // новый блок «Фото доски» — один раз добавляем после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.board.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.board) {
                    let i = (list.firstIndex(of: .commute) ?? list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.board, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.board.added")
            }
        }
        .sheet(item: $boardOpen) { b in
            NavigationStack {
                BoardBatchView(batch: b)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { boardOpen = nil } } }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showBoards) {
            NavigationStack {
                BoardBatchesList(subject: nil)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { showBoards = false } } }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showProfile) {
            ProfileView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(isPresented: $showHomeEditor) {
            NavigationStack {
                HomeEditor()
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { showHomeEditor = false } } }
            }
            .environmentObject(store)
        }
        .sheet(item: $place) { ref in
            PairPlaceView(slot: ref.slot)
                .environmentObject(schedule)
        }
        .fullScreenCover(item: $photoSubject) { ref in
            CameraPicker { image in
                photoSubject = nil
                if let image, BoardPhoto.save(image, subject: ref.name) != nil {
                    Haptics.success()
                    withAnimation { photoToast = "Фото сохранено в «\(ref.name)»" }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { withAnimation { photoToast = nil } }
                }
            }
            .ignoresSafeArea()
        }
        .overlay(alignment: .bottom) {
            if let photoToast {
                Label(photoToast, systemImage: "camera.fill")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 11)
                    .glass(20)
                    .padding(.bottom, 90)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .fullScreenCover(item: $opened) { r in
            WebScreen(resource: r)
                .environmentObject(store)
                .environmentObject(schedule)
        }
        .sheet(item: $openSubject) { ref in
            SubjectSheet(subject: ref.name)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $activeTool) { tool in
            ToolSheet(tool: tool)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $editing) { r in
            EditResourceView(resource: r) { store.upsert($0) }
        }
        .confirmationDialog("Вернуть стандартный список и очистить память?",
                            isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Сбросить", role: .destructive) { store.resetToDefaults() }
        }
    }

    @AppStorage("user.name") private var userName = ""

    @ViewBuilder
    private func homeBlock(_ sec: HomeSection) -> some View {
        switch sec {
        case .now:
            if schedule.isConfigured {
                NowCard(data: schedule.data,
                        onOpen: { tab = AppTab.schedule.rawValue },
                        onMap: { address in
                            if let u = Maps.smartURL(for: address) { openURL(u) }
                        },
                        onPhoto: { slot in photoSubject = SubjectRef(name: slot.lesson.subject) },
                        onPlace: { slot in place = PlaceRef(slot: slot) })
            } else {
                schedulePrompt
            }
        case .today:
            todayCard
        case .session:
            if schedule.isConfigured { SessionCard(data: schedule.data) }
        case .commute:
            if CommuteSettings.enabled && schedule.isConfigured {
                CommuteCard(data: schedule.data) {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
                        homeOrder = HomeSection.parse(homeOrder).filter { $0 != .commute }
                            .map(\.rawValue).joined(separator: ",")
                    }
                }
            }
        case .quick:
            if !store.quick.isEmpty { quickActions }
        case .subjects:
            SubjectsStrip { openSubject = SubjectRef(name: $0) }
        case .tools:
            ToolsGrid { activeTool = $0 }
        case .recents:
            if !store.recents.isEmpty { recentsSection }
        case .sites:
            sitesSection
        case .board:
            if schedule.isConfigured {
                BoardHomeCard(data: schedule.data,
                              onCamera: { photoSubject = SubjectRef(name: $0) },
                              onOpen: { boardOpen = $0 })
            }
        case .tiles:
            HomeTilesGrid(columns: max(2, min(columnsCount, 3))) { openTile($0) }
        case .weather:
            WeatherHomeCard(data: schedule.data)
        }
    }

    /// Перетащили блок на место другого
    private func moveSection(_ moved: HomeSection, to target: HomeSection) {
        var list = HomeSection.parse(homeOrder)
        guard moved != target, let from = list.firstIndex(of: moved),
              let to = list.firstIndex(of: target) else { return }
        list.remove(at: from)
        list.insert(moved, at: to)
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            homeOrder = list.map(\.rawValue).joined(separator: ",")
        }
        Haptics.success()
    }

    /// Нажали свою плитку
    private func openTile(_ t: HomeTile) {
        switch t.kind {
        case .link:
            opened = Resource(title: t.title, subtitle: "", url: t.value, icon: t.icon, category: "Мои плитки")
        case .tool:
            if let tool = Tool(rawValue: t.value) { activeTool = tool }
        case .subject:
            openSubject = SubjectRef(name: t.value)
        case .tab:
            tab = t.value
        case .camera:
            if let s = LessonPhotos.currentSlot(schedule.data) { photoSubject = SubjectRef(name: s.lesson.subject) } else { showBoards = true }
        case .boards:
            showBoards = true
        case .note:
            break
        }
    }

    /// В режиме сессии блок «Сессия» поднимается наверх
    private var homeSections: [HomeSection] {
        var list = HomeSection.parse(homeOrder)
        if schedule.isConfigured, SessionMode.isActive(schedule.data) {
            list.removeAll { $0 == .session }
            list.insert(.session, at: 0)
        }
        return list
    }

    private var greetingTitle: String {
        let first = userName.split(separator: " ").first.map(String.init) ?? ""
        return first.isEmpty ? Fmt.greeting : "\(Fmt.greeting), \(first)"
    }

    // MARK: сайты

    @ViewBuilder private var sitesSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                SectionTitle(text: "Сайты")
                Spacer()
                Text("\(store.items.count)")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(Color.primary.opacity(0.08), in: Capsule())
            }

            searchField

            if !query.trimmingCharacters(in: .whitespaces).isEmpty {
                let results = store.search(query)
                if results.isEmpty {
                    Text("Ничего не найдено")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                } else {
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(results) { r in card(r) }
                    }
                }
            } else {
                if !store.pinnedItems.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Избранное", systemImage: "pin.fill")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(Color.brand)
                        LazyVGrid(columns: columns, spacing: 14) {
                            ForEach(store.pinnedItems) { r in card(r) }
                        }
                    }
                }
                ForEach(store.visibleCategories, id: \.self) { category in
                    categoryBlock(category)
                }
                Text("Удерживай плитку: закрепить, изменить или удалить")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
            }
        }
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)
            TextField("Поиск по сайтам", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            if !query.isEmpty {
                Button { withAnimation { query = "" } } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .glass(16)
        .animation(.easeInOut(duration: 0.2), value: query.isEmpty)
    }

    private func categoryBlock(_ category: String) -> some View {
        let isCollapsed = collapsed.contains(category)
        let list = store.items(in: category)
        return VStack(alignment: .leading, spacing: 12) {
            Button { toggleCollapsed(category) } label: {
                HStack(spacing: 8) {
                    Text(category)
                        .font(.system(.headline, design: .rounded))
                        .foregroundStyle(.primary)
                    Text("\(list.count)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isCollapsed ? -90 : 0))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if !isCollapsed {
                LazyVGrid(columns: columns, spacing: 14) {
                    ForEach(list) { r in card(r) }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    private var addMenu: some View {
        Menu {
            Button {
                editing = Resource(title: "", subtitle: "", url: "https://",
                                   icon: "link", category: "Мои ссылки")
            } label: { Label("Добавить ссылку", systemImage: "plus") }
            Button { showHomeEditor = true } label: {
                Label("Настроить главную и плитки", systemImage: "slider.horizontal.3")
            }
            if !store.recents.isEmpty {
                Button { withAnimation { store.clearMemory() } } label: {
                    Label("Очистить недавние", systemImage: "clock.arrow.circlepath")
                }
            }
            Button(role: .destructive) { confirmReset = true } label: {
                Label("Сбросить ссылки", systemImage: "arrow.counterclockwise")
            }
        } label: {
            CircleIconButton(icon: "plus")
        }
    }

    // MARK: сегодня

    private var weekText: String {
        guard let w = Academic.week(from: schedule.data.semesterStart) else {
            return "Вне семестра"
        }
        return "Неделя \(w) · \(w % 2 == 0 ? "чётная" : "нечётная")"
    }

    private var schedulePrompt: some View {
        Button { tab = AppTab.schedule.rawValue } label: {
            HStack(spacing: 14) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Какая сейчас пара?")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text("Подключи расписание из РУЗ, и здесь будет текущая пара, аудитория и адрес")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
            .padding(16)
            .glass(26, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }

    private var todayCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                pill(icon: "calendar", text: weekText)
                pill(icon: "checklist", text: "Задач: \(tasks.active.count)")
            }
            Divider().opacity(0.5)
            if let next = tasks.nextOpen {
                HStack(spacing: 12) {
                    Image(systemName: "flag.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Ближайший дедлайн")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(next.title)
                            .font(.headline)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    Text(Fmt.relative(next.due))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(next.due < Date() ? Color.red : Color.brand)
                }
            } else {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    Text("Дедлайнов нет, можно выдохнуть")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(18)
        .glass(28)
    }

    private func pill(icon: String, text: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.brand)
            Text(text)
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.brand.opacity(0.12), in: Capsule())
    }

    // MARK: быстрые кнопки

    /// Быстрые кнопки: нажми — открыть, зажми и перетащи на другую — поменять местами
    private var quickActions: some View {
        HStack(spacing: 0) {
            ForEach(store.quick) { r in
                Button { open(r) } label: {
                    VStack(spacing: 8) {
                        Image(systemName: r.icon)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundStyle(brandGradient)
                            .bounce(on: store.openTicks[r.id] ?? 0)
                            .frame(width: 58, height: 58)
                            .glass(29, interactive: true)
                        Text(r.title)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(PressableStyle())
                .draggable(r.id.uuidString) {
                    Image(systemName: r.icon)
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 60, height: 60)
                        .background(brandGradient, in: Circle())
                }
                .dropDestination(for: String.self) { items, _ in
                    guard let dragged = items.first else { return false }
                    moveQuick(dragged, to: r.id.uuidString)
                    return true
                }
            }
        }
    }

    private func moveQuick(_ draggedID: String, to targetID: String) {
        var ids = store.quick.map { $0.id.uuidString }
        guard draggedID != targetID, let from = ids.firstIndex(of: draggedID),
              let to = ids.firstIndex(of: targetID) else { return }
        ids.remove(at: from)
        ids.insert(draggedID, at: to)
        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
            UserDefaults.standard.set(ids.joined(separator: ","), forKey: "quick.ids")
            store.objectWillChange.send()
        }
        Haptics.success()
    }

    // MARK: недавние (память)

    private var recentsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Недавние")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(store.recents) { r in
                        Button { open(r) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(Color.brand)
                                Text(r.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                if store.lastURL(for: r) != nil {
                                    Circle().fill(Color.brand).frame(width: 5, height: 5)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .glass(18, interactive: true)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 4)
            }
            .padding(.horizontal, -20)
        }
    }

    // MARK: карточка

    private func card(_ r: Resource) -> some View {
        let i = store.index(of: r)
        return Button { open(r) } label: {
            VStack(alignment: .leading, spacing: 0) {
                Image(systemName: r.icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .bounce(on: store.openTicks[r.id] ?? 0)
                Spacer(minLength: 22)
                Text(r.title)
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                if columnsCount < 3 {
                    Text(r.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, minHeight: columnsCount < 3 ? 104 : 84, alignment: .leading)
            .padding(columnsCount < 3 ? 16 : 13)
            .glass(24, interactive: true)
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .overlay(alignment: .topTrailing) {
            if r.pinned {
                Image(systemName: "pin.fill")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color.brand)
                    .padding(10)
            }
        }
        .contextMenu {
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { store.togglePin(r) }
            } label: {
                Label(r.pinned ? "Открепить" : "Закрепить в избранном", systemImage: r.pinned ? "pin.slash" : "pin")
            }
            Button {
                if let u = URL(string: r.url) { openURL(u) }
            } label: { Label("Открыть в Safari", systemImage: "safari") }
            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }
            Button(role: .destructive) { withAnimation { store.delete(r) } } label: {
                Label("Удалить", systemImage: "trash")
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 24)
        .scaleEffect(appeared ? 1 : 0.96)
        .animation(.spring(response: 0.55, dampingFraction: 0.8).delay(0.04 * Double(i) + 0.15),
                   value: appeared)
    }

    private func open(_ r: Resource) {
        Haptics.tap()
        store.markOpened(r)
        opened = r
    }
}

struct EditResourceView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var resource: Resource
    private let onSave: (Resource) -> Void

    private let icons = ["link", "globe", "book.fill", "doc.fill", "calendar", "envelope.fill",
                         "graduationcap.fill", "person.fill", "folder.fill", "star.fill",
                         "cpu", "building.columns.fill"]

    init(resource: Resource, onSave: @escaping (Resource) -> Void) {
        _resource = State(initialValue: resource)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Например, Библиотека", text: $resource.title)
                    TextField("Короткое описание", text: $resource.subtitle)
                }
                Section("Адрес") {
                    TextField("https://", text: $resource.url)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Раздел") {
                    TextField("Раздел", text: $resource.category)
                }
                Section("Иконка") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 12) {
                        ForEach(icons, id: \.self) { name in
                            Image(systemName: name)
                                .frame(width: 40, height: 40)
                                .foregroundStyle(resource.icon == name ? .white : Color.brand)
                                .background(resource.icon == name ? Color.brand : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .onTapGesture { resource.icon = name }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Ссылка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        var r = resource
                        r.url = r.url.trimmingCharacters(in: .whitespaces)
                        if r.category.trimmingCharacters(in: .whitespaces).isEmpty {
                            r.category = "Мои ссылки"
                        }
                        onSave(r)
                        dismiss()
                    }
                    .disabled(!resource.isValid)
                }
            }
        }
    }
}
