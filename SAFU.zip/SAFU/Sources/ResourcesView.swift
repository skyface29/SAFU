import SwiftUI

struct ResourcesView: View {
    @EnvironmentObject private var store: ResourceStore
    @Environment(\.openURL) private var openURL

    @State private var opened: Resource?
    @State private var editing: Resource?
    @State private var confirmReset = false
    @State private var appeared = false

    private let columns = [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)]

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 30) {
                    header

                    if !store.recents.isEmpty {
                        recentsSection
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }

                    ForEach(store.categories, id: \.self) { category in
                        VStack(alignment: .leading, spacing: 12) {
                            SectionTitle(text: category)
                            LazyVGrid(columns: columns, spacing: 14) {
                                ForEach(store.items(in: category)) { r in
                                    card(r)
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.45, dampingFraction: 0.85), value: store.recentIDs)
            }
        }
        .onAppear { appeared = true }
        .fullScreenCover(item: $opened) { r in
            WebScreen(resource: r).environmentObject(store)
        }
        .sheet(item: $editing) { r in
            EditResourceView(resource: r) { store.upsert($0) }
        }
        .confirmationDialog("Вернуть стандартный список и очистить память?",
                            isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Сбросить", role: .destructive) { store.resetToDefaults() }
        }
    }

    // MARK: шапка

    private var header: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text(Self.dateString)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                Text(Self.greeting)
                    .font(.system(size: 34, weight: .bold, design: .rounded))
            }
            Spacer()
            Menu {
                Button {
                    editing = Resource(title: "", subtitle: "", url: "https://",
                                       icon: "link", category: "Мои ссылки")
                } label: { Label("Добавить ссылку", systemImage: "plus") }
                if !store.recents.isEmpty {
                    Button { withAnimation { store.clearMemory() } } label: {
                        Label("Очистить недавние", systemImage: "clock.arrow.circlepath")
                    }
                }
                Button(role: .destructive) { confirmReset = true } label: {
                    Label("Сбросить всё", systemImage: "arrow.counterclockwise")
                }
            } label: {
                Image(systemName: "plus")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 44, height: 44)
                    .glass(22)
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : -10)
        .animation(.easeOut(duration: 0.5), value: appeared)
    }

    // MARK: недавние (память)

    private var recentsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Недавние")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(store.recents) { r in
                        Button { open(r) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(Color.safuBlue)
                                Text(r.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                if store.lastURL(for: r) != nil {
                                    Circle().fill(Color.safuBlue).frame(width: 5, height: 5)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .glass(18)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.horizontal, -20)
        }
    }

    // MARK: карточка

    private func card(_ r: Resource) -> some View {
        let i = store.index(of: r)
        return Button { open(r) } label: {
            VStack(alignment: .leading, spacing: 0) {
                Image(systemName: r.icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(
                        LinearGradient(colors: [.safuBlue, .safuViolet],
                                       startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .bounce(on: store.openTicks[r.id] ?? 0)
                Spacer(minLength: 22)
                Text(r.title)
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(r.subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, minHeight: 104, alignment: .leading)
            .padding(16)
            .glass()
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .contextMenu {
            Button {
                if let u = URL(string: r.url) { openURL(u) }
            } label: { Label("Открыть в Safari", systemImage: "safari") }
            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }
            Button(role: .destructive) { withAnimation { store.delete(r) } } label: {
                Label("Удалить", systemImage: "trash")
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 24)
        .scaleEffect(appeared ? 1 : 0.96)
        .animation(.spring(response: 0.55, dampingFraction: 0.8).delay(0.05 * Double(i) + 0.1),
                   value: appeared)
    }

    private func open(_ r: Resource) {
        Haptics.tap()
        store.markOpened(r)
        opened = r
    }

    // MARK: текст

    private static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }

    private static var dateString: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EEEE, d MMMM"
        return f.string(from: Date())
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct EditResourceView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var resource: Resource
    private let onSave: (Resource) -> Void

    private let icons = ["link", "globe", "book.fill", "doc.fill", "calendar", "envelope.fill",
                         "graduationcap.fill", "person.fill", "folder.fill", "star.fill",
                         "cpu", "building.columns.fill"]

    init(resource: Resource, onSave: @escaping (Resource) -> Void) {
        _resource = State(initialValue: resource)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Например, Библиотека", text: $resource.title)
                    TextField("Короткое описание", text: $resource.subtitle)
                }
                Section("Адрес") {
                    TextField("https://", text: $resource.url)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Раздел") {
                    TextField("Раздел", text: $resource.category)
                }
                Section("Иконка") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 12) {
                        ForEach(icons, id: \.self) { name in
                            Image(systemName: name)
                                .frame(width: 40, height: 40)
                                .foregroundStyle(resource.icon == name ? .white : Color.safuBlue)
                                .background(resource.icon == name ? Color.safuBlue : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .onTapGesture { resource.icon = name }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Ссылка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        var r = resource
                        r.url = r.url.trimmingCharacters(in: .whitespaces)
                        if r.category.trimmingCharacters(in: .whitespaces).isEmpty {
                            r.category = "Мои ссылки"
                        }
                        onSave(r)
                        dismiss()
                    }
                    .disabled(!resource.isValid)
                }
            }
        }
    }
}
