import SwiftUI
import UIKit

struct ResourcesView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.openURL) private var openURL
    @AppStorage("memory.tabID") private var tab = "home"
    /// Широкое окно Mac: главная в две колонки
    @Environment(\.macWide) private var macWide
    @AppStorage("home.order") private var homeOrder = HomeSection.defaultRaw
    @AppStorage("home.columns") private var columnsCount = 2
    /// Все сайты на главной свёрнуты в одну строку — до Sakai и почты и так дотягиваешься с панели
    @AppStorage("home.sitesOpen") private var sitesOpen = false
    @AppStorage("tabs.order") private var tabsRaw = AppTab.defaultRaw

    @State private var opened: Resource?
    @ObservedObject private var mailRouter = MailRouter.shared
    @State private var editing: Resource?
    @State private var confirmReset = false
    @State private var appeared = false
    @State private var query = ""
    @State private var activeTool: Tool?
    @State private var openSubject: SubjectRef?
    @State private var photoSubject: SubjectRef?
    @State private var photoToast: String?
    @State private var place: PlaceRef?
    @State private var boardOpen: BoardBatch?
    @State private var showBoards = false
    @State private var showHomeEditor = false
    @State private var showProfile = false
    /// Перенос на компьютер по QR-коду — кнопкой в углу главной, без похода в настройки
    @State private var showTransfer = false
    @State private var showSync = false
    @ObservedObject private var arrange = ArrangeSession.shared
    @AppStorage("hw.nowChip") private var hwNowChip = true
    /// Где главные кнопки (Sakai, почта…): dock — закреплены над вкладками, bottom — просто внизу главной, top — блоком сверху
    @AppStorage("home.quickPlace") private var quickPlace = QuickPlace.standard
    @AppStorage("home.collapsed") private var collapsedRaw = ""
    @AppStorage("ui.compact") private var compact = false
    /// Раскрыты плитки библиотек под панелью
    @AppStorage("home.libsOpen") private var libsOpen = false

    private var collapsed: Set<String> {
        Set(collapsedRaw.split(separator: "|").map(String.init))
    }

    private func toggleCollapsed(_ category: String) {
        var set = collapsed
        if set.contains(category) { set.remove(category) } else { set.insert(category) }
        Haptics.tap()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            collapsedRaw = set.sorted().joined(separator: "|")
        }
    }

    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12), count: max(2, min(columnsCount, 3)))
    }

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: compact ? 14 : 24) {
                    // три кнопки справа — приветствие может ужаться сильнее, чем на других экранах
                    ScreenHeader(caption: Fmt.today(), title: greetingTitle, minScale: 0.58) {
                        HStack(spacing: 8) {
                            addMenu
                            #if !targetEnvironment(macCatalyst)
                            // перенос на компьютер: камера сразу ждёт QR-код с экрана Арктики для Windows.
                            // На Mac его нет: Mac сам компьютер
                            Button {
                                Haptics.tap()
                                showTransfer = true
                            } label: {
                                CircleIconButton(icon: "qrcode.viewfinder")
                            }
                            .buttonStyle(PressableStyle())
                            .accessibilityLabel("Перенос на компьютер по QR-коду")
                            #endif
                            // аватар — переход в профиль
                            Button {
                                Haptics.tap()
                                if AppTab.parse(tabsRaw).contains(.profile) { tab = AppTab.profile.rawValue } else { showProfile = true }
                            } label: {
                                AvatarView(size: 40)
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }

                    // маленькая пометка: связан ли компьютер и на связи ли он сейчас
                    PCLinkChip { showSync = true }
                        .padding(.top, compact ? -6 : -12)

                    sectionsLayout

                    if HomeSection.parse(homeOrder).isEmpty {
                        Text("Главная пустая. Добавь блоки кнопкой ниже.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    Button {
                        Haptics.tap()
                        showHomeEditor = true
                    } label: {
                        Label("Настроить главную", systemImage: "slider.horizontal.3")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .glass(16)
                    }
                    .buttonStyle(PressableStyle())
                }
                .padding(.horizontal, compact ? 14 : 20)
                .padding(.top, compact ? 6 : 12)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.39, dampingFraction: 0.85), value: store.recentIDs)
                .animation(.spring(response: 0.39, dampingFraction: 0.85), value: store.items)
                .arrangeDropZone(.home)
            }
            .pausesAmbientWhileScrolling()
            .statusBarScrim()
            // пока всё покачивается — сверху «Готово»
            .overlay(alignment: .top) {
                ArrangeDoneBar()
                    .padding(.top, 4)
                    .animation(.spring(response: 0.32, dampingFraction: 0.86), value: arrange.editing)
            }
            // док с главными кнопками: всегда над панелью вкладок, до него легко дотянуться
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if quickPlace == "dock" && !store.quick.isEmpty {
                    quickDock
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        // ушли с главной — перестановка заканчивается сама
        .onDisappear { if arrange.editing != nil { arrange.done() } }
        .onAppear {
            appeared = true
            StrictLook.applyOnce()
            // преподавателю — его рабочие сайты (один раз)
            if TeacherMode.isOn, !UserDefaults.standard.bool(forKey: "resources.teacher.added") {
                let have = Set(store.items.map { $0.url.lowercased() })
                let extra = Resource.teacherDefaults.filter { !have.contains($0.url.lowercased()) }
                if !extra.isEmpty { store.items.insert(contentsOf: extra, at: 0) }
                UserDefaults.standard.set(true, forKey: "resources.teacher.added")
            }
            // студенту — ничего преподавательского: убираем сайты для сотрудников и блок «Преподавателю»
            // (могли остаться, если раньше выбирали режим преподавателя)
            if !TeacherMode.isOn {
                let staff = Set(Resource.teacherDefaults.map { $0.url.lowercased() })
                let isStaff: (Resource) -> Bool = { $0.category == "Преподавателю" && staff.contains($0.url.lowercased()) }
                if store.items.contains(where: isStaff) { store.items.removeAll(where: isStaff) }
                let clean = HomeSection.parse(homeOrder).map(\.rawValue).joined(separator: ",")
                if clean != homeOrder && !clean.isEmpty { homeOrder = clean }
                UserDefaults.standard.removeObject(forKey: "resources.teacher.added")
                UserDefaults.standard.removeObject(forKey: "home.teacher.added")
                if UserDefaults.standard.integer(forKey: "user.role") == 3 { UserDefaults.standard.set(0, forKey: "user.role") }
            }
            // преподавателю — своя карточка сразу после «пары сейчас» (один раз)
            if TeacherMode.isOn, !UserDefaults.standard.bool(forKey: "home.teacher.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.teacher) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.teacher, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.teacher.added")
            }
            // 9.9 убирал «Недавние» и «Предметы» — возвращаем на место
            if UserDefaults.standard.bool(forKey: "home.slim.99"), !UserDefaults.standard.bool(forKey: "home.slim.undo") {
                var list = HomeSection.parse(homeOrder)
                for (sec, after) in [(HomeSection.subjects, HomeSection.quick), (.recents, .tools)] where !list.contains(sec) {
                    let i = list.firstIndex(of: after).map { $0 + 1 } ?? list.count
                    list.insert(sec, at: min(i, list.count))
                }
                homeOrder = list.map(\.rawValue).joined(separator: ",")
                UserDefaults.standard.set(true, forKey: "home.slim.undo")
            }
            // новый блок «Дорога» — один раз добавляем после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.commute.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.commute) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.commute, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.commute.added")
            }
            // новый блок «Погода» — один раз добавляем сразу после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.weather.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.weather) {
                    let i = (list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.weather, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.weather.added")
            }
            // новый блок «Фото доски» — один раз добавляем после «пары сейчас»
            if !UserDefaults.standard.bool(forKey: "home.board.added") {
                var list = HomeSection.parse(homeOrder)
                if !list.contains(.board) {
                    let i = (list.firstIndex(of: .commute) ?? list.firstIndex(of: .now) ?? -1) + 1
                    list.insert(.board, at: min(i, list.count))
                    homeOrder = list.map(\.rawValue).joined(separator: ",")
                }
                UserDefaults.standard.set(true, forKey: "home.board.added")
            }
        }
        .sheet(item: $boardOpen) { b in
            NavigationStack {
                BoardBatchView(batch: b)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { boardOpen = nil } } }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showBoards) {
            NavigationStack {
                BoardSearchView()
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { showBoards = false } } }
            }
            .environmentObject(schedule)
        }
        .sheet(isPresented: $showProfile) {
            ProfileView()
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(isPresented: $showSync) {
            NavigationStack {
                PCSyncView()
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) { Button("Готово") { showSync = false } }
                    }
            }
        }
        .sheet(isPresented: $showTransfer) {
            NavigationStack {
                PCTransferView()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { showTransfer = false } }
                    }
            }
        }
        .sheet(isPresented: $showHomeEditor) {
            NavigationStack {
                HomeEditor()
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Готово") { showHomeEditor = false } } }
            }
            .environmentObject(store)
        }
        .sheet(item: $place) { ref in
            PairPlaceView(slot: ref.slot)
                .environmentObject(schedule)
        }
        .fullScreenCover(item: $photoSubject) { ref in
            CameraPicker { image in
                photoSubject = nil
                if let image, BoardPhoto.save(image, subject: ref.name) != nil {
                    Haptics.success()
                    withAnimation { photoToast = "Фото сохранено в «\(ref.name)»" }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) { withAnimation { photoToast = nil } }
                }
            }
            .ignoresSafeArea()
        }
        .overlay(alignment: .bottom) {
            if let photoToast {
                Label(photoToast, systemImage: "camera.fill")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 11)
                    .glass(20)
                    .padding(.bottom, 90)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .fullScreenCover(item: $opened) { r in
            // сайты «как в Safari» (почта) — настоящим Safari внутри приложения: там всё ведёт себя точно как в Safari
            Group {
                if let u = URL(string: r.url), WebModel.isPlain(u.host) {
                    SafariView(url: u).ignoresSafeArea()
                } else {
                    WebScreen(resource: r)
                        .environmentObject(store)
                        .environmentObject(schedule)
                }
            }
            // живой фон главной под сайтом не нужен: он отнимал плавность у прокрутки почты
            .pausesAmbient()
        }
        // нажали на уведомление о письме
        .onChange(of: mailRouter.pending) { _ in openMailIfAsked() }
        .onAppear { openMailIfAsked() }
        .sheet(item: $openSubject) { ref in
            SubjectSheet(subject: ref.name)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $activeTool) { tool in
            ToolSheet(tool: tool)
                .environmentObject(store)
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(item: $editing) { r in
            EditResourceView(resource: r) { store.upsert($0) }
        }
        .confirmationDialog("Вернуть стандартный список и очистить память?",
                            isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Сбросить", role: .destructive) { store.resetToDefaults() }
        }
    }

    @AppStorage("user.name") private var userName = ""

    /// Блок «под погодой и автобусом»: после последнего из них (или после карточки пары)
    private var quickAnchor: HomeSection? {
        let list = homeSections
        if let last = list.last(where: { $0 == .weather || $0 == .commute }) { return last }
        if list.contains(.homework) { return .homework }
        if list.contains(.now) { return .now }
        return list.first
    }

    /// Блок «под домашкой»: после «Домашки», а если её нет на главной — после карточки пары
    private var homeworkAnchor: HomeSection? {
        let list = homeSections
        if list.contains(.homework) && schedule.isConfigured && !TeacherMode.isOn { return .homework }
        if list.contains(.now) { return .now }
        return list.first
    }

    /// Блоки главной: на iPhone и в узком окне — одной колонкой, в широком окне Mac — в две
    @ViewBuilder
    private var sectionsLayout: some View {
        if macWide {
            // широкое окно Mac: слева главное (пара сейчас, домашка, инструменты, сайты),
            // справа узкая колонка — пары на сегодня, погода, дорога, сессия
            HStack(alignment: .top, spacing: 20) {
                VStack(alignment: .leading, spacing: compact ? 14 : 20) {
                    ForEach(homeSections.filter { !Self.sideSections.contains($0) }, id: \.self) { sec in
                        homeSection(sec)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .topLeading)
                VStack(alignment: .leading, spacing: compact ? 14 : 20) {
                    if schedule.isConfigured {
                        MacTodayCard(data: schedule.data) { tab = AppTab.schedule.rawValue }
                    }
                    ForEach(homeSections.filter { Self.sideSections.contains($0) }, id: \.self) { sec in
                        homeSection(sec)
                    }
                }
                .frame(width: 370, alignment: .topLeading)
            }
        } else {
            ForEach(homeSections, id: \.self) { sec in
                homeSection(sec)
            }
        }
    }

    /// Блоки правой колонки на широком окне Mac
    private static let sideSections: Set<HomeSection> = [.weather, .commute, .session, .today, .board]

    /// Блок главной со всем, что на него навешано: эффект прокрутки и перестановка удержанием
    private func homeSection(_ sec: HomeSection) -> some View {
        homeBlockWithQuick(sec)
            .scrollFX()
            // удержал блок — всё покачивается, тащишь вверх или вниз — блоки расступаются
            .arrangeable("home:" + sec.rawValue, kind: .home, amount: 0.35,
                         move: moveSectionIDs,
                         onRemove: { removeSection(sec) }) {
                Label(sec.title, systemImage: sec.icon)
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
    }

    @ViewBuilder
    private func homeBlockWithQuick(_ sec: HomeSection) -> some View {
        let anchored = (quickPlace == "bottom" && sec == quickAnchor) || (quickPlace == "homework" && sec == homeworkAnchor)
        // сайты в панели над вкладками (iOS 26) — под домашкой остаётся одна кнопка «Библиотеки»
        let barLibs = quickPlace == "bar" && sec == homeworkAnchor
        if anchored && !store.quick.isEmpty {
            VStack(spacing: compact ? 14 : 24) {
                homeBlock(sec)
                VStack(spacing: 10) {
                    dockBar
                    if libsOpen {
                        LibrariesPanel(open: $libsOpen)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
            }
        } else if barLibs {
            VStack(spacing: compact ? 14 : 24) {
                homeBlock(sec)
                VStack(spacing: 10) {
                    librariesRow
                    if libsOpen {
                        LibrariesPanel(open: $libsOpen)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
            }
        } else {
            homeBlock(sec)
        }
    }

    @ViewBuilder
    private func homeBlock(_ sec: HomeSection) -> some View {
        switch sec {
        case .now:
            if schedule.isConfigured {
                NowCard(data: schedule.data,
                        onOpen: { tab = AppTab.schedule.rawValue },
                        onMap: { address in
                            Maps.open(address)
                        },
                        onPhoto: { slot in photoSubject = SubjectRef(name: slot.lesson.subject) },
                        onPlace: { slot in place = PlaceRef(slot: slot) },
                        onHomework: hwNowChip ? { (slot: LessonSlot) in HomeworkRouter.shared.new(slot: slot) } : nil,
                        homeworkCount: { subject in HomeworkStore.shared.openCount(subject: subject) })
            } else {
                schedulePrompt
            }
        case .homework:
            if schedule.isConfigured && !TeacherMode.isOn {
                HWHomeCard(data: schedule.data) { HomeworkRouter.shared.openTab = true }
            }
        case .today:
            todayCard
        case .session:
            if schedule.isConfigured && !TeacherMode.isOn { SessionCard(data: schedule.data) }
        case .commute:
            if CommuteSettings.enabled && schedule.isConfigured && !TeacherMode.isOn {
                CommuteCard(data: schedule.data) {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                        homeOrder = HomeSection.parse(homeOrder).filter { $0 != .commute }
                            .map(\.rawValue).joined(separator: ",")
                    }
                }
            }
        case .quick:
            if !store.quick.isEmpty && quickPlace == "top" {
                VStack(spacing: 12) {
                    quickActions
                    if libsOpen {
                        LibrariesPanel(open: $libsOpen)
                            .transition(.move(edge: .top).combined(with: .opacity))
                    }
                }
            }
        case .subjects:
            SubjectsStrip { openSubject = SubjectRef(name: $0) }
        case .tools:
            ToolsGrid { activeTool = $0 }
        case .recents:
            if !store.recents.isEmpty { recentsSection }
        case .sites:
            sitesSection
        case .board:
            if schedule.isConfigured {
                BoardHomeCard(data: schedule.data,
                              onCamera: { photoSubject = SubjectRef(name: $0) },
                              onOpen: { boardOpen = $0 })
            }
        case .tiles:
            HomeTilesGrid(columns: max(2, min(columnsCount, 3))) { openTile($0) }
        case .weather:
            WeatherHomeCard(data: schedule.data)
        case .teacher:
            if TeacherMode.isOn {
                TeacherHomeCard(data: schedule.data,
                                onTool: { activeTool = $0 },
                                onRefresh: { Task { await schedule.sync(force: true) } },
                                syncing: schedule.syncing)
            }
        }
    }

    /// Блок проехал на место соседа (пока его тащат) — соседи расступаются
    private func moveSectionIDs(_ dragged: String, _ target: String) {
        let ids = HomeSection.parse(homeOrder).map { "home:" + $0.rawValue }
        guard let list = ArrangeOrder.moved(ids, dragged, to: target) else { return }
        homeOrder = list.map { String($0.dropFirst(5)) }.joined(separator: ",")
    }

    /// «−» в режиме перестановки: блок уходит с главной (вернуть — «Настроить главную»)
    private func removeSection(_ sec: HomeSection) {
        homeOrder = HomeSection.parse(homeOrder).filter { $0 != sec }.map(\.rawValue).joined(separator: ",")
    }

    /// Нажали свою плитку
    private func openTile(_ t: HomeTile) {
        switch t.kind {
        case .link:
            SiteTabs.shared.open(Resource(title: t.title, subtitle: "", url: t.value, icon: t.icon, category: "Мои плитки"))
        case .tool:
            if let tool = Tool(rawValue: t.value) { activeTool = tool }
        case .subject:
            openSubject = SubjectRef(name: t.value)
        case .tab:
            tab = t.value
        case .camera:
            if let s = LessonPhotos.currentSlot(schedule.data) { photoSubject = SubjectRef(name: s.lesson.subject) } else { showBoards = true }
        case .boards:
            showBoards = true
        case .note:
            break
        }
    }

    /// В режиме сессии блок «Сессия» поднимается наверх
    private var homeSections: [HomeSection] {
        var list = HomeSection.parse(homeOrder)
        if schedule.isConfigured, SessionMode.isActive(schedule.data) {
            list.removeAll { $0 == .session }
            list.insert(.session, at: 0)
        }
        return list
    }

    private var greetingTitle: String {
        let first = userName.split(separator: " ").first.map(String.init) ?? ""
        return first.isEmpty ? Fmt.greeting : "\(Fmt.greeting), \(first)"
    }

    // MARK: сайты

    @ViewBuilder private var sitesSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.34, dampingFraction: 0.88)) { sitesOpen.toggle() }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "globe")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(Color.brand)
                    Text("Все сайты")
                        .font(.system(.headline, design: .rounded))
                        .foregroundStyle(.primary)
                    Text("\(store.items.count)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(sitesOpen ? 0 : -90))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .glass(20)
            }
            .buttonStyle(PressableStyle())

            if sitesOpen {
                sitesContent
                    .transition(.opacity)
            }
        }
    }

    @ViewBuilder private var sitesContent: some View {
        VStack(alignment: .leading, spacing: 18) {
            searchField

            if !query.trimmingCharacters(in: .whitespaces).isEmpty {
                let results = store.search(query)
                if results.isEmpty {
                    Text("Ничего не найдено")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 20)
                } else {
                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(results) { r in card(r) }
                    }
                }
            } else {
                if !store.pinnedItems.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Избранное", systemImage: "pin.fill")
                            .font(.subheadline.weight(.bold))
                            .foregroundStyle(Color.brand)
                        LazyVGrid(columns: columns, spacing: 14) {
                            ForEach(store.pinnedItems) { r in card(r) }
                        }
                    }
                }
                ForEach(store.visibleCategories, id: \.self) { category in
                    categoryBlock(category)
                }
                Text("Удерживай плитку: закрепить, изменить или удалить")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
            }
        }
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)
            TextField("Поиск по сайтам", text: $query)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            if !query.isEmpty {
                Button { withAnimation { query = "" } } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .glass(16)
        .animation(.easeInOut(duration: 0.2), value: query.isEmpty)
    }

    private func categoryBlock(_ category: String) -> some View {
        let isCollapsed = collapsed.contains(category)
        let list = store.items(in: category)
        return VStack(alignment: .leading, spacing: 12) {
            Button { toggleCollapsed(category) } label: {
                HStack(spacing: 8) {
                    Text(category)
                        .font(.system(.headline, design: .rounded))
                        .foregroundStyle(.primary)
                    Text("\(list.count)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isCollapsed ? -90 : 0))
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if !isCollapsed {
                LazyVGrid(columns: columns, spacing: 14) {
                    ForEach(list) { r in card(r) }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }

    private var addMenu: some View {
        Menu {
            Button {
                editing = Resource(title: "", subtitle: "", url: "https://",
                                   icon: "link", category: "Мои ссылки")
            } label: { Label("Добавить ссылку", systemImage: "plus") }
            Button { showHomeEditor = true } label: {
                Label("Настроить главную и плитки", systemImage: "slider.horizontal.3")
            }
            if !store.recents.isEmpty {
                Button { withAnimation { store.clearMemory() } } label: {
                    Label("Очистить недавние", systemImage: "clock.arrow.circlepath")
                }
            }
            Button(role: .destructive) { confirmReset = true } label: {
                Label("Сбросить ссылки", systemImage: "arrow.counterclockwise")
            }
        } label: {
            CircleIconButton(icon: "plus")
        }
    }

    // MARK: сегодня

    private var weekText: String {
        guard let w = Academic.week(from: schedule.data.semesterStart) else {
            return "Вне семестра"
        }
        return "Неделя \(w) · \(w % 2 == 0 ? "чётная" : "нечётная")"
    }

    private var schedulePrompt: some View {
        Button { tab = AppTab.schedule.rawValue } label: {
            HStack(spacing: 14) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Какая сейчас пара?")
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Text("Подключи расписание из РУЗ, и здесь будет текущая пара, аудитория и адрес")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
            }
            .padding(16)
            .glass(26, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }

    private var todayCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 10) {
                pill(icon: "calendar", text: weekText)
                pill(icon: "checklist", text: "Задач: \(tasks.active.count)")
            }
            Divider().opacity(0.5)
            if let next = tasks.nextOpen {
                HStack(spacing: 12) {
                    Image(systemName: "flag.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Ближайший дедлайн")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Text(next.title)
                            .font(.headline)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 8)
                    Text(Fmt.relative(next.due))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(next.due < Date() ? Color.red : Color.brand)
                }
            } else {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(brandGradient)
                        .frame(width: 40, height: 40)
                        .background(Color.brand.opacity(0.12), in: Circle())
                    Text("Дедлайнов нет, можно выдохнуть")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(18)
        .glass(28)
    }

    private func pill(icon: String, text: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.brand)
            Text(text)
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.brand.opacity(0.12), in: Capsule())
    }

    // MARK: быстрые кнопки

    /// Быстрые кнопки: нажми — открыть, зажми и перетащи на другую — поменять местами
    private var quickActions: some View {
        HStack(spacing: 0) {
            ForEach(store.quick) { r in
                Button { open(r, origin: "top:" + r.id.uuidString, radius: 17) } label: {
                    VStack(spacing: 8) {
                        SiteAppIcon(resource: r, size: 58)
                            .bounce(on: store.openTicks[r.id] ?? 0)
                            .background(OriginProbe(key: "top:" + r.id.uuidString))
                        Text(r.title)
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.primary)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(PressableStyle())
                .arrangeable("quick:" + r.id.uuidString, kind: .quick, amount: 2.4, move: moveQuickIDs) {
                    SiteAppIcon(resource: r, size: 60)
                }
            }
            LibrariesTile(open: $libsOpen, size: 58, labelFont: .caption.weight(.medium))
        }
        .arrangeDropZone(.quick)
    }

    /// Нижний док: те же главные кнопки, но под большим пальцем и всегда на виду
    private var quickDock: some View {
        VStack(spacing: 10) {
            if libsOpen {
                LibrariesPanel(open: $libsOpen)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            dockBar
        }
            .shadow(color: .black.opacity(0.22), radius: 16, y: 6)
            .padding(.horizontal, compact ? 14 : 20)
            .padding(.bottom, 8)
    }

    /// Панель главных сайтов: плитки в цвет темы. Нажал — сайт вырастает прямо из своей плитки,
    /// закрыл — садится обратно. Последняя плитка — «Библиотеки»: все ЭБС в одном месте
    private var dockBar: some View {
        HStack(spacing: 0) {
            ForEach(store.quick.prefix(5)) { r in
                dockButton(r)
            }
            LibrariesTile(open: $libsOpen, size: store.quick.count >= 5 ? 46 : 50)
        }
        .arrangeDropZone(.quick)
        .animation(.spring(response: 0.31, dampingFraction: 0.82), value: store.quick.map(\.id))
        .padding(.horizontal, 4)
        .padding(.vertical, 12)
        .glass(24)
    }

    private func dockButton(_ r: Resource) -> some View {
        Button { open(r, origin: "dock:" + r.id.uuidString, radius: 15) } label: {
            VStack(spacing: 7) {
                SiteAppIcon(resource: r, size: 50)
                    .bounce(on: store.openTicks[r.id] ?? 0)
                    .background(OriginProbe(key: "dock:" + r.id.uuidString))
                Text(r.title)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressableStyle())
        .contextMenu {
            Button { open(r) } label: { Label("Открыть", systemImage: "arrow.up.right.square") }
            if QuickPlace.barAvailable && quickPlace != "bar" {
                Button { setQuickPlace("bar") } label: { Label("В панель вкладок", systemImage: "dock.rectangle") }
            }
            if quickPlace != "homework" {
                Button { setQuickPlace("homework") } label: { Label("Под домашкой", systemImage: "book.closed") }
            }
            if quickPlace != "dock" {
                Button { setQuickPlace("dock") } label: { Label("Закрепить внизу главной", systemImage: "pin.fill") }
            }
            if quickPlace != "bottom" {
                Button { setQuickPlace("bottom") } label: { Label("Под погодой и автобусом", systemImage: "rectangle.stack") }
            }
            if quickPlace != "top" {
                Button { setQuickPlace("top") } label: { Label("Наверх главной", systemImage: "arrow.up.to.line") }
            }
            Button { ArrangeSession.shared.enter(.quick) } label: {
                Label("Изменить порядок", systemImage: "arrow.left.arrow.right")
            }
        }
        .arrangeable("quick:" + r.id.uuidString, kind: .quick, amount: 2.4, move: moveQuickIDs) {
            SiteAppIcon(resource: r, size: 60)
        }
    }

    /// Кнопка «Библиотеки» строкой — когда сайты живут в панели над вкладками
    private var librariesRow: some View {
        Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.34, dampingFraction: 0.86)) { libsOpen.toggle() }
        } label: {
            HStack(spacing: 12) {
                SiteGlyphTile(icon: "books.vertical.fill", size: 38)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Библиотеки").font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                    Text("Знаниум, Лань, Юрайт и другие ЭБС").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: libsOpen ? "chevron.up" : "chevron.down")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(.secondary)
            }
            .padding(12)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressableStyle())
        .glass(20)
    }

    private func setQuickPlace(_ p: String) {
        Haptics.tap()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { quickPlace = p }
    }

    /// Кнопка проехала на место соседа — соседи расступаются
    private func moveQuickIDs(_ dragged: String, _ target: String) {
        QuickOrder.move(store, dragged, target)
    }

    // MARK: недавние (память)

    private var recentsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Недавние")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(store.recents) { r in
                        Button { open(r) } label: {
                            HStack(spacing: 8) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(Color.brand)
                                Text(r.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                if store.lastURL(for: r) != nil {
                                    Circle().fill(Color.brand).frame(width: 5, height: 5)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 10)
                            .glass(18, interactive: true)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.scale.combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 4)
            }
            .padding(.horizontal, -20)
        }
    }

    // MARK: карточка

    private func card(_ r: Resource) -> some View {
        let i = store.index(of: r)
        return Button { open(r) } label: {
            VStack(alignment: .leading, spacing: 0) {
                Image(systemName: r.icon)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(brandGradient)
                    .bounce(on: store.openTicks[r.id] ?? 0)
                Spacer(minLength: 22)
                Text(r.title)
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                if columnsCount < 3 {
                    Text(r.subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, minHeight: columnsCount < 3 ? 104 : 84, alignment: .leading)
            .padding(columnsCount < 3 ? 16 : 13)
            .glass(24, interactive: true)
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .overlay(alignment: .topTrailing) {
            if r.pinned {
                Image(systemName: "pin.fill")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Color.brand)
                    .padding(10)
            }
        }
        .contextMenu {
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { store.togglePin(r) }
            } label: {
                Label(r.pinned ? "Открепить" : "Закрепить в избранном", systemImage: r.pinned ? "pin.slash" : "pin")
            }
            Button {
                if let u = URL(string: r.url) { openURL(u) }
            } label: { Label("Открыть в Safari", systemImage: "safari") }
            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }
            Button(role: .destructive) { withAnimation { store.delete(r) } } label: {
                Label("Удалить", systemImage: "trash")
            }
        }
        .opacity(appeared ? 1 : 0)
        .offset(y: appeared ? 0 : 24)
        .scaleEffect(appeared ? 1 : 0.96)
        .animation(.spring(response: 0.46, dampingFraction: 0.8).delay(0.04 * Double(i) + 0.15),
                   value: appeared)
    }

    private func openMailIfAsked() {
        guard mailRouter.pending else { return }
        mailRouter.pending = false
        let mail = store.items.first { URL(string: $0.url)?.host == MailWatch.webHost }
            ?? Resource(title: "Почта", subtitle: "Samoware", url: "https://" + MailWatch.webHost,
                        icon: "envelope.fill", category: "Почта и документы")
        opened = nil
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { open(mail) }
    }

    /// Любой сайт, и почта тоже, — карточкой, которую можно смахнуть вниз и свернуть.
    /// origin — метка плитки, из которой карточка вырастет
    private func open(_ r: Resource, origin: String? = nil, radius: CGFloat = 15) {
        SiteTabs.shared.open(r, origin: origin, radius: radius)
        store.markOpenedSoon(r)
    }
}

struct EditResourceView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var resource: Resource
    private let onSave: (Resource) -> Void

    private let icons = ["link", "globe", "book.fill", "doc.fill", "calendar", "envelope.fill",
                         "graduationcap.fill", "person.fill", "folder.fill", "star.fill",
                         "cpu", "building.columns.fill"]

    init(resource: Resource, onSave: @escaping (Resource) -> Void) {
        _resource = State(initialValue: resource)
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Название") {
                    TextField("Например, Библиотека", text: $resource.title)
                    TextField("Короткое описание", text: $resource.subtitle)
                }
                Section("Адрес") {
                    TextField("https://", text: $resource.url)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section("Раздел") {
                    TextField("Раздел", text: $resource.category)
                }
                Section("Иконка") {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 6), spacing: 12) {
                        ForEach(icons, id: \.self) { name in
                            Image(systemName: name)
                                .frame(width: 40, height: 40)
                                .foregroundStyle(resource.icon == name ? .white : Color.brand)
                                .background(resource.icon == name ? Color.brand : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                                .onTapGesture { resource.icon = name }
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Ссылка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        var r = resource
                        r.url = r.url.trimmingCharacters(in: .whitespaces)
                        if r.category.trimmingCharacters(in: .whitespaces).isEmpty {
                            r.category = "Мои ссылки"
                        }
                        onSave(r)
                        dismiss()
                    }
                    .disabled(!resource.isValid)
                }
            }
        }
    }
}

/// Плитка сайта на панели: в цвет темы, как значки «Инструментов», — у всех сайтов одинаковая.
/// Карточка сайта вырастает из неё и садится обратно
struct SiteAppIcon: View {
    let resource: Resource
    var size: CGFloat = 50

    var body: some View {
        SiteGlyphTile(icon: resource.icon, size: size)
    }
}

/// Плитка в цвет темы с символом
struct SiteGlyphTile: View {
    let icon: String
    var size: CGFloat = 50

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: SiteTile.radius(size), style: .continuous)
        Image(systemName: icon)
            .font(.system(size: size * 0.42, weight: .semibold))
            .foregroundStyle(Color.brand)
            .frame(width: size, height: size)
            .background(shape.fill(SiteTile.fill))
            .overlay(shape.strokeBorder(SiteTile.stroke, lineWidth: 0.5))
            .accessibilityHidden(true)
    }
}
