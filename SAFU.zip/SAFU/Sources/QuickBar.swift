import SwiftUI

// MARK: - Главные кнопки в системной панели над вкладками (iOS 26)
//
// Та же стеклянная полоса, что у Музыки над вкладками. Когда при прокрутке вкладки сжимаются в кружок,
// полоса уезжает вправо рядом с ним — до Sakai и почты всегда дотягивается большой палец.

struct QuickAccessory: ViewModifier {
    let enabled: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *), enabled {
            content.tabViewBottomAccessory { QuickAccessoryBar() }
        } else {
            content
        }
        #else
        content
        #endif
    }
}

#if compiler(>=6.2)
@available(iOS 26.0, *)
private struct QuickAccessoryBar: View {
    @EnvironmentObject private var store: ResourceStore
    @Environment(\.tabViewBottomAccessoryPlacement) private var placement
    @AppStorage("home.quickPlace") private var quickPlace = QuickPlace.standard
    @ObservedObject private var arrange = ArrangeSession.shared

    var body: some View {
        let inline = placement == .inline
        HStack(spacing: 0) {
            ForEach(store.quick.prefix(inline ? 4 : 5)) { r in
                Button {
                    QuickOpen.open(r, store: store, origin: "bar:" + r.id.uuidString, radius: 12)
                } label: {
                    Group {
                        if inline {
                            Image(systemName: r.icon)
                                .font(.system(size: 17, weight: .semibold))
                        } else {
                            HStack(spacing: 6) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundStyle(Color.brand)
                                Text(r.title)
                                    .font(.footnote.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.75)
                            }
                        }
                    }
                    .background(OriginProbe(key: "bar:" + r.id.uuidString))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color.brand)
                .accessibilityLabel(r.title)
                .contextMenu {
                    Button { QuickOpen.open(r, store: store) } label: { Label("Открыть", systemImage: "arrow.up.right.square") }
                    Button { ArrangeSession.shared.enter(.quick) } label: {
                        Label("Изменить порядок", systemImage: "arrow.left.arrow.right")
                    }
                    Button { quickPlace = "homework" } label: { Label("Под домашкой на главной", systemImage: "book.closed") }
                    Button { quickPlace = "dock" } label: { Label("Закрепить внизу главной", systemImage: "pin") }
                    Button { quickPlace = "bottom" } label: { Label("Под погодой и автобусом", systemImage: "rectangle.stack") }
                    Button { quickPlace = "top" } label: { Label("Наверх главной", systemImage: "arrow.up.to.line") }
                }
                // удержал и тащишь — кнопки расступаются, как значки на рабочем столе iPhone
                .arrangeable("quick:" + r.id.uuidString, kind: .quick, amount: 2.4,
                             move: { QuickOrder.move(store, $0, $1) }) {
                    Image(systemName: r.icon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 52, height: 52)
                        .background(brandGradient, in: Circle())
                }
            }
            // пока кнопки покачиваются — «готово» прямо в полосе (на других вкладках нет верхней плашки)
            if arrange.editing == .quick {
                Button { arrange.done() } label: {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(Color.brand)
                        .frame(width: 40)
                        .frame(maxHeight: .infinity)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Готово")
                .transition(.scale.combined(with: .opacity))
            }
        }
        .arrangeDropZone(.quick)
        .animation(.spring(response: 0.31, dampingFraction: 0.82), value: store.quick.map(\.id))
        .animation(.spring(response: 0.28, dampingFraction: 0.85), value: arrange.editing)
        .padding(.horizontal, inline ? 6 : 10)
        // плашка свёрнутых сайтов следит, сжата ли панель, чтобы опускаться вместе с ней
        .onAppear { SiteTabs.shared.setBarInline(inline) }
        .onChange(of: inline) { _, now in SiteTabs.shared.setBarInline(now) }
    }
}
#endif
