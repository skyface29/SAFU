import SwiftUI

// MARK: - Главные кнопки в системной панели над вкладками (iOS 26)
//
// Та же стеклянная полоса, что у Музыки над вкладками. Когда при прокрутке вкладки сжимаются в кружок,
// полоса уезжает вправо рядом с ним — до Sakai и почты всегда дотягивается большой палец.

struct QuickAccessory: ViewModifier {
    let enabled: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *), enabled {
            content.tabViewBottomAccessory { QuickAccessoryBar() }
        } else {
            content
        }
        #else
        content
        #endif
    }
}

#if compiler(>=6.2)
@available(iOS 26.0, *)
private struct QuickAccessoryBar: View {
    @EnvironmentObject private var store: ResourceStore
    @Environment(\.tabViewBottomAccessoryPlacement) private var placement
    @AppStorage("home.quickPlace") private var quickPlace = QuickPlace.standard

    var body: some View {
        let inline = placement == .inline
        HStack(spacing: 0) {
            ForEach(store.quick.prefix(inline ? 4 : 5)) { r in
                Button {
                    QuickOpen.open(r, store: store)
                } label: {
                    Group {
                        if inline {
                            Image(systemName: r.icon)
                                .font(.system(size: 17, weight: .semibold))
                        } else {
                            HStack(spacing: 6) {
                                Image(systemName: r.icon)
                                    .font(.system(size: 15, weight: .semibold))
                                    .foregroundStyle(Color.brand)
                                Text(r.title)
                                    .font(.footnote.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.75)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color.brand)
                .accessibilityLabel(r.title)
                .contextMenu {
                    Button { QuickOpen.open(r, store: store) } label: { Label("Открыть", systemImage: "arrow.up.right.square") }
                    Button { quickPlace = "dock" } label: { Label("Закрепить внизу главной", systemImage: "pin") }
                    Button { quickPlace = "bottom" } label: { Label("Под погодой и автобусом", systemImage: "rectangle.stack") }
                    Button { quickPlace = "top" } label: { Label("Наверх главной", systemImage: "arrow.up.to.line") }
                }
            }
        }
        .padding(.horizontal, inline ? 6 : 10)
        // плашка свёрнутых сайтов следит, сжата ли панель, чтобы опускаться вместе с ней
        .onAppear { SiteTabs.shared.setBarInline(inline) }
        .onChange(of: inline) { _, now in SiteTabs.shared.setBarInline(now) }
    }
}
#endif
