import SwiftUI

struct InfoView: View {
    @AppStorage("group") private var group = "151621"
    @AppStorage("notes") private var notes = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Моя группа") {
                    TextField("Номер группы", text: $group)
                        .keyboardType(.numberPad)
                        .font(.title3.monospacedDigit())
                }

                Section("Полезно знать") {
                    InfoRow(icon: "calendar",
                            text: "Расписание 1–2 курса — в Модеусе, вкладка «Моё расписание».")
                    InfoRow(icon: "key.fill",
                            text: "Вход в почту и Модеус — адрес почты САФУ и пароль от учётной записи.")
                    InfoRow(icon: "person.badge.key.fill",
                            text: "Первокурсникам сначала нужно активировать учётную запись.")
                    InfoRow(icon: "hand.tap.fill",
                            text: "Входы на сайты сохраняются в приложении, заново вводить пароль обычно не нужно.")
                }

                Section("Поддержка") {
                    Link(destination: URL(string: "mailto:sakai@narfu.ru")!) {
                        Label("sakai@narfu.ru — активация, Sakai", systemImage: "envelope")
                    }
                    Link(destination: URL(string: "mailto:narfu@modeus.org")!) {
                        Label("narfu@modeus.org — проблемы с Модеусом", systemImage: "envelope")
                    }
                    Text("В письме укажи ФИО, номер группы и суть проблемы, приложи скриншот.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("Заметки") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 160)
                }
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Инфо")
        }
    }
}

private struct InfoRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Color.safuBlue)
                .frame(width: 24)
            Text(text)
        }
    }
}
