import SwiftUI

// MARK: - Свои плитки на главной
// Любая плитка: сайт, инструмент, предмет, вкладка, камера на доску, фото с пар или просто заметка-стикер.
// Цвет, значок, размер и порядок — свои. Удерживай плитку, чтобы изменить.

struct HomeTile: Codable, Identifiable, Hashable {
    enum Kind: String, Codable, CaseIterable, Identifiable {
        case link, tool, subject, tab, camera, boards, note
        var id: String { rawValue }
        var title: String {
            switch self {
            case .link: return "Сайт"
            case .tool: return "Инструмент"
            case .subject: return "Предмет"
            case .tab: return "Вкладка"
            case .camera: return "Фото доски"
            case .boards: return "Фото с пар"
            case .note: return "Стикер"
            }
        }
        var icon: String {
            switch self {
            case .link: return "link"
            case .tool: return "wrench.and.screwdriver.fill"
            case .subject: return "book.closed.fill"
            case .tab: return "square.grid.2x2.fill"
            case .camera: return "camera.fill"
            case .boards: return "photo.stack.fill"
            case .note: return "note.text"
            }
        }
    }

    var id = UUID()
    var title: String
    var icon: String
    var color: String = AccentTheme.blue.rawValue
    var kind: Kind
    var value: String = ""
    var wide = false

    var theme: AccentTheme { AccentTheme(rawValue: color) ?? .blue }
}

final class TileStore: ObservableObject {
    static let shared = TileStore()
    private let key = "home.tiles"

    @Published var tiles: [HomeTile] = [] { didSet { save() } }

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([HomeTile].self, from: raw) {
            tiles = list
        }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(tiles) { UserDefaults.standard.set(raw, forKey: key) }
    }

    func upsert(_ t: HomeTile) {
        if let i = tiles.firstIndex(where: { $0.id == t.id }) { tiles[i] = t } else { tiles.append(t) }
        // первая плитка — сам показываем блок на главной
        var order = HomeSection.parse(UserDefaults.standard.string(forKey: "home.order") ?? HomeSection.defaultRaw)
        if !order.contains(.tiles) {
            order.insert(.tiles, at: min(1, order.count))
            UserDefaults.standard.set(order.map(\.rawValue).joined(separator: ","), forKey: "home.order")
        }
    }

    func delete(_ t: HomeTile) { tiles.removeAll { $0.id == t.id } }

    func move(_ t: HomeTile, by delta: Int) {
        guard let i = tiles.firstIndex(where: { $0.id == t.id }) else { return }
        let j = max(0, min(tiles.count - 1, i + delta))
        guard i != j else { return }
        tiles.swapAt(i, j)
    }
}

// MARK: - Блок плиток на главной

struct HomeTilesGrid: View {
    @ObservedObject var store = TileStore.shared
    let columns: Int
    let onTap: (HomeTile) -> Void
    @State private var editing: HomeTile?
    @State private var isNew = false

    /// Ряды: широкая плитка — отдельный ряд, обычные — по `columns` в ряд
    private var rows: [[HomeTile]] {
        var out: [[HomeTile]] = []
        var cur: [HomeTile] = []
        for t in store.tiles {
            if t.wide {
                if !cur.isEmpty { out.append(cur); cur = [] }
                out.append([t])
            } else {
                cur.append(t)
                if cur.count == columns { out.append(cur); cur = [] }
            }
        }
        if !cur.isEmpty { out.append(cur) }
        return out
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                SectionTitle(text: "Мои плитки")
                Spacer()
                Button {
                    Haptics.tap()
                    isNew = true
                    editing = HomeTile(title: "", icon: "star.fill", color: AccentTheme.current.rawValue, kind: .link, value: "https://")
                } label: {
                    Image(systemName: "plus.circle.fill").font(.title3).foregroundStyle(brandGradient)
                }
            }
            if store.tiles.isEmpty {
                Text("Добавь свои плитки: любимый сайт, предмет, камеру на доску или стикер с напоминанием.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                HStack(spacing: 12) {
                    ForEach(row) { t in tileView(t) }
                    if !(row.first?.wide ?? false) && row.count < columns {
                        ForEach(0..<(columns - row.count), id: \.self) { _ in Color.clear.frame(maxWidth: .infinity) }
                    }
                }
            }
        }
        .sheet(item: $editing) { t in
            NavigationStack {
                TileEditor(tile: t, isNew: isNew)
            }
        }
    }

    private func tileView(_ t: HomeTile) -> some View {
        Button {
            Haptics.tap()
            if t.kind == .note { isNew = false; editing = t } else { onTap(t) }
        } label: {
            HomeTileLabel(tile: t)
        }
        .buttonStyle(PressableStyle())
        .contextMenu {
            Button { isNew = false; editing = t } label: { Label("Изменить", systemImage: "pencil") }
            Button {
                var c = t
                c.wide.toggle()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { store.upsert(c) }
            } label: {
                Label(t.wide ? "Сделать маленькой" : "Во всю ширину",
                      systemImage: t.wide ? "rectangle.split.2x1" : "rectangle")
            }
            Button { withAnimation { store.move(t, by: -1) } } label: { Label("Раньше", systemImage: "arrow.left") }
            Button { withAnimation { store.move(t, by: 1) } } label: { Label("Дальше", systemImage: "arrow.right") }
            Button(role: .destructive) { withAnimation { store.delete(t) } } label: { Label("Удалить", systemImage: "trash") }
        }
    }
}

struct HomeTileLabel: View {
    let tile: HomeTile

    var body: some View {
        let th = tile.theme
        if tile.kind == .note {
            VStack(alignment: .leading, spacing: 6) {
                Label(tile.title.isEmpty ? "Стикер" : tile.title, systemImage: tile.icon)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(th.color)
                Text(tile.value.isEmpty ? "Нажми, чтобы написать" : tile.value)
                    .font(.subheadline)
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(tile.wide ? 4 : 3)
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, minHeight: 86, alignment: .topLeading)
            .padding(12)
            .background(th.color.opacity(0.16), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(th.color.opacity(0.35), lineWidth: 1))
        } else {
            HStack(spacing: 10) {
                Image(systemName: tile.icon)
                    .font(.system(size: tile.wide ? 22 : 20, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 30)
                Text(tile.title)
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                    .multilineTextAlignment(.leading)
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, minHeight: tile.wide ? 58 : 70, alignment: .leading)
            .padding(12)
            .background(LinearGradient(colors: [th.color, th.secondary], startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }
}

// MARK: - Редактор плитки

struct TileEditor: View {
    @State var tile: HomeTile
    let isNew: Bool
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var store = TileStore.shared
    @State private var subjects: [String] = []

    static let icons = ["star.fill", "heart.fill", "bolt.fill", "flame.fill", "book.closed.fill", "graduationcap.fill",
                        "pencil", "doc.text.fill", "folder.fill", "camera.fill", "photo.stack.fill", "link",
                        "globe", "calendar", "clock.fill", "bell.fill", "checklist", "chart.bar.fill",
                        "function", "atom", "cpu", "laptopcomputer", "bus.fill", "cup.and.saucer.fill",
                        "music.note", "gamecontroller.fill", "person.2.fill", "bubble.left.fill", "paperplane.fill", "sparkles",
                        "note.text", "lightbulb.fill", "brain.head.profile", "leaf.fill", "snowflake", "mappin.and.ellipse"]

    private var canSave: Bool {
        switch tile.kind {
        case .link:
            guard let u = URL(string: tile.value), let sc = u.scheme?.lowercased() else { return false }
            return (sc == "http" || sc == "https") && u.host != nil
        case .tool: return Tool(rawValue: tile.value) != nil
        case .subject: return !tile.value.isEmpty
        case .tab: return AppTab(rawValue: tile.value) != nil
        case .camera, .boards, .note: return true
        }
    }

    var body: some View {
        Form {
            Section {
                HomeTileLabel(tile: displayTile)
                    .listRowInsets(EdgeInsets(top: 10, leading: 12, bottom: 10, trailing: 12))
                    .listRowBackground(Color.clear)
            }
            Section("Что делает") {
                Picker("Тип", selection: $tile.kind) {
                    ForEach(HomeTile.Kind.allCases) { k in Label(k.title, systemImage: k.icon).tag(k) }
                }
                .onChange(of: tile.kind) { k in applyDefaults(for: k) }
                switch tile.kind {
                case .link:
                    TextField("https://…", text: $tile.value)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                case .tool:
                    Picker("Инструмент", selection: $tile.value) {
                        ForEach(Tool.allCases) { t in Label(t.title, systemImage: t.icon).tag(t.rawValue) }
                    }
                    .onChange(of: tile.value) { v in
                        if let t = Tool(rawValue: v) { tile.title = t.title; tile.icon = t.icon }
                    }
                case .subject:
                    Picker("Предмет", selection: $tile.value) {
                        Text("Выбери").tag("")
                        ForEach(subjects, id: \.self) { Text($0).tag($0) }
                    }
                    .onChange(of: tile.value) { v in if !v.isEmpty { tile.title = v } }
                case .tab:
                    Picker("Вкладка", selection: $tile.value) {
                        ForEach(AppTab.allCases) { t in Label(t.title, systemImage: t.icon).tag(t.rawValue) }
                    }
                    .onChange(of: tile.value) { v in
                        if let t = AppTab(rawValue: v) { tile.title = t.title; tile.icon = t.icon }
                    }
                case .note:
                    TextEditor(text: $tile.value).frame(minHeight: 90)
                case .camera:
                    Text("Открывает камеру для текущей пары — фото ляжет в папку предмета по порядку.")
                        .font(.caption).foregroundStyle(.secondary)
                case .boards:
                    Text("Все пары с фото доски — открыть и отправить PDF группе.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            Section("Вид") {
                TextField("Название", text: $tile.title)
                Toggle("Во всю ширину", isOn: $tile.wide)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 40), spacing: 8)], spacing: 8) {
                    ForEach(Self.icons, id: \.self) { ic in
                        Image(systemName: ic)
                            .font(.system(size: 17, weight: .semibold))
                            .frame(width: 40, height: 40)
                            .foregroundStyle(tile.icon == ic ? Color.white : Color.primary)
                            .background(tile.icon == ic ? tile.theme.color : Color.primary.opacity(0.06),
                                        in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .onTapGesture { Haptics.tap(); tile.icon = ic }
                    }
                }
                .padding(.vertical, 4)
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 34), spacing: 10)], spacing: 10) {
                    ForEach(AccentTheme.allCases) { th in
                        Circle()
                            .fill(LinearGradient(colors: [th.color, th.secondary], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 30, height: 30)
                            .overlay(Circle().strokeBorder(Color.primary.opacity(tile.color == th.rawValue ? 0.8 : 0), lineWidth: 2).padding(-4))
                            .onTapGesture { Haptics.tap(); tile.color = th.rawValue }
                    }
                }
                .padding(.vertical, 4)
            }
            if !isNew {
                Section {
                    Button("Удалить плитку", role: .destructive) {
                        store.delete(tile)
                        dismiss()
                    }
                }
            }
        }
        .navigationTitle(isNew ? "Новая плитка" : "Плитка")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Готово") {
                    var t = tile
                    if t.title.trimmingCharacters(in: .whitespaces).isEmpty { t.title = defaultTitle }
                    store.upsert(t)
                    Haptics.success()
                    dismiss()
                }
                .fontWeight(.semibold)
                .disabled(!canSave)
            }
        }
        .onAppear { subjects = ScheduleQuery.subjects(SharedSchedule.load()) }
    }

    private var defaultTitle: String {
        switch tile.kind {
        case .link: return URL(string: tile.value)?.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт"
        default: return tile.kind.title
        }
    }

    private var displayTile: HomeTile {
        var t = tile
        if t.title.isEmpty { t.title = defaultTitle }
        return t
    }

    private func applyDefaults(for k: HomeTile.Kind) {
        tile.icon = k.icon
        switch k {
        case .link: tile.value = "https://"
        case .tool: tile.value = Tool.lectures.rawValue; tile.title = Tool.lectures.title; tile.icon = Tool.lectures.icon
        case .subject: tile.value = subjects.first ?? ""; tile.title = tile.value
        case .tab: tile.value = AppTab.schedule.rawValue; tile.title = AppTab.schedule.title; tile.icon = AppTab.schedule.icon
        case .camera: tile.value = ""; tile.title = "Сфоткать доску"
        case .boards: tile.value = ""; tile.title = "Фото с пар"
        case .note: tile.value = ""; tile.title = "Стикер"
        }
    }
}
