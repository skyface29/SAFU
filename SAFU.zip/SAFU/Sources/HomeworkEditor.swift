import SwiftUI
import PhotosUI

// MARK: - Редактор ДЗ
//
// Порядок как в жизни: с какой пары → что задали → когда сдавать.
// Всё, что можно угадать (пару, тип, срок), угадывается, но любую мелочь можно поменять.

struct HomeworkEditor: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = HomeworkStore.shared

    enum DueChoice: Hashable {
        case pair(skip: Int, kind: String)
        case tomorrow
        case week
        case custom
    }

    private let isNew: Bool
    private let original: Homework?
    @State private var hw: Homework
    @State private var slot: LessonSlot?
    @State private var subject: String
    @State private var day: Date
    @State private var due: DueChoice
    @State private var customDue: Date
    @State private var follow: Bool
    @State private var kindTouched: Bool
    /// При редактировании — якорь из записи, пока пару не поменяли
    @State private var keepAnchor: Date?
    @State private var anyTargets: [HWTarget] = []
    @State private var kindTargets: [HWTarget] = []
    @State private var showAllTargets = false
    @State private var newStep = ""
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showCamera = false
    @State private var addedPhotos: [String] = []
    @State private var removedPhotos: [String] = []
    @State private var preview: HWPhotoRef?
    @State private var askSubject = false
    @State private var subjectDraft = ""
    @State private var confirmDelete = false
    @State private var customReminder: Bool
    @State private var toast: String?
    @State private var savedCount = 0
    @FocusState private var textFocused: Bool
    @FocusState private var stepFocused: Bool

    @AppStorage("hw.eveningHour") private var eveningHour = 20
    @AppStorage("hw.eveningMinute") private var eveningMinute = 0
    @AppStorage("hw.morningHour") private var morningHour = 7
    @AppStorage("hw.morningMinute") private var morningMinute = 30

    init(route: HWEditorRoute, data: ScheduleData) {
        let cal = Calendar.current
        let tomorrowMorning: Date = {
            let t = cal.date(byAdding: .day, value: 1, to: Date()) ?? Date()
            return cal.date(bySettingHour: 8, minute: 0, second: 0, of: t) ?? t
        }()
        if let h = route.homework {
            isNew = false
            original = h
            _hw = State(initialValue: h)
            let s = h.fromPair ? HWPlanner.slot(subject: h.subject, start: h.givenAt, data: data) : nil
            _slot = State(initialValue: s)
            _subject = State(initialValue: h.subject)
            _day = State(initialValue: cal.startOfDay(for: h.fromPair ? h.givenAt : Date()))
            _due = State(initialValue: h.rule == .pair ? .pair(skip: h.skip, kind: h.matchKind) : .custom)
            _customDue = State(initialValue: h.due)
            _follow = State(initialValue: h.follow)
            _kindTouched = State(initialValue: true)
            _keepAnchor = State(initialValue: h.rule == .pair ? h.anchor : nil)
            _customReminder = State(initialValue: h.reminders.custom != nil)
        } else {
            isNew = true
            original = nil
            let s = route.slot ?? (route.subject == nil ? HWPlanner.suggestedSlot(data) : nil)
            let subj = s?.lesson.subject ?? route.subject ?? ""
            var h = Homework(subject: subj, text: "", due: tomorrowMorning)
            h.reminders = .defaults
            _hw = State(initialValue: h)
            _slot = State(initialValue: s)
            _subject = State(initialValue: subj)
            _day = State(initialValue: cal.startOfDay(for: s?.start ?? Date()))
            _due = State(initialValue: HomeworkEditor.defaultChoice(slot: s))
            _customDue = State(initialValue: tomorrowMorning)
            _follow = State(initialValue: HWPrefs.follow)
            _kindTouched = State(initialValue: false)
            _keepAnchor = State(initialValue: nil)
            _customReminder = State(initialValue: false)
        }
    }

    static func defaultChoice(slot: LessonSlot?) -> DueChoice {
        switch HWPrefs.defaultDue {
        case "nextSame": return .pair(skip: 0, kind: slot.map { KindStyle.of($0.lesson.kind).label } ?? "")
        case "skip1": return .pair(skip: 1, kind: "")
        case "tomorrow": return .tomorrow
        case "week": return .week
        default: return .pair(skip: 0, kind: "")
        }
    }

    // MARK: вычисления

    private var trimmedSubject: String { subject.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var trimmedText: String { hw.text.trimmingCharacters(in: .whitespacesAndNewlines) }

    private var canSave: Bool {
        !trimmedText.isEmpty || hw.steps.contains { !$0.text.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    private var hasChanges: Bool {
        isNew ? (canSave || !addedPhotos.isEmpty) : true
    }

    private var slotInFuture: Bool { slot.map { $0.start > Date() } ?? false }

    private var anchor: Date {
        if let keepAnchor { return keepAnchor }
        guard let s = slot else { return Date() }
        // пара ещё впереди — ДЗ к ней самой; идёт или прошла — к следующей после неё
        return s.start > Date() ? s.start.addingTimeInterval(-60) : s.end
    }

    private var isPairChoice: Bool {
        if case .pair = due { return true }
        return false
    }

    private var choiceSkip: Int {
        if case .pair(let skip, _) = due { return skip }
        return 0
    }

    private var choiceKind: String {
        if case .pair(_, let kind) = due { return kind }
        return ""
    }

    private var currentTargets: [HWTarget] { choiceKind.isEmpty ? anyTargets : kindTargets }

    private var resolvedTarget: HWTarget? {
        guard isPairChoice, currentTargets.count > choiceSkip else { return nil }
        return currentTargets[choiceSkip]
    }

    private var resolvedDue: Date {
        let cal = Calendar.current
        switch due {
        case .pair:
            if let t = resolvedTarget { return t.start }
            return weekLater
        case .tomorrow:
            let t = cal.date(byAdding: .day, value: 1, to: Date()) ?? Date()
            // к первой паре завтра, если она есть, иначе к 8:00
            if let first = ScheduleEngine.slots(on: t, data: schedule.data).first { return first.start }
            return cal.date(bySettingHour: 8, minute: 0, second: 0, of: t) ?? t
        case .week:
            return weekLater
        case .custom:
            return customDue
        }
    }

    private var weekLater: Date {
        let cal = Calendar.current
        if let s = slot {
            return cal.date(byAdding: .day, value: 7, to: s.start) ?? s.start
        }
        let d = cal.date(byAdding: .day, value: 7, to: Date()) ?? Date()
        return cal.date(bySettingHour: 23, minute: 59, second: 0, of: d) ?? d
    }

    /// Типы пар, которые у предмета есть впереди (для «к практике», «к лекции»)
    private var kindOptions: [String] {
        var out: [String] = []
        for t in anyTargets {
            let label = KindStyle.of(t.kind).label
            if !out.contains(label) { out.append(label) }
        }
        return out.count > 1 ? out : []
    }

    private func kindChipTitle(_ label: String) -> String {
        switch label {
        case "Лекция": return "К лекции"
        case "Практика": return "К практике"
        case "Лабораторная": return "К лабораторной"
        case "Семинар": return "К семинару"
        case "Консультация": return "К консультации"
        case "Зачёт": return "К зачёту"
        case "Экзамен": return "К экзамену"
        default: return "К «\(label)»"
        }
    }

    private func refreshTargets() {
        let data = schedule.data
        anyTargets = HWPlanner.targets(subject: trimmedSubject, after: anchor, kind: nil, data: data, limit: 10)
        if !choiceKind.isEmpty {
            kindTargets = HWPlanner.targets(subject: trimmedSubject, after: anchor, kind: choiceKind, data: data, limit: 8)
        } else {
            kindTargets = []
        }
    }

    // MARK: экран

    var body: some View {
        NavigationStack {
            ZStack {
                AmbientBackground()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 16) {
                        pairCard
                        textCard
                        dueCard
                        remindCard
                        extraCard
                        if !isNew { manageCard }
                        if isNew {
                            Button(action: saveAndNext) {
                                Label("Сохранить и записать ещё", systemImage: "plus.square.on.square")
                                    .font(.subheadline.weight(.semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 13)
                                    .glass(18, interactive: true)
                            }
                            .buttonStyle(PressableStyle())
                            .disabled(!canSave)
                            .opacity(canSave ? 1 : 0.5)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .padding(.bottom, 40)
                }
                .scrollDismissesKeyboard(.interactively)

                if let toast {
                    VStack {
                        Spacer()
                        Label(toast, systemImage: "checkmark.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 11)
                            .glass(22)
                            .padding(.bottom, 24)
                    }
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .allowsHitTesting(false)
                }
            }
            .navigationTitle(isNew ? (savedCount > 0 ? "Ещё ДЗ" : "Новое ДЗ") : "ДЗ")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(savedCount > 0 && !canSave ? "Готово" : "Отмена") { cancel() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") { save() }
                        .fontWeight(.semibold)
                        .disabled(!canSave)
                }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Скрыть") {
                        textFocused = false
                        stepFocused = false
                    }
                }
            }
            .onAppear {
                refreshTargets()
                if isNew {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { textFocused = true }
                }
            }
            .onChange(of: subject) { refreshTargets() }
            .onChange(of: slot) { refreshTargets() }
            .onChange(of: due) { refreshTargets() }
            .onChange(of: hw.text) {
                guard !kindTouched, HWPrefs.guessKind, let g = HWKind.guess(hw.text) else { return }
                hw.kind = g
            }
            .onChange(of: customReminder) {
                if customReminder {
                    if hw.reminders.custom == nil { hw.reminders.custom = defaultCustomReminder }
                } else {
                    hw.reminders.custom = nil
                }
            }
            .onChange(of: photoItems) { loadPhotos() }
            .alert("Предмет", isPresented: $askSubject) {
                TextField("Название предмета", text: $subjectDraft)
                Button("Готово") { chooseSubject(subjectDraft) }
                Button("Отмена", role: .cancel) {}
            } message: {
                Text("Если предмета нет в расписании")
            }
            .confirmationDialog("Удалить это ДЗ?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) {
                    store.delete(hw)
                    dismiss()
                }
            }
            .fullScreenCover(isPresented: $showCamera) {
                CameraPicker { image in
                    showCamera = false
                    if let image, let name = HWFiles.save(image, for: hw.id) {
                        hw.photos.append(name)
                        addedPhotos.append(name)
                        Haptics.success()
                    }
                }
                .ignoresSafeArea()
            }
            .sheet(item: $preview) { ref in
                HWPhotoViewer(ref: ref)
            }
        }
        .interactiveDismissDisabled(isNew && hasChanges)
    }

    // MARK: карточки

    private func card<Content: View>(_ title: String, icon: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(title, systemImage: icon)
                .font(.footnote.weight(.bold))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func chip(_ title: String, icon: String? = nil, selected: Bool, color: Color = .brand,
                      action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            HStack(spacing: 5) {
                if let icon { Image(systemName: icon) }
                Text(title).lineLimit(1)
            }
            .font(.subheadline.weight(.semibold))
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .foregroundStyle(selected ? Color.white : Color.primary)
            .background(selected ? AnyShapeStyle(color.gradient) : AnyShapeStyle(Color.primary.opacity(0.07)), in: Capsule())
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: 1. С какой пары

    private var stripDays: [Date] {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        return (-14...14).compactMap { cal.date(byAdding: .day, value: $0, to: today) }
    }

    private var pairCard: some View {
        card("С какой пары", icon: "calendar") {
            if let s = slot {
                selectedPair(s)
            } else if !trimmedSubject.isEmpty {
                HStack(spacing: 10) {
                    Circle().fill(SubjectColor.color(for: trimmedSubject)).frame(width: 10, height: 10)
                    Text(trimmedSubject).font(.headline).lineLimit(2)
                    Spacer()
                    Text("без пары").font(.caption).foregroundStyle(.secondary)
                }
            }

            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(stripDays, id: \.self) { d in
                            dayPill(d).id(d)
                        }
                    }
                    .padding(.vertical, 2)
                }
                .onAppear { proxy.scrollTo(day, anchor: .center) }
            }

            dayPairs

            Menu {
                Section("Предметы из расписания") {
                    ForEach(ScheduleQuery.subjects(schedule.data), id: \.self) { s in
                        Button(s) { chooseSubject(s) }
                    }
                }
                Button {
                    subjectDraft = trimmedSubject
                    askSubject = true
                } label: {
                    Label("Свой предмет…", systemImage: "pencil")
                }
                if slot != nil {
                    Button(role: .destructive) {
                        slot = nil
                        keepAnchor = nil
                    } label: {
                        Label("Не привязывать к паре", systemImage: "link.badge.plus")
                    }
                }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "books.vertical.fill").foregroundStyle(brandGradient)
                    Text(slot == nil && trimmedSubject.isEmpty ? "Без пары — выбрать предмет" : "Другой предмет или без пары")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                    Spacer()
                    Image(systemName: "chevron.up.chevron.down").font(.caption).foregroundStyle(.tertiary)
                }
                .padding(12)
                .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }

    private func selectedPair(_ s: LessonSlot) -> some View {
        let color = SubjectColor.color(for: s.lesson.subject)
        return HStack(spacing: 12) {
            Capsule().fill(color.gradient).frame(width: 5)
            VStack(alignment: .leading, spacing: 5) {
                Text(s.lesson.subject)
                    .font(.system(.headline, design: .rounded))
                    .lineLimit(2)
                HStack(spacing: 6) {
                    KindBadge(kind: s.lesson.kind, size: 9)
                    Text(pairWhen(s))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func pairWhen(_ s: LessonSlot) -> String {
        let now = Date()
        if s.start <= now && s.end > now { return "идёт сейчас · \(hmString(s.start))" }
        return HWFormat.dayTime(s.start)
    }

    private func dayPill(_ d: Date) -> some View {
        let cal = Calendar.current
        let selected = cal.isDate(d, inSameDayAs: day)
        let isToday = cal.isDateInToday(d)
        let hasPairs = !ScheduleEngine.slots(on: d, data: schedule.data).isEmpty
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { day = d }
        } label: {
            VStack(spacing: 3) {
                Text(Fmt.formatter("EE").string(from: d).lowercased())
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(selected ? Color.white.opacity(0.85) : Color.secondary)
                Text("\(cal.component(.day, from: d))")
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(selected ? Color.white : Color.primary)
                Circle()
                    .fill(selected ? Color.white : Color.brand)
                    .frame(width: 5, height: 5)
                    .opacity(hasPairs ? 1 : 0)
            }
            .frame(width: 44, height: 62)
            .background(selected ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.05)),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(Color.brand, lineWidth: isToday && !selected ? 1.5 : 0)
            )
        }
        .buttonStyle(PressableStyle())
    }

    @ViewBuilder
    private var dayPairs: some View {
        let list = ScheduleEngine.slots(on: day, data: schedule.data)
        if list.isEmpty {
            Text(Calendar.current.isDateInToday(day) ? "Сегодня пар нет" : "В этот день пар нет")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.vertical, 8)
        } else {
            VStack(spacing: 8) {
                ForEach(list, id: \.key) { s in
                    pairRow(s)
                }
            }
        }
    }

    private func pairRow(_ s: LessonSlot) -> some View {
        let selected = slot?.key == s.key
        let color = SubjectColor.color(for: s.lesson.subject)
        let now = Date()
        let live = s.start <= now && s.end > now
        let open = store.openCount(subject: s.lesson.subject)
        return Button {
            select(s)
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(hmString(s.start)).font(.subheadline.weight(.bold)).monospacedDigit()
                    Text(hmString(s.end)).font(.caption2).foregroundStyle(.secondary).monospacedDigit()
                }
                .frame(width: 44, alignment: .leading)
                Capsule().fill(color.gradient).frame(width: 4)
                VStack(alignment: .leading, spacing: 4) {
                    Text(s.lesson.subject)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2)
                    HStack(spacing: 6) {
                        KindBadge(kind: s.lesson.kind, size: 9)
                        if live {
                            Text("СЕЙЧАС").font(.caption2.weight(.heavy)).foregroundStyle(color)
                        } else if !s.lesson.room.isEmpty {
                            Text("ауд. \(s.lesson.room)").font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                }
                Spacer(minLength: 4)
                if selected {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.title3)
                        .foregroundStyle(brandGradient)
                } else if open > 0 {
                    Text("ДЗ \(open)")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.primary.opacity(0.07), in: Capsule())
                }
            }
            .padding(10)
            .background(selected ? color.opacity(0.16) : Color.primary.opacity(0.04),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(selected ? color : Color.clear, lineWidth: 1.5)
            )
            .opacity(s.end < now || selected ? 1 : 0.8)
        }
        .buttonStyle(PressableStyle())
    }

    private func select(_ s: LessonSlot) {
        Haptics.tap()
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
            let changedSubject = HWPlanner.key(s.lesson.subject) != HWPlanner.key(subject)
            slot = s
            subject = s.lesson.subject
            keepAnchor = nil
            if changedSubject, case .pair(_, let k) = due, !k.isEmpty {
                due = .pair(skip: 0, kind: "")
            }
        }
    }

    private func chooseSubject(_ raw: String) {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return }
        Haptics.tap()
        subject = s
        keepAnchor = nil
        // последняя прошедшая пара этого предмета за неделю — от неё и считаем «следующую»
        let past = ScheduleQuery.slots(schedule.data, from: -7, days: 8)
            .filter { HWPlanner.key($0.lesson.subject) == HWPlanner.key(s) && $0.start <= Date() }
            .max { $0.start < $1.start }
        slot = past
        if let past { day = Calendar.current.startOfDay(for: past.start) }
        if case .pair(_, let k) = due, !k.isEmpty { due = .pair(skip: 0, kind: "") }
    }

    // MARK: 2. Что задали

    private let inserts = ["№ ", "стр. ", "§ ", "упр. ", "задачи ", "вопросы ", "до конца главы"]

    private var textCard: some View {
        card("Что задали", icon: "text.book.closed.fill") {
            TextField("Например: № 245–250, прочитать § 3", text: $hw.text, axis: .vertical)
                .font(.body)
                .lineLimit(2...10)
                .focused($textFocused)
                .padding(12)
                .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(inserts, id: \.self) { s in
                        Button {
                            insert(s)
                        } label: {
                            Text(s.trimmingCharacters(in: .whitespaces))
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.primary.opacity(0.07), in: Capsule())
                        }
                        .buttonStyle(PressableStyle())
                    }
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Тип")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    if !kindTouched && HWPrefs.guessKind && !trimmedText.isEmpty {
                        Text("· угадал по тексту").font(.caption).foregroundStyle(.tertiary)
                    }
                }
                HWFlow(spacing: 6) {
                    ForEach(HWKind.allCases) { k in
                        chip(k.title, icon: k.icon, selected: hw.kind == k, color: k.color) {
                            hw.kind = k
                            kindTouched = true
                        }
                    }
                }
            }

            stepsEditor
        }
    }

    private func insert(_ s: String) {
        Haptics.tap()
        var t = hw.text
        if let last = t.last, last != " " && last != "\n" { t += " " }
        t += s
        hw.text = t
        textFocused = true
    }

    private var canSplit: Bool {
        let t = trimmedText
        return t.contains("\n") || t.contains(";")
    }

    private var stepsEditor: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(hw.steps.isEmpty ? "Разбить на пункты" : "Пункты · \(hw.steps.filter(\.done).count)/\(hw.steps.count)")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                if canSplit {
                    Button("Из текста по строкам") { splitText() }
                        .font(.caption.weight(.semibold))
                }
            }
            ForEach($hw.steps) { $step in
                HStack(spacing: 10) {
                    Button {
                        Haptics.tap()
                        step.done.toggle()
                    } label: {
                        Image(systemName: step.done ? "checkmark.circle.fill" : "circle")
                            .font(.title3)
                            .foregroundStyle(step.done ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary))
                    }
                    .buttonStyle(.plain)
                    TextField("Пункт", text: $step.text, axis: .vertical)
                        .lineLimit(1...4)
                        .strikethrough(step.done)
                    Button {
                        removeStep(step.id)
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(.tertiary)
                    }
                    .buttonStyle(.plain)
                }
            }
            HStack(spacing: 10) {
                Image(systemName: "plus.circle.fill")
                    .font(.title3)
                    .foregroundStyle(brandGradient)
                TextField("Добавить пункт: № 245, § 3…", text: $newStep)
                    .focused($stepFocused)
                    .submitLabel(.next)
                    .onSubmit {
                        addStep()
                        stepFocused = true
                    }
                if !newStep.trimmingCharacters(in: .whitespaces).isEmpty {
                    Button("Добавить") { addStep() }
                        .font(.caption.weight(.semibold))
                }
            }
        }
        .padding(12)
        .background(Color.primary.opacity(0.04), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func addStep() {
        let t = newStep.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        withAnimation { hw.steps.append(HWStep(text: t)) }
        newStep = ""
        Haptics.tap()
    }

    private func removeStep(_ id: UUID) {
        withAnimation { hw.steps.removeAll { $0.id == id } }
    }

    private func splitText() {
        let parts = hw.text
            .components(separatedBy: CharacterSet(charactersIn: "\n;"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        guard parts.count >= 2 else { return }
        Haptics.success()
        withAnimation {
            hw.steps.append(contentsOf: parts.map { HWStep(text: $0) })
            hw.text = ""
        }
    }

    // MARK: 3. Когда сдавать

    private var dueCard: some View {
        card("Когда сдавать", icon: "flag.checkered") {
            HWFlow(spacing: 6) {
                chip(slotInFuture ? "К этой паре" : "К следующей паре",
                     icon: "arrow.right.circle.fill",
                     selected: due == .pair(skip: 0, kind: "")) { due = .pair(skip: 0, kind: "") }
                ForEach(kindOptions, id: \.self) { label in
                    chip(kindChipTitle(label), selected: choiceKind == label && choiceSkip == 0,
                         color: KindStyle.of(label).color) { due = .pair(skip: 0, kind: label) }
                }
                chip("Через одну пару", selected: due == .pair(skip: 1, kind: "")) { due = .pair(skip: 1, kind: "") }
                chip("Завтра", selected: due == .tomorrow) { due = .tomorrow }
                chip("Через неделю", selected: due == .week) { due = .week }
                chip("Дата", icon: "calendar", selected: due == .custom) {
                    if due != .custom { customDue = resolvedDue }
                    due = .custom
                }
            }

            dueSummary

            if due == .custom {
                DatePicker("Сдать до", selection: $customDue, in: Date()...)
                    .font(.subheadline.weight(.semibold))
            }

            if isPairChoice && currentTargets.count > 1 {
                DisclosureGroup(isExpanded: $showAllTargets) {
                    VStack(spacing: 6) {
                        ForEach(Array(currentTargets.enumerated()), id: \.element.id) { i, t in
                            Button {
                                Haptics.tap()
                                due = .pair(skip: i, kind: choiceKind)
                            } label: {
                                HStack(spacing: 8) {
                                    KindBadge(kind: t.kind, size: 9)
                                    Text(HWFormat.dayTime(t.start))
                                        .font(.subheadline)
                                        .foregroundStyle(.primary)
                                    if t.estimated {
                                        Text("≈").font(.subheadline.weight(.bold)).foregroundStyle(.orange)
                                    }
                                    Spacer()
                                    if i == choiceSkip {
                                        Image(systemName: "checkmark").font(.subheadline.weight(.bold)).foregroundStyle(Color.brand)
                                    }
                                }
                                .padding(.vertical, 6)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.top, 6)
                } label: {
                    Text("Выбрать другую пару")
                        .font(.subheadline.weight(.semibold))
                }
                .tint(Color.primary)
            }

            if isPairChoice && resolvedTarget != nil {
                Toggle(isOn: $follow) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Следить за расписанием").font(.subheadline.weight(.semibold))
                        Text("Перенесут или отменят пару — срок переедет вместе с ней")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(Color.brand)
            }
        }
    }

    private var dueSummary: some View {
        let d = resolvedDue
        let t = resolvedTarget
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(HWFormat.dayTime(d).capitalizedFirst)
                    .font(.system(.title3, design: .rounded).weight(.bold))
                Spacer()
                Text(Fmt.relative(d))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(HWFormat.urgency(d))
            }
            if let t {
                HStack(spacing: 6) {
                    KindBadge(kind: t.kind, size: 9)
                    if !t.room.isEmpty {
                        Text("ауд. \(t.room)").font(.caption).foregroundStyle(.secondary)
                    }
                    if !trimmedSubject.isEmpty {
                        Text(trimmedSubject).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
                if t.estimated {
                    Label("Примерно: РУЗ ещё не выложил эту неделю, посчитал по прошлым. Уточнится само.",
                          systemImage: "wand.and.stars")
                        .font(.caption)
                        .foregroundStyle(.orange)
                } else {
                    Label(schedule.data.usesRuz ? "По расписанию РУЗ" : "По твоему расписанию",
                          systemImage: "checkmark.seal.fill")
                        .font(.caption)
                        .foregroundStyle(.green)
                }
            } else if isPairChoice {
                Label(trimmedSubject.isEmpty
                      ? "Выбери пару или предмет — посчитаю срок по расписанию"
                      : "Пар по предмету впереди не нашёл — пока через неделю",
                      systemImage: "exclamationmark.triangle.fill")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(HWFormat.urgency(d).opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    // MARK: 4. Напоминания

    private func clock(_ h: Int, _ m: Int) -> String { String(format: "%d:%02d", h, m) }

    private var defaultCustomReminder: Date {
        let d = resolvedDue.addingTimeInterval(-2 * 3600)
        return d > Date() ? d : Date().addingTimeInterval(3600)
    }

    private var customReminderBinding: Binding<Date> {
        Binding(get: { hw.reminders.custom ?? defaultCustomReminder },
                set: { hw.reminders.custom = $0 })
    }

    private var remindCard: some View {
        card("Напоминания", icon: "bell.badge.fill") {
            Toggle("Вечером накануне, в \(clock(eveningHour, eveningMinute))", isOn: $hw.reminders.evening)
            Toggle("Утром в день сдачи, в \(clock(morningHour, morningMinute))", isOn: $hw.reminders.morning)
            if !HWFormat.isEndOfDay(resolvedDue) {
                Toggle("За час до срока", isOn: $hw.reminders.hourBefore)
            }
            Toggle("В своё время", isOn: $customReminder)
            if customReminder {
                DatePicker("Когда", selection: customReminderBinding, in: Date()...)
            }
            Text("Время «вечером» и «утром» меняется в настройках домашки")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .tint(Color.brand)
        .font(.subheadline)
    }

    // MARK: 5. Ещё

    private var extraCard: some View {
        card("Ещё", icon: "ellipsis.circle.fill") {
            Toggle(isOn: $hw.important) {
                Label("Важное", systemImage: "star.fill")
                    .font(.subheadline.weight(.semibold))
            }
            .tint(.orange)

            TextField("Заметка: что взять, у кого спросить, ссылка…", text: $hw.note, axis: .vertical)
                .font(.subheadline)
                .lineLimit(1...6)
                .padding(12)
                .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            Text("Фото: доска, страница учебника, скрин из чата")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    Button { showCamera = true } label: { addTile(icon: "camera.fill", title: "Камера") }
                        .buttonStyle(PressableStyle())
                    PhotosPicker(selection: $photoItems, maxSelectionCount: 10, matching: .images) {
                        addTile(icon: "photo.on.rectangle", title: "Галерея")
                    }
                    .buttonStyle(PressableStyle())
                    ForEach(hw.photos, id: \.self) { name in
                        thumb(name)
                    }
                }
                .padding(.vertical, 2)
            }
        }
    }

    private func addTile(icon: String, title: String) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.title3).foregroundStyle(brandGradient)
            Text(title).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
        }
        .frame(width: 70, height: 70)
        .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func thumb(_ name: String) -> some View {
        HWThumb(id: hw.id, name: name, size: 70)
            .onTapGesture { preview = HWPhotoRef(owner: hw.id, name: name) }
            .contextMenu {
                Button(role: .destructive) { removePhoto(name) } label: { Label("Убрать фото", systemImage: "trash") }
            }
    }

    private func removePhoto(_ name: String) {
        withAnimation { hw.photos.removeAll { $0 == name } }
        if let i = addedPhotos.firstIndex(of: name) {
            addedPhotos.remove(at: i)
            HWFiles.remove(hw.id, name)
        } else {
            removedPhotos.append(name)
        }
    }

    private func loadPhotos() {
        let items = photoItems
        guard !items.isEmpty else { return }
        let id = hw.id
        Task { @MainActor in
            for item in items {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let img = UIImage(data: data),
                   let name = HWFiles.save(img, for: id) {
                    hw.photos.append(name)
                    addedPhotos.append(name)
                }
            }
            photoItems = []
            Haptics.success()
        }
    }

    // MARK: 6. Управление (для записанного ДЗ)

    private var manageCard: some View {
        card("Состояние", icon: "checkmark.circle.fill") {
            Toggle(isOn: $hw.done) {
                Label("Сделано", systemImage: "checkmark.seal.fill")
                    .font(.subheadline.weight(.semibold))
            }
            .tint(.green)

            if !hw.shiftNote.isEmpty {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "arrow.triangle.2.circlepath").foregroundStyle(.orange)
                    Text(hw.shiftNote).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button("Понятно") { hw.shiftNote = "" }.font(.caption.weight(.semibold))
                }
            }

            Text("Записано \(HWFormat.dayTime(hw.created))")
                .font(.caption)
                .foregroundStyle(.tertiary)

            Button(role: .destructive) {
                confirmDelete = true
            } label: {
                Label("Удалить ДЗ", systemImage: "trash")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(PressableStyle())
        }
    }

    // MARK: сохранение

    private func build() -> Homework {
        var h = hw
        h.subject = trimmedSubject
        h.text = trimmedText
        h.steps = hw.steps
            .map { HWStep(id: $0.id, text: $0.text.trimmingCharacters(in: .whitespacesAndNewlines), done: $0.done) }
            .filter { !$0.text.isEmpty }
        if let s = slot {
            h.fromPair = true
            h.givenAt = s.start
            h.givenKind = s.lesson.kind
        } else if keepAnchor == nil {
            h.fromPair = false
            if isNew { h.givenAt = Date() }
        }
        switch due {
        case .pair(let skip, let kind):
            if let t = resolvedTarget {
                h.rule = .pair
                h.anchor = anchor
                h.skip = skip
                h.matchKind = kind
                h.follow = follow
                h.due = t.start
                h.dueKind = t.kind
                h.dueRoom = t.room
                h.dueEstimated = t.estimated
            } else {
                h.rule = .date
                h.due = resolvedDue
                h.follow = false
                h.dueKind = ""
                h.dueRoom = ""
                h.dueEstimated = false
            }
        default:
            h.rule = .date
            h.due = resolvedDue
            h.dueKind = ""
            h.dueRoom = ""
            h.dueEstimated = false
        }
        if let o = original, abs(o.due.timeIntervalSince(h.due)) > 60 { h.shiftNote = "" }
        if !customReminder { h.reminders.custom = nil }
        if h.done {
            if h.doneAt == nil { h.doneAt = Date() }
        } else {
            h.doneAt = nil
        }
        return h
    }

    private func save() {
        let h = build()
        for n in removedPhotos { HWFiles.remove(h.id, n) }
        store.upsert(h)
        Haptics.success()
        dismiss()
    }

    /// Несколько заданий подряд с одной пары: пара и срок остаются, текст очищается
    private func saveAndNext() {
        let h = build()
        store.upsert(h)
        Haptics.success()
        savedCount += 1
        var n = Homework(subject: h.subject, text: "", due: h.due)
        n.reminders = h.reminders
        n.reminders.custom = nil
        hw = n
        kindTouched = false
        customReminder = false
        addedPhotos = []
        removedPhotos = []
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { toast = "Записал. Можно следующее" }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation { toast = nil } }
        textFocused = true
    }

    private func cancel() {
        if isNew {
            HWFiles.removeAll(hw.id)
        } else {
            for n in addedPhotos { HWFiles.remove(hw.id, n) }
        }
        dismiss()
    }
}
