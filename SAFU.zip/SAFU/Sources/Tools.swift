import SwiftUI
import UIKit
import MapKit
import CoreLocation
import QuickLook
import UserNotifications
import PhotosUI
import VisionKit

// MARK: - Список инструментов

enum Tool: String, Identifiable, CaseIterable {
    case attendance, broadcast, polls, subjects, session, grades, share, stats, teachers, map, focus, report

    var id: String { rawValue }

    var title: String {
        switch self {
        case .attendance: return "Посещаемость"
        case .broadcast: return "Рассылка"
        case .grades: return "БРС"
        case .polls: return "Опросы"
        case .share: return "Картинкой"
        case .stats: return "Статистика"
        case .subjects: return "Предметы"
        case .session: return "Сессия"
        case .teachers: return "Преподаватели"
        case .map: return "Карта корпусов"
        case .focus: return "Фокус"
        case .report: return "Титульник"
        }
    }

    var subtitle: String {
        switch self {
        case .attendance: return "Отметки группы"
        case .broadcast: return "Сообщение группе"
        case .grades: return "Баллы и прогноз"
        case .polls: return "Кто что ответил"
        case .share: return "Пары в чат группы"
        case .stats: return "Итоги семестра"
        case .subjects: return "Заметки и файлы"
        case .session: return "Билеты и отсчёт"
        case .teachers: return "Кто, где, когда"
        case .map: return "Где твои пары"
        case .focus: return "Помодоро-таймер"
        case .report: return "По СТО САФУ, .docx"
        }
    }

    var icon: String {
        switch self {
        case .attendance: return "person.crop.circle.badge.checkmark"
        case .broadcast: return "megaphone.fill"
        case .grades: return "star.leadinghalf.filled"
        case .polls: return "chart.bar.doc.horizontal.fill"
        case .share: return "photo.on.rectangle.angled"
        case .stats: return "chart.bar.fill"
        case .subjects: return "books.vertical.fill"
        case .session: return "graduationcap.fill"
        case .teachers: return "person.2.fill"
        case .map: return "map.fill"
        case .focus: return "timer"
        case .report: return "doc.richtext.fill"
        }
    }
}

struct ToolsGrid: View {
    let onOpen: (Tool) -> Void
    @AppStorage("user.role") private var role = 0
    @AppStorage("tools.rev") private var rev = ""

    private var visibleTools: [Tool] {
        Tool.allCases.filter { t in
            if role == 0 && (t == .attendance || t == .broadcast) { return false }
            return FeatureFlags.toolOn(t)
        }
    }
    private let columns = [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)]

    var body: some View {
        let _ = rev
        VStack(alignment: .leading, spacing: 12) {
            SectionTitle(text: "Инструменты")
            LazyVGrid(columns: columns, spacing: 12) {
                ForEach(visibleTools) { t in
                    Button { Haptics.tap(); onOpen(t) } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            Image(systemName: t.icon)
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundStyle(brandGradient)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(t.title)
                                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.8)
                                Text(t.subtitle)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.8)
                            }
                        }
                        .frame(maxWidth: .infinity, minHeight: 78, alignment: .leading)
                        .padding(12)
                        .glass(20, interactive: true)
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
    }
}

struct ToolSheet: View {
    let tool: Tool
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            content
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Готово") { dismiss() }
                    }
                }
        }
    }

    @ViewBuilder private var content: some View {
        switch tool {
        case .attendance: AttendanceView()
        case .broadcast: BroadcastView()
        case .polls: PollsView()
        case .share: ScheduleShareView()
        case .grades: BRSView()
        case .stats: StatsView()
        case .subjects: SubjectsView()
        case .session: SessionView()
        case .teachers: TeachersView()
        case .map: CampusMapView()
        case .focus: FocusView()
        case .report: ReportView()
        }
    }
}

// MARK: - Общие выборки из расписания

enum ScheduleQuery {
    /// Все пары в диапазоне дней от сегодня
    static func slots(_ data: ScheduleData, from: Int = 0, days: Int) -> [LessonSlot] {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        var out: [LessonSlot] = []
        for offset in from..<(from + days) {
            guard let d = cal.date(byAdding: .day, value: offset, to: today) else { continue }
            out += ScheduleEngine.slots(on: d, data: data)
        }
        return out
    }

    static func subjects(_ data: ScheduleData) -> [String] {
        var set = Set<String>()
        if data.usesRuz {
            for e in data.ruzEvents {
                let c = ScheduleCache.shared.clean(e.subject).subject
                if !c.isEmpty { set.insert(c) }
            }
        } else {
            for l in data.lessons { set.insert(l.subject) }
        }
        return set.filter { !$0.isEmpty }.sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }
}

/// Значок для предмета по ключевым словам
enum SubjectIcon {
    static func name(for subject: String) -> String {
        let s = subject.lowercased()
        let map: [(String, String)] = [
            ("алгебр", "function"), ("геометр", "triangle"), ("анализ", "sum"), ("математ", "x.squareroot"),
            ("иностран", "character.bubble.fill"), ("англ", "character.bubble.fill"),
            ("информацион", "cpu.fill"), ("программ", "chevron.left.forwardslash.chevron.right"),
            ("истори", "building.columns.fill"), ("логик", "brain.head.profile"),
            ("государствен", "flag.fill"), ("прав", "scalemass.fill"), ("финанс", "banknote.fill"),
            ("цифров", "desktopcomputer"), ("введение в профессию", "lock.shield.fill"),
            ("безопасн", "lock.shield.fill"), ("физ", "figure.run"), ("физическ", "figure.run"),
            ("философ", "books.vertical.fill"), ("эконом", "chart.line.uptrend.xyaxis"),
            ("физика", "atom"), ("хими", "flask.fill"), ("русск", "text.book.closed.fill"),
            ("сети", "network"), ("баз", "cylinder.split.1x2.fill"), ("криптограф", "key.fill")
        ]
        for (k, icon) in map where s.contains(k) { return icon }
        return "book.closed.fill"
    }
}

/// Кто ведёт предмет: мой преподаватель (подгруппа) или все из РУЗ
enum SubjectTeachers {
    static func text(_ subject: String, _ data: ScheduleData) -> String {
        let subj = subject.lowercased()
        let all = Array(Set(data.ruzEvents
            .filter { ScheduleCache.shared.clean($0.subject).subject.lowercased() == subj }
            .map(\.teacher).filter { !$0.isEmpty })).sorted()
        if let pref = data.teacherPref(for: subject), !pref.isEmpty {
            return all.first { $0.lowercased().contains(pref.lowercased()) } ?? pref
        }
        if all.isEmpty {
            let manual = Array(Set(data.lessons.filter { $0.subject == subject }.map(\.teacher).filter { !$0.isEmpty }))
            return manual.sorted().joined(separator: ", ")
        }
        return all.prefix(3).joined(separator: ", ") + (all.count > 3 ? " и др." : "")
    }
}

/// Красивая строка предмета: значок, название, преподаватель, файлы, ближайшая пара
struct SubjectRow: View {
    let subject: String
    let data: ScheduleData

    var body: some View {
        let color = SubjectColor.color(for: subject)
        let teacher = SubjectTeachers.text(subject, data)
        let files = SubjectFolders.fileCount(subject)
        let next = ScheduleQuery.slots(data, days: 14).first { $0.lesson.subject == subject && $0.end > Date() }
        HStack(spacing: 12) {
            Image(systemName: SubjectIcon.name(for: subject))
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 42, height: 42)
                .background(color.gradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(subject)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                if !teacher.isEmpty {
                    Label(teacher, systemImage: "person.fill")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                HStack(spacing: 8) {
                    if let n = next {
                        HStack(spacing: 4) {
                            Circle().fill(KindStyle.of(n.lesson.kind).color).frame(width: 6, height: 6)
                            Text(dayTime(n.start))
                        }
                    }
                    HStack(spacing: 3) {
                        Image(systemName: "doc.fill")
                        Text("\(files)")
                    }
                    .foregroundStyle(files > 0 ? Color.brand : Color.secondary)
                }
                .font(.caption2)
                .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 4)
    }
}

private func dayTime(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "EE, d MMM · H:mm"
    return f.string(from: d)
}

// MARK: - Предметы

struct SubjectsView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var query = ""

    private var list: [String] {
        let all = ScheduleQuery.subjects(schedule.data)
        let q = query.trimmingCharacters(in: .whitespaces)
        return q.isEmpty ? all : all.filter { $0.localizedCaseInsensitiveContains(q) }
    }

    var body: some View {
        List {
            if list.isEmpty {
                Text("Предметы появятся, когда подключишь расписание во вкладке «Пары».")
                    .foregroundStyle(.secondary)
            }
            ForEach(list, id: \.self) { subject in
                NavigationLink {
                    SubjectDetailView(subject: subject)
                } label: {
                    SubjectRow(subject: subject, data: schedule.data)
                }
            }
        }
        .searchable(text: $query, prompt: "Поиск предмета")
        .navigationTitle("Предметы")
    }
}

struct SubjectDetailView: View {
    let subject: String
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @State private var note = ""
    @State private var taskDraft: StudyTask?
    @State private var files: [FileItem] = []
    @State private var preview: URL?
    @State private var showImporter = false
    @State private var showPhotos = false
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var showScanner = false
    @State private var toast: String?

    private var color: Color { SubjectColor.color(for: subject) }
    private var folderURL: URL { SubjectFolders.url(subject) }
    private var upcoming: [LessonSlot] {
        ScheduleQuery.slots(schedule.data, days: 30).filter { $0.lesson.subject == subject && $0.end > Date() }
    }
    private var teachers: [String] {
        Array(Set(ScheduleQuery.slots(schedule.data, from: -30, days: 60)
            .filter { $0.lesson.subject == subject }.map(\.lesson.teacher)
            .filter { !$0.isEmpty })).sorted()
    }
    private var subjectTasks: [StudyTask] {
        tasks.tasks.filter { $0.subject.caseInsensitiveCompare(subject) == .orderedSame }.sorted { $0.due < $1.due }
    }

    /// Все преподаватели предмета из РУЗ (без фильтра подгрупп)
    private var allTeachers: [String] {
        let subj = subject.lowercased()
        let names = schedule.data.ruzEvents.filter { $0.subject.lowercased() == subj }.map(\.teacher).filter { !$0.isEmpty }
        return Array(Set(names)).sorted()
    }

    private func surname(_ full: String) -> String {
        full.split(separator: " ").first.map(String.init) ?? full
    }

    private var currentPref: String { schedule.data.teacherPrefs[subject] ?? schedule.data.teacherPref(for: subject) ?? "" }

    private var prefBinding: Binding<String> {
        Binding(get: { currentPref },
                set: { v in
                    var d = schedule.data
                    // убираем старые ключи, совпадающие с этим предметом
                    for k in d.teacherPrefs.keys where k.lowercased() == subject.lowercased()
                        || subject.lowercased().hasPrefix(k.lowercased()) {
                        d.teacherPrefs[k] = nil
                    }
                    d.teacherPrefs[subject] = v
                    schedule.data = d
                    Haptics.tap()
                })
    }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 6) {
                    Text(subject)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    if !teachers.isEmpty {
                        Label(teachers.joined(separator: ", "), systemImage: "person.fill")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    if let n = upcoming.first {
                        HStack(spacing: 6) {
                            KindBadge(kind: n.lesson.kind, size: 9)
                            Text("\(dayTime(n.start))\(n.lesson.room.isEmpty ? "" : " · ауд. \(n.lesson.room)")")
                                .font(.caption.weight(.semibold))
                        }
                    }
                }
                .padding(.vertical, 4)
                .listRowBackground(color.opacity(0.15))
            }

            Section {
                Picker("Мой преподаватель", selection: prefBinding) {
                    Text("Все (без фильтра)").tag("")
                    ForEach(allTeachers, id: \.self) { t in
                        Text(t).tag(surname(t))
                    }
                    if !currentPref.isEmpty && !allTeachers.contains(where: { surname($0) == currentPref }) {
                        Text(currentPref).tag(currentPref)
                    }
                }
            } header: {
                Text("Подгруппа")
            } footer: {
                Text("Если у предмета несколько подгрупп с разными преподавателями, в расписании останутся только пары твоего.")
            }

            // ФАЙЛЫ — главное на этом экране
            Section {
                HStack(spacing: 8) {
                    chip("Файл", "doc.badge.plus") { showImporter = true }
                    chip("Фото", "photo") { showPhotos = true }
                    if VNDocumentCameraViewController.isSupported {
                        chip("Скан", "doc.viewfinder") { showScanner = true }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))

                if files.isEmpty {
                    Text("Пока пусто. Добавь методички, лабы, фото доски.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                } else {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 88), spacing: 10)], spacing: 10) {
                        ForEach(files.prefix(9)) { f in
                            Button { if !f.isDirectory { preview = f.url } } label: {
                                VStack(spacing: 4) {
                                    FileThumb(item: f, size: nil)
                                        .aspectRatio(1, contentMode: .fit)
                                    Text(f.name)
                                        .font(.caption2.weight(.semibold))
                                        .foregroundStyle(.primary)
                                        .lineLimit(1)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.vertical, 4)
                }
                NavigationLink {
                    FolderView(url: folderURL, title: subject)
                } label: {
                    Label("Открыть папку предмета (\(SubjectFolders.fileCount(subject)))", systemImage: "folder.fill")
                        .font(.subheadline.weight(.semibold))
                }
            } header: {
                Text("Файлы предмета")
            } footer: {
                Text("Лежат в «Файлы › Предметы › \(subject)». Внутри можно создавать свои папки.")
            }

            Section("Ближайшие пары") {
                if upcoming.isEmpty {
                    Text("Нет в ближайший месяц").foregroundStyle(.secondary)
                }
                ForEach(upcoming.prefix(5), id: \.key) { s in
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 6) {
                            KindBadge(kind: s.lesson.kind, size: 9)
                            Text(dayTime(s.start)).font(.subheadline.weight(.semibold))
                        }
                        Text([s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)", AddressFormat.full(s.address)]
                                .filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Section {
                ForEach(subjectTasks) { t in
                    HStack {
                        Image(systemName: t.done ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(t.done ? Color.green : Color.secondary)
                        VStack(alignment: .leading) {
                            Text(t.title).strikethrough(t.done)
                            Text(Fmt.due(t.due)).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { tasks.toggle(t) }
                }
                Button {
                    var t = StudyTask.blank()
                    t.subject = subject
                    taskDraft = t
                } label: { Label("Добавить задачу", systemImage: "plus") }
            } header: {
                Text("Задачи")
            }

            Section("Заметки") {
                TextEditor(text: $note)
                    .frame(minHeight: 140)
                    .onChange(of: note) { v in SubjectNotes.set(v, for: subject) }
            }
        }
        .navigationTitle("Предмет")
        .navigationBarTitleDisplayMode(.inline)
        .overlay(alignment: .bottom) {
            if let toast {
                Label(toast, systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 11)
                    .glass(20)
                    .padding(.bottom, 16)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onAppear {
            note = SubjectNotes.get(subject)
            try? FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)
            reloadFiles()
        }
        .quickLookPreview($preview)
        .sheet(isPresented: $showImporter) {
            DocumentPicker { urls in
                showImporter = false
                guard !urls.isEmpty else { return }
                var ok = 0
                for u in urls { if (try? FileService.importFile(from: u, to: folderURL)) != nil { ok += 1 } }
                reloadFiles()
                flash("Добавлено: \(ok)")
            }
            .ignoresSafeArea()
        }
        .photosPicker(isPresented: $showPhotos, selection: $photoItems, matching: .any(of: [.images, .videos]))
        .onChange(of: photoItems) { items in
            guard !items.isEmpty else { return }
            Task {
                var ok = 0
                for item in items {
                    if let data = try? await item.loadTransferable(type: Data.self) {
                        let ext = item.supportedContentTypes.first?.preferredFilenameExtension ?? "jpg"
                        if (try? FileService.save(data, ext: ext, to: folderURL)) != nil { ok += 1 }
                    }
                }
                await MainActor.run {
                    photoItems = []
                    reloadFiles()
                    flash("Добавлено: \(ok)")
                }
            }
        }
        .fullScreenCover(isPresented: $showScanner) {
            DocumentScanner { images in
                showScanner = false
                guard !images.isEmpty else { return }
                try? FileService.savePDF(ScanPDF.make(images), in: folderURL)
                reloadFiles()
                flash("Скан сохранён")
            } onCancel: {
                showScanner = false
            }
            .ignoresSafeArea()
        }
        .sheet(item: $taskDraft) { t in
            TaskEditor(task: t, isNew: true, onSave: { tasks.upsert($0) }, onDelete: {})
        }
    }

    private func chip(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 17, weight: .semibold)).foregroundStyle(brandGradient)
                Text(title).font(.caption2.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.borderless)
    }

    private func reloadFiles() {
        files = FileService.sorted(FileService.list(folderURL), by: 1)
    }

    private func flash(_ text: String) {
        Haptics.success()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            withAnimation { toast = nil }
        }
    }
}

enum SubjectFolders {
    static var base: URL { FileService.root.appendingPathComponent("Предметы", isDirectory: true) }

    static func url(_ subject: String) -> URL {
        let clean = subject.replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
            .trimmingCharacters(in: .whitespaces)
        return base.appendingPathComponent(clean.isEmpty ? "Без названия" : clean, isDirectory: true)
    }

    /// Создаём папку для каждого предмета из расписания
    static func ensureAll(_ subjects: [String]) {
        for s in subjects {
            try? FileManager.default.createDirectory(at: url(s), withIntermediateDirectories: true)
        }
        // убираем пустые папки со «сломанными» названиями вроде «… Ссылка на курс …»
        let fm = FileManager.default
        let items = (try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        for u in items {
            let name = u.lastPathComponent
            let cleaned = EventText.cleanSubject(name).subject
            guard cleaned != name else { continue }
            let empty = ((try? fm.contentsOfDirectory(atPath: u.path)) ?? []).filter { !$0.hasPrefix(".") }.isEmpty
            if empty { try? fm.removeItem(at: u) }
        }
    }

    static func fileCount(_ subject: String) -> Int {
        let e = FileManager.default.enumerator(at: url(subject), includingPropertiesForKeys: [.isDirectoryKey],
                                               options: [.skipsHiddenFiles])
        var n = 0
        while let u = e?.nextObject() as? URL {
            if (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) != true { n += 1 }
        }
        return n
    }
}

struct SubjectRef: Identifiable {
    let name: String
    var id: String { name }
}

/// Лента предметов на главной: быстрый доступ к файлам и заметкам каждого предмета
struct SubjectsStrip: View {
    @EnvironmentObject private var schedule: ScheduleStore
    let onOpen: (String) -> Void

    private var subjects: [String] {
        // сначала те, у кого пара ближе
        let upcoming = ScheduleQuery.slots(schedule.data, days: 14).filter { $0.end > Date() }
        var order: [String] = []
        for s in upcoming where !order.contains(s.lesson.subject) { order.append(s.lesson.subject) }
        for s in ScheduleQuery.subjects(schedule.data) where !order.contains(s) { order.append(s) }
        return order
    }

    var body: some View {
        if !subjects.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    SectionTitle(text: "Предметы")
                    Spacer()
                    Text("\(subjects.count)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.secondary)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(subjects, id: \.self) { name in
                            Button { Haptics.tap(); onOpen(name) } label: { card(name) }
                                .buttonStyle(PressableStyle())
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 2)
                }
                .padding(.horizontal, -20)
            }
        }
    }

    private func card(_ name: String) -> some View {
        let teacher = SubjectTeachers.text(name, schedule.data)
        let files = SubjectFolders.fileCount(name)
        return HStack(spacing: 10) {
            Image(systemName: SubjectIcon.name(for: name))
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(SubjectColor.color(for: name).gradient, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            VStack(alignment: .leading, spacing: 2) {
                Text(name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                Text(teacher.isEmpty ? "файлов: \(files)" : teacher)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            if files > 0 {
                Text("\(files)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(Color.brand)
            }
        }
        .frame(width: 220)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .glass(16, interactive: true)
    }
}

struct SubjectSheet: View {
    let subject: String
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            SubjectDetailView(subject: subject)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
                }
        }
    }
}

enum SubjectNotes {
    private static let key = "subject.notes"
    static func get(_ subject: String) -> String {
        (UserDefaults.standard.dictionary(forKey: key) as? [String: String])?[subject] ?? ""
    }
    static func set(_ text: String, for subject: String) {
        var d = (UserDefaults.standard.dictionary(forKey: key) as? [String: String]) ?? [:]
        d[subject] = text
        UserDefaults.standard.set(d, forKey: key)
    }
}

// MARK: - Преподаватели

struct TeacherInfo: Identifiable {
    let name: String
    var subjects: Set<String>
    var kinds: Set<String>
    var now: LessonSlot?
    var next: LessonSlot?
    var total: Int
    var id: String { name }
}

enum TeacherIndex {
    static func build(_ data: ScheduleData) -> [TeacherInfo] {
        var map: [String: TeacherInfo] = [:]
        let now = Date()
        for s in ScheduleQuery.slots(data, from: -120, days: 240) where !s.lesson.teacher.isEmpty {
            var info = map[s.lesson.teacher]
                ?? TeacherInfo(name: s.lesson.teacher, subjects: [], kinds: [], now: nil, next: nil, total: 0)
            info.subjects.insert(s.lesson.subject)
            info.kinds.insert(KindStyle.of(s.lesson.kind).label)
            info.total += 1
            if s.start <= now && now < s.end { info.now = s }
            if s.start > now, info.next == nil || s.start < (info.next?.start ?? .distantFuture) { info.next = s }
            map[s.lesson.teacher] = info
        }
        return map.values.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
}

struct TeachersView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.openURL) private var openURL
    @State private var query = ""

    private var list: [TeacherInfo] {
        let q = query.trimmingCharacters(in: .whitespaces)
        return TeacherIndex.build(schedule.data).filter {
            q.isEmpty || $0.name.localizedCaseInsensitiveContains(q)
                || $0.subjects.contains { $0.localizedCaseInsensitiveContains(q) }
        }
    }

    var body: some View {
        List {
            if list.isEmpty {
                Text("Преподаватели появятся из твоего расписания РУЗ.").foregroundStyle(.secondary)
            }
            ForEach(list) { t in
                NavigationLink {
                    TeacherDetailView(name: t.name)
                } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text(t.name).font(.headline)
                            if t.now != nil {
                                Text("СЕЙЧАС")
                                    .font(.caption2.weight(.heavy))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(Color.green, in: Capsule())
                            }
                        }
                        Text(t.subjects.sorted().joined(separator: ", "))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                        if let n = t.now ?? t.next {
                            Label("\(t.now != nil ? "Сейчас" : dayTime(n.start))\(n.lesson.room.isEmpty ? "" : " · ауд. \(n.lesson.room)")",
                                  systemImage: "mappin.and.ellipse")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(Color.brand)
                        }
                    }
                    .padding(.vertical, 2)
                }
            }
            Section {
                Button {
                    if let u = URL(string: "https://ruz.narfu.ru/") { openURL(u) }
                } label: {
                    Label("Найти любого преподавателя в РУЗ", systemImage: "magnifyingglass")
                }
            } footer: {
                Text("Здесь видны пары преподавателей с твоей группой. Полное расписание преподавателя со всеми группами — через поиск в РУЗ.")
            }
        }
        .searchable(text: $query, prompt: "Фамилия или предмет")
        .navigationTitle("Преподаватели")
    }
}

struct TeacherDetailView: View {
    let name: String
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.openURL) private var openURL

    private var all: [LessonSlot] {
        ScheduleQuery.slots(schedule.data, from: -120, days: 240).filter { $0.lesson.teacher == name }
    }
    private var current: LessonSlot? { all.first { $0.start <= Date() && Date() < $0.end } }
    private var upcoming: [LessonSlot] { all.filter { $0.start > Date() } }
    private var past: [LessonSlot] { all.filter { $0.end <= Date() }.reversed() }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Text(name).font(.system(.title3, design: .rounded).weight(.bold))
                    Text(Set(all.map(\.lesson.subject)).sorted().joined(separator: ", "))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    HStack(spacing: 6) {
                        ForEach(Array(Set(all.map(\.lesson.kind))).sorted(), id: \.self) { k in
                            KindBadge(kind: k, size: 9)
                        }
                    }
                    Button {
                        UIPasteboard.general.string = name
                        Haptics.success()
                    } label: {
                        Label("Скопировать ФИО", systemImage: "doc.on.doc")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.borderless)
                }
                .padding(.vertical, 4)
            }

            if let c = current {
                Section("Сейчас у тебя") {
                    row(c, highlight: true)
                }
            }

            Section("Ближайшие занятия (\(upcoming.count))") {
                if upcoming.isEmpty {
                    Text("Ближайших пар с этим преподавателем нет").foregroundStyle(.secondary)
                }
                ForEach(upcoming.prefix(25), id: \.key) { s in row(s, highlight: false) }
            }

            if !past.isEmpty {
                Section("Уже прошли (\(past.count))") {
                    ForEach(past.prefix(10), id: \.key) { s in row(s, highlight: false).opacity(0.6) }
                }
            }
        }
        .navigationTitle("Преподаватель")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func row(_ s: LessonSlot, highlight: Bool) -> some View {
        Button {
            if !s.address.isEmpty, let u = Maps.smartURL(for: s.address) { openURL(u) }
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    KindBadge(kind: s.lesson.kind, size: 9)
                    Text(dayTime(s.start)).font(.subheadline.weight(.semibold))
                }
                Text(s.lesson.subject).font(.subheadline).foregroundStyle(.primary)
                if !s.lesson.room.isEmpty {
                    Label("ауд. \(s.lesson.room)", systemImage: "door.left.hand.open")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.primary)
                }
                if !s.address.isEmpty {
                    Label(AddressFormat.full(s.address), systemImage: "mappin.and.ellipse")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 2)
        }
        .buttonStyle(.plain)
        .listRowBackground(highlight ? Color.green.opacity(0.15) : nil)
    }
}

// MARK: - Карта корпусов

struct CampusMapView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.openURL) private var openURL
    @State private var pins: [Pin] = []
    @State private var position: MapCameraPosition = .region(MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 64.5401, longitude: 40.5433),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)))
    @State private var loading = false

    struct Pin: Identifiable {
        let address: String
        let coordinate: CLLocationCoordinate2D
        let count: Int
        let next: String
        var id: String { address }
    }

    struct AddrInfo: Identifiable {
        let address: String
        let count: Int
        let next: String
        var id: String { address }
    }

    private var addresses: [AddrInfo] {
        var counts: [String: Int] = [:]
        var firsts: [String: String] = [:]
        for s in ScheduleQuery.slots(schedule.data, days: 14) where !s.address.isEmpty {
            counts[s.address, default: 0] += 1
            if firsts[s.address] == nil { firsts[s.address] = "\(dayTime(s.start)): \(s.lesson.subject)" }
        }
        return counts.map { AddrInfo(address: $0.key, count: $0.value, next: firsts[$0.key] ?? "") }
            .sorted { $0.count > $1.count }
    }

    var body: some View {
        VStack(spacing: 0) {
            Map(position: $position) {
                ForEach(pins) { p in
                    Annotation(p.address, coordinate: p.coordinate) {
                        ZStack {
                            Circle().fill(brandGradient).frame(width: 34, height: 34)
                            Text("\(p.count)").font(.caption.weight(.heavy)).foregroundStyle(.white)
                        }
                        .shadow(radius: 4)
                    }
                }
            }
            .frame(height: 320)
            .overlay(alignment: .topTrailing) {
                if loading { ProgressView().padding(10).glass(14).padding(10) }
            }

            List {
                if addresses.isEmpty {
                    Text("На ближайшие две недели адресов в расписании нет.").foregroundStyle(.secondary)
                }
                ForEach(addresses) { item in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(AddressFormat.full(item.address)).font(.subheadline.weight(.bold))
                        Text("Пар за 2 недели: \(item.count) · ближайшая \(item.next)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        HStack(spacing: 14) {
                            Button("Яндекс Карты") { if let u = Maps.url(for: item.address) { openURL(u) } }
                            Button("Apple Карты") { if let u = Maps.appleURL(for: item.address) { openURL(u) } }
                        }
                        .font(.caption.weight(.semibold))
                        .buttonStyle(.borderless)
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .navigationTitle("Карта корпусов")
        .navigationBarTitleDisplayMode(.inline)
        .task { await geocodeAll() }
    }

    private func geocodeAll() async {
        let items = addresses
        guard !items.isEmpty else { return }
        loading = true
        var cache = (UserDefaults.standard.dictionary(forKey: "geo.cache") as? [String: [Double]]) ?? [:]
        var result: [Pin] = []
        let geocoder = CLGeocoder()
        for item in items {
            if let c = cache[item.address], c.count == 2 {
                result.append(Pin(address: item.address,
                                  coordinate: CLLocationCoordinate2D(latitude: c[0], longitude: c[1]),
                                  count: item.count, next: item.next))
                continue
            }
            let q = item.address.lowercased().contains("архангельск") ? item.address : "Архангельск, " + item.address
            let places = try? await geocoder.geocodeAddressString(q)
            if let loc = places?.first?.location {
                cache[item.address] = [loc.coordinate.latitude, loc.coordinate.longitude]
                result.append(Pin(address: item.address, coordinate: loc.coordinate, count: item.count, next: item.next))
            }
        }
        UserDefaults.standard.set(cache, forKey: "geo.cache")
        pins = result
        loading = false
        if let first = result.first {
            position = .region(MKCoordinateRegion(center: first.coordinate,
                                                  span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)))
        }
    }
}

// MARK: - Фокус (помодоро)

struct FocusView: View {
    @AppStorage("focus.work") private var workMin = 25
    @AppStorage("focus.break") private var breakMin = 5
    @AppStorage("focus.end") private var endTime: Double = 0
    @AppStorage("focus.remaining") private var pausedLeft: Double = 0
    @AppStorage("focus.isBreak") private var isBreak = false
    @AppStorage("focus.done") private var doneToday = 0
    @AppStorage("focus.day") private var doneDay = ""

    private var total: Double { Double(isBreak ? breakMin : workMin) * 60 }
    private var running: Bool { endTime > 0 }

    var body: some View {
        VStack(spacing: 26) {
            Picker("Режим", selection: Binding(get: { workMin }, set: { v in
                workMin = v
                breakMin = v == 50 ? 10 : (v == 15 ? 3 : 5)
                reset()
            })) {
                Text("15 / 3").tag(15)
                Text("25 / 5").tag(25)
                Text("50 / 10").tag(50)
            }
            .pickerStyle(.segmented)
            .disabled(running)

            TimelineView(.periodic(from: .now, by: 1)) { ctx in
                let left = remaining(at: ctx.date)
                ZStack {
                    Circle().stroke(Color.primary.opacity(0.08), lineWidth: 16)
                    Circle()
                        .trim(from: 0, to: total > 0 ? 1 - left / total : 0)
                        .stroke(isBreak ? AnyShapeStyle(Color.green.gradient) : AnyShapeStyle(brandGradient),
                                style: StrokeStyle(lineWidth: 16, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .animation(.linear(duration: 1), value: left)
                    VStack(spacing: 6) {
                        Text(isBreak ? "ПЕРЕРЫВ" : "ФОКУС")
                            .font(.caption.weight(.heavy))
                            .foregroundStyle(isBreak ? Color.green : Color.brand)
                        Text(clock(left))
                            .font(.system(size: 56, weight: .bold, design: .rounded))
                            .monospacedDigit()
                        Text("Сегодня: \(todayCount)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(width: 260, height: 260)
            }

            HStack(spacing: 14) {
                Button { reset() } label: {
                    Image(systemName: "arrow.counterclockwise")
                        .font(.title3.weight(.semibold))
                        .frame(width: 60, height: 60)
                        .glass(30, interactive: true)
                }
                Button { toggle() } label: {
                    Image(systemName: running ? "pause.fill" : "play.fill")
                        .font(.title.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(width: 84, height: 84)
                        .background(brandGradient, in: Circle())
                }
                Button { finish() } label: {
                    Image(systemName: "forward.end.fill")
                        .font(.title3.weight(.semibold))
                        .frame(width: 60, height: 60)
                        .glass(30, interactive: true)
                }
            }
            .buttonStyle(PressableStyle())
            .foregroundStyle(.primary)

            Text("Телефон пришлёт уведомление, когда время выйдет, даже если приложение закрыто.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Spacer()
        }
        .padding(24)
        .navigationTitle("Фокус")
        .task(id: endTime) {
            guard endTime > 0 else { return }
            let delay = endTime - Date().timeIntervalSince1970
            if delay > 0 { try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000)) }
            if !Task.isCancelled, endTime > 0, Date().timeIntervalSince1970 >= endTime - 0.5 { finish() }
        }
    }

    private var todayKey: String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }

    private var todayCount: Int { doneDay == todayKey ? doneToday : 0 }

    private func remaining(at date: Date) -> Double {
        if running { return max(0, endTime - date.timeIntervalSince1970) }
        return pausedLeft > 0 ? pausedLeft : total
    }

    private func clock(_ s: Double) -> String {
        let v = Int(s.rounded(.up))
        return String(format: "%02d:%02d", v / 60, v % 60)
    }

    private func toggle() {
        Haptics.tap()
        if running {
            pausedLeft = max(0, endTime - Date().timeIntervalSince1970)
            endTime = 0
            cancelNotification()
        } else {
            let left = pausedLeft > 0 ? pausedLeft : total
            pausedLeft = 0
            endTime = Date().timeIntervalSince1970 + left
            scheduleNotification(in: left)
        }
    }

    private func reset() {
        endTime = 0
        pausedLeft = 0
        cancelNotification()
    }

    private func finish() {
        if !isBreak {
            if doneDay != todayKey { doneDay = todayKey; doneToday = 0 }
            doneToday += 1
        }
        Haptics.success()
        isBreak.toggle()
        reset()
    }

    private func scheduleNotification(in seconds: Double) {
        Notifier.requestAuthorization()
        let c = UNMutableNotificationContent()
        c.title = isBreak ? "Перерыв окончен" : "Время отдохнуть"
        c.body = isBreak ? "Возвращайся к учёбе 💪" : "Ты отлично поработал. Перерыв \(breakMin) мин."
        c.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, seconds), repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "focus", content: c, trigger: trigger))
    }

    private func cancelNotification() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["focus"])
    }
}

// MARK: - Титульный лист по СТО САФУ

struct ReportView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("report.student") private var student = "Зарубин Кирилл Вениаминович"
    @AppStorage("group") private var group = "151621"
    @AppStorage("report.supervisor") private var supervisor = "Кашина Ксения Игоревна"
    @AppStorage("report.position") private var position = ""
    @AppStorage("report.school") private var school = "Высшая школа информационных технологий и автоматизированных систем"
    @AppStorage("report.kind") private var kind = 0
    @AppStorage("report.number") private var number = "1"
    @AppStorage("report.discipline") private var discipline = ""
    @AppStorage("report.topic") private var topic = ""
    @State private var preview: URL?
    @State private var created: URL?

    private let kinds = ["Лабораторная работа", "Практическая работа", "Курсовая работа", "Реферат", "Отчёт по практике"]

    var body: some View {
        Form {
            Section("Работа") {
                Picker("Вид", selection: $kind) {
                    ForEach(kinds.indices, id: \.self) { i in Text(kinds[i]).tag(i) }
                }
                if kind < 2 {
                    TextField("Номер", text: $number).keyboardType(.numberPad)
                }
                TextField("Дисциплина", text: $discipline)
                let subs = ScheduleQuery.subjects(schedule.data)
                if !subs.isEmpty {
                    Menu {
                        ForEach(subs, id: \.self) { s in Button(s) { discipline = s } }
                    } label: {
                        Label("Выбрать из расписания", systemImage: "list.bullet")
                    }
                }
                TextField("Тема", text: $topic, axis: .vertical)
            }
            Section("Студент") {
                TextField("ФИО", text: $student)
                TextField("Группа", text: $group).keyboardType(.numberPad)
                TextField("Высшая школа", text: $school, axis: .vertical)
            }
            Section("Руководитель") {
                TextField("ФИО", text: $supervisor)
                TextField("Должность (например, доцент)", text: $position)
            }
            Section {
                Button {
                    create()
                } label: {
                    Label("Создать титульник .docx", systemImage: "doc.badge.plus")
                        .font(.headline)
                }
                if let u = created {
                    Button { preview = u } label: { Label("Посмотреть", systemImage: "eye") }
                    ShareLink(item: u) { Label("Отправить / открыть в Word", systemImage: "square.and.arrow.up") }
                }
            } footer: {
                Text("Файл сохраняется в «Файлы › Отчёты». Шрифт Times New Roman 14, поля по СТО. Сверь с методичкой преподавателя: на кафедрах бывают свои требования.")
            }
        }
        .navigationTitle("Титульник")
        .quickLookPreview($preview)
    }

    private func create() {
        let workTitle: String
        switch kind {
        case 0: return makeWith("ЛАБОРАТОРНАЯ РАБОТА № \(number)")
        case 1: return makeWith("ПРАКТИЧЕСКАЯ РАБОТА № \(number)")
        case 2: workTitle = "КУРСОВАЯ РАБОТА"
        case 3: workTitle = "РЕФЕРАТ"
        default: workTitle = "ОТЧЁТ ПО ПРАКТИКЕ"
        }
        makeWith(workTitle)
    }

    private func makeWith(_ workTitle: String) {
        let year = Calendar.current.component(.year, from: Date())
        let data = DocxBuilder.titlePage(school: school, workTitle: workTitle, discipline: discipline, topic: topic,
                                         student: student, group: group, supervisor: supervisor,
                                         position: position, year: year)
        let dir = FileService.root.appendingPathComponent("Отчёты", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let short = kind < 2 ? "\(kind == 0 ? "ЛР" : "ПР")_\(number)" : kinds[kind]
        let name = "Титульник \(short)\(discipline.isEmpty ? "" : " — \(discipline.prefix(30))").docx"
            .replacingOccurrences(of: "/", with: "-")
        let url = FileService.uniqueURL(in: dir, name: name)
        do {
            try data.write(to: url)
            created = url
            preview = url
            Haptics.success()
        } catch {
            created = nil
        }
    }
}

// MARK: - Сборка .docx (минимальный документ Word без сторонних библиотек)

enum DocxBuilder {
    private static func esc(_ s: String) -> String {
        s.replacingOccurrences(of: "&", with: "&amp;")
            .replacingOccurrences(of: "<", with: "&lt;")
            .replacingOccurrences(of: ">", with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    private static func p(_ text: String, align: String = "center", bold: Bool = false, size: Int = 28,
                          caps: Bool = false, indentLeft: Int = 0) -> String {
        let ind = indentLeft > 0 ? "<w:ind w:left=\"\(indentLeft)\"/>" : ""
        let b = bold ? "<w:b/><w:bCs/>" : ""
        let c = caps ? "<w:caps/>" : ""
        return """
        <w:p><w:pPr><w:jc w:val="\(align)"/><w:spacing w:before="0" w:after="0" w:line="276" w:lineRule="auto"/>\(ind)</w:pPr>\
        <w:r><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>\(b)\(c)\
        <w:sz w:val="\(size)"/><w:szCs w:val="\(size)"/></w:rPr><w:t xml:space="preserve">\(esc(text))</w:t></w:r></w:p>
        """
    }

    private static func blank(_ n: Int) -> String { String(repeating: p(""), count: n) }

    static func titlePage(school: String, workTitle: String, discipline: String, topic: String,
                          student: String, group: String, supervisor: String, position: String, year: Int) -> Data {
        var body = ""
        body += p("МИНИСТЕРСТВО НАУКИ И ВЫСШЕГО ОБРАЗОВАНИЯ РОССИЙСКОЙ ФЕДЕРАЦИИ", size: 24)
        body += p("федеральное государственное автономное образовательное учреждение высшего образования", size: 24)
        body += p("«Северный (Арктический) федеральный университет имени М.В. Ломоносова»", bold: true, size: 24)
        body += blank(1)
        body += p(school, size: 28)
        body += blank(6)
        body += p(workTitle, bold: true, size: 32)
        body += blank(1)
        if !discipline.isEmpty { body += p("по дисциплине «\(discipline)»", size: 28) }
        if !topic.isEmpty { body += p("на тему: «\(topic)»", size: 28) }
        body += blank(6)
        body += p("Выполнил:", align: "left", size: 28, indentLeft: 5103)
        body += p("студент группы \(group)", align: "left", size: 28, indentLeft: 5103)
        body += p(student, align: "left", size: 28, indentLeft: 5103)
        body += blank(1)
        body += p("Проверил:", align: "left", size: 28, indentLeft: 5103)
        if !position.isEmpty { body += p(position, align: "left", size: 28, indentLeft: 5103) }
        body += p(supervisor, align: "left", size: 28, indentLeft: 5103)
        body += blank(7)
        body += p("Архангельск \(year)", size: 28)

        let document = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>\(body)\
        <w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="567" w:bottom="1134" w:left="1701" w:header="709" w:footer="709" w:gutter="0"/></w:sectPr>\
        </w:body></w:document>
        """
        let contentTypes = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">\
        <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>\
        <Default Extension="xml" ContentType="application/xml"/>\
        <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>\
        </Types>
        """
        let rels = """
        <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
        <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">\
        <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>\
        </Relationships>
        """
        return ZipWriter.make([
            ("[Content_Types].xml", Data(contentTypes.utf8)),
            ("_rels/.rels", Data(rels.utf8)),
            ("word/document.xml", Data(document.utf8))
        ])
    }
}

enum ZipWriter {
    /// Простой построитель байтов (little-endian)
    private struct Bytes {
        var data = Data()
        mutating func u16(_ v: UInt16) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
        mutating func u32(_ v: UInt32) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
        mutating func raw(_ d: Data) { data.append(d) }
    }

    /// ZIP без сжатия (метод «stored») — этого достаточно для .docx
    static func make(_ files: [(String, Data)]) -> Data {
        var out = Bytes()
        var central = Bytes()
        var offset: UInt32 = 0
        for (name, data) in files {
            let nameData = Data(name.utf8)
            let crc = CRC32.checksum(data)
            let size = UInt32(data.count)
            let nameLen = UInt16(nameData.count)

            var local = Bytes()
            local.u32(0x04034b50)
            local.u16(20); local.u16(0); local.u16(0); local.u16(0); local.u16(0x21)
            local.u32(crc); local.u32(size); local.u32(size)
            local.u16(nameLen); local.u16(0)
            local.raw(nameData)
            local.raw(data)

            central.u32(0x02014b50)
            central.u16(20); central.u16(20); central.u16(0); central.u16(0); central.u16(0); central.u16(0x21)
            central.u32(crc); central.u32(size); central.u32(size)
            central.u16(nameLen); central.u16(0); central.u16(0); central.u16(0); central.u16(0)
            central.u32(0); central.u32(offset)
            central.raw(nameData)

            out.raw(local.data)
            offset += UInt32(local.data.count)
        }
        let cdOffset = offset
        let cdSize = UInt32(central.data.count)
        out.raw(central.data)
        out.u32(0x06054b50)
        out.u16(0); out.u16(0)
        out.u16(UInt16(files.count)); out.u16(UInt16(files.count))
        out.u32(cdSize); out.u32(cdOffset); out.u16(0)
        return out.data
    }
}

enum CRC32 {
    private static let table: [UInt32] = (0..<256).map { i -> UInt32 in
        var c = UInt32(i)
        for _ in 0..<8 { c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1) }
        return c
    }

    static func checksum(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFFFFFF
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 0xFF)] ^ (crc >> 8)
        }
        return crc ^ 0xFFFFFFFF
    }
}
