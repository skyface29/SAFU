import Foundation
import WebKit

// MARK: - Дедлайны из Sakai → «Задачи»
// Используем вход, который уже есть во встроенном браузере (cookie Sakai), и стандартный API Sakai:
// /direct/assignment/my.json — все задания пользователя.

struct SakaiAssignment {
    let id: String
    let title: String
    let site: String
    let due: Date
    let url: String
}

enum SakaiSync {
    static let base = "https://sakai.narfu.ru"

    enum SyncError: LocalizedError {
        case notLoggedIn, bad
        var errorDescription: String? {
            switch self {
            case .notLoggedIn: return "Сначала войди в Sakai: главная → Sakai. Потом повтори."
            case .bad: return "Sakai ответил непонятно. Попробуй позже."
            }
        }
    }

    private static func restoreSession() async {
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            DispatchQueue.main.async {
                SessionKeeper.restore(into: WKWebsiteDataStore.default().httpCookieStore) { cont.resume() }
            }
        }
    }

    private static func cookieHeaders() async -> [String: String] {
        await withCheckedContinuation { (cont: CheckedContinuation<[String: String], Never>) in
            DispatchQueue.main.async {
                WKWebsiteDataStore.default().httpCookieStore.getAllCookies { cookies in
                    let host = "sakai.narfu.ru"
                    let mine = cookies.filter {
                        let d = $0.domain.trimmingCharacters(in: CharacterSet(charactersIn: "."))
                        return host == d || host.hasSuffix("." + d)
                    }
                    cont.resume(returning: HTTPCookie.requestHeaderFields(with: mine))
                }
            }
        }
    }

    private static func getJSON(_ path: String, headers: [String: String]) async throws -> Any {
        guard let url = URL(string: base + path) else { throw SyncError.bad }
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        for (k, v) in headers { req.setValue(v, forHTTPHeaderField: k) }
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let http = resp as? HTTPURLResponse, http.statusCode == 401 || http.statusCode == 403 { throw SyncError.notLoggedIn }
        guard let obj = try? JSONSerialization.jsonObject(with: data) else { throw SyncError.notLoggedIn }
        return obj
    }

    private static func date(_ v: Any?) -> Date? {
        if let d = v as? [String: Any] {
            if let e = d["epochSecond"] as? Double { return Date(timeIntervalSince1970: e) }
            if let e = d["epochSecond"] as? Int { return Date(timeIntervalSince1970: Double(e)) }
            if let t = d["time"] as? Double { return Date(timeIntervalSince1970: t / 1000) }
            if let t = d["time"] as? Int { return Date(timeIntervalSince1970: Double(t) / 1000) }
        }
        if let t = v as? Double { return Date(timeIntervalSince1970: t > 1e11 ? t / 1000 : t) }
        if let t = v as? Int { let d = Double(t); return Date(timeIntervalSince1970: d > 1e11 ? d / 1000 : d) }
        return nil
    }

    static func fetch() async throws -> [SakaiAssignment] {
        await restoreSession()
        let headers = await cookieHeaders()
        guard !headers.isEmpty else { throw SyncError.notLoggedIn }
        let obj = try await getJSON("/direct/assignment/my.json", headers: headers)
        guard let dict = obj as? [String: Any], let list = dict["assignment_collection"] as? [[String: Any]] else {
            throw SyncError.bad
        }
        var siteTitles: [String: String] = [:]
        var result: [SakaiAssignment] = []
        for a in list {
            guard let id = (a["id"] as? String) ?? (a["entityId"] as? String),
                  let title = a["title"] as? String,
                  let due = date(a["dueTime"]) ?? date(a["dueDate"]) else { continue }
            if (a["draft"] as? Bool) == true { continue }
            let context = (a["context"] as? String) ?? ""
            var site = (a["siteTitle"] as? String) ?? siteTitles[context] ?? ""
            if site.isEmpty && !context.isEmpty {
                if let s = try? await getJSON("/direct/site/\(context).json", headers: headers) as? [String: Any],
                   let t = s["title"] as? String {
                    site = t
                    siteTitles[context] = t
                }
            }
            let link = (a["entityURL"] as? String) ?? base
            result.append(SakaiAssignment(id: id, title: title, site: site, due: due, url: link))
        }
        return result
    }

    /// Забираем задания и кладём в «Задачи» (без дублей; срок обновляется, если его перенесли)
    @MainActor
    static func importInto(_ tasks: TaskStore) async -> String {
        do {
            let list = try await fetch()
            var map = (UserDefaults.standard.dictionary(forKey: "sakai.map") as? [String: String]) ?? [:]
            var added = 0, updated = 0
            for a in list where a.due > Date().addingTimeInterval(-86_400) {
                if let tid = map[a.id], let existing = tasks.tasks.first(where: { $0.id.uuidString == tid }) {
                    if existing.due != a.due || existing.title != a.title {
                        var t = existing
                        t.due = a.due
                        t.title = a.title
                        tasks.upsert(t)
                        updated += 1
                    }
                } else {
                    let t = StudyTask(title: a.title, subject: a.site, due: a.due, note: "Из Sakai\n\(a.url)")
                    tasks.upsert(t)
                    map[a.id] = t.id.uuidString
                    added += 1
                }
            }
            UserDefaults.standard.set(map, forKey: "sakai.map")
            UserDefaults.standard.set(Date().timeIntervalSinceReferenceDate, forKey: "sakai.last")
            if added == 0 && updated == 0 { return "Новых заданий в Sakai нет" }
            return "Из Sakai: новых \(added), обновлено \(updated)"
        } catch {
            return error.localizedDescription
        }
    }

    /// Тихая автозагрузка не чаще раза в 6 часов (если вход в Sakai уже был)
    @MainActor
    static func autoImport(_ tasks: TaskStore) async {
        let last = UserDefaults.standard.double(forKey: "sakai.last")
        guard Date().timeIntervalSinceReferenceDate - last > 6 * 3600 else { return }
        _ = await importInto(tasks)
    }
}
