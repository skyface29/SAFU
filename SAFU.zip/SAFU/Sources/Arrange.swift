import SwiftUI
import UniformTypeIdentifiers

// MARK: - Перестановка как на рабочем столе iPhone
//
// Удержал значок или блок — всё вокруг начинает покачиваться, значок поднимается под пальцем,
// а пока его тащишь, соседи сами расступаются и встают на новые места. Отпустил — значок встаёт
// в освободившееся место. Покачивание держится, пока не нажмёшь «Готово», — как на iPhone.
// Кнопка «−» в углу убирает значок или блок с главной.

/// Где переставляем. У каждого места свой тип перетаскивания — значок нельзя уронить в чужой ряд
enum ArrangeKind: String {
    case home, tools, tiles, quick

    var type: UTType { UTType(exportedAs: "ru.student.safuhub.arrange.\(rawValue)", conformingTo: .data) }

    var hint: String {
        switch self {
        case .home: return "Перетаскивай блоки — остальные расступятся"
        case .tools: return "Перетаскивай значки — остальные расступятся"
        case .tiles: return "Перетаскивай плитки — остальные расступятся"
        case .quick: return "Перетаскивай кнопки — остальные расступятся"
        }
    }
}

/// Провайдер перетаскивания, который сообщает, когда система его отпустила:
/// так понятно, что перетаскивание закончилось, даже если значок бросили мимо
final class ArrangeProvider: NSItemProvider {
    var onEnd: (() -> Void)?
    deinit { onEnd?() }
}

final class ArrangeSession: ObservableObject {
    static let shared = ArrangeSession()

    /// Где сейчас всё покачивается (режим перестановки)
    @Published private(set) var editing: ArrangeKind?
    /// Значок, который подняли: на его месте — пустое место
    @Published private(set) var hole: String?
    /// Что тащат прямо сейчас (для перестановки — без задержки)
    private(set) var kind: ArrangeKind?
    private(set) var item: String?
    private var token = 0
    private let selection = UISelectionFeedbackGenerator()

    /// Палец поднял значок
    func start(_ id: String, kind k: ArrangeKind) -> NSItemProvider {
        token += 1
        let t = token
        kind = k
        item = id
        if editing != k {
            Haptics.success()
            withAnimation(.easeOut(duration: 0.2)) { editing = k }
        }
        selection.prepare()
        // место пустеет чуть позже: системе нужен снимок значка, чтобы поднять его под пальцем
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
            guard let self, self.token == t else { return }
            withAnimation(.easeOut(duration: 0.15)) { self.hole = id }
        }
        let p = ArrangeProvider()
        p.registerDataRepresentation(forTypeIdentifier: k.type.identifier, visibility: .ownProcess) { done in
            done(Data(id.utf8), nil)
            return nil
        }
        p.onEnd = { [weak self] in
            DispatchQueue.main.async { self?.finish(t) }
        }
        return p
    }

    /// Значок прошёл над соседом — тот уже переехал, лёгкий щелчок
    func moved() {
        selection.selectionChanged()
        selection.prepare()
    }

    /// Отпустили (или бросили мимо) — значок встаёт на место
    func finish(_ t: Int? = nil) {
        if let t, t != token { return }
        token += 1
        kind = nil
        item = nil
        guard hole != nil else { return }
        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) { hole = nil }
    }

    /// Включить покачивание без перетаскивания (пункт «Изменить порядок» в меню)
    func enter(_ k: ArrangeKind) {
        guard editing != k else { return }
        Haptics.success()
        withAnimation(.easeOut(duration: 0.2)) { editing = k }
    }

    /// «Готово»
    func done() {
        finish()
        guard editing != nil else { return }
        Haptics.tap()
        withAnimation(.easeOut(duration: 0.2)) { editing = nil }
    }
}

/// Куда «проезжает» перетаскиваемый значок: как только он заходит на соседа, сосед уступает место
struct ArrangeDrop: DropDelegate {
    let kind: ArrangeKind
    /// nil — пустое место в ряду (туда можно только отпустить)
    let target: String?
    let move: (String, String) -> Void

    func validateDrop(info: DropInfo) -> Bool { ArrangeSession.shared.kind == kind }

    func dropEntered(info: DropInfo) {
        let s = ArrangeSession.shared
        guard s.kind == kind, let dragged = s.item, let target, dragged != target else { return }
        withAnimation(.spring(response: 0.34, dampingFraction: 0.8)) { move(dragged, target) }
        s.moved()
    }

    func dropUpdated(info: DropInfo) -> DropProposal? {
        DropProposal(operation: ArrangeSession.shared.kind == kind ? .move : .forbidden)
    }

    func performDrop(info: DropInfo) -> Bool {
        guard ArrangeSession.shared.kind == kind else { return false }
        ArrangeSession.shared.finish()
        return true
    }
}

/// Покачивание значка в режиме перестановки: у каждого свой темп и направление, как на iPhone.
/// Анимация живёт в самом модификаторе — содержимое значка на каждом кадре не пересчитывается
struct Jiggle: ViewModifier {
    let active: Bool
    var amount: Double = 1.8
    @State private var period = Double.random(in: 0.12...0.16)
    @State private var sign: Double = Bool.random() ? 1 : -1

    func body(content: Content) -> some View {
        content.keyframeAnimator(initialValue: 0.0, repeating: active) { view, angle in
            view.rotationEffect(.degrees(angle))
        } keyframes: { _ in
            KeyframeTrack {
                CubicKeyframe(amount * sign, duration: period / 2)
                CubicKeyframe(-amount * sign, duration: period)
                CubicKeyframe(0, duration: period / 2)
            }
        }
    }
}

private struct ArrangeItem<Preview: View>: ViewModifier {
    let id: String
    let kind: ArrangeKind
    let amount: Double
    let move: (String, String) -> Void
    let onRemove: (() -> Void)?
    let preview: Preview
    @ObservedObject private var session = ArrangeSession.shared

    func body(content: Content) -> some View {
        let editing = session.editing == kind
        let lifted = session.hole == id
        content
            // пока всё покачивается, нажатие ничего не открывает — только перестановка
            .overlay {
                if editing {
                    Color.clear
                        .contentShape(Rectangle())
                        .onTapGesture { Haptics.tap() }
                }
            }
            .overlay(alignment: .topLeading) {
                if editing, let onRemove, !lifted {
                    Button {
                        Haptics.tap()
                        withAnimation(.spring(response: 0.34, dampingFraction: 0.8)) { onRemove() }
                    } label: {
                        Image(systemName: "minus")
                            .font(.system(size: 11, weight: .heavy))
                            .foregroundStyle(.primary)
                            .frame(width: 24, height: 24)
                            .background(.regularMaterial, in: Circle())
                            .overlay(Circle().strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.5))
                            .contentShape(Circle().inset(by: -8))
                    }
                    .buttonStyle(.plain)
                    .offset(x: -7, y: -7)
                    .transition(.scale(scale: 0.4).combined(with: .opacity))
                    .accessibilityLabel("Убрать")
                }
            }
            .opacity(lifted ? 0.15 : 1)
            .scaleEffect(lifted ? 0.92 : 1)
            .modifier(Jiggle(active: editing && !lifted, amount: amount))
            .onDrag {
                session.start(id, kind: kind)
            } preview: {
                preview
            }
            .onDrop(of: [kind.type], delegate: ArrangeDrop(kind: kind, target: id, move: move))
    }
}

extension View {
    /// Значок или блок, который можно переставлять, как на рабочем столе iPhone.
    /// `move(тащат, на_место)` должен переставить элементы в данных — остальное сделает анимация
    func arrangeable<P: View>(_ id: String, kind: ArrangeKind, amount: Double = 1.8,
                              move: @escaping (String, String) -> Void,
                              onRemove: (() -> Void)? = nil,
                              @ViewBuilder preview: () -> P) -> some View {
        modifier(ArrangeItem(id: id, kind: kind, amount: amount, move: move, onRemove: onRemove, preview: preview()))
    }

    /// Ряд или сетка, куда можно отпустить значок (между значками)
    func arrangeDropZone(_ kind: ArrangeKind) -> some View {
        onDrop(of: [kind.type], delegate: ArrangeDrop(kind: kind, target: nil, move: { _, _ in }))
    }
}

/// Плашка «Готово» сверху, пока всё покачивается
struct ArrangeDoneBar: View {
    @ObservedObject private var session = ArrangeSession.shared

    var body: some View {
        if let k = session.editing {
            HStack(spacing: 10) {
                Image(systemName: "hand.draw.fill")
                    .foregroundStyle(Color.brand)
                Text(k.hint)
                    .font(.footnote.weight(.semibold))
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
                Spacer(minLength: 6)
                Button {
                    session.done()
                } label: {
                    Text("Готово")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
            .padding(.leading, 14)
            .padding(.trailing, 6)
            .padding(.vertical, 6)
            .liveGlass(24)
            .shadow(color: .black.opacity(0.18), radius: 14, y: 6)
            .padding(.horizontal, 14)
            .transition(.move(edge: .top).combined(with: .opacity))
        }
    }
}

/// Переставить элемент `dragged` на место `target` в списке идентификаторов
enum ArrangeOrder {
    static func moved(_ list: [String], _ dragged: String, to target: String) -> [String]? {
        guard dragged != target, let i = list.firstIndex(of: dragged), let j = list.firstIndex(of: target) else { return nil }
        var out = list
        out.remove(at: i)
        out.insert(dragged, at: j)
        return out
    }
}
