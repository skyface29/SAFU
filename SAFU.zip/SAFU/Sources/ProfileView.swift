import SwiftUI
import UIKit

struct ProfileView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("home.showNow") private var showNow = true
    @AppStorage("home.showToday.v2") private var showToday = false
    @AppStorage("home.showQuick") private var showQuick = true
    @AppStorage("home.showRecents") private var showRecents = true
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("ambient") private var ambient = true
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("animations") private var animations = true
    @AppStorage("web.light") private var webLight = true
    @State private var confirmClearSchedule = false
    @AppStorage("user.name") private var userName = "Кирилл"
    @AppStorage("backup.last") private var lastBackup: Double = 0
    @AppStorage("notify.digest") private var digest = true

    private var backupOld: Bool {
        lastBackup == 0 || Date().timeIntervalSinceReferenceDate - lastBackup > 7 * 86_400
    }
    @AppStorage("user.role") private var role = 0

    private var roleTitle: String {
        switch role {
        case 1: return "Староста"
        case 2: return "Зам. старосты"
        default: return "Студент САФУ"
        }
    }
    @AppStorage("web.savePasswords") private var savePasswords = true
    @AppStorage("web.autoLogin") private var autoLogin = true
    @AppStorage("notify.pairs") private var notifyPairs = true
    @AppStorage("notify.pairMinutes") private var notifyMinutes = 10
    @AppStorage("notify.changes") private var notifyChanges = true
    @AppStorage("live.enabled") private var liveEnabled = true
    @AppStorage("home.showTools") private var showTools = true
    @AppStorage("home.showSubjects") private var showSubjects = true
    @AppStorage("group") private var group = "151621"
    @AppStorage("notes") private var notes = ""
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("haptics") private var haptics = true
    @AppStorage("lockFiles") private var lockFiles = false
    @State private var memoryCleared = false

    private var version: String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
    }

    private var startBinding: Binding<Date> {
        Binding(get: { schedule.data.semesterStart },
                set: { schedule.data.semesterStart = $0 })
    }

    var body: some View {
        NavigationStack {
            Form {
                Group {
                Section {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle().fill(brandGradient)
                            Image(systemName: "snowflake")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 60, height: 60)
                        VStack(alignment: .leading, spacing: 4) {
                            TextField("Твоё имя", text: $userName)
                                .font(.system(.title3, design: .rounded).weight(.bold))
                                .textInputAutocapitalization(.words)
                            Text(roleTitle + (group.isEmpty ? "" : " · группа \(group)"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 6)
                }

                Section {
                    Picker("Роль в группе", selection: $role) {
                        Text("Студент").tag(0)
                        Text("Староста").tag(1)
                        Text("Зам. старосты").tag(2)
                    }
                } footer: {
                    Text(role == 0 ? "Старосте и заму откроется «Посещаемость»: отметки ребят на каждой паре." :
                            "«Посещаемость» — в инструментах на главной и в карточке любой пары.")
                }

                Section {
                    NavigationLink {
                        FeaturesView().environmentObject(schedule)
                    } label: {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Функции").fontWeight(.semibold)
                                Text("Утро, автобус, группа, маршруты, Siri").font(.caption).foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "switch.2").foregroundStyle(brandGradient)
                        }
                    }
                }

                Section("Оформление") {
                    Button {
                        Haptics.tap()
                        UserDefaults.standard.set(true, forKey: "ui.appearanceOpen")
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10, style: .continuous).fill(brandGradient)
                                Image(systemName: "paintpalette.fill")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                            .frame(width: 36, height: 36)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Оформление").fontWeight(.semibold).foregroundStyle(.primary)
                                Text("Стили, цвет, фон, карточки, шрифт, иконка")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            HStack(spacing: -6) {
                                ForEach([AccentTheme.cyber, .aurora, .gold], id: \.self) { th in
                                    Circle()
                                        .fill(LinearGradient(colors: [th.color, th.secondary],
                                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 18, height: 18)
                                        .overlay(Circle().strokeBorder(Color(.systemBackground), lineWidth: 1.5))
                                }
                            }
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.tertiary)
                        }
                    }
                }

                Section {
                    NavigationLink {
                        HomeEditor().environmentObject(store)
                    } label: {
                        Label("Главный экран", systemImage: "rectangle.3.group")
                    }
                    NavigationLink {
                        TabsEditor()
                    } label: {
                        Label("Нижняя панель", systemImage: "dock.rectangle")
                    }
                    NavigationLink {
                        CommuteSettingsView().environmentObject(schedule)
                    } label: {
                        Label("Дорога и автобусы", systemImage: "bus.fill")
                    }
                    NavigationLink {
                        BackupView()
                    } label: {
                        HStack {
                            Label("Резервная копия", systemImage: "externaldrive.badge.checkmark")
                            if backupOld {
                                Spacer()
                                Text("давно не было")
                                    .font(.caption2.weight(.bold))
                                    .foregroundStyle(.orange)
                            }
                        }
                    }
                } header: {
                    Text("Настроить интерфейс")
                } footer: {
                    Text("Меняй порядок блоков и вкладок, убирай ненужное и добавляй своё.")
                }

                Section {
                    Toggle("Сайты всегда светлые", isOn: $webLight)
                } header: {
                    Text("Сайты")
                } footer: {
                    Text("Sakai и другие сайты вуза в тёмной теме показывают тёмный текст на тёмном фоне. Эта настройка это исправляет.")
                }

                Section("Учёба") {
                    HStack {
                        Text("Группа")
                        Spacer()
                        TextField("номер", text: $group)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.secondary)
                    }
                    DatePicker("Начало семестра", selection: startBinding, displayedComponents: .date)
                    if schedule.archivedWeeks > 0 {
                        Button {
                            schedule.clearHistory()
                            Haptics.success()
                        } label: {
                            Label("Очистить архив расписания (\(schedule.archivedWeeks) нед.)", systemImage: "archivebox")
                        }
                    }
                    if schedule.hasLessons {
                        Button(role: .destructive) { confirmClearSchedule = true } label: {
                            Label("Удалить всё расписание", systemImage: "calendar.badge.minus")
                        }
                    }
                }

                Section {
                    InfoRow(icon: "square.grid.2x2", text: "Зажми пустое место на экране «Домой» → «Изменить» → «Добавить виджет» → САФУ. Есть маленький и средний виджеты.")
                    InfoRow(icon: "lock.iphone", text: "На экран блокировки: зажми экран блокировки → «Настроить» → виджеты → САФУ.")
                    InfoRow(icon: "antenna.radiowaves.left.and.right", text: "Виджет сам загружает пары из РУЗ для группы 151621. Другую группу можно указать так: удержать виджет → «Изменить виджет».")
                } header: {
                    Text("Виджет")
                }

                }
                Group {
                Section {
                    Toggle(isOn: $lockFiles) {
                        Label("Файлы по Face ID", systemImage: "faceid")
                    }
                } header: {
                    Text("Безопасность")
                } footer: {
                    Text("Вкладка «Файлы» будет открываться только после Face ID или код-пароля.")
                }

                Section {
                    Toggle(isOn: $liveEnabled) { Label("Пара на экране блокировки", systemImage: "platter.filled.bottom.iphone") }
                        .onChange(of: liveEnabled) { _ in schedule.refreshSideEffects() }
                    if liveEnabled {
                        NavigationLink {
                            LiveStyleView().environmentObject(schedule)
                        } label: {
                            Label("Вид Live Activity", systemImage: "paintpalette.fill")
                        }
                    }
                    Toggle(isOn: $notifyPairs) { Label("Напоминать о парах", systemImage: "bell.badge.fill") }
                        .onChange(of: notifyPairs) { _ in
                            Notifier.requestAuthorization()
                            schedule.refreshSideEffects()
                        }
                    if notifyPairs {
                        Picker("За сколько минут", selection: $notifyMinutes) {
                            Text("5").tag(5)
                            Text("10").tag(10)
                            Text("15").tag(15)
                            Text("30").tag(30)
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: notifyMinutes) { _ in schedule.refreshSideEffects() }
                    }
                    Toggle(isOn: $notifyChanges) { Label("Сообщать об изменениях в РУЗ", systemImage: "exclamationmark.arrow.triangle.2.circlepath") }
                    Toggle(isOn: $digest) { Label("Итоги недели по воскресеньям", systemImage: "calendar.badge.clock") }
                        .onChange(of: digest) { _ in schedule.refreshSideEffects() }
                } header: {
                    Text("Уведомления и экран блокировки")
                } footer: {
                    Text("Live Activity показывает текущую или следующую пару с таймером, аудиторией и адресом на экране блокировки и в Dynamic Island. Обновляется при открытии приложения.")
                }

                Section {
                    Toggle(isOn: $savePasswords) { Label("Запоминать пароли", systemImage: "key.fill") }
                    Toggle(isOn: $autoLogin) { Label("Входить автоматически", systemImage: "bolt.fill") }
                        .disabled(!savePasswords)
                    NavigationLink {
                        PasswordsView()
                    } label: {
                        Label("Сохранённые пароли", systemImage: "lock.rectangle.stack")
                    }
                } header: {
                    Text("Пароли и вход")
                } footer: {
                    Text("Вход на сайты сохраняется даже после перезапуска приложения. Пароли лежат в связке ключей iPhone, зашифрованно.")
                }

                Section("Полезно знать") {
                    InfoRow(icon: "calendar", text: "Расписание подтягивается из РУЗ автоматически, вкладка «Пары».")
                    InfoRow(icon: "key.fill", text: "Вход в почту и Sakai: адрес почты САФУ и пароль от учётной записи.")
                    InfoRow(icon: "person.badge.key.fill", text: "Первокурсникам сначала нужно активировать учётную запись.")
                }

                Section("Поддержка") {
                    Link(destination: URL(string: "mailto:sakai@narfu.ru")!) {
                        Label("sakai@narfu.ru: активация, Sakai", systemImage: "envelope")
                    }
                }

                Section {
                    NavigationLink {
                        DeveloperView()
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(brandGradient)
                                Text("КЗ").font(.system(size: 14, weight: .heavy, design: .rounded)).foregroundStyle(.white)
                            }
                            .frame(width: 38, height: 38)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Разработчик и о приложении").fontWeight(.semibold)
                                Text("\(Developer.name) · @\(Developer.telegram) · версия \(Developer.version)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                    }
                }

                Section("Заметки") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 140)
                }

                Section {
                    Button {
                        store.clearMemory()
                        Haptics.success()
                        withAnimation { memoryCleared = true }
                    } label: {
                        Label(memoryCleared ? "Память очищена" : "Очистить недавние и сохранённые страницы",
                              systemImage: memoryCleared ? "checkmark.circle.fill" : "clock.arrow.circlepath")
                    }
                } header: {
                    Text("Память")
                } footer: {
                    Text("Приложение запоминает недавние сайты, последнюю открытую страницу в каждом и вкладку, на которой ты был.")
                }

                Section {
                    HStack {
                        Text("Версия")
                        Spacer()
                        Text(version).foregroundStyle(.secondary)
                    }
                }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Профиль")
            .confirmationDialog("Удалить все пары?", isPresented: $confirmClearSchedule, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) { schedule.clearAll() }
            }
        }
    }
}

private struct InfoRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Color.brand)
                .frame(width: 24)
            Text(text)
        }
    }
}


struct PasswordsView: View {
    @State private var list: [SiteCredential] = CredentialStore.all()
    @State private var confirmLogout = false

    var body: some View {
        List {
            Section {
                if list.isEmpty {
                    Text("Пока нет. Войди на сайт внутри приложения, и оно предложит сохранить пароль.")
                        .foregroundStyle(.secondary)
                }
                ForEach(list) { c in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(c.host).font(.headline)
                        Text(c.user.isEmpty ? "—" : c.user)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                .onDelete { idx in
                    for i in idx { CredentialStore.delete(list[i].host) }
                    list = CredentialStore.all()
                }
            } footer: {
                Text("Смахни влево, чтобы удалить. Сами пароли не показываются.")
            }

            Section {
                Button(role: .destructive) { confirmLogout = true } label: {
                    Label("Выйти со всех сайтов и удалить пароли", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }
        }
        .navigationTitle("Пароли")
        .confirmationDialog("Выйти со всех сайтов и удалить сохранённые пароли?",
                            isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Выйти и удалить", role: .destructive) {
                CredentialStore.deleteAll()
                SessionKeeper.clearAll { list = [] }
                Haptics.success()
            }
        }
    }
}


struct AppIconPicker: View {
    @State private var current: String? = UIApplication.shared.alternateIconName
    @State private var failed = false

    private struct Icon: Identifiable {
        let id: String?
        let preview: String
        let title: String
        var key: String { id ?? "classic" }
    }

    private let colors: [Icon] = [
        Icon(id: nil, preview: "IconPreview-Classic", title: "Классика"),
        Icon(id: "AppIcon-Night", preview: "IconPreview-Night", title: "Ночь"),
        Icon(id: "AppIcon-Ice", preview: "IconPreview-Ice", title: "Лёд"),
        Icon(id: "AppIcon-Mint", preview: "IconPreview-Mint", title: "Мята"),
        Icon(id: "AppIcon-Violet", preview: "IconPreview-Violet", title: "Фиолет"),
        Icon(id: "AppIcon-Sunset", preview: "IconPreview-Sunset", title: "Закат"),
        Icon(id: "AppIcon-Mono", preview: "IconPreview-Mono", title: "Минимал")
    ]

    private let designs: [Icon] = [
        Icon(id: "AppIcon-Aurora", preview: "IconPreview-Aurora", title: "Сияние"),
        Icon(id: "AppIcon-Shield", preview: "IconPreview-Shield", title: "Защита"),
        Icon(id: "AppIcon-Letter", preview: "IconPreview-Letter", title: "Буква С"),
        Icon(id: "AppIcon-Cap", preview: "IconPreview-Cap", title: "Выпускник"),
        Icon(id: "AppIcon-Glass", preview: "IconPreview-Glass", title: "Стекло"),
        Icon(id: "AppIcon-Pixel", preview: "IconPreview-Pixel", title: "Пиксель"),
        Icon(id: "AppIcon-Neon", preview: "IconPreview-Neon", title: "Неон")
    ]

    private let columns = [GridItem(.adaptive(minimum: 76), spacing: 14)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                group("Дизайны", designs)
                group("Цвета", colors)
                if failed {
                    Text("iOS не дал сменить иконку. Попробуй ещё раз или перезапусти приложение.")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Иконка")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func group(_ title: String, _ list: [Icon]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.system(.headline, design: .rounded))
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(list) { icon in cell(icon) }
            }
        }
    }

    private func cell(_ icon: Icon) -> some View {
        let selected = current == icon.id
        return Button {
            guard UIApplication.shared.supportsAlternateIcons, current != icon.id else { return }
            UIApplication.shared.setAlternateIconName(icon.id) { error in
                DispatchQueue.main.async {
                    if error == nil {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { current = icon.id }
                        failed = false
                        Haptics.success()
                    } else {
                        failed = true
                    }
                }
            }
        } label: {
            VStack(spacing: 7) {
                Image(icon.preview)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 66, height: 66)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: .black.opacity(0.25), radius: 6, y: 3)
                    .overlay(
                        RoundedRectangle(cornerRadius: 19, style: .continuous)
                            .strokeBorder(selected ? Color.brand : Color.clear, lineWidth: 3)
                            .padding(-5)
                    )
                    .overlay(alignment: .bottomTrailing) {
                        if selected {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 20))
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(.white, Color.brand)
                                .offset(x: 8, y: 8)
                        }
                    }
                    .scaleEffect(selected ? 1.04 : 1)
                Text(icon.title)
                    .font(.caption2.weight(selected ? .bold : .medium))
                    .foregroundStyle(selected ? Color.brand : Color.secondary)
                    .lineLimit(1)
            }
            .padding(.vertical, 4)
        }
        .buttonStyle(.plain)
    }
}


// MARK: - Настройка вида Live Activity

struct LiveStyleView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("live.theme") private var theme = LiveTheme.night.rawValue
    @AppStorage("live.layout") private var layout = LiveLayout.full.rawValue

    var body: some View {
        Form {
            Section {
                preview
                    .listRowInsets(EdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12))
                    .listRowBackground(Color.clear)
            } header: {
                Text("Так будет на экране блокировки")
            }

            Section("Размер") {
                Picker("Размер", selection: $layout) {
                    ForEach(LiveLayout.allCases) { l in Text(l.title).tag(l.rawValue) }
                }
                .pickerStyle(.segmented)
            }

            Section {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: 10)], spacing: 10) {
                    ForEach(LiveTheme.allCases) { t in
                        Button {
                            Haptics.tap()
                            theme = t.rawValue
                        } label: {
                            VStack(spacing: 6) {
                                swatch(t)
                                    .frame(height: 44)
                                    .overlay {
                                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                                            .strokeBorder(theme == t.rawValue ? Color.brand : Color.primary.opacity(0.1),
                                                          lineWidth: theme == t.rawValue ? 2.5 : 1)
                                    }
                                Text(t.title)
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.8)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Тема")
            } footer: {
                Text("«Прозрачная» почти не видна на фоне обоев, «Стекло» — системное размытие, как у музыки. Dynamic Island всегда тёмный — так устроен iOS.")
            }
        }
        .navigationTitle("Live Activity")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: theme) { _ in schedule.refreshSideEffects() }
        .onChange(of: layout) { _ in schedule.refreshSideEffects() }
    }

    private var preview: some View {
        let t = LiveTheme(rawValue: theme) ?? .night
        return LiveLockScreenView(state: .sample(theme: theme, layout: layout))
            .environment(\.colorScheme, .dark)
            .background { themeBackground(t) }
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .padding(10)
            .background {
                // «обои» под превью, чтобы было видно прозрачность
                LinearGradient(colors: [Color(red: 0.20, green: 0.28, blue: 0.40), Color(red: 0.40, green: 0.45, blue: 0.55)],
                               startPoint: .top, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            }
            .animation(.spring(response: 0.35, dampingFraction: 0.85), value: theme)
            .animation(.spring(response: 0.35, dampingFraction: 0.85), value: layout)
    }

    @ViewBuilder private func themeBackground(_ t: LiveTheme) -> some View {
        if let tint = t.tint, t != .clear {
            tint
        } else if t == .clear {
            Color.white.opacity(0.06)
        } else {
            Rectangle().fill(.ultraThinMaterial)
        }
    }

    private func swatch(_ t: LiveTheme) -> some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.20, green: 0.28, blue: 0.40), Color(red: 0.40, green: 0.45, blue: 0.55)],
                           startPoint: .top, endPoint: .bottom)
            themeBackground(t)
            if let g = t.gradient(for: "Лекция") { g }
            Text("10:10")
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(t.adaptiveText ? Color.white : t.accent)
        }
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}
