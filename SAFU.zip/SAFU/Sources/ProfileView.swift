import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var store: ResourceStore
    @AppStorage("group") private var group = "151621"
    @AppStorage("notes") private var notes = ""
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("haptics") private var haptics = true
    @AppStorage("lockFiles") private var lockFiles = false
    @AppStorage("semesterStart") private var semesterStart = Academic.defaultStart.timeIntervalSince1970
    @State private var memoryCleared = false

    private var version: String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
    }

    private var startBinding: Binding<Date> {
        Binding(get: { Date(timeIntervalSince1970: semesterStart) },
                set: { semesterStart = $0.timeIntervalSince1970 })
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle().fill(brandGradient)
                            Image(systemName: "snowflake")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 60, height: 60)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Студент САФУ")
                                .font(.system(.title3, design: .rounded).weight(.bold))
                            Text(group.isEmpty ? "Группа не указана" : "Группа \(group)")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 6)
                }

                Section("Оформление") {
                    HStack {
                        ForEach(AccentTheme.allCases) { th in
                            Circle()
                                .fill(LinearGradient(colors: [th.color, th.secondary],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 34, height: 34)
                                .overlay(
                                    Circle()
                                        .strokeBorder(Color.primary.opacity(theme == th.rawValue ? 0.8 : 0), lineWidth: 2)
                                        .padding(-5)
                                )
                                .frame(maxWidth: .infinity)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    Haptics.tap()
                                    theme = th.rawValue
                                }
                        }
                    }
                    .padding(.vertical, 8)
                    Toggle("Вибрация", isOn: $haptics)
                }

                Section("Учёба") {
                    HStack {
                        Text("Группа")
                        Spacer()
                        TextField("номер", text: $group)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.secondary)
                    }
                    DatePicker("Начало семестра", selection: startBinding, displayedComponents: .date)
                }

                Section {
                    Toggle(isOn: $lockFiles) {
                        Label("Файлы по Face ID", systemImage: "faceid")
                    }
                } header: {
                    Text("Безопасность")
                } footer: {
                    Text("Вкладка «Файлы» будет открываться только после Face ID или код-пароля.")
                }

                Section("Полезно знать") {
                    InfoRow(icon: "calendar", text: "Расписание 1–2 курса в Модеусе, вкладка «Моё расписание».")
                    InfoRow(icon: "key.fill", text: "Вход в почту и Модеус: адрес почты САФУ и пароль от учётной записи.")
                    InfoRow(icon: "person.badge.key.fill", text: "Первокурсникам сначала нужно активировать учётную запись.")
                }

                Section("Поддержка") {
                    Link(destination: URL(string: "mailto:sakai@narfu.ru")!) {
                        Label("sakai@narfu.ru: активация, Sakai", systemImage: "envelope")
                    }
                    Link(destination: URL(string: "mailto:narfu@modeus.org")!) {
                        Label("narfu@modeus.org: Модеус", systemImage: "envelope")
                    }
                }

                Section("Заметки") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 140)
                }

                Section {
                    Button {
                        store.clearMemory()
                        Haptics.success()
                        withAnimation { memoryCleared = true }
                    } label: {
                        Label(memoryCleared ? "Память очищена" : "Очистить недавние и сохранённые страницы",
                              systemImage: memoryCleared ? "checkmark.circle.fill" : "clock.arrow.circlepath")
                    }
                } header: {
                    Text("Память")
                } footer: {
                    Text("Приложение запоминает недавние сайты, последнюю открытую страницу в каждом и вкладку, на которой ты был.")
                }

                Section {
                    HStack {
                        Text("Версия")
                        Spacer()
                        Text(version).foregroundStyle(.secondary)
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Профиль")
        }
    }
}

private struct InfoRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Color.brand)
                .frame(width: 24)
            Text(text)
        }
    }
}
