import SwiftUI
import UIKit
import WidgetKit

struct ProfileView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("home.showNow") private var showNow = true
    @AppStorage("home.showToday.v2") private var showToday = false
    @AppStorage("home.showQuick") private var showQuick = true
    @AppStorage("home.showRecents") private var showRecents = true
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("ambient") private var ambient = true
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("animations") private var animations = true
    @AppStorage("web.light") private var webLight = true
    @State private var confirmClearSchedule = false
    @AppStorage("user.name") private var userName = ""
    @AppStorage("backup.last") private var lastBackup: Double = 0
    @AppStorage("notify.digest") private var digest = true

    private var backupOld: Bool {
        lastBackup == 0 || Date().timeIntervalSinceReferenceDate - lastBackup > 7 * 86_400
    }
    @AppStorage("user.role") private var role = 0

    private var roleTitle: String {
        switch role {
        case 1: return "Староста"
        case 2: return "Зам. старосты"
        case 3: return "Преподаватель САФУ"
        default: return "Студент САФУ"
        }
    }
    @AppStorage("web.savePasswords") private var savePasswords = true
    @AppStorage("web.autoLogin") private var autoLogin = true
    @AppStorage("notify.pairs") private var notifyPairs = true
    @AppStorage("notify.pairMinutes") private var notifyMinutes = 10
    @AppStorage("notify.changes") private var notifyChanges = true
    @AppStorage("live.enabled") private var liveEnabled = true
    @AppStorage("live.always") private var liveAlways = true
    @AppStorage("home.showTools") private var showTools = true
    @AppStorage("home.showSubjects") private var showSubjects = true
    @AppStorage("group") private var group = ""
    @AppStorage("notes") private var notes = ""
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("haptics") private var haptics = true
    @AppStorage("lockFiles") private var lockFiles = false
    @AppStorage(AppLock.key) private var lockApp = false
    @AppStorage("privacy.shield") private var privacyShield = true
    @AppStorage("widget.theme") private var widgetTheme = WidgetTheme.night.rawValue
    @AppStorage("widget.teacher") private var widgetTeacher = true
    @State private var widgetLink: (ok: Bool, text: String)?

    /// Отдать виджету оформление и расписание и попросить его обновиться
    private func pushWidget() {
        WidgetBridge.publishLook(theme: widgetTheme, showTeacher: widgetTeacher)
        WidgetBridge.publish(schedule.data)
        WidgetCenter.shared.reloadAllTimelines()
    }
    @State private var memoryCleared = false

    private var version: String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
    }

    private var startBinding: Binding<Date> {
        Binding(get: { schedule.data.semesterStart },
                set: { schedule.data.semesterStart = $0 })
    }

    var body: some View {
        NavigationStack {
            Form {
                Group {
                Section {
                    HStack(spacing: 14) {
                        // нажми, чтобы поставить своё фото
                        AvatarEditor(size: 64)
                        VStack(alignment: .leading, spacing: 4) {
                            TextField("Твоё имя", text: $userName)
                                .font(.system(.title3, design: .rounded).weight(.bold))
                                .textInputAutocapitalization(.words)
                            Text(roleTitle + (group.isEmpty ? "" : " · группа \(group)"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 6)
                }

                Section {
                    Button {
                        Haptics.tap()
                        UserDefaults.standard.set(true, forKey: "onboarding.again")
                    } label: {
                        Label(TeacherMode.isOn ? "Сменить школу или фамилию — пройти настройку заново"
                                               : "Сменить группу или школу — пройти настройку заново", systemImage: "arrow.triangle.2.circlepath")
                    }
                    if TeacherMode.isOn {
                        LabeledContent("Как вы записаны в РУЗ", value: TeacherMode.query)
                    } else {
                        Picker("Роль в группе", selection: $role) {
                            Text("Студент").tag(0)
                            Text("Староста").tag(1)
                            Text("Зам. старосты").tag(2)
                        }
                    }
                } footer: {
                    Text(role == 3 ? "Бета. " + TeacherMode.betaNote :
                            role == 0 ? "Старосте и заму откроется «Посещаемость»: отметки ребят на каждой паре." :
                            "«Посещаемость» — в инструментах на главной и в карточке любой пары.")
                }

                Section {
                    NavigationLink {
                        FeaturesView().environmentObject(schedule)
                    } label: {
                        Label {
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Функции").fontWeight(.semibold)
                                Text("Утро, автобус, группа, маршруты, Siri").font(.caption).foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "switch.2").foregroundStyle(brandGradient)
                        }
                    }
                }

                Section("Оформление") {
                    Button {
                        Haptics.tap()
                        UserDefaults.standard.set(true, forKey: "ui.appearanceOpen")
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 10, style: .continuous).fill(brandGradient)
                                Image(systemName: "paintpalette.fill")
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                            .frame(width: 36, height: 36)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Оформление").fontWeight(.semibold).foregroundStyle(.primary)
                                Text("Стили, цвет, фон, карточки, шрифт, иконка")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            HStack(spacing: -6) {
                                ForEach([AccentTheme.cyber, .aurora, .gold], id: \.self) { th in
                                    Circle()
                                        .fill(LinearGradient(colors: [th.color, th.secondary],
                                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                                        .frame(width: 18, height: 18)
                                        .overlay(Circle().strokeBorder(Color(.systemBackground), lineWidth: 1.5))
                                }
                            }
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.tertiary)
                        }
                    }
                }

                Section {
                    NavigationLink {
                        HomeEditor().environmentObject(store)
                    } label: {
                        Label("Главный экран", systemImage: "rectangle.3.group")
                    }
                    NavigationLink {
                        TabsEditor()
                    } label: {
                        #if targetEnvironment(macCatalyst)
                        Label("Разделы боковой панели", systemImage: "sidebar.left")
                        #else
                        Label("Нижняя панель", systemImage: "dock.rectangle")
                        #endif
                    }
                    NavigationLink {
                        CommuteSettingsView().environmentObject(schedule)
                    } label: {
                        Label("Дорога и автобусы", systemImage: "bus.fill")
                    }
                    NavigationLink {
                        PCSyncView()
                    } label: {
                        #if targetEnvironment(macCatalyst)
                        Label("Синхронизация с iPhone", systemImage: "arrow.triangle.2.circlepath")
                        #else
                        Label("Синхронизация с компьютером", systemImage: "arrow.triangle.2.circlepath")
                        #endif
                    }
                    #if !targetEnvironment(macCatalyst)
                    NavigationLink {
                        PCTransferView()
                    } label: {
                        Label("Перенос на компьютер", systemImage: "laptopcomputer.and.arrow.down")
                    }
                    #endif
                    NavigationLink {
                        BackupView()
                    } label: {
                        HStack {
                            Label("Резервная копия", systemImage: "externaldrive.badge.checkmark")
                            if backupOld {
                                Spacer()
                                Text("давно не было")
                                    .font(.caption2.weight(.bold))
                                    .foregroundStyle(.orange)
                            }
                        }
                    }
                } header: {
                    Text("Настроить интерфейс")
                } footer: {
                    Text("Меняй порядок блоков и вкладок, убирай ненужное и добавляй своё.")
                }

                Section {
                    Toggle("Сайты всегда светлые", isOn: $webLight)
                } header: {
                    Text("Сайты")
                } footer: {
                    Text("Sakai и другие сайты вуза в тёмной теме показывают тёмный текст на тёмном фоне. Эта настройка это исправляет.")
                }

                Section("Учёба") {
                    NavigationLink {
                        MailNotifyView()
                    } label: {
                        Label("Уведомления о письмах", systemImage: "envelope.badge.fill")
                    }
                    HStack {
                        Text("Группа")
                        Spacer()
                        TextField("номер", text: $group)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.secondary)
                    }
                    DatePicker("Начало семестра", selection: startBinding, displayedComponents: .date)
                    if schedule.archivedWeeks > 0 {
                        Button {
                            schedule.clearHistory()
                            Haptics.success()
                        } label: {
                            Label("Очистить архив расписания (\(schedule.archivedWeeks) нед.)", systemImage: "archivebox")
                        }
                    }
                    if schedule.hasLessons {
                        Button(role: .destructive) { confirmClearSchedule = true } label: {
                            Label("Удалить всё расписание", systemImage: "calendar.badge.minus")
                        }
                    }
                }

                Section {
                    #if targetEnvironment(macCatalyst)
                    InfoRow(icon: "square.grid.2x2", text: "Правый клик по рабочему столу → «Изменить виджеты» → Арктика (не раздел «iPhone»). Есть маленький, средний и большой виджеты, их можно поставить и в Центр уведомлений.")
                    #else
                    InfoRow(icon: "square.grid.2x2", text: "Зажми пустое место на экране «Домой» → «Изменить» → «Добавить виджет» → Арктика. Есть маленький и средний виджеты.")
                    InfoRow(icon: "lock.iphone", text: "На экран блокировки: зажми экран блокировки → «Настроить» → виджеты → Арктика.")
                    #endif
                    #if targetEnvironment(macCatalyst)
                    InfoRow(icon: "paintpalette.fill", text: "Стили: в галерее Арктики — «Пары» и «Пары · Сияние», «Графит», «Бордо», «Хвоя», «Закат», «Светлый». Каждый стиль — отдельный виджет.")
                    InfoRow(icon: "antenna.radiowaves.left.and.right", text: "Виджет сам берёт группу и пары у Арктики на этом Mac — iPhone рядом не нужен. Если данных нет, грузит пары из РУЗ сам, кнопка ↻ — обновить.")
                    #else
                    InfoRow(icon: "paintpalette.fill", text: "Стили: в галерее Арктики листай вбок — «Пары · Сияние», «Графит», «Бордо», «Хвоя», «Закат», «Светлый», «Прозрачный». Каждый стиль — отдельный виджет.")
                    NavigationLink {
                        WidgetWallpaperView()
                    } label: {
                        Label("Прозрачный виджет (фон из обоев)", systemImage: "circle.dashed")
                    }
                    InfoRow(icon: "antenna.radiowaves.left.and.right", text: "Виджет сам берёт группу из приложения. Если подпись не даёт общих данных — он узнает группу из Live Activity пары, как только она появится на экране блокировки. Пары виджет грузит из РУЗ сам, кнопка ↻ — обновить.")
                    #endif
                    Button {
                        pushWidget()
                        let r = SharedKeychain.selfTest()
                        widgetLink = r
                        if r.ok { Haptics.success() }
                    } label: {
                        Label("Проверить связь с виджетом", systemImage: "checkmark.shield")
                    }
                    if let widgetLink {
                        Label(widgetLink.text, systemImage: widgetLink.ok ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                            .font(.caption)
                            .foregroundStyle(widgetLink.ok ? Color.green : Color.orange)
                    }
                    Button {
                        Haptics.success()
                        pushWidget()
                    } label: {
                        Label("Обновить виджет сейчас", systemImage: "arrow.clockwise")
                    }
                } header: {
                    Text("Виджет")
                }

                }
                Group {
                Section {
                    Toggle(isOn: Binding(get: { lockApp }, set: { on in
                        if on {
                            // включаем только после успешной проверки — чтобы не запереть себя
                            AppLock.confirm { ok in
                                lockApp = ok
                                if ok { Haptics.success() }
                            }
                        } else {
                            lockApp = false
                        }
                    })) {
                        Label("Вход по \(AppLock.biometryName)", systemImage: "faceid")
                    }
                    Toggle(isOn: $lockFiles) {
                        Label("Файлы по Face ID", systemImage: "faceid")
                    }
                    Toggle(isOn: $privacyShield) {
                        Label("Прятать экран в переключателе", systemImage: "eye.slash.fill")
                    }
                } header: {
                    Text("Безопасность")
                } footer: {
                    Text("Вход по Face ID — приложение спрашивает его при запуске и после каждого сворачивания. Вкладка «Файлы» может отдельно открываться только после Face ID или код-пароля. В списке открытых приложений вместо оценок, паролей и файлов будет заставка. Пароли и ключи хранятся в связке ключей только на этом iPhone и не попадают в резервные копии.")
                }

                Section {
                    Toggle(isOn: $liveEnabled) { Label("Пара на экране блокировки", systemImage: "platter.filled.bottom.iphone") }
                        .onChange(of: liveEnabled) { _ in schedule.refreshSideEffects() }
                    if liveEnabled {
                        Toggle(isOn: $liveAlways) {
                            Label {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text("Висеть всегда")
                                    Text("Даже без пар — следующая пара и день недели").font(.caption).foregroundStyle(.secondary)
                                }
                            } icon: { Image(systemName: "pin.fill") }
                        }
                        .onChange(of: liveAlways) { _ in schedule.refreshSideEffects() }
                        NavigationLink {
                            LiveStyleView().environmentObject(schedule)
                        } label: {
                            Label("Вид Live Activity", systemImage: "paintpalette.fill")
                        }
                    }
                    Toggle(isOn: $notifyPairs) { Label("Напоминать о парах", systemImage: "bell.badge.fill") }
                        .onChange(of: notifyPairs) { _ in
                            Notifier.requestAuthorization()
                            schedule.refreshSideEffects()
                        }
                    if notifyPairs {
                        Picker("За сколько минут", selection: $notifyMinutes) {
                            Text("5").tag(5)
                            Text("10").tag(10)
                            Text("15").tag(15)
                            Text("30").tag(30)
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: notifyMinutes) { _ in schedule.refreshSideEffects() }
                    }
                    Toggle(isOn: $notifyChanges) { Label("Сообщать об изменениях в РУЗ", systemImage: "exclamationmark.arrow.triangle.2.circlepath") }
                    Toggle(isOn: $digest) { Label("Итоги недели по воскресеньям", systemImage: "calendar.badge.clock") }
                        .onChange(of: digest) { _ in schedule.refreshSideEffects() }
                } header: {
                    Text("Уведомления и экран блокировки")
                } footer: {
                    Text("Live Activity показывает текущую или следующую пару с таймером, аудиторией и адресом на экране блокировки и в Dynamic Island. Обновляется при открытии приложения.")
                }

                Section {
                    Toggle(isOn: $savePasswords) { Label("Запоминать пароли", systemImage: "key.fill") }
                    Toggle(isOn: $autoLogin) { Label("Входить автоматически", systemImage: "bolt.fill") }
                        .disabled(!savePasswords)
                    NavigationLink {
                        // открываются только по Face ID или код-паролю
                        LockGate(always: true, title: "Пароли защищены", reason: "Доступ к сохранённым паролям") {
                            PasswordsView()
                        }
                    } label: {
                        Label("Сохранённые пароли", systemImage: "lock.rectangle.stack")
                    }
                } header: {
                    Text("Пароли и вход")
                } footer: {
                    Text("Вход на сайты сохраняется даже после перезапуска приложения, пароль на сайте подставляется сам. Список сохранённых паролей открывается только по Face ID. Пароли лежат в связке ключей iPhone, зашифрованно.")
                }

                Section("Полезно знать") {
                    InfoRow(icon: "calendar", text: "Расписание подтягивается из РУЗ автоматически, вкладка «Пары».")
                    InfoRow(icon: "key.fill", text: "Вход в почту и Sakai: адрес почты САФУ и пароль от учётной записи.")
                    InfoRow(icon: "person.badge.key.fill", text: "Первокурсникам сначала нужно активировать учётную запись.")
                }

                Section {
                    NavigationLink {
                        LegalView()
                    } label: {
                        Label("Конфиденциальность и данные", systemImage: "hand.raised.fill")
                    }
                } footer: {
                    Text("Неофициальное приложение, не связано с САФУ. Всё хранится только на телефоне.")
                }

                Section {
                    NavigationLink {
                        DeveloperView()
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(brandGradient)
                                Image(systemName: "chevron.left.forwardslash.chevron.right")
                                    .font(.system(size: 13, weight: .bold)).foregroundStyle(.white)
                            }
                            .frame(width: 38, height: 38)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Разработчик и о приложении").fontWeight(.semibold)
                                Text("\(Developer.name) · версия \(Developer.version)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                    }
                }

                NotesPreviewSection()

                Section {
                    Button {
                        store.clearMemory()
                        Haptics.success()
                        withAnimation { memoryCleared = true }
                    } label: {
                        Label(memoryCleared ? "Память очищена" : "Очистить недавние и сохранённые страницы",
                              systemImage: memoryCleared ? "checkmark.circle.fill" : "clock.arrow.circlepath")
                    }
                } header: {
                    Text("Память")
                } footer: {
                    Text("Приложение запоминает недавние сайты, последнюю открытую страницу в каждом и вкладку, на которой ты был.")
                }

                Section {
                    HStack {
                        Text("Версия")
                        Spacer()
                        Text(version).foregroundStyle(.secondary)
                    }
                }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .pausesAmbientWhileScrolling()
            .navigationTitle("Профиль")
            .confirmationDialog("Удалить все пары?", isPresented: $confirmClearSchedule, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) { schedule.clearAll() }
            }
        }
    }
}

struct InfoRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Color.brand)
                .frame(width: 24)
            Text(text)
        }
    }
}


struct PasswordsView: View {
    @State private var list: [SiteCredential] = CredentialStore.all()
    @State private var confirmLogout = false
    @State private var shown: Set<String> = []

    var body: some View {
        List {
            Section {
                if list.isEmpty {
                    Text("Пока нет. Войди на сайт внутри приложения, и оно предложит сохранить пароль.")
                        .foregroundStyle(.secondary)
                }
                ForEach(list) { c in
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(c.host).font(.headline)
                            Text(c.user.isEmpty ? "—" : c.user)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            if shown.contains(c.host) {
                                Text(c.pass)
                                    .font(.system(.subheadline, design: .monospaced))
                                    .textSelection(.enabled)
                            }
                        }
                        Spacer()
                        Button {
                            if shown.contains(c.host) { shown.remove(c.host) } else { shown.insert(c.host) }
                        } label: {
                            Image(systemName: shown.contains(c.host) ? "eye.slash" : "eye")
                        }
                        .buttonStyle(.borderless)
                        Button {
                            // пароль в буфере живёт минуту и не уходит на другие устройства
                            UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: c.pass]],
                                                          options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
                            Haptics.success()
                        } label: {
                            Image(systemName: "doc.on.doc")
                        }
                        .buttonStyle(.borderless)
                    }
                }
                .onDelete { idx in
                    for i in idx { CredentialStore.delete(list[i].host) }
                    list = CredentialStore.all()
                }
            } footer: {
                Text("👁 — показать пароль, ⧉ — скопировать (буфер очистится через минуту). Смахни влево, чтобы удалить.")
            }

            Section {
                Button(role: .destructive) { confirmLogout = true } label: {
                    Label("Выйти со всех сайтов и удалить пароли", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }
        }
        .navigationTitle("Пароли")
        .confirmationDialog("Выйти со всех сайтов и удалить сохранённые пароли?",
                            isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Выйти и удалить", role: .destructive) {
                CredentialStore.deleteAll()
                SessionKeeper.clearAll { list = [] }
                Haptics.success()
            }
        }
    }
}


struct AppIconPicker: View {
    @State private var current: String? = UIApplication.shared.alternateIconName
    @State private var failed = false

    private struct Icon: Identifiable {
        let id: String?
        let preview: String
        let title: String
        var secret = false
        var key: String { id ?? "classic" }
    }

    private let gold = Icon(id: "AppIcon-Gold", preview: "IconPreview-Gold", title: "Золото", secret: true)
    private let exclusive: [Icon] = [
        Icon(id: "AppIcon-Developer", preview: "IconPreview-Developer", title: "Бриллиант", secret: true),
        Icon(id: "AppIcon-Leather", preview: "IconPreview-Leather", title: "Зачётка", secret: true),
        Icon(id: "AppIcon-Steel", preview: "IconPreview-Steel", title: "Сталь", secret: true),
        Icon(id: "AppIcon-Pin", preview: "IconPreview-Pin", title: "Значок", secret: true),
        Icon(id: "AppIcon-Ticket", preview: "IconPreview-Ticket", title: "Билет 150", secret: true)
    ]

    private let colors: [Icon] = [
        Icon(id: nil, preview: "IconPreview-Classic", title: "Классика"),
        Icon(id: "AppIcon-Night", preview: "IconPreview-Night", title: "Ночь"),
        Icon(id: "AppIcon-Ice", preview: "IconPreview-Ice", title: "Лёд"),
        Icon(id: "AppIcon-Mint", preview: "IconPreview-Mint", title: "Мята"),
        Icon(id: "AppIcon-Violet", preview: "IconPreview-Violet", title: "Фиолет"),
        Icon(id: "AppIcon-Sunset", preview: "IconPreview-Sunset", title: "Закат"),
        Icon(id: "AppIcon-Mono", preview: "IconPreview-Mono", title: "Минимал")
    ]

    private let themed: [Icon] = [
        Icon(id: "AppIcon-iOS6", preview: "IconPreview-iOS6", title: "Классика")
    ]

    private let designs: [Icon] = [
        Icon(id: "AppIcon-Aurora", preview: "IconPreview-Aurora", title: "Сияние"),
        Icon(id: "AppIcon-Shield", preview: "IconPreview-Shield", title: "Защита"),
        Icon(id: "AppIcon-Letter", preview: "IconPreview-Letter", title: "Буква С"),
        Icon(id: "AppIcon-Cap", preview: "IconPreview-Cap", title: "Выпускник"),
        Icon(id: "AppIcon-Glass", preview: "IconPreview-Glass", title: "Стекло"),
        Icon(id: "AppIcon-Pixel", preview: "IconPreview-Pixel", title: "Пиксель"),
        Icon(id: "AppIcon-Neon", preview: "IconPreview-Neon", title: "Неон")
    ]

    private let columns = [GridItem(.adaptive(minimum: 76), spacing: 14)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if VipIcons.unlocked { group("Эксклюзив", exclusive) }
                secretGroup
                group("Темы", themed)
                group("Дизайны", designs)
                group("Цвета", colors)
                if failed {
                    Text("iOS не дал сменить иконку. Попробуй ещё раз или перезапусти приложение.")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
            .pausesAmbientWhileScrolling()
        .navigationTitle("Иконка")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var secretGroup: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Секретные").font(.system(.headline, design: .rounded))
            LazyVGrid(columns: columns, spacing: 16) {
                if GoldIcon.unlocked { cell(gold) } else { lockedCell(gold) }
            }
            if !GoldIcon.unlocked {
                Text("Золото открывается, когда все предметы в БРС на «5».")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func lockedCell(_ icon: Icon) -> some View {
        VStack(spacing: 7) {
            Image(icon.preview)
                .resizable()
                .scaledToFill()
                .frame(width: 66, height: 66)
                .blur(radius: 7)
                .overlay(Color.black.opacity(0.35))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                .overlay(Image(systemName: "lock.fill").font(.system(size: 20, weight: .bold)).foregroundStyle(.white))
            Text("???")
                .font(.caption2.weight(.medium))
                .foregroundStyle(.secondary)
        }
    }

    private func group(_ title: String, _ list: [Icon]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.system(.headline, design: .rounded))
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(list) { icon in cell(icon) }
            }
        }
    }

    private func cell(_ icon: Icon) -> some View {
        let selected = current == icon.id
        return Button {
            guard UIApplication.shared.supportsAlternateIcons, current != icon.id else { return }
            UIApplication.shared.setAlternateIconName(icon.id) { error in
                DispatchQueue.main.async {
                    if error == nil {
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.7)) { current = icon.id }
                        failed = false
                        Haptics.success()
                    } else {
                        failed = true
                    }
                }
            }
        } label: {
            VStack(spacing: 7) {
                Image(icon.preview)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 66, height: 66)
                    .overlay { if icon.secret { IconShine() } }
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .shadow(color: icon.secret ? Color(red: 1, green: 0.8, blue: 0.3).opacity(0.6) : .black.opacity(0.25),
                            radius: icon.secret ? 10 : 6, y: 3)
                    .overlay(
                        RoundedRectangle(cornerRadius: 19, style: .continuous)
                            .strokeBorder(selected ? Color.brand : Color.clear, lineWidth: 3)
                            .padding(-5)
                    )
                    .overlay(alignment: .bottomTrailing) {
                        if selected {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.system(size: 20))
                                .symbolRenderingMode(.palette)
                                .foregroundStyle(.white, Color.brand)
                                .offset(x: 8, y: 8)
                        }
                    }
                    .scaleEffect(selected ? 1.04 : 1)
                Text(icon.title)
                    .font(.caption2.weight(selected ? .bold : .medium))
                    .foregroundStyle(selected ? Color.brand : Color.secondary)
                    .lineLimit(1)
            }
            .padding(.vertical, 4)
        }
        .buttonStyle(.plain)
    }
}


// MARK: - Настройка вида Live Activity

struct LiveStyleView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("live.theme") private var theme = LiveTheme.night.rawValue
    @AppStorage("live.layout") private var layout = LiveLayout.full.rawValue
    @AppStorage("live.island") private var island = "timer"

    var body: some View {
        Form {
            Section {
                preview
                    .listRowInsets(EdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12))
                    .listRowBackground(Color.clear)
            } header: {
                Text("Так будет на экране блокировки")
            }

            Section("Размер") {
                Picker("Размер", selection: $layout) {
                    ForEach(LiveLayout.allCases) { l in Text(l.title).tag(l.rawValue) }
                }
                .pickerStyle(.segmented)
            }

            Section {
                Picker("Dynamic Island", selection: $island) {
                    Text("Значок и таймер").tag("timer")
                    Text("Только значок").tag("icon")
                }
                .pickerStyle(.segmented)
            } header: {
                Text("Dynamic Island")
            } footer: {
                Text("Совсем убрать пару из Dynamic Island iOS не позволяет, пока она есть на экране блокировки. «Только значок» — самый маленький вариант. Выключить всё — «Пара на экране блокировки» в Профиле.")
            }

            Section {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: 10)], spacing: 10) {
                    ForEach(LiveTheme.allCases) { t in
                        Button {
                            Haptics.tap()
                            theme = t.rawValue
                        } label: {
                            VStack(spacing: 6) {
                                swatch(t)
                                    .frame(height: 44)
                                    .overlay {
                                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                                            .strokeBorder(theme == t.rawValue ? Color.brand : Color.primary.opacity(0.1),
                                                          lineWidth: theme == t.rawValue ? 2.5 : 1)
                                    }
                                Text(t.title)
                                    .font(.caption2.weight(.semibold))
                                    .foregroundStyle(.primary)
                                    .lineLimit(1)
                                    .minimumScaleFactor(0.8)
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 4)
            } header: {
                Text("Тема")
            } footer: {
                Text("«Прозрачная» почти не видна на фоне обоев, «Стекло» — системное размытие, как у музыки. Dynamic Island всегда тёмный — так устроен iOS.")
            }
        }
        .navigationTitle("Live Activity")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: theme) { _ in schedule.refreshSideEffects() }
        .onChange(of: layout) { _ in schedule.refreshSideEffects() }
        .onChange(of: island) { _ in schedule.refreshSideEffects() }
    }

    private var preview: some View {
        let t = LiveTheme(rawValue: theme) ?? .night
        return LiveLockScreenView(state: .sample(theme: theme, layout: layout))
            .environment(\.colorScheme, .dark)
            .background { themeBackground(t) }
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .padding(10)
            .background {
                // «обои» под превью, чтобы было видно прозрачность
                LinearGradient(colors: [Color(red: 0.20, green: 0.28, blue: 0.40), Color(red: 0.40, green: 0.45, blue: 0.55)],
                               startPoint: .top, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
            }
            .animation(.spring(response: 0.32, dampingFraction: 0.85), value: theme)
            .animation(.spring(response: 0.32, dampingFraction: 0.85), value: layout)
    }

    @ViewBuilder private func themeBackground(_ t: LiveTheme) -> some View {
        if let tint = t.tint, t != .clear {
            tint
        } else if t == .clear {
            Color.white.opacity(0.06)
        } else {
            Rectangle().fill(.ultraThinMaterial)
        }
    }

    private func swatch(_ t: LiveTheme) -> some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.20, green: 0.28, blue: 0.40), Color(red: 0.40, green: 0.45, blue: 0.55)],
                           startPoint: .top, endPoint: .bottom)
            themeBackground(t)
            if let g = t.gradient(for: "Лекция") { g }
            Text("10:10")
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(t.adaptiveText ? Color.white : t.accent)
        }
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

/// Блик, пробегающий по секретным иконкам
struct IconShine: View {
    @State private var move = false

    var body: some View {
        GeometryReader { g in
            LinearGradient(colors: [.clear, .white.opacity(0.6), .clear], startPoint: .leading, endPoint: .trailing)
                .frame(width: g.size.width * 0.45, height: g.size.height * 1.6)
                .rotationEffect(.degrees(22))
                .offset(x: move ? g.size.width * 1.3 : -g.size.width * 0.9, y: -g.size.height * 0.3)
        }
        .allowsHitTesting(false)
        .onAppear {
            withAnimation(.easeInOut(duration: 1.6).delay(0.3).repeatForever(autoreverses: false)) { move = true }
        }
    }
}
