import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("home.showNow") private var showNow = true
    @AppStorage("home.showToday") private var showToday = true
    @AppStorage("home.showQuick") private var showQuick = true
    @AppStorage("home.showRecents") private var showRecents = true
    @AppStorage("home.columns") private var columnsCount = 2
    @AppStorage("ambient") private var ambient = true
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("animations") private var animations = true
    @AppStorage("web.light") private var webLight = true
    @State private var confirmClearSchedule = false
    @AppStorage("web.savePasswords") private var savePasswords = true
    @AppStorage("web.autoLogin") private var autoLogin = true
    @AppStorage("group") private var group = "151621"
    @AppStorage("notes") private var notes = ""
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("haptics") private var haptics = true
    @AppStorage("lockFiles") private var lockFiles = false
    @State private var memoryCleared = false

    private var version: String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
    }

    private var startBinding: Binding<Date> {
        Binding(get: { schedule.data.semesterStart },
                set: { schedule.data.semesterStart = $0 })
    }

    var body: some View {
        NavigationStack {
            Form {
                Group {
                Section {
                    HStack(spacing: 14) {
                        ZStack {
                            Circle().fill(brandGradient)
                            Image(systemName: "snowflake")
                                .font(.system(size: 26, weight: .semibold))
                                .foregroundStyle(.white)
                        }
                        .frame(width: 60, height: 60)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Студент САФУ")
                                .font(.system(.title3, design: .rounded).weight(.bold))
                            Text(group.isEmpty ? "Группа не указана" : "Группа \(group)")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 6)
                }

                Section("Оформление") {
                    HStack {
                        ForEach(AccentTheme.allCases) { th in
                            Circle()
                                .fill(LinearGradient(colors: [th.color, th.secondary],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 34, height: 34)
                                .overlay(
                                    Circle()
                                        .strokeBorder(Color.primary.opacity(theme == th.rawValue ? 0.8 : 0), lineWidth: 2)
                                        .padding(-5)
                                )
                                .frame(maxWidth: .infinity)
                                .contentShape(Rectangle())
                                .onTapGesture {
                                    Haptics.tap()
                                    theme = th.rawValue
                                }
                        }
                    }
                    .padding(.vertical, 8)
                    Picker("Карточки", selection: $cardStyle) {
                        Text("Стекло").tag(0)
                        Text("Сплошные").tag(1)
                        Text("Цветные").tag(2)
                    }
                    .pickerStyle(.segmented)
                    Toggle("Живой фон", isOn: $ambient)
                    Toggle("Анимации", isOn: $animations)
                    Toggle("Вибрация", isOn: $haptics)
                }

                Section {
                    Toggle("Сейчас / следующая пара", isOn: $showNow)
                    Toggle("Карточка «Сегодня»", isOn: $showToday)
                    Toggle("Быстрые кнопки", isOn: $showQuick)
                    Toggle("Недавние", isOn: $showRecents)
                    Picker("Плиток в ряд", selection: $columnsCount) {
                        Text("2").tag(2)
                        Text("3").tag(3)
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("Главная")
                }

                Section {
                    Toggle("Сайты всегда светлые", isOn: $webLight)
                } header: {
                    Text("Сайты")
                } footer: {
                    Text("Sakai и другие сайты вуза в тёмной теме показывают тёмный текст на тёмном фоне. Эта настройка это исправляет.")
                }

                Section("Учёба") {
                    HStack {
                        Text("Группа")
                        Spacer()
                        TextField("номер", text: $group)
                            .keyboardType(.numberPad)
                            .multilineTextAlignment(.trailing)
                            .foregroundStyle(.secondary)
                    }
                    DatePicker("Начало семестра", selection: startBinding, displayedComponents: .date)
                    if schedule.archivedWeeks > 0 {
                        Button {
                            schedule.clearHistory()
                            Haptics.success()
                        } label: {
                            Label("Очистить архив расписания (\(schedule.archivedWeeks) нед.)", systemImage: "archivebox")
                        }
                    }
                    if schedule.hasLessons {
                        Button(role: .destructive) { confirmClearSchedule = true } label: {
                            Label("Удалить всё расписание", systemImage: "calendar.badge.minus")
                        }
                    }
                }

                Section {
                    InfoRow(icon: "square.grid.2x2", text: "Зажми пустое место на экране «Домой» → «Изменить» → «Добавить виджет» → САФУ. Есть маленький и средний виджеты.")
                    InfoRow(icon: "lock.iphone", text: "На экран блокировки: зажми экран блокировки → «Настроить» → виджеты → САФУ.")
                    InfoRow(icon: "antenna.radiowaves.left.and.right", text: "Виджет сам загружает пары из РУЗ для группы 151621. Другую группу можно указать так: удержать виджет → «Изменить виджет».")
                } header: {
                    Text("Виджет")
                }

                }
                Group {
                Section {
                    Toggle(isOn: $lockFiles) {
                        Label("Файлы по Face ID", systemImage: "faceid")
                    }
                } header: {
                    Text("Безопасность")
                } footer: {
                    Text("Вкладка «Файлы» будет открываться только после Face ID или код-пароля.")
                }

                Section {
                    Toggle(isOn: $savePasswords) { Label("Запоминать пароли", systemImage: "key.fill") }
                    Toggle(isOn: $autoLogin) { Label("Входить автоматически", systemImage: "bolt.fill") }
                        .disabled(!savePasswords)
                    NavigationLink {
                        PasswordsView()
                    } label: {
                        Label("Сохранённые пароли", systemImage: "lock.rectangle.stack")
                    }
                } header: {
                    Text("Пароли и вход")
                } footer: {
                    Text("Вход на сайты сохраняется даже после перезапуска приложения. Пароли лежат в связке ключей iPhone, зашифрованно.")
                }

                Section("Полезно знать") {
                    InfoRow(icon: "calendar", text: "Расписание подтягивается из РУЗ автоматически, вкладка «Пары».")
                    InfoRow(icon: "key.fill", text: "Вход в почту и Sakai: адрес почты САФУ и пароль от учётной записи.")
                    InfoRow(icon: "person.badge.key.fill", text: "Первокурсникам сначала нужно активировать учётную запись.")
                }

                Section("Поддержка") {
                    Link(destination: URL(string: "mailto:sakai@narfu.ru")!) {
                        Label("sakai@narfu.ru: активация, Sakai", systemImage: "envelope")
                    }
                }

                Section("Заметки") {
                    TextEditor(text: $notes)
                        .frame(minHeight: 140)
                }

                Section {
                    Button {
                        store.clearMemory()
                        Haptics.success()
                        withAnimation { memoryCleared = true }
                    } label: {
                        Label(memoryCleared ? "Память очищена" : "Очистить недавние и сохранённые страницы",
                              systemImage: memoryCleared ? "checkmark.circle.fill" : "clock.arrow.circlepath")
                    }
                } header: {
                    Text("Память")
                } footer: {
                    Text("Приложение запоминает недавние сайты, последнюю открытую страницу в каждом и вкладку, на которой ты был.")
                }

                Section {
                    HStack {
                        Text("Версия")
                        Spacer()
                        Text(version).foregroundStyle(.secondary)
                    }
                }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AmbientBackground())
            .navigationTitle("Профиль")
            .confirmationDialog("Удалить все пары?", isPresented: $confirmClearSchedule, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) { schedule.clearAll() }
            }
        }
    }
}

private struct InfoRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(Color.brand)
                .frame(width: 24)
            Text(text)
        }
    }
}


struct PasswordsView: View {
    @State private var list: [SiteCredential] = CredentialStore.all()
    @State private var confirmLogout = false

    var body: some View {
        List {
            Section {
                if list.isEmpty {
                    Text("Пока нет. Войди на сайт внутри приложения, и оно предложит сохранить пароль.")
                        .foregroundStyle(.secondary)
                }
                ForEach(list) { c in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(c.host).font(.headline)
                        Text(c.user.isEmpty ? "—" : c.user)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                .onDelete { idx in
                    for i in idx { CredentialStore.delete(list[i].host) }
                    list = CredentialStore.all()
                }
            } footer: {
                Text("Смахни влево, чтобы удалить. Сами пароли не показываются.")
            }

            Section {
                Button(role: .destructive) { confirmLogout = true } label: {
                    Label("Выйти со всех сайтов и удалить пароли", systemImage: "rectangle.portrait.and.arrow.right")
                }
            }
        }
        .navigationTitle("Пароли")
        .confirmationDialog("Выйти со всех сайтов и удалить сохранённые пароли?",
                            isPresented: $confirmLogout, titleVisibility: .visible) {
            Button("Выйти и удалить", role: .destructive) {
                CredentialStore.deleteAll()
                SessionKeeper.clearAll { list = [] }
                Haptics.success()
            }
        }
    }
}
