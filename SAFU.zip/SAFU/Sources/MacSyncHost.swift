import SwiftUI
import Network
import CryptoKit
import Security
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Mac — это компьютер: синхронизация с iPhone, как у Арктики для Windows
//
// На iPhone Арктика сама ищет компьютер и ходит к нему. Mac — компьютер, поэтому здесь всё наоборот:
// Арктика для Mac ждёт телефон на порту синхронизации (47823, занят — соседние) и показывает QR-код связки.
// Телефон сканирует его («Синхронизация с компьютером» → «Связать по QR-коду») или находит Mac в сети сам
// и связывается по коду из четырёх цифр («Разрешить» на Mac). Дальше телефон сам заходит каждые несколько
// секунд и присылает ДЗ, задачи и заметки, Mac сводит их со своими по полям (побеждает поздняя правка)
// и отдаёт общую версию. Протокол и шифрование — те же, что у Windows (windows/electron/sync.ts,
// syncpair.ts, src/lib/syncmerge.ts): AES-256-GCM ключом связки, к шифру привязан адрес запроса.
//
//   GET  /v2/hello                                         → {app, v, pc, pair, port}
//   POST /v2/pair/start | key | wait                       → связка без QR-кода (X25519 + код + «Разрешить»)
//   POST /v2/sync  {device, data:{homework, tasks, notes}}  → {data, pc, app, hosts, port}

#if targetEnvironment(macCatalyst)

/// Связка этого Mac с телефоном: номер и постоянный ключ (в связке ключей Mac)
struct MacSyncPairing: Codable, Equatable {
    var id: String
    var key: Data
    var created: Date
}

@MainActor
final class MacSyncHost: ObservableObject {
    static let shared = MacSyncHost()

    /// Порты, которые телефон проверяет при поиске компьютера (как у Windows)
    static let ports = [47823, 47824, 47825, 47826, 47827, 47828, 47829, 47830]

    @Published private(set) var pairing: MacSyncPairing?
    @Published private(set) var port = 0
    @Published private(set) var hosts: [String] = []
    @Published private(set) var running = false
    @Published private(set) var problem: String?
    @Published private(set) var lastSync: Date?
    @Published private(set) var lastDevice: String?
    /// Телефон просит связку без QR-кода: показать код и «Разрешить»
    @Published var ask: PairAsk?

    struct PairAsk: Identifiable, Equatable {
        let id = UUID()
        let device: String
        let code: String
    }

    private var listener: NWListener?
    private weak var tasks: TaskStore?
    private var started = false
    private let queue = DispatchQueue(label: "ru.student.safuhub.macsync", qos: .userInitiated)

    private let pairKey = "macsync.pair.v1"
    private let stateKey = "macsync.state.v1"
    private let lastKey = "macsync.last"
    private let deviceKey = "macsync.device"
    private static let route = "/v2/sync"

    private init() {
        if let raw = Keychain.get(pairKey), let p = try? JSONDecoder().decode(MacSyncPairing.self, from: raw) { pairing = p }
        let t = UserDefaults.standard.double(forKey: lastKey)
        lastSync = t > 0 ? Date(timeIntervalSince1970: t) : nil
        lastDevice = UserDefaults.standard.string(forKey: deviceKey)
    }

    /// Имя Mac, как его увидит телефон
    let name: String = {
        var n = ProcessInfo.processInfo.hostName
        if n.hasSuffix(".local") { n = String(n.dropLast(6)) }
        n = n.replacingOccurrences(of: "-", with: " ").trimmingCharacters(in: .whitespaces)
        return n.isEmpty || n == "localhost" ? "Mac" : String(n.prefix(40))
    }()

    var version: String { Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "" }

    // MARK: запуск

    /// Вместе с хранилищами: ждём телефон, пока Арктика на Mac открыта
    func start(tasks: TaskStore) {
        self.tasks = tasks
        guard !started else { return }
        started = true
        if pairing == nil { newPairing() }
        refreshHosts()
        Task { await listen() }
        NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { _ in
            Task { @MainActor in
                MacSyncHost.shared.refreshHosts()
                if !MacSyncHost.shared.running { await MacSyncHost.shared.listen() }
            }
        }
    }

    /// Новый код связки: старый телефон перестанет синхронизироваться, пока его не свяжут заново
    func newPairing() {
        var id = Data(count: 9)
        var key = Data(count: 32)
        _ = id.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 9, $0.baseAddress!) }
        _ = key.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 32, $0.baseAddress!) }
        let p = MacSyncPairing(id: id.base64URL, key: key, created: Date())
        if let raw = try? JSONEncoder().encode(p) { Keychain.set(raw, for: pairKey) }
        pairing = p
        // отметки «что и когда менялось» — от прежней связки, новому телефону они ни к чему
        UserDefaults.standard.removeObject(forKey: stateKey)
        lastSync = nil
        lastDevice = nil
        UserDefaults.standard.removeObject(forKey: lastKey)
        UserDefaults.standard.removeObject(forKey: deviceKey)
    }

    /// Адреса Mac в домашней сети: сначала Wi‑Fi (192.168…), потом остальные
    func refreshHosts() {
        let list = LocalNet.interfaces().map { LocalNet.dotted($0.ip) }
        let ranked = list.sorted { rank($0) < rank($1) }
        var seen = Set<String>()
        let out = Array(ranked.filter { seen.insert($0).inserted }.prefix(5))
        if out != hosts { hosts = out }
    }

    private func rank(_ ip: String) -> Int {
        if ip.hasPrefix("192.168.") { return 0 }
        if ip.hasPrefix("10.") || ip.hasPrefix("172.") { return 1 }
        return 4
    }

    /// Ссылка для QR-кода — та же, что у Windows: arktika://sync?v=1&h=…&p=…&i=…&k=…&n=…
    var link: String? {
        guard let p = pairing, port > 0, !hosts.isEmpty else { return nil }
        var c = URLComponents()
        c.scheme = "arktika"
        c.host = "sync"
        c.queryItems = [
            URLQueryItem(name: "v", value: "1"),
            URLQueryItem(name: "h", value: hosts.joined(separator: ",")),
            URLQueryItem(name: "p", value: String(port)),
            URLQueryItem(name: "i", value: p.id),
            URLQueryItem(name: "k", value: p.key.base64URL),
            URLQueryItem(name: "n", value: name),
        ]
        return c.url?.absoluteString
    }

    // MARK: сервер

    private func listen() async {
        guard listener == nil else { return }
        let order = [UserDefaults.standard.integer(forKey: "macsync.port")].filter { $0 > 0 } + Self.ports
        var seen = Set<Int>()
        for p in order where seen.insert(p).inserted {
            if let l = await tryListen(p) {
                listener = l
                port = p
                running = true
                problem = nil
                UserDefaults.standard.set(p, forKey: "macsync.port")
                SmokeTour.log("sync listening on \(p)")
                return
            }
        }
        problem = "Все порты синхронизации (47823–47830) заняты другими программами"
    }

    private func tryListen(_ p: Int) async -> NWListener? {
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(p)) else { return nil }
        let params = NWParameters.tcp
        params.allowLocalEndpointReuse = true
        params.includePeerToPeer = false
        guard let l = try? NWListener(using: params, on: nwPort) else { return nil }
        let q = queue
        l.newConnectionHandler = { conn in
            HTTPConnection(conn, queue: q).start()
        }
        return await withCheckedContinuation { (cont: CheckedContinuation<NWListener?, Never>) in
            var done = false
            let finish: (NWListener?) -> Void = { r in
                guard !done else { return }
                done = true
                cont.resume(returning: r)
            }
            l.stateUpdateHandler = { [weak l] st in
                switch st {
                case .ready:
                    q.async { finish(l) }
                case .failed, .cancelled:
                    l?.cancel()
                    q.async { finish(nil) }
                default:
                    break
                }
            }
            l.start(queue: q)
            q.asyncAfter(deadline: .now() + 3) { finish(nil) }
        }
    }

    // MARK: запросы

    struct Reply {
        var status = 200
        var type = "application/json; charset=utf-8"
        var body = Data()

        static func json(_ v: Any, status: Int = 200) -> Reply {
            Reply(status: status, body: (try? JSONSerialization.data(withJSONObject: v)) ?? Data("{}".utf8))
        }

        static func text(_ s: String, status: Int) -> Reply {
            Reply(status: status, type: "text/plain; charset=utf-8", body: Data(s.utf8))
        }
    }

    func handle(method: String, path: String, headers: [String: String], body: Data) async -> Reply {
        let route = path.split(separator: "?", maxSplits: 1).first.map(String.init) ?? path
        if method == "GET" && route == "/v2/hello" {
            var j: [String: Any] = ["app": "arktika", "v": 2, "pc": name, "port": port]
            if let p = pairing { j["pair"] = Self.pairTag(p.id) } else { j["pair"] = NSNull() }
            return .json(j)
        }
        if method == "POST" && route.hasPrefix("/v2/pair/") {
            return await pairStep(String(route.dropFirst(9)), body)
        }
        guard method == "POST", route == Self.route else { return .text("unknown", status: 404) }
        guard let p = pairing, headers["x-arktika-pair"] == p.id else { return .text("pair", status: 403) }
        let key = SymmetricKey(data: p.key)
        guard let plain = try? PCCrypto.open(body, key: key, aad: "POST \(Self.route)"),
              let j = (try? JSONSerialization.jsonObject(with: plain)) as? [String: Any] else {
            return .text("bad seal", status: 400)
        }
        let device = ((j["device"] as? String) ?? "iPhone").trimmingCharacters(in: .whitespacesAndNewlines)
        var answer: [String: Any] = ["data": merge(j["data"] as? [String: Any] ?? [:])]
        answer["pc"] = name
        answer["app"] = version
        answer["hosts"] = hosts
        answer["port"] = port
        guard let raw = try? JSONSerialization.data(withJSONObject: answer),
              let sealed = try? PCCrypto.seal(raw, key: key, aad: "R POST \(Self.route)") else {
            return .text("seal", status: 500)
        }
        let now = Date()
        lastSync = now
        lastDevice = String(device.prefix(60))
        UserDefaults.standard.set(now.timeIntervalSince1970, forKey: lastKey)
        UserDefaults.standard.set(lastDevice, forKey: deviceKey)
        return Reply(status: 200, type: "application/octet-stream", body: sealed)
    }

    // MARK: сведение (как windows/src/lib/syncmerge.ts)

    private func loadState() -> [String: SyncCollState] {
        guard let raw = UserDefaults.standard.data(forKey: stateKey),
              let s = try? JSONDecoder().decode([String: SyncCollState].self, from: raw) else { return [:] }
        return s
    }

    private func saveState(_ s: [String: SyncCollState]) {
        if let raw = try? JSONEncoder().encode(s) { UserDefaults.standard.set(raw, forKey: stateKey) }
    }

    /// Свести присланное с тем, что на Mac, положить общее в хранилища и вернуть его телефону
    private func merge(_ remote: [String: Any]) -> [String: Any] {
        let now = Date().timeIntervalSince1970 * 1000
        var state = loadState()
        var out: [String: Any] = [:]
        let homework = HomeworkStore.shared.items
        var local: [String: [[String: Any]]] = [
            "homework": SyncCodec.dicts(homework),
            "notes": SyncCodec.dicts(NotesStore.shared.notes),
        ]
        if let t = tasks?.tasks { local["tasks"] = SyncCodec.dicts(t) }

        for (coll, items) in local {
            let st = SyncStamps.refresh(coll, items, state[coll] ?? SyncCollState(), now: now)
            guard let r = remote[coll] as? [String: Any] else {
                // телефон эту коллекцию не прислал — отдаём свою как есть
                state[coll] = st
                out[coll] = ["items": strip(coll, items), "m": SyncStamps.wire(st), "tomb": st.tomb]
                continue
            }
            let merged = Self.mergeColl(coll, items: items, st: st,
                                        remote: (r["items"] as? [[String: Any]]) ?? [],
                                        rm: SyncStamps.readM(r["m"]), rtomb: SyncStamps.readTomb(r["tomb"]))
            // то, что ляжет в хранилище, — в виде для сети: по нему отметки после сведения
            let final: [[String: Any]]
            switch coll {
            case "homework":
                let mine = Dictionary(homework.map { ($0.id.uuidString.lowercased(), $0) }, uniquingKeysWith: { a, _ in a })
                let list: [Homework] = merged.items.compactMap { d in
                    var d = d
                    // фото — свои: у записи с телефона их здесь нет
                    d["photos"] = mine[SyncStamps.idOf(d)]?.photos ?? []
                    return SyncCodec.decode(d, as: Homework.self)
                }
                if list != homework { HomeworkStore.shared.applySync(list) }
                final = SyncCodec.dicts(list)
            case "tasks":
                let defaults: [String: Any] = ["title": "", "subject": "", "note": "", "done": false, "remind": true, "due": now]
                let list = merged.items.compactMap { SyncCodec.decode($0, as: StudyTask.self, defaults: defaults) }
                if let t = tasks, list != t.tasks { t.applySync(list) }
                final = SyncCodec.dicts(list)
            case "notes":
                let defaults: [String: Any] = ["title": "", "text": "", "items": [Any](), "subject": "", "color": 0, "pinned": false,
                                               "created": now, "updated": now]
                let list = merged.items.compactMap { SyncCodec.decode($0, as: Note.self, defaults: defaults) }
                if list != NotesStore.shared.notes { NotesStore.shared.applySync(list) }
                final = SyncCodec.dicts(list)
            default:
                continue
            }
            state[coll] = SyncStamps.restamp(coll, final, m: merged.m, tomb: merged.tomb)
            out[coll] = ["items": strip(coll, final), "m": merged.m, "tomb": merged.tomb]
        }
        saveState(state)
        return out
    }

    /// Фото ДЗ — файлы этого Mac, телефону они не нужны (он оставляет свои)
    private func strip(_ coll: String, _ items: [[String: Any]]) -> [[String: Any]] {
        guard let fields = SyncStamps.localOnly[coll] else { return items }
        return items.map { d in
            var d = d
            for f in fields where d[f] != nil { d[f] = [Any]() }
            return d
        }
    }

    struct Merged {
        var items: [[String: Any]]
        var m: [String: [String: Double]]
        var tomb: [String: Double]
    }

    /// Свести свою коллекцию (отметки уже обновлены) с пришедшей. Порядок — свой, новые с телефона — в конце
    static func mergeColl(_ coll: String, items local: [[String: Any]], st: SyncCollState,
                          remote: [[String: Any]], rm: [String: [String: Double]], rtomb: [String: Double]) -> Merged {
        var L: [String: [String: Any]] = [:]
        var lorder: [String] = []
        for x in local {
            let id = SyncStamps.idOf(x)
            if L[id] == nil { lorder.append(id) }
            L[id] = x
        }
        var R: [String: [String: Any]] = [:]
        var rorder: [String] = []
        for x in remote {
            let id = SyncStamps.idOf(x)
            if R[id] == nil { rorder.append(id) }
            R[id] = x
        }
        let ltomb = st.tomb
        var tomb = ltomb
        for (id, t) in rtomb { tomb[id] = max(tomb[id] ?? 0, t) }
        func lm(_ id: String) -> [String: Double] { (st.stamps[id] ?? [:]).mapValues(\.m) }
        func maxOf(_ r: [String: Double]) -> Double { max(0, r.values.max() ?? 0) }
        let localOnly = SyncStamps.localOnly[coll] ?? []

        var items: [[String: Any]] = []
        var m: [String: [String: Double]] = [:]
        for id in lorder + rorder.filter({ L[$0] == nil }) where !id.isEmpty {
            let l = L[id]
            let r = R[id]
            let lt = lm(id)
            let rt = rm[id] ?? [:]
            if let l, r == nil {
                // на телефоне удалили — и здесь после этого не трогали
                if let t = rtomb[id], t >= maxOf(lt) { continue }
                items.append(l)
                m[id] = lt
                tomb[id] = nil
            } else if let r, l == nil {
                if let t = ltomb[id], t >= maxOf(rt) { continue }
                var it = r
                for f in localOnly where it[f] != nil { it[f] = [Any]() }
                items.append(it)
                m[id] = rt
                tomb[id] = nil
            } else if let l, let r {
                var it = l
                var mm: [String: Double] = [:]
                for f in Set(l.keys).union(r.keys) where SyncStamps.synced(coll, f) {
                    let a = lt[f] ?? 0
                    let b = rt[f] ?? 0
                    var useRemote = b > a
                    if a == b {
                        // ничья (первая встреча): «сделано» важнее «не сделано», недостающее поле берём оттуда
                        if f == "done" { useRemote = (r["done"] as? Bool ?? false) && !(l["done"] as? Bool ?? false) }
                        else if f == "doneAt" { useRemote = !(r["doneAt"] is NSNull || r["doneAt"] == nil) && (l["doneAt"] is NSNull || l["doneAt"] == nil) }
                        else { useRemote = l[f] == nil }
                    }
                    if useRemote, let v = r[f] { it[f] = v }
                    mm[f] = max(a, b)
                }
                items.append(it)
                m[id] = mm
                tomb[id] = nil
            }
        }
        return Merged(items: items, m: m, tomb: tomb)
    }

    // MARK: связка без QR-кода (как windows/electron/syncpair.ts)

    private final class PairSession {
        let sid: String
        let device: String
        let priv = Curve25519.KeyAgreement.PrivateKey()
        var pub: Data { priv.publicKey.rawRepresentation }
        let created = Date()
        var status = "start"
        var box: Data?
        init(sid: String, device: String) {
            self.sid = sid
            self.device = device
        }
    }

    private var session: PairSession?
    private static let pairTTL: TimeInterval = 180

    static func pairTag(_ id: String) -> String {
        String(SHA256.hash(data: Data(id.utf8)).map { String(format: "%02x", $0) }.joined().prefix(12))
    }

    private func live(_ sid: Any?) -> PairSession? {
        guard let s = session, let sid = sid as? String, s.sid == sid, Date().timeIntervalSince(s.created) < Self.pairTTL else { return nil }
        return s
    }

    private func pairStep(_ step: String, _ body: Data) async -> Reply {
        guard body.count <= 4096 else { return .text("too big", status: 413) }
        let j = (try? JSONSerialization.jsonObject(with: body.isEmpty ? Data("{}".utf8) : body)) as? [String: Any] ?? [:]
        switch step {
        case "start":
            // уже ждём ответа на другой запрос — не засыпаем человека окнами
            if let cur = session, cur.status == "wait", Date().timeIntervalSince(cur.created) < Self.pairTTL {
                return .json(["error": "busy"], status: 409)
            }
            var raw = Data(count: 12)
            _ = raw.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 12, $0.baseAddress!) }
            let device = ((j["device"] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let s = PairSession(sid: raw.base64URL, device: device.isEmpty ? "iPhone" : String(device.prefix(60)))
            session = s
            return .json(["sid": s.sid, "commit": Data(SHA256.hash(data: s.pub)).base64EncodedString()])

        case "key":
            guard let s = live(j["sid"]) else { return .json(["error": "gone"], status: 410) }
            guard s.status == "start" else { return .json(["error": "state"], status: 409) }
            guard let b64 = j["pub"] as? String, let phonePub = Data(base64Encoded: b64), phonePub.count == 32,
                  let phoneKey = try? Curve25519.KeyAgreement.PublicKey(rawRepresentation: phonePub),
                  let shared = try? s.priv.sharedSecretFromKeyAgreement(with: phoneKey) else {
                return .json(["error": "pub"], status: 400)
            }
            let pcPub = s.pub
            let key = shared.hkdfDerivedSymmetricKey(using: SHA256.self, salt: Data("arktika-pair-v1".utf8),
                                                     sharedInfo: phonePub + pcPub, outputByteCount: 32)
            let code = PCPairing.code(phonePub, pcPub)
            s.status = "wait"
            pending = (s.sid, key)
            ask = PairAsk(device: s.device, code: code)
            // проверка сборки в GitHub: «Разрешить» нажимать некому — связываем сами, чтобы проверить весь обмен
            if SmokeTour.enabled {
                SmokeTour.log("pair ask \(s.device) code \(code) — auto allow")
                decide(true)
            }
            return .json(["pub": pcPub.base64EncodedString(), "code": code])

        case "wait":
            guard let s = live(j["sid"]) else { return .json(["error": "gone"], status: 410) }
            if s.status == "start" { return .json(["error": "state"], status: 409) }
            // держим запрос, пока человек думает (не дольше 25 секунд — телефон спросит снова)
            let until = Date().addingTimeInterval(25)
            while s.status == "wait" && Date() < until {
                try? await Task.sleep(nanoseconds: 300_000_000)
            }
            if s.status == "ok", let box = s.box {
                if session === s { session = nil } // ключ отдаётся один раз
                return .json(["status": "ok", "box": box.base64EncodedString()])
            }
            if s.status == "denied" {
                if session === s { session = nil }
                return .json(["status": "denied"])
            }
            return .json(["status": "wait"])

        default:
            return .text("unknown", status: 404)
        }
    }

    /// Ключ, которым зашифруем связку для телефона, когда человек нажмёт «Разрешить»
    private var pending: (sid: String, key: SymmetricKey)?

    /// Ответ человека на запрос связки
    func decide(_ allow: Bool) {
        ask = nil
        guard let s = session, let pend = pending, pend.sid == s.sid, s.status == "wait" else { return }
        pending = nil
        guard allow else {
            s.status = "denied"
            return
        }
        if pairing == nil { newPairing() }
        guard let p = pairing else { s.status = "denied"; return }
        refreshHosts()
        let grant: [String: Any] = ["id": p.id, "key": p.key.base64URL, "hosts": hosts, "port": port, "name": name]
        guard let raw = try? JSONSerialization.data(withJSONObject: grant),
              let box = try? PCCrypto.seal(raw, key: pend.key, aad: "arktika pair") else {
            s.status = "denied"
            return
        }
        s.box = box
        s.status = "ok"
    }
}

// MARK: - HTTP поверх TCP (запросы телефона небольшие: заголовки + тело по Content-Length)

private final class HTTPConnection {
    private let conn: NWConnection
    private let queue: DispatchQueue
    private var buffer = Data()
    private var keepSelf: HTTPConnection?
    private static let limit = 24 * 1024 * 1024

    init(_ conn: NWConnection, queue: DispatchQueue) {
        self.conn = conn
        self.queue = queue
    }

    func start() {
        keepSelf = self
        conn.stateUpdateHandler = { [weak self] st in
            switch st {
            case .failed, .cancelled: self?.keepSelf = nil
            default: break
            }
        }
        conn.start(queue: queue)
        receive()
        // телефон не дослал запрос за 60 секунд — закрываем
        queue.asyncAfter(deadline: .now() + 60) { [weak self] in self?.conn.cancel() }
    }

    private func receive() {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 1 << 16) { [weak self] data, _, complete, error in
            guard let self else { return }
            if let data, !data.isEmpty { self.buffer.append(data) }
            if self.buffer.count > Self.limit { self.conn.cancel(); return }
            if self.tryHandle() { return }
            if complete || error != nil { self.conn.cancel(); return }
            self.receive()
        }
    }

    /// Весь запрос пришёл — отвечаем. false — ждём ещё
    private func tryHandle() -> Bool {
        guard let end = buffer.range(of: Data("\r\n\r\n".utf8)) else { return false }
        let head = String(decoding: buffer[buffer.startIndex..<end.lowerBound], as: UTF8.self)
        var lines = head.components(separatedBy: "\r\n")
        guard !lines.isEmpty else { conn.cancel(); return true }
        let first = lines.removeFirst().split(separator: " ")
        guard first.count >= 2 else { conn.cancel(); return true }
        var headers: [String: String] = [:]
        for l in lines {
            guard let c = l.firstIndex(of: ":") else { continue }
            headers[l[..<c].trimmingCharacters(in: .whitespaces).lowercased()] = l[l.index(after: c)...].trimmingCharacters(in: .whitespaces)
        }
        let length = Int(headers["content-length"] ?? "0") ?? 0
        guard length >= 0, length <= Self.limit else { conn.cancel(); return true }
        let bodyStart = end.upperBound
        guard buffer.count - (bodyStart - buffer.startIndex) >= length else { return false }
        let body = Data(buffer[bodyStart..<(bodyStart + length)])
        let method = String(first[0])
        let path = String(first[1])
        Task { @MainActor in
            let r = await MacSyncHost.shared.handle(method: method, path: path, headers: headers, body: body)
            self.queue.async { self.send(r) }
        }
        return true
    }

    private func send(_ r: MacSyncHost.Reply) {
        let reason: String
        switch r.status {
        case 200: reason = "OK"
        case 400: reason = "Bad Request"
        case 403: reason = "Forbidden"
        case 404: reason = "Not Found"
        case 409: reason = "Conflict"
        case 410: reason = "Gone"
        case 413: reason = "Payload Too Large"
        default: reason = "Error"
        }
        var head = "HTTP/1.1 \(r.status) \(reason)\r\n"
        head += "Content-Type: \(r.type)\r\n"
        head += "Content-Length: \(r.body.count)\r\n"
        head += "Cache-Control: no-store\r\n"
        head += "Connection: close\r\n\r\n"
        conn.send(content: Data(head.utf8) + r.body, completion: .contentProcessed { [weak self] _ in
            self?.conn.cancel()
        })
    }
}

extension Data {
    /// base64url без «=» в конце (так ключ записан в QR)
    var base64URL: String {
        base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
}

// MARK: - Экран: Профиль → «Синхронизация с iPhone» (на Mac)

struct MacSyncView: View {
    @ObservedObject private var host = MacSyncHost.shared
    @State private var confirmNew = false

    var body: some View {
        List {
            Section {
                HStack(alignment: .top, spacing: 24) {
                    qr
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Наведи камеру iPhone на код")
                            .font(.title3.weight(.semibold))
                        step(1, "На iPhone открой Арктику → Профиль → «Синхронизация с компьютером»")
                        step(2, "Нажми «Связать по QR-коду» и наведи камеру на этот код")
                        step(3, "Готово: ДЗ, задачи и заметки станут общими. Телефон сам заходит, пока Арктика открыта на обоих")
                        Text("Можно и без кода: на iPhone в «Компьютерах рядом» выбери этот Mac и нажми здесь «Разрешить».")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 8)
            }

            Section {
                LabeledContent("Состояние") { Text(status).foregroundStyle(host.running ? Color.primary : Color.orange) }
                LabeledContent("Этот Mac") { Text(host.name) }
                if !host.hosts.isEmpty {
                    LabeledContent("Адрес в сети") { Text(host.hosts.joined(separator: ", ") + (host.port > 0 ? " · порт \(host.port)" : "")) }
                }
                if let problem = host.problem {
                    Label(problem, systemImage: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                }
            } header: {
                Text("Синхронизация")
            }

            Section {
                Button("Новый код связки") { confirmNew = true }
                    .buttonStyle(.bordered)
            } footer: {
                Text("Связанный по старому коду iPhone перестанет синхронизироваться, пока его не свяжут заново.")
            }
        }
        .navigationTitle("Синхронизация с iPhone")
        .onAppear { host.refreshHosts() }
        .confirmationDialog("Сделать новый код связки?", isPresented: $confirmNew, titleVisibility: .visible) {
            Button("Новый код", role: .destructive) { host.newPairing() }
        }
    }

    private var status: String {
        guard host.running else { return host.problem == nil ? "запускаю…" : "не работает" }
        guard let last = host.lastSync else { return "жду iPhone" }
        let device = host.lastDevice.map { "«\($0)»" } ?? "iPhone"
        return "\(device) · \(PCSync.ago(last))"
    }

    @ViewBuilder private var qr: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.white)
            if let link = host.link, let img = QRImage.make(link) {
                Image(uiImage: img)
                    .interpolation(.none)
                    .resizable()
                    .scaledToFit()
                    .padding(14)
            } else {
                VStack(spacing: 8) {
                    ProgressView()
                    Text(host.hosts.isEmpty ? "Нет Wi‑Fi" : "Готовлю код…")
                        .font(.caption)
                        .foregroundStyle(.black.opacity(0.6))
                }
            }
        }
        .frame(width: 240, height: 240)
        .accessibilityLabel("QR-код связки с iPhone")
    }

    private func step(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text("\(n)")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white)
                .frame(width: 20, height: 20)
                .background(Circle().fill(Color.brand))
            Text(text)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

enum QRImage {
    static func make(_ s: String) -> UIImage? {
        let f = CIFilter.qrCodeGenerator()
        f.message = Data(s.utf8)
        f.correctionLevel = "M"
        guard let out = f.outputImage?.transformed(by: CGAffineTransform(scaleX: 10, y: 10)),
              let cg = CIContext().createCGImage(out, from: out.extent) else { return nil }
        return UIImage(cgImage: cg)
    }
}

/// Запрос связки без QR-кода: окно с кодом и «Разрешить» — где бы ни был человек в приложении
struct MacSyncAskModifier: ViewModifier {
    @ObservedObject private var host = MacSyncHost.shared

    func body(content: Content) -> some View {
        content.alert(item: Binding(get: { host.ask }, set: { if $0 == nil, host.ask != nil { host.decide(false) } })) { a in
            Alert(title: Text("Связать «\(a.device)» с этим Mac?"),
                  message: Text("Проверь, что на iPhone тот же код: \(a.code)\n\nДЗ, задачи и заметки станут общими."),
                  primaryButton: .default(Text("Разрешить")) { host.decide(true) },
                  secondaryButton: .cancel(Text("Отклонить")) { host.decide(false) })
        }
    }
}

/// Пометка на главной Mac: iPhone на связи / был недавно / не связан
struct MacSyncChip: View {
    @ObservedObject private var host = MacSyncHost.shared
    var open: () -> Void

    var body: some View {
        TimelineView(.periodic(from: .now, by: 10)) { ctx in
            let st = state(ctx.date)
            Button(action: open) {
                HStack(spacing: 7) {
                    Circle().fill(st.1).frame(width: 7, height: 7)
                    Image(systemName: "iphone")
                        .font(.caption.weight(.semibold))
                    Text(st.0)
                        .font(.caption.weight(.semibold))
                        .lineLimit(1)
                }
                .foregroundStyle(st.2 ? Color.primary : Color.secondary)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
            }
            .buttonStyle(.plain)
            .accessibilityHint("Синхронизация с iPhone")
        }
    }

    private func state(_ now: Date) -> (String, Color, Bool) {
        guard let last = host.lastSync else { return ("iPhone не связан", Color.secondary.opacity(0.6), false) }
        let device = host.lastDevice ?? "iPhone"
        if now.timeIntervalSince(last) < 30 { return ("\(device) · на связи", .green, true) }
        return ("\(device) · \(PCSync.ago(last, now: now))", .orange, false)
    }
}

#endif
