import SwiftUI
import WebKit
import Security

// MARK: - Modeus — основной источник расписания САФУ
// РУЗ сам отправляет студентов в Modeus (narfu.modeus.org), и полное расписание теперь там.
// Вход — на официальной странице САФУ внутри приложения: пароль вводится на сайте университета,
// приложение его не видит и не хранит. Сохраняется только ключ доступа Modeus (id_token) —
// в связке ключей этого iPhone, без синхронизации и без резервных копий.
// API то же, что у открытых проектов modeus-sync и YetAnotherCalendar:
//   POST /schedule-calendar-v2/api/calendar/events/search   — пары человека
//   POST /schedule-calendar-v2/api/people/persons/search    — поиск человека по ФИО

enum ModeusError: LocalizedError {
    case notConnected, expired, http(Int), parse

    var errorDescription: String? {
        switch self {
        case .notConnected: return "Modeus не подключён"
        case .expired: return "Вход в Modeus устарел — войди ещё раз"
        case .http(let c): return "Modeus ответил ошибкой \(c)"
        case .parse: return "Modeus прислал непонятный ответ"
        }
    }
}

enum Modeus {
    static let base = "https://narfu.modeus.org"
    static let host = "narfu.modeus.org"
    static let timeZone = TimeZone(identifier: "Europe/Moscow") ?? .current

    // MARK: ключ доступа (только на этом телефоне)

    private static let service = "ru.student.safuhub.modeus"

    static var token: String? {
        get {
            let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: "id_token",
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
            var out: AnyObject?
            guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
                  let d = out as? Data else { return nil }
            return String(data: d, encoding: .utf8)
        }
        set {
            let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: "id_token"]
            SecItemDelete(q as CFDictionary)
            guard let newValue else { return }
            var add = q
            add[kSecValueData as String] = Data(newValue.utf8)
            add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            SecItemAdd(add as CFDictionary, nil)
        }
    }

    /// Подключён ли Modeus (ключ может быть устаревшим — тогда обновим его тихо)
    static var isConnected: Bool { UserDefaults.standard.bool(forKey: "modeus.on") && token != nil }

    static func save(token t: String) {
        token = t
        UserDefaults.standard.set(true, forKey: "modeus.on")
        if let name = claims(t)?["name"] as? String ?? claims(t)?["given_name"] as? String {
            UserDefaults.standard.set(name, forKey: "modeus.name")
        }
    }

    static func disconnect() {
        token = nil
        UserDefaults.standard.set(false, forKey: "modeus.on")
        UserDefaults.standard.removeObject(forKey: "modeus.name")
    }

    static func claims(_ jwt: String) -> [String: Any]? {
        let parts = jwt.split(separator: ".")
        guard parts.count >= 2 else { return nil }
        var s = String(parts[1]).replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while s.count % 4 != 0 { s += "=" }
        guard let d = Data(base64Encoded: s) else { return nil }
        return (try? JSONSerialization.jsonObject(with: d)) as? [String: Any]
    }

    /// Ключ, который ещё действует (с запасом в минуту)
    static var validToken: String? {
        guard let t = token, let c = claims(t) else { return nil }
        if let exp = c["exp"] as? Double, Date(timeIntervalSince1970: exp) < Date().addingTimeInterval(60) { return nil }
        return t
    }

    static var personID: String? {
        guard let t = token, let c = claims(t) else { return nil }
        return c["person_id"] as? String
    }

    /// Похоже ли на ключ Modeus
    static func isModeusToken(_ t: String) -> Bool { claims(t)?["person_id"] != nil }

    // MARK: вход

    /// Адрес входа: из публичной настройки сайта Modeus (clientId и страница входа), иначе — главная Modeus
    static func authorizeURL() async -> URL {
        let fallback = URL(string: base + "/")!
        guard let cfgURL = URL(string: base + "/schedule-calendar/assets/app.config.json"),
              let loaded = try? await URLSession.shared.data(from: cfgURL),
              let json = try? JSONSerialization.jsonObject(with: loaded.0) as? [String: Any],
              let wso = json["wso"] as? [String: Any],
              let clientID = wso["clientId"] as? String else { return fallback }
        let login = (wso["loginUrl"] as? String) ?? "https://narfu-auth.modeus.org/oauth2/authorize"
        var c = URLComponents(string: login)
        let nonce = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        c?.queryItems = [
            URLQueryItem(name: "client_id", value: clientID),
            URLQueryItem(name: "redirect_uri", value: base + "/"),
            URLQueryItem(name: "response_type", value: "id_token"),
            URLQueryItem(name: "scope", value: "openid"),
            URLQueryItem(name: "nonce", value: nonce),
            URLQueryItem(name: "state", value: nonce),
        ]
        return c?.url ?? fallback
    }

    /// id_token из адреса после входа (…#id_token=…)
    static func token(in url: URL) -> String? {
        let s = url.absoluteString
        guard let r = s.range(of: "id_token=") else { return nil }
        let tail = s[r.upperBound...]
        let t = tail.prefix { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" || $0 == "." }
        return t.isEmpty ? nil : String(t)
    }

    /// Действующий ключ: сохранённый или тихо обновлённый (вход в САФУ запомнен в браузере приложения)
    @MainActor
    static func freshToken() async throws -> String {
        guard isConnected else { throw ModeusError.notConnected }
        if let t = validToken { return t }
        if let t = await ModeusSilentLogin.run(), isModeusToken(t) {
            save(token: t)
            return t
        }
        throw ModeusError.expired
    }

    // MARK: API

    private static func post(_ path: String, body: [String: Any], token: String) async throws -> [String: Any] {
        guard let url = URL(string: base + path) else { throw ModeusError.parse }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, resp) = try await URLSession.shared.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        if code == 401 || code == 403 { throw ModeusError.expired }
        guard (200..<300).contains(code) else { throw ModeusError.http(code) }
        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw ModeusError.parse }
        return json
    }

    private static let iso: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        f.timeZone = timeZone
        return f
    }()

    /// Пары людей (по умолчанию — свои) с from по to
    @MainActor
    static func events(persons: [String]? = nil, from: Date, to: Date) async throws -> [RuzEvent] {
        var tok = try await freshToken()
        guard let ids = persons ?? personID.map({ [$0] }), !ids.isEmpty else { throw ModeusError.parse }
        var all: [RuzEvent] = []
        var cur = from
        while cur < to {
            let end = min(cur.addingTimeInterval(30 * 86_400), to)
            let body: [String: Any] = ["size": 500, "timeMin": iso.string(from: cur), "timeMax": iso.string(from: end),
                                       "attendeePersonId": ids]
            let path = "/schedule-calendar-v2/api/calendar/events/search?tz=Europe/Moscow"
            let json: [String: Any]
            do {
                json = try await post(path, body: body, token: tok)
            } catch ModeusError.expired {
                // ключ истёк прямо сейчас — один раз обновляем и повторяем
                if let t = await ModeusSilentLogin.run(), isModeusToken(t) { save(token: t); tok = t } else { throw ModeusError.expired }
                json = try await post(path, body: body, token: tok)
            }
            all += parseEvents(json)
            cur = end
        }
        var seen = Set<String>()
        return all.filter { seen.insert($0.id).inserted }.sorted { $0.start < $1.start }
    }

    /// Поиск людей по ФИО: [(id, ФИО)]
    @MainActor
    static func persons(named name: String) async throws -> [(id: String, name: String)] {
        let tok = try await freshToken()
        let json = try await post("/schedule-calendar-v2/api/people/persons/search",
                                  body: ["fullName": name, "sort": "+fullName", "size": 20, "page": 0], token: tok)
        let list = ((json["_embedded"] as? [String: Any])?["persons"] as? [[String: Any]]) ?? []
        return list.compactMap { p in
            guard let id = p["id"] as? String, let n = p["fullName"] as? String else { return nil }
            return (id, n)
        }
    }

    // MARK: разбор ответа (HAL: _embedded + ссылки _links)

    private static func linkID(_ any: Any?) -> String? {
        let obj: [String: Any]?
        if let arr = any as? [[String: Any]] { obj = arr.first } else { obj = any as? [String: Any] }
        guard let href = obj?["href"] as? String else { return nil }
        return href.split(separator: "/").last.map(String.init)
    }

    private static let kinds: [String: String] = [
        "LECT": "Лекция", "SEMI": "Практика", "LAB": "Лабораторная работа", "CONS": "Консультация",
        "SELF": "Самостоятельная работа", "EXAMINATION": "Экзамен", "MIDTERM": "Зачёт",
        "CUR_CHECK": "Контрольная", "PRETEST": "Зачёт",
    ]

    private static func date(_ any: Any?) -> Date? {
        guard let s = any as? String else { return nil }
        if let d = iso.date(from: s) { return d }
        let frac = ISO8601DateFormatter()
        frac.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = frac.date(from: s) { return d }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = timeZone
        for p in ["yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd'T'HH:mm"] {
            f.dateFormat = p
            if let d = f.date(from: s) { return d }
        }
        return nil
    }

    static func parseEvents(_ json: [String: Any]) -> [RuzEvent] {
        guard let emb = json["_embedded"] as? [String: Any] else { return [] }
        func byID(_ key: String) -> [String: [String: Any]] {
            var m: [String: [String: Any]] = [:]
            for x in (emb[key] as? [[String: Any]]) ?? [] { if let id = x["id"] as? String { m[id] = x } }
            return m
        }
        let courses = byID("course-unit-realizations")
        let persons = byID("persons")
        let rooms = byID("rooms")
        var locations: [String: String] = [:]
        for l in (emb["event-locations"] as? [[String: Any]]) ?? [] {
            if let id = l["eventId"] as? String, let c = l["customLocation"] as? String { locations[id] = c }
        }
        var evRooms: [String: [[String: Any]]] = [:]
        for er in (emb["event-rooms"] as? [[String: Any]]) ?? [] {
            let links = er["_links"] as? [String: Any]
            if let ev = linkID(links?["event"]), let room = linkID(links?["room"]).flatMap({ rooms[$0] }) {
                evRooms[ev, default: []].append(room)
            }
        }
        var teachers: [String: [String]] = [:]
        for a in (emb["event-attendees"] as? [[String: Any]]) ?? [] {
            let role = (a["roleId"] as? String) ?? "TEACH"
            guard role == "TEACH" else { continue }
            let links = a["_links"] as? [String: Any]
            if let ev = linkID(links?["event"]), let p = linkID(links?["person"]).flatMap({ persons[$0] }),
               let n = p["fullName"] as? String, !n.lowercased().hasPrefix("support") {
                teachers[ev, default: []].append(n)
            }
        }

        var out: [RuzEvent] = []
        for ev in (emb["events"] as? [[String: Any]]) ?? [] {
            guard let id = ev["id"] as? String,
                  let start = date(ev["start"]) ?? date(ev["startsAt"]),
                  let end = date(ev["end"]) ?? date(ev["endsAt"]) else { continue }
            let links = ev["_links"] as? [String: Any]
            let course = linkID(links?["course-unit-realization"]).flatMap { courses[$0] }
            let subject = (course?["name"] as? String) ?? (ev["name"] as? String) ?? "Занятие"
            let typeID = ev["typeId"] as? String ?? ""
            var room = ""
            var address = ""
            if let r = evRooms[id]?.first {
                room = ((r["name"] as? String) ?? "")
                    .replacingOccurrences(of: "ауд.", with: "", options: .caseInsensitive)
                    .trimmingCharacters(in: .whitespaces)
                let b = r["building"] as? [String: Any]
                address = (b?["address"] as? String) ?? (b?["name"] as? String) ?? ""
            }
            if address.isEmpty, let custom = locations[id], custom != "LXP" { address = custom }
            let topic = (ev["name"] as? String) ?? ""
            out.append(RuzEvent(start: start, end: end, subject: subject,
                                kind: kinds[typeID] ?? typeID,
                                teacher: Array(Set(teachers[id] ?? [])).sorted().joined(separator: ", "),
                                room: room, address: address,
                                note: topic == subject ? "" : topic))
        }
        return out
    }
}

// MARK: - Окно входа в Modeus

struct ModeusLoginView: View {
    let onDone: (Bool) -> Void
    @State private var url: URL?
    @State private var loading = true

    var body: some View {
        NavigationStack {
            ZStack {
                if let url {
                    ModeusWeb(url: url, loading: $loading) { token in
                        Modeus.save(token: token)
                        Haptics.success()
                        onDone(true)
                    }
                }
                if loading {
                    ProgressView().controlSize(.large)
                }
            }
            .safeAreaInset(edge: .top) {
                Label("Войди своей учётной записью САФУ. Пароль вводится на сайте университета — приложение его не видит.",
                      systemImage: "lock.shield.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.bar)
            }
            .navigationTitle("Вход в Modeus")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { onDone(false) } }
            }
        }
        .task { url = await Modeus.authorizeURL() }
    }
}

/// Браузер входа: ловит адрес с #id_token, а если сайт спрятал ключ — берёт его из хранилища страницы
private struct ModeusWeb: UIViewRepresentable {
    let url: URL
    @Binding var loading: Bool
    let onToken: (String) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> WKWebView {
        let w = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
        w.navigationDelegate = context.coordinator
        w.load(URLRequest(url: url))
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        let parent: ModeusWeb
        private var done = false
        init(_ p: ModeusWeb) { parent = p }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let u = action.request.url, let t = Modeus.token(in: u), Modeus.isModeusToken(t) {
                finish(t)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.loading = false
            if let u = webView.url, let t = Modeus.token(in: u), Modeus.isModeusToken(t) { finish(t); return }
            guard webView.url?.host == Modeus.host else { return }
            ModeusSilentLogin.extract(from: webView) { [weak self] t in
                if let t { self?.finish(t) }
            }
        }

        private func finish(_ t: String) {
            guard !done else { return }
            done = true
            DispatchQueue.main.async { self.parent.onToken(t) }
        }
    }
}

// MARK: - Тихое обновление ключа
// Вход в САФУ запоминается в браузере приложения, поэтому новый ключ обычно выдаётся без пароля.

enum ModeusSilentLogin {
    /// Текущая попытка (держим ссылку, пока идёт)
    @MainActor private static var current: SilentJob?

    @MainActor
    static func run(timeout: Double = 20) async -> String? {
        let url = await Modeus.authorizeURL()
        return await withCheckedContinuation { (c: CheckedContinuation<String?, Never>) in
            let job = SilentJob(c)
            let w = WKWebView(frame: CGRect(x: 0, y: 0, width: 2, height: 2))
            w.alpha = 0.01
            w.isUserInteractionEnabled = false
            let d = SilentDelegate(job)
            w.navigationDelegate = d
            job.web = w
            job.delegate = d
            // невидимо прикрепляем к окну — так WebKit надёжнее исполняет страницу
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            scenes.first?.windows.first?.addSubview(w)
            current = job
            w.load(URLRequest(url: url))
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                job.finish(nil)
            }
        }
    }

    @MainActor fileprivate static func clear(_ job: SilentJob) {
        if current === job { current = nil }
    }

    /// Ищет ключ Modeus в хранилище страницы (localStorage / sessionStorage)
    static func extract(from web: WKWebView, _ done: @escaping (String?) -> Void) {
        let js = """
        (function(){try{for(const s of [localStorage, sessionStorage]){for(let i=0;i<s.length;i++){
        const v=s.getItem(s.key(i)); if(!v) continue; const m=v.match(/eyJ[\\w-]+\\.eyJ[\\w-]+\\.[\\w-]+/g);
        if(m){for(const t of m){ if(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')).indexOf('person_id')>=0) return t; }}}}}catch(e){} return null;})()
        """
        web.evaluateJavaScript(js) { result, _ in done(result as? String) }
    }
}

/// Одна тихая попытка: возобновляется ровно один раз — ключом или nil по таймауту
@MainActor
private final class SilentJob {
    private var c: CheckedContinuation<String?, Never>?
    var web: WKWebView?
    var delegate: SilentDelegate?

    init(_ c: CheckedContinuation<String?, Never>) { self.c = c }

    func finish(_ t: String?) {
        guard let c else { return }
        self.c = nil
        web?.stopLoading()
        web?.removeFromSuperview()
        web = nil
        delegate = nil
        ModeusSilentLogin.clear(self)
        c.resume(returning: t)
    }
}

private final class SilentDelegate: NSObject, WKNavigationDelegate {
    weak var job: SilentJob?
    init(_ j: SilentJob) { job = j }

    private func deliver(_ t: String) {
        Task { @MainActor [weak self] in self?.job?.finish(t) }
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let u = action.request.url, let t = Modeus.token(in: u), Modeus.isModeusToken(t) {
            decisionHandler(.cancel)
            deliver(t)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let u = webView.url, let t = Modeus.token(in: u), Modeus.isModeusToken(t) { deliver(t); return }
        guard webView.url?.host == Modeus.host else { return }
        // страница Modeus могла сама забрать ключ из адреса — даём ей секунду и смотрим хранилище
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            ModeusSilentLogin.extract(from: webView) { t in if let t { self?.deliver(t) } }
        }
    }
}

// MARK: - Карточка «подключить Modeus»

struct ModeusConnectCard: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var login = false
    @AppStorage("modeus.on") private var on = false
    var compact = false

    var body: some View {
        Button {
            Haptics.tap()
            login = true
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "calendar.badge.checkmark")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text("Полное расписание из Modeus").font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                    Text("РУЗ показывает не всё. Войди учётной записью САФУ — пары подтянутся из Modeus.")
                        .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.secondary)
            }
            .padding(compact ? 10 : 14)
            .glass(20)
        }
        .buttonStyle(PressableStyle())
        .sheet(isPresented: $login) {
            ModeusLoginView { ok in
                login = false
                if ok {
                    schedule.clearRuzCache()
                    Task { await schedule.sync(force: true) }
                }
            }
        }
    }
}
