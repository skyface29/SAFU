import SwiftUI
import UIKit
import SpriteKit
import UserNotifications

// MARK: - Праздники и анимации
// Конфетти и поздравления: конец пар, конец недели, выполненная задача, сданный экзамен,
// праздники и день рождения. Каждый повод включается отдельно.

struct Celebration: Identifiable, Equatable {
    /// fireworks — салют из ракет + конфетти; big — длинный салют на конец недели; magic — звёзды шара предсказаний
    enum Style: Equatable { case confetti, emoji([String]), fireworks(big: Bool), magic }
    let id = UUID()
    let created = Date()
    let title: String
    let subtitle: String
    let style: Style
    /// Пасхалки и игра показываются, даже если праздничные анимации выключены
    var force: Bool = false
    /// Значок SF Symbols в кружке слева; без него — по стилю праздника
    var symbol: String? = nil
    /// Короткая подпись справа: время пар, оценка, сколько осталось
    var meta: String? = nil

    var icon: String {
        if let symbol { return symbol }
        switch style {
        case .fireworks: return "sparkles"
        case .confetti: return "party.popper.fill"
        case .emoji: return "star.fill"
        case .magic: return "sparkles"
        }
    }

    /// Градиент кружка со значком
    var tint: [Color] {
        switch icon {
        case "sparkles": return [Color(red: 0.75, green: 0.52, blue: 0.99), Color(red: 0.39, green: 0.40, blue: 0.95)]
        case "checkmark": return [Color(red: 0.29, green: 0.87, blue: 0.50), Color(red: 0.09, green: 0.64, blue: 0.29)]
        case "desktopcomputer": return [Color(red: 0.38, green: 0.65, blue: 0.98), Color(red: 0.15, green: 0.39, blue: 0.92)]
        case "graduationcap.fill": return [Color(red: 0.22, green: 0.74, blue: 0.97), Color(red: 0.39, green: 0.40, blue: 0.95)]
        case "birthday.cake.fill": return [Color(red: 0.96, green: 0.45, blue: 0.71), Color(red: 0.98, green: 0.44, blue: 0.52)]
        default: return [Color(red: 1.00, green: 0.81, blue: 0.35), Color(red: 1.00, green: 0.48, blue: 0.35)]
        }
    }

    /// Сколько живёт праздник: карточка уходит раньше, а конфетти и салют успевают догореть
    var duration: Double {
        if case .fireworks(let big) = style { return big ? 9.2 : 7.2 }
        return 5.2
    }
}

final class CelebrationCenter: ObservableObject {
    static let shared = CelebrationCenter()
    @Published var current: Celebration? {
        didSet {
            if current == nil {
                toastRect = .zero
                FXLayer.hideSoon()
            }
        }
    }
    /// Где на экране плашка с поздравлением — только по ней можно нажать, остальное проходит в приложение
    var toastRect: CGRect = .zero
    /// Конфетти или салют ещё летят — карточку уже закрыли, но окно ждёт, пока всё догорит
    var effectRunning = false

    func fire(_ c: Celebration) {
        guard Celebrations.on || c.force else { return }
        DispatchQueue.main.async {
            // приложение закрыто Face ID — салют дождётся, пока его откроют (раньше он отыгрывал под замком)
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: 0)
                return
            }
            FXLayer.show()
            Haptics.success()
            withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) { self.current = c }
            let id = c.id
            // на салюте каждый разрыв ракеты — «хлопок» вибрацией (его делает сама сцена)
            DispatchQueue.main.asyncAfter(deadline: .now() + c.duration) {
                if self.current?.id == id {
                    withAnimation(.easeOut(duration: 0.4)) { self.current = nil }
                }
            }
        }
    }

    private func waitForUnlock(_ c: Celebration, tries: Int) {
        guard tries < 120 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: tries + 1)
            } else {
                // после Face ID — короткая пауза, пока замок растворяется
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.fire(c) }
            }
        }
    }
}

// MARK: - Своё окно поверх всего

/// Салют и конфетти живут в отдельном прозрачном окне над приложением, листами, полноэкранными окнами
/// и карточками сайтов. Раньше они рисовались в главном экране и оставались под открытым листом
/// или карточкой — поэтому «пропадали». Нажать можно только на плашку поздравления.
final class FXWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let r = CelebrationCenter.shared.toastRect
        guard r.width > 0, r.insetBy(dx: -6, dy: -6).contains(point) else { return nil }
        return super.hitTest(point, with: event)
    }
}

enum FXLayer {
    private static var window: FXWindow?
    private static var hideWork: DispatchWorkItem?
    private static var observer: NSObjectProtocol?

    static func show() {
        hideWork?.cancel()
        hideWork = nil
        if window == nil {
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first else { return }
            let host = UIHostingController(rootView: FXRoot())
            host.view.backgroundColor = .clear
            let w = FXWindow(windowScene: scene)
            // выше листов и карточек сайтов (они на .normal + 1), ниже замка Face ID
            w.windowLevel = .normal + 5
            w.backgroundColor = .clear
            w.rootViewController = host
            window = w
            // ушли из приложения — поздравление не висит поверх шторки приватности
            observer = NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                                              object: nil, queue: .main) { _ in
                CelebrationCenter.shared.current = nil
                window?.isHidden = true
            }
        }
        window?.isHidden = false
    }

    /// Окно прячется, когда поздравление доиграло исчезновение
    static func hideSoon() {
        hideWork?.cancel()
        let work = DispatchWorkItem {
            guard CelebrationCenter.shared.current == nil else { return }
            window?.isHidden = true
        }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }
}

private struct FXRoot: View {
    var body: some View {
        CelebrationOverlay()
            .modifier(AppearanceRoot())
    }
}

enum Celebrations {
    private static var d: UserDefaults { .standard }
    private static func flag(_ k: String, _ def: Bool = true) -> Bool { d.object(forKey: k) as? Bool ?? def }

    static var on: Bool { flag("fx.on") }
    static var dayEnd: Bool { flag("fx.dayEnd") }
    static var weekEnd: Bool { flag("fx.weekEnd") }
    static var tasks: Bool { flag("fx.tasks") }
    static var exams: Bool { flag("fx.exams") }
    static var holidays: Bool { flag("fx.holidays") }
    static var birthday: Bool { flag("fx.birthday") }

    // MARK: разово за день

    private static func dayKey(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }

    private static func once(_ id: String) -> Bool {
        let k = "fx.shown.\(id).\(dayKey())"
        if d.bool(forKey: k) { return false }
        d.set(true, forKey: k)
        return true
    }

    // MARK: поводы

    /// Проверка при открытии приложения
    static func checkOnOpen(data: ScheduleData) {
        guard on else { return }
        let now = Date()
        if birthday, isBirthday(now), once("bday") {
            let name = (d.string(forKey: "user.name") ?? "").split(separator: " ").first.map(String.init) ?? ""
            CelebrationCenter.shared.fire(Celebration(title: "С днём рождения\(name.isEmpty ? "" : ", \(name)")!",
                                                      subtitle: "Пусть все дедлайны будут далеко, а автоматы — близко",
                                                      style: .emoji(["🎂", "🎉", "🎈", "✨"]), symbol: "birthday.cake.fill"))
            return
        }
        if holidays, let h = Holiday.today(now), once("hol-\(h.id)") {
            CelebrationCenter.shared.fire(Celebration(title: h.title, subtitle: h.subtitle, style: h.style))
            return
        }
        // конец пар / недели
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let slots = ScheduleEngine.slots(on: today, data: data)
        guard let last = slots.last, now >= last.end, now < last.end.addingTimeInterval(6 * 3600) else { return }
        let restOfWeekEmpty = weekDone(after: today, data: data)
        if weekEnd, restOfWeekEmpty, once("week") {
            CelebrationCenter.shared.fire(Celebration(title: "Неделя закрыта!",
                                                      subtitle: "Салют в твою честь — свободен до понедельника",
                                                      style: .fireworks(big: true), symbol: "sparkles", meta: "до пн"))
        } else if dayEnd, !restOfWeekEmpty, once("day") {
            CelebrationCenter.shared.fire(Celebration(title: "Пары всё!",
                                                      subtitle: "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть",
                                                      style: .fireworks(big: false), symbol: "party.popper.fill",
                                                      meta: slots.first.map { "\(hhmm($0.start))\n\(hhmm(last.end))" }))
        }
    }

    private static func hhmm(_ d: Date) -> String {
        let c = Calendar.current.dateComponents([.hour, .minute], from: d)
        return String(format: "%d:%02d", c.hour ?? 0, c.minute ?? 0)
    }

    /// После этого дня до конца недели пар больше нет?
    static func weekDone(after day: Date, data: ScheduleData) -> Bool {
        let cal = Calendar.current
        let wd = ScheduleEngine.weekday(of: day)
        guard wd < 7 else { return true }
        for i in 1...(7 - wd) {
            if let next = cal.date(byAdding: .day, value: i, to: cal.startOfDay(for: day)),
               !ScheduleEngine.slots(on: next, data: data).isEmpty { return false }
        }
        return true
    }

    /// Конец сегодняшней последней пары, если он ещё впереди
    static func nextFinish(data: ScheduleData) -> Date? {
        let today = Calendar.current.startOfDay(for: Date())
        guard let last = ScheduleEngine.slots(on: today, data: data).last, last.end > Date() else { return nil }
        return last.end
    }

    /// «Пары всё!» и «Неделя закрыта!» уведомлением на 8 дней вперёд — придут, даже если приложение закрыто.
    /// Нажал — открывается приложение, и там салют.
    static func scheduleNotifications(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (0..<8).map { "fx.end.\($0)" })
        guard on, dayEnd || weekEnd else { return }
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        for i in 0..<8 {
            guard let day = cal.date(byAdding: .day, value: i, to: today) else { continue }
            let slots = ScheduleEngine.slots(on: day, data: data)
            guard let last = slots.last, last.end > Date() else { continue }
            let isWeek = weekDone(after: day, data: data)
            guard isWeek ? weekEnd : dayEnd else { continue }
            let c = UNMutableNotificationContent()
            c.title = isWeek ? "Неделя закрыта! 🎆" : "Пары всё! 🎉"
            c.body = isWeek ? "Свободен до понедельника — открой, там салют в твою честь"
                            : "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть"
            c.sound = .default
            let fire = last.end.addingTimeInterval(20)
            let comps = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fire)
            center.add(UNNotificationRequest(identifier: "fx.end.\(i)", content: c,
                                             trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
        }
    }

    static func taskDone(title: String, left: Int) {
        guard on, tasks else { return }
        CelebrationCenter.shared.fire(Celebration(title: left == 0 ? "Все задачи сделаны!" : "Готово",
                                                  subtitle: left == 0 ? "Ни одного хвоста — красота" : "«\(title)» закрыта",
                                                  style: .confetti, symbol: "checkmark",
                                                  meta: left == 0 ? nil : "ещё \(left)"))
    }

    static func examPassed(subject: String, grade: String) {
        guard on, exams else { return }
        CelebrationCenter.shared.fire(Celebration(title: "Сдано!",
                                                  subtitle: subject,
                                                  style: .emoji(["🎓", "🎉", "⭐️", "🔥"]), symbol: "graduationcap.fill",
                                                  meta: grade))
    }

    static func test() {
        CelebrationCenter.shared.fire(Celebration(title: "Вот так это выглядит",
                                                  subtitle: "Салют как на компьютере, карточка снизу",
                                                  style: .fireworks(big: true)))
    }

    // MARK: день рождения

    static var birthdayDate: Date? {
        let v = d.double(forKey: "user.birthday")
        return v == 0 ? nil : Date(timeIntervalSince1970: v)
    }

    private static func isBirthday(_ now: Date) -> Bool {
        guard let b = birthdayDate else { return false }
        let cal = Calendar.current
        return cal.component(.day, from: b) == cal.component(.day, from: now)
            && cal.component(.month, from: b) == cal.component(.month, from: now)
    }

    private static func pairsWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "пара" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "пары" }
        return "пар"
    }
}

// MARK: - Праздники

struct Holiday {
    let id: String
    let month: Int
    let day: Int
    let title: String
    let subtitle: String
    let style: Celebration.Style

    static let all: [Holiday] = [
        Holiday(id: "ny", month: 1, day: 1, title: "С Новым годом! 🎄", subtitle: "Пусть сессия сдастся сама",
                style: .emoji(["🎄", "❄️", "✨", "🎆"])),
        Holiday(id: "xmas", month: 1, day: 7, title: "С Рождеством! ⭐️", subtitle: "Тепла и уюта", style: .emoji(["⭐️", "❄️", "🕯️"])),
        Holiday(id: "tatiana", month: 1, day: 25, title: "С Днём студента! 🎓", subtitle: "Татьянин день — это твой праздник",
                style: .emoji(["🎓", "📚", "🎉", "✨"])),
        Holiday(id: "feb23", month: 2, day: 23, title: "С 23 Февраля! 🎖️", subtitle: "Сил и стойкости", style: .emoji(["🎖️", "⭐️"])),
        Holiday(id: "mar8", month: 3, day: 8, title: "С 8 Марта! 💐", subtitle: "Весны и хорошего настроения",
                style: .emoji(["💐", "🌷", "🌸", "✨"])),
        Holiday(id: "cosmos", month: 4, day: 12, title: "С Днём космонавтики! 🚀", subtitle: "Поехали!", style: .emoji(["🚀", "🪐", "⭐️"])),
        Holiday(id: "may1", month: 5, day: 1, title: "С Первомаем! 🌷", subtitle: "Весна, труд и отдых", style: .emoji(["🌷", "🌼", "☀️"])),
        Holiday(id: "may9", month: 5, day: 9, title: "С Днём Победы", subtitle: "Помним", style: .emoji(["🕊️", "🌷"])),
        Holiday(id: "jun12", month: 6, day: 12, title: "С Днём России!", subtitle: "Хороших выходных", style: .confetti),
        Holiday(id: "sep1", month: 9, day: 1, title: "С Днём знаний! 📚", subtitle: "Новый семестр — новый уровень",
                style: .emoji(["📚", "✏️", "🎓", "🍁"])),
        Holiday(id: "prog", month: 9, day: 13, title: "С Днём программиста! 💻", subtitle: "256-й день года — свой праздник",
                style: .emoji(["💻", "⌨️", "🐛", "✨"])),
        Holiday(id: "nov4", month: 11, day: 4, title: "С Днём народного единства!", subtitle: "Отдыхай", style: .confetti),
        Holiday(id: "students", month: 11, day: 17, title: "С Международным днём студента! 🎓", subtitle: "Учёба подождёт пять минут",
                style: .emoji(["🎓", "🎉", "📚"])),
        Holiday(id: "security", month: 11, day: 30, title: "С Днём защиты информации! 🔐", subtitle: "Твой профессиональный праздник",
                style: .emoji(["🔐", "🛡️", "💾", "✨"])),
        Holiday(id: "nye", month: 12, day: 31, title: "Последний день года! 🎆", subtitle: "Ты хорошо поработал", style: .emoji(["🎆", "🎄", "✨", "🥂"])),
    ]

    static func today(_ now: Date) -> Holiday? {
        let cal = Calendar.current
        let m = cal.component(.month, from: now), dd = cal.component(.day, from: now)
        // День программиста — 256-й день года (12 сентября в високосный)
        let progDay = cal.range(of: .day, in: .year, for: now)?.count == 366 ? 12 : 13
        return all.first { h in
            if h.id == "prog" { return m == 9 && dd == progDay }
            return h.month == m && h.day == dd
        }
    }
}

// MARK: - Отрисовка

struct CelebrationOverlay: View {
    @ObservedObject private var center = CelebrationCenter.shared

    var body: some View {
        ZStack {
            if let c = center.current {
                if case .fireworks = c.style {
                    // лёгкое затемнение, чтобы салют было видно и в светлой теме
                    Color.black.opacity(0.35)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                }
                CelebrationFX(style: c.style)
                    .id("fx-\(c.id)")
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .transition(.opacity)
                BottomToast(c: c)
                    .id("toast-\(c.id)")
                    .transition(.opacity)
            }
        }
    }
}

/// Плашка поздравления: стеклянная карточка выезжает снизу, над панелью вкладок, как на Windows.
/// Островок не трогает. Уходит сама, по тапу или свайпу вниз; конфетти и салют при этом доигрывают
private struct BottomToast: View {
    let c: Celebration
    @ObservedObject private var center = CelebrationCenter.shared
    @Environment(\.colorScheme) private var scheme
    @State private var shown = false
    @State private var shine = false
    @State private var pull: CGFloat = 0

    /// Сколько держится карточка: на салюте уходит раньше, чтобы ракеты было видно целиком
    static func visible(_ c: Celebration) -> Double {
        if case .fireworks = c.style { return 3.4 }
        return min(c.duration, 3.6)
    }

    var body: some View {
        VStack {
            Spacer(minLength: 0)
            card
                    .frame(maxWidth: 440)
                    .padding(.horizontal, 14)
                    .background(
                        GeometryReader { r in
                            Color.clear
                                .onAppear { center.toastRect = r.frame(in: .global) }
                                .onChange(of: r.frame(in: .global)) { _, f in if shown { center.toastRect = f } }
                        }
                    )
                    .offset(y: shown ? max(0, pull) : 150)
                    .scaleEffect(shown ? 1 : 0.9, anchor: .bottom)
                    .opacity(shown ? 1 : 0)
                    // над панелью вкладок
                    .padding(.bottom, 58)
        }
        .frame(maxWidth: .infinity)
        .onAppear {
            withAnimation(.spring(response: 0.48, dampingFraction: 0.7).delay(0.08)) { shown = true }
            // блик пробегает по карточке один раз, когда она встала на место
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.42) {
                withAnimation(.easeInOut(duration: 0.9)) { shine = true }
            }
        }
        .task(id: c.id) {
            try? await Task.sleep(nanoseconds: UInt64(Self.visible(c) * 1_000_000_000))
            guard center.current?.id == c.id else { return }
            close()
        }
    }

    private var card: some View {
        let shape = RoundedRectangle(cornerRadius: 26, style: .continuous)
        let accent = c.tint.last ?? .orange
        return HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: c.tint, startPoint: .topLeading, endPoint: .bottomTrailing))
                Circle()
                    .strokeBorder(.white.opacity(0.35), lineWidth: 1)
                Image(systemName: c.icon)
                    .font(.system(size: 21, weight: .semibold))
                    .foregroundStyle(.white)
                    .symbolEffect(.bounce, value: shown)
            }
            .frame(width: 50, height: 50)
            .shadow(color: accent.opacity(0.45), radius: 9, y: 4)
            VStack(alignment: .leading, spacing: 3) {
                Text(c.title)
                    .font(.system(size: 17, weight: .heavy, design: .rounded))
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                    .fixedSize(horizontal: false, vertical: true)
                if !c.subtitle.isEmpty {
                    Text(c.subtitle)
                        .font(.system(size: 13.5))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            if let meta = c.meta {
                Text(meta)
                    .font(.system(size: 12, weight: .bold, design: .rounded).monospacedDigit())
                    .foregroundStyle(accent)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .fixedSize()
                    .padding(.horizontal, 9)
                    .padding(.vertical, 6)
                    .background(accent.opacity(0.14), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            }
        }
        .padding(.leading, 14)
        .padding(.trailing, 16)
        .padding(.vertical, 14)
        .background(.regularMaterial, in: shape)
        // лёгкий цветной отсвет праздника по краю стекла
        .background(
            shape.fill(LinearGradient(colors: c.tint.map { $0.opacity(0.18) }, startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .overlay(
            shape.strokeBorder(
                LinearGradient(colors: [.white.opacity(scheme == .dark ? 0.22 : 0.7), .white.opacity(0.05)],
                               startPoint: .top, endPoint: .bottom),
                lineWidth: 0.8)
        )
        .overlay(
            GeometryReader { g in
                LinearGradient(colors: [.clear, .white.opacity(scheme == .dark ? 0.16 : 0.45), .clear],
                               startPoint: .leading, endPoint: .trailing)
                    .frame(width: g.size.width * 0.35)
                    .rotationEffect(.degrees(18))
                    .offset(x: shine ? g.size.width * 1.2 : -g.size.width * 0.5)
            }
            .clipShape(shape)
            .allowsHitTesting(false)
        )
        .shadow(color: .black.opacity(scheme == .dark ? 0.45 : 0.16), radius: 24, y: 10)
        .contentShape(shape)
        .onTapGesture { close() }
        .gesture(
            DragGesture(minimumDistance: 6)
                .onChanged { v in pull = v.translation.height }
                .onEnded { v in
                    if v.translation.height > 40 || v.predictedEndTranslation.height > 120 {
                        close()
                    } else {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) { pull = 0 }
                    }
                }
        )
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(.isButton)
    }

    private func close() {
        guard shown else { return }
        withAnimation(.spring(response: 0.34, dampingFraction: 0.9)) { shown = false }
        center.toastRect = .zero
        let id = c.id
        // карточка ушла, а конфетти и салют доигрывают до конца — окно закроется по сроку праздника
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            guard center.current?.id == id, !center.effectRunning else { return }
            withAnimation(.easeOut(duration: 0.2)) { center.current = nil }
        }
    }
}

// MARK: - Конфетти и салют: свой движок

/// Конфетти и салют рисует SpriteKit (видеочип). Физику считаем сами, она простая и предсказуемая:
/// у каждой бумажки есть сопротивление воздуха, тяжесть, покачивание и переворот — поэтому залп
/// взлетает, тормозит и кружась опускается, а не уносится по прямой за край экрана.
/// Отсчёт идёт с первого показанного кадра, а когда всё догорело, сцена встаёт на паузу.
private struct CelebrationFX: UIViewRepresentable {
    let style: Celebration.Style

    func makeUIView(context: Context) -> FXSpriteView {
        let v = FXSpriteView()
        v.allowsTransparency = true
        v.backgroundColor = .clear
        v.isUserInteractionEnabled = false
        v.ignoresSiblingOrder = true
        v.preferredFramesPerSecond = UIScreen.main.maximumFramesPerSecond
        context.coordinator.view = v
        // сцена создаётся, когда известен размер экрана
        let style = style
        v.onLayout = { [weak coordinator = context.coordinator] in coordinator?.start(style) }
        return v
    }

    func updateUIView(_ v: FXSpriteView, context: Context) {}

    static func dismantleUIView(_ v: FXSpriteView, coordinator: Coordinator) {
        v.isPaused = true
        v.presentScene(nil)
        CelebrationCenter.shared.effectRunning = false
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    final class Coordinator {
        weak var view: SKView?
        func start(_ style: Celebration.Style) {
            guard let v = view, v.scene == nil, v.bounds.width > 10, v.bounds.height > 10 else { return }
            guard !UIAccessibility.isReduceMotionEnabled else { return }
            let scene = CelebrationScene(size: v.bounds.size, style: style)
            CelebrationCenter.shared.effectRunning = true
            scene.onFinish = { [weak v] in
                v?.isPaused = true
                CelebrationCenter.shared.effectRunning = false
            }
            v.presentScene(scene)
        }
    }
}

final class FXSpriteView: SKView {
    var onLayout: (() -> Void)?
    override func layoutSubviews() {
        super.layoutSubviews()
        onLayout?()
    }
}

final class CelebrationScene: SKScene {
    private let style: Celebration.Style
    var onFinish: (() -> Void)?

    private struct Paper {
        let node: SKSpriteNode
        let light: UIColor
        let dark: UIColor
        var vx: CGFloat, vy: CGFloat
        var spin: CGFloat, flip: CGFloat, flipSpeed: CGFloat, sway: CGFloat
        var life: CGFloat = 0
        let max: CGFloat
        let delay: CGFloat
        let tint: Bool
        let base: CGFloat
    }

    /// Искра салюта. streak — вытягивается по направлению полёта, как светящийся след на Windows
    private struct Spark {
        let node: SKSpriteNode
        var vx: CGFloat, vy: CGFloat
        var life: CGFloat = 0
        let max: CGFloat
        let drag: CGFloat
        let fall: CGFloat
        let streak: Bool
        let twinkle: Bool
        let size: CGFloat
    }

    private struct Rocket {
        let head: SKSpriteNode
        var x: CGFloat, y: CGFloat, vy: CGFloat
        let top: CGFloat
        let color: UIColor
        let delay: CGFloat
        var smoke: CGFloat = 0
        var done = false
    }

    private var papers: [Paper] = []
    private var sparks: [Spark] = []
    private var rockets: [Rocket] = []
    private var clock: TimeInterval?
    private var elapsed: CGFloat = 0
    private var finished = false

    // MARK: Палитры и текстуры

    private static let paperColors: [UIColor] = [
        UIColor(red: 1.00, green: 0.35, blue: 0.35, alpha: 1), UIColor(red: 1.00, green: 0.75, blue: 0.20, alpha: 1),
        UIColor(red: 0.30, green: 0.79, blue: 0.44, alpha: 1), UIColor(red: 0.25, green: 0.61, blue: 1.00, alpha: 1),
        UIColor(red: 0.70, green: 0.40, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.45, blue: 0.75, alpha: 1),
        UIColor(red: 0.98, green: 0.98, blue: 1.00, alpha: 1),
    ]
    /// Шар предсказаний: сирень, фиолетовый, жемчуг и золото
    private static let magicColors: [UIColor] = [
        UIColor(red: 0.74, green: 0.60, blue: 1.00, alpha: 1), UIColor(red: 0.56, green: 0.38, blue: 1.00, alpha: 1),
        UIColor(red: 0.90, green: 0.86, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.84, blue: 0.42, alpha: 1),
        UIColor(red: 1.00, green: 0.62, blue: 0.86, alpha: 1),
    ]
    /// Цвета салюта — те же, что на Windows
    private static let rocketColors: [UIColor] = [
        UIColor(red: 1.00, green: 0.30, blue: 0.43, alpha: 1), UIColor(red: 1.00, green: 0.84, blue: 0.04, alpha: 1),
        UIColor(red: 0.30, green: 0.79, blue: 0.94, alpha: 1), UIColor(red: 0.50, green: 0.93, blue: 0.60, alpha: 1),
        UIColor(red: 0.78, green: 0.49, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.62, blue: 0.00, alpha: 1),
    ]
    private static let ember = UIColor(red: 1.00, green: 0.80, blue: 0.40, alpha: 1)

    /// Белые заготовки — цвет каждой бумажке задаётся тонированием, текстур всего несколько
    private static let rect = shape(CGSize(width: 8, height: 12)) { UIBezierPath(roundedRect: $0, cornerRadius: 1.5) }
    private static let strip = shape(CGSize(width: 4, height: 15)) { UIBezierPath(roundedRect: $0, cornerRadius: 1) }
    private static let disc = shape(CGSize(width: 8, height: 8)) { UIBezierPath(ovalIn: $0) }
    private static let star = shape(CGSize(width: 12, height: 12)) { r in
        let p = UIBezierPath()
        let c = CGPoint(x: r.midX, y: r.midY)
        for i in 0..<8 {
            let a = CGFloat(i) * .pi / 4 - .pi / 2
            let rad = i % 2 == 0 ? r.width / 2 : r.width * 0.17
            let pt = CGPoint(x: c.x + cos(a) * rad, y: c.y + sin(a) * rad)
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.close()
        return p
    }
    private static let glow = glowTexture(16, core: 0.3)
    private static let flash = glowTexture(96, core: 0.04)
    /// Искра со следом: яркая голова сверху и тающий хвост вниз
    private static let streakTexture: SKTexture = {
        let size = CGSize(width: 8, height: 48)
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        let img = UIGraphicsImageRenderer(size: size, format: f).image { ctx in
            let colors = [UIColor.white.withAlphaComponent(0).cgColor, UIColor.white.withAlphaComponent(0.45).cgColor,
                          UIColor.white.cgColor]
            guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray,
                                     locations: [0, 0.7, 1]) else { return }
            ctx.cgContext.saveGState()
            UIBezierPath(roundedRect: CGRect(x: 2, y: 0, width: 4, height: size.height), cornerRadius: 2).addClip()
            ctx.cgContext.drawLinearGradient(g, start: CGPoint(x: 0, y: size.height), end: CGPoint(x: 0, y: 4), options: [])
            ctx.cgContext.restoreGState()
            let head = CGRect(x: 0, y: 0, width: 8, height: 8)
            if let hg = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor.white.cgColor, UIColor.white.withAlphaComponent(0).cgColor] as CFArray,
                                   locations: [0.3, 1]) {
                ctx.cgContext.drawRadialGradient(hg, startCenter: CGPoint(x: head.midX, y: head.midY), startRadius: 0,
                                                 endCenter: CGPoint(x: head.midX, y: head.midY), endRadius: 4, options: [])
            }
        }
        return SKTexture(image: img)
    }()

    private static func shape(_ size: CGSize, _ path: (CGRect) -> UIBezierPath) -> SKTexture {
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        let img = UIGraphicsImageRenderer(size: size, format: f).image { _ in
            UIColor.white.setFill()
            path(CGRect(origin: .zero, size: size)).fill()
        }
        return SKTexture(image: img)
    }

    private static func glowTexture(_ size: CGFloat, core: CGFloat) -> SKTexture {
        let f = UIGraphicsImageRendererFormat()
        f.scale = 2
        let img = UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: f).image { ctx in
            let colors = [UIColor.white.cgColor, UIColor.white.withAlphaComponent(0.6).cgColor, UIColor.white.withAlphaComponent(0).cgColor]
            guard let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray,
                                     locations: [0, core, 1]) else { return }
            let c = CGPoint(x: size / 2, y: size / 2)
            ctx.cgContext.drawRadialGradient(g, startCenter: c, startRadius: 0, endCenter: c, endRadius: size / 2, options: [])
        }
        return SKTexture(image: img)
    }

    private static func emojiTexture(_ e: String) -> SKTexture? {
        let str = NSAttributedString(string: e, attributes: [.font: UIFont.systemFont(ofSize: 24)])
        let size = str.size()
        guard size.width > 0, size.height > 0 else { return nil }
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        return SKTexture(image: UIGraphicsImageRenderer(size: size, format: f).image { _ in str.draw(at: .zero) })
    }

    // MARK: Запуск

    init(size: CGSize, style: Celebration.Style) {
        self.style = style
        super.init(size: size)
        backgroundColor = .clear
        scaleMode = .resizeFill
    }

    required init?(coder: NSCoder) { fatalError() }

    override func didMove(to view: SKView) {
        let plain: [(UIColor, SKTexture?)] = Self.paperColors.map { ($0, nil) }
        switch style {
        case .confetti: cannons(plain)
        case .emoji(let list):
            let tex: [(UIColor, SKTexture?)] = list.compactMap { Self.emojiTexture($0) }.map { (UIColor.white, $0) }
            cannons(tex.isEmpty ? plain : tex + plain, count: 60)
        case .magic: magic()
        case .fireworks(let big): fireworks(big: big)
        }
    }

    private func r(_ a: CGFloat, _ b: CGFloat) -> CGFloat { CGFloat.random(in: a...b) }

    private func addPaper(at p: CGPoint, vx: CGFloat, vy: CGFloat, color: UIColor, texture: SKTexture?,
                          delay: CGFloat, life: ClosedRange<CGFloat> = 3.6...5, scale: ClosedRange<CGFloat> = 0.85...1.25,
                          tinted: Bool? = nil) {
        let tex = texture ?? [Self.rect, Self.rect, Self.strip, Self.disc].randomElement()!
        let n = SKSpriteNode(texture: tex)
        let tint = tinted ?? (texture == nil)
        if tint {
            n.color = color
            n.colorBlendFactor = 1
        }
        let base = r(scale.lowerBound, scale.upperBound)
        n.setScale(base)
        n.position = p
        n.zRotation = r(0, .pi * 2)
        n.isHidden = delay > 0
        addChild(n)
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        color.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        papers.append(Paper(node: n, light: color, dark: UIColor(hue: h, saturation: s, brightness: b * 0.72, alpha: 1),
                            vx: vx, vy: vy, spin: r(-6, 6), flip: r(0, .pi * 2), flipSpeed: r(5, 11),
                            sway: r(0, .pi * 2), max: r(life.lowerBound, life.upperBound), delay: delay, tint: tint, base: base))
    }

    /// Хлопушки: два залпа из нижних углов к середине экрана
    private func cannons(_ kinds: [(UIColor, SKTexture?)], count: Int = 80) {
        let h = size.height
        for side: CGFloat in [-1, 1] {
            let origin = CGPoint(x: side < 0 ? -6 : size.width + 6, y: h * 0.14)
            for _ in 0..<count {
                let ang = .pi / 2 + side * r(0.12, 0.62)
                let sp = r(h * 1.2, h * 2.1)
                let k = kinds.randomElement()!
                addPaper(at: origin, vx: cos(ang) * sp, vy: sin(ang) * sp, color: k.0, texture: k.1,
                         delay: side < 0 ? r(0, 0.08) : r(0.12, 0.2))
            }
        }
    }

    /// Шар предсказаний: маленькое конфетти и звёздочки вылетают из-за карточки фонтанчиком,
    /// мерцают и мягко оседают
    private func magic() {
        let h = size.height
        let origin = CGPoint(x: size.width / 2, y: h * 0.17)
        for i in 0..<90 {
            let ang = .pi / 2 + r(-0.75, 0.75)
            let sp = r(h * 0.75, h * 1.35)
            let isStar = i % 3 == 0
            addPaper(at: CGPoint(x: origin.x + r(-60, 60), y: origin.y), vx: cos(ang) * sp, vy: sin(ang) * sp,
                     color: Self.magicColors.randomElement()!, texture: isStar ? Self.star : nil,
                     delay: 0.18 + r(0, 0.12), life: 2.8...3.8, scale: isStar ? 0.6...0.95 : 0.45...0.7, tinted: true)
        }
        for _ in 0..<26 {
            let ang = .pi / 2 + r(-0.9, 0.9), sp = r(h * 0.3, h * 0.6)
            spark(at: CGPoint(x: origin.x + r(-50, 50), y: origin.y), vx: cos(ang) * sp, vy: sin(ang) * sp,
                  color: Self.magicColors.randomElement()!, life: r(1.4, 2.2), drag: 2.2, fall: 0.04,
                  streak: false, twinkle: true, size: r(0.35, 0.6), delay: 0.2)
        }
    }

    /// Салют как на Windows: ракеты по очереди взлетают, оставляя золотые искры, тормозят
    /// и раскрываются шаром или ровным кольцом; искры тянут светящиеся следы и осыпаются
    private func fireworks(big: Bool) {
        let n = big ? 14 : 8
        let step: CGFloat = big ? 0.42 : 0.52
        let w = size.width, h = size.height
        // скорости с Windows (пиксели за кадр при 60 к/с), приведённые к высоте экрана iPhone
        let k = h / 850
        for i in 0..<n {
            let head = SKSpriteNode(texture: Self.glow)
            head.blendMode = .add
            head.setScale(0.6)
            head.isHidden = true
            addChild(head)
            rockets.append(Rocket(head: head, x: r(w * 0.15, w * 0.85), y: -10, vy: r(600, 780) * k,
                                  top: h * r(0.55, 0.88), color: Self.rocketColors[i % Self.rocketColors.count],
                                  delay: 0.12 + CGFloat(i) * step + r(0, 0.2)))
        }
    }

    private func spark(at p: CGPoint, vx: CGFloat, vy: CGFloat, color: UIColor, life: CGFloat, drag: CGFloat,
                       fall: CGFloat, streak: Bool, twinkle: Bool, size: CGFloat, delay: CGFloat = 0) {
        let n = SKSpriteNode(texture: streak ? Self.streakTexture : Self.glow)
        n.blendMode = .add
        n.color = color
        n.colorBlendFactor = 1
        n.anchorPoint = streak ? CGPoint(x: 0.5, y: 0.92) : CGPoint(x: 0.5, y: 0.5)
        n.setScale(size)
        n.position = p
        n.isHidden = delay > 0
        addChild(n)
        sparks.append(Spark(node: n, vx: vx, vy: vy, life: -delay, max: life, drag: drag, fall: fall,
                            streak: streak, twinkle: twinkle, size: size))
    }

    private func explode(_ rk: Rocket, big: Bool) {
        let p = CGPoint(x: rk.x, y: rk.y)
        let w = size.width
        let count = big ? 110 : 75
        // половина залпов — ровное кольцо, остальные — пушистый шар
        let ring = Bool.random()
        for i in 0..<count {
            let ang = CGFloat(i) / CGFloat(count) * .pi * 2
            let sp = ring ? w * (big ? 0.78 : 0.62) : w * r(0.12, big ? 0.95 : 0.75)
            let white = CGFloat.random(in: 0...1) > 0.8
            spark(at: p, vx: cos(ang) * sp, vy: sin(ang) * sp, color: white ? .white : rk.color,
                  life: r(1.0, 1.65), drag: 1.83, fall: 0.25, streak: true, twinkle: false, size: r(0.42, 0.62))
        }
        let f = SKSpriteNode(texture: Self.flash)
        f.blendMode = .add
        f.color = rk.color
        f.colorBlendFactor = 0.5
        f.position = p
        f.setScale(0.35)
        addChild(f)
        f.run(.sequence([.group([.scale(to: 1.25, duration: 0.22), .fadeOut(withDuration: 0.3)]), .removeFromParent()]))
        UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: big ? 0.8 : 0.65)
    }

    // MARK: Кадр

    override func update(_ currentTime: TimeInterval) {
        guard !finished else { return }
        let dt = CGFloat(min(1.0 / 30, currentTime - (clock ?? currentTime)))
        clock = currentTime
        elapsed += dt
        let h = size.height
        let t = elapsed
        var alive = false

        // бумажки: воздух тормозит быстрые, тяжесть тянет вниз, но не быстрее «парашютной» скорости
        let gravity = h * 0.55, terminal = h * 0.16, drag: CGFloat = 2.6
        for i in papers.indices {
            var p = papers[i]
            guard t >= p.delay, p.life < p.max else { continue }
            alive = true
            p.node.isHidden = false
            p.life += dt
            p.vx -= p.vx * drag * dt
            p.vy -= p.vy * drag * dt
            p.vy -= gravity * dt
            if p.vy < -terminal { p.vy = -terminal }
            p.vx += sin(p.life * 3 + p.sway) * h * 0.09 * dt
            p.node.position.x += p.vx * dt
            p.node.position.y += p.vy * dt
            p.node.zRotation += p.spin * dt
            p.flip += p.flipSpeed * dt
            // переворот бумажки: сжимается до ребра и показывает тёмную сторону
            let f = cos(p.flip)
            p.node.xScale = p.base
            p.node.yScale = max(0.08, abs(f)) * p.base
            if p.tint { p.node.color = f < 0 ? p.dark : p.light }
            p.node.alpha = min(1, (p.max - p.life) / 0.6)
            if p.life >= p.max || p.node.position.y < -30 {
                p.life = p.max
                p.node.removeFromParent()
            }
            papers[i] = p
        }

        // ракеты: летят вверх и тормозят, пока не дойдут до высоты разрыва
        var big = false
        if case .fireworks(let b) = style { big = b }
        let k = h / 850
        for i in rockets.indices {
            var rk = rockets[i]
            guard t >= rk.delay, !rk.done else { continue }
            alive = true
            rk.head.isHidden = false
            rk.y += rk.vy * dt
            rk.vy -= 432 * k * dt
            rk.head.position = CGPoint(x: rk.x, y: rk.y)
            // за ракетой сыплются золотые искорки
            rk.smoke += dt
            while rk.smoke > 1.0 / 60 {
                rk.smoke -= 1.0 / 60
                spark(at: CGPoint(x: rk.x + r(-1.5, 1.5), y: rk.y - 4), vx: r(-18, 18), vy: -r(30, 90),
                      color: Self.ember, life: 0.34, drag: 0, fall: 0, streak: false, twinkle: false, size: 0.26)
            }
            if rk.y >= rk.top || rk.vy <= 60 * k {
                rk.done = true
                rk.head.removeFromParent()
                explode(rk, big: big)
            }
            rockets[i] = rk
        }

        for i in sparks.indices {
            var s = sparks[i]
            guard s.life < s.max else { continue }
            alive = true
            s.life += dt
            guard s.life > 0 else { sparks[i] = s; continue }
            s.node.isHidden = false
            s.vx -= s.vx * s.drag * dt
            s.vy -= s.vy * s.drag * dt
            s.vy -= h * s.fall * dt
            s.node.position.x += s.vx * dt
            s.node.position.y += s.vy * dt
            let a = max(0, 1 - s.life / s.max)
            if s.streak {
                // след тем длиннее, чем быстрее летит искра; к концу остаётся просто точка
                let speed = sqrt(s.vx * s.vx + s.vy * s.vy)
                s.node.zRotation = atan2(s.vy, s.vx) - .pi / 2
                s.node.yScale = s.size * min(1, max(0.18, speed / (size.width * 0.9)))
                s.node.xScale = s.size
            }
            s.node.alpha = s.twinkle ? a * (0.4 + 0.6 * abs(sin(s.life * 18 + s.node.position.x))) : a
            if s.life >= s.max { s.node.removeFromParent() }
            sparks[i] = s
        }
        if rockets.contains(where: { !$0.done }) { alive = true }

        if !alive && t > 0.5 {
            finished = true
            papers.removeAll()
            sparks.removeAll()
            onFinish?()
        }
    }
}

// MARK: - Настройки

struct CelebrationSettingsView: View {
    @AppStorage("fx.on") private var on = true
    @AppStorage("fx.dayEnd") private var dayEnd = true
    @AppStorage("fx.weekEnd") private var weekEnd = true
    @AppStorage("fx.tasks") private var tasks = true
    @AppStorage("fx.exams") private var exams = true
    @AppStorage("fx.holidays") private var holidays = true
    @AppStorage("fx.birthday") private var birthday = true
    @AppStorage("user.birthday") private var birthdayTS: Double = 0

    private var bdayBinding: Binding<Date> {
        Binding(get: { birthdayTS == 0 ? Calendar.current.date(from: DateComponents(year: 2007, month: 1, day: 1)) ?? Date()
                                       : Date(timeIntervalSince1970: birthdayTS) },
                set: { birthdayTS = $0.timeIntervalSince1970 })
    }

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $on) { Label("Праздничные анимации", systemImage: "party.popper.fill") }
                if on {
                    Button {
                        Celebrations.test()
                    } label: {
                        Label("Показать сейчас", systemImage: "sparkles")
                    }
                }
            } footer: {
                Text("Конфетти и короткое поздравление внизу экрана. Не мешает: пропадает само через пару секунд, тап — сразу.")
            }
            if on {
                Section("Когда") {
                    Toggle("Закончились пары на сегодня", isOn: $dayEnd)
                    Toggle("Закончилась учебная неделя", isOn: $weekEnd)
                    Toggle("Выполнил задачу", isOn: $tasks)
                    Toggle("Сдал экзамен или зачёт", isOn: $exams)
                    Toggle("Праздники", isOn: $holidays)
                    Toggle("День рождения", isOn: $birthday)
                    if birthday {
                        DatePicker("Дата рождения", selection: bdayBinding, displayedComponents: .date)
                    }
                }
                Section {
                    ForEach(Holiday.all, id: \.id) { h in
                        HStack {
                            Text(h.title).font(.subheadline)
                            Spacer()
                            Text("\(h.day).\(String(format: "%02d", h.month))")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text("Какие праздники")
                } footer: {
                    Text("Среди них — День студента, День программиста и 30 ноября — День защиты информации.")
                }
            }
        }
        .navigationTitle("Праздники")
    }
}
