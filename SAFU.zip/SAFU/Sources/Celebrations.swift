import SwiftUI
import UIKit
import UserNotifications

// MARK: - Праздники и анимации
// Конфетти и поздравления: конец пар, конец недели, выполненная задача, сданный экзамен,
// праздники и день рождения. Каждый повод включается отдельно.

struct Celebration: Identifiable, Equatable {
    /// fireworks — салют из ракет + конфетти; big — длинный салют на конец недели
    enum Style: Equatable { case confetti, emoji([String]), fireworks(big: Bool) }
    let id = UUID()
    let created = Date()
    let title: String
    let subtitle: String
    let style: Style
    /// Пасхалки и игра показываются, даже если праздничные анимации выключены
    var force: Bool = false
    /// Значок SF Symbols в кружке слева; без него — по стилю праздника
    var symbol: String? = nil
    /// Короткая подпись справа: время пар, оценка, сколько осталось
    var meta: String? = nil

    var icon: String {
        if let symbol { return symbol }
        switch style {
        case .fireworks: return "sparkles"
        case .confetti: return "party.popper.fill"
        case .emoji: return "star.fill"
        }
    }

    /// Градиент кружка со значком
    var tint: [Color] {
        switch icon {
        case "sparkles": return [Color(red: 0.75, green: 0.52, blue: 0.99), Color(red: 0.39, green: 0.40, blue: 0.95)]
        case "checkmark": return [Color(red: 0.29, green: 0.87, blue: 0.50), Color(red: 0.09, green: 0.64, blue: 0.29)]
        case "desktopcomputer": return [Color(red: 0.38, green: 0.65, blue: 0.98), Color(red: 0.15, green: 0.39, blue: 0.92)]
        case "graduationcap.fill": return [Color(red: 0.22, green: 0.74, blue: 0.97), Color(red: 0.39, green: 0.40, blue: 0.95)]
        case "birthday.cake.fill": return [Color(red: 0.96, green: 0.45, blue: 0.71), Color(red: 0.98, green: 0.44, blue: 0.52)]
        default: return [Color(red: 1.00, green: 0.81, blue: 0.35), Color(red: 1.00, green: 0.48, blue: 0.35)]
        }
    }

    /// Сколько висит на экране
    var duration: Double {
        if case .fireworks(let big) = style { return big ? 7.5 : 6 }
        return 4.2
    }
}

final class CelebrationCenter: ObservableObject {
    static let shared = CelebrationCenter()
    @Published var current: Celebration? {
        didSet {
            if current == nil {
                toastRect = .zero
                FXLayer.hideSoon()
            }
        }
    }
    /// Где на экране плашка с поздравлением — только по ней можно нажать, остальное проходит в приложение
    var toastRect: CGRect = .zero

    func fire(_ c: Celebration) {
        guard Celebrations.on || c.force else { return }
        DispatchQueue.main.async {
            // приложение закрыто Face ID — салют дождётся, пока его откроют (раньше он отыгрывал под замком)
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: 0)
                return
            }
            FXLayer.show()
            Haptics.success()
            withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) { self.current = c }
            let id = c.id
            // на салюте — ещё пара «хлопков» вибрацией
            if case .fireworks = c.style {
                for delay in [1.1, 1.9, 2.8] {
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                        UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.8)
                    }
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + c.duration) {
                if self.current?.id == id {
                    withAnimation(.easeOut(duration: 0.4)) { self.current = nil }
                }
            }
        }
    }

    private func waitForUnlock(_ c: Celebration, tries: Int) {
        guard tries < 120 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: tries + 1)
            } else {
                // после Face ID — короткая пауза, пока замок растворяется
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.fire(c) }
            }
        }
    }
}

// MARK: - Своё окно поверх всего

/// Салют и конфетти живут в отдельном прозрачном окне над приложением, листами, полноэкранными окнами
/// и карточками сайтов. Раньше они рисовались в главном экране и оставались под открытым листом
/// или карточкой — поэтому «пропадали». Нажать можно только на плашку поздравления.
final class FXWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let r = CelebrationCenter.shared.toastRect
        guard r.width > 0, r.insetBy(dx: -6, dy: -6).contains(point) else { return nil }
        return super.hitTest(point, with: event)
    }
}

enum FXLayer {
    private static var window: FXWindow?
    private static var hideWork: DispatchWorkItem?
    private static var observer: NSObjectProtocol?

    static func show() {
        hideWork?.cancel()
        hideWork = nil
        if window == nil {
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first else { return }
            let host = UIHostingController(rootView: FXRoot())
            host.view.backgroundColor = .clear
            let w = FXWindow(windowScene: scene)
            // выше листов и карточек сайтов (они на .normal + 1), ниже замка Face ID
            w.windowLevel = .normal + 5
            w.backgroundColor = .clear
            w.rootViewController = host
            window = w
            // ушли из приложения — поздравление не висит поверх шторки приватности
            observer = NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                                              object: nil, queue: .main) { _ in
                CelebrationCenter.shared.current = nil
                window?.isHidden = true
            }
        }
        window?.isHidden = false
    }

    /// Высота верхнего выреза: у iPhone с Dynamic Island она от 51 pt — по ней плашка растёт прямо из островка
    static var safeTop: CGFloat {
        if let window { return window.safeAreaInsets.top }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        return scenes.first?.windows.first?.safeAreaInsets.top ?? 47
    }

    /// Окно прячется, когда поздравление доиграло исчезновение
    static func hideSoon() {
        hideWork?.cancel()
        let work = DispatchWorkItem {
            guard CelebrationCenter.shared.current == nil else { return }
            window?.isHidden = true
        }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }
}

private struct FXRoot: View {
    var body: some View {
        CelebrationOverlay()
            .modifier(AppearanceRoot())
    }
}

enum Celebrations {
    private static var d: UserDefaults { .standard }
    private static func flag(_ k: String, _ def: Bool = true) -> Bool { d.object(forKey: k) as? Bool ?? def }

    static var on: Bool { flag("fx.on") }
    static var dayEnd: Bool { flag("fx.dayEnd") }
    static var weekEnd: Bool { flag("fx.weekEnd") }
    static var tasks: Bool { flag("fx.tasks") }
    static var exams: Bool { flag("fx.exams") }
    static var holidays: Bool { flag("fx.holidays") }
    static var birthday: Bool { flag("fx.birthday") }

    // MARK: разово за день

    private static func dayKey(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }

    private static func once(_ id: String) -> Bool {
        let k = "fx.shown.\(id).\(dayKey())"
        if d.bool(forKey: k) { return false }
        d.set(true, forKey: k)
        return true
    }

    // MARK: поводы

    /// Проверка при открытии приложения
    static func checkOnOpen(data: ScheduleData) {
        guard on else { return }
        let now = Date()
        if birthday, isBirthday(now), once("bday") {
            let name = (d.string(forKey: "user.name") ?? "").split(separator: " ").first.map(String.init) ?? ""
            CelebrationCenter.shared.fire(Celebration(title: "С днём рождения\(name.isEmpty ? "" : ", \(name)")!",
                                                      subtitle: "Пусть все дедлайны будут далеко, а автоматы — близко",
                                                      style: .emoji(["🎂", "🎉", "🎈", "✨"]), symbol: "birthday.cake.fill"))
            return
        }
        if holidays, let h = Holiday.today(now), once("hol-\(h.id)") {
            CelebrationCenter.shared.fire(Celebration(title: h.title, subtitle: h.subtitle, style: h.style))
            return
        }
        // конец пар / недели
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let slots = ScheduleEngine.slots(on: today, data: data)
        guard let last = slots.last, now >= last.end, now < last.end.addingTimeInterval(6 * 3600) else { return }
        let restOfWeekEmpty = weekDone(after: today, data: data)
        if weekEnd, restOfWeekEmpty, once("week") {
            CelebrationCenter.shared.fire(Celebration(title: "Неделя закрыта!",
                                                      subtitle: "Салют в твою честь — свободен до понедельника",
                                                      style: .fireworks(big: true), symbol: "sparkles", meta: "до пн"))
        } else if dayEnd, !restOfWeekEmpty, once("day") {
            CelebrationCenter.shared.fire(Celebration(title: "Пары всё!",
                                                      subtitle: "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть",
                                                      style: .fireworks(big: false), symbol: "party.popper.fill",
                                                      meta: slots.first.map { "\(hhmm($0.start))\n\(hhmm(last.end))" }))
        }
    }

    private static func hhmm(_ d: Date) -> String {
        let c = Calendar.current.dateComponents([.hour, .minute], from: d)
        return String(format: "%d:%02d", c.hour ?? 0, c.minute ?? 0)
    }

    /// После этого дня до конца недели пар больше нет?
    static func weekDone(after day: Date, data: ScheduleData) -> Bool {
        let cal = Calendar.current
        let wd = ScheduleEngine.weekday(of: day)
        guard wd < 7 else { return true }
        for i in 1...(7 - wd) {
            if let next = cal.date(byAdding: .day, value: i, to: cal.startOfDay(for: day)),
               !ScheduleEngine.slots(on: next, data: data).isEmpty { return false }
        }
        return true
    }

    /// Конец сегодняшней последней пары, если он ещё впереди
    static func nextFinish(data: ScheduleData) -> Date? {
        let today = Calendar.current.startOfDay(for: Date())
        guard let last = ScheduleEngine.slots(on: today, data: data).last, last.end > Date() else { return nil }
        return last.end
    }

    /// «Пары всё!» и «Неделя закрыта!» уведомлением на 8 дней вперёд — придут, даже если приложение закрыто.
    /// Нажал — открывается приложение, и там салют.
    static func scheduleNotifications(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (0..<8).map { "fx.end.\($0)" })
        guard on, dayEnd || weekEnd else { return }
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        for i in 0..<8 {
            guard let day = cal.date(byAdding: .day, value: i, to: today) else { continue }
            let slots = ScheduleEngine.slots(on: day, data: data)
            guard let last = slots.last, last.end > Date() else { continue }
            let isWeek = weekDone(after: day, data: data)
            guard isWeek ? weekEnd : dayEnd else { continue }
            let c = UNMutableNotificationContent()
            c.title = isWeek ? "Неделя закрыта! 🎆" : "Пары всё! 🎉"
            c.body = isWeek ? "Свободен до понедельника — открой, там салют в твою честь"
                            : "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть"
            c.sound = .default
            let fire = last.end.addingTimeInterval(20)
            let comps = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fire)
            center.add(UNNotificationRequest(identifier: "fx.end.\(i)", content: c,
                                             trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
        }
    }

    static func taskDone(title: String, left: Int) {
        guard on, tasks else { return }
        CelebrationCenter.shared.fire(Celebration(title: left == 0 ? "Все задачи сделаны!" : "Готово",
                                                  subtitle: left == 0 ? "Ни одного хвоста — красота" : "«\(title)» закрыта",
                                                  style: .confetti, symbol: "checkmark",
                                                  meta: left == 0 ? nil : "ещё \(left)"))
    }

    static func examPassed(subject: String, grade: String) {
        guard on, exams else { return }
        CelebrationCenter.shared.fire(Celebration(title: "Сдано!",
                                                  subtitle: subject,
                                                  style: .emoji(["🎓", "🎉", "⭐️", "🔥"]), symbol: "graduationcap.fill",
                                                  meta: grade))
    }

    static func test() {
        CelebrationCenter.shared.fire(Celebration(title: "Вот так это выглядит",
                                                  subtitle: "Салют на месте, плашка растёт из островка",
                                                  style: .fireworks(big: true)))
    }

    // MARK: день рождения

    static var birthdayDate: Date? {
        let v = d.double(forKey: "user.birthday")
        return v == 0 ? nil : Date(timeIntervalSince1970: v)
    }

    private static func isBirthday(_ now: Date) -> Bool {
        guard let b = birthdayDate else { return false }
        let cal = Calendar.current
        return cal.component(.day, from: b) == cal.component(.day, from: now)
            && cal.component(.month, from: b) == cal.component(.month, from: now)
    }

    private static func pairsWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "пара" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "пары" }
        return "пар"
    }
}

// MARK: - Праздники

struct Holiday {
    let id: String
    let month: Int
    let day: Int
    let title: String
    let subtitle: String
    let style: Celebration.Style

    static let all: [Holiday] = [
        Holiday(id: "ny", month: 1, day: 1, title: "С Новым годом! 🎄", subtitle: "Пусть сессия сдастся сама",
                style: .emoji(["🎄", "❄️", "✨", "🎆"])),
        Holiday(id: "xmas", month: 1, day: 7, title: "С Рождеством! ⭐️", subtitle: "Тепла и уюта", style: .emoji(["⭐️", "❄️", "🕯️"])),
        Holiday(id: "tatiana", month: 1, day: 25, title: "С Днём студента! 🎓", subtitle: "Татьянин день — это твой праздник",
                style: .emoji(["🎓", "📚", "🎉", "✨"])),
        Holiday(id: "feb23", month: 2, day: 23, title: "С 23 Февраля! 🎖️", subtitle: "Сил и стойкости", style: .emoji(["🎖️", "⭐️"])),
        Holiday(id: "mar8", month: 3, day: 8, title: "С 8 Марта! 💐", subtitle: "Весны и хорошего настроения",
                style: .emoji(["💐", "🌷", "🌸", "✨"])),
        Holiday(id: "cosmos", month: 4, day: 12, title: "С Днём космонавтики! 🚀", subtitle: "Поехали!", style: .emoji(["🚀", "🪐", "⭐️"])),
        Holiday(id: "may1", month: 5, day: 1, title: "С Первомаем! 🌷", subtitle: "Весна, труд и отдых", style: .emoji(["🌷", "🌼", "☀️"])),
        Holiday(id: "may9", month: 5, day: 9, title: "С Днём Победы", subtitle: "Помним", style: .emoji(["🕊️", "🌷"])),
        Holiday(id: "jun12", month: 6, day: 12, title: "С Днём России!", subtitle: "Хороших выходных", style: .confetti),
        Holiday(id: "sep1", month: 9, day: 1, title: "С Днём знаний! 📚", subtitle: "Новый семестр — новый уровень",
                style: .emoji(["📚", "✏️", "🎓", "🍁"])),
        Holiday(id: "prog", month: 9, day: 13, title: "С Днём программиста! 💻", subtitle: "256-й день года — свой праздник",
                style: .emoji(["💻", "⌨️", "🐛", "✨"])),
        Holiday(id: "nov4", month: 11, day: 4, title: "С Днём народного единства!", subtitle: "Отдыхай", style: .confetti),
        Holiday(id: "students", month: 11, day: 17, title: "С Международным днём студента! 🎓", subtitle: "Учёба подождёт пять минут",
                style: .emoji(["🎓", "🎉", "📚"])),
        Holiday(id: "security", month: 11, day: 30, title: "С Днём защиты информации! 🔐", subtitle: "Твой профессиональный праздник",
                style: .emoji(["🔐", "🛡️", "💾", "✨"])),
        Holiday(id: "nye", month: 12, day: 31, title: "Последний день года! 🎆", subtitle: "Ты хорошо поработал", style: .emoji(["🎆", "🎄", "✨", "🥂"])),
    ]

    static func today(_ now: Date) -> Holiday? {
        let cal = Calendar.current
        let m = cal.component(.month, from: now), dd = cal.component(.day, from: now)
        // День программиста — 256-й день года (12 сентября в високосный)
        let progDay = cal.range(of: .day, in: .year, for: now)?.count == 366 ? 12 : 13
        return all.first { h in
            if h.id == "prog" { return m == 9 && dd == progDay }
            return h.month == m && h.day == dd
        }
    }
}

// MARK: - Отрисовка

struct CelebrationOverlay: View {
    @ObservedObject private var center = CelebrationCenter.shared

    var body: some View {
        ZStack {
            if let c = center.current {
                if case .fireworks(let big) = c.style {
                    // лёгкое затемнение, чтобы салют было видно и в светлой теме
                    Color.black.opacity(0.35)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                    FireworksEmitter(big: big)
                        .id(c.id)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                } else {
                    ConfettiEmitter(style: c.style)
                        .id("confetti-\(c.id)")
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                }
                IslandToast(c: c)
                    .id("toast-\(c.id)")
                    .transition(.opacity)
            }
        }
    }
}

/// Плашка поздравления вырастает из Dynamic Island (на iPhone без островка — из маленькой капсулы под вырезом),
/// а перед исчезновением сворачивается обратно. Чёрная, как сам островок, поэтому одинаково смотрится в обеих темах.
private struct IslandToast: View {
    let c: Celebration
    @ObservedObject private var center = CelebrationCenter.shared
    @State private var open = false

    private static let gold = Color(red: 1.0, green: 0.81, blue: 0.35)

    var body: some View {
        let safeTop = FXLayer.safeTop
        let island = safeTop >= 51
        let closed = island ? CGSize(width: 126, height: 37) : CGSize(width: 150, height: 34)
        let top: CGFloat = island ? 11 : safeTop + 4
        let radius: CGFloat = open ? 34 : closed.height / 2
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)

        GeometryReader { g in
            VStack(spacing: 0) {
                ZStack {
                    shape.fill(Color.black)
                    shape.strokeBorder(Color.white.opacity(open ? 0.1 : 0), lineWidth: 0.6)
                    content
                        .opacity(open ? 1 : 0)
                        .scaleEffect(open ? 1 : 0.86)
                }
                .frame(width: open ? min(g.size.width - 16, 420) : closed.width,
                       height: open ? 80 : closed.height)
                .clipShape(shape)
                .shadow(color: .black.opacity(open ? 0.35 : 0), radius: 22, y: 10)
                .background(
                    GeometryReader { r in
                        Color.clear
                            .onAppear { center.toastRect = r.frame(in: .global) }
                            .onChange(of: r.frame(in: .global)) { _, f in center.toastRect = f }
                    }
                )
                .contentShape(shape)
                .onTapGesture { close() }
                .gesture(DragGesture(minimumDistance: 8).onEnded { v in
                    if v.translation.height < -16 { close() }
                })
                .accessibilityElement(children: .combine)
                .accessibilityAddTraits(.isButton)
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, top)
        }
        .ignoresSafeArea()
        .onAppear {
            // пауза на кадр — чтобы капсула успела встать на место островка и выросла из него
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.72)) { open = true }
            }
        }
        // сворачивается в островок чуть раньше, чем поздравление уйдёт совсем;
        // и своя страховка: уходит само, даже если окно было перекрыто другим экраном
        .task(id: c.id) {
            try? await Task.sleep(nanoseconds: UInt64(max(0.5, c.duration - 0.45) * 1_000_000_000))
            guard center.current?.id == c.id else { return }
            close()
        }
    }

    private var content: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(LinearGradient(colors: c.tint, startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: c.icon)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(.white)
            }
            .frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 2) {
                Text(c.title)
                    .font(.system(size: 16, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                Text(c.subtitle)
                    .font(.system(size: 12.5))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
            }
            Spacer(minLength: 4)
            if let meta = c.meta {
                Text(meta)
                    .font(.system(size: 11.5, weight: .bold, design: .rounded).monospacedDigit())
                    .foregroundStyle(Self.gold)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .fixedSize()
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(Self.gold.opacity(0.14), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            }
        }
        .padding(.leading, 16)
        .padding(.trailing, 18)
    }

    private func close() {
        guard open else { return }
        withAnimation(.spring(response: 0.38, dampingFraction: 0.86)) { open = false }
        let id = c.id
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if center.current?.id == id { withAnimation(.easeOut(duration: 0.2)) { center.current = nil } }
        }
    }
}

/// Взрыв конфетти (или эмодзи) снизу экрана: частицы взлетают веером, кувыркаются и падают.
/// Рисует Core Animation (CAEmitterLayer) — это дёшево и одинаково работает на всех iOS,
/// а SwiftUI во время полёта ничего не пересчитывает.
private struct ConfettiEmitter: UIViewRepresentable {
    let style: Celebration.Style

    func makeUIView(context: Context) -> ConfettiEmitterView { ConfettiEmitterView(style: style) }
    func updateUIView(_ v: ConfettiEmitterView, context: Context) {}
}

final class ConfettiEmitterView: UIView {
    private let emitter = CAEmitterLayer()
    private let style: Celebration.Style
    private var fired = false

    private static let colors: [UIColor] = [
        UIColor(red: 1.00, green: 0.36, blue: 0.36, alpha: 1), UIColor(red: 1.00, green: 0.75, blue: 0.20, alpha: 1),
        UIColor(red: 0.30, green: 0.80, blue: 0.45, alpha: 1), UIColor(red: 0.25, green: 0.60, blue: 1.00, alpha: 1),
        UIColor(red: 0.70, green: 0.40, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.45, blue: 0.75, alpha: 1),
    ]

    init(style: Celebration.Style) {
        self.style = style
        super.init(frame: .zero)
        isUserInteractionEnabled = false
        backgroundColor = .clear
        layer.addSublayer(emitter)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        emitter.frame = bounds
        emitter.emitterShape = .line
        emitter.emitterPosition = CGPoint(x: bounds.midX, y: bounds.maxY + 16)
        emitter.emitterSize = CGSize(width: bounds.width * 0.85, height: 1)
        if !fired && bounds.width > 10 && bounds.height > 10 {
            fired = true
            fire()
        }
    }

    private func fire() {
        guard !UIAccessibility.isReduceMotionEnabled else { return }
        let h = max(bounds.height, 500)
        emitter.renderMode = .unordered
        // без этого слой «досчитывает» частицы из прошлого и первая волна появляется уже в воздухе
        emitter.beginTime = CACurrentMediaTime()
        emitter.birthRate = 1
        emitter.emitterCells = cells(height: h)
        // залп: частицы рождаются полсекунды, потом только летят
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { [weak self] in self?.emitter.birthRate = 0 }
    }

    private func cells(height h: CGFloat) -> [CAEmitterCell] {
        // скорость подобрана так, чтобы средние долетали до верхней четверти экрана: h ≈ v² / 2g.
        // Тяготение слабее, чем было, — конфетти висит в воздухе около 3,5 с, а не улетает за 2
        let gravity = h * 0.5
        let speed = sqrt(2 * gravity * h * 0.78)
        func base(_ img: UIImage, rate: Float) -> CAEmitterCell {
            let c = CAEmitterCell()
            c.contents = img.cgImage
            c.birthRate = rate
            c.lifetime = 6
            c.velocity = speed
            c.velocityRange = speed * 0.16
            c.emissionLongitude = -.pi / 2
            c.emissionRange = .pi / 5
            c.yAcceleration = gravity
            c.spin = 0
            c.spinRange = 9
            c.alphaSpeed = -0.1
            return c
        }
        if case .emoji(let list) = style, !list.isEmpty {
            return list.compactMap { e -> CAEmitterCell? in
                guard let img = Self.emojiImage(e) else { return nil }
                let c = base(img, rate: Float(max(110 / list.count, 12)))
                c.contentsScale = img.scale
                c.scale = 1
                c.scaleRange = 0.35
                c.spinRange = 4
                return c
            }
        }
        var out: [CAEmitterCell] = []
        for (i, color) in Self.colors.enumerated() {
            for shape in 0..<3 {
                let img = Self.piece(color, shape: shape)
                let c = base(img, rate: 16)
                c.contentsScale = img.scale
                c.scale = 1
                c.scaleRange = 0.4
                // у каждой бумажки свой темп кувырка
                c.spin = CGFloat((i + shape) % 2 == 0 ? 2.5 : -2.5)
                out.append(c)
            }
        }
        return out
    }

    /// Бумажка конфетти: прямоугольник, полоска или кружок
    private static func piece(_ color: UIColor, shape: Int) -> UIImage {
        let size: CGSize = shape == 0 ? CGSize(width: 11, height: 6) : shape == 1 ? CGSize(width: 7, height: 12) : CGSize(width: 8, height: 8)
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        return UIGraphicsImageRenderer(size: size, format: f).image { ctx in
            color.setFill()
            let r = CGRect(origin: .zero, size: size)
            if shape == 2 {
                ctx.cgContext.fillEllipse(in: r)
            } else {
                UIBezierPath(roundedRect: r, cornerRadius: 1.5).fill()
            }
        }
    }

    private static func emojiImage(_ e: String) -> UIImage? {
        let font = UIFont.systemFont(ofSize: 28)
        let str = NSAttributedString(string: e, attributes: [.font: font])
        let size = str.size()
        guard size.width > 0, size.height > 0 else { return nil }
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        return UIGraphicsImageRenderer(size: size, format: f).image { _ in str.draw(at: .zero) }
    }
}

/// Салют: ракеты со светящимся хвостом взлетают, замедляются и разрываются шаром искр с золотым дождём.
/// Всё рисует рендер-сервер iOS: ракета — частица CAEmitterLayer, которая в конце жизни сама рождает вспышку,
/// искры и блёстки (вложенные CAEmitterCell). Процессор кадры не считает, поэтому салют не тормозит приложение.
/// Время отсчитывается с момента показа, а не с момента события: после Face ID салют не «отгорает» за кадром.
private struct FireworksEmitter: UIViewRepresentable {
    let big: Bool

    func makeUIView(context: Context) -> FireworksEmitterView { FireworksEmitterView(big: big) }
    func updateUIView(_ v: FireworksEmitterView, context: Context) {}
}

final class FireworksEmitterView: UIView {
    private let emitter = CAEmitterLayer()
    private let big: Bool
    private var fired = false

    /// Цвет шара и цвет искр поярче
    private static let palette: [(UIColor, UIColor)] = [
        (UIColor(red: 1.00, green: 0.35, blue: 0.40, alpha: 1), UIColor(red: 1.00, green: 0.85, blue: 0.60, alpha: 1)),
        (UIColor(red: 1.00, green: 0.80, blue: 0.25, alpha: 1), .white),
        (UIColor(red: 0.35, green: 0.85, blue: 1.00, alpha: 1), UIColor(red: 0.80, green: 0.95, blue: 1.00, alpha: 1)),
        (UIColor(red: 0.50, green: 1.00, blue: 0.55, alpha: 1), UIColor(red: 0.90, green: 1.00, blue: 0.75, alpha: 1)),
        (UIColor(red: 0.80, green: 0.45, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.78, blue: 1.00, alpha: 1)),
        (UIColor(red: 1.00, green: 0.50, blue: 0.80, alpha: 1), .white),
    ]
    private static let gold = UIColor(red: 1.00, green: 0.82, blue: 0.45, alpha: 1)

    private static let dot = glowImage(size: 12, core: 0.35)
    private static let flash = glowImage(size: 64, core: 0.05)

    init(big: Bool) {
        self.big = big
        super.init(frame: .zero)
        isUserInteractionEnabled = false
        backgroundColor = .clear
        layer.addSublayer(emitter)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        emitter.frame = bounds
        emitter.emitterShape = .line
        emitter.emitterPosition = CGPoint(x: bounds.midX, y: bounds.maxY + 8)
        emitter.emitterSize = CGSize(width: bounds.width * 0.55, height: 1)
        if !fired && bounds.width > 10 && bounds.height > 10 {
            fired = true
            fire()
        }
    }

    private func fire() {
        guard !UIAccessibility.isReduceMotionEnabled else { return }
        let h = Double(bounds.height)
        emitter.renderMode = .additive      // вспышки складываются и светятся
        emitter.beginTime = CACurrentMediaTime()
        emitter.birthRate = 1
        let n = big ? 12 : 7
        let span = big ? 4.4 : 2.6
        // у каждой ракеты своя ячейка со своим временем старта — запуски идут ровно, без случайных пауз
        emitter.emitterCells = (0..<n).map { i -> CAEmitterCell in
            let launch = 0.1 + Double(i) / Double(n) * span + Double.random(in: 0...0.2)
            return rocket(launch: launch, colors: Self.palette[(i + Int.random(in: 0...5)) % Self.palette.count], h: h)
        }
    }

    private func rocket(launch: Double, colors: (UIColor, UIColor), h: Double) -> CAEmitterCell {
        // ракета замедляется и разрывается в верхней точке: d = g·T²/2, v = g·T
        let rise = Double.random(in: 0.95...1.2)
        let height = h * Double.random(in: 0.5...0.78)
        let g = 2 * height / (rise * rise)
        let r = CAEmitterCell()
        r.contents = Self.dot.cgImage
        r.beginTime = launch
        r.duration = 0.025
        r.birthRate = 50                    // ровно одна ракета за 0,025 с
        r.lifetime = Float(rise)
        r.velocity = CGFloat(g * rise)
        r.yAcceleration = CGFloat(g)
        r.emissionLongitude = -.pi / 2
        r.emissionRange = .pi / 22
        r.scale = 0.45
        r.color = UIColor.white.cgColor

        // хвост из искр за ракетой
        let trail = CAEmitterCell()
        trail.contents = Self.dot.cgImage
        trail.birthRate = 55
        trail.lifetime = 0.45
        trail.lifetimeRange = 0.15
        trail.velocity = 18
        trail.velocityRange = 10
        trail.emissionLongitude = .pi / 2
        trail.emissionRange = .pi / 5
        trail.scale = 0.28
        trail.scaleSpeed = -0.4
        trail.alphaSpeed = -2
        trail.color = Self.gold.cgColor

        // вспышка в момент разрыва
        let flash = CAEmitterCell()
        flash.contents = Self.flash.cgImage
        flash.beginTime = rise - 0.03
        flash.duration = 0.02
        flash.birthRate = 60
        flash.lifetime = 0.3
        flash.scale = big ? 1.5 : 1.2
        flash.scaleSpeed = -2.5
        flash.alphaSpeed = -3.2
        flash.color = colors.0.withAlphaComponent(0.85).cgColor

        // шар искр
        let sparks = CAEmitterCell()
        sparks.contents = Self.dot.cgImage
        sparks.beginTime = rise - 0.03
        sparks.duration = 0.05
        sparks.birthRate = big ? 2000 : 1600 // ≈ 100 / 80 искр
        sparks.lifetime = 1.7
        sparks.lifetimeRange = 0.5
        sparks.velocity = big ? 150 : 125
        sparks.velocityRange = 45
        sparks.emissionRange = 2 * .pi
        sparks.yAcceleration = 65
        sparks.scale = 0.42
        sparks.scaleRange = 0.12
        sparks.scaleSpeed = -0.15
        sparks.alphaSpeed = -0.55
        sparks.color = colors.0.cgColor
        sparks.redRange = 0.08
        sparks.greenRange = 0.08
        sparks.blueRange = 0.08

        // светлые искры поверх — шар не выглядит однотонным
        let bright = CAEmitterCell()
        bright.contents = Self.dot.cgImage
        bright.beginTime = rise - 0.03
        bright.duration = 0.05
        bright.birthRate = 500
        bright.lifetime = 1.2
        bright.lifetimeRange = 0.3
        bright.velocity = big ? 135 : 112
        bright.velocityRange = 30
        bright.emissionRange = 2 * .pi
        bright.yAcceleration = 60
        bright.scale = 0.3
        bright.scaleSpeed = -0.12
        bright.alphaSpeed = -0.8
        bright.color = colors.1.cgColor

        // золотой дождь: медленные блёстки, которые оседают после взрыва
        let glitter = CAEmitterCell()
        glitter.contents = Self.dot.cgImage
        glitter.beginTime = rise - 0.03
        glitter.duration = 0.06
        glitter.birthRate = 450
        glitter.lifetime = 2.4
        glitter.lifetimeRange = 0.6
        glitter.velocity = 55
        glitter.velocityRange = 30
        glitter.emissionRange = 2 * .pi
        glitter.yAcceleration = 45
        glitter.scale = 0.22
        glitter.scaleRange = 0.08
        glitter.alphaSpeed = -0.38
        glitter.color = Self.gold.cgColor

        r.emitterCells = [trail, flash, sparks, bright, glitter]
        return r
    }

    /// Светящаяся точка: яркая середина и мягкий край
    private static func glowImage(size: CGFloat, core: CGFloat) -> UIImage {
        let f = UIGraphicsImageRendererFormat()
        f.scale = 2
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: f).image { ctx in
            let colors = [UIColor.white.cgColor, UIColor.white.withAlphaComponent(0.8).cgColor, UIColor.white.withAlphaComponent(0).cgColor] as CFArray
            guard let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, core, 1]) else { return }
            let c = CGPoint(x: size / 2, y: size / 2)
            ctx.cgContext.drawRadialGradient(grad, startCenter: c, startRadius: 0, endCenter: c, endRadius: size / 2, options: [])
        }
    }
}

// MARK: - Настройки

struct CelebrationSettingsView: View {
    @AppStorage("fx.on") private var on = true
    @AppStorage("fx.dayEnd") private var dayEnd = true
    @AppStorage("fx.weekEnd") private var weekEnd = true
    @AppStorage("fx.tasks") private var tasks = true
    @AppStorage("fx.exams") private var exams = true
    @AppStorage("fx.holidays") private var holidays = true
    @AppStorage("fx.birthday") private var birthday = true
    @AppStorage("user.birthday") private var birthdayTS: Double = 0

    private var bdayBinding: Binding<Date> {
        Binding(get: { birthdayTS == 0 ? Calendar.current.date(from: DateComponents(year: 2007, month: 1, day: 1)) ?? Date()
                                       : Date(timeIntervalSince1970: birthdayTS) },
                set: { birthdayTS = $0.timeIntervalSince1970 })
    }

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $on) { Label("Праздничные анимации", systemImage: "party.popper.fill") }
                if on {
                    Button {
                        Celebrations.test()
                    } label: {
                        Label("Показать сейчас", systemImage: "sparkles")
                    }
                }
            } footer: {
                Text("Конфетти и короткое поздравление внизу экрана. Не мешает: пропадает само через пару секунд, тап — сразу.")
            }
            if on {
                Section("Когда") {
                    Toggle("Закончились пары на сегодня", isOn: $dayEnd)
                    Toggle("Закончилась учебная неделя", isOn: $weekEnd)
                    Toggle("Выполнил задачу", isOn: $tasks)
                    Toggle("Сдал экзамен или зачёт", isOn: $exams)
                    Toggle("Праздники", isOn: $holidays)
                    Toggle("День рождения", isOn: $birthday)
                    if birthday {
                        DatePicker("Дата рождения", selection: bdayBinding, displayedComponents: .date)
                    }
                }
                Section {
                    ForEach(Holiday.all, id: \.id) { h in
                        HStack {
                            Text(h.title).font(.subheadline)
                            Spacer()
                            Text("\(h.day).\(String(format: "%02d", h.month))")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text("Какие праздники")
                } footer: {
                    Text("Среди них — День студента, День программиста и 30 ноября — День защиты информации.")
                }
            }
        }
        .navigationTitle("Праздники")
    }
}
