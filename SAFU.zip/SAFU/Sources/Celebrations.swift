import SwiftUI
import UIKit
import UserNotifications

// MARK: - Праздники и анимации
// Конфетти и поздравления: конец пар, конец недели, выполненная задача, сданный экзамен,
// праздники и день рождения. Каждый повод включается отдельно.

struct Celebration: Identifiable, Equatable {
    /// fireworks — салют из ракет + конфетти; big — длинный салют на конец недели
    enum Style: Equatable { case confetti, emoji([String]), fireworks(big: Bool) }
    let id = UUID()
    let created = Date()
    let title: String
    let subtitle: String
    let style: Style
    /// Пасхалки и игра показываются, даже если праздничные анимации выключены
    var force: Bool = false

    /// Сколько висит на экране
    var duration: Double {
        if case .fireworks(let big) = style { return big ? 7.5 : 6 }
        return 4.2
    }
}

final class CelebrationCenter: ObservableObject {
    static let shared = CelebrationCenter()
    @Published var current: Celebration? {
        didSet {
            if current == nil {
                toastRect = .zero
                FXLayer.hideSoon()
            }
        }
    }
    /// Где на экране плашка с поздравлением — только по ней можно нажать, остальное проходит в приложение
    var toastRect: CGRect = .zero

    func fire(_ c: Celebration) {
        guard Celebrations.on || c.force else { return }
        DispatchQueue.main.async {
            // приложение закрыто Face ID — салют дождётся, пока его откроют (раньше он отыгрывал под замком)
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: 0)
                return
            }
            FXLayer.show()
            Haptics.success()
            withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) { self.current = c }
            let id = c.id
            // на салюте — ещё пара «хлопков» вибрацией
            if case .fireworks = c.style {
                for delay in [0.9, 1.6, 2.4] {
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                        UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.8)
                    }
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + c.duration) {
                if self.current?.id == id {
                    withAnimation(.easeOut(duration: 0.4)) { self.current = nil }
                }
            }
        }
    }

    private func waitForUnlock(_ c: Celebration, tries: Int) {
        guard tries < 120 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            if AppLock.shared.isLocked {
                self.waitForUnlock(c, tries: tries + 1)
            } else {
                // после Face ID — короткая пауза, пока замок растворяется
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self.fire(c) }
            }
        }
    }
}

// MARK: - Своё окно поверх всего

/// Салют и конфетти живут в отдельном прозрачном окне над приложением, листами, полноэкранными окнами
/// и карточками сайтов. Раньше они рисовались в главном экране и оставались под открытым листом
/// или карточкой — поэтому «пропадали». Нажать можно только на плашку поздравления.
final class FXWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let r = CelebrationCenter.shared.toastRect
        guard r.width > 0, r.insetBy(dx: -6, dy: -6).contains(point) else { return nil }
        return super.hitTest(point, with: event)
    }
}

enum FXLayer {
    private static var window: FXWindow?
    private static var hideWork: DispatchWorkItem?
    private static var observer: NSObjectProtocol?

    static func show() {
        hideWork?.cancel()
        hideWork = nil
        if window == nil {
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first else { return }
            let host = UIHostingController(rootView: FXRoot())
            host.view.backgroundColor = .clear
            let w = FXWindow(windowScene: scene)
            // выше листов и карточек сайтов (они на .normal + 1), ниже замка Face ID
            w.windowLevel = .normal + 5
            w.backgroundColor = .clear
            w.rootViewController = host
            window = w
            // ушли из приложения — поздравление не висит поверх шторки приватности
            observer = NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                                              object: nil, queue: .main) { _ in
                CelebrationCenter.shared.current = nil
                window?.isHidden = true
            }
        }
        window?.isHidden = false
    }

    /// Окно прячется, когда поздравление доиграло исчезновение
    static func hideSoon() {
        hideWork?.cancel()
        let work = DispatchWorkItem {
            guard CelebrationCenter.shared.current == nil else { return }
            window?.isHidden = true
        }
        hideWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6, execute: work)
    }
}

private struct FXRoot: View {
    var body: some View {
        CelebrationOverlay()
            .modifier(AppearanceRoot())
    }
}

enum Celebrations {
    private static var d: UserDefaults { .standard }
    private static func flag(_ k: String, _ def: Bool = true) -> Bool { d.object(forKey: k) as? Bool ?? def }

    static var on: Bool { flag("fx.on") }
    static var dayEnd: Bool { flag("fx.dayEnd") }
    static var weekEnd: Bool { flag("fx.weekEnd") }
    static var tasks: Bool { flag("fx.tasks") }
    static var exams: Bool { flag("fx.exams") }
    static var holidays: Bool { flag("fx.holidays") }
    static var birthday: Bool { flag("fx.birthday") }

    // MARK: разово за день

    private static func dayKey(_ date: Date = Date()) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }

    private static func once(_ id: String) -> Bool {
        let k = "fx.shown.\(id).\(dayKey())"
        if d.bool(forKey: k) { return false }
        d.set(true, forKey: k)
        return true
    }

    // MARK: поводы

    /// Проверка при открытии приложения
    static func checkOnOpen(data: ScheduleData) {
        guard on else { return }
        let now = Date()
        if birthday, isBirthday(now), once("bday") {
            let name = (d.string(forKey: "user.name") ?? "").split(separator: " ").first.map(String.init) ?? ""
            CelebrationCenter.shared.fire(Celebration(title: "С днём рождения\(name.isEmpty ? "" : ", \(name)")! 🎂",
                                                      subtitle: "Пусть все дедлайны будут далеко, а автоматы — близко",
                                                      style: .emoji(["🎂", "🎉", "🎈", "✨"])))
            return
        }
        if holidays, let h = Holiday.today(now), once("hol-\(h.id)") {
            CelebrationCenter.shared.fire(Celebration(title: h.title, subtitle: h.subtitle, style: h.style))
            return
        }
        // конец пар / недели
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let slots = ScheduleEngine.slots(on: today, data: data)
        guard let last = slots.last, now >= last.end, now < last.end.addingTimeInterval(6 * 3600) else { return }
        let restOfWeekEmpty = weekDone(after: today, data: data)
        if weekEnd, restOfWeekEmpty, once("week") {
            CelebrationCenter.shared.fire(Celebration(title: "Неделя закрыта! 🎆",
                                                      subtitle: "Салют в твою честь — свободен до понедельника",
                                                      style: .fireworks(big: true)))
        } else if dayEnd, !restOfWeekEmpty, once("day") {
            CelebrationCenter.shared.fire(Celebration(title: "Пары всё! 🎉",
                                                      subtitle: "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть",
                                                      style: .fireworks(big: false)))
        }
    }

    /// После этого дня до конца недели пар больше нет?
    static func weekDone(after day: Date, data: ScheduleData) -> Bool {
        let cal = Calendar.current
        let wd = ScheduleEngine.weekday(of: day)
        guard wd < 7 else { return true }
        for i in 1...(7 - wd) {
            if let next = cal.date(byAdding: .day, value: i, to: cal.startOfDay(for: day)),
               !ScheduleEngine.slots(on: next, data: data).isEmpty { return false }
        }
        return true
    }

    /// Конец сегодняшней последней пары, если он ещё впереди
    static func nextFinish(data: ScheduleData) -> Date? {
        let today = Calendar.current.startOfDay(for: Date())
        guard let last = ScheduleEngine.slots(on: today, data: data).last, last.end > Date() else { return nil }
        return last.end
    }

    /// «Пары всё!» и «Неделя закрыта!» уведомлением на 8 дней вперёд — придут, даже если приложение закрыто.
    /// Нажал — открывается приложение, и там салют.
    static func scheduleNotifications(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: (0..<8).map { "fx.end.\($0)" })
        guard on, dayEnd || weekEnd else { return }
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        for i in 0..<8 {
            guard let day = cal.date(byAdding: .day, value: i, to: today) else { continue }
            let slots = ScheduleEngine.slots(on: day, data: data)
            guard let last = slots.last, last.end > Date() else { continue }
            let isWeek = weekDone(after: day, data: data)
            guard isWeek ? weekEnd : dayEnd else { continue }
            let c = UNMutableNotificationContent()
            c.title = isWeek ? "Неделя закрыта! 🎆" : "Пары всё! 🎉"
            c.body = isWeek ? "Свободен до понедельника — открой, там салют в твою честь"
                            : "\(slots.count) \(pairsWord(slots.count)) позади. Можно выдохнуть"
            c.sound = .default
            let fire = last.end.addingTimeInterval(20)
            let comps = cal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: fire)
            center.add(UNNotificationRequest(identifier: "fx.end.\(i)", content: c,
                                             trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
        }
    }

    static func taskDone(title: String, left: Int) {
        guard on, tasks else { return }
        CelebrationCenter.shared.fire(Celebration(title: left == 0 ? "Все задачи сделаны! 🏆" : "Готово! ✅",
                                                  subtitle: left == 0 ? "Ни одного хвоста — красота" : "«\(title)» закрыта. Осталось \(left)",
                                                  style: .confetti))
    }

    static func examPassed(subject: String, grade: String) {
        guard on, exams else { return }
        CelebrationCenter.shared.fire(Celebration(title: "Сдано! 🎓",
                                                  subtitle: "\(subject) — \(grade)",
                                                  style: .emoji(["🎓", "🎉", "⭐️", "🔥"])))
    }

    static func test() {
        CelebrationCenter.shared.fire(Celebration(title: "Вот так это выглядит 🎆",
                                                  subtitle: "Салют и конфетти на месте",
                                                  style: .fireworks(big: true)))
    }

    // MARK: день рождения

    static var birthdayDate: Date? {
        let v = d.double(forKey: "user.birthday")
        return v == 0 ? nil : Date(timeIntervalSince1970: v)
    }

    private static func isBirthday(_ now: Date) -> Bool {
        guard let b = birthdayDate else { return false }
        let cal = Calendar.current
        return cal.component(.day, from: b) == cal.component(.day, from: now)
            && cal.component(.month, from: b) == cal.component(.month, from: now)
    }

    private static func pairsWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "пара" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "пары" }
        return "пар"
    }
}

// MARK: - Праздники

struct Holiday {
    let id: String
    let month: Int
    let day: Int
    let title: String
    let subtitle: String
    let style: Celebration.Style

    static let all: [Holiday] = [
        Holiday(id: "ny", month: 1, day: 1, title: "С Новым годом! 🎄", subtitle: "Пусть сессия сдастся сама",
                style: .emoji(["🎄", "❄️", "✨", "🎆"])),
        Holiday(id: "xmas", month: 1, day: 7, title: "С Рождеством! ⭐️", subtitle: "Тепла и уюта", style: .emoji(["⭐️", "❄️", "🕯️"])),
        Holiday(id: "tatiana", month: 1, day: 25, title: "С Днём студента! 🎓", subtitle: "Татьянин день — это твой праздник",
                style: .emoji(["🎓", "📚", "🎉", "✨"])),
        Holiday(id: "feb23", month: 2, day: 23, title: "С 23 Февраля! 🎖️", subtitle: "Сил и стойкости", style: .emoji(["🎖️", "⭐️"])),
        Holiday(id: "mar8", month: 3, day: 8, title: "С 8 Марта! 💐", subtitle: "Весны и хорошего настроения",
                style: .emoji(["💐", "🌷", "🌸", "✨"])),
        Holiday(id: "cosmos", month: 4, day: 12, title: "С Днём космонавтики! 🚀", subtitle: "Поехали!", style: .emoji(["🚀", "🪐", "⭐️"])),
        Holiday(id: "may1", month: 5, day: 1, title: "С Первомаем! 🌷", subtitle: "Весна, труд и отдых", style: .emoji(["🌷", "🌼", "☀️"])),
        Holiday(id: "may9", month: 5, day: 9, title: "С Днём Победы", subtitle: "Помним", style: .emoji(["🕊️", "🌷"])),
        Holiday(id: "jun12", month: 6, day: 12, title: "С Днём России!", subtitle: "Хороших выходных", style: .confetti),
        Holiday(id: "sep1", month: 9, day: 1, title: "С Днём знаний! 📚", subtitle: "Новый семестр — новый уровень",
                style: .emoji(["📚", "✏️", "🎓", "🍁"])),
        Holiday(id: "prog", month: 9, day: 13, title: "С Днём программиста! 💻", subtitle: "256-й день года — свой праздник",
                style: .emoji(["💻", "⌨️", "🐛", "✨"])),
        Holiday(id: "nov4", month: 11, day: 4, title: "С Днём народного единства!", subtitle: "Отдыхай", style: .confetti),
        Holiday(id: "students", month: 11, day: 17, title: "С Международным днём студента! 🎓", subtitle: "Учёба подождёт пять минут",
                style: .emoji(["🎓", "🎉", "📚"])),
        Holiday(id: "security", month: 11, day: 30, title: "С Днём защиты информации! 🔐", subtitle: "Твой профессиональный праздник",
                style: .emoji(["🔐", "🛡️", "💾", "✨"])),
        Holiday(id: "nye", month: 12, day: 31, title: "Последний день года! 🎆", subtitle: "Ты хорошо поработал", style: .emoji(["🎆", "🎄", "✨", "🥂"])),
    ]

    static func today(_ now: Date) -> Holiday? {
        let cal = Calendar.current
        let m = cal.component(.month, from: now), dd = cal.component(.day, from: now)
        // День программиста — 256-й день года (12 сентября в високосный)
        let progDay = cal.range(of: .day, in: .year, for: now)?.count == 366 ? 12 : 13
        return all.first { h in
            if h.id == "prog" { return m == 9 && dd == progDay }
            return h.month == m && h.day == dd
        }
    }
}

// MARK: - Отрисовка

struct CelebrationOverlay: View {
    @ObservedObject private var center = CelebrationCenter.shared

    var body: some View {
        ZStack {
            if let c = center.current {
                if case .fireworks(let big) = c.style {
                    // лёгкое затемнение, чтобы салют было видно и в светлой теме
                    Color.black.opacity(0.35)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                    FireworksShow(start: c.created, big: big)
                        .id(c.id)
                        .ignoresSafeArea()
                        .allowsHitTesting(false)
                        .transition(.opacity)
                }
                ConfettiEmitter(style: c.style)
                    .id("confetti-\(c.id)")
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .transition(.opacity)
                VStack {
                    Spacer()
                    VStack(spacing: 4) {
                        Text(c.title)
                            .font(.system(.title3, design: .rounded).weight(.heavy))
                            .multilineTextAlignment(.center)
                        Text(c.subtitle)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.horizontal, 22)
                    .padding(.vertical, 16)
                    .frame(maxWidth: 340)
                    .glass(26)
                    .shadow(color: .black.opacity(0.15), radius: 18, y: 8)
                    .background(
                        GeometryReader { g in
                            Color.clear
                                .onAppear { center.toastRect = g.frame(in: .global) }
                                .onChange(of: g.frame(in: .global)) { _, r in center.toastRect = r }
                        }
                    )
                    .onTapGesture { withAnimation { center.current = nil } }
                    .padding(.bottom, 110)
                    // своя страховка: поздравление уходит само, даже если окно было перекрыто другим экраном
                    .task(id: c.id) {
                        try? await Task.sleep(nanoseconds: UInt64((c.duration + 0.3) * 1_000_000_000))
                        if center.current?.id == c.id { withAnimation(.easeOut(duration: 0.4)) { center.current = nil } }
                    }
                    .transition(.move(edge: .bottom).combined(with: .opacity).combined(with: .scale(scale: 0.9)))
                }
            }
        }
    }
}

/// Взрыв конфетти (или эмодзи) снизу экрана: частицы взлетают веером, кувыркаются и падают.
/// Рисует Core Animation (CAEmitterLayer) — это дёшево и одинаково работает на всех iOS,
/// а SwiftUI во время полёта ничего не пересчитывает.
private struct ConfettiEmitter: UIViewRepresentable {
    let style: Celebration.Style

    func makeUIView(context: Context) -> ConfettiEmitterView { ConfettiEmitterView(style: style) }
    func updateUIView(_ v: ConfettiEmitterView, context: Context) {}
}

final class ConfettiEmitterView: UIView {
    private let emitter = CAEmitterLayer()
    private let style: Celebration.Style
    private var fired = false

    private static let colors: [UIColor] = [
        UIColor(red: 1.00, green: 0.36, blue: 0.36, alpha: 1), UIColor(red: 1.00, green: 0.75, blue: 0.20, alpha: 1),
        UIColor(red: 0.30, green: 0.80, blue: 0.45, alpha: 1), UIColor(red: 0.25, green: 0.60, blue: 1.00, alpha: 1),
        UIColor(red: 0.70, green: 0.40, blue: 1.00, alpha: 1), UIColor(red: 1.00, green: 0.45, blue: 0.75, alpha: 1),
    ]

    init(style: Celebration.Style) {
        self.style = style
        super.init(frame: .zero)
        isUserInteractionEnabled = false
        backgroundColor = .clear
        layer.addSublayer(emitter)
    }

    required init?(coder: NSCoder) { fatalError() }

    override func layoutSubviews() {
        super.layoutSubviews()
        emitter.frame = bounds
        emitter.emitterShape = .line
        emitter.emitterPosition = CGPoint(x: bounds.midX, y: bounds.maxY + 16)
        emitter.emitterSize = CGSize(width: bounds.width * 0.85, height: 1)
        if !fired && bounds.width > 10 && bounds.height > 10 {
            fired = true
            fire()
        }
    }

    private func fire() {
        guard !UIAccessibility.isReduceMotionEnabled else { return }
        let h = max(bounds.height, 500)
        emitter.renderMode = .unordered
        // без этого слой «досчитывает» частицы из прошлого и первая волна появляется уже в воздухе
        emitter.beginTime = CACurrentMediaTime()
        emitter.birthRate = 1
        emitter.emitterCells = cells(height: h)
        // короткий залп: частицы рождаются 0,3 секунды, потом только летят
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in self?.emitter.birthRate = 0 }
    }

    private func cells(height h: CGFloat) -> [CAEmitterCell] {
        // скорость подобрана так, чтобы верхние долетали почти до верха экрана: h ≈ v² / 2g
        let gravity = h * 0.95
        let speed = sqrt(2 * gravity * h * 0.85)
        func base(_ img: UIImage, rate: Float) -> CAEmitterCell {
            let c = CAEmitterCell()
            c.contents = img.cgImage
            c.birthRate = rate
            c.lifetime = 5.5
            c.velocity = speed
            c.velocityRange = speed * 0.3
            c.emissionLongitude = -.pi / 2
            c.emissionRange = .pi / 6.5
            c.yAcceleration = gravity
            c.spin = 0
            c.spinRange = 9
            c.alphaSpeed = -0.12
            return c
        }
        if case .emoji(let list) = style, !list.isEmpty {
            return list.compactMap { e -> CAEmitterCell? in
                guard let img = Self.emojiImage(e) else { return nil }
                let c = base(img, rate: Float(max(110 / list.count, 12)))
                c.contentsScale = img.scale
                c.scale = 1
                c.scaleRange = 0.35
                c.spinRange = 4
                return c
            }
        }
        var out: [CAEmitterCell] = []
        for (i, color) in Self.colors.enumerated() {
            for shape in 0..<3 {
                let img = Self.piece(color, shape: shape)
                let c = base(img, rate: 22)
                c.contentsScale = img.scale
                c.scale = 1
                c.scaleRange = 0.4
                // у каждой бумажки свой темп кувырка
                c.spin = CGFloat((i + shape) % 2 == 0 ? 2.5 : -2.5)
                out.append(c)
            }
        }
        return out
    }

    /// Бумажка конфетти: прямоугольник, полоска или кружок
    private static func piece(_ color: UIColor, shape: Int) -> UIImage {
        let size: CGSize = shape == 0 ? CGSize(width: 11, height: 6) : shape == 1 ? CGSize(width: 7, height: 12) : CGSize(width: 8, height: 8)
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        return UIGraphicsImageRenderer(size: size, format: f).image { ctx in
            color.setFill()
            let r = CGRect(origin: .zero, size: size)
            if shape == 2 {
                ctx.cgContext.fillEllipse(in: r)
            } else {
                UIBezierPath(roundedRect: r, cornerRadius: 1.5).fill()
            }
        }
    }

    private static func emojiImage(_ e: String) -> UIImage? {
        let font = UIFont.systemFont(ofSize: 28)
        let str = NSAttributedString(string: e, attributes: [.font: font])
        let size = str.size()
        guard size.width > 0, size.height > 0 else { return nil }
        let f = UIGraphicsImageRendererFormat()
        f.scale = 3
        return UIGraphicsImageRenderer(size: size, format: f).image { _ in str.draw(at: .zero) }
    }
}

/// Салют: ракеты со светящимся хвостом взлетают и разрываются шарами искр, которые оседают и гаснут
private struct FireworksShow: View {
    let start: Date
    let big: Bool

    private struct Rocket {
        let launch: Double     // когда стартует, с
        let x: Double          // откуда (доля ширины)
        let tx: Double         // где взрывается (доли экрана)
        let ty: Double
        let hue: Int
        let count: Int
        let ring: Bool         // кольцо или шар
    }

    private static let palette: [(Color, Color)] = [
        (Color(red: 1.00, green: 0.35, blue: 0.35), Color(red: 1.00, green: 0.85, blue: 0.55)),
        (Color(red: 1.00, green: 0.80, blue: 0.25), Color.white),
        (Color(red: 0.35, green: 0.85, blue: 1.00), Color(red: 0.80, green: 0.95, blue: 1.00)),
        (Color(red: 0.55, green: 1.00, blue: 0.45), Color(red: 0.95, green: 1.00, blue: 0.70)),
        (Color(red: 0.85, green: 0.45, blue: 1.00), Color(red: 1.00, green: 0.75, blue: 1.00)),
        (Color(red: 1.00, green: 0.55, blue: 0.80), Color.white),
    ]

    @State private var rockets: [Rocket] = []
    @State private var done = false

    private static func make(big: Bool) -> [Rocket] {
        var g = SystemRandomNumberGenerator()
        func r(_ a: Double, _ b: Double) -> Double { Double.random(in: a...b, using: &g) }
        let n = big ? 11 : 6
        let span = big ? 4.6 : 3.0
        return (0..<n).map { i in
            Rocket(launch: Double(i) / Double(n) * span + r(0, 0.25),
                   x: r(0.15, 0.85), tx: r(0.15, 0.85), ty: r(0.14, 0.42),
                   hue: Int(r(0, 5.99)), count: Int(r(34, 54)), ring: r(0, 1) < 0.3)
        }
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: nil, paused: done)) { ctx in
            let t = ctx.date.timeIntervalSince(start)
            Canvas { g, size in
                g.blendMode = .plusLighter      // вспышки складываются и светятся
                let w = Double(size.width), h = Double(size.height)
                for (i, rk) in rockets.enumerated() {
                    let lt = t - rk.launch
                    guard lt > 0 else { continue }
                    let rise = 0.85
                    let colors = Self.palette[rk.hue % Self.palette.count]
                    let sx = rk.x * w, sy = h + 10
                    let ex = rk.tx * w, ey = rk.ty * h
                    if lt < rise {
                        // взлёт с замедлением и хвостом из искр
                        let p = 1 - pow(1 - lt / rise, 2)
                        let x = sx + (ex - sx) * p, y = sy + (ey - sy) * p
                        for k in 0..<7 {
                            let back = Double(k) * 0.035
                            let pp = max(0, 1 - pow(1 - max(0, lt - back) / rise, 2))
                            let tx = sx + (ex - sx) * pp, ty = sy + (ey - sy) * pp
                            let rr = 2.4 - Double(k) * 0.28
                            g.fill(Path(ellipseIn: CGRect(x: tx - rr, y: ty - rr, width: rr * 2, height: rr * 2)),
                                   with: .color(colors.1.opacity(0.9 - Double(k) * 0.12)))
                        }
                        g.fill(Path(ellipseIn: CGRect(x: x - 3, y: y - 3, width: 6, height: 6)), with: .color(.white))
                        continue
                    }
                    // взрыв
                    let bt = lt - rise
                    let life = 1.9
                    guard bt < life else { continue }
                    let fade = max(0, 1 - bt / life)
                    // вспышка в момент разрыва
                    if bt < 0.18 {
                        let fr = 40 * (1 - bt / 0.18) + 10
                        g.fill(Path(ellipseIn: CGRect(x: ex - fr, y: ey - fr, width: fr * 2, height: fr * 2)),
                               with: .radialGradient(Gradient(colors: [Color.white.opacity(0.8), colors.0.opacity(0)]),
                                                     center: CGPoint(x: ex, y: ey), startRadius: 0, endRadius: fr))
                    }
                    let speed = (big ? 150.0 : 125.0) * (rk.ring ? 1.1 : 1.0)
                    // разлёт с торможением и лёгкой гравитацией
                    let dist = speed * (1 - exp(-2.6 * bt)) / 1.0
                    let fall = 38 * bt * bt
                    for j in 0..<rk.count {
                        let a = Double(j) / Double(rk.count) * 2 * .pi + Double(i) * 0.37
                        let jitter = rk.ring ? 1.0 : 0.55 + 0.45 * abs(sin(Double(j) * 12.9898 + Double(i)))
                        let px = ex + cos(a) * dist * jitter
                        let py = ey + sin(a) * dist * jitter + fall
                        // мерцание в конце
                        let twinkle = bt > life * 0.55 ? (0.5 + 0.5 * sin(bt * 40 + Double(j))) : 1
                        let rr = 1.9 * (0.6 + 0.4 * fade)
                        let col = (j % 3 == 0 ? colors.1 : colors.0).opacity(fade * twinkle)
                        g.fill(Path(ellipseIn: CGRect(x: px - rr, y: py - rr, width: rr * 2, height: rr * 2)), with: .color(col))
                        // короткий след искры
                        if bt < 0.9 {
                            var trail = Path()
                            trail.move(to: CGPoint(x: px, y: py))
                            trail.addLine(to: CGPoint(x: ex + cos(a) * dist * jitter * 0.82, y: ey + sin(a) * dist * jitter * 0.82 + fall * 0.8))
                            g.stroke(trail, with: .color(colors.0.opacity(0.35 * fade)), lineWidth: 1.1)
                        }
                    }
                }
            }
        }
        .onAppear { rockets = Self.make(big: big) }
        .task {
            // после последней ракеты кадры больше не считаем
            try? await Task.sleep(nanoseconds: UInt64(((big ? 4.85 : 3.25) + 0.85 + 1.9 + 0.2) * 1_000_000_000))
            done = true
        }
    }
}

// MARK: - Настройки

struct CelebrationSettingsView: View {
    @AppStorage("fx.on") private var on = true
    @AppStorage("fx.dayEnd") private var dayEnd = true
    @AppStorage("fx.weekEnd") private var weekEnd = true
    @AppStorage("fx.tasks") private var tasks = true
    @AppStorage("fx.exams") private var exams = true
    @AppStorage("fx.holidays") private var holidays = true
    @AppStorage("fx.birthday") private var birthday = true
    @AppStorage("user.birthday") private var birthdayTS: Double = 0

    private var bdayBinding: Binding<Date> {
        Binding(get: { birthdayTS == 0 ? Calendar.current.date(from: DateComponents(year: 2007, month: 1, day: 1)) ?? Date()
                                       : Date(timeIntervalSince1970: birthdayTS) },
                set: { birthdayTS = $0.timeIntervalSince1970 })
    }

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $on) { Label("Праздничные анимации", systemImage: "party.popper.fill") }
                if on {
                    Button {
                        Celebrations.test()
                    } label: {
                        Label("Показать сейчас", systemImage: "sparkles")
                    }
                }
            } footer: {
                Text("Конфетти и короткое поздравление внизу экрана. Не мешает: пропадает само через пару секунд, тап — сразу.")
            }
            if on {
                Section("Когда") {
                    Toggle("Закончились пары на сегодня", isOn: $dayEnd)
                    Toggle("Закончилась учебная неделя", isOn: $weekEnd)
                    Toggle("Выполнил задачу", isOn: $tasks)
                    Toggle("Сдал экзамен или зачёт", isOn: $exams)
                    Toggle("Праздники", isOn: $holidays)
                    Toggle("День рождения", isOn: $birthday)
                    if birthday {
                        DatePicker("Дата рождения", selection: bdayBinding, displayedComponents: .date)
                    }
                }
                Section {
                    ForEach(Holiday.all, id: \.id) { h in
                        HStack {
                            Text(h.title).font(.subheadline)
                            Spacer()
                            Text("\(h.day).\(String(format: "%02d", h.month))")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                } header: {
                    Text("Какие праздники")
                } footer: {
                    Text("Среди них — День студента, День программиста и 30 ноября — День защиты информации.")
                }
            }
        }
        .navigationTitle("Праздники")
    }
}
