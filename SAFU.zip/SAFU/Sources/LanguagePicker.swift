import SwiftUI
import WidgetKit

/// Следит за сменой языка: корень приложения перерисовывается целиком
final class LangWatch: ObservableObject {
    static let shared = LangWatch()
    @Published private(set) var revision = 0
    private var token: NSObjectProtocol?

    private init() {
        token = NotificationCenter.default.addObserver(forName: Lang.changed, object: nil, queue: .main) { [weak self] _ in
            Fmt.resetForLanguage()
            WidgetCenter.shared.reloadAllTimelines()
            self?.revision += 1
        }
    }
}

/// Профиль → «Язык»: как в системе, русский или английский
struct LanguageSection: View {
    @State private var choice = Lang.choice

    var body: some View {
        Section {
            Picker(selection: $choice) {
                Text(L("Как в системе · \(Lang.systemIsEnglish ? "English" : "Русский")"))
                    .tag(AppLanguage.system)
                Text("Русский").tag(AppLanguage.ru)
                Text("English").tag(AppLanguage.en)
            } label: {
                Label(Lang.en ? "Language" : "Язык", systemImage: "globe")
            }
            .onChange(of: choice) { _, v in
                Haptics.tap()
                Lang.choice = v
            }
        } footer: {
            Text(L("Язык приложения меняется сразу. Названия предметов, ФИО преподавателей, аудитории и тексты ДЗ остаются как в РУЗ и на сайтах университета."))
        }
    }
}

/// Переключатель «RU | EN» на первом экране регистрации
struct LanguageSwitch: View {
    @State private var en = Lang.en

    var body: some View {
        HStack(spacing: 2) {
            option("RU", selected: !en) { set(false) }
            option("EN", selected: en) { set(true) }
        }
        .padding(3)
        .background(.ultraThinMaterial, in: Capsule())
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Language")
    }

    private func option(_ title: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: .heavy, design: .rounded))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .foregroundStyle(selected ? Color.white : Color.secondary)
                .background(selected ? AnyShapeStyle(Color.brand) : AnyShapeStyle(Color.clear), in: Capsule())
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private func set(_ english: Bool) {
        guard english != en else { return }
        Haptics.tap()
        en = english
        // совпадает с системой — оставляем «как в системе», чтобы потом следовать за ней
        Lang.choice = english == Lang.systemIsEnglish ? .system : (english ? .en : .ru)
    }
}
