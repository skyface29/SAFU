import SwiftUI

// MARK: - Мини-инструкция после первой регистрации
//
// Четыре коротких экрана: где что лежит и два главных жеста. Показывается один раз,
// её всегда можно пропустить.

final class TourRouter: ObservableObject {
    static let shared = TourRouter()
    @Published var show = false
    private static let key = "tour.v1.shown"

    /// После первой регистрации — один раз, когда окно регистрации уже закрылось
    func requestOnce() {
        guard !UserDefaults.standard.bool(forKey: Self.key) else { return }
        UserDefaults.standard.set(true, forKey: Self.key)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { self.show = true }
    }
}

struct TourHost: ViewModifier {
    @ObservedObject private var router = TourRouter.shared

    func body(content: Content) -> some View {
        content.fullScreenCover(isPresented: $router.show) {
            OnboardingTour { router.show = false }
        }
    }
}

private struct TourPage: Identifiable {
    let id: Int
    let icon: String
    let title: String
    let text: String
    let hint: String
}

struct OnboardingTour: View {
    let onDone: () -> Void
    @State private var page = 0

    private var pages: [TourPage] {
        var list: [TourPage] = [
            TourPage(id: 0, icon: "clock.fill",
                     title: "Пара — сразу на главной",
                     text: "Какая пара сейчас, где аудитория и сколько до конца.",
                     hint: "Листай карточку пары влево и вправо"),
            TourPage(id: 1, icon: "rectangle.stack.fill",
                     title: "Сайты в одно касание",
                     text: "Sakai, почта и РУЗ — в панели внизу, под большим пальцем.",
                     hint: "Сайт можно смахнуть вниз — он свернётся, но не закроется"),
        ]
        if !TeacherMode.isOn {
            list.append(TourPage(id: 2, icon: "book.closed.fill",
                                 title: "Домашка сама считает сроки",
                                 text: "Записал ДЗ с пары — срок встанет к следующей паре по расписанию.",
                                 hint: "Кнопка «ДЗ» — прямо в карточке пары"))
        }
        list.append(TourPage(id: 3, icon: "slider.horizontal.3",
                             title: "Всё под себя",
                             text: "Погоду, автобус и другие блоки добавишь в «Настроить главную».",
                             hint: "Зажми любой блок и перетащи"))
        return list
    }

    var body: some View {
        let list = pages
        ZStack {
            AmbientBackground()

            VStack(spacing: 0) {
                HStack {
                    Spacer()
                    Button("Пропустить") { finish() }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .opacity(page < list.count - 1 ? 1 : 0)
                }
                .padding(.horizontal, 24)
                .padding(.top, 12)

                TabView(selection: $page) {
                    ForEach(Array(list.enumerated()), id: \.element.id) { i, p in
                        pageView(p).tag(i)
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .never))

                HStack(spacing: 7) {
                    ForEach(0..<list.count, id: \.self) { i in
                        Capsule()
                            .fill(i == page ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary.opacity(0.35)))
                            .frame(width: i == page ? 22 : 7, height: 7)
                    }
                }
                .animation(.spring(response: 0.35, dampingFraction: 0.8), value: page)
                .padding(.bottom, 22)

                Button {
                    Haptics.tap()
                    if page < list.count - 1 {
                        withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) { page += 1 }
                    } else {
                        finish()
                    }
                } label: {
                    Text(page < list.count - 1 ? "Дальше" : "Начать")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .buttonStyle(PressableStyle())
                .padding(.horizontal, 24)
                .padding(.bottom, 20)
            }
        }
    }

    private func pageView(_ p: TourPage) -> some View {
        VStack(spacing: 22) {
            Spacer(minLength: 10)
            ZStack {
                Circle()
                    .fill(brandGradient)
                    .frame(width: 128, height: 128)
                    .shadow(color: Color.brand.opacity(0.45), radius: 28, y: 10)
                Image(systemName: p.icon)
                    .font(.system(size: 52, weight: .semibold))
                    .foregroundStyle(.white)
            }
            VStack(spacing: 10) {
                Text(p.title)
                    .font(.system(.title2, design: .rounded).weight(.bold))
                    .multilineTextAlignment(.center)
                Text(p.text)
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Label(p.hint, systemImage: "hand.tap.fill")
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
                .glass(18)
            Spacer(minLength: 10)
        }
        .padding(.horizontal, 32)
    }

    private func finish() {
        Haptics.success()
        onDone()
    }
}
