import SwiftUI

// MARK: - Резервная копия
// Один файл .safubackup (обычный ZIP без сжатия): настройки и данные приложения, служебные файлы
// (фото доски по парам, лекции, аватар) и вкладка «Файлы». Пишется и читается по частям,
// поэтому даже гигабайт фото не займёт оперативную память. Пароли и ключи в копию не попадают.

enum BackupManager {
    /// Что не кладём в копию: модели Whisper (сотни МБ, скачаются заново), старые копии, временное
    static func skip(_ rel: String) -> Bool {
        let first = rel.split(separator: "/").first.map(String.init) ?? rel
        return ["huggingface", "Inbox", ".Trash"].contains(first)
            || rel.hasSuffix(".safubackup") || rel.hasSuffix(".part")
    }

    private static var support: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
    }

    /// Все файлы для копии: (путь в архиве, файл на диске)
    static func collect(includeFiles: Bool) -> [(String, URL)] {
        var out: [(String, URL)] = []
        func walk(_ root: URL, prefix: String) {
            let fm = FileManager.default
            guard let e = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey],
                                        options: [.skipsHiddenFiles]) else { return }
            let base = root.standardizedFileURL.path + "/"
            while let u = e.nextObject() as? URL {
                let rel = u.standardizedFileURL.path.replacingOccurrences(of: base, with: "")
                if skip(rel) {
                    if (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true { e.skipDescendants() }
                    continue
                }
                guard (try? u.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else { continue }
                out.append((prefix + rel, u))
            }
        }
        walk(support, prefix: "support/")
        if includeFiles { walk(FileService.root, prefix: "files/") }
        return out
    }

    /// Сколько займёт копия (для подписи)
    static func estimate(includeFiles: Bool) -> Int64 {
        collect(includeFiles: includeFiles).reduce(Int64(0)) { sum, item in
            sum + Int64((try? item.1.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
    }

    /// Собрать копию. progress(готово, всего)
    static func makeBackup(includeFiles: Bool, progress: ((Int, Int) -> Void)? = nil) throws -> URL {
        let bundleID = Bundle.main.bundleIdentifier ?? "ru.student.safuhub"
        let domain = UserDefaults.standard.persistentDomain(forName: bundleID) ?? [:]
        let plist = try PropertyListSerialization.data(fromPropertyList: domain, format: .binary, options: 0)

        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH-mm"
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("САФУ копия \(f.string(from: Date())).safubackup")
        try? FileManager.default.removeItem(at: url)
        let writer = try StreamZipWriter(url: url)
        try writer.add(name: "data.plist", data: plist)
        let files = collect(includeFiles: includeFiles)
        for (i, item) in files.enumerated() {
            try autoreleasepool { try writer.add(name: item.0, file: item.1) }
            progress?(i + 1, files.count)
        }
        try writer.finish()
        UserDefaults.standard.set(Date().timeIntervalSinceReferenceDate, forKey: "backup.last")
        return url
    }

    /// Восстановление: настройки, служебные файлы и файлы. Возвращает число восстановленных файлов
    static func restore(from url: URL, progress: ((Int) -> Void)? = nil) throws -> Int {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        var domain: [String: Any]?
        var restored = 0
        let fm = FileManager.default
        try StreamZipReader.read(url) { name, sink in
            if name == "data.plist" {
                let d = try sink.data()
                domain = try PropertyListSerialization.propertyList(from: d, format: nil) as? [String: Any]
                return
            }
            let dest: URL
            if name.hasPrefix("files/") {
                dest = FileService.root.appendingPathComponent(String(name.dropFirst(6)))
            } else if name.hasPrefix("support/") {
                dest = support.appendingPathComponent(String(name.dropFirst(8)))
            } else { return }
            // защита от путей вида ../../ — пишем только внутрь своих папок
            guard !name.contains(".."), !name.hasSuffix("/") else { return }
            try? fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
            try sink.write(to: dest)
            restored += 1
            progress?(restored)
        }
        guard let domain else {
            throw NSError(domain: "backup", code: 1, userInfo: [NSLocalizedDescriptionKey: "Это не резервная копия САФУ"])
        }
        let bundleID = Bundle.main.bundleIdentifier ?? "ru.student.safuhub"
        UserDefaults.standard.setPersistentDomain(domain, forName: bundleID)
        UserDefaults.standard.set(true, forKey: "onboarded")
        // расписание — и в общие данные для виджета
        if let raw = domain[SharedSchedule.key] as? Data { SharedSchedule.shared.set(raw, forKey: SharedSchedule.key) }
        return restored
    }
}

// MARK: - ZIP по частям (без сжатия, как .docx и старые копии)

final class StreamZipWriter {
    private let handle: FileHandle
    private var offset: UInt64 = 0
    private var central = Data()
    private var count = 0

    init(url: URL) throws {
        FileManager.default.createFile(atPath: url.path, contents: nil)
        handle = try FileHandle(forWritingTo: url)
    }

    private static func le16(_ v: UInt16) -> Data { withUnsafeBytes(of: v.littleEndian) { Data($0) } }
    private static func le32(_ v: UInt32) -> Data { withUnsafeBytes(of: v.littleEndian) { Data($0) } }

    func add(name: String, data: Data) throws {
        try add(name: name, size: UInt64(data.count), crc: CRC32.checksum(data)) { try handle.write(contentsOf: data) }
    }

    /// Файл читается кусками по 1 МБ: сначала считаем CRC, потом пишем
    func add(name: String, file: URL) throws {
        let size = UInt64((try? file.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        guard size < UInt64(UInt32.max) else { return }        // файлы больше 4 ГБ не поддерживаем
        let crc = try Self.crc(of: file)
        try add(name: name, size: size, crc: crc) {
            let r = try FileHandle(forReadingFrom: file)
            defer { try? r.close() }
            while let chunk = try r.read(upToCount: 1 << 20), !chunk.isEmpty {
                try handle.write(contentsOf: chunk)
            }
        }
    }

    private static func crc(of file: URL) throws -> UInt32 {
        let r = try FileHandle(forReadingFrom: file)
        defer { try? r.close() }
        var c: UInt32 = 0xFFFFFFFF
        while let chunk = try r.read(upToCount: 1 << 20), !chunk.isEmpty {
            c = chunk.withUnsafeBytes { CRC32.update(c, $0) }
        }
        return c ^ 0xFFFFFFFF
    }

    private func add(name: String, size: UInt64, crc: UInt32, body: () throws -> Void) throws {
        guard offset < UInt64(UInt32.max) else { return }
        let n = Data(name.utf8)
        var local = Data()
        local += Self.le32(0x04034b50)
        local += Self.le16(20) + Self.le16(0x0800) + Self.le16(0) + Self.le16(0) + Self.le16(0x21)   // 0x0800 — имена в UTF-8
        local += Self.le32(crc) + Self.le32(UInt32(size)) + Self.le32(UInt32(size))
        local += Self.le16(UInt16(n.count)) + Self.le16(0) + n
        try handle.write(contentsOf: local)
        try body()

        central += Self.le32(0x02014b50)
        central += Self.le16(20) + Self.le16(20) + Self.le16(0x0800) + Self.le16(0) + Self.le16(0) + Self.le16(0x21)
        central += Self.le32(crc) + Self.le32(UInt32(size)) + Self.le32(UInt32(size))
        central += Self.le16(UInt16(n.count)) + Self.le16(0) + Self.le16(0) + Self.le16(0) + Self.le16(0)
        central += Self.le32(0) + Self.le32(UInt32(offset)) + n
        offset += UInt64(local.count) + size
        count += 1
    }

    func finish() throws {
        let cdOffset = UInt32(min(offset, UInt64(UInt32.max)))
        try handle.write(contentsOf: central)
        var end = Data()
        end += Self.le32(0x06054b50) + Self.le16(0) + Self.le16(0)
        end += Self.le16(UInt16(min(count, 65535))) + Self.le16(UInt16(min(count, 65535)))
        end += Self.le32(UInt32(central.count)) + Self.le32(cdOffset) + Self.le16(0)
        try handle.write(contentsOf: end)
        try handle.close()
    }
}

enum StreamZipReader {
    /// Кусок архива: можно прочитать в память (маленький) или сразу записать в файл (большой)
    struct Sink {
        let handle: FileHandle
        let size: Int
        func data() throws -> Data { try handle.read(upToCount: size) ?? Data() }
        func write(to url: URL) throws {
            FileManager.default.createFile(atPath: url.path, contents: nil)
            let w = try FileHandle(forWritingTo: url)
            defer { try? w.close() }
            var left = size
            while left > 0, let chunk = try handle.read(upToCount: min(left, 1 << 20)), !chunk.isEmpty {
                try w.write(contentsOf: chunk)
                left -= chunk.count
            }
        }
    }

    static func read(_ url: URL, entry: (String, Sink) throws -> Void) throws {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        func u16(_ d: Data, _ p: Int) -> Int { Int(d[d.startIndex + p]) | Int(d[d.startIndex + p + 1]) << 8 }
        func u32(_ d: Data, _ p: Int) -> Int { u16(d, p) | u16(d, p + 2) << 16 }
        while let head = try h.read(upToCount: 30), head.count == 30, u32(head, 0) == 0x04034b50 {
            let method = u16(head, 8)
            let size = u32(head, 18)
            let nameLen = u16(head, 26)
            let extraLen = u16(head, 28)
            let nameData = try h.read(upToCount: nameLen) ?? Data()
            if extraLen > 0 { _ = try h.read(upToCount: extraLen) }
            let start = try h.offset()
            let name = String(decoding: nameData, as: UTF8.self)
            if method == 0 { try entry(name, Sink(handle: h, size: size)) }
            // к следующей записи — независимо от того, сколько прочитали
            try h.seek(toOffset: start + UInt64(size))
        }
    }
}

struct BackupView: View {
    @State private var includeFiles = true
    @State private var backupURL: URL?
    @State private var working = false
    @State private var message: String?
    @State private var showPicker = false
    @AppStorage("backup.last") private var lastBackup: Double = 0

    private var lastText: String {
        guard lastBackup > 0 else { return "Копий ещё не было" }
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        return "Последняя копия " + f.localizedString(for: Date(timeIntervalSinceReferenceDate: lastBackup), relativeTo: Date())
    }

    @State private var status: String?

    var body: some View {
        Form {
            Section {
                Toggle("Вместе с файлами и фото доски", isOn: $includeFiles)
                Button {
                    working = true
                    status = "Собираю копию…"
                    let withFiles = includeFiles
                    DispatchQueue.global(qos: .userInitiated).async {
                        let result = Result {
                            try BackupManager.makeBackup(includeFiles: withFiles) { i, n in
                                DispatchQueue.main.async { status = "Собираю копию… \(i) из \(n)" }
                            }
                        }
                        DispatchQueue.main.async {
                            working = false
                            status = nil
                            switch result {
                            case .success(let u):
                                backupURL = u
                                let size = (try? u.resourceValues(forKeys: [.fileSizeKey]).fileSize).map {
                                    ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file)
                                } ?? ""
                                message = "Копия готова\(size.isEmpty ? "" : " (\(size))"). Сохрани её в «Файлы», iCloud Drive или отправь себе в Telegram."
                                Haptics.success()
                            case .failure(let e):
                                message = e.localizedDescription
                            }
                        }
                    }
                } label: {
                    HStack {
                        Label("Сделать копию", systemImage: "arrow.down.doc.fill")
                        if working { Spacer(); ProgressView() }
                    }
                }
                .disabled(working)
                if let status {
                    Text(status).font(.caption).foregroundStyle(.secondary).monospacedDigit()
                }
                if let u = backupURL {
                    ShareLink(item: u) {
                        Label("Сохранить копию в «Файлы» / отправить", systemImage: "square.and.arrow.up")
                    }
                }
            } header: {
                Text("Резервная копия")
            } footer: {
                Text("\(lastText). В копии: расписание и память недель, задачи, заметки, посещаемость, лекции с конспектами, фото доски по парам, аватар, настройки и файлы. Пароли и ключи в копию не попадают — это безопаснее. Модель распознавания речи не копируется, она скачается заново.")
            }

            Section {
                Button { showPicker = true } label: {
                    Label("Восстановить из копии", systemImage: "arrow.uturn.backward.circle.fill")
                }
                .disabled(working)
            } footer: {
                Text("Выбери файл .safubackup. После восстановления закрой приложение смахиванием и открой снова.")
            }

            if let message {
                Section { Text(message).font(.subheadline) }
            }
        }
        .navigationTitle("Резервная копия")
        .sheet(isPresented: $showPicker) {
            DocumentPicker { urls in
                showPicker = false
                guard let u = urls.first else { return }
                working = true
                status = "Восстанавливаю…"
                DispatchQueue.global(qos: .userInitiated).async {
                    let result = Result {
                        try BackupManager.restore(from: u) { n in
                            DispatchQueue.main.async { status = "Восстанавливаю… файлов: \(n)" }
                        }
                    }
                    DispatchQueue.main.async {
                        working = false
                        status = nil
                        switch result {
                        case .success(let n):
                            message = "Готово: настройки восстановлены, файлов: \(n). Закрой приложение смахиванием и открой снова."
                            Haptics.success()
                        case .failure(let e):
                            message = e.localizedDescription
                        }
                    }
                }
            }
            .ignoresSafeArea()
        }
    }
}
