import SwiftUI

// MARK: - Резервная копия: все настройки и данные + файлы в один архив .safubackup

enum BackupManager {
    /// Архив: data.plist (все настройки/данные приложения) + files/… (вкладка «Файлы»)
    static func makeBackup(includeFiles: Bool) throws -> URL {
        var entries: [(String, Data)] = []
        let bundleID = Bundle.main.bundleIdentifier ?? "ru.student.safuhub"
        let domain = UserDefaults.standard.persistentDomain(forName: bundleID) ?? [:]
        let plist = try PropertyListSerialization.data(fromPropertyList: domain, format: .binary, options: 0)
        entries.append(("data.plist", plist))

        if includeFiles {
            let root = FileService.root
            let fm = FileManager.default
            if let e = fm.enumerator(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]) {
                while let u = e.nextObject() as? URL {
                    if (try? u.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true { continue }
                    if u.pathExtension == "safubackup" { continue }
                    let rel = u.path.replacingOccurrences(of: root.path + "/", with: "")
                    if let d = try? Data(contentsOf: u) { entries.append(("files/" + rel, d)) }
                }
            }
        }

        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH-mm"
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("САФУ копия \(f.string(from: Date())).safubackup")
        try ZipWriter.make(entries).write(to: url)
        UserDefaults.standard.set(Date().timeIntervalSinceReferenceDate, forKey: "backup.last")
        return url
    }

    /// Восстановление: возвращаем настройки и файлы. Пароли не входят в копию (остаются только в связке ключей).
    static func restore(from url: URL) throws -> Int {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let data = try Data(contentsOf: url)
        let entries = ZipReader.read(data)
        guard let plistData = entries["data.plist"],
              let domain = try PropertyListSerialization.propertyList(from: plistData, format: nil) as? [String: Any] else {
            throw NSError(domain: "backup", code: 1, userInfo: [NSLocalizedDescriptionKey: "Это не резервная копия САФУ"])
        }
        let bundleID = Bundle.main.bundleIdentifier ?? "ru.student.safuhub"
        UserDefaults.standard.setPersistentDomain(domain, forName: bundleID)

        var restored = 0
        for (name, content) in entries where name.hasPrefix("files/") {
            let rel = String(name.dropFirst("files/".count))
            guard !rel.isEmpty, !rel.contains("..") else { continue }
            let dest = FileService.root.appendingPathComponent(rel)
            try? FileManager.default.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
            if (try? content.write(to: dest)) != nil { restored += 1 }
        }
        return restored
    }
}

/// Читает ZIP без сжатия (такие делает наш ZipWriter)
enum ZipReader {
    static func read(_ data: Data) -> [String: Data] {
        var result: [String: Data] = [:]
        let bytes = [UInt8](data)
        var i = 0
        func u16(_ p: Int) -> Int { Int(bytes[p]) | Int(bytes[p + 1]) << 8 }
        func u32(_ p: Int) -> Int { u16(p) | u16(p + 2) << 16 }
        while i + 30 <= bytes.count, u32(i) == 0x04034b50 {
            let method = u16(i + 8)
            let size = u32(i + 18)
            let nameLen = u16(i + 26)
            let extraLen = u16(i + 28)
            let nameStart = i + 30
            let dataStart = nameStart + nameLen + extraLen
            guard dataStart + size <= bytes.count else { break }
            let name = String(decoding: bytes[nameStart..<(nameStart + nameLen)], as: UTF8.self)
            if method == 0 { result[name] = Data(bytes[dataStart..<(dataStart + size)]) }
            i = dataStart + size
        }
        return result
    }
}

struct BackupView: View {
    @State private var includeFiles = true
    @State private var backupURL: URL?
    @State private var working = false
    @State private var message: String?
    @State private var showPicker = false
    @AppStorage("backup.last") private var lastBackup: Double = 0

    private var lastText: String {
        guard lastBackup > 0 else { return "Копий ещё не было" }
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        return "Последняя копия " + f.localizedString(for: Date(timeIntervalSinceReferenceDate: lastBackup), relativeTo: Date())
    }

    var body: some View {
        Form {
            Section {
                Toggle("Вместе с файлами", isOn: $includeFiles)
                Button {
                    working = true
                    let withFiles = includeFiles
                    DispatchQueue.global(qos: .userInitiated).async {
                        let result = Result { try BackupManager.makeBackup(includeFiles: withFiles) }
                        DispatchQueue.main.async {
                            working = false
                            switch result {
                            case .success(let u):
                                backupURL = u
                                message = "Копия готова. Сохрани её в «Файлы» или iCloud Drive."
                                Haptics.success()
                            case .failure(let e):
                                message = e.localizedDescription
                            }
                        }
                    }
                } label: {
                    HStack {
                        Label("Сделать копию", systemImage: "arrow.down.doc.fill")
                        if working { Spacer(); ProgressView() }
                    }
                }
                if let u = backupURL {
                    ShareLink(item: u) {
                        Label("Сохранить копию в «Файлы» / отправить", systemImage: "square.and.arrow.up")
                    }
                }
            } header: {
                Text("Резервная копия")
            } footer: {
                Text("\(lastText). Если сертификат отзовут и приложение удалится, из копии вернутся расписание, память недель, задачи, заметки, посещаемость, настройки и файлы. Пароли в копию не попадают — это безопаснее.")
            }

            Section {
                Button { showPicker = true } label: {
                    Label("Восстановить из копии", systemImage: "arrow.uturn.backward.circle.fill")
                }
            } footer: {
                Text("Выбери файл .safubackup. После восстановления перезапусти приложение.")
            }

            if let message {
                Section { Text(message).font(.subheadline) }
            }
        }
        .navigationTitle("Резервная копия")
        .sheet(isPresented: $showPicker) {
            DocumentPicker { urls in
                showPicker = false
                guard let u = urls.first else { return }
                do {
                    let n = try BackupManager.restore(from: u)
                    message = "Готово: настройки восстановлены, файлов: \(n). Закрой приложение смахиванием и открой снова."
                    Haptics.success()
                } catch {
                    message = error.localizedDescription
                }
            }
            .ignoresSafeArea()
        }
    }
}
