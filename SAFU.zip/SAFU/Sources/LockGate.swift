import SwiftUI
import LocalAuthentication

struct LockGate<Content: View>: View {
    @AppStorage("lockFiles") private var enabled = false
    @State private var unlocked = false
    @Environment(\.scenePhase) private var phase
    private let content: () -> Content
    /// true — закрыто всегда (например, сохранённые пароли), без оглядки на настройку «Файлы по Face ID»
    private let always: Bool
    private let title: String
    private let reason: String

    init(always: Bool = false, title: String = "Файлы защищены", reason: String = "Доступ к твоим файлам",
         @ViewBuilder content: @escaping () -> Content) {
        self.always = always
        self.title = title
        self.reason = reason
        self.content = content
    }

    var body: some View {
        Group {
            if !(enabled || always) || unlocked {
                content()
            } else {
                locked
            }
        }
        .onChange(of: phase) { newPhase in
            if newPhase == .background { unlocked = false }
        }
    }

    private var locked: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(brandGradient)
                Text(title)
                    .font(.system(.title3, design: .rounded).weight(.bold))
                Button(action: authenticate) {
                    Label("Разблокировать", systemImage: "faceid")
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 14)
                        .glass(24, interactive: true)
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear(perform: authenticate)
    }

    private func authenticate() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            unlocked = true
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) { success, _ in
            DispatchQueue.main.async {
                if success {
                    Haptics.success()
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) { unlocked = true }
                }
            }
        }
    }
}
