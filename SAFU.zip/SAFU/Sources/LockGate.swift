import SwiftUI
import LocalAuthentication

struct LockGate<Content: View>: View {
    @AppStorage("lockFiles") private var enabled = false
    @State private var unlocked = false
    @Environment(\.scenePhase) private var phase
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        Group {
            if !enabled || unlocked {
                content()
            } else {
                locked
            }
        }
        .onChange(of: phase) { newPhase in
            if newPhase == .background { unlocked = false }
        }
    }

    private var locked: some View {
        ZStack {
            AmbientBackground()
            VStack(spacing: 18) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(brandGradient)
                Text("Файлы защищены")
                    .font(.system(.title3, design: .rounded).weight(.bold))
                Button(action: authenticate) {
                    Label("Разблокировать", systemImage: "faceid")
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 14)
                        .glass(24, interactive: true)
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear(perform: authenticate)
    }

    private func authenticate() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            unlocked = true
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { success, _ in
            DispatchQueue.main.async {
                if success {
                    Haptics.success()
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) { unlocked = true }
                }
            }
        }
    }
}
