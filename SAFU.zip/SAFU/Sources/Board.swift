import SwiftUI
import UIKit
import Vision
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Доска → текст
// Сфоткал доску — приложение само находит её края, выпрямляет перспективу, распознаёт текст
// (русский и английский, прямо на телефоне, без интернета) и добавляет в поиск.
// Потом по словам находятся все фото доски: «интеграл», «лаба 3», «вариант 2».

struct BoardEntry: Codable, Identifiable, Hashable {
    let name: String        // имя файла в папке предмета
    let subject: String
    var text: String
    let date: Date
    var straightened: Bool

    var id: String { subject + "/" + name }
    var url: URL { SubjectFolders.url(subject).appendingPathComponent(name) }
    var exists: Bool { FileManager.default.fileExists(atPath: url.path) }
}

final class BoardIndex: ObservableObject {
    static let shared = BoardIndex()

    @Published private(set) var entries: [BoardEntry] = []
    /// Сколько снимков сейчас распознаётся
    @Published private(set) var working = 0

    private static var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("board-index.json")
    }

    init() {
        if let raw = try? Data(contentsOf: Self.fileURL),
           let list = try? JSONDecoder().decode([BoardEntry].self, from: raw) {
            entries = list
        }
    }

    private func save() {
        let list = entries
        DispatchQueue.global(qos: .utility).async {
            if let raw = try? JSONEncoder().encode(list) { try? raw.write(to: Self.fileURL, options: .atomic) }
        }
    }

    func begin() { working += 1 }
    func end() { working = max(0, working - 1) }

    func upsert(_ e: BoardEntry) {
        if let i = entries.firstIndex(where: { $0.id == e.id }) { entries[i] = e } else { entries.insert(e, at: 0) }
        save()
    }

    /// Убираем из индекса фото, которые удалили или переименовали
    func prune() {
        let alive = entries.filter(\.exists)
        if alive.count != entries.count {
            entries = alive
            save()
        }
    }

    func contains(subject: String, name: String) -> Bool {
        entries.contains { $0.subject == subject && $0.name == name }
    }

    func search(_ query: String) -> [BoardEntry] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        let all = entries.sorted { $0.date > $1.date }
        guard !q.isEmpty else { return all }
        let words = q.split(separator: " ").map(String.init)
        return all.filter { e in
            let hay = (e.text + " " + e.subject).lowercased()
            return words.allSatisfy { hay.contains($0) }
        }
    }
}

enum BoardScan {
    /// Выпрямить, распознать, переписать файл выпрямленной версией и добавить в индекс (в фоне)
    static func process(fileAt url: URL, subject: String, date: Date = Date()) {
        DispatchQueue.main.async { BoardIndex.shared.begin() }
        DispatchQueue.global(qos: .userInitiated).async {
            defer { DispatchQueue.main.async { BoardIndex.shared.end() } }
            guard let raw = UIImage(contentsOfFile: url.path) else { return }
            let up = normalized(raw)
            var final = up
            var straight = false
            if let s = straighten(up) {
                final = s
                straight = true
                if let d = s.jpegData(compressionQuality: 0.85) { try? d.write(to: url, options: .atomic) }
            }
            let text = recognize(final)
            let entry = BoardEntry(name: url.lastPathComponent, subject: subject, text: text, date: date, straightened: straight)
            DispatchQueue.main.async { BoardIndex.shared.upsert(entry) }
        }
    }

    /// Все старые фото доски из папок предметов, которых ещё нет в поиске
    static func indexExisting() {
        let fm = FileManager.default
        let base = SubjectFolders.base
        let subjects = (try? fm.contentsOfDirectory(at: base, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        for dir in subjects {
            let subject = dir.lastPathComponent
            let files = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.contentModificationDateKey],
                                                      options: [.skipsHiddenFiles])) ?? []
            for f in files where ["jpg", "jpeg", "png", "heic"].contains(f.pathExtension.lowercased()) {
                guard !BoardIndex.shared.contains(subject: subject, name: f.lastPathComponent) else { continue }
                let date = (try? f.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? Date()
                process(fileAt: f, subject: subject, date: date)
            }
        }
    }

    /// Поворачиваем пиксели «как на экране» и уменьшаем до разумного размера
    static func normalized(_ img: UIImage) -> UIImage {
        let maxSide: CGFloat = 3000
        let scale = min(1, maxSide / max(img.size.width, img.size.height))
        if img.imageOrientation == .up && scale >= 1 { return img }
        let size = CGSize(width: img.size.width * scale, height: img.size.height * scale)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            img.draw(in: CGRect(origin: .zero, size: size))
        }
    }

    /// Находим прямоугольник доски и снимаем перекос. nil — доска не найдена, оставляем как есть
    static func straighten(_ img: UIImage) -> UIImage? {
        guard let cg = img.cgImage else { return nil }
        let req = VNDetectRectanglesRequest()
        req.minimumConfidence = 0.7
        req.minimumAspectRatio = 0.25
        req.maximumAspectRatio = 1.0
        req.minimumSize = 0.35
        req.quadratureTolerance = 30
        req.maximumObservations = 1
        try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([req])
        guard let r = req.results?.first else { return nil }
        let ci = CIImage(cgImage: cg)
        let w = ci.extent.width, h = ci.extent.height
        func p(_ pt: CGPoint) -> CGPoint { CGPoint(x: pt.x * w, y: pt.y * h) }
        let f = CIFilter.perspectiveCorrection()
        f.inputImage = ci
        f.topLeft = p(r.topLeft)
        f.topRight = p(r.topRight)
        f.bottomLeft = p(r.bottomLeft)
        f.bottomRight = p(r.bottomRight)
        guard var out = f.outputImage else { return nil }
        let c = CIFilter.colorControls()
        c.inputImage = out
        c.contrast = 1.12
        c.saturation = 1.05
        if let o = c.outputImage { out = o }
        guard let res = CIContext().createCGImage(out, from: out.extent) else { return nil }
        return UIImage(cgImage: res)
    }

    /// Текст с доски построчно, сверху вниз
    static func recognize(_ img: UIImage) -> String {
        guard let cg = img.cgImage else { return "" }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["ru-RU", "en-US"]
        req.usesLanguageCorrection = true
        try? VNImageRequestHandler(cgImage: cg, options: [:]).perform([req])
        let lines = (req.results ?? []).sorted { a, b in
            // в Vision начало координат снизу: чем больше maxY, тем выше строка
            if abs(a.boundingBox.midY - b.boundingBox.midY) > 0.015 { return a.boundingBox.midY > b.boundingBox.midY }
            return a.boundingBox.minX < b.boundingBox.minX
        }
        return lines.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
    }
}

// MARK: - Поиск по доскам

struct BoardSearchView: View {
    @ObservedObject private var index = BoardIndex.shared
    @State private var query = ""
    @State private var open: BoardEntry?

    var body: some View {
        let results = index.search(query)
        return ScrollView {
            LazyVStack(spacing: 12) {
                if index.working > 0 {
                    HStack(spacing: 10) {
                        ProgressView()
                        Text("Распознаю доски: \(index.working)")
                            .font(.subheadline.weight(.semibold))
                        Spacer()
                    }
                    .padding(14)
                    .glass(18)
                }
                if index.entries.isEmpty {
                    EmptyState(icon: "text.viewfinder", title: "Сфоткай доску",
                               text: "На главной в карточке пары — «Фото доски в папку предмета». Приложение выпрямит снимок и распознает текст, а здесь по нему можно будет искать.")
                        .padding(.top, 30)
                } else if results.isEmpty {
                    Text("Ничего не нашлось по «\(query)»")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(.top, 30)
                }
                ForEach(results) { e in
                    Button {
                        Haptics.tap()
                        open = e
                    } label: {
                        BoardRow(entry: e, query: query)
                    }
                    .buttonStyle(PressableStyle())
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .searchable(text: $query, prompt: "Слово с доски: интеграл, вариант 2…")
        .navigationTitle("Доски")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button {
                        Haptics.tap()
                        BoardScan.indexExisting()
                    } label: {
                        Label("Распознать старые фото", systemImage: "text.viewfinder")
                    }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .onAppear { index.prune() }
        .sheet(item: $open) { e in
            NavigationStack { BoardDetailView(entry: e) }
        }
    }
}

private struct BoardRow: View {
    let entry: BoardEntry
    let query: String
    @State private var thumb: UIImage?

    /// Кусочек текста вокруг найденного слова
    private var snippet: String {
        let text = entry.text.replacingOccurrences(of: "\n", with: " · ")
        let q = query.trimmingCharacters(in: .whitespaces).lowercased().split(separator: " ").first.map(String.init) ?? ""
        guard !q.isEmpty, let r = text.lowercased().range(of: q) else {
            return text.isEmpty ? "Текст не распознан" : String(text.prefix(120))
        }
        let low = text.lowercased()
        let offset = low.distance(from: low.startIndex, to: r.lowerBound)
        let start = text.index(text.startIndex, offsetBy: max(0, offset - 40), limitedBy: text.endIndex) ?? text.startIndex
        let end = text.index(start, offsetBy: 140, limitedBy: text.endIndex) ?? text.endIndex
        return (start > text.startIndex ? "…" : "") + String(text[start..<end]) + (end < text.endIndex ? "…" : "")
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.primary.opacity(0.06))
                if let thumb {
                    Image(uiImage: thumb).resizable().scaledToFill()
                } else {
                    Image(systemName: "photo").foregroundStyle(.secondary)
                }
            }
            .frame(width: 64, height: 64)
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(entry.subject)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .lineLimit(1)
                    if entry.straightened {
                        Image(systemName: "perspective").font(.caption2).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 4)
                    Text(Fmt.relative(entry.date)).font(.caption2).foregroundStyle(.tertiary)
                }
                Text(snippet)
                    .font(.caption)
                    .foregroundStyle(.primary)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(18)
        .task(id: entry.id) {
            let url = entry.url
            let img = await Task.detached(priority: .utility) { () -> UIImage? in
                UIImage(contentsOfFile: url.path)?.preparingThumbnail(of: CGSize(width: 160, height: 160))
            }.value
            thumb = img
        }
    }
}

struct BoardDetailView: View {
    let entry: BoardEntry
    @Environment(\.dismiss) private var dismiss
    @State private var image: UIImage?
    @State private var toast: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Group {
                    if let image {
                        Image(uiImage: image).resizable().scaledToFit()
                    } else {
                        ProgressView().frame(maxWidth: .infinity, minHeight: 200)
                    }
                }
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                HStack(spacing: 10) {
                    action("doc.on.doc", "Копировать") {
                        UIPasteboard.general.string = entry.text
                        show("Текст скопирован")
                    }
                    action("note.text.badge.plus", "В заметки") {
                        let title = "Доска · " + Fmt.formatter("d MMMM").string(from: entry.date)
                        NotesStore.shared.upsert(Note(title: title, text: entry.text, subject: entry.subject))
                        show("Добавлено в заметки")
                    }
                    ShareLink(item: entry.text.isEmpty ? entry.subject : entry.text) {
                        VStack(spacing: 4) {
                            Image(systemName: "square.and.arrow.up").font(.system(size: 17, weight: .semibold))
                            Text("Поделиться").font(.caption2.weight(.semibold))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .foregroundStyle(Color.brand)
                        .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                }

                VStack(alignment: .leading, spacing: 8) {
                    Label("Текст с доски", systemImage: "text.viewfinder")
                        .font(.system(.headline, design: .rounded))
                    Text(entry.text.isEmpty ? "Текст не распознан — попробуй снять ближе и ровнее." : entry.text)
                        .font(.body)
                        .foregroundStyle(entry.text.isEmpty ? .secondary : .primary)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(16)
                .glass(20)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle(entry.subject)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() }.fontWeight(.semibold) }
        }
        .overlay(alignment: .bottom) {
            if let toast {
                Text(toast)
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .glass(18)
                    .padding(.bottom, 30)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .task {
            let url = entry.url
            image = await Task.detached(priority: .userInitiated) { UIImage(contentsOfFile: url.path) }.value
        }
    }

    private func show(_ text: String) {
        Haptics.success()
        withAnimation { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation { toast = nil } }
    }

    private func action(_ icon: String, _ title: String, _ run: @escaping () -> Void) -> some View {
        Button(action: run) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 17, weight: .semibold))
                Text(title).font(.caption2.weight(.semibold))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .foregroundStyle(Color.brand)
            .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PressableStyle())
    }
}
