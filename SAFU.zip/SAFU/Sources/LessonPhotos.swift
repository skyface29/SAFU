import SwiftUI
import UIKit
import UserNotifications
import ImageIO
import UniformTypeIdentifiers

// MARK: - Фото доски по парам
// Снимки доски группируются по парам и идут строго по времени: раньше снято — раньше стоит.
// После пары их можно одним PDF (или фотками по порядку) отправить в чат группы.

struct BoardShot: Identifiable, Hashable {
    let url: URL
    let date: Date
    var id: String { url.path }
}

struct BoardBatch: Identifiable, Hashable {
    let subject: String
    let slot: LessonSlot?
    let day: Date
    let shots: [BoardShot]

    var id: String { subject + "|" + (slot?.key ?? "\(Int(day.timeIntervalSince1970))") }
    var start: Date { slot?.start ?? shots.first?.date ?? day }

    var title: String {
        let d = Fmt.formatter("EE, d MMMM").string(from: start)
        if let slot {
            let pair = slot.lesson.pair > 0 ? "\(slot.lesson.pair) пара · " : ""
            return "\(d.capitalizedFirst) · \(pair)\(Fmt.formatter("HH:mm").string(from: slot.start))"
        }
        return d.capitalizedFirst
    }

    var shortDate: String { Fmt.formatter("dd.MM").string(from: start) }
    var countText: String { LessonPhotos.photosWord(shots.count) }
}

enum LessonPhotos {
    static let imageExt: Set<String> = ["jpg", "jpeg", "png", "heic"]

    static func photosWord(_ n: Int) -> String { "\(n) фото" }

    /// Время съёмки: из названия «Доска 26.09 12-10-05», потом из индекса досок, потом дата создания файла
    static func captureDate(_ url: URL, subject: String) -> Date {
        let name = url.deletingPathExtension().lastPathComponent
        if let d = dateFromName(name) { return d }
        // индекс досок живёт на главном потоке — из фона его не трогаем
        if Thread.isMainThread, let e = BoardIndex.shared.entries.first(where: { $0.subject == subject && $0.name == url.lastPathComponent }) {
            return e.date
        }
        let v = try? url.resourceValues(forKeys: [.creationDateKey, .contentModificationDateKey])
        return v?.creationDate ?? v?.contentModificationDate ?? Date.distantPast
    }

    private static func dateFromName(_ name: String) -> Date? {
        // «Доска 26.09 12-10» или «Доска 26.09 12-10-05», иногда с « (2)» в конце
        let pattern = #"(\d{2})\.(\d{2}) (\d{2})-(\d{2})(?:-(\d{2}))?(?: \((\d+)\))?"#
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: name, range: NSRange(name.startIndex..., in: name)) else { return nil }
        func g(_ i: Int) -> Int? {
            guard let r = Range(m.range(at: i), in: name) else { return nil }
            return Int(name[r])
        }
        guard let day = g(1), let month = g(2), let hour = g(3), let minute = g(4) else { return nil }
        let cal = Calendar.current
        var c = DateComponents()
        c.year = cal.component(.year, from: Date())
        c.month = month; c.day = day; c.hour = hour; c.minute = minute
        c.second = g(5) ?? 0
        guard var d = cal.date(from: c) else { return nil }
        // снимок из прошлого года (январь смотрит на декабрьские фото)
        if d > Date().addingTimeInterval(86400) { d = cal.date(byAdding: .year, value: -1, to: d) ?? d }
        // копии с одинаковой минутой — по номеру «(2)», «(3)»
        if let n = g(6) { d = d.addingTimeInterval(Double(n) * 0.001) }
        return d
    }

    static func isBoardPhoto(_ url: URL) -> Bool {
        imageExt.contains(url.pathExtension.lowercased()) && url.lastPathComponent.hasPrefix("Доска")
    }

    /// Все фото доски предмета по времени (раньше — первее)
    static func shots(subject: String) -> [BoardShot] {
        let dir = SubjectFolders.url(subject)
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.creationDateKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles])) ?? []
        return urls.filter(isBoardPhoto)
            .map { BoardShot(url: $0, date: captureDate($0, subject: subject)) }
            .sorted { $0.date < $1.date }
    }

    /// Пара, во время которой (или сразу после) сделан снимок
    static func slot(for date: Date, subject: String, data: ScheduleData) -> LessonSlot? {
        let day = Calendar.current.startOfDay(for: date)
        return ScheduleEngine.slots(on: day, data: data).first {
            $0.lesson.subject == subject && date >= $0.start.addingTimeInterval(-15 * 60) && date <= $0.end.addingTimeInterval(30 * 60)
        }
    }

    /// Снимки предмета, собранные по парам: новые пары сверху, внутри пары — по времени
    static func batches(subject: String, data: ScheduleData) -> [BoardBatch] {
        var groups: [String: (slot: LessonSlot?, day: Date, shots: [BoardShot])] = [:]
        for s in shots(subject: subject) {
            let sl = slot(for: s.date, subject: subject, data: data)
            let day = Calendar.current.startOfDay(for: s.date)
            let key = sl?.key ?? "day-\(Int(day.timeIntervalSince1970))"
            var g = groups[key] ?? (slot: sl, day: day, shots: [])
            g.shots.append(s)
            groups[key] = g
        }
        return groups.values.map { BoardBatch(subject: subject, slot: $0.slot, day: $0.day, shots: $0.shots) }
            .sorted { $0.start > $1.start }
    }

    /// Все пары с фото по всем предметам (для главной и «Досок»)
    static func allBatches(data: ScheduleData, limit: Int = 30) -> [BoardBatch] {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: SubjectFolders.base, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        return dirs.flatMap { batches(subject: $0.lastPathComponent, data: data) }
            .sorted { $0.start > $1.start }
            .prefix(limit).map { $0 }
    }

    /// Пара «сейчас» для кнопки камеры: идёт, скоро начнётся или только что закончилась
    static func currentSlot(_ data: ScheduleData, at now: Date = Date()) -> LessonSlot? {
        let today = ScheduleEngine.slots(on: Calendar.current.startOfDay(for: now), data: data)
        if let s = today.first(where: { now >= $0.start.addingTimeInterval(-10 * 60) && now <= $0.end }) { return s }
        return today.last(where: { $0.end < now && now.timeIntervalSince($0.end) < 40 * 60 })
    }

    /// Фото конкретной пары
    static func batch(for slot: LessonSlot, data: ScheduleData) -> BoardBatch? {
        batches(subject: slot.lesson.subject, data: data).first { $0.slot?.key == slot.key }
    }
}

// MARK: - Быстрая работа с фото (ImageIO)
// Уменьшенная картинка читается прямо из файла, без распаковки полного 12-Мп снимка:
// в разы быстрее и почти без расхода памяти.

enum FastImage {
    static func cgThumbnail(_ url: URL, maxPixel: CGFloat) -> CGImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,     // сразу правильный поворот
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel,
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary)
    }

    static func image(_ url: URL, maxPixel: CGFloat) -> UIImage? {
        cgThumbnail(url, maxPixel: maxPixel).map { UIImage(cgImage: $0) }
    }

    static func jpeg(_ cg: CGImage, quality: CGFloat) -> Data? {
        let data = NSMutableData()
        guard let dst = CGImageDestinationCreateWithData(data as CFMutableData, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dst, cg, [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        return CGImageDestinationFinalize(dst) ? data as Data : nil
    }
}

// MARK: - PDF со всеми фото пары

enum LessonPhotosPDF {
    /// Отпечаток набора фото: те же снимки — тот же PDF, можно не собирать заново
    static func signature(_ batch: BoardBatch) -> String {
        var h = Hasher()
        h.combine(batch.subject)
        h.combine(batch.title)
        for s in batch.shots {
            h.combine(s.url.lastPathComponent)
            let m = (try? s.url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
            h.combine(m?.timeIntervalSince1970 ?? 0)
        }
        return String(UInt(bitPattern: h.finalize()), radix: 36)
    }

    private static func fileURL(_ batch: BoardBatch, signature: String) -> URL {
        let safe = batch.subject.replacingOccurrences(of: "/", with: "-").prefix(60)
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("board-pdf-\(signature)", isDirectory: true)
        return dir.appendingPathComponent("\(safe) \(batch.shortDate) — доска.pdf")
    }

    /// Уже собранный PDF для этих фото
    static func cached(_ batch: BoardBatch, signature: String) -> URL? {
        let u = fileURL(batch, signature: signature)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// Одна страница — одно фото, по порядку, с подписью «предмет · дата · 3/7».
    /// Фото кладутся в PDF готовым JPEG (без повторного сжатия PDF-движком) — быстро и компактно.
    static func make(_ batch: BoardBatch, signature: String? = nil, progress: ((Int, Int) -> Void)? = nil) -> URL? {
        let sig = signature ?? self.signature(batch)
        if let hit = cached(batch, signature: sig) { return hit }
        let url = fileURL(batch, signature: sig)
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let tmp = url.appendingPathExtension("part")
        let pageWidth: CGFloat = 842
        let header: CGFloat = 34
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [kCGPDFContextTitle as String: "\(batch.subject) — \(batch.title)",
                               kCGPDFContextCreator as String: "САФУ"]
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: 595), format: format)
        let timeFmt = Fmt.formatter("HH:mm")
        let attrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 13, weight: .semibold),
            .foregroundColor: UIColor.darkGray,
        ]
        let total = batch.shots.count
        do {
            try renderer.writePDF(to: tmp) { ctx in
                for (i, shot) in batch.shots.enumerated() {
                    autoreleasepool {
                        guard let cg = FastImage.cgThumbnail(shot.url, maxPixel: 2000),
                              let jpg = FastImage.jpeg(cg, quality: 0.72),
                              let provider = CGDataProvider(data: jpg as CFData),
                              let img = CGImage(jpegDataProviderSource: provider, decode: nil,
                                                shouldInterpolate: true, intent: .defaultIntent) else { return }
                        let ratio = CGFloat(img.height) / CGFloat(max(img.width, 1))
                        let page = CGRect(x: 0, y: 0, width: pageWidth, height: pageWidth * ratio + header)
                        ctx.beginPage(withBounds: page, pageInfo: [:])
                        UIColor.white.setFill()
                        UIRectFill(page)
                        let caption = "\(batch.subject) · \(batch.title) · \(timeFmt.string(from: shot.date))   \(i + 1)/\(total)"
                        (caption as NSString).draw(in: CGRect(x: 14, y: 9, width: pageWidth - 28, height: header - 10), withAttributes: attrs)
                        UIImage(cgImage: img).draw(in: CGRect(x: 0, y: header, width: pageWidth, height: pageWidth * ratio))
                    }
                    progress?(i + 1, total)
                }
            }
            try? FileManager.default.removeItem(at: url)
            try FileManager.default.moveItem(at: tmp, to: url)
            return url
        } catch {
            try? FileManager.default.removeItem(at: tmp)
            return nil
        }
    }

    /// Удаляем PDF и копии фото, оставшиеся после отправки
    static func cleanTemp() {
        let tmp = FileManager.default.temporaryDirectory
        let items = (try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil)) ?? []
        for u in items where u.lastPathComponent.hasPrefix("board-") || u.lastPathComponent.hasSuffix("— доска.pdf") {
            try? FileManager.default.removeItem(at: u)
        }
    }

    /// Фото с номерами в названии — чтобы в чате они легли по порядку.
    /// Жёсткие ссылки вместо копий: мгновенно и без лишнего места
    static func numberedCopies(_ batch: BoardBatch) -> [URL] {
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent("board-\(UUID().uuidString)", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let f = Fmt.formatter("HH-mm")
        return batch.shots.enumerated().compactMap { i, s in
            let dst = dir.appendingPathComponent(String(format: "%02d %@ %@.%@", i + 1, batch.shortDate,
                                                        f.string(from: s.date), s.url.pathExtension))
            if (try? fm.linkItem(at: s.url, to: dst)) != nil { return dst }
            return (try? fm.copyItem(at: s.url, to: dst)) != nil ? dst : nil
        }
    }
}

/// Сборка PDF в фоне. Один и тот же набор не собирается дважды одновременно
actor BoardPDFBuilder {
    static let shared = BoardPDFBuilder()
    private var running: [String: Task<URL?, Never>] = [:]

    func pdf(for batch: BoardBatch, progress: (@Sendable (Int, Int) -> Void)? = nil) async -> URL? {
        let sig = LessonPhotosPDF.signature(batch)
        if let hit = LessonPhotosPDF.cached(batch, signature: sig) { return hit }
        if let t = running[sig] { return await t.value }
        let t = Task.detached(priority: .userInitiated) {
            LessonPhotosPDF.make(batch, signature: sig, progress: progress)
        }
        running[sig] = t
        let url = await t.value
        running[sig] = nil
        return url
    }

    /// Заранее, пока смотришь фото пары — к моменту «Отправить» PDF уже готов
    func prewarm(_ batch: BoardBatch) {
        guard !batch.shots.isEmpty else { return }
        let sig = LessonPhotosPDF.signature(batch)
        guard LessonPhotosPDF.cached(batch, signature: sig) == nil, running[sig] == nil else { return }
        let t = Task.detached(priority: .utility) { LessonPhotosPDF.make(batch, signature: sig) }
        running[sig] = t
        Task {
            _ = await t.value
            self.finish(sig)
        }
    }

    private func finish(_ sig: String) { running[sig] = nil }
}

// MARK: - Напоминание после пары

enum BoardReminder {
    static let subjectKey = "board.subject"
    static let startKey = "board.start"

    /// Сфоткал доску на паре — после её конца придёт «Отправь ребятам N фото»
    static func schedule(subject: String) {
        let data = SharedSchedule.load()
        guard UserDefaults.standard.object(forKey: "board.remind") as? Bool ?? true,
              let slot = LessonPhotos.slot(for: Date(), subject: subject, data: data) else { return }
        let fire = max(slot.end.addingTimeInterval(60), Date().addingTimeInterval(5))
        guard fire.timeIntervalSinceNow < 3 * 3600 else { return }
        let count = LessonPhotos.batch(for: slot, data: data)?.shots.count ?? 1
        let c = UNMutableNotificationContent()
        c.title = "Фото с пары: \(slot.lesson.subject)"
        c.body = "\(LessonPhotos.photosWord(count)) доски по порядку — нажми, чтобы собрать PDF и отправить ребятам"
        c.sound = .default
        c.userInfo = [subjectKey: subject, startKey: slot.start.timeIntervalSince1970]
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: fire.timeIntervalSinceNow, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "board.\(slot.key)", content: c, trigger: trigger))
    }
}

/// Какую пару с фото открыть (из уведомления или ссылки safu://board)
final class BoardRouter: ObservableObject {
    static let shared = BoardRouter()
    struct Target: Identifiable, Equatable {
        let subject: String
        let start: Date?
        var id: String { subject + "\(start?.timeIntervalSince1970 ?? 0)" }
    }
    @Published var target: Target?
    /// Открыть камеру для текущей пары
    @Published var camera = false
}

// MARK: - Экран пары с фото

/// Готовые миниатюры — чтобы при прокрутке не декодировать фото заново
enum ThumbCache {
    static let shared: NSCache<NSString, UIImage> = {
        let c = NSCache<NSString, UIImage>()
        c.countLimit = 300
        return c
    }()
}

/// Миниатюра без загрузки полного снимка в память
struct BoardThumb: View {
    let url: URL
    var corner: CGFloat = 12
    @State private var image: UIImage?

    var body: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.07))
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: "photo").foregroundStyle(.tertiary)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
            .task(id: url) {
                // в ключе — время изменения: после выпрямления снимок перезаписывается, старая миниатюра не годится
                let mtime = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
                let key = "\(url.path)|\(mtime?.timeIntervalSince1970 ?? 0)" as NSString
                if let hit = ThumbCache.shared.object(forKey: key) { image = hit; return }
                let u = url
                let thumb = await Task.detached(priority: .utility) {
                    FastImage.image(u, maxPixel: 360)
                }.value
                if let thumb { ThumbCache.shared.setObject(thumb, forKey: key) }
                image = thumb
            }
    }
}

/// Что отправить через окно «Поделиться» (через item — иначе SwiftUI иногда показывает пустое окно)
struct ShareItem: Identifiable {
    let id = UUID()
    let items: [Any]
}

/// Какое фото открыть в галерее
struct GalleryRef: Identifiable {
    let id = UUID()
    let shots: [BoardShot]
    let index: Int
}

// MARK: - Галерея: листать, приближать, смахнуть вниз — закрыть

struct BoardGallery: View {
    let shots: [BoardShot]
    @State var index: Int
    @Environment(\.dismiss) private var dismiss
    @State private var drag: CGFloat = 0
    @State private var zoomed = false
    @State private var chrome = true
    @State private var share: ShareItem?

    private var progress: CGFloat { min(1, abs(drag) / 300) }

    var body: some View {
        ZStack {
            Color.black.opacity(Double(1 - progress * 0.8)).ignoresSafeArea()

            TabView(selection: $index) {
                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                    ZoomableShot(url: s.url, zoomed: $zoomed)
                        .tag(i)
                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { chrome.toggle() } }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            .offset(y: drag)
            .scaleEffect(1 - progress * 0.15)
            .simultaneousGesture(
                DragGesture(minimumDistance: 20)
                    .onChanged { v in
                        guard !zoomed, abs(v.translation.height) > abs(v.translation.width) else { return }
                        drag = v.translation.height
                    }
                    .onEnded { v in
                        guard !zoomed else { return }
                        if abs(drag) > 120 || abs(v.predictedEndTranslation.height) > 400 {
                            dismiss()
                        } else {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { drag = 0 }
                        }
                    }
            )

            if chrome && drag == 0 {
                VStack {
                    HStack(spacing: 12) {
                        Button { dismiss() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        Spacer()
                        if shots.indices.contains(index) {
                            VStack(spacing: 1) {
                                Text("\(index + 1) из \(shots.count)").font(.subheadline.weight(.bold))
                                Text(Fmt.formatter("d MMMM, HH:mm").string(from: shots[index].date)).font(.caption2)
                            }
                            .foregroundStyle(.white)
                        }
                        Spacer()
                        Button {
                            if shots.indices.contains(index) { share = ShareItem(items: [shots[index].url]) }
                        } label: {
                            Image(systemName: "square.and.arrow.up").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                    }
                    .padding(.horizontal, 16)
                    Spacer()
                    // полоска миниатюр — прыгнуть к любому фото
                    ScrollViewReader { proxy in
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 6) {
                                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                                    BoardThumb(url: s.url, corner: 7)
                                        .frame(width: i == index ? 52 : 40, height: 40)
                                        .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Color.white.opacity(i == index ? 0.9 : 0), lineWidth: 2))
                                        .id(i)
                                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { index = i } }
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                        .onChange(of: index) { i in withAnimation { proxy.scrollTo(i, anchor: .center) } }
                        .onAppear { proxy.scrollTo(index, anchor: .center) }
                    }
                    .padding(.bottom, 8)
                }
                .transition(.opacity)
            }
        }
        .statusBarHidden(!chrome)
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .onChange(of: index) { _ in zoomed = false }
    }
}

/// Одно фото с приближением щипком и двойным тапом
struct ZoomableShot: View {
    let url: URL
    @Binding var zoomed: Bool
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .offset(offset)
                        .frame(width: geo.size.width, height: geo.size.height)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { v in scale = max(1, min(5, base * v)) }
                                .onEnded { _ in
                                    base = scale
                                    if scale <= 1.01 { reset() } else { zoomed = true }
                                }
                        )
                        .simultaneousGesture(
                            DragGesture()
                                .onChanged { v in
                                    guard scale > 1 else { return }
                                    offset = CGSize(width: lastOffset.width + v.translation.width,
                                                    height: lastOffset.height + v.translation.height)
                                }
                                .onEnded { _ in lastOffset = offset },
                            including: scale > 1 ? .all : .subviews
                        )
                        .onTapGesture(count: 2) {
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                if scale > 1 { reset() } else { scale = 2.5; base = 2.5; zoomed = true }
                            }
                        }
                } else {
                    ProgressView().tint(.white)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .task(id: url) {
            let u = url
            image = await Task.detached(priority: .userInitiated) {
                FastImage.image(u, maxPixel: 2600)
            }.value
        }
    }

    private func reset() {
        scale = 1; base = 1; offset = .zero; lastOffset = .zero; zoomed = false
    }
}

// MARK: - Экран пары с фото

struct BoardBatchView: View {
    @State var batch: BoardBatch
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var gallery: GalleryRef?
    @State private var share: ShareItem?
    @State private var camera = false
    @State private var toDelete: BoardShot?
    /// Идёт сборка: «Собираю PDF… 5 из 24»
    @State private var working: String?

    private func sendPDF() {
        guard working == nil else { return }
        let b = batch
        working = "Собираю PDF…"
        Task {
            let url = await BoardPDFBuilder.shared.pdf(for: b) { i, n in
                Task { @MainActor in working = "Собираю PDF… \(i) из \(n)" }
            }
            working = nil
            if let url { share = ShareItem(items: [url]) }
        }
    }

    private func sendPhotos() {
        guard working == nil else { return }
        let b = batch
        working = "Готовлю фото…"
        Task {
            let copies = await Task.detached(priority: .userInitiated) { LessonPhotosPDF.numberedCopies(b) }.value
            working = nil
            if !copies.isEmpty { share = ShareItem(items: copies) }
        }
    }

    private func reload() {
        let all = LessonPhotos.batches(subject: batch.subject, data: schedule.data)
        if let b = all.first(where: { $0.id == batch.id }) { batch = b }
        else if let slot = batch.slot, let b = LessonPhotos.batch(for: slot, data: schedule.data) { batch = b }
        else { batch = BoardBatch(subject: batch.subject, slot: batch.slot, day: batch.day, shots: []) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(batch.subject)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text("\(batch.title) · \(batch.countText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(SubjectColor.color(for: batch.subject).opacity(0.15),
                            in: RoundedRectangle(cornerRadius: 22, style: .continuous))

                HStack(spacing: 10) {
                    bigButton("Отправить PDF", "doc.richtext.fill", primary: true) { sendPDF() }
                    bigButton("Фото по порядку", "photo.stack.fill") { sendPhotos() }
                }
                .disabled(batch.shots.isEmpty || working != nil)

                bigButton("Сфоткать ещё", "camera.fill") { camera = true }

                if batch.shots.isEmpty {
                    Text("Фото этой пары пока нет.").font(.subheadline).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8),
                                    GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                        Button { gallery = GalleryRef(shots: batch.shots, index: i) } label: {
                            BoardThumb(url: s.url, corner: 12)
                                .aspectRatio(1, contentMode: .fit)
                                .overlay(alignment: .topLeading) {
                                    Text("\(i + 1)")
                                        .font(.caption2.weight(.heavy))
                                        .foregroundStyle(.white)
                                        .frame(width: 20, height: 20)
                                        .background(Color.brand, in: Circle())
                                        .padding(5)
                                }
                                .overlay(alignment: .bottomTrailing) {
                                    Text(Fmt.formatter("HH:mm").string(from: s.date))
                                        .font(.system(size: 9, weight: .bold))
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 5).padding(.vertical, 2)
                                        .background(.black.opacity(0.45), in: Capsule())
                                        .padding(5)
                                }
                        }
                        .buttonStyle(PressableStyle())
                        .contextMenu {
                            Button { share = ShareItem(items: [s.url]) } label: {
                                Label("Отправить это фото", systemImage: "square.and.arrow.up")
                            }
                            Button(role: .destructive) { toDelete = s } label: { Label("Удалить", systemImage: "trash") }
                        }
                    }
                }
                Text("Нажми на фото — откроется галерея: листай вбок, приближай щипком, смахни вниз, чтобы закрыть. Порядок — по времени съёмки.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Фото пары")
        .navigationBarTitleDisplayMode(.inline)
        .overlay {
            if let working {
                ProgressOverlay(text: working)
            }
        }
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { image in
                camera = false
                if let image, BoardPhoto.save(image, subject: batch.subject) != nil {
                    Haptics.success()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { reload() }
                }
            }
            .ignoresSafeArea()
        }
        .confirmationDialog("Удалить фото?", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } }),
                            titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let s = toDelete { try? FileManager.default.removeItem(at: s.url) }
                toDelete = nil
                BoardIndex.shared.prune()
                reload()
            }
        }
        .onAppear {
            reload()
            // PDF собирается заранее в фоне — к нажатию «Отправить» он уже готов
            let b = batch
            Task { await BoardPDFBuilder.shared.prewarm(b) }
        }
    }

    private func bigButton(_ title: String, _ icon: String, primary: Bool = false, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(primary ? Color.white : Color.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background {
                    if primary {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(brandGradient)
                    } else {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.primary.opacity(0.08))
                    }
                }
        }
        .buttonStyle(PressableStyle())
    }
}

/// Плашка «идёт работа» поверх экрана
struct ProgressOverlay: View {
    let text: String
    var body: some View {
        VStack(spacing: 10) {
            ProgressView().controlSize(.large)
            Text(text).font(.subheadline.weight(.semibold)).monospacedDigit()
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 20)
        .glass(22)
        .transition(.opacity.combined(with: .scale(scale: 0.95)))
    }
}

/// Обычное окно «Поделиться» (для нескольких файлов сразу)
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Строка пары с фото: полоска миниатюр. Если задан onShot — миниатюры открывают галерею
struct BoardBatchRow: View {
    let batch: BoardBatch
    var showSubject = false
    var onShot: ((Int) -> Void)? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(showSubject ? batch.subject : batch.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(showSubject ? "\(batch.title) · \(batch.countText)" : batch.countText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
            // все фото по порядку; полоска сама доезжает до самых новых
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 6) {
                        ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                            BoardThumb(url: s.url, corner: 9)
                                .frame(width: 64, height: 48)
                                .id(s.id)
                                .onTapGesture { onShot?(i) }
                        }
                    }
                }
                .frame(height: 48)
                .onAppear { if let last = batch.shots.last { proxy.scrollTo(last.id, anchor: .trailing) } }
                .onChange(of: batch.shots.count) { _ in
                    if let last = batch.shots.last { withAnimation { proxy.scrollTo(last.id, anchor: .trailing) } }
                }
            }
            .allowsHitTesting(onShot != nil)
        }
        .contentShape(Rectangle())
    }
}

/// Все пары с фото одного предмета (или всех, если subject == nil)
struct BoardBatchesList: View {
    let subject: String?
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var list: [BoardBatch] = []

    var body: some View {
        List {
            if list.isEmpty {
                Text("Фото доски пока нет. Снимай прямо на паре — кнопка камеры есть на главной, в карточке пары, на экране блокировки и на странице предмета.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            ForEach(list) { b in
                NavigationLink {
                    BoardBatchView(batch: b)
                } label: {
                    BoardBatchRow(batch: b, showSubject: subject == nil)
                }
            }
        }
        .navigationTitle(subject == nil ? "Фото с пар" : "Фото доски")
        .onAppear {
            list = subject.map { LessonPhotos.batches(subject: $0, data: schedule.data) }
                ?? LessonPhotos.allBatches(data: schedule.data, limit: 100)
        }
    }
}

// MARK: - Карточка «Фото доски» на главной
// Свёрнута в одну строку (камера + сколько фото), по нажатию разворачивается.

struct BoardHomeCard: View {
    let data: ScheduleData
    let onCamera: (String) -> Void
    let onOpen: (BoardBatch) -> Void
    @ObservedObject private var index = BoardIndex.shared
    @AppStorage("board.card.open") private var open = false
    @State private var latest: BoardBatch?
    @State private var share: ShareItem?
    @State private var gallery: GalleryRef?
    @State private var working: String?

    private var slot: LessonSlot? { LessonPhotos.currentSlot(data) }

    private var summary: String {
        if let b = latest, !b.shots.isEmpty {
            let isCurrent = slot.map { b.slot?.key == $0.key } ?? false
            return (isCurrent ? "эта пара" : b.shortDate) + " · " + b.countText
        }
        return slot != nil ? "сфоткай доску этой пары" : "фото пока нет"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // строка-заголовок: всегда видна
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "camera.viewfinder")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(brandGradient)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Фото доски").font(.system(.subheadline, design: .rounded).weight(.bold)).foregroundStyle(.primary)
                            Text(summary).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        if index.working > 0 { ProgressView().controlSize(.small) }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                if let slot {
                    Button {
                        Haptics.tap()
                        onCamera(slot.lesson.subject)
                    } label: {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 34, height: 34)
                            .background(brandGradient, in: Circle())
                    }
                    .buttonStyle(PressableStyle())
                }
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(open ? 180 : 0))
                        .frame(width: 30, height: 30)
                        .background(Color.primary.opacity(0.07), in: Circle())
                }
                .buttonStyle(.plain)
            }

            if open {
                VStack(alignment: .leading, spacing: 12) {
                    if let b = latest, !b.shots.isEmpty {
                        // миниатюра — галерея, остальная строка — экран пары
                        BoardBatchRow(batch: b, showSubject: true) { i in
                            gallery = GalleryRef(shots: b.shots, index: i)
                        }
                        .onTapGesture { onOpen(b) }
                        Button {
                            guard working == nil else { return }
                            working = "Собираю PDF…"
                            Task {
                                let url = await BoardPDFBuilder.shared.pdf(for: b) { i, n in
                                    Task { @MainActor in working = "Собираю PDF… \(i) из \(n)" }
                                }
                                working = nil
                                if let url { share = ShareItem(items: [url]) }
                            }
                        } label: {
                            Label(working ?? "Отправить ребятам PDF (\(b.shots.count))",
                                  systemImage: working == nil ? "paperplane.fill" : "hourglass")
                                .font(.subheadline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(PressableStyle())
                    } else {
                        Text("На паре нажми на камеру — фото лягут в папку предмета по порядку, а после пары их можно одним PDF отправить группе. Кнопка камеры есть и на экране блокировки.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .glass(22)
        .onAppear { refresh() }
        .onChange(of: index.entries.count) { _ in refresh() }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
    }

    /// Поиск фото — в фоне, чтобы главная не подтормаживала
    private func refresh() {
        let d = data
        let current = slot
        Task {
            let b = await Task.detached(priority: .utility) { () -> BoardBatch? in
                if let current, let b = LessonPhotos.batch(for: current, data: d) { return b }
                return LessonPhotos.allBatches(data: d, limit: 1).first
            }.value
            latest = b
        }
    }
}
