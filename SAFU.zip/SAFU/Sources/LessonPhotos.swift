import SwiftUI
import UIKit
import UserNotifications
import QuickLook

// MARK: - Фото доски по парам
// Снимки доски группируются по парам и идут строго по времени: раньше снято — раньше стоит.
// После пары их можно одним PDF (или фотками по порядку) отправить в чат группы.

struct BoardShot: Identifiable, Hashable {
    let url: URL
    let date: Date
    var id: String { url.path }
}

struct BoardBatch: Identifiable, Hashable {
    let subject: String
    let slot: LessonSlot?
    let day: Date
    let shots: [BoardShot]

    var id: String { subject + "|" + (slot?.key ?? "\(Int(day.timeIntervalSince1970))") }
    var start: Date { slot?.start ?? shots.first?.date ?? day }

    var title: String {
        let d = Fmt.formatter("EE, d MMMM").string(from: start)
        if let slot {
            let pair = slot.lesson.pair > 0 ? "\(slot.lesson.pair) пара · " : ""
            return "\(d.capitalizedFirst) · \(pair)\(Fmt.formatter("HH:mm").string(from: slot.start))"
        }
        return d.capitalizedFirst
    }

    var shortDate: String { Fmt.formatter("dd.MM").string(from: start) }
    var countText: String { LessonPhotos.photosWord(shots.count) }
}

enum LessonPhotos {
    static let imageExt: Set<String> = ["jpg", "jpeg", "png", "heic"]

    static func photosWord(_ n: Int) -> String { "\(n) фото" }

    /// Время съёмки: из названия «Доска 26.09 12-10-05», потом из индекса досок, потом дата создания файла
    static func captureDate(_ url: URL, subject: String) -> Date {
        let name = url.deletingPathExtension().lastPathComponent
        if let d = dateFromName(name) { return d }
        if let e = BoardIndex.shared.entries.first(where: { $0.subject == subject && $0.name == url.lastPathComponent }) {
            return e.date
        }
        let v = try? url.resourceValues(forKeys: [.creationDateKey, .contentModificationDateKey])
        return v?.creationDate ?? v?.contentModificationDate ?? Date.distantPast
    }

    private static func dateFromName(_ name: String) -> Date? {
        // «Доска 26.09 12-10» или «Доска 26.09 12-10-05», иногда с « (2)» в конце
        let pattern = #"(\d{2})\.(\d{2}) (\d{2})-(\d{2})(?:-(\d{2}))?(?: \((\d+)\))?"#
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: name, range: NSRange(name.startIndex..., in: name)) else { return nil }
        func g(_ i: Int) -> Int? {
            guard let r = Range(m.range(at: i), in: name) else { return nil }
            return Int(name[r])
        }
        guard let day = g(1), let month = g(2), let hour = g(3), let minute = g(4) else { return nil }
        let cal = Calendar.current
        var c = DateComponents()
        c.year = cal.component(.year, from: Date())
        c.month = month; c.day = day; c.hour = hour; c.minute = minute
        c.second = g(5) ?? 0
        guard var d = cal.date(from: c) else { return nil }
        // снимок из прошлого года (январь смотрит на декабрьские фото)
        if d > Date().addingTimeInterval(86400) { d = cal.date(byAdding: .year, value: -1, to: d) ?? d }
        // копии с одинаковой минутой — по номеру «(2)», «(3)»
        if let n = g(6) { d = d.addingTimeInterval(Double(n) * 0.001) }
        return d
    }

    static func isBoardPhoto(_ url: URL) -> Bool {
        imageExt.contains(url.pathExtension.lowercased()) && url.lastPathComponent.hasPrefix("Доска")
    }

    /// Все фото доски предмета по времени (раньше — первее)
    static func shots(subject: String) -> [BoardShot] {
        let dir = SubjectFolders.url(subject)
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.creationDateKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles])) ?? []
        return urls.filter(isBoardPhoto)
            .map { BoardShot(url: $0, date: captureDate($0, subject: subject)) }
            .sorted { $0.date < $1.date }
    }

    /// Пара, во время которой (или сразу после) сделан снимок
    static func slot(for date: Date, subject: String, data: ScheduleData) -> LessonSlot? {
        let day = Calendar.current.startOfDay(for: date)
        return ScheduleEngine.slots(on: day, data: data).first {
            $0.lesson.subject == subject && date >= $0.start.addingTimeInterval(-15 * 60) && date <= $0.end.addingTimeInterval(30 * 60)
        }
    }

    /// Снимки предмета, собранные по парам: новые пары сверху, внутри пары — по времени
    static func batches(subject: String, data: ScheduleData) -> [BoardBatch] {
        var groups: [String: (slot: LessonSlot?, day: Date, shots: [BoardShot])] = [:]
        for s in shots(subject: subject) {
            let sl = slot(for: s.date, subject: subject, data: data)
            let day = Calendar.current.startOfDay(for: s.date)
            let key = sl?.key ?? "day-\(Int(day.timeIntervalSince1970))"
            var g = groups[key] ?? (slot: sl, day: day, shots: [])
            g.shots.append(s)
            groups[key] = g
        }
        return groups.values.map { BoardBatch(subject: subject, slot: $0.slot, day: $0.day, shots: $0.shots) }
            .sorted { $0.start > $1.start }
    }

    /// Все пары с фото по всем предметам (для главной и «Досок»)
    static func allBatches(data: ScheduleData, limit: Int = 30) -> [BoardBatch] {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: SubjectFolders.base, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        return dirs.flatMap { batches(subject: $0.lastPathComponent, data: data) }
            .sorted { $0.start > $1.start }
            .prefix(limit).map { $0 }
    }

    /// Пара «сейчас» для кнопки камеры: идёт, скоро начнётся или только что закончилась
    static func currentSlot(_ data: ScheduleData, at now: Date = Date()) -> LessonSlot? {
        let today = ScheduleEngine.slots(on: Calendar.current.startOfDay(for: now), data: data)
        if let s = today.first(where: { now >= $0.start.addingTimeInterval(-10 * 60) && now <= $0.end }) { return s }
        return today.last(where: { $0.end < now && now.timeIntervalSince($0.end) < 40 * 60 })
    }

    /// Фото конкретной пары
    static func batch(for slot: LessonSlot, data: ScheduleData) -> BoardBatch? {
        batches(subject: slot.lesson.subject, data: data).first { $0.slot?.key == slot.key }
    }
}

// MARK: - PDF со всеми фото пары

enum LessonPhotosPDF {
    /// Одна страница — одно фото, по порядку, с подписью «предмет · дата · 3/7»
    static func make(_ batch: BoardBatch) -> URL? {
        let safe = batch.subject.replacingOccurrences(of: "/", with: "-").prefix(60)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe) \(batch.shortDate) — доска.pdf")
        try? FileManager.default.removeItem(at: url)
        let pageWidth: CGFloat = 842
        let header: CGFloat = 34
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [kCGPDFContextTitle as String: "\(batch.subject) — \(batch.title)",
                               kCGPDFContextCreator as String: "САФУ"]
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: 595), format: format)
        do {
            try renderer.writePDF(to: url) { ctx in
                for (i, shot) in batch.shots.enumerated() {
                    guard let img = downscaled(shot.url, maxSide: 2200) else { continue }
                    let ratio = img.size.height / max(img.size.width, 1)
                    let h = pageWidth * ratio + header
                    let page = CGRect(x: 0, y: 0, width: pageWidth, height: h)
                    ctx.beginPage(withBounds: page, pageInfo: [:])
                    UIColor.white.setFill()
                    UIRectFill(page)
                    let time = Fmt.formatter("HH:mm").string(from: shot.date)
                    let caption = "\(batch.subject) · \(batch.title) · \(time)   \(i + 1)/\(batch.shots.count)"
                    let attrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 13, weight: .semibold),
                        .foregroundColor: UIColor.darkGray,
                    ]
                    (caption as NSString).draw(in: CGRect(x: 14, y: 9, width: pageWidth - 28, height: header - 10), withAttributes: attrs)
                    img.draw(in: CGRect(x: 0, y: header, width: pageWidth, height: pageWidth * ratio))
                }
            }
            return url
        } catch {
            return nil
        }
    }

    static func downscaled(_ url: URL, maxSide: CGFloat) -> UIImage? {
        guard let img = UIImage(contentsOfFile: url.path) else { return nil }
        let scale = min(1, maxSide / max(img.size.width, img.size.height))
        if scale >= 1 && img.imageOrientation == .up { return img }
        let size = CGSize(width: img.size.width * scale, height: img.size.height * scale)
        let f = UIGraphicsImageRendererFormat()
        f.scale = 1
        return UIGraphicsImageRenderer(size: size, format: f).image { _ in img.draw(in: CGRect(origin: .zero, size: size)) }
    }

    /// Удаляем PDF и копии фото, оставшиеся после отправки
    static func cleanTemp() {
        let tmp = FileManager.default.temporaryDirectory
        let items = (try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil)) ?? []
        for u in items where u.lastPathComponent.hasPrefix("board-") || u.lastPathComponent.hasSuffix("— доска.pdf") {
            try? FileManager.default.removeItem(at: u)
        }
    }

    /// Копии фото с номерами в названии — чтобы в чате они легли по порядку
    static func numberedCopies(_ batch: BoardBatch) -> [URL] {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("board-\(UUID().uuidString)", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return batch.shots.enumerated().compactMap { i, s in
            let dst = dir.appendingPathComponent(String(format: "%02d %@ %@.%@", i + 1, batch.shortDate,
                                                        Fmt.formatter("HH-mm").string(from: s.date), s.url.pathExtension))
            return (try? FileManager.default.copyItem(at: s.url, to: dst)) != nil ? dst : nil
        }
    }
}

// MARK: - Напоминание после пары

enum BoardReminder {
    static let subjectKey = "board.subject"
    static let startKey = "board.start"

    /// Сфоткал доску на паре — после её конца придёт «Отправь ребятам N фото»
    static func schedule(subject: String) {
        let data = SharedSchedule.load()
        guard UserDefaults.standard.object(forKey: "board.remind") as? Bool ?? true,
              let slot = LessonPhotos.slot(for: Date(), subject: subject, data: data) else { return }
        let fire = max(slot.end.addingTimeInterval(60), Date().addingTimeInterval(5))
        guard fire.timeIntervalSinceNow < 3 * 3600 else { return }
        let count = LessonPhotos.batch(for: slot, data: data)?.shots.count ?? 1
        let c = UNMutableNotificationContent()
        c.title = "Фото с пары: \(slot.lesson.subject)"
        c.body = "\(LessonPhotos.photosWord(count)) доски по порядку — нажми, чтобы собрать PDF и отправить ребятам"
        c.sound = .default
        c.userInfo = [subjectKey: subject, startKey: slot.start.timeIntervalSince1970]
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: fire.timeIntervalSinceNow, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "board.\(slot.key)", content: c, trigger: trigger))
    }
}

/// Какую пару с фото открыть (из уведомления или ссылки safu://board)
final class BoardRouter: ObservableObject {
    static let shared = BoardRouter()
    struct Target: Identifiable, Equatable {
        let subject: String
        let start: Date?
        var id: String { subject + "\(start?.timeIntervalSince1970 ?? 0)" }
    }
    @Published var target: Target?
    /// Открыть камеру для текущей пары
    @Published var camera = false
}

// MARK: - Экран пары с фото

/// Готовые миниатюры — чтобы при прокрутке не декодировать фото заново
enum ThumbCache {
    static let shared: NSCache<NSString, UIImage> = {
        let c = NSCache<NSString, UIImage>()
        c.countLimit = 300
        return c
    }()
}

/// Миниатюра без загрузки полного снимка в память
struct BoardThumb: View {
    let url: URL
    var corner: CGFloat = 12
    @State private var image: UIImage?

    var body: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.07))
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: "photo").foregroundStyle(.tertiary)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
            .task(id: url) {
                let key = url.path as NSString
                if let hit = ThumbCache.shared.object(forKey: key) { image = hit; return }
                let u = url
                let thumb = await Task.detached(priority: .utility) {
                    UIImage(contentsOfFile: u.path)?.preparingThumbnail(of: CGSize(width: 360, height: 360))
                }.value
                if let thumb { ThumbCache.shared.setObject(thumb, forKey: key) }
                image = thumb
            }
    }
}

/// Что отправить через окно «Поделиться» (через item — иначе SwiftUI иногда показывает пустое окно)
struct ShareItem: Identifiable {
    let id = UUID()
    let items: [Any]
}

/// Какое фото открыть в галерее
struct GalleryRef: Identifiable {
    let id = UUID()
    let shots: [BoardShot]
    let index: Int
}

// MARK: - Галерея: листать, приближать, смахнуть вниз — закрыть

struct BoardGallery: View {
    let shots: [BoardShot]
    @State var index: Int
    @Environment(\.dismiss) private var dismiss
    @State private var drag: CGFloat = 0
    @State private var zoomed = false
    @State private var chrome = true
    @State private var share: ShareItem?

    private var progress: CGFloat { min(1, abs(drag) / 300) }

    var body: some View {
        ZStack {
            Color.black.opacity(1 - progress * 0.8).ignoresSafeArea()

            TabView(selection: $index) {
                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                    ZoomableShot(url: s.url, zoomed: $zoomed)
                        .tag(i)
                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { chrome.toggle() } }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            .offset(y: drag)
            .scaleEffect(1 - progress * 0.15)
            .simultaneousGesture(
                DragGesture(minimumDistance: 20)
                    .onChanged { v in
                        guard !zoomed, abs(v.translation.height) > abs(v.translation.width) else { return }
                        drag = v.translation.height
                    }
                    .onEnded { v in
                        guard !zoomed else { return }
                        if abs(drag) > 120 || abs(v.predictedEndTranslation.height) > 400 {
                            dismiss()
                        } else {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) { drag = 0 }
                        }
                    }
            )

            if chrome && drag == 0 {
                VStack {
                    HStack(spacing: 12) {
                        Button { dismiss() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        Spacer()
                        if shots.indices.contains(index) {
                            VStack(spacing: 1) {
                                Text("\(index + 1) из \(shots.count)").font(.subheadline.weight(.bold))
                                Text(Fmt.formatter("d MMMM, HH:mm").string(from: shots[index].date)).font(.caption2)
                            }
                            .foregroundStyle(.white)
                        }
                        Spacer()
                        Button {
                            if shots.indices.contains(index) { share = ShareItem(items: [shots[index].url]) }
                        } label: {
                            Image(systemName: "square.and.arrow.up").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                    }
                    .padding(.horizontal, 16)
                    Spacer()
                    // полоска миниатюр — прыгнуть к любому фото
                    ScrollViewReader { proxy in
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 6) {
                                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                                    BoardThumb(url: s.url, corner: 7)
                                        .frame(width: i == index ? 52 : 40, height: 40)
                                        .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Color.white.opacity(i == index ? 0.9 : 0), lineWidth: 2))
                                        .id(i)
                                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { index = i } }
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                        .onChange(of: index) { i in withAnimation { proxy.scrollTo(i, anchor: .center) } }
                        .onAppear { proxy.scrollTo(index, anchor: .center) }
                    }
                    .padding(.bottom, 8)
                }
                .transition(.opacity)
            }
        }
        .statusBarHidden(!chrome)
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .onChange(of: index) { _ in zoomed = false }
    }
}

/// Одно фото с приближением щипком и двойным тапом
struct ZoomableShot: View {
    let url: URL
    @Binding var zoomed: Bool
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .offset(offset)
                        .frame(width: geo.size.width, height: geo.size.height)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { v in scale = max(1, min(5, base * v)) }
                                .onEnded { _ in
                                    base = scale
                                    if scale <= 1.01 { reset() } else { zoomed = true }
                                }
                        )
                        .simultaneousGesture(
                            DragGesture()
                                .onChanged { v in
                                    guard scale > 1 else { return }
                                    offset = CGSize(width: lastOffset.width + v.translation.width,
                                                    height: lastOffset.height + v.translation.height)
                                }
                                .onEnded { _ in lastOffset = offset },
                            including: scale > 1 ? .all : .subviews
                        )
                        .onTapGesture(count: 2) {
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                if scale > 1 { reset() } else { scale = 2.5; base = 2.5; zoomed = true }
                            }
                        }
                } else {
                    ProgressView().tint(.white)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .task(id: url) {
            let u = url
            image = await Task.detached(priority: .userInitiated) {
                LessonPhotosPDF.downscaled(u, maxSide: 2600)
            }.value
        }
    }

    private func reset() {
        scale = 1; base = 1; offset = .zero; lastOffset = .zero; zoomed = false
    }
}

// MARK: - Экран пары с фото

struct BoardBatchView: View {
    @State var batch: BoardBatch
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var gallery: GalleryRef?
    @State private var share: ShareItem?
    @State private var camera = false
    @State private var toDelete: BoardShot?

    private func reload() {
        let all = LessonPhotos.batches(subject: batch.subject, data: schedule.data)
        if let b = all.first(where: { $0.id == batch.id }) { batch = b }
        else if let slot = batch.slot, let b = LessonPhotos.batch(for: slot, data: schedule.data) { batch = b }
        else { batch = BoardBatch(subject: batch.subject, slot: batch.slot, day: batch.day, shots: []) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(batch.subject)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text("\(batch.title) · \(batch.countText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(SubjectColor.color(for: batch.subject).opacity(0.15),
                            in: RoundedRectangle(cornerRadius: 22, style: .continuous))

                HStack(spacing: 10) {
                    bigButton("Отправить PDF", "doc.richtext.fill", primary: true) {
                        if let pdf = LessonPhotosPDF.make(batch) { share = ShareItem(items: [pdf]) }
                    }
                    bigButton("Фото по порядку", "photo.stack.fill") {
                        let copies = LessonPhotosPDF.numberedCopies(batch)
                        if !copies.isEmpty { share = ShareItem(items: copies) }
                    }
                }
                .disabled(batch.shots.isEmpty)

                bigButton("Сфоткать ещё", "camera.fill") { camera = true }

                if batch.shots.isEmpty {
                    Text("Фото этой пары пока нет.").font(.subheadline).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8),
                                    GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                        Button { gallery = GalleryRef(shots: batch.shots, index: i) } label: {
                            BoardThumb(url: s.url, corner: 12)
                                .aspectRatio(1, contentMode: .fit)
                                .overlay(alignment: .topLeading) {
                                    Text("\(i + 1)")
                                        .font(.caption2.weight(.heavy))
                                        .foregroundStyle(.white)
                                        .frame(width: 20, height: 20)
                                        .background(Color.brand, in: Circle())
                                        .padding(5)
                                }
                                .overlay(alignment: .bottomTrailing) {
                                    Text(Fmt.formatter("HH:mm").string(from: s.date))
                                        .font(.system(size: 9, weight: .bold))
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 5).padding(.vertical, 2)
                                        .background(.black.opacity(0.45), in: Capsule())
                                        .padding(5)
                                }
                        }
                        .buttonStyle(PressableStyle())
                        .contextMenu {
                            Button { share = ShareItem(items: [s.url]) } label: {
                                Label("Отправить это фото", systemImage: "square.and.arrow.up")
                            }
                            Button(role: .destructive) { toDelete = s } label: { Label("Удалить", systemImage: "trash") }
                        }
                    }
                }
                Text("Нажми на фото — откроется галерея: листай вбок, приближай щипком, смахни вниз, чтобы закрыть. Порядок — по времени съёмки.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Фото пары")
        .navigationBarTitleDisplayMode(.inline)
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { image in
                camera = false
                if let image, BoardPhoto.save(image, subject: batch.subject) != nil {
                    Haptics.success()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { reload() }
                }
            }
            .ignoresSafeArea()
        }
        .confirmationDialog("Удалить фото?", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } }),
                            titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let s = toDelete { try? FileManager.default.removeItem(at: s.url) }
                toDelete = nil
                BoardIndex.shared.prune()
                reload()
            }
        }
        .onAppear { reload() }
    }

    private func bigButton(_ title: String, _ icon: String, primary: Bool = false, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(primary ? Color.white : Color.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background {
                    if primary {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(brandGradient)
                    } else {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.primary.opacity(0.08))
                    }
                }
        }
        .buttonStyle(PressableStyle())
    }
}

/// Обычное окно «Поделиться» (для нескольких файлов сразу)
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Строка пары с фото: полоска миниатюр. Если задан onShot — миниатюры открывают галерею
struct BoardBatchRow: View {
    let batch: BoardBatch
    var showSubject = false
    var onShot: ((Int) -> Void)? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(showSubject ? batch.subject : batch.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(showSubject ? "\(batch.title) · \(batch.countText)" : batch.countText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(Array(batch.shots.prefix(20).enumerated()), id: \.element.id) { i, s in
                        BoardThumb(url: s.url, corner: 9)
                            .frame(width: 64, height: 48)
                            .onTapGesture { onShot?(i) }
                    }
                }
            }
            .allowsHitTesting(onShot != nil)
        }
        .contentShape(Rectangle())
    }
}

/// Все пары с фото одного предмета (или всех, если subject == nil)
struct BoardBatchesList: View {
    let subject: String?
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var list: [BoardBatch] = []

    var body: some View {
        List {
            if list.isEmpty {
                Text("Фото доски пока нет. Снимай прямо на паре — кнопка камеры есть на главной, в карточке пары, на экране блокировки и на странице предмета.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            ForEach(list) { b in
                NavigationLink {
                    BoardBatchView(batch: b)
                } label: {
                    BoardBatchRow(batch: b, showSubject: subject == nil)
                }
            }
        }
        .navigationTitle(subject == nil ? "Фото с пар" : "Фото доски")
        .onAppear {
            list = subject.map { LessonPhotos.batches(subject: $0, data: schedule.data) }
                ?? LessonPhotos.allBatches(data: schedule.data, limit: 100)
        }
    }
}

// MARK: - Карточка «Фото доски» на главной
// Свёрнута в одну строку (камера + сколько фото), по нажатию разворачивается.

struct BoardHomeCard: View {
    let data: ScheduleData
    let onCamera: (String) -> Void
    let onOpen: (BoardBatch) -> Void
    @ObservedObject private var index = BoardIndex.shared
    @AppStorage("board.card.open") private var open = false
    @State private var latest: BoardBatch?
    @State private var share: ShareItem?
    @State private var gallery: GalleryRef?

    private var slot: LessonSlot? { LessonPhotos.currentSlot(data) }

    private var summary: String {
        if let b = latest, !b.shots.isEmpty {
            let isCurrent = slot.map { b.slot?.key == $0.key } ?? false
            return (isCurrent ? "эта пара" : b.shortDate) + " · " + b.countText
        }
        return slot != nil ? "сфоткай доску этой пары" : "фото пока нет"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // строка-заголовок: всегда видна
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "camera.viewfinder")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(brandGradient)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Фото доски").font(.system(.subheadline, design: .rounded).weight(.bold)).foregroundStyle(.primary)
                            Text(summary).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        if index.working > 0 { ProgressView().controlSize(.small) }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                if let slot {
                    Button {
                        Haptics.tap()
                        onCamera(slot.lesson.subject)
                    } label: {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 34, height: 34)
                            .background(brandGradient, in: Circle())
                    }
                    .buttonStyle(PressableStyle())
                }
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(open ? 180 : 0))
                        .frame(width: 30, height: 30)
                        .background(Color.primary.opacity(0.07), in: Circle())
                }
                .buttonStyle(.plain)
            }

            if open {
                VStack(alignment: .leading, spacing: 12) {
                    if let b = latest, !b.shots.isEmpty {
                        // миниатюра — галерея, остальная строка — экран пары
                        BoardBatchRow(batch: b, showSubject: true) { i in
                            gallery = GalleryRef(shots: b.shots, index: i)
                        }
                        .onTapGesture { onOpen(b) }
                        Button {
                            if let pdf = LessonPhotosPDF.make(b) { share = ShareItem(items: [pdf]) }
                        } label: {
                            Label("Отправить ребятам PDF (\(b.shots.count))", systemImage: "paperplane.fill")
                                .font(.subheadline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(PressableStyle())
                    } else {
                        Text("На паре нажми на камеру — фото лягут в папку предмета по порядку, а после пары их можно одним PDF отправить группе. Кнопка камеры есть и на экране блокировки.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .glass(22)
        .onAppear { refresh() }
        .onChange(of: index.entries.count) { _ in refresh() }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
    }

    private func refresh() {
        if let slot, let b = LessonPhotos.batch(for: slot, data: data) {
            latest = b
        } else {
            latest = LessonPhotos.allBatches(data: data, limit: 1).first
        }
    }
}
