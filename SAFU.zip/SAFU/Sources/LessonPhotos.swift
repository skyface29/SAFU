import SwiftUI
import UIKit
import UserNotifications
import ImageIO
import UniformTypeIdentifiers
import PhotosUI

// MARK: - Фото доски по парам
// Снимки доски группируются по парам и идут строго по времени: раньше снято — раньше стоит.
// После пары их можно одним PDF (или фотками по порядку) отправить в чат группы.

struct BoardShot: Identifiable, Hashable {
    let url: URL
    let date: Date
    var id: String { url.path }
}

struct BoardBatch: Identifiable, Hashable {
    let subject: String
    let slot: LessonSlot?
    let day: Date
    let shots: [BoardShot]

    var id: String { subject + "|" + (slot?.key ?? "\(Int(day.timeIntervalSince1970))") }
    var start: Date { slot?.start ?? shots.first?.date ?? day }

    var title: String {
        let d = Fmt.formatter("EE, d MMMM").string(from: start)
        if let slot {
            let pair = slot.lesson.pair > 0 ? L("\(slot.lesson.pair) пара · ") : ""
            return "\(d.capitalizedFirst) · \(pair)\(Fmt.formatter("HH:mm").string(from: slot.start))"
        }
        return d.capitalizedFirst
    }

    var shortDate: String { Fmt.formatter("dd.MM").string(from: start) }
    var countText: String { LessonPhotos.photosWord(shots.count) }
}

/// Предмет на экране «Фото доски»
struct BoardSubjectSummary: Identifiable, Hashable {
    let subject: String
    let photos: Int
    let days: Int
    let latest: BoardShot?
    var id: String { subject }

    /// «сегодня», «вчера», «12 окт»
    var lastText: String {
        guard let d = latest?.date else { return "" }
        let cal = Calendar.current
        if cal.isDateInToday(d) { return L("сегодня") }
        if cal.isDateInYesterday(d) { return L("вчера") }
        return Fmt.formatter("d MMM").string(from: d)
    }
}

enum LessonPhotos {
    static let imageExt: Set<String> = ["jpg", "jpeg", "png", "heic"]

    static func photosWord(_ n: Int) -> String { L("\(n) фото") }

    /// Время съёмки: из названия «Доска 26.09 12-10-05», потом из индекса досок, потом дата создания файла
    static func captureDate(_ url: URL, subject: String) -> Date {
        let name = url.deletingPathExtension().lastPathComponent
        if let d = dateFromName(name) { return d }
        // индекс досок живёт на главном потоке — из фона его не трогаем
        if Thread.isMainThread, let e = BoardIndex.shared.entries.first(where: { $0.subject == subject && $0.name == url.lastPathComponent }) {
            return e.date
        }
        let v = try? url.resourceValues(forKeys: [.creationDateKey, .contentModificationDateKey])
        return v?.creationDate ?? v?.contentModificationDate ?? Date.distantPast
    }

    /// «Доска 26.09 12-10» или «Доска 26.09 12-10-05», иногда с « (2)» в конце.
    /// Регулярка собирается один раз — раньше на каждое фото при каждом показе списка
    private static let nameRegex = try? NSRegularExpression(
        pattern: #"(\d{2})\.(\d{2}) (\d{2})-(\d{2})(?:-(\d{2}))?(?: \((\d+)\))?"#)

    private static func dateFromName(_ name: String) -> Date? {
        guard let re = nameRegex,
              let m = re.firstMatch(in: name, range: NSRange(name.startIndex..., in: name)) else { return nil }
        func g(_ i: Int) -> Int? {
            guard let r = Range(m.range(at: i), in: name) else { return nil }
            return Int(name[r])
        }
        guard let day = g(1), let month = g(2), let hour = g(3), let minute = g(4) else { return nil }
        let cal = Calendar.current
        var c = DateComponents()
        c.year = cal.component(.year, from: Date())
        c.month = month; c.day = day; c.hour = hour; c.minute = minute
        c.second = g(5) ?? 0
        guard var d = cal.date(from: c) else { return nil }
        // снимок из прошлого года (январь смотрит на декабрьские фото)
        if d > Date().addingTimeInterval(86400) { d = cal.date(byAdding: .year, value: -1, to: d) ?? d }
        // копии с одинаковой минутой — по номеру «(2)», «(3)»
        if let n = g(6) { d = d.addingTimeInterval(Double(n) * 0.001) }
        return d
    }

    static func isBoardPhoto(_ url: URL) -> Bool {
        imageExt.contains(url.pathExtension.lowercased()) && url.lastPathComponent.hasPrefix("Доска")
    }

    /// Все фото доски предмета по времени (раньше — первее)
    static func shots(subject: String) -> [BoardShot] {
        let dir = SubjectFolders.url(subject)
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.creationDateKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles])) ?? []
        return urls.filter(isBoardPhoto)
            .map { BoardShot(url: $0, date: captureDate($0, subject: subject)) }
            .sorted { $0.date < $1.date }
    }

    /// Пара, во время которой (или сразу после) сделан снимок
    static func slot(for date: Date, subject: String, data: ScheduleData) -> LessonSlot? {
        let day = Calendar.current.startOfDay(for: date)
        return ScheduleEngine.slots(on: day, data: data).first {
            $0.lesson.subject == subject && date >= $0.start.addingTimeInterval(-15 * 60) && date <= $0.end.addingTimeInterval(30 * 60)
        }
    }

    /// Снимки предмета, собранные по парам: новые пары сверху, внутри пары — по времени
    static func batches(subject: String, data: ScheduleData) -> [BoardBatch] {
        var groups: [String: (slot: LessonSlot?, day: Date, shots: [BoardShot])] = [:]
        for s in shots(subject: subject) {
            let sl = slot(for: s.date, subject: subject, data: data)
            let day = Calendar.current.startOfDay(for: s.date)
            let key = sl?.key ?? "day-\(Int(day.timeIntervalSince1970))"
            var g = groups[key] ?? (slot: sl, day: day, shots: [])
            g.shots.append(s)
            groups[key] = g
        }
        return groups.values.map { BoardBatch(subject: subject, slot: $0.slot, day: $0.day, shots: $0.shots) }
            .sorted { $0.start > $1.start }
    }

    /// Все пары с фото по всем предметам (для главной и «Досок»)
    static func allBatches(data: ScheduleData, limit: Int = 30) -> [BoardBatch] {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: SubjectFolders.base, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
        // папка называется почти как предмет (без «/» и «:») — возвращаем настоящее название из расписания,
        // иначе фото не находили свою пару
        var real: [String: String] = [:]
        for s in ScheduleQuery.subjects(data) { real[SubjectFolders.url(s).lastPathComponent] = s }
        return dirs
            .filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
            .flatMap { batches(subject: real[$0.lastPathComponent] ?? $0.lastPathComponent, data: data) }
            .sorted { $0.start > $1.start }
            .prefix(limit).map { $0 }
    }

    /// Фото предмета по дням: все снимки дня вместе (две пары подряд — один день), новые дни сверху
    static func dayBatches(subject: String, data: ScheduleData) -> [BoardBatch] {
        let cal = Calendar.current
        var order: [Date] = []
        var map: [Date: [BoardShot]] = [:]
        for s in shots(subject: subject) {
            let d = cal.startOfDay(for: s.date)
            if map[d] == nil { order.append(d) }
            map[d, default: []].append(s)
        }
        return order.map { day -> BoardBatch in
            let list = (map[day] ?? []).sorted { $0.date < $1.date }
            // все снимки дня с одной пары — подпишем пару; иначе просто день
            let slots = list.map { slot(for: $0.date, subject: subject, data: data) }
            let first = slots.first ?? nil
            let one = slots.allSatisfy { $0 != nil && $0?.key == first?.key } ? first : nil
            return BoardBatch(subject: subject, slot: one, day: day, shots: list)
        }
        .sorted { $0.day > $1.day }
    }

    /// Предметы с фото доски: сколько снимков и дат, последний снимок — обложка. Свежие сверху
    static func subjectSummaries(data: ScheduleData) -> [BoardSubjectSummary] {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: SubjectFolders.base, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])) ?? []
        var real: [String: String] = [:]
        for s in ScheduleQuery.subjects(data) { real[SubjectFolders.url(s).lastPathComponent] = s }
        let cal = Calendar.current
        return dirs
            .filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true }
            .compactMap { dir -> BoardSubjectSummary? in
                let name = real[dir.lastPathComponent] ?? dir.lastPathComponent
                let list = shots(subject: name)
                guard !list.isEmpty else { return nil }
                let days = Set(list.map { cal.startOfDay(for: $0.date) }).count
                return BoardSubjectSummary(subject: name, photos: list.count, days: days, latest: list.last)
            }
            .sorted { ($0.latest?.date ?? .distantPast) > ($1.latest?.date ?? .distantPast) }
    }

    /// Пара «сейчас» для кнопки камеры: идёт, скоро начнётся или только что закончилась
    static func currentSlot(_ data: ScheduleData, at now: Date = Date()) -> LessonSlot? {
        let today = ScheduleEngine.slots(on: Calendar.current.startOfDay(for: now), data: data)
        if let s = today.first(where: { now >= $0.start.addingTimeInterval(-10 * 60) && now <= $0.end }) { return s }
        return today.last(where: { $0.end < now && now.timeIntervalSince($0.end) < 40 * 60 })
    }

    /// Фото конкретной пары
    static func batch(for slot: LessonSlot, data: ScheduleData) -> BoardBatch? {
        batches(subject: slot.lesson.subject, data: data).first { $0.slot?.key == slot.key }
    }
}

// MARK: - Разложить фото из галереи по парам
// Сфоткал доску обычной камерой — не беда: по времени съёмки приложение находит пару в расписании
// и кладёт снимок в папку её предмета, а в названии — время съёмки, чтобы он встал в свою пару по порядку.

enum BoardImport {
    private static let exifFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = .current
        f.dateFormat = "yyyy:MM:dd HH:mm:ss"
        return f
    }()

    private static let nameFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "dd.MM HH-mm-ss"
        return f
    }()

    /// Время съёмки из самого снимка (EXIF)
    static func captureDate(_ data: Data) -> Date? {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil),
              let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any] else { return nil }
        if let exif = props[kCGImagePropertyExifDictionary] as? [CFString: Any] {
            for key in [kCGImagePropertyExifDateTimeOriginal, kCGImagePropertyExifDateTimeDigitized] {
                if let s = exif[key] as? String, let d = exifFormatter.date(from: s) { return d }
            }
        }
        if let tiff = props[kCGImagePropertyTIFFDictionary] as? [CFString: Any],
           let s = tiff[kCGImagePropertyTIFFDateTime] as? String, let d = exifFormatter.date(from: s) {
            return d
        }
        return nil
    }

    /// Пара любого предмета, во время которой (или сразу после) сделан снимок
    static func slot(at date: Date, data: ScheduleData) -> LessonSlot? {
        let day = Calendar.current.startOfDay(for: date)
        return ScheduleEngine.slots(on: day, data: data).first {
            date >= $0.start.addingTimeInterval(-15 * 60) && date <= $0.end.addingTimeInterval(30 * 60)
        }
    }

    /// JPEG как есть, остальное (HEIC, PNG) — переводим в JPEG: так снимок открывается везде и уходит в PDF
    private static func jpegData(_ data: Data) -> Data? {
        guard let src = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        if let t = CGImageSourceGetType(src) as String?, t == UTType.jpeg.identifier { return data }
        let out = NSMutableData()
        guard let dst = CGImageDestinationCreateWithData(out, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        let opts: [CFString: Any] = [kCGImageDestinationLossyCompressionQuality: 0.85]
        CGImageDestinationAddImageFromSource(dst, src, 0, opts as CFDictionary)
        return CGImageDestinationFinalize(dst) ? out as Data : nil
    }

    /// Положить снимок в папку предмета, в названии — время съёмки
    @discardableResult
    static func save(_ data: Data, subject: String, date: Date) -> URL? {
        guard let jpg = jpegData(data) else { return nil }
        let dir = SubjectFolders.url(subject)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = FileService.uniqueURL(in: dir, name: L("Доска \(nameFormatter.string(from: date)).jpg"))
        do { try jpg.write(to: url, options: .atomic) } catch { return nil }
        BoardScan.process(fileAt: url, subject: subject, date: date)
        return url
    }

    /// Снимок без пары ждёт, куда его положить, во временной папке (а не в памяти)
    struct Pending: Identifiable {
        let id = UUID()
        let file: URL
        let date: Date
    }

    static func park(_ data: Data, date: Date) -> Pending? {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("board-import", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(UUID().uuidString)
        guard (try? data.write(to: url)) != nil else { return nil }
        return Pending(file: url, date: date)
    }

    static func place(_ p: Pending, subject: String) {
        if let data = try? Data(contentsOf: p.file) { save(data, subject: subject, date: p.date) }
        try? FileManager.default.removeItem(at: p.file)
    }

    static func drop(_ list: [Pending]) {
        for p in list { try? FileManager.default.removeItem(at: p.file) }
    }
}

// MARK: - Быстрая работа с фото (ImageIO)
// Уменьшенная картинка читается прямо из файла, без распаковки полного 12-Мп снимка:
// в разы быстрее и почти без расхода памяти.

enum FastImage {
    static func cgThumbnail(_ url: URL, maxPixel: CGFloat) -> CGImage? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary) else { return nil }
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,     // сразу правильный поворот
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel,
        ]
        return CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary)
    }

    static func image(_ url: URL, maxPixel: CGFloat) -> UIImage? {
        cgThumbnail(url, maxPixel: maxPixel).map { UIImage(cgImage: $0) }
    }

    static func jpeg(_ cg: CGImage, quality: CGFloat) -> Data? {
        let data = NSMutableData()
        guard let dst = CGImageDestinationCreateWithData(data as CFMutableData, UTType.jpeg.identifier as CFString, 1, nil) else { return nil }
        CGImageDestinationAddImage(dst, cg, [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        return CGImageDestinationFinalize(dst) ? data as Data : nil
    }
}

// MARK: - PDF со всеми фото пары

enum LessonPhotosPDF {
    /// Отпечаток набора фото: те же снимки — тот же PDF, можно не собирать заново
    static func signature(_ batch: BoardBatch) -> String {
        var h = Hasher()
        h.combine(batch.subject)
        h.combine(batch.title)
        for s in batch.shots {
            h.combine(s.url.lastPathComponent)
            let m = (try? s.url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
            h.combine(m?.timeIntervalSince1970 ?? 0)
        }
        return String(UInt(bitPattern: h.finalize()), radix: 36)
    }

    private static func fileURL(_ batch: BoardBatch, signature: String) -> URL {
        let safe = batch.subject.replacingOccurrences(of: "/", with: "-").prefix(60)
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("board-pdf-\(signature)", isDirectory: true)
        return dir.appendingPathComponent("\(safe) \(batch.shortDate) — доска.pdf")
    }

    /// Уже собранный PDF для этих фото
    static func cached(_ batch: BoardBatch, signature: String) -> URL? {
        let u = fileURL(batch, signature: signature)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }

    /// Одна страница — одно фото, по порядку, с подписью «предмет · дата · 3/7».
    /// Фото кладутся в PDF готовым JPEG (без повторного сжатия PDF-движком) — быстро и компактно.
    static func make(_ batch: BoardBatch, signature: String? = nil, progress: ((Int, Int) -> Void)? = nil) -> URL? {
        let sig = signature ?? self.signature(batch)
        if let hit = cached(batch, signature: sig) { return hit }
        let url = fileURL(batch, signature: sig)
        try? FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        let tmp = url.appendingPathExtension("part")
        let pageWidth: CGFloat = 842
        let header: CGFloat = 34
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [kCGPDFContextTitle as String: "\(batch.subject) — \(batch.title)",
                               kCGPDFContextCreator as String: AppInfo.name]
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: 595), format: format)
        let timeFmt = Fmt.formatter("HH:mm")
        let attrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 13, weight: .semibold),
            .foregroundColor: UIColor.darkGray,
        ]
        let total = batch.shots.count
        do {
            try renderer.writePDF(to: tmp) { ctx in
                for (i, shot) in batch.shots.enumerated() {
                    autoreleasepool {
                        guard let cg = FastImage.cgThumbnail(shot.url, maxPixel: 2000),
                              let jpg = FastImage.jpeg(cg, quality: 0.72),
                              let provider = CGDataProvider(data: jpg as CFData),
                              let img = CGImage(jpegDataProviderSource: provider, decode: nil,
                                                shouldInterpolate: true, intent: .defaultIntent) else { return }
                        let ratio = CGFloat(img.height) / CGFloat(max(img.width, 1))
                        let page = CGRect(x: 0, y: 0, width: pageWidth, height: pageWidth * ratio + header)
                        ctx.beginPage(withBounds: page, pageInfo: [:])
                        UIColor.white.setFill()
                        UIRectFill(page)
                        let caption = "\(batch.subject) · \(batch.title) · \(timeFmt.string(from: shot.date))   \(i + 1)/\(total)"
                        (caption as NSString).draw(in: CGRect(x: 14, y: 9, width: pageWidth - 28, height: header - 10), withAttributes: attrs)
                        UIImage(cgImage: img).draw(in: CGRect(x: 0, y: header, width: pageWidth, height: pageWidth * ratio))
                    }
                    progress?(i + 1, total)
                }
            }
            try? FileManager.default.removeItem(at: url)
            try FileManager.default.moveItem(at: tmp, to: url)
            return url
        } catch {
            try? FileManager.default.removeItem(at: tmp)
            return nil
        }
    }

    /// Удаляем PDF и копии фото, оставшиеся после отправки
    static func cleanTemp() {
        let tmp = FileManager.default.temporaryDirectory
        let items = (try? FileManager.default.contentsOfDirectory(at: tmp, includingPropertiesForKeys: nil)) ?? []
        for u in items where u.lastPathComponent.hasPrefix("board-") || u.lastPathComponent.hasSuffix("— доска.pdf") {
            try? FileManager.default.removeItem(at: u)
        }
    }

    /// Фото с номерами в названии — чтобы в чате они легли по порядку.
    /// Жёсткие ссылки вместо копий: мгновенно и без лишнего места
    static func numberedCopies(_ batch: BoardBatch) -> [URL] {
        let fm = FileManager.default
        let dir = fm.temporaryDirectory.appendingPathComponent("board-\(UUID().uuidString)", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let f = Fmt.formatter("HH-mm")
        return batch.shots.enumerated().compactMap { i, s in
            let dst = dir.appendingPathComponent(String(format: "%02d %@ %@.%@", i + 1, batch.shortDate,
                                                        f.string(from: s.date), s.url.pathExtension))
            if (try? fm.linkItem(at: s.url, to: dst)) != nil { return dst }
            return (try? fm.copyItem(at: s.url, to: dst)) != nil ? dst : nil
        }
    }
}

/// Сборка PDF в фоне. Один и тот же набор не собирается дважды одновременно
actor BoardPDFBuilder {
    static let shared = BoardPDFBuilder()
    private var running: [String: Task<URL?, Never>] = [:]

    func pdf(for batch: BoardBatch, progress: (@Sendable (Int, Int) -> Void)? = nil) async -> URL? {
        let sig = LessonPhotosPDF.signature(batch)
        if let hit = LessonPhotosPDF.cached(batch, signature: sig) { return hit }
        if let t = running[sig] { return await t.value }
        let t = Task.detached(priority: .userInitiated) {
            LessonPhotosPDF.make(batch, signature: sig, progress: progress)
        }
        running[sig] = t
        let url = await t.value
        running[sig] = nil
        return url
    }

    /// Заранее, пока смотришь фото пары — к моменту «Отправить» PDF уже готов
    func prewarm(_ batch: BoardBatch) {
        guard !batch.shots.isEmpty else { return }
        let sig = LessonPhotosPDF.signature(batch)
        guard LessonPhotosPDF.cached(batch, signature: sig) == nil, running[sig] == nil else { return }
        let t = Task.detached(priority: .utility) { LessonPhotosPDF.make(batch, signature: sig) }
        running[sig] = t
        Task {
            _ = await t.value
            self.finish(sig)
        }
    }

    private func finish(_ sig: String) { running[sig] = nil }
}

// MARK: - Напоминание после пары

enum BoardReminder {
    static let subjectKey = "board.subject"
    static let startKey = "board.start"

    /// Сфоткал доску на паре — после её конца придёт «Отправь ребятам N фото»
    static func schedule(subject: String) {
        let data = SharedSchedule.load()
        guard UserDefaults.standard.object(forKey: "board.remind") as? Bool ?? true,
              let slot = LessonPhotos.slot(for: Date(), subject: subject, data: data) else { return }
        let fire = max(slot.end.addingTimeInterval(60), Date().addingTimeInterval(5))
        guard fire.timeIntervalSinceNow < 3 * 3600 else { return }
        let count = LessonPhotos.batch(for: slot, data: data)?.shots.count ?? 1
        let c = UNMutableNotificationContent()
        c.title = L("Фото с пары: \(slot.lesson.subject)")
        c.body = L("\(LessonPhotos.photosWord(count)) доски по порядку — нажми, чтобы собрать PDF и отправить ребятам")
        c.sound = .default
        c.userInfo = [subjectKey: subject, startKey: slot.start.timeIntervalSince1970]
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: fire.timeIntervalSinceNow, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "board.\(slot.key)", content: c, trigger: trigger))
    }
}

/// Какую пару с фото открыть (из уведомления или ссылки safu://board)
final class BoardRouter: ObservableObject {
    static let shared = BoardRouter()
    struct Target: Identifiable, Equatable {
        let subject: String
        let start: Date?
        var id: String { subject + "\(start?.timeIntervalSince1970 ?? 0)" }
    }
    @Published var target: Target?
    /// Открыть камеру для текущей пары
    @Published var camera = false
    /// Для какого предмета снимаем (из виджета); nil — текущая пара
    var cameraSubject: String?

    /// Предмет из виджета: закреплённые материалы, файлы, заметки
    struct SubjectLink: Identifiable { let name: String; var id: String { name } }
    @Published var subject: SubjectLink?
}

// MARK: - Экран пары с фото

/// Готовые миниатюры — чтобы при прокрутке не декодировать фото заново
enum ThumbCache {
    static let shared: NSCache<NSString, UIImage> = {
        let c = NSCache<NSString, UIImage>()
        c.countLimit = 300
        return c
    }()
}

/// Миниатюра без загрузки полного снимка в память
struct BoardThumb: View {
    let url: URL
    var corner: CGFloat = 12
    @State private var image: UIImage?
    @State private var version = 0

    var body: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.07))
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: "photo").foregroundStyle(.tertiary)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
            .task(id: "\(url.path)|\(version)") {
                // в ключе — время изменения: после выпрямления снимок перезаписывается, старая миниатюра не годится
                let mtime = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate
                let key = "\(url.path)|\(mtime?.timeIntervalSince1970 ?? 0)" as NSString
                if let hit = ThumbCache.shared.object(forKey: key) { image = hit; return }
                let u = url
                let thumb = await Task.detached(priority: .utility) {
                    FastImage.image(u, maxPixel: 360)
                }.value
                if let thumb { ThumbCache.shared.setObject(thumb, forKey: key) }
                if thumb != nil || image == nil { image = thumb }
            }
            // снимок только что дописали или выпрямили — миниатюра обновляется
            .onReceive(NotificationCenter.default.publisher(for: .boardPhotoWritten)) { n in
                if (n.object as? URL)?.path == url.path { version += 1 }
            }
    }
}

/// Что отправить через окно «Поделиться» (через item — иначе SwiftUI иногда показывает пустое окно)
struct ShareItem: Identifiable {
    let id = UUID()
    let items: [Any]
}

/// Какое фото открыть в галерее
struct GalleryRef: Identifiable {
    let id = UUID()
    let shots: [BoardShot]
    let index: Int
}

// MARK: - Галерея: листать, приближать, смахнуть вниз — закрыть

struct BoardGallery: View {
    let shots: [BoardShot]
    @State var index: Int
    @Environment(\.dismiss) private var dismiss
    @State private var drag: CGFloat = 0
    @State private var zoomed = false
    @State private var chrome = true
    @State private var share: ShareItem?

    private var progress: CGFloat { min(1, abs(drag) / 300) }

    var body: some View {
        ZStack {
            Color.black.opacity(Double(1 - progress * 0.8)).ignoresSafeArea()

            TabView(selection: $index) {
                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                    ZoomableShot(url: s.url, zoomed: $zoomed)
                        .tag(i)
                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { chrome.toggle() } }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .ignoresSafeArea()
            .offset(y: drag)
            .scaleEffect(1 - progress * 0.15)
            .simultaneousGesture(
                DragGesture(minimumDistance: 20)
                    .onChanged { v in
                        guard !zoomed, abs(v.translation.height) > abs(v.translation.width) else { return }
                        drag = v.translation.height
                    }
                    .onEnded { v in
                        guard !zoomed else { return }
                        if abs(drag) > 120 || abs(v.predictedEndTranslation.height) > 400 {
                            dismiss()
                        } else {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) { drag = 0 }
                        }
                    }
            )

            if chrome && drag == 0 {
                VStack {
                    HStack(spacing: 12) {
                        Button { dismiss() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                        Spacer()
                        if shots.indices.contains(index) {
                            VStack(spacing: 1) {
                                Text(L("\(index + 1) из \(shots.count)")).font(.subheadline.weight(.bold))
                                Text(Fmt.formatter("d MMMM, HH:mm").string(from: shots[index].date)).font(.caption2)
                            }
                            .foregroundStyle(.white)
                        }
                        Spacer()
                        Button {
                            if shots.indices.contains(index) { share = ShareItem(items: [shots[index].url]) }
                        } label: {
                            Image(systemName: "square.and.arrow.up").font(.system(size: 15, weight: .bold))
                                .foregroundStyle(.white).frame(width: 38, height: 38)
                                .background(.ultraThinMaterial, in: Circle())
                        }
                    }
                    .padding(.horizontal, 16)
                    Spacer()
                    // полоска миниатюр — прыгнуть к любому фото
                    ScrollViewReader { proxy in
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 6) {
                                ForEach(Array(shots.enumerated()), id: \.element.id) { i, s in
                                    BoardThumb(url: s.url, corner: 7)
                                        .frame(width: i == index ? 52 : 40, height: 40)
                                        .overlay(RoundedRectangle(cornerRadius: 7).strokeBorder(Color.white.opacity(i == index ? 0.9 : 0), lineWidth: 2))
                                        .id(i)
                                        .onTapGesture { withAnimation(.easeOut(duration: 0.2)) { index = i } }
                                }
                            }
                            .padding(.horizontal, 16)
                        }
                        .onChange(of: index) { i in withAnimation { proxy.scrollTo(i, anchor: .center) } }
                        .onAppear { proxy.scrollTo(index, anchor: .center) }
                    }
                    .padding(.bottom, 8)
                }
                .transition(.opacity)
            }
        }
        .statusBarHidden(!chrome)
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .onChange(of: index) { _ in zoomed = false }
    }
}

/// Одно фото с приближением щипком и двойным тапом
struct ZoomableShot: View {
    let url: URL
    @Binding var zoomed: Bool
    @State private var image: UIImage?
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { geo in
            ZStack {
                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .offset(offset)
                        .frame(width: geo.size.width, height: geo.size.height)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { v in scale = max(1, min(5, base * v)) }
                                .onEnded { _ in
                                    base = scale
                                    if scale <= 1.01 { reset() } else { zoomed = true }
                                }
                        )
                        .simultaneousGesture(
                            DragGesture()
                                .onChanged { v in
                                    guard scale > 1 else { return }
                                    offset = CGSize(width: lastOffset.width + v.translation.width,
                                                    height: lastOffset.height + v.translation.height)
                                }
                                .onEnded { _ in lastOffset = offset },
                            including: scale > 1 ? .all : .subviews
                        )
                        .onTapGesture(count: 2) {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.8)) {
                                if scale > 1 { reset() } else { scale = 2.5; base = 2.5; zoomed = true }
                            }
                        }
                } else {
                    ProgressView().tint(.white)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .task(id: url) {
            let u = url
            image = await Task.detached(priority: .userInitiated) {
                FastImage.image(u, maxPixel: 2600)
            }.value
        }
    }

    private func reset() {
        scale = 1; base = 1; offset = .zero; lastOffset = .zero; zoomed = false
    }
}

// MARK: - Экран пары с фото

struct BoardBatchView: View {
    @State var batch: BoardBatch
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var gallery: GalleryRef?
    @State private var share: ShareItem?
    @State private var camera = false
    @State private var toDelete: BoardShot?
    /// Идёт сборка: «Собираю PDF… 5 из 24»
    @State private var working: String?

    private func sendPDF() {
        guard working == nil else { return }
        let b = batch
        working = L("Собираю PDF…")
        Task {
            let url = await BoardPDFBuilder.shared.pdf(for: b) { i, n in
                Task { @MainActor in working = L("Собираю PDF… \(i) из \(n)") }
            }
            working = nil
            if let url { share = ShareItem(items: [url]) }
        }
    }

    private func sendPhotos() {
        guard working == nil else { return }
        let b = batch
        working = L("Готовлю фото…")
        Task {
            let copies = await Task.detached(priority: .userInitiated) { LessonPhotosPDF.numberedCopies(b) }.value
            working = nil
            if !copies.isEmpty { share = ShareItem(items: copies) }
        }
    }

    private func reload() {
        // открыли день целиком (из списка дат) — все снимки этого дня
        if batch.slot == nil {
            let cal = Calendar.current
            batch = LessonPhotos.dayBatches(subject: batch.subject, data: schedule.data)
                .first { cal.isDate($0.day, inSameDayAs: batch.day) }
                ?? BoardBatch(subject: batch.subject, slot: nil, day: batch.day, shots: [])
            return
        }
        let all = LessonPhotos.batches(subject: batch.subject, data: schedule.data)
        if let b = all.first(where: { $0.id == batch.id }) { batch = b }
        else if let slot = batch.slot, let b = LessonPhotos.batch(for: slot, data: schedule.data) { batch = b }
        else { batch = BoardBatch(subject: batch.subject, slot: batch.slot, day: batch.day, shots: []) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(batch.subject)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text("\(batch.title) · \(batch.countText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(SubjectColor.color(for: batch.subject).opacity(0.15),
                            in: RoundedRectangle(cornerRadius: 22, style: .continuous))

                HStack(spacing: 10) {
                    bigButton(L("Отправить PDF"), "doc.richtext.fill", primary: true) { sendPDF() }
                    bigButton(L("Фото по порядку"), "photo.stack.fill") { sendPhotos() }
                }
                .disabled(batch.shots.isEmpty || working != nil)

                bigButton(L("Сфоткать ещё"), "camera.fill") { camera = true }

                if batch.shots.isEmpty {
                    Text(L("Фото этой пары пока нет.")).font(.subheadline).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8),
                                    GridItem(.flexible(), spacing: 8)], spacing: 8) {
                    ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                        Button { gallery = GalleryRef(shots: batch.shots, index: i) } label: {
                            BoardThumb(url: s.url, corner: 12)
                                .aspectRatio(1, contentMode: .fit)
                                .overlay(alignment: .topLeading) {
                                    Text("\(i + 1)")
                                        .font(.caption2.weight(.heavy))
                                        .foregroundStyle(.white)
                                        .frame(width: 20, height: 20)
                                        .background(Color.brand, in: Circle())
                                        .padding(5)
                                }
                                .overlay(alignment: .bottomTrailing) {
                                    Text(Fmt.formatter("HH:mm").string(from: s.date))
                                        .font(.system(size: 9, weight: .bold))
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 5).padding(.vertical, 2)
                                        .background(.black.opacity(0.45), in: Capsule())
                                        .padding(5)
                                }
                        }
                        .buttonStyle(PressableStyle())
                        .contextMenu {
                            Button { share = ShareItem(items: [s.url]) } label: {
                                Label(L("Отправить это фото"), systemImage: "square.and.arrow.up")
                            }
                            Button(role: .destructive) { toDelete = s } label: { Label(L("Удалить"), systemImage: "trash") }
                        }
                    }
                }
                Text(L("Нажми на фото — откроется галерея: листай вбок, приближай щипком, смахни вниз, чтобы закрыть. Порядок — по времени съёмки."))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
            .pausesAmbientWhileScrolling()
        .navigationTitle(batch.slot == nil ? BoardDates.dayTitle(batch.day) : L("Фото пары"))
        .navigationBarTitleDisplayMode(.inline)
        .overlay {
            if let working {
                ProgressOverlay(text: working)
            }
        }
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { image in
                camera = false
                if let image, BoardPhoto.save(image, subject: batch.subject) != nil {
                    Haptics.success()
                    reload()
                }
            }
            .ignoresSafeArea()
        }
        .confirmationDialog(L("Удалить фото?"), isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } }),
                            titleVisibility: .visible) {
            Button(L("Удалить"), role: .destructive) {
                if let s = toDelete { try? FileManager.default.removeItem(at: s.url) }
                toDelete = nil
                BoardIndex.shared.prune()
                reload()
            }
        }
        .onAppear {
            reload()
            // PDF собирается заранее в фоне — к нажатию «Отправить» он уже готов
            let b = batch
            Task { await BoardPDFBuilder.shared.prewarm(b) }
        }
        // новый снимок записан (или выпрямлен) — сразу в сетке
        .onReceive(NotificationCenter.default.publisher(for: .boardPhotoWritten)) { _ in reload() }
    }

    private func bigButton(_ title: String, _ icon: String, primary: Bool = false, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(primary ? Color.white : Color.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background {
                    if primary {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(brandGradient)
                    } else {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.primary.opacity(0.08))
                    }
                }
        }
        .buttonStyle(PressableStyle())
    }
}

/// Плашка «идёт работа» поверх экрана
struct ProgressOverlay: View {
    let text: String
    var body: some View {
        VStack(spacing: 10) {
            ProgressView().controlSize(.large)
            Text(text).font(.subheadline.weight(.semibold)).monospacedDigit()
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 20)
        .glass(22)
        .transition(.opacity.combined(with: .scale(scale: 0.95)))
    }
}

/// Обычное окно «Поделиться» (для нескольких файлов сразу)
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Строка пары с фото: полоска миниатюр. Если задан onShot — миниатюры открывают галерею
struct BoardBatchRow: View {
    let batch: BoardBatch
    var showSubject = false
    var onShot: ((Int) -> Void)? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(showSubject ? batch.subject : batch.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(showSubject ? "\(batch.title) · \(batch.countText)" : batch.countText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
            // все фото по порядку; полоска сама доезжает до самых новых
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    LazyHStack(spacing: 6) {
                        ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                            BoardThumb(url: s.url, corner: 9)
                                .frame(width: 64, height: 48)
                                .id(s.id)
                                .onTapGesture { onShot?(i) }
                        }
                    }
                }
                .frame(height: 48)
                .onAppear { if let last = batch.shots.last { proxy.scrollTo(last.id, anchor: .trailing) } }
                .onChange(of: batch.shots.count) { _ in
                    if let last = batch.shots.last { withAnimation { proxy.scrollTo(last.id, anchor: .trailing) } }
                }
            }
            .allowsHitTesting(onShot != nil)
        }
        .contentShape(Rectangle())
    }
}

// MARK: - Фото доски: предмет → дата → фото
//
// Главный экран — плитки предметов с обложкой (последний снимок). Нажал предмет — список дат,
// когда фотографировал доску. Нажал дату — все фото этого дня по порядку, с отправкой PDF.

/// Плитка предмета: обложка — последний снимок, под ней сколько фото и дат
struct BoardSubjectCard: View {
    let summary: BoardSubjectSummary

    var body: some View {
        let color = SubjectColor.color(for: summary.subject)
        VStack(alignment: .leading, spacing: 0) {
            ZStack(alignment: .bottomLeading) {
                if let latest = summary.latest {
                    BoardThumb(url: latest.url, corner: 0)
                } else {
                    Rectangle().fill(color.opacity(0.2))
                }
                LinearGradient(colors: [.clear, .black.opacity(0.55)], startPoint: .center, endPoint: .bottom)
                HStack(spacing: 4) {
                    Image(systemName: "photo.on.rectangle.angled")
                    Text("\(summary.photos)").monospacedDigit()
                }
                .font(.caption2.weight(.bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 8).padding(.vertical, 4)
                .background(.black.opacity(0.35), in: Capsule())
                .padding(8)
            }
            .aspectRatio(4 / 3, contentMode: .fit)
            .clipped()

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Circle().fill(color).frame(width: 8, height: 8)
                    Text(summary.subject)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                }
                Text("\(summary.days) \(HWText.plural(summary.days, L("дата"), L("даты"), L("дат"))) · \(summary.lastText)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .padding(10)
            .frame(maxWidth: .infinity, minHeight: 64, alignment: .topLeading)
        }
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).strokeBorder(color.opacity(0.35), lineWidth: 1))
        .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

/// Строка даты: стопка из последних снимков дня, дата и пара
struct BoardDayRow: View {
    let batch: BoardBatch

    var body: some View {
        HStack(spacing: 14) {
            // стопка карточек: до трёх снимков дня веером
            ZStack {
                ForEach(Array(batch.shots.suffix(3).enumerated()), id: \.element.id) { i, s in
                    let depth = Double(min(batch.shots.count, 3) - 1 - i)
                    BoardThumb(url: s.url, corner: 10)
                        .frame(width: 58, height: 58)
                        .overlay(RoundedRectangle(cornerRadius: 10, style: .continuous).strokeBorder(.white.opacity(0.8), lineWidth: 1.5))
                        .shadow(color: .black.opacity(0.15), radius: 2, y: 1)
                        .rotationEffect(.degrees(depth * -6))
                        .offset(x: depth * -3, y: depth * -2)
                }
            }
            .frame(width: 66, height: 64)

            VStack(alignment: .leading, spacing: 3) {
                Text(BoardDates.dayTitle(batch.day))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 4)
        }
        .padding(.vertical, 4)
    }

    private var subtitle: String {
        var parts: [String] = []
        if let slot = batch.slot {
            if slot.lesson.pair > 0 { parts.append(L("\(slot.lesson.pair) пара")) }
            parts.append(Fmt.formatter("HH:mm").string(from: slot.start))
        } else if let first = batch.shots.first, let last = batch.shots.last {
            let f = Fmt.formatter("HH:mm")
            let a = f.string(from: first.date), b = f.string(from: last.date)
            parts.append(a == b ? a : "\(a)–\(b)")
        }
        parts.append(batch.countText)
        return parts.joined(separator: " · ")
    }
}

enum BoardDates {
    static func dayTitle(_ d: Date) -> String {
        let cal = Calendar.current
        if cal.isDateInToday(d) { return L("Сегодня") }
        if cal.isDateInYesterday(d) { return L("Вчера") }
        let sameYear = cal.component(.year, from: d) == cal.component(.year, from: Date())
        return Fmt.formatter(sameYear ? "EEEE, d MMMM" : "EEEE, d MMMM yyyy").string(from: d).capitalizedFirst
    }

    static func monthTitle(_ d: Date) -> String {
        Fmt.formatter("LLLL yyyy").string(from: d).capitalizedFirst
    }
}

/// Даты одного предмета: нажал дату — все фото этого дня
struct BoardDatesView: View {
    let subject: String
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var days: [BoardBatch] = []
    @State private var loaded = false

    private struct Month: Identifiable {
        let title: String
        let days: [BoardBatch]
        var id: String { title }
    }

    private var months: [Month] {
        var order: [String] = []
        var map: [String: [BoardBatch]] = [:]
        for b in days {
            let t = BoardDates.monthTitle(b.day)
            if map[t] == nil { order.append(t) }
            map[t, default: []].append(b)
        }
        return order.map { Month(title: $0, days: map[$0] ?? []) }
    }

    var body: some View {
        let color = SubjectColor.color(for: subject)
        List {
            Section {
                HStack(spacing: 12) {
                    Image(systemName: "camera.viewfinder")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(color.gradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(subject).font(.headline).lineLimit(2)
                        let photos = days.reduce(0) { $0 + $1.shots.count }
                        Text(loaded ? L("\(photos) фото · \(days.count) \(HWText.plural(days.count, L("дата"), L("даты"), L("дат")))") : L("Считаю…"))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .monospacedDigit()
                    }
                }
                .padding(.vertical, 4)
            }

            if !loaded {
                HStack { Spacer(); ProgressView(); Spacer() }
                    .listRowBackground(Color.clear)
            } else if days.isEmpty {
                Text(L("Фото доски по этому предмету пока нет. Снимай прямо на паре — или нажми «Из галереи» вверху."))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(months) { m in
                    Section(m.title) {
                        ForEach(m.days) { b in
                            NavigationLink {
                                BoardBatchView(batch: b)
                            } label: {
                                BoardDayRow(batch: b)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(subject)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { Task { await load() } }
        .refreshable { await load() }
        .onReceive(NotificationCenter.default.publisher(for: .boardPhotoWritten)) { _ in Task { await load() } }
        .boardImport(subject: subject) { await load() }
    }

    /// Обход папки — в фоне: экран открывается сразу
    private func load() async {
        let data = schedule.data
        let s = subject
        let result = await Task.detached(priority: .userInitiated) {
            LessonPhotos.dayBatches(subject: s, data: data)
        }.value
        withAnimation(.easeInOut(duration: 0.2)) {
            days = result
            loaded = true
        }
    }
}

// MARK: - Фото из галереи — по предметам и парам

extension View {
    /// Кнопка «Из галереи» в шапке: снимки сами раскладываются по предметам и парам по времени съёмки.
    /// subject — сразу в этот предмет
    func boardImport(subject: String?, reload: @escaping () async -> Void) -> some View {
        modifier(BoardImportTools(subject: subject, reload: reload))
    }
}

private struct BoardImportTools: ViewModifier {
    let subject: String?
    let reload: () async -> Void
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var importItems: [PhotosPickerItem] = []
    @State private var importing: String?
    @State private var importNote: String?
    @State private var pending: [BoardImport.Pending] = []
    @State private var askPlace = false

    func body(content: Content) -> some View {
        content
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    PhotosPicker(selection: $importItems, maxSelectionCount: 60, matching: .images,
                                 preferredItemEncoding: .current) {
                        Label(L("Из галереи"), systemImage: "photo.badge.plus")
                    }
                    .disabled(importing != nil)
                }
            }
            .onChange(of: importItems) {
                guard !importItems.isEmpty else { return }
                let items = importItems
                importItems = []
                Task { await importPhotos(items) }
            }
            .overlay {
                if let importing { ProgressOverlay(text: importing) }
            }
            .alert(L("Фото разложены"), isPresented: Binding(get: { importNote != nil }, set: { if !$0 { importNote = nil } })) {
                Button("OK", role: .cancel) {
                    // остались снимки без пары — следом спросим, куда их положить
                    if !pending.isEmpty {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { askPlace = true }
                    }
                }
            } message: {
                Text(importNote ?? "")
            }
            .confirmationDialog(L("Куда положить \(pending.count) фото?"), isPresented: $askPlace, titleVisibility: .visible) {
                ForEach(ScheduleQuery.subjects(schedule.data), id: \.self) { s in
                    Button(s) { placePending(in: s) }
                }
                Button(L("Не сохранять"), role: .destructive) {
                    BoardImport.drop(pending)
                    pending = []
                }
            } message: {
                Text(L("В это время пар не было (или у снимка нет даты). Выбери предмет — фото лягут в его папку по времени съёмки."))
            }
    }

    /// Фото из галереи: время съёмки → пара → папка предмета. Без пары — спросим предмет
    private func importPhotos(_ items: [PhotosPickerItem]) async {
        let data = schedule.data
        let fixed = subject
        var placed = 0
        var subjectsHit = Set<String>()
        var left: [BoardImport.Pending] = []
        for (i, item) in items.enumerated() {
            importing = L("Раскладываю фото… \(i + 1) из \(items.count)")
            guard let raw = try? await item.loadTransferable(type: Data.self) else { continue }
            let result = await Task.detached(priority: .userInitiated) { () -> (String?, BoardImport.Pending?) in
                let date = BoardImport.captureDate(raw) ?? Date()
                let subj = fixed ?? BoardImport.slot(at: date, data: data)?.lesson.subject
                if let subj {
                    return BoardImport.save(raw, subject: subj, date: date) != nil ? (subj, nil) : (nil, nil)
                }
                return (nil, BoardImport.park(raw, date: date))
            }.value
            if let s = result.0 {
                placed += 1
                subjectsHit.insert(s)
            }
            if let p = result.1 { left.append(p) }
        }
        importing = nil
        await reload()
        if placed > 0 {
            Haptics.success()
            let n = subjectsHit.count
            importNote = fixed != nil
                ? L("\(placed) фото — в «\(fixed!)», каждое к своей дате по времени съёмки.")
                : L("\(placed) фото — по \(n) \(HWText.plural(n, L("предмету"), L("предметам"), L("предметам"))), каждое к своей дате по времени съёмки.")
                    + (left.isEmpty ? "" : L(" Ещё \(left.count) без пары — выбери для них предмет."))
        }
        if !left.isEmpty {
            pending = left
            // окно с выбором — после сообщения о разложенных
            DispatchQueue.main.asyncAfter(deadline: .now() + (placed > 0 ? 0.1 : 0)) { if importNote == nil { askPlace = true } }
        }
    }

    private func placePending(in s: String) {
        let list = pending
        pending = []
        Task {
            importing = L("Раскладываю фото…")
            await Task.detached(priority: .userInitiated) {
                for p in list { BoardImport.place(p, subject: s) }
            }.value
            importing = nil
            Haptics.success()
            await reload()
        }
    }
}

// MARK: - Карточка «Фото доски» на главной
// Свёрнута в одну строку (камера + сколько фото), по нажатию разворачивается.

struct BoardHomeCard: View {
    let data: ScheduleData
    let onCamera: (String) -> Void
    let onOpen: (BoardBatch) -> Void
    @ObservedObject private var index = BoardIndex.shared
    @AppStorage("board.card.open") private var open = false
    @State private var latest: BoardBatch?
    @State private var share: ShareItem?
    @State private var gallery: GalleryRef?
    @State private var working: String?

    private var slot: LessonSlot? { LessonPhotos.currentSlot(data) }

    private var summary: String {
        if let b = latest, !b.shots.isEmpty {
            let isCurrent = slot.map { b.slot?.key == $0.key } ?? false
            return (isCurrent ? L("эта пара") : b.shortDate) + " · " + b.countText
        }
        return slot != nil ? L("сфоткай доску этой пары") : L("фото пока нет")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // строка-заголовок: всегда видна
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "camera.viewfinder")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(brandGradient)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(L("Фото доски")).font(.system(.subheadline, design: .rounded).weight(.bold)).foregroundStyle(.primary)
                            Text(summary).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 4)
                        if index.working > 0 { ProgressView().controlSize(.small) }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                if let slot {
                    Button {
                        Haptics.tap()
                        onCamera(slot.lesson.subject)
                    } label: {
                        Image(systemName: "camera.fill")
                            .font(.system(size: 14, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 34, height: 34)
                            .background(brandGradient, in: Circle())
                    }
                    .buttonStyle(PressableStyle())
                }
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(open ? 180 : 0))
                        .frame(width: 30, height: 30)
                        .background(Color.primary.opacity(0.07), in: Circle())
                }
                .buttonStyle(.plain)
            }

            if open {
                VStack(alignment: .leading, spacing: 12) {
                    if let b = latest, !b.shots.isEmpty {
                        // миниатюра — галерея, остальная строка — экран пары
                        BoardBatchRow(batch: b, showSubject: true) { i in
                            gallery = GalleryRef(shots: b.shots, index: i)
                        }
                        .onTapGesture { onOpen(b) }
                        Button {
                            guard working == nil else { return }
                            working = L("Собираю PDF…")
                            Task {
                                let url = await BoardPDFBuilder.shared.pdf(for: b) { i, n in
                                    Task { @MainActor in working = L("Собираю PDF… \(i) из \(n)") }
                                }
                                working = nil
                                if let url { share = ShareItem(items: [url]) }
                            }
                        } label: {
                            Label(working ?? L("Отправить ребятам PDF (\(b.shots.count))"),
                                  systemImage: working == nil ? "paperplane.fill" : "hourglass")
                                .font(.subheadline.weight(.semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .buttonStyle(PressableStyle())
                    } else {
                        Text(L("На паре нажми на камеру — фото лягут в папку предмета по порядку, а после пары их можно одним PDF отправить группе. Кнопка камеры есть и на экране блокировки."))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .glass(22)
        .onAppear { refresh() }
        .onChange(of: index.entries.count) { _ in refresh() }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(item: $gallery) { g in
            BoardGallery(shots: g.shots, index: g.index)
                .presentationBackground(.clear)
        }
    }

    /// Поиск фото — в фоне, чтобы главная не подтормаживала
    private func refresh() {
        let d = data
        let current = slot
        Task {
            let b = await Task.detached(priority: .utility) { () -> BoardBatch? in
                if let current, let b = LessonPhotos.batch(for: current, data: d) { return b }
                return LessonPhotos.allBatches(data: d, limit: 1).first
            }.value
            latest = b
        }
    }
}
