import SwiftUI
import UIKit
import UserNotifications
import QuickLook

// MARK: - Фото доски по парам
// Снимки доски группируются по парам и идут строго по времени: раньше снято — раньше стоит.
// После пары их можно одним PDF (или фотками по порядку) отправить в чат группы.

struct BoardShot: Identifiable, Hashable {
    let url: URL
    let date: Date
    var id: String { url.path }
}

struct BoardBatch: Identifiable, Hashable {
    let subject: String
    let slot: LessonSlot?
    let day: Date
    let shots: [BoardShot]

    var id: String { subject + "|" + (slot?.key ?? "\(Int(day.timeIntervalSince1970))") }
    var start: Date { slot?.start ?? shots.first?.date ?? day }

    var title: String {
        let d = Fmt.formatter("EE, d MMMM").string(from: start)
        if let slot {
            let pair = slot.lesson.pair > 0 ? "\(slot.lesson.pair) пара · " : ""
            return "\(d.capitalizedFirst) · \(pair)\(Fmt.formatter("HH:mm").string(from: slot.start))"
        }
        return d.capitalizedFirst
    }

    var shortDate: String { Fmt.formatter("dd.MM").string(from: start) }
    var countText: String { LessonPhotos.photosWord(shots.count) }
}

enum LessonPhotos {
    static let imageExt: Set<String> = ["jpg", "jpeg", "png", "heic"]

    static func photosWord(_ n: Int) -> String { "\(n) фото" }

    /// Время съёмки: из названия «Доска 26.09 12-10-05», потом из индекса досок, потом дата создания файла
    static func captureDate(_ url: URL, subject: String) -> Date {
        let name = url.deletingPathExtension().lastPathComponent
        if let d = dateFromName(name) { return d }
        if let e = BoardIndex.shared.entries.first(where: { $0.subject == subject && $0.name == url.lastPathComponent }) {
            return e.date
        }
        let v = try? url.resourceValues(forKeys: [.creationDateKey, .contentModificationDateKey])
        return v?.creationDate ?? v?.contentModificationDate ?? Date.distantPast
    }

    private static func dateFromName(_ name: String) -> Date? {
        // «Доска 26.09 12-10» или «Доска 26.09 12-10-05», иногда с « (2)» в конце
        let pattern = #"(\d{2})\.(\d{2}) (\d{2})-(\d{2})(?:-(\d{2}))?(?: \((\d+)\))?"#
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: name, range: NSRange(name.startIndex..., in: name)) else { return nil }
        func g(_ i: Int) -> Int? {
            guard let r = Range(m.range(at: i), in: name) else { return nil }
            return Int(name[r])
        }
        guard let day = g(1), let month = g(2), let hour = g(3), let minute = g(4) else { return nil }
        let cal = Calendar.current
        var c = DateComponents()
        c.year = cal.component(.year, from: Date())
        c.month = month; c.day = day; c.hour = hour; c.minute = minute
        c.second = g(5) ?? 0
        guard var d = cal.date(from: c) else { return nil }
        // снимок из прошлого года (январь смотрит на декабрьские фото)
        if d > Date().addingTimeInterval(86400) { d = cal.date(byAdding: .year, value: -1, to: d) ?? d }
        // копии с одинаковой минутой — по номеру «(2)», «(3)»
        if let n = g(6) { d = d.addingTimeInterval(Double(n) * 0.001) }
        return d
    }

    static func isBoardPhoto(_ url: URL) -> Bool {
        imageExt.contains(url.pathExtension.lowercased()) && url.lastPathComponent.hasPrefix("Доска")
    }

    /// Все фото доски предмета по времени (раньше — первее)
    static func shots(subject: String) -> [BoardShot] {
        let dir = SubjectFolders.url(subject)
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: [.creationDateKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles])) ?? []
        return urls.filter(isBoardPhoto)
            .map { BoardShot(url: $0, date: captureDate($0, subject: subject)) }
            .sorted { $0.date < $1.date }
    }

    /// Пара, во время которой (или сразу после) сделан снимок
    static func slot(for date: Date, subject: String, data: ScheduleData) -> LessonSlot? {
        let day = Calendar.current.startOfDay(for: date)
        return ScheduleEngine.slots(on: day, data: data).first {
            $0.lesson.subject == subject && date >= $0.start.addingTimeInterval(-15 * 60) && date <= $0.end.addingTimeInterval(30 * 60)
        }
    }

    /// Снимки предмета, собранные по парам: новые пары сверху, внутри пары — по времени
    static func batches(subject: String, data: ScheduleData) -> [BoardBatch] {
        var groups: [String: (slot: LessonSlot?, day: Date, shots: [BoardShot])] = [:]
        for s in shots(subject: subject) {
            let sl = slot(for: s.date, subject: subject, data: data)
            let day = Calendar.current.startOfDay(for: s.date)
            let key = sl?.key ?? "day-\(Int(day.timeIntervalSince1970))"
            var g = groups[key] ?? (slot: sl, day: day, shots: [])
            g.shots.append(s)
            groups[key] = g
        }
        return groups.values.map { BoardBatch(subject: subject, slot: $0.slot, day: $0.day, shots: $0.shots) }
            .sorted { $0.start > $1.start }
    }

    /// Все пары с фото по всем предметам (для главной и «Досок»)
    static func allBatches(data: ScheduleData, limit: Int = 30) -> [BoardBatch] {
        let dirs = (try? FileManager.default.contentsOfDirectory(
            at: SubjectFolders.base, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
        return dirs.flatMap { batches(subject: $0.lastPathComponent, data: data) }
            .sorted { $0.start > $1.start }
            .prefix(limit).map { $0 }
    }

    /// Пара «сейчас» для кнопки камеры: идёт, скоро начнётся или только что закончилась
    static func currentSlot(_ data: ScheduleData, at now: Date = Date()) -> LessonSlot? {
        let today = ScheduleEngine.slots(on: Calendar.current.startOfDay(for: now), data: data)
        if let s = today.first(where: { now >= $0.start.addingTimeInterval(-10 * 60) && now <= $0.end }) { return s }
        return today.last(where: { $0.end < now && now.timeIntervalSince($0.end) < 40 * 60 })
    }

    /// Фото конкретной пары
    static func batch(for slot: LessonSlot, data: ScheduleData) -> BoardBatch? {
        batches(subject: slot.lesson.subject, data: data).first { $0.slot?.key == slot.key }
    }
}

// MARK: - PDF со всеми фото пары

enum LessonPhotosPDF {
    /// Одна страница — одно фото, по порядку, с подписью «предмет · дата · 3/7»
    static func make(_ batch: BoardBatch) -> URL? {
        let safe = batch.subject.replacingOccurrences(of: "/", with: "-").prefix(60)
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe) \(batch.shortDate) — доска.pdf")
        try? FileManager.default.removeItem(at: url)
        let pageWidth: CGFloat = 842
        let header: CGFloat = 34
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [kCGPDFContextTitle as String: "\(batch.subject) — \(batch.title)",
                               kCGPDFContextCreator as String: "САФУ"]
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: 595), format: format)
        do {
            try renderer.writePDF(to: url) { ctx in
                for (i, shot) in batch.shots.enumerated() {
                    guard let img = downscaled(shot.url, maxSide: 2200) else { continue }
                    let ratio = img.size.height / max(img.size.width, 1)
                    let h = pageWidth * ratio + header
                    let page = CGRect(x: 0, y: 0, width: pageWidth, height: h)
                    ctx.beginPage(withBounds: page, pageInfo: [:])
                    UIColor.white.setFill()
                    UIRectFill(page)
                    let time = Fmt.formatter("HH:mm").string(from: shot.date)
                    let caption = "\(batch.subject) · \(batch.title) · \(time)   \(i + 1)/\(batch.shots.count)"
                    let attrs: [NSAttributedString.Key: Any] = [
                        .font: UIFont.systemFont(ofSize: 13, weight: .semibold),
                        .foregroundColor: UIColor.darkGray,
                    ]
                    (caption as NSString).draw(in: CGRect(x: 14, y: 9, width: pageWidth - 28, height: header - 10), withAttributes: attrs)
                    img.draw(in: CGRect(x: 0, y: header, width: pageWidth, height: pageWidth * ratio))
                }
            }
            return url
        } catch {
            return nil
        }
    }

    static func downscaled(_ url: URL, maxSide: CGFloat) -> UIImage? {
        guard let img = UIImage(contentsOfFile: url.path) else { return nil }
        let scale = min(1, maxSide / max(img.size.width, img.size.height))
        if scale >= 1 && img.imageOrientation == .up { return img }
        let size = CGSize(width: img.size.width * scale, height: img.size.height * scale)
        let f = UIGraphicsImageRendererFormat()
        f.scale = 1
        return UIGraphicsImageRenderer(size: size, format: f).image { _ in img.draw(in: CGRect(origin: .zero, size: size)) }
    }

    /// Копии фото с номерами в названии — чтобы в чате они легли по порядку
    static func numberedCopies(_ batch: BoardBatch) -> [URL] {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("board-\(UUID().uuidString)", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return batch.shots.enumerated().compactMap { i, s in
            let dst = dir.appendingPathComponent(String(format: "%02d %@ %@.%@", i + 1, batch.shortDate,
                                                        Fmt.formatter("HH-mm").string(from: s.date), s.url.pathExtension))
            return (try? FileManager.default.copyItem(at: s.url, to: dst)) != nil ? dst : nil
        }
    }
}

// MARK: - Напоминание после пары

enum BoardReminder {
    static let subjectKey = "board.subject"
    static let startKey = "board.start"

    /// Сфоткал доску на паре — после её конца придёт «Отправь ребятам N фото»
    static func schedule(subject: String) {
        let data = SharedSchedule.load()
        guard UserDefaults.standard.object(forKey: "board.remind") as? Bool ?? true,
              let slot = LessonPhotos.slot(for: Date(), subject: subject, data: data) else { return }
        let fire = max(slot.end.addingTimeInterval(60), Date().addingTimeInterval(5))
        guard fire.timeIntervalSinceNow < 3 * 3600 else { return }
        let count = LessonPhotos.batch(for: slot, data: data)?.shots.count ?? 1
        let c = UNMutableNotificationContent()
        c.title = "Фото с пары: \(slot.lesson.subject)"
        c.body = "\(LessonPhotos.photosWord(count)) доски по порядку — нажми, чтобы собрать PDF и отправить ребятам"
        c.sound = .default
        c.userInfo = [subjectKey: subject, startKey: slot.start.timeIntervalSince1970]
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: fire.timeIntervalSinceNow, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "board.\(slot.key)", content: c, trigger: trigger))
    }
}

/// Какую пару с фото открыть (из уведомления или ссылки safu://board)
final class BoardRouter: ObservableObject {
    static let shared = BoardRouter()
    struct Target: Identifiable, Equatable {
        let subject: String
        let start: Date?
        var id: String { subject + "\(start?.timeIntervalSince1970 ?? 0)" }
    }
    @Published var target: Target?
    /// Открыть камеру для текущей пары
    @Published var camera = false
}

// MARK: - Экран пары с фото

/// Миниатюра без загрузки полного снимка в память
struct BoardThumb: View {
    let url: URL
    var corner: CGFloat = 12
    @State private var image: UIImage?

    var body: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.07))
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: "photo").foregroundStyle(.tertiary)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: corner, style: .continuous))
            .task(id: url) {
                let u = url
                image = await Task.detached(priority: .utility) {
                    UIImage(contentsOfFile: u.path)?.preparingThumbnail(of: CGSize(width: 360, height: 360))
                }.value
            }
    }
}

struct BoardBatchView: View {
    @State var batch: BoardBatch
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var preview: URL?
    @State private var pdf: URL?
    @State private var copies: [URL] = []
    @State private var sharePDF = false
    @State private var sharePhotos = false
    @State private var camera = false
    @State private var toDelete: BoardShot?

    private func reload() {
        let all = LessonPhotos.batches(subject: batch.subject, data: schedule.data)
        if let b = all.first(where: { $0.id == batch.id }) { batch = b }
        else if let slot = batch.slot, let b = LessonPhotos.batch(for: slot, data: schedule.data) { batch = b }
        else { batch = BoardBatch(subject: batch.subject, slot: batch.slot, day: batch.day, shots: []) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(batch.subject)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text("\(batch.title) · \(batch.countText)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .background(SubjectColor.color(for: batch.subject).opacity(0.15),
                            in: RoundedRectangle(cornerRadius: 22, style: .continuous))

                HStack(spacing: 10) {
                    bigButton("Отправить PDF", "doc.richtext.fill", primary: true) {
                        pdf = LessonPhotosPDF.make(batch)
                        if pdf != nil { sharePDF = true }
                    }
                    bigButton("Фото по порядку", "photo.stack.fill") {
                        copies = LessonPhotosPDF.numberedCopies(batch)
                        if !copies.isEmpty { sharePhotos = true }
                    }
                }
                .disabled(batch.shots.isEmpty)

                bigButton("Сфоткать ещё", "camera.fill") { camera = true }

                if batch.shots.isEmpty {
                    Text("Фото этой пары пока нет.").font(.subheadline).foregroundStyle(.secondary)
                }
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                    ForEach(Array(batch.shots.enumerated()), id: \.element.id) { i, s in
                        Button { preview = s.url } label: {
                            BoardThumb(url: s.url, corner: 16)
                                .aspectRatio(4 / 3, contentMode: .fit)
                                .overlay(alignment: .topLeading) {
                                    Text("\(i + 1)")
                                        .font(.caption.weight(.heavy))
                                        .foregroundStyle(.white)
                                        .frame(width: 24, height: 24)
                                        .background(Color.brand, in: Circle())
                                        .padding(6)
                                }
                                .overlay(alignment: .bottomTrailing) {
                                    Text(Fmt.formatter("HH:mm").string(from: s.date))
                                        .font(.caption2.weight(.bold))
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 7).padding(.vertical, 3)
                                        .background(.black.opacity(0.45), in: Capsule())
                                        .padding(6)
                                }
                        }
                        .buttonStyle(PressableStyle())
                        .contextMenu {
                            ShareLink(item: s.url) { Label("Отправить это фото", systemImage: "square.and.arrow.up") }
                            Button(role: .destructive) { toDelete = s } label: { Label("Удалить", systemImage: "trash") }
                        }
                    }
                }
                Text("Порядок — по времени съёмки: раньше сфоткано, раньше стоит. В PDF каждое фото — отдельная страница с номером и временем.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Фото пары")
        .navigationBarTitleDisplayMode(.inline)
        .quickLookPreview($preview, in: batch.shots.map(\.url))
        .sheet(isPresented: $sharePDF) {
            if let pdf { ShareSheet(items: [pdf]) }
        }
        .sheet(isPresented: $sharePhotos) {
            ShareSheet(items: copies)
        }
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { image in
                camera = false
                if let image, BoardPhoto.save(image, subject: batch.subject) != nil {
                    Haptics.success()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { reload() }
                }
            }
            .ignoresSafeArea()
        }
        .confirmationDialog("Удалить фото?", isPresented: Binding(get: { toDelete != nil }, set: { if !$0 { toDelete = nil } }),
                            titleVisibility: .visible) {
            Button("Удалить", role: .destructive) {
                if let s = toDelete { try? FileManager.default.removeItem(at: s.url) }
                toDelete = nil
                BoardIndex.shared.prune()
                reload()
            }
        }
        .onAppear { reload() }
    }

    private func bigButton(_ title: String, _ icon: String, primary: Bool = false, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(primary ? Color.white : Color.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background {
                    if primary {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(brandGradient)
                    } else {
                        RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.primary.opacity(0.08))
                    }
                }
        }
        .buttonStyle(PressableStyle())
    }
}

/// Обычное окно «Поделиться» (для нескольких файлов сразу)
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

/// Строка пары с фото: полоска миниатюр + кнопка «отправить»
struct BoardBatchRow: View {
    let batch: BoardBatch
    var showSubject = false

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(showSubject ? batch.subject : batch.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(showSubject ? "\(batch.title) · \(batch.countText)" : batch.countText)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 6) {
                    ForEach(batch.shots.prefix(12)) { s in
                        BoardThumb(url: s.url, corner: 9).frame(width: 64, height: 48)
                    }
                }
            }
            .allowsHitTesting(false)
        }
        .contentShape(Rectangle())
    }
}

/// Все пары с фото одного предмета (или всех, если subject == nil)
struct BoardBatchesList: View {
    let subject: String?
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var list: [BoardBatch] = []

    var body: some View {
        List {
            if list.isEmpty {
                Text("Фото доски пока нет. Снимай прямо на паре — кнопка камеры есть на главной, в карточке пары и на странице предмета.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            ForEach(list) { b in
                NavigationLink {
                    BoardBatchView(batch: b)
                } label: {
                    BoardBatchRow(batch: b, showSubject: subject == nil)
                }
            }
        }
        .navigationTitle(subject == nil ? "Фото с пар" : "Фото доски")
        .onAppear {
            list = subject.map { LessonPhotos.batches(subject: $0, data: schedule.data) }
                ?? LessonPhotos.allBatches(data: schedule.data, limit: 100)
        }
    }
}

// MARK: - Карточка «Доска» на главной

struct BoardHomeCard: View {
    let data: ScheduleData
    let onCamera: (String) -> Void
    let onOpen: (BoardBatch) -> Void
    @ObservedObject private var index = BoardIndex.shared
    @State private var latest: BoardBatch?
    @State private var pdf: URL?
    @State private var share = false

    private var slot: LessonSlot? { LessonPhotos.currentSlot(data) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "camera.viewfinder").foregroundStyle(brandGradient)
                Text("Фото доски").font(.system(.headline, design: .rounded))
                Spacer()
                if index.working > 0 {
                    ProgressView().controlSize(.small)
                }
            }

            if let slot {
                Text(slot.lesson.subject).font(.subheadline.weight(.semibold)).lineLimit(1)
                Button {
                    Haptics.tap()
                    onCamera(slot.lesson.subject)
                } label: {
                    Label("Сфоткать доску", systemImage: "camera.fill")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(PressableStyle())
            }

            if let b = latest, !b.shots.isEmpty {
                Button { onOpen(b) } label: {
                    BoardBatchRow(batch: b, showSubject: true)
                }
                .buttonStyle(.plain)
                Button {
                    pdf = LessonPhotosPDF.make(b)
                    if pdf != nil { share = true }
                } label: {
                    Label("Отправить ребятам PDF (\(b.shots.count))", systemImage: "paperplane.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(PressableStyle())
            } else if slot == nil {
                Text("На паре нажми на камеру — фото лягут в папку предмета по порядку, а после пары их можно одним PDF отправить группе.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .glass(22)
        .onAppear { refresh() }
        .onChange(of: index.entries.count) { _ in refresh() }
        .sheet(isPresented: $share) {
            if let pdf { ShareSheet(items: [pdf]) }
        }
    }

    private func refresh() {
        if let slot, let b = LessonPhotos.batch(for: slot, data: data) {
            latest = b
        } else {
            latest = LessonPhotos.allBatches(data: data, limit: 1).first
        }
    }
}
