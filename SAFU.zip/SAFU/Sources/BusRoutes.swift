import SwiftUI
import UIKit

// MARK: - Маршруты автобусов
// Раньше был зашит только 150. Теперь у каждого студента свой список:
// 150 по умолчанию + любые свои автобусы. Активный маршрут считает «Дорогу», напоминания и Live Activity.

enum BusDirection: String, Codable {
    case toCampus, toHome
    var flipped: BusDirection { self == .toCampus ? .toHome : .toCampus }
}

enum BusDayType: String, CaseIterable, Identifiable, Codable {
    case weekday, saturday, sunday
    var id: String { rawValue }
    var title: String {
        switch self {
        case .weekday: return "Пн–Пт"
        case .saturday: return "Суббота"
        case .sunday: return "Воскресенье"
        }
    }
    static func of(_ day: Date) -> BusDayType {
        switch ScheduleEngine.weekday(of: day) {   // 1 = пн … 7 = вс
        case 6: return .saturday
        case 7: return .sunday
        default: return .weekday
        }
    }
}

struct BusTrip: Hashable {
    let departure: Date
    let arrival: Date
}

struct BusRoute: Codable, Identifiable, Hashable {
    var id: String = UUID().uuidString
    var number: String = ""
    /// Откуда ты едешь на пары (дом)
    var homeCity: String = ""
    var homeStop: String = ""
    /// Куда (к универу)
    var campusCity: String = "Архангельск"
    var campusStop: String = ""
    var travelMinutes: Int = 30
    /// Для пар без особых правил: выехать не позже чем за N минут до начала
    var leadMinutes: Int = 60
    var colorHex: String = "F28C1A"
    /// Расписания: BusDayType.rawValue → «06:20 06:40 …»
    var toCampus: [String: String] = [:]
    var toHome: [String: String] = [:]
    var mapLink: String = ""
    /// Направление по геолокации: в Архангельске — домой, вне — в город. Только для межгорода.
    var useGeo: Bool = false
    var builtIn: Bool = false

    init() {}

    private enum K: String, CodingKey {
        case id, number, homeCity, homeStop, campusCity, campusStop, travelMinutes, leadMinutes
        case colorHex, toCampus, toHome, mapLink, useGeo, builtIn
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        id = try c.decodeIfPresent(String.self, forKey: .id) ?? UUID().uuidString
        number = try c.decodeIfPresent(String.self, forKey: .number) ?? ""
        homeCity = try c.decodeIfPresent(String.self, forKey: .homeCity) ?? ""
        homeStop = try c.decodeIfPresent(String.self, forKey: .homeStop) ?? ""
        campusCity = try c.decodeIfPresent(String.self, forKey: .campusCity) ?? "Архангельск"
        campusStop = try c.decodeIfPresent(String.self, forKey: .campusStop) ?? ""
        travelMinutes = try c.decodeIfPresent(Int.self, forKey: .travelMinutes) ?? 30
        leadMinutes = try c.decodeIfPresent(Int.self, forKey: .leadMinutes) ?? 60
        colorHex = try c.decodeIfPresent(String.self, forKey: .colorHex) ?? "F28C1A"
        toCampus = try c.decodeIfPresent([String: String].self, forKey: .toCampus) ?? [:]
        toHome = try c.decodeIfPresent([String: String].self, forKey: .toHome) ?? [:]
        mapLink = try c.decodeIfPresent(String.self, forKey: .mapLink) ?? ""
        useGeo = try c.decodeIfPresent(Bool.self, forKey: .useGeo) ?? false
        builtIn = try c.decodeIfPresent(Bool.self, forKey: .builtIn) ?? false
    }

    // MARK: вычисляемое

    var color: Color { Color(hex: colorHex) ?? .orange }
    var title: String { number.isEmpty ? "Автобус" : "Автобус \(number)" }
    var routeText: String {
        let a = homeCity.isEmpty ? homeStop : homeCity
        let b = campusCity.isEmpty ? campusStop : campusCity
        return "\(a) ⇄ \(b)"
    }

    func fromCity(_ d: BusDirection) -> String { d == .toCampus ? homeCity : campusCity }
    func toCity(_ d: BusDirection) -> String { d == .toCampus ? campusCity : homeCity }
    func fromStop(_ d: BusDirection) -> String { d == .toCampus ? homeStop : campusStop }
    func toStop(_ d: BusDirection) -> String { d == .toCampus ? campusStop : homeStop }

    /// Своя ссылка на Яндекс Карты или поиск по номеру
    var mapURL: URL {
        if let u = URL(string: mapLink.trimmingCharacters(in: .whitespaces)), u.scheme != nil { return u }
        let q = "автобус \(number) \(campusCity)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "https://yandex.ru/maps/20/arkhangelsk/?text=\(q)")!
    }

    func timesRaw(_ d: BusDirection, _ type: BusDayType) -> String {
        (d == .toCampus ? toCampus : toHome)[type.rawValue] ?? ""
    }

    mutating func setTimes(_ d: BusDirection, _ type: BusDayType, _ raw: String) {
        let clean = BusRoute.normalize(raw)
        if d == .toCampus { toCampus[type.rawValue] = clean } else { toHome[type.rawValue] = clean }
    }

    func times(_ d: BusDirection, type: BusDayType) -> [String] {
        timesRaw(d, type).split(separator: " ").map(String.init)
    }

    func times(_ d: BusDirection, on day: Date) -> [String] { times(d, type: BusDayType.of(day)) }

    func trips(_ d: BusDirection, on day: Date) -> [BusTrip] {
        let cal = Calendar.current
        let travel = Double(travelMinutes) * 60
        return times(d, on: day).compactMap { t in
            let p = t.split(separator: ":").compactMap { Int($0) }
            guard p.count == 2, let dep = cal.date(bySettingHour: p[0], minute: p[1], second: 0, of: day) else { return nil }
            return BusTrip(departure: dep, arrival: dep.addingTimeInterval(travel))
        }
    }

    var isEmpty: Bool {
        BusDayType.allCases.allSatisfy { times(.toCampus, type: $0).isEmpty && times(.toHome, type: $0).isEmpty }
    }

    /// Любой текст («6.20, 7:40; 8:15») → «06:20 07:40 08:15», по порядку и без повторов
    static func normalize(_ raw: String) -> String {
        let pattern = try? NSRegularExpression(pattern: "(\\d{1,2})[:.](\\d{2})")
        let ns = raw as NSString
        var set = Set<Int>()
        pattern?.enumerateMatches(in: raw, range: NSRange(location: 0, length: ns.length)) { m, _, _ in
            guard let m, let h = Int(ns.substring(with: m.range(at: 1))),
                  let mi = Int(ns.substring(with: m.range(at: 2))), h < 24, mi < 60 else { return }
            set.insert(h * 60 + mi)
        }
        return set.sorted().map { String(format: "%02d:%02d", $0 / 60, $0 % 60) }.joined(separator: " ")
    }

    // MARK: 150 по умолчанию

    static let default150: BusRoute = {
        var r = BusRoute()
        r.id = "builtin-150"
        r.number = "150"
        r.homeCity = "Северодвинск"
        r.homeStop = "о. Ягры"
        r.campusCity = "Архангельск"
        r.campusStop = "м.р. вокзал"
        r.travelMinutes = 60
        r.leadMinutes = 100
        r.colorHex = "F28C1A"
        r.useGeo = true
        r.builtIn = true
        r.mapLink = "https://yandex.ru/maps/20/arkhangelsk/routes/bus_150/796d617073626d313a2f2f7472616e7369742f6c696e653f69643d31373034383535383634266c6c3d34302e31383136333325324336342e353534353734266e616d653d31353026723d313833383726747970653d627573/"
        r.toCampus = [
            "weekday": "06:20 06:40 07:00 07:25 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:00 14:30 15:10 16:00 16:35 17:30 18:30 19:30",
            "saturday": "06:40 07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30",
            "sunday": "07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30",
        ]
        r.toHome = [
            "weekday": "06:10 07:40 08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 15:30 16:00 16:30 17:00 17:30 18:15 19:00 20:00",
            "saturday": "08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00",
            "sunday": "08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00",
        ]
        return r
    }()

    // MARK: обмен с одногруппниками

    static let sharePrefix = "SAFU-BUS:"

    var shareCode: String {
        var copy = self
        copy.builtIn = false
        let data = (try? JSONEncoder().encode(copy)) ?? Data()
        return BusRoute.sharePrefix + data.base64EncodedString()
    }

    static func fromShareCode(_ text: String) -> BusRoute? {
        guard let r = text.range(of: sharePrefix) else { return nil }
        let tail = text[r.upperBound...].prefix { !$0.isWhitespace }
        guard let data = Data(base64Encoded: String(tail)),
              var route = try? JSONDecoder().decode(BusRoute.self, from: data) else { return nil }
        route.id = UUID().uuidString
        route.builtIn = false
        return route
    }
}

// MARK: - Хранилище

final class BusRouteStore: ObservableObject {
    static let shared = BusRouteStore()

    private let key = "bus.routes.v1"
    private let activeKey = "bus.active"

    @Published var routes: [BusRoute] { didSet { persist() } }
    @Published var activeID: String { didSet { UserDefaults.standard.set(activeID, forKey: activeKey) } }

    private init() {
        let d = UserDefaults.standard
        if let raw = d.data(forKey: key), let list = try? JSONDecoder().decode([BusRoute].self, from: raw), !list.isEmpty {
            routes = list
        } else {
            routes = [BusRoute.default150]
        }
        activeID = d.string(forKey: activeKey) ?? BusRoute.default150.id
    }

    var active: BusRoute {
        routes.first { $0.id == activeID } ?? routes.first ?? BusRoute.default150
    }

    func upsert(_ r: BusRoute) {
        if let i = routes.firstIndex(where: { $0.id == r.id }) { routes[i] = r } else { routes.append(r) }
    }

    func delete(_ r: BusRoute) {
        routes.removeAll { $0.id == r.id }
        if routes.isEmpty { routes = [BusRoute.default150] }
        if !routes.contains(where: { $0.id == activeID }) { activeID = routes[0].id }
    }

    func activate(_ r: BusRoute) {
        guard r.id != activeID else { return }
        activeID = r.id
        BusLiveManager.stop()
    }

    /// Вернуть встроенный 150, если его удалили
    func restore150() {
        if !routes.contains(where: { $0.id == BusRoute.default150.id }) { routes.insert(BusRoute.default150, at: 0) }
    }

    /// Поправить активный маршрут (время в пути, запас) из настроек
    func updateActive(_ change: (inout BusRoute) -> Void) {
        var r = active
        change(&r)
        upsert(r)
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(routes) { UserDefaults.standard.set(data, forKey: key) }
    }
}

enum BusRoutes {
    static var active: BusRoute { BusRouteStore.shared.active }
}

// MARK: - Палитра цветов маршрута

enum BusPalette {
    static let hexes = ["F28C1A", "E94B4B", "E8457C", "8B5CF6", "3B82F6", "06B6D4", "10B981", "84CC16", "EAB308", "64748B"]
}

// MARK: - Экран «Мои автобусы»

struct BusRoutesView: View {
    @ObservedObject private var store = BusRouteStore.shared
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var editing: BusRoute?
    @State private var importError = false
    @State private var imported: String?

    var body: some View {
        List {
            Section {
                ForEach(store.routes) { r in
                    row(r)
                        .swipeActions(edge: .trailing) {
                            if store.routes.count > 1 {
                                Button(role: .destructive) { store.delete(r) } label: { Label("Удалить", systemImage: "trash") }
                            }
                            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }.tint(.blue)
                        }
                }
            } header: {
                Text("Нажми, чтобы выбрать свой")
            } footer: {
                Text("По выбранному автобусу считаются «Дорога» на главной, напоминания «пора выходить», утренняя сводка и Live Activity.")
            }

            Section {
                Button {
                    var r = BusRoute()
                    r.colorHex = BusPalette.hexes.randomElement() ?? "3B82F6"
                    editing = r
                } label: {
                    Label("Добавить автобус", systemImage: "plus.circle.fill")
                }
                Button {
                    if let text = UIPasteboard.general.string, let r = BusRoute.fromShareCode(text) {
                        store.upsert(r)
                        Haptics.success()
                        imported = r.title
                    } else {
                        importError = true
                    }
                } label: {
                    Label("Вставить код от одногруппника", systemImage: "doc.on.clipboard")
                }
                if !store.routes.contains(where: { $0.id == BusRoute.default150.id }) {
                    Button { store.restore150() } label: {
                        Label("Вернуть автобус 150", systemImage: "arrow.uturn.backward")
                    }
                }
            } footer: {
                Text("Настроил свой автобус — нажми «Поделиться» в нём и скинь код в чат группы. Остальным останется скопировать и вставить.")
            }
        }
        .navigationTitle("Мои автобусы")
        .sheet(item: $editing) { r in
            BusRouteEditor(route: r) { saved in
                store.upsert(saved)
                if store.routes.count == 1 { store.activeID = saved.id }
            }
        }
        .alert("В буфере нет кода автобуса", isPresented: $importError) {
            Button("Понятно", role: .cancel) {}
        } message: {
            Text("Код начинается с «SAFU-BUS:». Попроси одногруппника нажать «Поделиться» в его автобусе.")
        }
        .alert("Добавлен", isPresented: Binding(get: { imported != nil }, set: { if !$0 { imported = nil } })) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text("\(imported ?? "") теперь в списке. Нажми на него, чтобы сделать своим.")
        }
        .onDisappear { schedule.refreshSideEffects() }
    }

    private func row(_ r: BusRoute) -> some View {
        let on = r.id == store.activeID
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { store.activate(r) }
        } label: {
            HStack(spacing: 12) {
                Text(r.number.isEmpty ? "?" : r.number)
                    .font(.system(size: r.number.count > 3 ? 13 : 16, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
                    .frame(width: 48, height: 40)
                    .background(r.color.gradient, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                VStack(alignment: .leading, spacing: 2) {
                    Text(r.routeText).font(.subheadline.weight(.semibold)).foregroundStyle(.primary).lineLimit(1)
                    Text("в пути \(r.travelMinutes) мин" + (r.isEmpty ? " · нет расписания" : ""))
                        .font(.caption)
                        .foregroundStyle(r.isEmpty ? Color.orange : Color.secondary)
                }
                Spacer()
                Image(systemName: on ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(on ? Color.brand : Color.secondary.opacity(0.4))
            }
            .padding(.vertical, 2)
        }
        .contextMenu {
            Button { editing = r } label: { Label("Изменить", systemImage: "pencil") }
            ShareLink(item: r.shareCode) { Label("Поделиться кодом", systemImage: "square.and.arrow.up") }
        }
    }
}

// MARK: - Редактор автобуса

struct BusRouteEditor: View {
    @State var route: BusRoute
    let onSave: (BusRoute) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var direction: BusDirection = .toCampus
    @State private var texts: [String: String] = [:]

    private func tkey(_ d: BusDirection, _ t: BusDayType) -> String { d.rawValue + "." + t.rawValue }

    private var canSave: Bool { !route.number.trimmingCharacters(in: .whitespaces).isEmpty }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        Text(route.number.isEmpty ? "№" : route.number)
                            .font(.system(size: 22, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                            .frame(width: 64, height: 54)
                            .background(route.color.gradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        TextField("Номер, например 104", text: $route.number)
                            .font(.system(.title3, design: .rounded).weight(.bold))
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(BusPalette.hexes, id: \.self) { h in
                                Circle()
                                    .fill(Color(hex: h) ?? .gray)
                                    .frame(width: 30, height: 30)
                                    .overlay(Circle().strokeBorder(Color.primary.opacity(route.colorHex == h ? 0.8 : 0), lineWidth: 2).padding(-4))
                                    .padding(4)
                                    .onTapGesture { Haptics.tap(); route.colorHex = h }
                            }
                        }
                    }
                }

                Section("Откуда ты едешь (дом)") {
                    TextField("Город, например Новодвинск", text: $route.homeCity)
                    TextField("Остановка", text: $route.homeStop)
                }
                Section("Куда (к универу)") {
                    TextField("Город", text: $route.campusCity)
                    TextField("Остановка", text: $route.campusStop)
                }

                Section {
                    Stepper("В пути: \(route.travelMinutes) мин", value: $route.travelMinutes, in: 5...240, step: 5)
                    Stepper("Выезд за \(route.leadMinutes) мин до пары", value: $route.leadMinutes, in: 10...240, step: 5)
                    Toggle("Направление по геолокации", isOn: $route.useGeo)
                } header: {
                    Text("Время")
                } footer: {
                    Text("«Выезд за» — берётся последний рейс, который уходит не позже чем за столько минут до первой пары. Геолокацию включай только для межгорода: в Архангельске покажу рейсы домой, за городом — в универ.")
                }

                Section {
                    Picker("Направление", selection: $direction) {
                        Text("В универ").tag(BusDirection.toCampus)
                        Text("Домой").tag(BusDirection.toHome)
                    }
                    .pickerStyle(.segmented)
                    ForEach(BusDayType.allCases) { t in
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text(t.title).font(.subheadline.weight(.semibold))
                                Spacer()
                                if t != .weekday {
                                    Button("как в будни") {
                                        texts[tkey(direction, t)] = texts[tkey(direction, .weekday)] ?? ""
                                        Haptics.tap()
                                    }
                                    .font(.caption.weight(.semibold))
                                    .buttonStyle(.borderless)
                                }
                            }
                            TextField("06:20 07:00 07:40 …", text: binding(direction, t), axis: .vertical)
                                .font(.system(.body, design: .monospaced))
                                .keyboardType(.numbersAndPunctuation)
                                .lineLimit(2...6)
                            let n = BusRoute.normalize(texts[tkey(direction, t)] ?? "").split(separator: " ").count
                            Text(n == 0 ? "рейсов нет" : "рейсов: \(n)")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 2)
                    }
                } header: {
                    Text("Расписание")
                } footer: {
                    Text("Вставь времена как угодно: через пробел, запятую, «6.20» или «06:20» — приложение само разберёт и отсортирует.")
                }

                Section {
                    TextField("Ссылка на маршрут в Яндекс Картах", text: $route.mapLink)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                } header: {
                    Text("Где автобус сейчас")
                } footer: {
                    Text("Необязательно. Без ссылки откроется поиск маршрута по номеру.")
                }

                if canSave {
                    Section {
                        ShareLink(item: collect().shareCode) {
                            Label("Поделиться с группой", systemImage: "square.and.arrow.up")
                        }
                    } footer: {
                        Text("Отправится код — одногруппник вставит его в «Мои автобусы».")
                    }
                }
            }
            .navigationTitle(route.number.isEmpty ? "Новый автобус" : "Автобус \(route.number)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") {
                        onSave(collect())
                        Haptics.success()
                        dismiss()
                    }
                    .fontWeight(.semibold)
                    .disabled(!canSave)
                }
            }
            .onAppear {
                for d in [BusDirection.toCampus, .toHome] {
                    for t in BusDayType.allCases { texts[tkey(d, t)] = route.timesRaw(d, t) }
                }
            }
        }
    }

    private func binding(_ d: BusDirection, _ t: BusDayType) -> Binding<String> {
        Binding(get: { texts[tkey(d, t)] ?? "" }, set: { texts[tkey(d, t)] = $0 })
    }

    private func collect() -> BusRoute {
        var r = route
        r.number = r.number.trimmingCharacters(in: .whitespaces)
        for d in [BusDirection.toCampus, .toHome] {
            for t in BusDayType.allCases { r.setTimes(d, t, texts[tkey(d, t)] ?? "") }
        }
        return r
    }
}
