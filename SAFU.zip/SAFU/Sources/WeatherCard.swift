import SwiftUI

// MARK: - Погода на главной: сейчас, по часам и что надеть
// Город — по геолокации (Архангельск или Северодвинск), прогноз — Open-Meteo, обновляется раз в час.

enum Outfit {
    struct Item: Hashable {
        let icon: String
        let text: String
    }

    /// Что надеть: по «ощущается», ветру и осадкам в ближайшие часы
    static func items(now h: WeatherHour, soon: [WeatherHour]) -> [Item] {
        var out: [Item] = []
        let f = h.feels
        switch f {
        case ..<(-25):
            out.append(Item(icon: "thermometer.snowflake", text: "Пуховик, термобельё и тёплые штаны"))
            out.append(Item(icon: "hand.raised.fill", text: "Варежки, а не перчатки"))
            out.append(Item(icon: "face.dashed", text: "Шапка и шарф — закрой лицо от мороза"))
        case -25..<(-15):
            out.append(Item(icon: "snowflake", text: "Зимняя куртка, шапка, шарф и тёплые перчатки"))
            out.append(Item(icon: "shoeprints.fill", text: "Зимняя обувь с толстой подошвой"))
        case -15..<(-5):
            out.append(Item(icon: "snowflake", text: "Тёплая куртка, шапка и перчатки"))
        case -5..<3:
            out.append(Item(icon: "wind.snow", text: "Демисезонная куртка и шапка"))
        case 3..<10:
            out.append(Item(icon: "cloud.sun.fill", text: "Лёгкая куртка или ветровка"))
        case 10..<17:
            out.append(Item(icon: "tshirt.fill", text: "Худи или кофта"))
        default:
            out.append(Item(icon: "sun.max.fill", text: "Можно в футболке — тепло"))
        }

        let windMax = ([h] + soon).map(\.wind).max() ?? h.wind
        if windMax >= 14 {
            out.append(Item(icon: "tornado", text: "Очень сильный ветер \(Int(windMax.rounded())) м/с — капюшон и ветрозащита, осторожно у щитов и деревьев"))
        } else if windMax >= 8 {
            out.append(Item(icon: "wind", text: "Ветер до \(Int(windMax.rounded())) м/с — с реки дует, пригодится капюшон"))
        }

        let window = [h] + soon
        let rain = window.contains { (51...67).contains($0.code) || (80...82).contains($0.code) || (95...99).contains($0.code) }
        let snow = window.contains { (71...77).contains($0.code) || $0.code == 85 || $0.code == 86 }
        if rain { out.append(Item(icon: "umbrella.fill", text: "Будет дождь — зонт или дождевик")) }
        if snow { out.append(Item(icon: "cloud.snow.fill", text: "Снег — непромокаемая обувь")) }
        // около нуля с осадками — гололёд
        if (rain || snow), window.contains(where: { $0.temp > -3 && $0.temp < 2 }) {
            out.append(Item(icon: "exclamationmark.triangle.fill", text: "Около нуля — скользко, осторожно на ступеньках"))
        }
        return out
    }

    static func windWord(_ w: Double) -> String {
        switch w {
        case ..<3: return "тихо"
        case 3..<8: return "ветерок"
        case 8..<14: return "сильный ветер"
        default: return "очень сильный ветер"
        }
    }

    static func sky(_ code: Int) -> String {
        switch code {
        case 0: return "Ясно"
        case 1, 2: return "Переменная облачность"
        case 3: return "Пасмурно"
        case 45, 48: return "Туман"
        case 51...57: return "Морось"
        case 61...67, 80...82: return "Дождь"
        case 71...77, 85, 86: return "Снег"
        case 95...99: return "Гроза"
        default: return "—"
        }
    }
}

extension Outfit {
    /// Коротко, в одну строку: «Зимняя куртка, шапка · капюшон — ветер · зонт»
    static func short(now h: WeatherHour, soon: [WeatherHour]) -> String {
        var parts: [String] = []
        switch h.feels {
        case ..<(-25): parts.append("Пуховик, варежки, закрой лицо")
        case -25..<(-15): parts.append("Зимняя куртка, шапка, шарф")
        case -15..<(-5): parts.append("Тёплая куртка и шапка")
        case -5..<3: parts.append("Куртка и шапка")
        case 3..<10: parts.append("Лёгкая куртка")
        case 10..<17: parts.append("Кофта или худи")
        default: parts.append("Футболка")
        }
        let window = [h] + soon
        let wind = window.map(\.wind).max() ?? h.wind
        if wind >= 8 { parts.append("капюшон — ветер \(Int(wind.rounded())) м/с") }
        if window.contains(where: { (51...67).contains($0.code) || (80...82).contains($0.code) || (95...99).contains($0.code) }) {
            parts.append("зонт")
        }
        if window.contains(where: { (71...77).contains($0.code) || $0.code == 85 || $0.code == 86 }) {
            parts.append("непромокаемая обувь")
        }
        return parts.joined(separator: " · ")
    }
}

/// Погода одной строкой: «🌨 −3° · ощущ. −9° · 8 м/с — куртка, шапка, капюшон». Нажал — прогноз по часам
struct WeatherHomeCard: View {
    let data: ScheduleData
    @ObservedObject private var weather = WeatherStore.shared
    @ObservedObject private var locator = CityLocator.shared
    @State private var more = false

    private var city: HomeCity { locator.city ?? .arkhangelsk }
    private var now: WeatherHour? { weather.hour(at: Date()) }
    private var next: [WeatherHour] {
        let t = Date()
        return weather.hours.filter { $0.time > t }.prefix(10).map { $0 }
    }

    var body: some View {
        Group {
            if let h = now {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 8) {
                        Text(WeatherCache.emoji(h.code)).font(.system(size: 20))
                        Text(WeatherCache.deg(h.temp)).font(.system(.headline, design: .rounded).weight(.heavy))
                        Text("· \(Int(h.wind.rounded())) м/с").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                        Text(Outfit.short(now: h, soon: Array(next.prefix(6))))
                            .font(.caption.weight(.medium))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                        Spacer(minLength: 0)
                    }
                    if more {
                        HStack(spacing: 0) {
                            ForEach(next, id: \.time) { x in
                                VStack(spacing: 2) {
                                    Text(Fmt.formatter("HH").string(from: x.time)).font(.system(size: 9, weight: .semibold)).foregroundStyle(.secondary)
                                    Text(WeatherCache.emoji(x.code)).font(.caption)
                                    Text(WeatherCache.deg(x.temp)).font(.system(size: 10, weight: .bold))
                                }
                                .frame(maxWidth: .infinity)
                            }
                        }
                        Text("\(city == .arkhangelsk ? "Архангельск" : "Северодвинск") · ощущается \(WeatherCache.deg(h.feels)) · \(Outfit.sky(h.code).lowercased())")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { more.toggle() }
                }
            } else {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.mini)
                    Text("Погода…").font(.caption).foregroundStyle(.secondary)
                    Spacer(minLength: 0)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .glass(18)
        .task {
            locator.refresh()
            await weather.refresh(city: city)
        }
        .onChange(of: locator.city) { c in
            Task { await weather.refresh(city: c) }
        }
    }
}
