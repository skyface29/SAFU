import SwiftUI

// MARK: - Погода на главной: сейчас, по часам и что надеть
// Город — по геолокации (Архангельск или Северодвинск), прогноз — Open-Meteo, обновляется раз в час.

enum Outfit {
    struct Item: Hashable {
        let icon: String
        let text: String
    }

    /// Что надеть: по «ощущается», ветру и осадкам в ближайшие часы
    static func items(now h: WeatherHour, soon: [WeatherHour]) -> [Item] {
        var out: [Item] = []
        let f = h.feels
        switch f {
        case ..<(-25):
            out.append(Item(icon: "thermometer.snowflake", text: "Пуховик, термобельё и тёплые штаны"))
            out.append(Item(icon: "hand.raised.fill", text: "Варежки, а не перчатки"))
            out.append(Item(icon: "face.dashed", text: "Шапка и шарф — закрой лицо от мороза"))
        case -25..<(-15):
            out.append(Item(icon: "snowflake", text: "Зимняя куртка, шапка, шарф и тёплые перчатки"))
            out.append(Item(icon: "shoeprints.fill", text: "Зимняя обувь с толстой подошвой"))
        case -15..<(-5):
            out.append(Item(icon: "snowflake", text: "Тёплая куртка, шапка и перчатки"))
        case -5..<3:
            out.append(Item(icon: "wind.snow", text: "Демисезонная куртка и шапка"))
        case 3..<10:
            out.append(Item(icon: "cloud.sun.fill", text: "Лёгкая куртка или ветровка"))
        case 10..<17:
            out.append(Item(icon: "tshirt.fill", text: "Худи или кофта"))
        default:
            out.append(Item(icon: "sun.max.fill", text: "Можно в футболке — тепло"))
        }

        let windMax = ([h] + soon).map(\.wind).max() ?? h.wind
        if windMax >= 14 {
            out.append(Item(icon: "tornado", text: "Очень сильный ветер \(Int(windMax.rounded())) м/с — капюшон и ветрозащита, осторожно у щитов и деревьев"))
        } else if windMax >= 8 {
            out.append(Item(icon: "wind", text: "Ветер до \(Int(windMax.rounded())) м/с — с реки дует, пригодится капюшон"))
        }

        let window = [h] + soon
        let rain = window.contains { (51...67).contains($0.code) || (80...82).contains($0.code) || (95...99).contains($0.code) }
        let snow = window.contains { (71...77).contains($0.code) || $0.code == 85 || $0.code == 86 }
        if rain { out.append(Item(icon: "umbrella.fill", text: "Будет дождь — зонт или дождевик")) }
        if snow { out.append(Item(icon: "cloud.snow.fill", text: "Снег — непромокаемая обувь")) }
        // около нуля с осадками — гололёд
        if (rain || snow), window.contains(where: { $0.temp > -3 && $0.temp < 2 }) {
            out.append(Item(icon: "exclamationmark.triangle.fill", text: "Около нуля — скользко, осторожно на ступеньках"))
        }
        return out
    }

    static func windWord(_ w: Double) -> String {
        switch w {
        case ..<3: return "тихо"
        case 3..<8: return "ветерок"
        case 8..<14: return "сильный ветер"
        default: return "очень сильный ветер"
        }
    }

    static func sky(_ code: Int) -> String {
        switch code {
        case 0: return "Ясно"
        case 1, 2: return "Переменная облачность"
        case 3: return "Пасмурно"
        case 45, 48: return "Туман"
        case 51...57: return "Морось"
        case 61...67, 80...82: return "Дождь"
        case 71...77, 85, 86: return "Снег"
        case 95...99: return "Гроза"
        default: return "—"
        }
    }
}

struct WeatherHomeCard: View {
    let data: ScheduleData
    @ObservedObject private var weather = WeatherStore.shared
    @ObservedObject private var locator = CityLocator.shared
    @AppStorage("weather.card.open") private var open = true

    private var city: HomeCity { locator.city ?? .arkhangelsk }
    private var now: WeatherHour? { weather.hour(at: Date()) }
    private var next: [WeatherHour] {
        let t = Date()
        return weather.hours.filter { $0.time > t }.prefix(12).map { $0 }
    }
    private var today: (min: Double, max: Double)? {
        let cal = Calendar.current
        let temps = weather.hours.filter { cal.isDateInToday($0.time) }.map(\.temp)
        guard let lo = temps.min(), let hi = temps.max() else { return nil }
        return (lo, hi)
    }
    /// Погода к концу пар сегодня
    private var afterPairs: (Date, WeatherHour)? {
        guard let last = ScheduleEngine.slots(on: Date(), data: data).last, last.end > Date(),
              let h = weather.hour(at: last.end) else { return nil }
        return (last.end, h)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "location.fill").font(.caption).foregroundStyle(Color.brand)
                Text("Погода · \(city == .arkhangelsk ? "Архангельск" : "Северодвинск")")
                    .font(.system(.headline, design: .rounded))
                Spacer()
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { open.toggle() }
                } label: {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(open ? 180 : 0))
                        .frame(width: 30, height: 30)
                        .background(Color.primary.opacity(0.07), in: Circle())
                }
                .buttonStyle(.plain)
            }

            if let h = now {
                HStack(alignment: .center, spacing: 14) {
                    Text(WeatherCache.emoji(h.code)).font(.system(size: 46))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(WeatherCache.deg(h.temp))
                            .font(.system(size: 40, weight: .heavy, design: .rounded))
                            .contentTransition(.numericText())
                        Text("\(Outfit.sky(h.code)) · ощущается \(WeatherCache.deg(h.feels))")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                    VStack(alignment: .trailing, spacing: 4) {
                        Label("\(Int(h.wind.rounded())) м/с", systemImage: "wind")
                            .font(.subheadline.weight(.semibold))
                        Text(Outfit.windWord(h.wind)).font(.caption).foregroundStyle(.secondary)
                        if let t = today {
                            Text("\(WeatherCache.deg(t.min))…\(WeatherCache.deg(t.max))")
                                .font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                        }
                    }
                }

                if open {
                    VStack(alignment: .leading, spacing: 12) {
                        // по часам
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(next, id: \.time) { x in
                                    VStack(spacing: 4) {
                                        Text(Fmt.formatter("HH").string(from: x.time) + ":00")
                                            .font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                                        Text(WeatherCache.emoji(x.code)).font(.title3)
                                        Text(WeatherCache.deg(x.temp)).font(.caption.weight(.bold))
                                        if x.wind >= 8 {
                                            Text("\(Int(x.wind.rounded()))м/с").font(.system(size: 9, weight: .semibold)).foregroundStyle(.orange)
                                        }
                                    }
                                    .frame(width: 44)
                                }
                            }
                        }

                        if let ap = afterPairs {
                            Label("После пар (\(Fmt.formatter("HH:mm").string(from: ap.0))): \(WeatherCache.line(ap.1))",
                                  systemImage: "figure.walk.departure")
                                .font(.caption.weight(.semibold))
                        }

                        // что надеть
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Что надеть").font(.subheadline.weight(.bold))
                            ForEach(Outfit.items(now: h, soon: Array(next.prefix(6))), id: \.self) { it in
                                HStack(alignment: .top, spacing: 10) {
                                    Image(systemName: it.icon)
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundStyle(brandGradient)
                                        .frame(width: 22)
                                    Text(it.text).font(.subheadline)
                                    Spacer(minLength: 0)
                                }
                            }
                        }
                        .padding(12)
                        .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            } else {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(locator.denied ? "Без геолокации показываю Архангельск" : "Загружаю прогноз…")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
            }
        }
        .padding(16)
        .glass(22)
        .task {
            locator.refresh()
            await weather.refresh(city: city)
        }
        .onChange(of: locator.city) { c in
            Task { await weather.refresh(city: c) }
        }
    }
}
