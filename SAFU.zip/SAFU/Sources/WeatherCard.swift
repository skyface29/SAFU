import SwiftUI

// MARK: - Погода на главной: сейчас, по часам и что надеть
// Город — по геолокации (Архангельск или Северодвинск), прогноз — Open-Meteo, обновляется раз в час.

enum Outfit {
    struct Item: Hashable {
        let icon: String
        let text: String
    }

    /// Что надеть: по «ощущается», ветру и осадкам в ближайшие часы
    static func items(now h: WeatherHour, soon: [WeatherHour]) -> [Item] {
        var out: [Item] = []
        let f = h.feels
        switch f {
        case ..<(-25):
            out.append(Item(icon: "thermometer.snowflake", text: "Пуховик, термобельё и тёплые штаны"))
            out.append(Item(icon: "hand.raised.fill", text: "Варежки, а не перчатки"))
            out.append(Item(icon: "face.dashed", text: "Шапка и шарф — закрой лицо от мороза"))
        case -25..<(-15):
            out.append(Item(icon: "snowflake", text: "Зимняя куртка, шапка, шарф и тёплые перчатки"))
            out.append(Item(icon: "shoeprints.fill", text: "Зимняя обувь с толстой подошвой"))
        case -15..<(-5):
            out.append(Item(icon: "snowflake", text: "Тёплая куртка, шапка и перчатки"))
        case -5..<3:
            out.append(Item(icon: "wind.snow", text: "Демисезонная куртка и шапка"))
        case 3..<10:
            out.append(Item(icon: "cloud.sun.fill", text: "Лёгкая куртка или ветровка"))
        case 10..<17:
            out.append(Item(icon: "tshirt.fill", text: "Худи или кофта"))
        default:
            out.append(Item(icon: "sun.max.fill", text: "Можно в футболке — тепло"))
        }

        let windMax = ([h] + soon).map(\.wind).max() ?? h.wind
        if windMax >= 14 {
            out.append(Item(icon: "tornado", text: "Очень сильный ветер \(Int(windMax.rounded())) м/с — капюшон и ветрозащита, осторожно у щитов и деревьев"))
        } else if windMax >= 8 {
            out.append(Item(icon: "wind", text: "Ветер до \(Int(windMax.rounded())) м/с — с реки дует, пригодится капюшон"))
        }

        let window = [h] + soon
        let rain = window.contains { (51...67).contains($0.code) || (80...82).contains($0.code) || (95...99).contains($0.code) }
        let snow = window.contains { (71...77).contains($0.code) || $0.code == 85 || $0.code == 86 }
        if rain { out.append(Item(icon: "umbrella.fill", text: "Будет дождь — зонт или дождевик")) }
        if snow { out.append(Item(icon: "cloud.snow.fill", text: "Снег — непромокаемая обувь")) }
        // около нуля с осадками — гололёд
        if (rain || snow), window.contains(where: { $0.temp > -3 && $0.temp < 2 }) {
            out.append(Item(icon: "exclamationmark.triangle.fill", text: "Около нуля — скользко, осторожно на ступеньках"))
        }
        return out
    }

    static func windWord(_ w: Double) -> String {
        switch w {
        case ..<3: return "тихо"
        case 3..<8: return "ветерок"
        case 8..<14: return "сильный ветер"
        default: return "очень сильный ветер"
        }
    }

    static func sky(_ code: Int) -> String {
        switch code {
        case 0: return "Ясно"
        case 1, 2: return "Переменная облачность"
        case 3: return "Пасмурно"
        case 45, 48: return "Туман"
        case 51...57: return "Морось"
        case 61...67, 80...82: return "Дождь"
        case 71...77, 85, 86: return "Снег"
        case 95...99: return "Гроза"
        default: return "—"
        }
    }
}

extension Outfit {
    /// Коротко, в одну строку: «Зимняя куртка, шапка · капюшон — ветер · зонт»
    static func short(now h: WeatherHour, soon: [WeatherHour]) -> String {
        var parts: [String] = []
        switch h.feels {
        case ..<(-25): parts.append("Пуховик, варежки, закрой лицо")
        case -25..<(-15): parts.append("Зимняя куртка, шапка, шарф")
        case -15..<(-5): parts.append("Тёплая куртка и шапка")
        case -5..<3: parts.append("Куртка и шапка")
        case 3..<10: parts.append("Лёгкая куртка")
        case 10..<17: parts.append("Кофта или худи")
        default: parts.append("Футболка")
        }
        let window = [h] + soon
        let wind = window.map(\.wind).max() ?? h.wind
        if wind >= 8 { parts.append("капюшон — ветер \(Int(wind.rounded())) м/с") }
        if window.contains(where: { (51...67).contains($0.code) || (80...82).contains($0.code) || (95...99).contains($0.code) }) {
            parts.append("зонт")
        }
        if window.contains(where: { (71...77).contains($0.code) || $0.code == 85 || $0.code == 86 }) {
            parts.append("непромокаемая обувь")
        }
        return parts.joined(separator: " · ")
    }
}

/// Компактная погода: одна строка + «что надеть», подробности по нажатию
struct WeatherHomeCard: View {
    let data: ScheduleData
    @ObservedObject private var weather = WeatherStore.shared
    @ObservedObject private var locator = CityLocator.shared
    @AppStorage("weather.card.more") private var more = false

    private var city: HomeCity { locator.city ?? .arkhangelsk }
    private var now: WeatherHour? { weather.hour(at: Date()) }
    private var next: [WeatherHour] {
        let t = Date()
        return weather.hours.filter { $0.time > t }.prefix(12).map { $0 }
    }
    private var afterPairs: (Date, WeatherHour)? {
        guard let last = ScheduleEngine.slots(on: Date(), data: data).last, last.end > Date(),
              let h = weather.hour(at: last.end) else { return nil }
        return (last.end, h)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let h = now {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { more.toggle() }
                } label: {
                    HStack(spacing: 10) {
                        Text(WeatherCache.emoji(h.code)).font(.system(size: 28))
                        Text(WeatherCache.deg(h.temp))
                            .font(.system(size: 26, weight: .heavy, design: .rounded))
                            .foregroundStyle(.primary)
                        VStack(alignment: .leading, spacing: 1) {
                            Text("ощущ. \(WeatherCache.deg(h.feels)) · \(Int(h.wind.rounded())) м/с")
                                .font(.caption.weight(.semibold)).foregroundStyle(.primary)
                            Text(city == .arkhangelsk ? "Архангельск" : "Северодвинск")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "chevron.down")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.secondary)
                            .rotationEffect(.degrees(more ? 180 : 0))
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                // что надеть — сразу, одной строкой
                Label(Outfit.short(now: h, soon: Array(next.prefix(6))), systemImage: "tshirt.fill")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)

                if more {
                    VStack(alignment: .leading, spacing: 10) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(next, id: \.time) { x in
                                    VStack(spacing: 3) {
                                        Text(Fmt.formatter("HH").string(from: x.time))
                                            .font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
                                        Text(WeatherCache.emoji(x.code)).font(.subheadline)
                                        Text(WeatherCache.deg(x.temp)).font(.caption2.weight(.bold))
                                    }
                                    .frame(width: 34)
                                }
                            }
                        }
                        if let ap = afterPairs {
                            Label("После пар (\(Fmt.formatter("HH:mm").string(from: ap.0))): \(WeatherCache.line(ap.1))",
                                  systemImage: "figure.walk.departure")
                                .font(.caption.weight(.semibold))
                        }
                        ForEach(Outfit.items(now: h, soon: Array(next.prefix(6))), id: \.self) { it in
                            Label(it.text, systemImage: it.icon).font(.caption)
                        }
                    }
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }
            } else {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text("Погода загружается…").font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .glass(20)
        .task {
            locator.refresh()
            await weather.refresh(city: city)
        }
        .onChange(of: locator.city) { c in
            Task { await weather.refresh(city: c) }
        }
    }
}
