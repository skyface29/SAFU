import SwiftUI

// MARK: - Мини-игра «Трасса 150»
// Автобус едет из Северодвинска в Архангельск. Тап — прыжок (в воздухе можно ещё раз).
// Ямы, конусы, снеговики и лоси. ☕️ — +1 км, ⚡️ — турбо: несёшься и сносишь всё на пути.
// Пять чистых прыжков подряд — бонус. По дороге день сменяется закатом и ночью с северным сиянием.
// Доехал 60 км — успел на пару.

final class BusGame {
    enum Phase { case ready, running, over, won }

    enum Kind: CaseIterable {
        case pit, cone, snowman, moose
        var w: Double {
            switch self {
            case .pit: return 46
            case .cone: return 28
            case .snowman: return 44
            case .moose: return 54
            }
        }
        var h: Double {
            switch self {
            case .pit: return 14
            case .cone: return 34
            case .snowman: return 42
            case .moose: return 56
            }
        }
        var emoji: String {
            switch self {
            case .pit: return "🕳️"
            case .cone: return "🚧"
            case .snowman: return "⛄️"
            case .moose: return "🫎"
            }
        }
        var font: Double {
            switch self {
            case .pit: return 34
            case .cone: return 36
            case .snowman: return 44
            case .moose: return 56
            }
        }
    }

    struct Obstacle {
        var x: Double
        let kind: Kind
        var cleared = false
        var flung = false
        var fy: Double = 0
        var fvy: Double = 0
        var spin: Double = 0
    }
    struct Pickup { var x: Double; var y: Double; let turbo: Bool; var taken = false }
    struct Particle { var x: Double; var y: Double; var vx: Double; var vy: Double; var age: Double = 0; let life: Double; let size: Double; let kind: Int }
    struct Floater { var x: Double; var y: Double; var age: Double = 0; let text: String; let big: Bool }

    var phase: Phase = .ready
    var last: Date?
    var y: Double = 0          // высота над дорогой
    var vy: Double = 0
    var jumps = 0
    var speed: Double = 260
    var distance: Double = 0   // пиксели
    var bonusKm: Double = 0
    var obstacles: [Obstacle] = []
    var pickups: [Pickup] = []
    var particles: [Particle] = []
    var floaters: [Floater] = []
    var spawnIn: Double = 1.2
    var coffeeIn: Double = 3
    var turboIn: Double = 16
    var exhaustIn: Double = 0
    var elapsed: Double = 0
    var shake: Double = 0
    var squash: Double = 0
    var turbo: Double = 0      // секунды турбо
    var combo = 0
    var bestCombo = 0
    var checkpoint = 1
    var newRecord = false
    var overAt: Date?

    static let goalKm: Double = 60
    static let pxPerKm: Double = 520

    var km: Double { min(Self.goalKm, distance / Self.pxPerKm + bonusKm) }

    static var best: Double {
        get { UserDefaults.standard.double(forKey: "game.best") }
        set { UserDefaults.standard.set(newValue, forKey: "game.best") }
    }

    func reset() {
        phase = .running
        last = nil; y = 0; vy = 0; jumps = 0; speed = 260; distance = 0; bonusKm = 0
        obstacles = []; pickups = []; particles = []; floaters = []
        spawnIn = 1.2; coffeeIn = 3; turboIn = 16; exhaustIn = 0; elapsed = 0
        shake = 0; squash = 0; turbo = 0; combo = 0; bestCombo = 0; checkpoint = 1; newRecord = false; overAt = nil
    }

    func tap() {
        switch phase {
        case .ready, .won:
            reset()
            Haptics.tap()
        case .over:
            // не перезапускаем случайным тапом сразу после аварии
            if let o = overAt, Date().timeIntervalSince(o) < 0.7 { return }
            reset()
            Haptics.tap()
        case .running:
            if jumps < 2 {
                vy = jumps == 0 ? 820 : 720
                jumps += 1
                Haptics.tap()
            }
        }
    }

    private func float(_ text: String, x: Double, y: Double, big: Bool = false) {
        floaters.append(Floater(x: x, y: y, text: text, big: big))
    }

    private func burst(x: Double, y: Double, count: Int, kind: Int, power: Double) {
        for _ in 0..<count {
            let a = Double.random(in: 0...(2 * .pi))
            let v = Double.random(in: 0.3...1) * power
            particles.append(Particle(x: x, y: y, vx: cos(a) * v, vy: sin(a) * v - power * 0.3,
                                      life: Double.random(in: 0.4...1.0), size: Double.random(in: 2...6), kind: kind))
        }
    }

    func update(_ now: Date, width: Double, ground: Double, busX: Double) {
        let dt = min(1.0 / 20, now.timeIntervalSince(last ?? now))
        last = now
        shake = max(0, shake - dt * 2.5)
        squash = max(0, squash - dt * 5)

        // частицы и надписи живут и после аварии
        for i in particles.indices {
            particles[i].age += dt
            particles[i].x += particles[i].vx * dt
            particles[i].y += particles[i].vy * dt
            if particles[i].kind != 0 { particles[i].vy += 900 * dt }
        }
        particles.removeAll { $0.age > $0.life }
        for i in floaters.indices { floaters[i].age += dt; floaters[i].y -= 40 * dt }
        floaters.removeAll { $0.age > ($0.big ? 2.2 : 1.1) }
        for i in obstacles.indices where obstacles[i].flung {
            obstacles[i].fvy += 1600 * dt
            obstacles[i].fy += obstacles[i].fvy * dt
            obstacles[i].spin += dt * 9
            obstacles[i].x += 220 * dt
        }

        guard phase == .running else { return }
        elapsed += dt

        if turbo > 0 { turbo = max(0, turbo - dt) }
        let base = min(640, 260 + elapsed * 9)
        speed = turbo > 0 ? base * 1.55 : base
        distance += speed * dt

        // прыжок
        let wasAir = y > 0
        vy -= 2500 * dt
        y += vy * dt
        if y <= 0 {
            if wasAir && vy < -300 {
                squash = 1
                burst(x: busX, y: ground - 2, count: 6, kind: 1, power: 120)
            }
            y = 0; vy = 0; jumps = 0
        }

        // выхлоп
        exhaustIn -= dt
        if exhaustIn <= 0 {
            exhaustIn = turbo > 0 ? 0.025 : 0.06
            particles.append(Particle(x: busX - 30, y: ground - y - 12, vx: -speed * 0.25 - 40,
                                      vy: Double.random(in: -50 ... -15), life: 0.7,
                                      size: Double.random(in: 5...9), kind: turbo > 0 ? 3 : 0))
        }

        // препятствия
        for i in obstacles.indices where !obstacles[i].flung { obstacles[i].x -= speed * dt }
        obstacles.removeAll { $0.x < -90 || $0.fy > 900 }
        spawnIn -= dt
        if spawnIn <= 0 {
            var kinds: [Kind] = [.pit, .cone, .snowman, .pit, .cone]
            if km > 12 { kinds.append(.moose) }
            if km > 35 { kinds.append(.moose) }
            obstacles.append(Obstacle(x: width + 60, kind: kinds.randomElement() ?? .pit))
            spawnIn = Double.random(in: 0.75...1.6) * (340 / speed + 0.35)
        }

        // кофе и турбо
        for i in pickups.indices { pickups[i].x -= speed * dt }
        pickups.removeAll { $0.x < -40 || $0.taken }
        coffeeIn -= dt
        if coffeeIn <= 0 {
            pickups.append(Pickup(x: width + 40, y: Double.random(in: 70...150), turbo: false))
            coffeeIn = Double.random(in: 3...6)
        }
        turboIn -= dt
        if turboIn <= 0 {
            pickups.append(Pickup(x: width + 40, y: Double.random(in: 110...170), turbo: true))
            turboIn = Double.random(in: 18...28)
        }

        // столкновения
        let busRect = CGRect(x: busX - 24, y: ground - y - 34, width: 50, height: 30)
        for i in obstacles.indices where !obstacles[i].flung {
            let o = obstacles[i]
            let r = CGRect(x: o.x - o.kind.w / 2 + 6, y: ground - o.kind.h + 4, width: o.kind.w - 12, height: o.kind.h - 4)
            if busRect.intersects(r) {
                if turbo > 0 {
                    obstacles[i].flung = true
                    obstacles[i].fvy = -700
                    shake = max(shake, 0.4)
                    burst(x: o.x, y: ground - o.kind.h / 2, count: 10, kind: 2, power: 320)
                    float(["БАХ!", "ХРЯСЬ!", "С ДОРОГИ!"].randomElement() ?? "БАХ!", x: o.x, y: ground - 80)
                    Haptics.tap()
                    continue
                }
                phase = .over
                overAt = now
                shake = 1
                combo = 0
                burst(x: busX, y: ground - y - 20, count: 30, kind: 2, power: 420)
                float("💥", x: busX, y: ground - y - 30, big: true)
                if km > Self.best { Self.best = km; newRecord = true }
                Haptics.success()
                return
            }
            // чистый прыжок через препятствие
            if !o.cleared && o.x < busX - 30 {
                obstacles[i].cleared = true
                combo += 1
                bestCombo = max(bestCombo, combo)
                if combo % 5 == 0 {
                    bonusKm += 1
                    float("Комбо ×\(combo) · +1 км", x: busX + 40, y: ground - 150, big: true)
                    Haptics.success()
                }
            }
        }
        for i in pickups.indices where !pickups[i].taken {
            let r = CGRect(x: pickups[i].x - 16, y: ground - pickups[i].y - 16, width: 32, height: 32)
            if busRect.intersects(r) {
                pickups[i].taken = true
                if pickups[i].turbo {
                    turbo = 4
                    float("ТУРБО ⚡️", x: busX + 30, y: ground - 170, big: true)
                    burst(x: pickups[i].x, y: ground - pickups[i].y, count: 14, kind: 3, power: 260)
                    Haptics.success()
                } else {
                    bonusKm += 1
                    float("+1 км ☕️", x: pickups[i].x, y: ground - pickups[i].y - 20)
                    Haptics.tap()
                }
            }
        }

        // отметки на трассе
        let marks = [(15.0, "15 км · держись"), (30.0, "Полпути! ☕️"), (45.0, "Финишная прямая 🔥")]
        if checkpoint <= marks.count, km >= marks[checkpoint - 1].0 {
            float(marks[checkpoint - 1].1, x: width / 2, y: ground * 0.5, big: true)
            checkpoint += 1
            Haptics.success()
        }

        if km >= Self.goalKm {
            phase = .won
            Self.best = Self.goalKm
            Eggs.mark(.arrived)
            burst(x: busX, y: ground - 40, count: 40, kind: 3, power: 500)
            CelebrationCenter.shared.fire(Celebration(title: "Доехал! Успел на пару 🎓",
                                                      subtitle: "60 км за \(Int(elapsed)) сек. Ты легенда трассы 150",
                                                      style: .emoji(["🚌", "🎓", "☕️", "🎉"]), force: true))
        }
    }
}

// MARK: - Экран

struct BusGameView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var game = BusGame()

    var body: some View {
        GeometryReader { geo in
            TimelineView(.animation(paused: false)) { ctx in
                Canvas { g, size in
                    draw(&g, size: size, now: ctx.date)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { game.tap() }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .background(Color.black)
        .ignoresSafeArea()
        .overlay(alignment: .topTrailing) {
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(.black.opacity(0.35), in: Circle())
            }
            .padding(.trailing, 18)
            .padding(.top, 8)
        }
        .statusBarHidden()
    }

    // MARK: цвета по ходу поездки: день → закат → ночь

    private struct Tint {
        var r: Double, g: Double, b: Double
        static func mix(_ a: Tint, _ b: Tint, _ f: Double) -> Tint {
            let f = min(1, max(0, f))
            return Tint(r: a.r + (b.r - a.r) * f, g: a.g + (b.g - a.g) * f, b: a.b + (b.b - a.b) * f)
        }
        static func ramp(_ p: Double, _ keys: [(Double, Tint)]) -> Tint {
            guard let first = keys.first, let last = keys.last else { return Tint(r: 0, g: 0, b: 0) }
            if p <= first.0 { return first.1 }
            for i in 1..<keys.count where p <= keys[i].0 {
                return mix(keys[i - 1].1, keys[i].1, (p - keys[i - 1].0) / (keys[i].0 - keys[i - 1].0))
            }
            return last.1
        }
        func color(_ o: Double = 1) -> Color { Color(red: r, green: g, blue: b).opacity(o) }
    }

    private static func noise(_ i: Int) -> Double {
        let v = sin(Double(i) * 12.9898 + 78.233) * 43758.5453
        return v - v.rounded(.down)
    }

    private func draw(_ g: inout GraphicsContext, size: CGSize, now: Date) {
        let w = Double(size.width), h = Double(size.height)
        let ground = h * 0.70
        let busX = w * 0.22
        game.update(now, width: w, ground: ground, busX: busX)
        let t = now.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 10_000)
        let p = game.phase == .ready ? 0 : game.km / BusGame.goalKm
        let night = min(1, max(0, (p - 0.55) / 0.3))

        if game.shake > 0 {
            g.translateBy(x: CGFloat(sin(t * 60) * 9 * game.shake), y: CGFloat(cos(t * 47) * 5 * game.shake))
        }

        // небо
        let top = Tint.ramp(p, [(0, Tint(r: 0.36, g: 0.64, b: 0.96)), (0.4, Tint(r: 0.3, g: 0.42, b: 0.82)),
                                (0.62, Tint(r: 0.2, g: 0.14, b: 0.4)), (0.85, Tint(r: 0.03, g: 0.04, b: 0.13))])
        let bottom = Tint.ramp(p, [(0, Tint(r: 0.82, g: 0.92, b: 1)), (0.4, Tint(r: 1, g: 0.74, b: 0.48)),
                                   (0.62, Tint(r: 0.96, g: 0.42, b: 0.32)), (0.85, Tint(r: 0.1, g: 0.1, b: 0.26))])
        let sky = CGRect(x: -20, y: -20, width: w + 40, height: ground + 20)
        g.fill(Path(sky), with: .linearGradient(Gradient(colors: [top.color(), bottom.color()]),
                                                startPoint: CGPoint(x: 0, y: 0), endPoint: CGPoint(x: 0, y: ground)))

        // звёзды и северное сияние
        if night > 0 {
            for i in 0..<70 {
                let stx = Self.noise(i) * w
                let sty = Self.noise(i + 500) * ground * 0.75
                let tw = 0.5 + 0.5 * sin(t * (1 + Self.noise(i + 900) * 3) + Double(i))
                let r = 0.6 + Self.noise(i + 300) * 1.2
                g.fill(Path(ellipseIn: CGRect(x: stx - r, y: sty - r, width: r * 2, height: r * 2)),
                       with: .color(.white.opacity(night * (0.35 + 0.65 * tw))))
            }
            var aurora = g
            aurora.blendMode = .plusLighter
            aurora.addFilter(.blur(radius: 14))
            for band in 0..<3 {
                var path = Path()
                let baseY = ground * (0.18 + Double(band) * 0.09)
                path.move(to: CGPoint(x: -20, y: baseY))
                var ax = -20.0
                while ax <= w + 20 {
                    let yy = baseY + sin(ax / 70 + t * 0.6 + Double(band) * 2) * 18 + sin(ax / 31 - t * 0.9) * 7
                    path.addLine(to: CGPoint(x: ax, y: yy))
                    ax += 10
                }
                path.addLine(to: CGPoint(x: w + 20, y: baseY + 90))
                path.addLine(to: CGPoint(x: -20, y: baseY + 90))
                path.closeSubpath()
                let c = band == 1 ? Color(red: 0.4, green: 0.6, blue: 1) : Color(red: 0.25, green: 1, blue: 0.55)
                aurora.fill(path, with: .linearGradient(Gradient(colors: [c.opacity(0.55 * night), c.opacity(0)]),
                                                        startPoint: CGPoint(x: 0, y: baseY - 20), endPoint: CGPoint(x: 0, y: baseY + 90)))
            }
        }

        // солнце садится, луна встаёт
        let sunY = ground * (0.18 + p * 1.05)
        if sunY < ground + 40 {
            let sunC = Tint.mix(Tint(r: 1, g: 0.95, b: 0.7), Tint(r: 1, g: 0.45, b: 0.2), p * 1.6)
            g.fill(Path(ellipseIn: CGRect(x: w * 0.74 - 70, y: sunY - 70, width: 140, height: 140)),
                   with: .radialGradient(Gradient(colors: [sunC.color(0.5), sunC.color(0)]), center: CGPoint(x: w * 0.74, y: sunY),
                                         startRadius: 0, endRadius: 70))
            g.fill(Path(ellipseIn: CGRect(x: w * 0.74 - 24, y: sunY - 24, width: 48, height: 48)), with: .color(sunC.color()))
        }
        if night > 0 {
            let my = ground * (0.55 - 0.35 * night)
            g.fill(Path(ellipseIn: CGRect(x: w * 0.3 - 16, y: my - 16, width: 32, height: 32)),
                   with: .color(Color(red: 0.95, green: 0.95, blue: 0.85).opacity(night)))
            g.fill(Path(ellipseIn: CGRect(x: w * 0.3 - 9, y: my - 19, width: 32, height: 32)), with: .color(top.color(night)))
        }

        // дальние холмы
        let hill = Tint.mix(Tint.mix(bottom, Tint(r: 0.2, g: 0.3, b: 0.4), 0.55), Tint(r: 0.04, g: 0.05, b: 0.1), night)
        var hills = Path()
        hills.move(to: CGPoint(x: -20, y: ground))
        var hx = -20.0
        let hoff = game.distance * 0.04
        while hx <= w + 20 {
            let yy = ground - 50 - sin((hx + hoff) / 120) * 18 - sin((hx + hoff) / 47) * 8
            hills.addLine(to: CGPoint(x: hx, y: yy))
            hx += 12
        }
        hills.addLine(to: CGPoint(x: w + 20, y: ground))
        hills.closeSubpath()
        g.fill(hills, with: .color(hill.color()))

        // дома (параллакс)
        let city = Tint.mix(Tint.mix(bottom, Tint(r: 0.1, g: 0.12, b: 0.18), 0.6), Tint(r: 0.03, g: 0.03, b: 0.07), night)
        let off = game.distance * 0.15
        var x = -(off.truncatingRemainder(dividingBy: 90))
        var i = Int(off / 90)
        while x < w + 90 {
            let bh = 30 + Double((i * 37) % 60)
            g.fill(Path(CGRect(x: x, y: ground - bh - 26, width: 64, height: bh + 26)), with: .color(city.color(0.95)))
            if night > 0.2 {
                for wy in stride(from: ground - bh - 18, to: ground - 20, by: 14) {
                    for wx in [x + 10, x + 28, x + 46] where (Int(wx + wy) / 7 + i) % 3 == 0 {
                        g.fill(Path(CGRect(x: wx, y: wy, width: 6, height: 7)), with: .color(Color.yellow.opacity(0.7 * night)))
                    }
                }
            }
            x += 90; i += 1
        }

        // ёлки у дороги
        let pine = Tint.mix(Tint(r: 0.1, g: 0.32, b: 0.22), Tint(r: 0.02, g: 0.07, b: 0.06), night)
        let poff = game.distance * 0.4
        var px = -(poff.truncatingRemainder(dividingBy: 38))
        var pineIdx = Int(poff / 38)
        while px < w + 40 {
            let ph = 34 + Self.noise(pineIdx) * 40
            var tree = Path()
            tree.move(to: CGPoint(x: px, y: ground - ph))
            tree.addLine(to: CGPoint(x: px + 15, y: ground - 4))
            tree.addLine(to: CGPoint(x: px - 15, y: ground - 4))
            tree.closeSubpath()
            g.fill(tree, with: .color(pine.color()))
            if night < 0.5 {
                // снег на макушке
                var cap = Path()
                cap.move(to: CGPoint(x: px, y: ground - ph))
                cap.addLine(to: CGPoint(x: px + 5, y: ground - ph + 10))
                cap.addLine(to: CGPoint(x: px - 5, y: ground - ph + 10))
                cap.closeSubpath()
                g.fill(cap, with: .color(.white.opacity(0.85 * (1 - night * 2))))
            }
            px += 38; pineIdx += 1
        }

        // дорога с обочиной
        g.fill(Path(CGRect(x: -20, y: ground - 4, width: w + 40, height: 6)), with: .color(Color(white: 0.85 - 0.6 * night)))
        g.fill(Path(CGRect(x: -20, y: ground, width: w + 40, height: h - ground + 20)),
               with: .linearGradient(Gradient(colors: [Color(white: 0.3 - 0.16 * night), Color(white: 0.18 - 0.12 * night)]),
                                     startPoint: CGPoint(x: 0, y: ground), endPoint: CGPoint(x: 0, y: h)))
        let dash = -(game.distance.truncatingRemainder(dividingBy: 60))
        var dx = dash
        while dx < w {
            g.fill(Path(CGRect(x: dx, y: ground + 34, width: 30, height: 4)), with: .color(.white.opacity(0.7)))
            dx += 60
        }
        // столбики со светоотражателями
        let postGap = 180.0
        var sx = -(game.distance.truncatingRemainder(dividingBy: postGap))
        while sx < w + 20 {
            g.fill(Path(CGRect(x: sx, y: ground + 44, width: 4, height: 18)), with: .color(.white.opacity(0.8)))
            g.fill(Path(CGRect(x: sx, y: ground + 46, width: 4, height: 5)), with: .color(Color.orange.opacity(0.6 + 0.4 * night)))
            sx += postGap
        }
        // километровые знаки каждые 5 км
        let signGap = BusGame.pxPerKm * 5
        let firstSign = (game.distance / signGap).rounded(.up)
        let signX = firstSign * signGap - game.distance + busX
        if firstSign > 0, signX < w + 60 {
            let n = Int(firstSign) * 5
            g.fill(Path(CGRect(x: signX - 1.5, y: ground - 58, width: 3, height: 58)), with: .color(Color(white: 0.55)))
            let board = CGRect(x: signX - 26, y: ground - 82, width: 52, height: 26)
            g.fill(Path(roundedRect: board, cornerRadius: 4), with: .color(Color(red: 0.1, green: 0.45, blue: 0.25)))
            g.stroke(Path(roundedRect: board.insetBy(dx: 2, dy: 2), cornerRadius: 3), with: .color(.white), lineWidth: 1)
            g.draw(g.resolve(Text("\(n) км").font(.system(size: 12, weight: .heavy, design: .rounded)).foregroundColor(.white)),
                   at: CGPoint(x: signX, y: ground - 69))
        }

        // фары ночью
        if night > 0.25 {
            var beam = Path()
            let by = ground - game.y - 14
            beam.move(to: CGPoint(x: busX + 26, y: by))
            beam.addLine(to: CGPoint(x: busX + 230, y: by - 30))
            beam.addLine(to: CGPoint(x: busX + 230, y: by + 36))
            beam.closeSubpath()
            var lit = g
            lit.blendMode = .plusLighter
            lit.fill(beam, with: .linearGradient(Gradient(colors: [Color.yellow.opacity(0.45 * night), .clear]),
                                                 startPoint: CGPoint(x: busX + 26, y: by), endPoint: CGPoint(x: busX + 230, y: by)))
        }

        // препятствия
        for o in game.obstacles {
            let txt = g.resolve(Text(o.kind.emoji).font(.system(size: o.kind.font)))
            var c = g
            c.translateBy(x: o.x, y: ground - o.kind.h / 2 + (o.kind == .pit ? 6 : 0) + o.fy)
            if o.flung { c.rotate(by: .radians(o.spin)) }
            if o.kind == .moose { c.scaleBy(x: -1, y: 1) }   // лось смотрит на автобус
            c.draw(txt, at: .zero)
        }
        // кофе и турбо
        for pk in game.pickups {
            let bob = sin(t * 4 + pk.x / 40) * 5
            let pt = CGPoint(x: pk.x, y: ground - pk.y + bob)
            if pk.turbo {
                var glow = g
                glow.blendMode = .plusLighter
                glow.fill(Path(ellipseIn: CGRect(x: pt.x - 26, y: pt.y - 26, width: 52, height: 52)),
                          with: .radialGradient(Gradient(colors: [Color.yellow.opacity(0.7), .clear]), center: pt, startRadius: 0, endRadius: 26))
            }
            g.draw(g.resolve(Text(pk.turbo ? "⚡️" : "☕️").font(.system(size: pk.turbo ? 30 : 26))), at: pt)
        }

        // частицы
        for pt in game.particles {
            let a = max(0, 1 - pt.age / pt.life)
            let r = pt.kind == 0 ? pt.size * (1 + pt.age * 2) : pt.size
            let rect = CGRect(x: pt.x - r, y: pt.y - r, width: r * 2, height: r * 2)
            switch pt.kind {
            case 0: g.fill(Path(ellipseIn: rect), with: .color(Color(white: 0.75).opacity(0.45 * a)))
            case 1: g.fill(Path(ellipseIn: rect), with: .color(Color(red: 0.8, green: 0.75, blue: 0.7).opacity(0.7 * a)))
            case 2: g.fill(Path(ellipseIn: rect), with: .color(Color(red: 1, green: 0.6 * a + 0.2, blue: 0.1).opacity(a)))
            default:
                var l = g
                l.blendMode = .plusLighter
                l.fill(Path(ellipseIn: rect), with: .color(Color(red: 1, green: 0.85, blue: 0.3).opacity(a)))
            }
        }

        // автобус (эмодзи смотрит влево — отражаем)
        let busY = ground - game.y - 20
        if game.turbo > 0 {
            var glow = g
            glow.blendMode = .plusLighter
            let pulse = 0.6 + 0.4 * sin(t * 20)
            glow.fill(Path(ellipseIn: CGRect(x: busX - 50, y: busY - 44, width: 100, height: 88)),
                      with: .radialGradient(Gradient(colors: [Color.yellow.opacity(0.55 * pulse), .clear]),
                                            center: CGPoint(x: busX, y: busY), startRadius: 0, endRadius: 50))
            g.draw(g.resolve(Text("🔥").font(.system(size: 26))), at: CGPoint(x: busX - 40, y: busY + 6))
        }
        var bus = g
        bus.translateBy(x: busX, y: busY + game.squash * 6)
        bus.scaleBy(x: -(1 + game.squash * 0.12), y: 1 - game.squash * 0.15)
        if game.y > 0 { bus.rotate(by: .degrees(max(-14, min(10, -game.vy / 80)))) }
        if game.phase == .over { bus.rotate(by: .degrees(18)) }
        bus.draw(g.resolve(Text("🚌").font(.system(size: 50))), at: .zero)

        // всплывающие надписи
        for f in game.floaters {
            let a = max(0, 1 - f.age / (f.big ? 2.2 : 1.1))
            let s = f.big ? 24.0 : 17.0
            let pop = f.age < 0.15 ? 0.6 + f.age / 0.15 * 0.4 : 1
            var c = g
            c.opacity = a
            c.translateBy(x: f.x, y: f.y)
            c.scaleBy(x: pop, y: pop)
            c.draw(c.resolve(Text(f.text).font(.system(size: s, weight: .heavy, design: .rounded)).foregroundColor(.white)),
                   at: .zero)
        }

        // табло
        let km = game.km
        g.draw(g.resolve(Text("\(Int(km)) / \(Int(BusGame.goalKm)) км").font(.system(size: 24, weight: .heavy, design: .rounded)).foregroundColor(.white)),
               at: CGPoint(x: 24, y: 60), anchor: .leading)
        var sub = "рекорд \(Int(BusGame.best)) км"
        if game.combo >= 2 { sub += "  ·  комбо ×\(game.combo)" }
        g.draw(g.resolve(Text(sub).font(.system(size: 13, weight: .bold)).foregroundColor(.white.opacity(0.85))),
               at: CGPoint(x: 24, y: 86), anchor: .leading)
        // прогресс по трассе
        let barW = w - 48
        g.fill(Path(roundedRect: CGRect(x: 24, y: 104, width: barW, height: 6), cornerRadius: 3), with: .color(.white.opacity(0.25)))
        g.fill(Path(roundedRect: CGRect(x: 24, y: 104, width: barW * km / BusGame.goalKm, height: 6), cornerRadius: 3),
               with: .linearGradient(Gradient(colors: [.orange, .yellow]), startPoint: CGPoint(x: 24, y: 0), endPoint: CGPoint(x: 24 + barW, y: 0)))
        var mini = g
        mini.translateBy(x: 24 + barW * km / BusGame.goalKm, y: 106)
        mini.scaleBy(x: -1, y: 1)
        mini.draw(g.resolve(Text("🚌").font(.system(size: 14))), at: .zero)
        g.draw(g.resolve(Text("Северодвинск").font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.8))),
               at: CGPoint(x: 24, y: 124), anchor: .leading)
        g.draw(g.resolve(Text("Архангельск").font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.8))),
               at: CGPoint(x: w - 24, y: 124), anchor: .trailing)
        if game.turbo > 0 {
            g.fill(Path(roundedRect: CGRect(x: 24, y: 136, width: 90, height: 5), cornerRadius: 2.5), with: .color(.white.opacity(0.2)))
            g.fill(Path(roundedRect: CGRect(x: 24, y: 136, width: 90 * game.turbo / 4, height: 5), cornerRadius: 2.5), with: .color(.yellow))
        }

        // экраны
        let center = CGPoint(x: w / 2, y: h * 0.36)
        switch game.phase {
        case .ready:
            banner(&g, at: center, title: "Трасса 150",
                   text: "Тап — прыжок, в воздухе ещё раз.\n☕️ +1 км · ⚡️ турбо · берегись лосей.\nНужно 60 км до пары.")
        case .over:
            banner(&g, at: center, title: game.newRecord ? "Новый рекорд! \(Int(km)) км 🏆" : "Авария на \(Int(km)) км 💥",
                   text: "Лучшее комбо ×\(game.bestCombo).\nТап — ещё раз. Автобус не ждёт!")
        case .won:
            banner(&g, at: center, title: "Доехал! 🎓", text: "Успел на пару. Комбо ×\(game.bestCombo).\nТап — поехать снова")
        case .running:
            break
        }
    }

    private func banner(_ g: inout GraphicsContext, at p: CGPoint, title: String, text: String) {
        let box = CGRect(x: p.x - 160, y: p.y - 66, width: 320, height: 138)
        g.fill(Path(roundedRect: box, cornerRadius: 24), with: .color(.black.opacity(0.5)))
        g.stroke(Path(roundedRect: box, cornerRadius: 24), with: .color(.white.opacity(0.15)), lineWidth: 1)
        g.draw(g.resolve(Text(title).font(.system(size: 24, weight: .heavy, design: .rounded)).foregroundColor(.white)),
               at: CGPoint(x: p.x, y: p.y - 30))
        g.draw(g.resolve(Text(text).font(.system(size: 13, weight: .semibold)).foregroundColor(.white.opacity(0.85))),
               in: CGRect(x: box.minX + 16, y: p.y - 8, width: box.width - 32, height: 70))
    }
}
