import SwiftUI

// MARK: - Мини-игра «Трасса 150»
// Автобус едет из Северодвинска в Архангельск. Тап — прыжок (в воздухе можно ещё раз).
// Перепрыгивай ямы, конусы и сугробы, собирай кофе (+1 км). Доехал 60 км — успел на пару.

final class BusGame {
    enum Phase { case ready, running, over, won }

    struct Obstacle { var x: Double; let kind: Int; let w: Double; let h: Double }
    struct Coffee { var x: Double; var y: Double; var taken = false }

    var phase: Phase = .ready
    var last: Date?
    var y: Double = 0          // высота над дорогой
    var vy: Double = 0
    var jumps = 0
    var speed: Double = 260
    var distance: Double = 0   // пиксели
    var bonusKm: Double = 0
    var obstacles: [Obstacle] = []
    var coffees: [Coffee] = []
    var spawnIn: Double = 1.2
    var coffeeIn: Double = 3
    var elapsed: Double = 0
    var shake: Double = 0

    static let goalKm: Double = 60
    static let pxPerKm: Double = 520

    var km: Double { min(Self.goalKm, distance / Self.pxPerKm + bonusKm) }

    static var best: Double {
        get { UserDefaults.standard.double(forKey: "game.best") }
        set { UserDefaults.standard.set(newValue, forKey: "game.best") }
    }

    func reset() {
        phase = .running
        last = nil; y = 0; vy = 0; jumps = 0; speed = 260; distance = 0; bonusKm = 0
        obstacles = []; coffees = []; spawnIn = 1.2; coffeeIn = 3; elapsed = 0; shake = 0
    }

    func tap() {
        switch phase {
        case .ready, .over, .won:
            reset()
            Haptics.tap()
        case .running:
            if jumps < 2 {
                vy = jumps == 0 ? 820 : 700
                jumps += 1
                Haptics.tap()
            }
        }
    }

    func step(_ now: Date, width: Double) {
        guard phase == .running else { last = now; return }
        let dt = min(1.0 / 20, now.timeIntervalSince(last ?? now))
        last = now
        elapsed += dt
        shake = max(0, shake - dt * 3)

        speed = min(640, 260 + elapsed * 9)
        distance += speed * dt

        // прыжок
        vy -= 2500 * dt
        y += vy * dt
        if y <= 0 { y = 0; vy = 0; jumps = 0 }

        // препятствия
        for i in obstacles.indices { obstacles[i].x -= speed * dt }
        obstacles.removeAll { $0.x < -80 }
        spawnIn -= dt
        if spawnIn <= 0 {
            let kind = Int.random(in: 0...2)
            let size: (Double, Double) = kind == 0 ? (46, 14) : (kind == 1 ? (28, 34) : (48, 26))
            obstacles.append(Obstacle(x: width + 40, kind: kind, w: size.0, h: size.1))
            spawnIn = Double.random(in: 0.75...1.6) * (340 / speed + 0.35)
        }

        // кофе
        for i in coffees.indices { coffees[i].x -= speed * dt }
        coffees.removeAll { $0.x < -40 || $0.taken }
        coffeeIn -= dt
        if coffeeIn <= 0 {
            coffees.append(Coffee(x: width + 40, y: Double.random(in: 70...150)))
            coffeeIn = Double.random(in: 3...6)
        }
    }

    /// Проверка столкновений в координатах экрана
    func collide(busX: Double, ground: Double) {
        guard phase == .running else { return }
        let busRect = CGRect(x: busX - 24, y: ground - y - 34, width: 50, height: 30)
        for o in obstacles {
            let r = CGRect(x: o.x - o.w / 2 + 6, y: ground - o.h + 4, width: o.w - 12, height: o.h - 4)
            if busRect.intersects(r) {
                phase = .over
                shake = 1
                if km > Self.best { Self.best = km }
                Haptics.success()
                return
            }
        }
        for i in coffees.indices where !coffees[i].taken {
            let r = CGRect(x: coffees[i].x - 14, y: ground - coffees[i].y - 14, width: 28, height: 28)
            if busRect.intersects(r) {
                coffees[i].taken = true
                bonusKm += 1
                Haptics.tap()
            }
        }
        if km >= Self.goalKm {
            phase = .won
            Self.best = Self.goalKm
            Eggs.mark(.arrived)
            CelebrationCenter.shared.fire(Celebration(title: "Доехал! Успел на пару 🎓",
                                                      subtitle: "60 км за \(Int(elapsed)) сек. Ты легенда трассы 150",
                                                      style: .emoji(["🚌", "🎓", "☕️", "🎉"]), force: true))
        }
    }
}

struct BusGameView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @State private var game = BusGame()

    var body: some View {
        GeometryReader { geo in
            TimelineView(.animation(paused: false)) { ctx in
                Canvas { g, size in
                    draw(&g, size: size, now: ctx.date)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture { game.tap() }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .background(sky)
        .ignoresSafeArea()
        .overlay(alignment: .topTrailing) {
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(.black.opacity(0.35), in: Circle())
            }
            .padding(.trailing, 18)
            .padding(.top, 8)
        }
        .statusBarHidden()
    }

    private var sky: some View {
        LinearGradient(colors: scheme == .dark
                       ? [Color(red: 0.05, green: 0.07, blue: 0.18), Color(red: 0.18, green: 0.14, blue: 0.30)]
                       : [Color(red: 0.55, green: 0.78, blue: 0.98), Color(red: 0.98, green: 0.80, blue: 0.62)],
                       startPoint: .top, endPoint: .bottom)
    }

    private func draw(_ g: inout GraphicsContext, size: CGSize, now: Date) {
        let w = Double(size.width), h = Double(size.height)
        game.step(now, width: w)
        let ground = h * 0.70
        let busX = w * 0.22
        game.collide(busX: busX, ground: ground)

        if game.shake > 0 {
            g.translateBy(x: CGFloat(sin(now.timeIntervalSince1970 * 60) * 6 * game.shake), y: 0)
        }

        // дальние дома (параллакс)
        let city = Color.black.opacity(scheme == .dark ? 0.35 : 0.12)
        let off = game.distance * 0.15
        var x = -(off.truncatingRemainder(dividingBy: 90))
        var i = Int(off / 90)
        while x < w + 90 {
            let bh = 40 + Double((i * 37) % 70)
            g.fill(Path(CGRect(x: x, y: ground - bh - 30, width: 70, height: bh + 30)), with: .color(city))
            // окна
            if scheme == .dark {
                for wy in stride(from: ground - bh - 20, to: ground - 20, by: 16) {
                    for wx in [x + 12, x + 32, x + 52] where (Int(wx + wy) / 7) % 3 == 0 {
                        g.fill(Path(CGRect(x: wx, y: wy, width: 6, height: 7)), with: .color(Color.yellow.opacity(0.5)))
                    }
                }
            }
            x += 90; i += 1
        }

        // дорога
        g.fill(Path(CGRect(x: 0, y: ground, width: w, height: h - ground)),
               with: .color(Color(white: scheme == .dark ? 0.16 : 0.32)))
        let dash = -(game.distance.truncatingRemainder(dividingBy: 60))
        var dx = dash
        while dx < w {
            g.fill(Path(CGRect(x: dx, y: ground + 34, width: 30, height: 4)), with: .color(.white.opacity(0.7)))
            dx += 60
        }

        // препятствия
        for o in game.obstacles {
            let emoji = o.kind == 0 ? "🕳️" : (o.kind == 1 ? "🚧" : "⛄️")
            let t = g.resolve(Text(emoji).font(.system(size: o.kind == 0 ? 34 : 36)))
            g.draw(t, at: CGPoint(x: o.x, y: ground - o.h / 2 + (o.kind == 0 ? 6 : 0)))
        }
        // кофе
        for c in game.coffees {
            let bob = sin(now.timeIntervalSince1970 * 4 + c.x / 40) * 5
            g.draw(g.resolve(Text("☕️").font(.system(size: 26))), at: CGPoint(x: c.x, y: ground - c.y + bob))
        }

        // автобус (эмодзи смотрит влево — отражаем)
        var bus = g
        bus.translateBy(x: busX, y: ground - game.y - 20)
        bus.scaleBy(x: -1, y: 1)
        if game.y > 0 { bus.rotate(by: .degrees(-6)) }
        bus.draw(g.resolve(Text("🚌").font(.system(size: 50))), at: .zero)

        // табло
        let km = game.km
        let hud = "\(Int(km)) / \(Int(BusGame.goalKm)) км"
        g.draw(g.resolve(Text(hud).font(.system(size: 22, weight: .heavy, design: .rounded)).foregroundColor(.white)),
               at: CGPoint(x: 24, y: 60), anchor: .leading)
        g.draw(g.resolve(Text("рекорд \(Int(BusGame.best)) км").font(.system(size: 13, weight: .bold)).foregroundColor(.white.opacity(0.8))),
               at: CGPoint(x: 24, y: 86), anchor: .leading)
        // прогресс по трассе
        let barW = w - 48
        g.fill(Path(roundedRect: CGRect(x: 24, y: 104, width: barW, height: 6), cornerRadius: 3), with: .color(.white.opacity(0.25)))
        g.fill(Path(roundedRect: CGRect(x: 24, y: 104, width: barW * km / BusGame.goalKm, height: 6), cornerRadius: 3),
               with: .color(.orange))
        g.draw(g.resolve(Text("Северодвинск").font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.8))),
               at: CGPoint(x: 24, y: 122), anchor: .leading)
        g.draw(g.resolve(Text("Архангельск").font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.8))),
               at: CGPoint(x: w - 24, y: 122), anchor: .trailing)

        // экраны
        let center = CGPoint(x: w / 2, y: h * 0.36)
        switch game.phase {
        case .ready:
            banner(&g, at: center, title: "Трасса 150", text: "Тап — прыжок, в воздухе можно ещё раз.\nСобирай ☕️, не влети в яму. Нужно 60 км.")
        case .over:
            banner(&g, at: center, title: "Авария на \(Int(km)) км 💥", text: "Тап — ещё раз. Автобус не ждёт!")
        case .won:
            banner(&g, at: center, title: "Доехал! 🎓", text: "Успел на пару. Тап — поехать снова")
        case .running:
            break
        }
    }

    private func banner(_ g: inout GraphicsContext, at p: CGPoint, title: String, text: String) {
        let box = CGRect(x: p.x - 150, y: p.y - 60, width: 300, height: 120)
        g.fill(Path(roundedRect: box, cornerRadius: 22), with: .color(.black.opacity(0.45)))
        g.draw(g.resolve(Text(title).font(.system(size: 24, weight: .heavy, design: .rounded)).foregroundColor(.white)),
               at: CGPoint(x: p.x, y: p.y - 22))
        g.draw(g.resolve(Text(text).font(.system(size: 13, weight: .semibold)).foregroundColor(.white.opacity(0.85))),
               in: CGRect(x: box.minX + 16, y: p.y + 2, width: box.width - 32, height: 50))
    }
}
