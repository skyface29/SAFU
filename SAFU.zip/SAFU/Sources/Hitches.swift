import SwiftUI
import UIKit
import Darwin
import MachO

// MARK: - Запись пролагов
//
// Экран дёргается, когда главный поток не успевает к следующему кадру. Здесь мы замечаем каждый раз,
// когда он занят дольше 50 мс (3 кадра на 60 Гц, 6 — на 120), и в этот момент снимаем его стек:
// в отчёте видно, какая функция держала экран. Включается вручную в «Разработчике»
// и сама выключается через 30 минут — сторож просыпается 60 раз в секунду, постоянно держать его незачем

final class HitchMonitor: ObservableObject {
    static let shared = HitchMonitor()

    struct Hitch: Identifiable {
        let id = UUID()
        let date: Date
        let ms: Int
        /// Вкладка и открыт ли сайт
        let place: String
        let addresses: [UInt]
        var frames: [String] = []
        var headline = ""
    }

    @Published private(set) var hitches: [Hitch] = []
    @Published private(set) var isOn = false
    @Published private(set) var until: Date?

    private static let threshold: CFAbsoluteTime = 0.05
    private static let untilKey = "dev.hitches.until"
    private static let keep = 60

    // общее для главного потока и сторожа — под замком
    private let lock = NSLock()
    /// Когда главный поток проснулся и начал работу; 0 — спит и ждёт событий
    private var busySince: CFAbsoluteTime = 0
    /// Для какой работы стек уже снят (одного снимка на пролаг хватает)
    private var sampledFor: CFAbsoluteTime = 0
    private var sample: [UInt] = []
    /// Номер запуска сторожа: выключили и снова включили — старый поток видит чужой номер и выходит
    private var generation = 0

    private var observers: [CFRunLoopObserver] = []
    private var mainThread: thread_act_t = 0
    private var stackLow: UInt = 0
    private var stackHigh: UInt = 0
    /// Куда сторож пишет адреса, пока главный поток остановлен (выделять память в этот момент нельзя)
    private let buffer = UnsafeMutablePointer<UInt>.allocate(capacity: 64)
    private var stopTimer: Timer?
    private let symbolQueue = DispatchQueue(label: "safu.hitches.symbols", qos: .utility)

    private init() {}

    /// Запись включали и время не вышло, а приложение перезапустилось — продолжаем
    static func resumeIfNeeded() {
        guard let until = UserDefaults.standard.object(forKey: untilKey) as? Date else { return }
        if until > Date() {
            shared.start(until: until)
        } else {
            UserDefaults.standard.removeObject(forKey: untilKey)
        }
    }

    func setOn(_ on: Bool) {
        if on { start(until: Date().addingTimeInterval(30 * 60)) } else { stop() }
    }

    func clear() { hitches.removeAll() }

    private func start(until: Date) {
        UserDefaults.standard.set(until, forKey: Self.untilKey)
        self.until = until
        stopTimer?.invalidate()
        stopTimer = Timer.scheduledTimer(withTimeInterval: max(1, until.timeIntervalSinceNow), repeats: false) { [weak self] _ in
            self?.stop()
        }
        guard !isOn else { return }
        isOn = true

        if mainThread == 0 {
            mainThread = mach_thread_self()
            let t = pthread_self()
            stackHigh = UInt(bitPattern: pthread_get_stackaddr_np(t))
            stackLow = stackHigh - UInt(pthread_get_stacksize_np(t))
        }

        // проснулся — первым делом; уснул — самым последним, уже после отрисовки кадра
        let wake = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault, CFRunLoopActivity.afterWaiting.rawValue,
                                                      true, CFIndex.min) { [weak self] _, _ in
            self?.began()
        }
        let rest = CFRunLoopObserverCreateWithHandler(kCFAllocatorDefault,
                                                       CFRunLoopActivity.beforeWaiting.rawValue | CFRunLoopActivity.exit.rawValue,
                                                       true, CFIndex.max) { [weak self] _, _ in
            self?.ended()
        }
        let created: [CFRunLoopObserver?] = [wake, rest]
        for o in created.compactMap({ $0 }) {
            CFRunLoopAddObserver(CFRunLoopGetMain(), o, .commonModes)
            observers.append(o)
        }

        lock.lock()
        generation += 1
        let gen = generation
        busySince = 0
        lock.unlock()

        let watchdog = Thread { [weak self] in
            // холостой прогон на своём потоке: всё, что коду снятия стека нужно подготовить в первый раз,
            // готовится сейчас, а не когда главный поток уже остановлен
            _ = self?.captureStack(of: mach_thread_self(), suspend: false)
            while true {
                usleep(16_000)
                guard let self = self, self.check(generation: gen) else { return }
            }
        }
        watchdog.name = "safu.hitches"
        watchdog.qualityOfService = .userInteractive
        watchdog.start()
    }

    private func stop() {
        stopTimer?.invalidate()
        stopTimer = nil
        UserDefaults.standard.removeObject(forKey: Self.untilKey)
        until = nil
        guard isOn else { return }
        isOn = false
        for o in observers {
            CFRunLoopRemoveObserver(CFRunLoopGetMain(), o, .commonModes)
            CFRunLoopObserverInvalidate(o)
        }
        observers.removeAll()
        lock.lock()
        generation += 1
        busySince = 0
        lock.unlock()
    }

    // MARK: главный поток

    private func began() {
        let now = CFAbsoluteTimeGetCurrent()
        lock.lock()
        busySince = now
        lock.unlock()
    }

    private func ended() {
        let now = CFAbsoluteTimeGetCurrent()
        lock.lock()
        let since = busySince
        busySince = 0
        let addresses = sampledFor == since ? sample : []
        lock.unlock()
        guard since > 0, now - since >= Self.threshold else { return }
        let ms = Int((now - since) * 1000)
        // запись — уже после кадра, чтобы сама она ничего не задерживала
        DispatchQueue.main.async { [weak self] in
            self?.record(ms: ms, at: since, addresses: addresses)
        }
    }

    private func record(ms: Int, at time: CFAbsoluteTime, addresses: [UInt]) {
        guard isOn, UIApplication.shared.applicationState == .active else { return }
        let raw = UserDefaults.standard.string(forKey: "memory.tabID") ?? AppTab.home.rawValue
        var place = AppTab(rawValue: raw)?.title ?? raw
        if SiteTabs.shared.activeID != nil { place += L(" · открыт сайт") }
        var h = Hitch(date: Date(timeIntervalSinceReferenceDate: time), ms: ms, place: place, addresses: addresses)
        if addresses.isEmpty { h.headline = L("стек не успели снять") }
        hitches.append(h)
        if hitches.count > Self.keep { hitches.removeFirst(hitches.count - Self.keep) }
        guard !addresses.isEmpty else { return }
        let id = h.id
        symbolQueue.async { [weak self] in
            let frames = HitchSymbols.describe(addresses)
            let headline = HitchSymbols.headline(frames)
            DispatchQueue.main.async {
                guard let self = self, let i = self.hitches.firstIndex(where: { $0.id == id }) else { return }
                self.hitches[i].frames = frames
                self.hitches[i].headline = headline
            }
        }
    }

    // MARK: сторож

    /// false — запись выключили, сторожу пора выходить
    private func check(generation gen: Int) -> Bool {
        lock.lock()
        let alive = generation == gen
        let since = busySince
        let done = sampledFor
        lock.unlock()
        guard alive else { return false }
        guard since > 0, since != done, CFAbsoluteTimeGetCurrent() - since >= Self.threshold else { return true }
        let n = captureStack(of: mainThread, suspend: true)
        let addresses = Array(UnsafeBufferPointer(start: buffer, count: n))
        lock.lock()
        if busySince == since {
            sampledFor = since
            sample = addresses
        }
        lock.unlock()
        return true
    }

    /// Стек главного потока по цепочке frame pointer. Пока поток остановлен, ничего не выделяем
    /// в памяти и не берём замков: он мог встать посреди malloc, и мы бы повисли вместе с ним
    private func captureStack(of thread: thread_act_t, suspend: Bool) -> Int {
        #if arch(arm64)
        let lo = stackLow, hi = stackHigh, buf = buffer
        let mask: UInt = 0x0000_007F_FFFF_FFFF     // то же, что HitchSymbols.strip, но без вызовов
        guard thread != 0 else { return 0 }
        if suspend {
            guard thread_suspend(thread) == KERN_SUCCESS else { return 0 }
        }
        defer { if suspend { thread_resume(thread) } }
        var state = arm_thread_state64_t()
        var count = mach_msg_type_number_t(MemoryLayout<arm_thread_state64_t>.size / MemoryLayout<natural_t>.size)
        let kr = withUnsafeMutablePointer(to: &state) { p in
            p.withMemoryRebound(to: natural_t.self, capacity: Int(count)) {
                thread_get_state(thread, thread_state_flavor_t(ARM_THREAD_STATE64), $0, &count)
            }
        }
        guard kr == KERN_SUCCESS else { return 0 }
        var n = 0
        buf[n] = UInt(state.__pc) & mask; n += 1
        buf[n] = UInt(state.__lr) & mask; n += 1
        var fp = UInt(state.__fp)
        let sp = UInt(state.__sp)
        while n < 64 {
            // адрес из чужого кадра может оказаться любым — проверяем без переполнения
            guard fp >= sp, fp >= lo, fp < hi, hi &- fp >= 16, fp & 7 == 0,
                  let frame = UnsafePointer<UInt>(bitPattern: fp) else { break }
            let ret = frame[1] & mask
            if ret == 0 { break }
            buf[n] = ret
            n += 1
            let next = frame[0]
            guard next > fp else { break }
            fp = next
        }
        return n
        #else
        return 0
        #endif
    }

    // MARK: отчёт

    /// Текст для разработчика: устройство, настройки, которые влияют на плавность, и стеки пролагов
    func report(_ done: @escaping (String) -> Void) {
        let list = hitches
        let d = UserDefaults.standard
        var head: [String] = []
        head.append(L("Арктика \(Developer.version) · \(HitchSymbols.model) · iOS \(UIDevice.current.systemVersion)"))
        let pi = ProcessInfo.processInfo
        head.append(L("Энергосбережение: \(pi.isLowPowerModeEnabled ? L("да") : L("нет")) · нагрев: \(pi.thermalState.rawValue)"))
        head.append(L("Сжатие панели: \(d.object(forKey: "ui.minimizeTabBar") as? Bool ?? true ? L("да") : L("нет"))")
                    + L(" · фон: \(d.string(forKey: "bg.style") ?? L("по умолчанию"))")
                    + (d.object(forKey: "ambient") as? Bool ?? true ? "" : L(" (стоит)"))
                    + L(" · карточки: \(d.integer(forKey: "cardStyle"))")
                    + L(" · кнопки: \(d.string(forKey: "home.quickPlace") ?? QuickPlace.standard)"))
        head.append(L("Пролагов: \(list.count)"))
        symbolQueue.async {
            var text = head.joined(separator: "\n")
            let f = DateFormatter()
            f.dateFormat = "HH:mm:ss"
            for h in list.reversed() {
                text += L("\n\n\(f.string(from: h.date)) · \(h.ms) мс · \(h.place)")
                let frames = h.frames.isEmpty ? HitchSymbols.describe(h.addresses) : h.frames
                if frames.isEmpty { text += L("\n  (стек не успели снять)") }
                for line in frames.prefix(28) { text += "\n  " + line }
            }
            DispatchQueue.main.async { done(text) }
        }
    }
}

// MARK: - Имена функций по адресам

enum HitchSymbols {
    /// Подпись указателя (PAC) в старших битах адреса возврата системных библиотек — срезаем
    static func strip(_ a: UInt) -> UInt { a & 0x0000_007F_FFFF_FFFF }

    static var model: String {
        var u = utsname()
        uname(&u)
        return withUnsafeBytes(of: u.machine) { String(decoding: $0.prefix { $0 != 0 }, as: UTF8.self) }
    }

    private static let appName = (Bundle.main.executableURL?.lastPathComponent) ?? "SAFU"

    /// «Библиотека функция» для каждого адреса. Свои функции ищем в таблице символов приложения:
    /// dladdr их не знает, из приложения наружу ничего не экспортируется
    static func describe(_ addresses: [UInt]) -> [String] {
        var out: [String] = []
        var prev: UInt = 0
        for (i, a) in addresses.enumerated() where a != prev {
            prev = a
            // адрес возврата указывает на следующую инструкцию — для имени берём сам вызов
            let q = i == 0 ? a : a &- 1
            var info = Dl_info()
            guard let ptr = UnsafeRawPointer(bitPattern: q), dladdr(ptr, &info) != 0 else {
                out.append("? 0x" + String(a, radix: 16))
                continue
            }
            let image = info.dli_fname.map { (String(cString: $0) as NSString).lastPathComponent } ?? "?"
            if image == appName {
                let base = UInt(bitPattern: info.dli_fbase)
                let file = "0x" + String(0x1_0000_0000 &+ (q &- base), radix: 16)
                if let name = AppSymbols.shared.name(for: q) {
                    out.append("\(image) \(name) [\(file)]")
                } else {
                    out.append("\(image) \(file)")
                }
            } else if let s = info.dli_sname {
                out.append("\(image) \(demangle(String(cString: s)))")
            } else {
                out.append("\(image) +0x" + String(q &- UInt(bitPattern: info.dli_fbase), radix: 16))
            }
        }
        return out
    }

    /// Короткая строка для списка: первая своя функция в стеке, иначе верхняя системная
    static func headline(_ frames: [String]) -> String {
        let own = frames.first { $0.hasPrefix(appName + " ") && !$0.contains("Hitch") }
        let line = own ?? frames.first ?? "—"
        let short = line.hasPrefix(appName + " ") ? String(line.dropFirst(appName.count + 1)) : line
        return String(short.prefix(90))
    }

    static func demangle(_ symbol: String) -> String {
        var s = symbol
        if s.hasPrefix("_$s") || s.hasPrefix("_$S") { s.removeFirst() }
        guard s.hasPrefix("$s") || s.hasPrefix("$S") else { return String(s.prefix(140)) }
        let result: String? = s.withCString { c in
            guard let out = _swiftDemangle(c, strlen(c), nil, nil, 0) else { return nil }
            defer { free(out) }
            return String(cString: out)
        }
        return String((result ?? s).prefix(140))
    }
}

@_silgen_name("swift_demangle")
private func _swiftDemangle(_ mangledName: UnsafePointer<CChar>?, _ mangledNameLength: Int,
                            _ outputBuffer: UnsafeMutablePointer<CChar>?, _ outputBufferSize: UnsafeMutablePointer<Int>?,
                            _ flags: UInt32) -> UnsafeMutablePointer<CChar>?

/// Таблица символов самого приложения (сборка не урезана, имена функций в ней есть).
/// Строится один раз, при первом отчёте, и не на главном потоке
private final class AppSymbols {
    static let shared = AppSymbols()

    private var starts: [UInt] = []
    private var offsets: [UInt32] = []
    private var strings: UnsafePointer<CChar>?

    private init() {
        guard let raw = _dyld_get_image_header(0) else { return }
        let header = UnsafeRawPointer(raw)
        let mh = header.load(as: mach_header_64.self)
        guard mh.magic == UInt32(MH_MAGIC_64) else { return }
        let slide = UInt(bitPattern: _dyld_get_image_vmaddr_slide(0))
        var p = header.advanced(by: MemoryLayout<mach_header_64>.size)
        var linkedit: segment_command_64?
        var symtab: symtab_command?
        for _ in 0..<mh.ncmds {
            let lc = p.load(as: load_command.self)
            if lc.cmd == UInt32(LC_SEGMENT_64) {
                let seg = p.load(as: segment_command_64.self)
                let name = withUnsafeBytes(of: seg.segname) { String(decoding: $0.prefix { $0 != 0 }, as: UTF8.self) }
                if name == "__LINKEDIT" { linkedit = seg }
            } else if lc.cmd == UInt32(LC_SYMTAB) {
                symtab = p.load(as: symtab_command.self)
            }
            p = p.advanced(by: Int(lc.cmdsize))
        }
        guard let le = linkedit, let st = symtab else { return }
        let base = slide &+ UInt(le.vmaddr) &- UInt(le.fileoff)
        guard let syms = UnsafePointer<nlist_64>(bitPattern: base &+ UInt(st.symoff)),
              let strs = UnsafePointer<CChar>(bitPattern: base &+ UInt(st.stroff)) else { return }
        var pairs: [(UInt, UInt32)] = []
        pairs.reserveCapacity(Int(st.nsyms) / 2)
        for i in 0..<Int(st.nsyms) {
            let s = syms[i]
            guard s.n_type & UInt8(N_STAB) == 0, s.n_type & UInt8(N_TYPE) == UInt8(N_SECT), s.n_value != 0 else { continue }
            pairs.append((UInt(s.n_value) &+ slide, s.n_un.n_strx))
        }
        pairs.sort { $0.0 < $1.0 }
        starts = pairs.map { $0.0 }
        offsets = pairs.map { $0.1 }
        strings = strs
    }

    func name(for address: UInt) -> String? {
        guard let strings, !starts.isEmpty, address >= starts[0] else { return nil }
        // последний символ, который начинается не позже адреса
        var lo = 0, hi = starts.count - 1
        while lo < hi {
            let mid = (lo + hi + 1) / 2
            if starts[mid] <= address { lo = mid } else { hi = mid - 1 }
        }
        let name = String(cString: strings.advanced(by: Int(offsets[lo])))
        return HitchSymbols.demangle(name.hasPrefix("_") ? String(name.dropFirst()) : name)
    }
}

// MARK: - Карточка в «Разработчике»

struct HitchCard: View {
    @ObservedObject private var monitor = HitchMonitor.shared
    @State private var copied = false

    private static let time: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss"
        return f
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Toggle(isOn: Binding(get: { monitor.isOn }, set: { on in
                Haptics.tap()
                monitor.setOn(on)
            })) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(L("Запись пролагов")).font(.system(.headline, design: .rounded))
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .tint(Color.brand)

            Text(L("Включи, полистай там, где дёргается, и нажми «Скопировать отчёт» — пришли его разработчику. В отчёте видно, какая функция держала экран. Если рывки есть, а записей нет, тормозит отрисовка (стекло, фон), а не код."))
                .font(.caption)
                .foregroundStyle(.secondary)

            if !monitor.hitches.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(monitor.hitches.suffix(6).reversed())) { h in
                        HStack(alignment: .firstTextBaseline, spacing: 10) {
                            Text(L("\(h.ms) мс"))
                                .font(.caption.weight(.heavy).monospacedDigit())
                                .foregroundStyle(h.ms >= 100 ? Color.red : Color.orange)
                                .frame(width: 60, alignment: .leading)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(h.headline.isEmpty ? "…" : h.headline)
                                    .font(.caption.weight(.semibold))
                                    .lineLimit(1)
                                Text("\(Self.time.string(from: h.date)) · \(h.place)")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                }
                HStack(spacing: 10) {
                    Button {
                        Haptics.tap()
                        monitor.report { text in
                            UIPasteboard.general.string = text
                            Haptics.success()
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { copied = true }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { copied = false }
                            }
                        }
                    } label: {
                        Label(copied ? L("Скопировано") : L("Скопировать отчёт"), systemImage: copied ? "checkmark" : "doc.on.doc")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 11)
                            .background(brandGradient, in: Capsule())
                    }
                    .buttonStyle(PressableStyle())
                    Button {
                        Haptics.tap()
                        monitor.clear()
                    } label: {
                        Text(L("Очистить"))
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 16)
                            .padding(.vertical, 11)
                            .background(Color.primary.opacity(0.08), in: Capsule())
                    }
                    .buttonStyle(PressableStyle())
                }
            } else if monitor.isOn {
                Label(L("Пока ни одного пролага дольше 50 мс"), systemImage: "checkmark.circle.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.green)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private var subtitle: String {
        guard monitor.isOn, let until = monitor.until else { return L("Отчёт для разработчика") }
        return L("Пишется до \(Self.time.string(from: until).prefix(5))")
    }
}
