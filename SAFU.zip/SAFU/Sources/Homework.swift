import SwiftUI
import UIKit
import UserNotifications

// MARK: - Домашка: модель
//
// Преподаватели ДЗ обычно только говорят, поэтому его записывают сами.
// Главная идея: ДЗ привязано к паре, на которой его задали, а срок — к паре, к которой его сдавать
// («к следующей практике», «через одну пару»). Если РУЗ перенесёт или отменит пару, срок сам подстроится.

enum HWKind: String, Codable, CaseIterable, Identifiable {
    case exercises, reading, notes, lab, prep, project, other

    var id: String { rawValue }

    var title: String {
        switch self {
        case .exercises: return "Задачи"
        case .reading: return "Прочитать"
        case .notes: return "Конспект"
        case .lab: return "Лаба / отчёт"
        case .prep: return "Подготовиться"
        case .project: return "Проект"
        case .other: return "Другое"
        }
    }

    var icon: String {
        switch self {
        case .exercises: return "list.number"
        case .reading: return "book.fill"
        case .notes: return "doc.text.fill"
        case .lab: return "flask.fill"
        case .prep: return "brain.head.profile"
        case .project: return "rectangle.on.rectangle.angled"
        case .other: return "square.and.pencil"
        }
    }

    var color: Color {
        switch self {
        case .exercises: return Color(red: 0.25, green: 0.52, blue: 1.0)
        case .reading: return Color(red: 0.16, green: 0.72, blue: 0.45)
        case .notes: return Color(red: 0.10, green: 0.70, blue: 0.78)
        case .lab: return Color(red: 1.0, green: 0.55, blue: 0.10)
        case .prep: return Color(red: 0.62, green: 0.40, blue: 0.95)
        case .project: return Color(red: 0.93, green: 0.30, blue: 0.62)
        case .other: return Color(red: 0.55, green: 0.58, blue: 0.65)
        }
    }

    /// Угадываем тип по тексту задания
    static func guess(_ text: String) -> HWKind? {
        let t = text.lowercased()
        guard !t.isEmpty else { return nil }
        func has(_ words: [String]) -> Bool { words.contains { t.contains($0) } }
        if has(["лаб", "отчёт", "отчет", "протокол"]) { return .lab }
        if has(["проект", "презентац", "курсов"]) { return .project }
        if has(["контрольн", "тест", "опрос", "коллоквиум", "подготов", "выучить", "выучи", "повтор", "экзамен", "зачёт", "зачет"]) { return .prep }
        if has(["конспект", "реферат", "эссе", "доклад", "сочинен", "написать"]) { return .notes }
        if has(["прочит", "параграф", "§", "глав", "читать", "статью"]) { return .reading }
        if has(["№", "номер", "задач", "упр", "пример", "стр.", "решить", "реши"]) { return .exercises }
        return nil
    }
}

enum HWRule: String, Codable {
    /// Срок — N-я пара предмета после «якоря» (обычно пара, на которой задали)
    case pair
    /// Срок — конкретное время
    case date
}

struct HWStep: Identifiable, Codable, Hashable {
    var id = UUID()
    var text: String
    var done = false
}

struct HWReminders: Codable, Hashable {
    var evening = true
    var morning = false
    var hourBefore = true
    var custom: Date?

    static var defaults: HWReminders {
        HWReminders(evening: HWPrefs.remindEvening, morning: HWPrefs.remindMorning,
                    hourBefore: HWPrefs.remindHour, custom: nil)
    }

    enum CodingKeys: String, CodingKey { case evening, morning, hourBefore, custom }

    init(evening: Bool = true, morning: Bool = false, hourBefore: Bool = true, custom: Date? = nil) {
        self.evening = evening
        self.morning = morning
        self.hourBefore = hourBefore
        self.custom = custom
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        evening = try c.decodeIfPresent(Bool.self, forKey: .evening) ?? true
        morning = try c.decodeIfPresent(Bool.self, forKey: .morning) ?? false
        hourBefore = try c.decodeIfPresent(Bool.self, forKey: .hourBefore) ?? true
        custom = try c.decodeIfPresent(Date.self, forKey: .custom)
    }
}

struct Homework: Identifiable, Codable, Hashable {
    var id = UUID()
    var subject: String
    var text: String
    var kind: HWKind = .exercises

    /// Пара, на которой задали (начало) и её тип
    var givenAt: Date = Date()
    var givenKind: String = ""
    var fromPair = false

    /// Срок и правило, по которому он считается
    var due: Date
    var rule: HWRule = .date
    var anchor: Date = Date()
    var skip: Int = 0
    /// «Следующая практика»: тип пары, к которой сдавать ("" — любая пара предмета)
    var matchKind: String = ""
    /// Следить за расписанием: пару перенесли — срок переехал вместе с ней
    var follow = true
    /// Дистанционные пары не считаются парой сдачи (срок встаёт на ближайшую очную)
    var skipRemote = true

    /// Что известно о паре сдачи (для подписи)
    var dueKind: String = ""
    var dueRoom: String = ""
    /// Срок посчитан по прошлым неделям: РУЗ ещё не выложил эту неделю
    var dueEstimated = false
    /// «Пару перенесли: было …»
    var shiftNote: String = ""

    var steps: [HWStep] = []
    var important = false
    var note: String = ""
    var photos: [String] = []
    var reminders = HWReminders()

    var done = false
    var doneAt: Date?
    var created = Date()

    init(subject: String, text: String, due: Date) {
        self.subject = subject
        self.text = text
        self.due = due
    }

    // Читаем бережно: новые поля в будущих версиях не должны ломать старые записи
    enum CodingKeys: String, CodingKey {
        case id, subject, text, kind, givenAt, givenKind, fromPair, due, rule, anchor, skip, matchKind, follow, skipRemote
        case dueKind, dueRoom, dueEstimated, shiftNote, steps, important, note, photos, reminders, done, doneAt, created
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        subject = try c.decodeIfPresent(String.self, forKey: .subject) ?? ""
        text = try c.decodeIfPresent(String.self, forKey: .text) ?? ""
        kind = (try? c.decodeIfPresent(HWKind.self, forKey: .kind)) ?? .other
        givenAt = try c.decodeIfPresent(Date.self, forKey: .givenAt) ?? Date()
        givenKind = try c.decodeIfPresent(String.self, forKey: .givenKind) ?? ""
        fromPair = try c.decodeIfPresent(Bool.self, forKey: .fromPair) ?? false
        due = try c.decodeIfPresent(Date.self, forKey: .due) ?? Date()
        rule = (try? c.decodeIfPresent(HWRule.self, forKey: .rule)) ?? .date
        anchor = try c.decodeIfPresent(Date.self, forKey: .anchor) ?? givenAt
        skip = try c.decodeIfPresent(Int.self, forKey: .skip) ?? 0
        matchKind = try c.decodeIfPresent(String.self, forKey: .matchKind) ?? ""
        follow = try c.decodeIfPresent(Bool.self, forKey: .follow) ?? true
        skipRemote = try c.decodeIfPresent(Bool.self, forKey: .skipRemote) ?? false
        dueKind = try c.decodeIfPresent(String.self, forKey: .dueKind) ?? ""
        dueRoom = try c.decodeIfPresent(String.self, forKey: .dueRoom) ?? ""
        dueEstimated = try c.decodeIfPresent(Bool.self, forKey: .dueEstimated) ?? false
        shiftNote = try c.decodeIfPresent(String.self, forKey: .shiftNote) ?? ""
        steps = try c.decodeIfPresent([HWStep].self, forKey: .steps) ?? []
        important = try c.decodeIfPresent(Bool.self, forKey: .important) ?? false
        note = try c.decodeIfPresent(String.self, forKey: .note) ?? ""
        photos = try c.decodeIfPresent([String].self, forKey: .photos) ?? []
        reminders = try c.decodeIfPresent(HWReminders.self, forKey: .reminders) ?? HWReminders()
        done = try c.decodeIfPresent(Bool.self, forKey: .done) ?? false
        doneAt = try c.decodeIfPresent(Date.self, forKey: .doneAt)
        created = try c.decodeIfPresent(Date.self, forKey: .created) ?? Date()
    }

    var isOverdue: Bool { !done && due < Date() }
    var stepsDone: Int { steps.filter(\.done).count }
    var stepsProgress: Double { steps.isEmpty ? 0 : Double(stepsDone) / Double(steps.count) }

    /// Заголовок для списков: текст, а если его нет — первый подпункт
    var title: String {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        return steps.first?.text ?? "Без описания"
    }

    func isSameSubject(_ other: String) -> Bool {
        HWPlanner.key(subject) == HWPlanner.key(other)
    }
}

// MARK: - Настройки

enum HWPrefs {
    private static var d: UserDefaults { .standard }
    private static func int(_ k: String, _ def: Int) -> Int { d.object(forKey: k) as? Int ?? def }
    private static func bool(_ k: String, _ def: Bool) -> Bool { d.object(forKey: k) as? Bool ?? def }
    private static func string(_ k: String, _ def: String) -> String { d.string(forKey: k) ?? def }

    static var eveningHour: Int { int("hw.eveningHour", 20) }
    static var eveningMinute: Int { int("hw.eveningMinute", 0) }
    static var morningHour: Int { int("hw.morningHour", 7) }
    static var morningMinute: Int { int("hw.morningMinute", 30) }
    static var remindEvening: Bool { bool("hw.remind.evening", true) }
    static var remindMorning: Bool { bool("hw.remind.morning", false) }
    static var remindHour: Bool { bool("hw.remind.hour", true) }
    /// next · nextSame · skip1 · tomorrow · week
    static var defaultDue: String { string("hw.defaultDue", "next") }
    static var follow: Bool { bool("hw.follow", true) }
    /// Не считать дистанционные пары, когда срок «к следующей паре»
    static var skipRemote: Bool { bool("hw.skipRemote", true) }
    static var guessKind: Bool { bool("hw.guessKind", true) }
    static var notifyShift: Bool { bool("hw.notifyShift", true) }
    static var celebrate: Bool { bool("hw.celebrate", true) }
    static var badge: Bool { bool("hw.badge", true) }
    static var keepDoneDays: Int { int("hw.keepDone", 30) }
    static var askAfter: Bool { bool("hw.ask", false) }
    static var askDelay: Int { int("hw.ask.delay", 3) }
    static var askLecture: Bool { bool("hw.ask.lecture", false) }
    static var askPractice: Bool { bool("hw.ask.practice", true) }
    static var askLab: Bool { bool("hw.ask.lab", true) }
    static var askSeminar: Bool { bool("hw.ask.seminar", true) }

    static func asks(kind: String) -> Bool {
        let k = kind.lowercased()
        if k.hasPrefix("лекц") { return askLecture }
        if k.hasPrefix("практ") { return askPractice }
        if k.hasPrefix("лаб") { return askLab }
        if k.hasPrefix("семин") { return askSeminar }
        return false
    }
}

// MARK: - Пары для сроков

/// Пара, к которой можно сдавать ДЗ
struct HWTarget: Hashable, Identifiable {
    let start: Date
    let end: Date
    let kind: String
    let room: String
    /// Нет в загруженном расписании — посчитано по прошлым неделям
    let estimated: Bool
    var id: Date { start }
}

enum HWPlanner {
    static func key(_ s: String) -> String {
        s.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func sameKind(_ a: String, _ b: String) -> Bool {
        KindStyle.of(a).label == KindStyle.of(b).label
    }

    /// Последний день, до которого расписание точно известно (РУЗ выкладывает не весь семестр)
    static func knownUntil(_ data: ScheduleData) -> Date? {
        guard data.usesRuz else { return nil }
        return data.ruzEvents.map(\.end).max()
    }

    /// Пары предмета строго после `anchor`: сначала из расписания, дальше — прогноз по прошлым неделям.
    /// Идём по дням и останавливаемся, как только набрали нужное: обычно это 1–3 дня, а не полгода.
    /// Дни берутся из общего дневного кеша расписания, поэтому повторные расчёты почти бесплатны.
    static func targets(subject: String, after anchor: Date, kind: String?, data: ScheduleData, limit: Int = 8,
                        skipRemote: Bool = HWPrefs.skipRemote) -> [HWTarget] {
        let subj = key(subject)
        guard !subj.isEmpty, limit > 0 else { return [] }
        let cal = Calendar.current
        let kindFilter = kind.flatMap { $0.isEmpty ? nil : $0 }
        let known = knownUntil(data)
        let today = cal.startOfDay(for: Date())
        var day = cal.startOfDay(for: anchor)
        // смотрим не дальше 60 дней от сегодня (и не дальше известного расписания РУЗ)
        var lastDay = cal.date(byAdding: .day, value: 60, to: max(today, day)) ?? day
        if let known { lastDay = min(lastDay, cal.startOfDay(for: known)) }

        var out: [HWTarget] = []
        var guardCount = 0
        while day <= lastDay && guardCount < 200 {
            for s in ScheduleEngine.slots(on: day, data: data) {
                guard s.start > anchor, key(s.lesson.subject) == subj else { continue }
                if skipRemote && s.isRemote { continue }
                if let k = kindFilter, !sameKind(k, s.lesson.kind) { continue }
                if out.last.map({ $0.start == s.start }) == true { continue }
                out.append(HWTarget(start: s.start, end: s.end, kind: s.lesson.kind, room: s.lesson.room, estimated: false))
                if out.count >= limit { return out }
            }
            guard let next = cal.date(byAdding: .day, value: 1, to: day) else { break }
            day = next
            guardCount += 1
        }

        // РУЗ выложил не всё — достраиваем по тому, как пара шла в последние недели
        guard let known else { return out }
        let from = max(anchor, known, out.last?.start ?? .distantPast)
        for p in predict(subject: subj, kind: kindFilter, after: from, data: data, known: known, skipRemote: skipRemote) {
            out.append(p)
            if out.count >= limit { break }
        }
        return out
    }

    /// Прогноз пар после конца известного расписания: повторяем недельный (или двухнедельный) ритм
    private static func predict(subject: String, kind: String?, after: Date, data: ScheduleData, known: Date,
                                skipRemote: Bool) -> [HWTarget] {
        let cal = Calendar.current
        let knownDay = cal.startOfDay(for: known)
        var past: [LessonSlot] = []
        for back in 0..<28 {
            guard let d = cal.date(byAdding: .day, value: -back, to: knownDay) else { continue }
            for s in ScheduleEngine.slots(on: d, data: data)
            where key(s.lesson.subject) == subject && (kind == nil || sameKind(kind!, s.lesson.kind))
                && !(skipRemote && s.isRemote) {
                past.append(s)
            }
        }
        guard !past.isEmpty else { return [] }

        // группируем по «день недели + время начала»
        var groups: [String: [LessonSlot]] = [:]
        for s in past {
            let comps = cal.dateComponents([.weekday, .hour, .minute], from: s.start)
            let k = "\(comps.weekday ?? 0)-\(comps.hour ?? 0)-\(comps.minute ?? 0)"
            groups[k, default: []].append(s)
        }

        let horizon = after.addingTimeInterval(70 * 86_400)
        var out: [HWTarget] = []
        for (_, list) in groups {
            let sorted = list.sorted { $0.start < $1.start }
            guard let last = sorted.last else { continue }
            var gaps: [Int] = []
            for i in 1..<max(1, sorted.count) {
                let g = cal.dateComponents([.day], from: sorted[i - 1].start, to: sorted[i].start).day ?? 7
                gaps.append(g)
            }
            let period = (gaps.min() ?? 14) <= 8 ? 7 : 14
            let duration = last.end.timeIntervalSince(last.start)
            var k = 1
            while k < 30 {
                guard let t = cal.date(byAdding: .day, value: period * k, to: last.start) else { break }
                if t > horizon { break }
                if t > after {
                    out.append(HWTarget(start: t, end: t.addingTimeInterval(duration), kind: last.lesson.kind,
                                        room: last.lesson.room, estimated: true))
                }
                k += 1
            }
        }
        return out.sorted { $0.start < $1.start }
    }

    /// Срок ДЗ по его правилу
    static func resolve(_ h: Homework, data: ScheduleData) -> HWTarget? {
        guard h.rule == .pair else { return nil }
        let list = targets(subject: h.subject, after: h.anchor,
                           kind: h.matchKind.isEmpty ? nil : h.matchKind,
                           data: data, limit: h.skip + 1, skipRemote: h.skipRemote)
        return list.count > h.skip ? list[h.skip] : nil
    }

    /// Пара, с которой логичнее всего записывать ДЗ прямо сейчас: идёт или закончилась недавно
    static func suggestedSlot(_ data: ScheduleData, now: Date = Date()) -> LessonSlot? {
        let today = ScheduleEngine.slots(on: now, data: data)
        if let cur = today.first(where: { $0.start <= now && $0.end > now }) { return cur }
        return today.filter { $0.end <= now && now.timeIntervalSince($0.end) < 3 * 3600 }
            .max { $0.end < $1.end }
    }

    /// Находим пару в расписании по предмету и времени начала
    static func slot(subject: String, start: Date, data: ScheduleData) -> LessonSlot? {
        ScheduleEngine.slots(on: start, data: data).first {
            abs($0.start.timeIntervalSince(start)) < 90 && key($0.lesson.subject) == key(subject)
        }
    }
}

// MARK: - Подписи дат

enum HWFormat {
    static func isEndOfDay(_ d: Date) -> Bool {
        let c = Calendar.current.dateComponents([.hour, .minute], from: d)
        return c.hour == 23 && c.minute == 59
    }

    /// «сегодня, 10:10» · «завтра, 8:20» · «пт 3 окт, 12:00»
    static func dayTime(_ d: Date) -> String {
        let cal = Calendar.current
        let time = isEndOfDay(d) ? "до конца дня" : hmString(d)
        if cal.isDateInToday(d) { return "сегодня, \(time)" }
        if cal.isDateInTomorrow(d) { return "завтра, \(time)" }
        if cal.isDateInYesterday(d) { return "вчера, \(time)" }
        let sameYear = cal.component(.year, from: d) == cal.component(.year, from: Date())
        let day = Fmt.formatter(sameYear ? "EE d MMM" : "EE d MMM yyyy").string(from: d)
        return "\(day), \(time)"
    }

    /// Короткая плашка срока: «через 3 ч», «завтра 8:20», «пн 6 окт», «просрочено»
    static func chip(_ d: Date, done: Bool = false) -> String {
        let cal = Calendar.current
        let now = Date()
        if !done && d < now {
            let days = cal.dateComponents([.day], from: cal.startOfDay(for: d), to: cal.startOfDay(for: now)).day ?? 0
            return days <= 0 ? "просрочено" : "просрочено \(days) дн"
        }
        let mins = Int(d.timeIntervalSince(now) / 60)
        if mins < 60 && mins >= 0 { return "через \(max(mins, 1)) мин" }
        if cal.isDateInToday(d) { return isEndOfDay(d) ? "сегодня" : "сегодня \(hmString(d))" }
        if cal.isDateInTomorrow(d) { return isEndOfDay(d) ? "завтра" : "завтра \(hmString(d))" }
        let days = cal.dateComponents([.day], from: cal.startOfDay(for: now), to: cal.startOfDay(for: d)).day ?? 0
        // «пн, 18:00» — коротко и сразу видно время пары
        if days < 7 {
            let wd = Fmt.formatter("EE").string(from: d).lowercased()
            return isEndOfDay(d) ? wd : "\(wd), \(hmString(d))"
        }
        return Fmt.formatter("d MMM").string(from: d)
    }

    /// Цвет срочности
    static func urgency(_ d: Date, done: Bool = false) -> Color {
        if done { return .secondary }
        let left = d.timeIntervalSinceNow
        if left < 0 { return .red }
        if left < 24 * 3600 { return .orange }
        if left < 3 * 24 * 3600 { return Color.brand }
        return .secondary
    }
}

// MARK: - Хранилище

final class HomeworkStore: ObservableObject {
    static let shared = HomeworkStore()

    private let key = "homework.v1"
    /// Все записи. Отсортированные списки считаются один раз на изменение, а не на каждую отрисовку
    @Published private(set) var items: [Homework] = [] {
        didSet { rebuild() }
    }
    private(set) var active: [Homework] = []
    private(set) var finished: [Homework] = []
    private static let saveQueue = DispatchQueue(label: "safu.homework.save", qos: .utility)

    private init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Homework].self, from: data) {
            items = decoded
        }
        rebuild()
    }

    private func rebuild() {
        active = items.filter { !$0.done }.sorted { $0.due < $1.due }
        finished = items.filter(\.done).sorted { ($0.doneAt ?? $0.due) > ($1.doneAt ?? $1.due) }
    }

    /// Запись на диск — в фоне, чтобы галочка ставилась мгновенно
    private func save() {
        let snapshot = items
        let k = key
        HomeworkStore.saveQueue.async {
            if let data = try? JSONEncoder().encode(snapshot) {
                UserDefaults.standard.set(data, forKey: k)
            }
        }
    }

    // MARK: выборки

    var overdue: [Homework] { active.filter { $0.due < Date() } }

    func item(_ id: UUID) -> Homework? { items.first { $0.id == id } }

    /// Бейдж на вкладке: просроченные и те, что сдавать в ближайшие сутки
    var badgeCount: Int {
        let limit = Date().addingTimeInterval(24 * 3600)
        return active.filter { $0.due < limit }.count
    }

    func openCount(subject: String) -> Int {
        active.filter { $0.isSameSubject(subject) }.count
    }

    func openItems(subject: String) -> [Homework] {
        active.filter { $0.isSameSubject(subject) }
    }

    /// ДЗ, которое надо сдать на этой паре
    func due(at slot: LessonSlot) -> [Homework] {
        items.filter { $0.isSameSubject(slot.lesson.subject) && abs($0.due.timeIntervalSince(slot.start)) < 90 }
            .sorted { !$0.done && $1.done }
    }

    /// ДЗ, которое задали на этой паре
    func given(at slot: LessonSlot) -> [Homework] {
        items.filter { $0.fromPair && $0.isSameSubject(slot.lesson.subject) && abs($0.givenAt.timeIntervalSince(slot.start)) < 90 }
    }

    /// Сделано за последние 7 дней и сколько всего было к сдаче за это время
    var weekStats: (done: Int, total: Int) {
        let from = Date().addingTimeInterval(-7 * 86_400)
        let to = Date().addingTimeInterval(7 * 86_400)
        let window = items.filter { ($0.due >= from && $0.due <= to) || ($0.doneAt ?? .distantPast) >= from }
        return (window.filter(\.done).count, window.count)
    }

    /// Предметы с открытым ДЗ, ближайшие сроки — первыми
    var subjects: [String] {
        var out: [String] = []
        for h in active where !out.contains(where: { HWPlanner.key($0) == HWPlanner.key(h.subject) }) {
            out.append(h.subject)
        }
        return out
    }

    // MARK: изменения

    func upsert(_ h: Homework) {
        var h = h
        h.text = h.text.trimmingCharacters(in: .whitespacesAndNewlines)
        if let i = items.firstIndex(where: { $0.id == h.id }) {
            items[i] = h
        } else {
            items.append(h)
        }
        save()
        HWNotifier.requestAuthorization()
        HWNotifier.schedule(h)
    }

    func toggle(_ h: Homework) {
        guard let i = items.firstIndex(where: { $0.id == h.id }) else { return }
        items[i].done.toggle()
        items[i].doneAt = items[i].done ? Date() : nil
        if items[i].done {
            // сделал всё — отмечаем и подпункты
            for j in items[i].steps.indices { items[i].steps[j].done = true }
            Haptics.success()
            if HWPrefs.celebrate {
                Celebrations.taskDone(title: items[i].title, left: active.count)
            }
        } else {
            Haptics.tap()
        }
        save()
        HWNotifier.schedule(items[i])
    }

    func markDone(id: UUID) {
        guard let h = item(id), !h.done else { return }
        toggle(h)
    }

    func toggleStep(_ h: Homework, step: HWStep) {
        guard let i = items.firstIndex(where: { $0.id == h.id }),
              let j = items[i].steps.firstIndex(where: { $0.id == step.id }) else { return }
        items[i].steps[j].done.toggle()
        Haptics.tap()
        // все пункты готовы — задание готово
        if !items[i].done && items[i].steps.allSatisfy(\.done) {
            items[i].done = true
            items[i].doneAt = Date()
            Haptics.success()
            if HWPrefs.celebrate { Celebrations.taskDone(title: items[i].title, left: active.count) }
            HWNotifier.schedule(items[i])
        }
        save()
    }

    func delete(_ h: Homework) {
        HWNotifier.cancel(h)
        HWFiles.removeAll(h.id)
        items.removeAll { $0.id == h.id }
        save()
    }

    func clearFinished() {
        for h in finished { HWFiles.removeAll(h.id) }
        items.removeAll(where: \.done)
        save()
    }

    /// Перенести на следующую пару (или на день, если срок — дата)
    func postpone(_ h: Homework, data: ScheduleData) {
        var n = h
        if n.rule == .pair {
            n.skip += 1
            if let t = HWPlanner.resolve(n, data: data) {
                n.due = t.start
                n.dueKind = t.kind
                n.dueRoom = t.room
                n.dueEstimated = t.estimated
            } else {
                n.skip -= 1
                n.rule = .date
                n.due = h.due.addingTimeInterval(7 * 86_400)
            }
        } else {
            n.due = h.due.addingTimeInterval(86_400)
        }
        n.shiftNote = ""
        upsert(n)
        Haptics.tap()
    }

    func duplicate(_ h: Homework) {
        var n = h
        n.id = UUID()
        n.done = false
        n.doneAt = nil
        n.created = Date()
        n.photos = []
        n.steps = h.steps.map { HWStep(text: $0.text) }
        upsert(n)
    }

    func dismissShift(_ h: Homework) {
        guard let i = items.firstIndex(where: { $0.id == h.id }) else { return }
        items[i].shiftNote = ""
        save()
    }

    /// Расписание обновилось: сроки «к паре» переезжают вслед за парами
    func reconcile(_ data: ScheduleData) {
        guard data.usesRuz ? !data.ruzEvents.isEmpty : !data.lessons.isEmpty else { return }
        var list = items
        var touched: [Homework] = []
        let now = Date()
        for i in list.indices {
            let h = list[i]
            guard !h.done, h.rule == .pair, h.follow, let t = HWPlanner.resolve(h, data: data) else { continue }
            var changed = false
            if abs(t.start.timeIntervalSince(h.due)) > 60 {
                // уже сданное по сроку не двигаем назад в прошлое
                if h.due < now && t.start < now { continue }
                if !h.dueEstimated && h.due > now {
                    list[i].shiftNote = "Пару перенесли: было \(HWFormat.dayTime(h.due))"
                    if HWPrefs.notifyShift { HWNotifier.notifyShift(list[i], old: h.due, new: t.start) }
                }
                list[i].due = t.start
                changed = true
            }
            if list[i].dueKind != t.kind || list[i].dueRoom != t.room || list[i].dueEstimated != t.estimated {
                list[i].dueKind = t.kind
                list[i].dueRoom = t.room
                list[i].dueEstimated = t.estimated
                changed = true
            }
            if changed { touched.append(list[i]) }
        }
        guard !touched.isEmpty else { return }
        items = list
        save()
        for h in touched { HWNotifier.schedule(h) }
    }

    /// Старое сделанное ДЗ убираем, чтобы список не разрастался
    func cleanupFinished() {
        let days = HWPrefs.keepDoneDays
        guard days > 0 else { return }
        let limit = Date().addingTimeInterval(-Double(days) * 86_400)
        let old = items.filter { $0.done && ($0.doneAt ?? $0.due) < limit }
        guard !old.isEmpty else { return }
        for h in old { HWFiles.removeAll(h.id) }
        items.removeAll { h in old.contains { $0.id == h.id } }
        save()
    }

    /// ДЗ, записанное в прошлой версии как задача, переносим сюда (один раз)
    func migrate(from tasks: TaskStore) {
        let flag = "homework.migrated.v1"
        guard !UserDefaults.standard.bool(forKey: flag) else { return }
        UserDefaults.standard.set(true, forKey: flag)
        let old = tasks.tasks.filter { $0.note.hasPrefix("ДЗ") }
        guard !old.isEmpty else { return }
        for t in old {
            var h = Homework(subject: t.subject, text: t.title, due: t.due)
            h.kind = HWKind.guess(t.title) ?? .other
            h.done = t.done
            h.doneAt = t.done ? t.due : nil
            h.reminders = HWReminders(evening: t.remind, morning: false, hourBefore: t.remind, custom: nil)
            h.follow = false
            items.append(h)
            tasks.delete(t)
            HWNotifier.schedule(h)
        }
        save()
    }

    func rescheduleAll() {
        for h in items { HWNotifier.schedule(h) }
    }
}

// MARK: - Фото к ДЗ

enum HWFiles {
    static var root: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return base.appendingPathComponent("Homework", isDirectory: true)
    }

    static func dir(_ id: UUID) -> URL { root.appendingPathComponent(id.uuidString, isDirectory: true) }

    static func url(_ id: UUID, _ name: String) -> URL { dir(id).appendingPathComponent(name) }

    /// Сохраняем уменьшенную копию, возвращаем имя файла
    static func save(_ image: UIImage, for id: UUID) -> String? {
        let maxSide: CGFloat = 2000
        let size = image.size
        let scale = min(1, maxSide / max(size.width, size.height, 1))
        var img = image
        if scale < 1 {
            let target = CGSize(width: size.width * scale, height: size.height * scale)
            let format = UIGraphicsImageRendererFormat()
            format.scale = 1
            img = UIGraphicsImageRenderer(size: target, format: format).image { _ in
                image.draw(in: CGRect(origin: .zero, size: target))
            }
        }
        guard let data = img.jpegData(compressionQuality: 0.8) else { return nil }
        let folder = dir(id)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let name = "\(UUID().uuidString.prefix(8)).jpg"
        do {
            try data.write(to: folder.appendingPathComponent(name), options: .completeFileProtectionUntilFirstUserAuthentication)
            return name
        } catch {
            return nil
        }
    }

    static func image(_ id: UUID, _ name: String) -> UIImage? {
        UIImage(contentsOfFile: url(id, name).path)
    }

    static func remove(_ id: UUID, _ name: String) {
        try? FileManager.default.removeItem(at: url(id, name))
    }

    static func removeAll(_ id: UUID) {
        try? FileManager.default.removeItem(at: dir(id))
    }
}

// MARK: - Напоминания

enum HWNotifier {
    static let category = "hw"
    static let doneAction = "hw.done"
    static let idKey = "hw.id"

    static func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    /// Кнопка «Сделано» прямо в уведомлении
    static func registerCategory() {
        let center = UNUserNotificationCenter.current()
        let done = UNNotificationAction(identifier: doneAction, title: "Сделано", options: [])
        let cat = UNNotificationCategory(identifier: category, actions: [done], intentIdentifiers: [], options: [])
        center.getNotificationCategories { existing in
            var set = existing.filter { $0.identifier != HWNotifier.category }
            set.insert(cat)
            center.setNotificationCategories(set)
        }
    }

    private static func ids(_ h: Homework) -> [String] {
        ["e", "m", "h", "c"].map { "hw-\(h.id.uuidString)-\($0)" }
    }

    static func cancel(_ h: Homework) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids(h))
    }

    static func schedule(_ h: Homework) {
        cancel(h)
        guard !h.done else { return }
        let cal = Calendar.current
        var plan: [(String, Date, String)] = []
        if h.reminders.evening,
           let prev = cal.date(byAdding: .day, value: -1, to: h.due),
           let t = cal.date(bySettingHour: HWPrefs.eveningHour, minute: HWPrefs.eveningMinute, second: 0, of: prev) {
            plan.append(("e", t, "Завтра сдавать ДЗ"))
        }
        if h.reminders.morning,
           let t = cal.date(bySettingHour: HWPrefs.morningHour, minute: HWPrefs.morningMinute, second: 0, of: h.due),
           t < h.due {
            plan.append(("m", t, "Сегодня сдавать ДЗ"))
        }
        if h.reminders.hourBefore && !HWFormat.isEndOfDay(h.due) {
            plan.append(("h", h.due.addingTimeInterval(-3600), "Через час сдавать ДЗ"))
        }
        if let c = h.reminders.custom {
            plan.append(("c", c, "Напоминание о ДЗ"))
        }

        var body = h.subject.isEmpty ? h.title : "\(h.subject): \(h.title)"
        if !h.steps.isEmpty { body += " (\(h.stepsDone)/\(h.steps.count))" }

        for (suffix, fire, title) in plan where fire > Date() {
            let content = UNMutableNotificationContent()
            content.title = title
            content.body = body
            content.sound = .default
            content.categoryIdentifier = category
            content.threadIdentifier = "homework"
            content.userInfo = [idKey: h.id.uuidString]
            let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
            let req = UNNotificationRequest(identifier: "hw-\(h.id.uuidString)-\(suffix)", content: content,
                                            trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
            UNUserNotificationCenter.current().add(req)
        }
    }

    static func notifyShift(_ h: Homework, old: Date, new: Date) {
        let content = UNMutableNotificationContent()
        content.title = "Срок ДЗ сдвинулся"
        content.body = "\(h.subject): пару перенесли, теперь сдавать \(HWFormat.dayTime(new))"
        content.sound = .default
        content.threadIdentifier = "homework"
        content.userInfo = [idKey: h.id.uuidString]
        UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: "hw-shift-\(h.id.uuidString)", content: content, trigger: nil))
    }
}

/// «Что задали?» — уведомление после пары, чтобы не забыть записать
enum HWAsk {
    static let prefix = "hw-ask-"
    static let subjectKey = "hw.ask.subject"
    static let startKey = "hw.ask.start"

    static func schedule(_ data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        let enabled = HWPrefs.askAfter
        let delay = TimeInterval(HWPrefs.askDelay * 60)
        // список пар считаем сразу, а не в колбэке
        let slots = enabled
            ? Array(ScheduleQuery.slots(data, days: 4).filter { $0.end > Date() && HWPrefs.asks(kind: $0.lesson.kind) }.prefix(20))
            : []
        center.getPendingNotificationRequests { reqs in
            let old = reqs.map(\.identifier).filter { $0.hasPrefix(HWAsk.prefix) }
            center.removePendingNotificationRequests(withIdentifiers: old)
            guard enabled else { return }
            let cal = Calendar.current
            for s in slots {
                let fire = s.end.addingTimeInterval(delay)
                guard fire > Date() else { continue }
                let content = UNMutableNotificationContent()
                content.title = "Что задали по «\(s.lesson.subject)»?"
                content.body = "Нажми, чтобы записать ДЗ. Срок поставлю к следующей паре."
                content.sound = .default
                content.threadIdentifier = "homework"
                content.userInfo = [HWAsk.subjectKey: s.lesson.subject, HWAsk.startKey: s.start.timeIntervalSince1970]
                let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                let req = UNNotificationRequest(identifier: "\(HWAsk.prefix)\(Int(s.start.timeIntervalSince1970))", content: content,
                                                trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
                center.add(req)
            }
        }
    }
}

// MARK: - Открыть редактор откуда угодно (уведомление, главная, карточка пары)

struct HWEditorRoute: Identifiable {
    let id = UUID()
    var homework: Homework?
    var slot: LessonSlot?
    var subject: String?
}

final class HomeworkRouter: ObservableObject {
    static let shared = HomeworkRouter()
    @Published var editor: HWEditorRoute?
    /// Попросили открыть вкладку ДЗ
    @Published var openTab = false

    func new(slot: LessonSlot? = nil, subject: String? = nil) {
        editor = HWEditorRoute(homework: nil, slot: slot, subject: subject)
    }

    func edit(_ h: Homework) {
        editor = HWEditorRoute(homework: h, slot: nil, subject: nil)
    }
}

// MARK: - Переход к паре в расписании

/// Попросили показать день в «Парах» (например, пару, к которой сдавать ДЗ)
final class ScheduleJump: ObservableObject {
    static let shared = ScheduleJump()
    @Published var target: Date?

    func show(_ date: Date) {
        Haptics.tap()
        target = date
    }
}
