import Foundation

struct Resource: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var subtitle: String
    var url: String
    var icon: String
    var category: String

    var isValid: Bool {
        guard !title.trimmingCharacters(in: .whitespaces).isEmpty,
              let u = URL(string: url),
              let scheme = u.scheme?.lowercased(),
              scheme == "http" || scheme == "https",
              u.host != nil else { return false }
        return true
    }

    static let defaults: [Resource] = [
        Resource(title: "Sakai", subtitle: "Курсы, задания, оценки",
                 url: "https://sakai.narfu.ru", icon: "graduationcap.fill", category: "Учёба"),
        Resource(title: "Модеус", subtitle: "Моё расписание (1–2 курс)",
                 url: "https://narfu.modeus.org", icon: "calendar", category: "Учёба"),
        Resource(title: "Расписание РУЗ", subtitle: "ruz.narfu.ru",
                 url: "https://ruz.narfu.ru", icon: "calendar.badge.clock", category: "Учёба"),
        Resource(title: "Samoware", subtitle: "Почта САФУ",
                 url: "https://edu.narfu.ru", icon: "envelope.fill", category: "Почта и документы"),
        Resource(title: "Р7-Офис", subtitle: "Документы и облако",
                 url: "https://office.edu.narfu.ru", icon: "doc.richtext.fill", category: "Почта и документы"),
        Resource(title: "Сайт САФУ", subtitle: "narfu.ru",
                 url: "https://narfu.ru", icon: "building.columns.fill", category: "Университет"),
        Resource(title: "Справочник студента", subtitle: "Новости, документы, FAQ",
                 url: "https://narfu.ru/forstudent/", icon: "book.fill", category: "Университет"),
        Resource(title: "ВШИТАС", subtitle: "Страница высшей школы",
                 url: "https://narfu.ru/hsitas/", icon: "cpu", category: "Университет"),
        Resource(title: "Личный кабинет", subtitle: "Вход на narfu.ru",
                 url: "https://narfu.ru/user/authorization.php", icon: "person.crop.circle.fill", category: "Университет")
    ]
}

final class ResourceStore: ObservableObject {
    private let key = "resources.v1"

    @Published var items: [Resource] {
        didSet { save() }
    }

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Resource].self, from: data),
           !decoded.isEmpty {
            items = decoded
        } else {
            items = Resource.defaults
        }
    }

    var categories: [String] {
        var seen = Set<String>()
        return items.map(\.category).filter { seen.insert($0).inserted }
    }

    func items(in category: String) -> [Resource] {
        items.filter { $0.category == category }
    }

    func upsert(_ r: Resource) {
        if let i = items.firstIndex(where: { $0.id == r.id }) {
            items[i] = r
        } else {
            items.append(r)
        }
    }

    func delete(_ r: Resource) {
        items.removeAll { $0.id == r.id }
    }

    func resetToDefaults() {
        items = Resource.defaults
    }

    private func save() {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
