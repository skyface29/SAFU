import Foundation

struct Resource: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var subtitle: String
    var url: String
    var icon: String
    var category: String
    var pinned: Bool = false

    var isValid: Bool {
        guard !title.trimmingCharacters(in: .whitespaces).isEmpty,
              let u = URL(string: url),
              let scheme = u.scheme?.lowercased(),
              scheme == "http" || scheme == "https",
              u.host != nil else { return false }
        return true
    }

    static let defaults: [Resource] = [
        Resource(title: "Sakai", subtitle: "Курсы и задания",
                 url: "https://sakai.narfu.ru", icon: "graduationcap.fill", category: "Учёба"),
        Resource(title: "РУЗ", subtitle: "Расписание",
                 url: "https://ruz.narfu.ru", icon: "clock.fill", category: "Учёба"),
        Resource(title: "Почта", subtitle: "Samoware",
                 url: "https://edu.narfu.ru", icon: "envelope.fill", category: "Почта и документы"),
        Resource(title: "Р7-Офис", subtitle: "Документы",
                 url: "https://office.edu.narfu.ru", icon: "doc.text.fill", category: "Почта и документы"),
        Resource(title: "САФУ", subtitle: "narfu.ru",
                 url: "https://narfu.ru", icon: "building.columns.fill", category: "Университет"),
        Resource(title: "Студенту", subtitle: "Справочник",
                 url: "https://narfu.ru/forstudent/", icon: "book.fill", category: "Университет"),
        Resource(title: "ВШИТАС", subtitle: "Высшая школа",
                 url: "https://narfu.ru/hsitas/", icon: "cpu", category: "Университет"),
        Resource(title: "Личный кабинет", subtitle: "Зачётная книжка",
                 url: "https://lk.narfu.ru", icon: "person.text.rectangle.fill", category: "Университет"),
        Resource(title: "Вход на сайт", subtitle: "narfu.ru",
                 url: "https://narfu.ru/user/authorization.php", icon: "person.crop.circle.fill", category: "Университет")
    ]
}

extension Resource {
    /// Рабочие сайты преподавателя САФУ (добавляются при регистрации преподавателем)
    static let teacherDefaults: [Resource] = [
        Resource(title: "Антиплагиат.ВУЗ", subtitle: "Проверка ВКР и работ",
                 url: "https://narfu.antiplagiat.ru", icon: "checkmark.shield.fill", category: "Преподавателю"),
        Resource(title: "МООК САФУ", subtitle: "Онлайн-курсы Open edX",
                 url: "https://edx2.narfu.ru", icon: "play.rectangle.fill", category: "Преподавателю"),
        Resource(title: "Сотруднику", subtitle: "Сервисы и документы",
                 url: "https://narfu.ru/forstaff/", icon: "briefcase.fill", category: "Преподавателю"),
        Resource(title: "Инструкции ИТ", subtitle: "Учётные записи, почта, Sakai",
                 url: "https://narfu.ru/university/structure/upravleniya/it/manuals/", icon: "wrench.and.screwdriver.fill", category: "Преподавателю"),
        Resource(title: "Библиотека", subtitle: "Интеллектуальный центр",
                 url: "https://library.narfu.ru", icon: "books.vertical.fill", category: "Преподавателю"),
    ]

    // Старые сохранения (без «закреплено») тоже читаются
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        title = try c.decode(String.self, forKey: .title)
        subtitle = try c.decodeIfPresent(String.self, forKey: .subtitle) ?? ""
        url = try c.decode(String.self, forKey: .url)
        icon = try c.decodeIfPresent(String.self, forKey: .icon) ?? "link"
        category = try c.decodeIfPresent(String.self, forKey: .category) ?? "Мои ссылки"
        pinned = try c.decodeIfPresent(Bool.self, forKey: .pinned) ?? false
    }
}

final class ResourceStore: ObservableObject {
    private let itemsKey = "resources.v1"
    private let recentsKey = "memory.recents"
    private let lastURLsKey = "memory.lastURLs"

    @Published var items: [Resource] { didSet { saveItems() } }
    /// Память: недавно открытые ресурсы (последние сверху)
    @Published private(set) var recentIDs: [UUID] { didSet { saveRecents() } }
    /// Счётчик открытий в текущей сессии — для анимации иконок
    @Published private(set) var openTicks: [UUID: Int] = [:]
    /// Память: последняя страница внутри каждого ресурса
    private var lastURLs: [String: String]

    init() {
        let d = UserDefaults.standard
        if let data = d.data(forKey: itemsKey),
           let decoded = try? JSONDecoder().decode([Resource].self, from: data),
           !decoded.isEmpty {
            items = decoded
        } else {
            items = Resource.defaults
        }
        recentIDs = (d.stringArray(forKey: recentsKey) ?? []).compactMap(UUID.init(uuidString:))
        lastURLs = (d.dictionary(forKey: lastURLsKey) as? [String: String]) ?? [:]
        // Модеус больше не нужен: расписание берётся из РУЗ
        items.removeAll { $0.url.contains("modeus") }
        // Новый личный кабинет (зачётка) добавляем и тем, у кого список уже сохранён
        if !items.contains(where: { $0.url.contains("lk.narfu.ru") }) {
            items.append(Resource(title: "Личный кабинет", subtitle: "Зачётная книжка",
                                  url: "https://lk.narfu.ru", icon: "person.text.rectangle.fill",
                                  category: "Университет"))
        }
        saveItems()
    }

    var categories: [String] {
        var seen = Set<String>()
        return items.map(\.category).filter { seen.insert($0).inserted }
    }

    func items(in category: String) -> [Resource] {
        items.filter { $0.category == category && !$0.pinned }
    }

    var pinnedItems: [Resource] { items.filter(\.pinned) }

    /// Категории, в которых остались незакреплённые сайты
    var visibleCategories: [String] {
        categories.filter { !items(in: $0).isEmpty }
    }

    func search(_ query: String) -> [Resource] {
        let q = query.trimmingCharacters(in: .whitespaces)
        guard !q.isEmpty else { return [] }
        return items.filter {
            $0.title.localizedCaseInsensitiveContains(q)
                || $0.subtitle.localizedCaseInsensitiveContains(q)
                || $0.category.localizedCaseInsensitiveContains(q)
                || $0.url.localizedCaseInsensitiveContains(q)
        }
    }

    func togglePin(_ r: Resource) {
        guard let i = items.firstIndex(where: { $0.id == r.id }) else { return }
        items[i].pinned.toggle()
    }

    var recents: [Resource] {
        recentIDs.compactMap { id in items.first { $0.id == id } }
    }

    /// Быстрые кнопки на главной
    var quick: [Resource] {
        // свой выбор из настроек главного экрана
        let chosen = (UserDefaults.standard.string(forKey: "quick.ids") ?? "")
            .split(separator: ",").map(String.init)
        if !chosen.isEmpty {
            return chosen.compactMap { id in items.first { $0.id.uuidString == id } }
        }
        return ["ruz.narfu", "edu.narfu", "sakai", "office.edu"].compactMap { key in
            items.first { $0.url.contains(key) }
        }
    }

    func index(of r: Resource) -> Int {
        items.firstIndex { $0.id == r.id } ?? 0
    }

    // MARK: память

    func markOpened(_ r: Resource) {
        var ids = recentIDs.filter { $0 != r.id }
        ids.insert(r.id, at: 0)
        recentIDs = Array(ids.prefix(8))
        openTicks[r.id, default: 0] += 1
    }

    /// То же, но когда карточка сайта уже выехала: иначе главная перестраивает «Недавние» с анимацией
    /// в те же мгновения, когда карточка только начинает подниматься, и старт выходит с запинкой
    func markOpenedSoon(_ r: Resource) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.markOpened(r) }
    }

    func lastURL(for r: Resource) -> URL? {
        lastURLs[r.id.uuidString].flatMap(URL.init(string:))
    }

    /// Запоминаем страницу, только если к ней безопасно вернуться:
    /// тот же сайт и не страница входа/выхода (одноразовые ссылки входа потом ломают открытие)
    func saveLastURL(_ url: URL, for r: Resource) {
        guard let home = URL(string: r.url)?.host?.lowercased(),
              let host = url.host?.lowercased(),
              host == home || host.hasSuffix("." + home) || home.hasSuffix("." + host) else { return }
        let s = url.absoluteString.lowercased()
        let bad = ["login", "logout", "auth", "adfs", "saml", "token", "ticket", "sso", "signin",
                   "session", "xlogin", "relogin", "error", "redirect"]
        if bad.contains(where: { s.contains($0) }) { return }
        lastURLs[r.id.uuidString] = url.absoluteString
        UserDefaults.standard.set(lastURLs, forKey: lastURLsKey)
    }

    func clearLastURL(for r: Resource) {
        lastURLs[r.id.uuidString] = nil
        UserDefaults.standard.set(lastURLs, forKey: lastURLsKey)
    }

    func clearMemory() {
        recentIDs = []
        lastURLs = [:]
        UserDefaults.standard.set(lastURLs, forKey: lastURLsKey)
    }

    // MARK: редактирование

    func upsert(_ r: Resource) {
        if let i = items.firstIndex(where: { $0.id == r.id }) {
            items[i] = r
        } else {
            items.append(r)
        }
    }

    func delete(_ r: Resource) {
        items.removeAll { $0.id == r.id }
        recentIDs.removeAll { $0 == r.id }
    }

    func resetToDefaults() {
        items = Resource.defaults
        clearMemory()
    }

    private func saveItems() {
        if let data = try? JSONEncoder().encode(items) {
            UserDefaults.standard.set(data, forKey: itemsKey)
        }
    }

    private func saveRecents() {
        UserDefaults.standard.set(recentIDs.map(\.uuidString), forKey: recentsKey)
    }
}
