import SwiftUI
import UIKit

// MARK: - ДЗ по нажатию: красиво оформленная карточка и «Отправить ребятам»
//
// Нажал на задание — сначала оно открывается для чтения: предмет, срок, текст по пунктам
// (записано как попало — показано аккуратно), шаги, заметка и фото. «Изменить» — тот же редактор, что раньше.
// «Отправить ребятам» — картинкой (красивая карточка для чата группы) или текстом.

/// Что показать в листе ДЗ: карточку для чтения или редактор
struct HomeworkSheet: View {
    let route: HWEditorRoute
    let data: ScheduleData
    @State private var editing = false

    var body: some View {
        if route.preview, let h = route.homework, !editing {
            HWDetailView(id: h.id, fallback: h, data: data) {
                withAnimation(.easeInOut(duration: 0.2)) { editing = true }
            }
        } else {
            HomeworkEditor(route: editRoute, data: data)
        }
    }

    private var editRoute: HWEditorRoute {
        guard route.preview, let h = route.homework else { return route }
        return HWEditorRoute(homework: HomeworkStore.shared.item(h.id) ?? h, slot: nil, subject: nil)
    }
}

struct HWDetailView: View {
    let id: UUID
    let fallback: Homework
    let data: ScheduleData
    let onEdit: () -> Void
    @ObservedObject private var store = HomeworkStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var share: ShareItem?
    @State private var preview: HWPhotoRef?
    @State private var copied = false

    private var h: Homework { store.item(id) ?? fallback }
    private var color: Color { SubjectColor.color(for: h.subject) }

    var body: some View {
        let hw = h
        let blocks = HWPretty.blocks(hw.text)
        NavigationStack {
            ZStack {
                AmbientBackground()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 14) {
                        header(hw)
                        dueCard(hw)
                        if !blocks.isEmpty { taskCard(blocks) }
                        if !hw.steps.isEmpty { stepsCard(hw) }
                        let note = hw.note.trimmingCharacters(in: .whitespacesAndNewlines)
                        if !note.isEmpty { noteCard(note) }
                        if !hw.photos.isEmpty { photosCard(hw) }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { actionBar(hw) }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Закрыть") { dismiss() }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button { onEdit() } label: { Label("Изменить", systemImage: "pencil") }
                }
            }
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(item: $preview) { HWPhotoViewer(ref: $0) }
    }

    // MARK: части

    private func header(_ hw: Homework) -> some View {
        HStack(alignment: .center, spacing: 14) {
            Image(systemName: hw.kind.icon)
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 54, height: 54)
                .background(color.gradient, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .shadow(color: color.opacity(0.35), radius: 10, y: 5)
            VStack(alignment: .leading, spacing: 6) {
                Text(hw.subject.isEmpty ? "Без предмета" : hw.subject)
                    .font(.system(.title2, design: .rounded).weight(.bold))
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 6) {
                    tag(hw.kind.title, icon: hw.kind.icon, tint: color)
                    if hw.important { tag("Важно", icon: "exclamationmark", tint: .red) }
                    if hw.done { tag("Сделано", icon: "checkmark", tint: .green) }
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.top, 6)
    }

    private func tag(_ text: String, icon: String, tint: Color) -> some View {
        Label(text, systemImage: icon)
            .font(.caption.weight(.semibold))
            .foregroundStyle(tint)
            .padding(.horizontal, 9)
            .padding(.vertical, 4)
            .background(tint.opacity(0.13), in: Capsule())
    }

    private func dueCard(_ hw: Homework) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Label("Сдать", systemImage: "calendar")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                Spacer()
                Text((hw.dueEstimated ? "≈ " : "") + HWFormat.chip(hw.due, done: hw.done))
                    .font(.footnote.weight(.bold))
                    .foregroundStyle(HWFormat.urgency(hw.due, done: hw.done))
            }
            Text(HWShare.dueLine(hw).capitalizedFirst)
                .font(.headline)
                .fixedSize(horizontal: false, vertical: true)
            if hw.dueEstimated {
                Text("Срок посчитан по прошлым неделям — РУЗ ещё не выложил расписание")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            if !hw.shiftNote.isEmpty {
                Text(hw.shiftNote)
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
            Button {
                dismiss()
                ScheduleJump.shared.show(hw.due)
            } label: {
                Label("Показать в расписании", systemImage: "arrow.right.circle")
                    .font(.subheadline.weight(.semibold))
            }
            .buttonStyle(.plain)
            .foregroundStyle(Color.brand)
            .padding(.top, 2)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(20)
    }

    private func taskCard(_ blocks: [HWPretty.Block]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("Задание", icon: "text.alignleft")
            ForEach(blocks) { b in
                HWBlockRow(block: b)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(20)
        .textSelection(.enabled)
    }

    private func stepsCard(_ hw: Homework) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                sectionTitle("Шаги", icon: "checklist")
                Spacer()
                Text("\(hw.stepsDone) из \(hw.steps.count)")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
            }
            ProgressView(value: hw.stepsProgress)
                .tint(color)
            ForEach(hw.steps) { s in
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) { store.toggleStep(hw, step: s) }
                } label: {
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Image(systemName: s.done ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(s.done ? Color.green : Color.secondary)
                        Text(HWPretty.styled(HWPretty.clean(s.text)))
                            .strikethrough(s.done)
                            .foregroundStyle(s.done ? .secondary : .primary)
                            .multilineTextAlignment(.leading)
                        Spacer(minLength: 0)
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(20)
    }

    private func noteCard(_ note: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("Заметка", icon: "text.bubble")
            Text(note)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .textSelection(.enabled)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(20)
    }

    private func photosCard(_ hw: Homework) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("Фото · \(hw.photos.count)", icon: "photo.on.rectangle")
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 8)], spacing: 8) {
                ForEach(hw.photos, id: \.self) { p in
                    Button { preview = HWPhotoRef(owner: hw.id, name: p) } label: {
                        HWThumb(id: hw.id, name: p, size: 92)
                    }
                    .buttonStyle(PressableStyle())
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(20)
    }

    private func sectionTitle(_ text: String, icon: String) -> some View {
        Label(text, systemImage: icon)
            .font(.footnote.weight(.semibold))
            .foregroundStyle(.secondary)
    }

    // MARK: снизу: сделано и отправить

    private func actionBar(_ hw: Homework) -> some View {
        HStack(spacing: 10) {
            Button {
                Haptics.success()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { store.toggle(hw) }
            } label: {
                Image(systemName: hw.done ? "arrow.uturn.backward" : "checkmark")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(hw.done ? Color.primary : Color.green)
                    .frame(width: 54, height: 50)
                    .glass(16)
            }
            .buttonStyle(PressableStyle())
            .accessibilityLabel(hw.done ? "Вернуть в работу" : "Сделано")

            Menu {
                Button { shareImage(hw) } label: { Label("Картинкой", systemImage: "photo") }
                Button { share = ShareItem(items: HWShare.items(hw)) } label: { Label("Текстом", systemImage: "text.alignleft") }
                Button {
                    UIPasteboard.general.string = HWShare.text(hw)
                    Haptics.success()
                } label: { Label("Скопировать текст", systemImage: "doc.on.doc") }
            } label: {
                Label("Отправить ребятам", systemImage: "paperplane.fill")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            } primaryAction: {
                shareImage(hw)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(.bar)
    }

    /// Карточка картинкой (и фото задания следом) — так в чате группы выглядит аккуратнее всего
    private func shareImage(_ hw: Homework) {
        Haptics.tap()
        var items: [Any] = []
        if let img = HWShareCard.render(hw) { items.append(img) } else { items.append(HWShare.text(hw)) }
        for p in hw.photos {
            let u = HWFiles.url(hw.id, p)
            if FileManager.default.fileExists(atPath: u.path) { items.append(u) }
        }
        share = ShareItem(items: items)
    }
}

/// Пункт задания: номер или точка в цвет темы, текст с выделенными номерами и страницами
struct HWBlockRow: View {
    let block: HWPretty.Block
    var size: CGFloat = 17

    var body: some View {
        if block.marker.isEmpty {
            Text(HWPretty.styled(block.text))
                .font(.system(size: size))
                .fixedSize(horizontal: false, vertical: true)
        } else {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text(block.marker)
                    .font(.system(size: size, weight: .bold, design: .rounded))
                    .foregroundStyle(Color.brand)
                    .frame(minWidth: 22, alignment: .leading)
                Text(HWPretty.styled(block.text))
                    .font(.system(size: size))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

// MARK: - Картинка для чата группы

/// Аккуратная карточка ДЗ: цветная шапка с предметом, срок, задание по пунктам, шаги и подпись
struct HWShareCard: View {
    let hw: Homework

    @MainActor
    static func render(_ hw: Homework) -> UIImage? {
        let r = ImageRenderer(content: HWShareCard(hw: hw).environment(\.colorScheme, .light))
        r.scale = 3
        return r.uiImage
    }

    var body: some View {
        let color = SubjectColor.color(for: hw.subject)
        let blocks = HWPretty.blocks(hw.text)
        let note = hw.note.trimmingCharacters(in: .whitespacesAndNewlines)
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "book.closed.fill")
                    Text("ДОМАШНЕЕ ЗАДАНИЕ")
                        .tracking(1.2)
                    Spacer()
                    if hw.important {
                        Text("ВАЖНО")
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(.white.opacity(0.25), in: Capsule())
                    }
                }
                .font(.system(size: 11, weight: .heavy))
                .foregroundStyle(.white.opacity(0.9))
                Text(hw.subject.isEmpty ? "Без предмета" : hw.subject)
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 6) {
                    Image(systemName: "calendar")
                    Text("Сдать: " + HWShare.dueLine(hw))
                }
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white.opacity(0.95))
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [color, Color.brand], startPoint: .topLeading, endPoint: .bottomTrailing))

            VStack(alignment: .leading, spacing: 12) {
                ForEach(blocks) { b in
                    HWBlockRow(block: b, size: 16)
                        .foregroundStyle(Color(white: 0.1))
                }
                if !hw.steps.isEmpty {
                    if !blocks.isEmpty { Divider() }
                    ForEach(hw.steps) { s in
                        HStack(alignment: .firstTextBaseline, spacing: 10) {
                            Image(systemName: s.done ? "checkmark.square.fill" : "square")
                                .foregroundStyle(s.done ? Color.green : color)
                            Text(HWPretty.clean(s.text))
                                .font(.system(size: 15))
                                .foregroundStyle(Color(white: 0.15))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
                if !note.isEmpty {
                    Text(note)
                        .font(.system(size: 14).italic())
                        .foregroundStyle(Color(white: 0.4))
                        .fixedSize(horizontal: false, vertical: true)
                }
                if !hw.photos.isEmpty {
                    Label("\(hw.photos.count) фото — следом", systemImage: "paperclip")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color(white: 0.45))
                }
                if blocks.isEmpty && hw.steps.isEmpty && note.isEmpty {
                    Text("Без описания")
                        .font(.system(size: 15))
                        .foregroundStyle(Color(white: 0.45))
                }
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 5) {
                Image(systemName: "snowflake")
                Text("Арктика")
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(Color(white: 0.6))
            .padding(.horizontal, 20)
            .padding(.bottom, 14)
        }
        .frame(width: 360)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .shadow(color: .black.opacity(0.12), radius: 14, y: 6)
        .padding(18)
        .background(LinearGradient(colors: [color.opacity(0.16), Color.brand.opacity(0.10)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing))
        .background(Color.white)
    }
}
