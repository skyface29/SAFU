import SwiftUI
import UserNotifications
#if canImport(AlarmKit)
import AlarmKit
#endif

// MARK: - Умный подъём
// Будильник ставится сам под первую пару: автобус 150, дорога до остановки, сборы, мороз.
// Вечером — «пора спать» по циклам сна (по 90 минут), чтобы проснуться легко.
// На iOS 26 — настоящий будильник (AlarmKit), на старых — серия громких уведомлений.

enum WakeSettings {
    private static var d: UserDefaults { .standard }
    static var enabled: Bool { d.object(forKey: "wake.on") as? Bool ?? false }
    static var prepMinutes: Int { let v = d.integer(forKey: "wake.prep"); return v == 0 ? 40 : v }
    static var coldEarlier: Bool { d.object(forKey: "wake.cold") as? Bool ?? true }
    static var cycles: Int { let v = d.integer(forKey: "wake.cycles"); return v == 0 ? 5 : v }
    static var bedtime: Bool { d.object(forKey: "wake.bed") as? Bool ?? true }
    static var realAlarm: Bool { d.object(forKey: "wake.alarm") as? Bool ?? true }
}

struct WakePlan: Identifiable {
    let pair: LessonSlot
    let bus: BusTrip?
    let leave: Date
    let wake: Date
    let bed: Date
    let cold: Bool
    let remote: Bool
    var id: Date { pair.start }
}

enum WakePlanner {
    /// План на день: когда лечь, встать, выйти
    static func plan(for day: Date, data: ScheduleData) -> WakePlan? {
        guard let first = ScheduleEngine.slots(on: day, data: data).first else { return nil }
        let remote = AddressFormat.isRemote(first.address)
        var bus: BusTrip?
        var leave: Date
        if remote {
            leave = first.start
        } else if CommuteSettings.enabled, let trip = CommutePlanner.morning(for: first) {
            bus = trip
            leave = trip.departure.addingTimeInterval(-Double(CommuteSettings.homeMinutes) * 60)
        } else {
            leave = first.start.addingTimeInterval(-45 * 60)
        }
        var wake = leave.addingTimeInterval(-Double(remote ? 25 : WakeSettings.prepMinutes) * 60)
        var cold = false
        if WakeSettings.coldEarlier, !remote,
           let w = WeatherCache.cachedHour(at: bus?.departure ?? leave), w.feels <= -20 {
            wake = wake.addingTimeInterval(-10 * 60)
            cold = true
        }
        // лечь: целые циклы сна по 90 минут + 15 минут, чтобы уснуть
        let bed = wake.addingTimeInterval(-Double(WakeSettings.cycles) * 90 * 60 - 15 * 60)
        return WakePlan(pair: first, bus: bus, leave: leave, wake: wake, bed: bed, cold: cold, remote: remote)
    }

    /// Планы на неделю вперёд, у которых подъём ещё впереди
    static func upcoming(_ data: ScheduleData, days: Int = 7) -> [WakePlan] {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        return (0..<days).compactMap { off -> WakePlan? in
            guard let d = cal.date(byAdding: .day, value: off, to: today), let p = plan(for: d, data: data) else { return nil }
            return p.wake > Date() ? p : nil
        }
    }

    static func hm(_ d: Date) -> String { Fmt.formatter("H:mm").string(from: d) }

    /// Текст «пара и автобус» для уведомления
    static func details(_ p: WakePlan) -> String {
        var s = "«\(p.pair.lesson.subject)» в \(hm(p.pair.start))"
        if let b = p.bus { s += " · автобус \(BusRoutes.active.number) в \(hm(b.departure))" }
        if p.remote { s += " · дистанционно" }
        if let w = WeatherCache.cachedHour(at: p.bus?.departure ?? p.leave) { s += "\n" + WeatherCache.line(w) }
        return s
    }

    /// Пересчитать уведомления и будильники (после любого изменения расписания или настроек)
    static func schedule(data: ScheduleData) {
        let plans = upcoming(data)
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { reqs in
            let old = reqs.map(\.identifier).filter { $0.hasPrefix("wake-") || $0.hasPrefix("bed-") }
            center.removePendingNotificationRequests(withIdentifiers: old)
            guard WakeSettings.enabled else { return }
            let cal = Calendar.current
            let useAlarm = alarmKitAvailable && WakeSettings.realAlarm
            for (i, p) in plans.enumerated() {
                // подъём: если нет настоящего будильника — три громких уведомления подряд
                if !useAlarm {
                    for (k, delay) in [0.0, 3.0, 6.0].enumerated() {
                        let fire = p.wake.addingTimeInterval(delay * 60)
                        let c = UNMutableNotificationContent()
                        c.title = k == 0 ? "Подъём ⏰ \(hm(p.wake))" : "Вставай! Уже \(hm(fire)) ⏰"
                        c.body = details(p) + (p.cold ? "\nМороз — будильник на 10 минут раньше" : "")
                        c.sound = .default
                        let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                        center.add(UNNotificationRequest(identifier: "wake-\(i)-\(k)", content: c,
                                                         trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
                    }
                }
                // пора спать
                if WakeSettings.bedtime, p.bed > Date() {
                    let c = UNMutableNotificationContent()
                    c.title = "Пора спать 😴"
                    c.body = "Подъём в \(hm(p.wake)) — это \(WakeSettings.cycles) циклов сна. Завтра " + details(p)
                    c.sound = .default
                    let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: p.bed)
                    center.add(UNNotificationRequest(identifier: "bed-\(i)", content: c,
                                                     trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
                }
            }
        }
        #if canImport(AlarmKit)
        if #available(iOS 26.0, *) {
            Task { await WakeAlarms.sync(plans) }
        }
        #endif
    }

    /// Есть ли на этом телефоне настоящий будильник (iOS 26+)
    static var alarmKitAvailable: Bool {
        #if canImport(AlarmKit)
        if #available(iOS 26.0, *) { return true }
        #endif
        return false
    }
}

#if canImport(AlarmKit)
@available(iOS 26.0, *)
enum WakeAlarms {
    struct Meta: AlarmMetadata {}
    private static let key = "wake.alarmIDs"

    static func sync(_ plans: [WakePlan]) async {
        let manager = AlarmManager.shared
        for s in UserDefaults.standard.stringArray(forKey: key) ?? [] {
            if let id = UUID(uuidString: s) { try? manager.cancel(id: id) }
        }
        UserDefaults.standard.set([String](), forKey: key)
        guard WakeSettings.enabled, WakeSettings.realAlarm else { return }
        if manager.authorizationState == .notDetermined {
            _ = try? await manager.requestAuthorization()
        }
        guard manager.authorizationState == .authorized else { return }
        var ids: [String] = []
        for p in plans.prefix(3) where p.wake > Date() {
            let time = WakePlanner.hm(p.pair.start)
            let stop = AlarmButton(text: "Встаю", textColor: .white, systemImageName: "sun.max.fill")
            let alert = AlarmPresentation.Alert(title: "Подъём — пара в \(time)", stopButton: stop)
            let attributes = AlarmAttributes<Meta>(presentation: AlarmPresentation(alert: alert), tintColor: .orange)
            let id = UUID()
            if (try? await manager.schedule(id: id, configuration: .alarm(schedule: .fixed(p.wake), attributes: attributes))) != nil {
                ids.append(id.uuidString)
            }
        }
        UserDefaults.standard.set(ids, forKey: key)
    }
}
#endif

// MARK: - Экран «Подъём»

struct WakeView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("wake.on") private var enabled = false
    @AppStorage("wake.prep") private var prep = 40
    @AppStorage("wake.cold") private var cold = true
    @AppStorage("wake.cycles") private var cycles = 5
    @AppStorage("wake.bed") private var bedtime = true
    @AppStorage("wake.alarm") private var realAlarm = true

    private var plans: [WakePlan] { WakePlanner.upcoming(schedule.data) }

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $enabled) {
                    Label("Умный подъём", systemImage: "alarm.fill")
                }
            } footer: {
                Text("Будильник ставится сам под первую пару: учитывает автобус, дорогу до остановки, сборы и мороз. Вечером подскажет, когда лечь, чтобы проснуться в конце цикла сна.")
            }

            if let p = plans.first {
                Section {
                    timeline(p)
                        .padding(.vertical, 6)
                } header: {
                    Text(Calendar.current.isDateInToday(p.pair.start) ? "Сегодня" : (Calendar.current.isDateInTomorrow(p.pair.start) ? "Завтра" : Fmt.formatter("EEEE, d MMMM").string(from: p.pair.start)))
                }
            } else {
                Section {
                    Text("На неделю вперёд пар нет — будильник не нужен 😎").foregroundStyle(.secondary)
                }
            }

            Section("Настройки") {
                Stepper("Сборы: \(prep) мин", value: $prep, in: 10...120, step: 5)
                Stepper("Сон: \(cycles) циклов · \(sleepText)", value: $cycles, in: 3...7)
                Toggle("В мороз будить на 10 минут раньше", isOn: $cold)
                Toggle("Напоминать, когда ложиться", isOn: $bedtime)
                if WakePlanner.alarmKitAvailable {
                    Toggle("Настоящий будильник", isOn: $realAlarm)
                }
            }

            if plans.count > 1 {
                Section("Неделя") {
                    ForEach(plans) { p in
                        HStack {
                            Text(Fmt.formatter("EE, d MMM").string(from: p.pair.start).capitalizedFirst)
                                .frame(width: 88, alignment: .leading)
                            Text(WakePlanner.hm(p.wake)).fontWeight(.bold).monospacedDigit()
                            if p.cold { Text("❄️") }
                            Spacer()
                            Text(p.pair.lesson.subject).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        .font(.subheadline)
                    }
                }
            }
        }
        .navigationTitle("Подъём")
        .onChange(of: enabled) { _ in resync() }
        .onChange(of: prep) { _ in resync() }
        .onChange(of: cycles) { _ in resync() }
        .onChange(of: cold) { _ in resync() }
        .onChange(of: bedtime) { _ in resync() }
        .onChange(of: realAlarm) { _ in resync() }
    }

    private var sleepText: String {
        let m = cycles * 90
        return m % 60 == 0 ? "\(m / 60) ч" : "\(m / 60) ч \(m % 60) мин"
    }

    private func resync() {
        Haptics.tap()
        Notifier.requestAuthorization()
        WakePlanner.schedule(data: schedule.data)
    }

    private func timeline(_ p: WakePlan) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            step("moon.zzz.fill", "Лечь", p.bed, "\(cycles) циклов сна")
            step("alarm.fill", "Подъём", p.wake, p.cold ? "мороз — на 10 минут раньше" : "сборы \(prep) мин", big: true)
            if !p.remote { step("figure.walk", "Выйти из дома", p.leave, nil) }
            if let b = p.bus { step("bus.fill", "Автобус \(BusRoutes.active.number)", b.departure, nil) }
            step("graduationcap.fill", p.pair.lesson.subject, p.pair.start, p.remote ? "дистанционно" : (p.pair.lesson.room.isEmpty ? nil : "ауд. \(p.pair.lesson.room)"), last: true)
        }
    }

    private func step(_ icon: String, _ title: String, _ time: Date, _ note: String?, big: Bool = false, last: Bool = false) -> some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 0) {
                Image(systemName: icon)
                    .font(.system(size: big ? 16 : 13, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: big ? 34 : 28, height: big ? 34 : 28)
                    .background(big ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.brand.opacity(0.55)), in: Circle())
                if !last {
                    Rectangle().fill(Color.brand.opacity(0.25)).frame(width: 2, height: 18)
                }
            }
            .frame(width: 34)
            VStack(alignment: .leading, spacing: 1) {
                HStack {
                    Text(title).font(big ? Font.headline : Font.subheadline.weight(.semibold)).lineLimit(1)
                    Spacer()
                    Text(WakePlanner.hm(time))
                        .font(big ? Font.system(.title2, design: .rounded).weight(.heavy) : Font.subheadline.weight(.bold))
                        .monospacedDigit()
                        .foregroundStyle(big ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary))
                }
                if let note { Text(note).font(.caption).foregroundStyle(.secondary) }
            }
        }
    }
}
