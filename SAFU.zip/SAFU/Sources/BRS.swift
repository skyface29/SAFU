import SwiftUI

// MARK: - БРС: балльно-рейтинговая система
// Баллы по каждому предмету, прогноз оценки, сколько не хватает до зачёта / 4 / 5 / автомата.
// Хранится под старым ключом grades.v1 — прежние оценки не пропадут.

struct GradeEntry: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var points: Double
    var outOf: Double = 0          // 0 — без максимума
    var date: Date = Date()
    /// "" — вписано вручную, иначе откуда подтянуто (Sakai / ЛК)
    var source: String = ""

    init(title: String, points: Double, outOf: Double = 0, date: Date = Date(), source: String = "") {
        self.title = title; self.points = points; self.outOf = outOf; self.date = date; self.source = source
    }

    /// Итоговый балл из Личного кабинета — он уже включает всё остальное
    var isTotal: Bool { source == "ЛК" && title == "Итог" }

    private enum K: String, CodingKey { case id, title, points, outOf, date, source }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? "Работа"
        points = try c.decodeIfPresent(Double.self, forKey: .points) ?? 0
        outOf = try c.decodeIfPresent(Double.self, forKey: .outOf) ?? 0
        date = try c.decodeIfPresent(Date.self, forKey: .date) ?? Date()
        source = try c.decodeIfPresent(String.self, forKey: .source) ?? ""
    }
}

enum ControlType: Int, Codable, CaseIterable, Identifiable {
    case credit = 0, exam = 1, graded = 2
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .credit: return "Зачёт"
        case .exam: return "Экзамен"
        case .graded: return "Дифзачёт"
        }
    }
}

struct SubjectGrades: Codable, Identifiable, Hashable {
    var id = UUID()
    var subject: String
    var entries: [GradeEntry] = []
    var pass: Double = 61          // зачёт / «3»
    var good: Double = 76          // «4»
    var excellent: Double = 91     // «5»
    var auto: Double = 85          // автомат
    var max: Double = 100
    var control: ControlType = .exam
    var result: String = ""        // итог после сессии

    init(subject: String) { self.subject = subject }

    private enum K: String, CodingKey { case id, subject, entries, pass, good, excellent, auto, max, control, result }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        subject = try c.decodeIfPresent(String.self, forKey: .subject) ?? ""
        entries = try c.decodeIfPresent([GradeEntry].self, forKey: .entries) ?? []
        pass = try c.decodeIfPresent(Double.self, forKey: .pass) ?? 61
        good = try c.decodeIfPresent(Double.self, forKey: .good) ?? 76
        excellent = try c.decodeIfPresent(Double.self, forKey: .excellent) ?? 91
        auto = try c.decodeIfPresent(Double.self, forKey: .auto) ?? 85
        max = try c.decodeIfPresent(Double.self, forKey: .max) ?? 100
        control = try c.decodeIfPresent(ControlType.self, forKey: .control) ?? .exam
        result = try c.decodeIfPresent(String.self, forKey: .result) ?? ""
    }

    var total: Double {
        if let t = entries.filter(\.isTotal).map(\.points).max() { return t }
        return entries.reduce(0) { $0 + $1.points }
    }
    var isAuto: Bool { entries.contains { !$0.source.isEmpty } }
    var ratio: Double { max > 0 ? Swift.min(1, total / max) : 0 }

    /// Прогноз по текущим баллам
    var forecast: String {
        let t = total
        switch control {
        case .credit:
            return t >= pass ? "зачёт" : "пока не зачёт"
        case .exam, .graded:
            if t >= excellent { return "5" }
            if t >= good { return "4" }
            if t >= pass { return "3" }
            return "—"
        }
    }

    var statusColor: Color {
        let t = total
        if t >= auto || t >= excellent { return .green }
        if t >= pass { return Color.brand }
        if ratio >= 0.4 { return .orange }
        return .red
    }

    /// Что делать дальше — одной строкой
    var nextStep: String {
        let t = total
        func f(_ v: Double) -> String { BRSFormat.num(v) }
        if !result.isEmpty { return "Итог: \(result)" }
        if t >= max { return "Максимум набран 🔥" }
        if control == .credit {
            if t >= auto { return "Автомат есть 🎉" }
            if t >= pass { return "Зачёт есть · до автомата \(f(auto - t))" }
            return "До зачёта \(f(pass - t))"
        }
        if t >= excellent { return "Идёшь на «5» 🎉" }
        if t >= good { return "Сейчас «4» · до «5» \(f(excellent - t))" }
        if t >= pass { return "Сейчас «3» · до «4» \(f(good - t))" }
        return "До «3» не хватает \(f(pass - t))"
    }
}

enum BRSFormat {
    static func num(_ v: Double) -> String {
        v == v.rounded() ? String(Int(v)) : String(format: "%.1f", v)
    }
}

final class GradesStore: ObservableObject {
    static let shared = GradesStore()
    @Published var items: [SubjectGrades] = [] { didSet { save() } }
    private let key = "grades.v1"

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let v = try? JSONDecoder().decode([SubjectGrades].self, from: raw) { items = v }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(items) { UserDefaults.standard.set(raw, forKey: key) }
    }

    func index(of subject: String) -> Int? { items.firstIndex { $0.subject == subject } }

    var average: Double {
        let list = items.filter { !$0.entries.isEmpty }
        guard !list.isEmpty else { return 0 }
        return list.reduce(0) { $0 + $1.total } / Double(list.count)
    }
}

// MARK: - Экран БРС

struct BRSView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = GradesStore.shared
    @State private var open: SubjectGrades?
    @State private var syncing = false
    @State private var status = ""
    @State private var showReport = false
    @AppStorage("brs.auto") private var autoSync = true
    @State private var login: Resource?
    @State private var sakaiUser: String?
    @State private var lkOK = GradeSync.lkLoggedIn
    @State private var checkingLogin = true
    /// Для экрана входа: свой экземпляр, чтобы не зависеть от того, откуда открыта БРС
    private static let loginStore = ResourceStore()

    private var missing: [String] {
        ScheduleQuery.subjects(schedule.data).filter { s in !store.items.contains { $0.subject == s } }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                loginCard
                syncBar
                summary
                if store.items.isEmpty {
                    EmptyState(icon: "star.leadinghalf.filled", title: "Добавь предметы",
                               text: "Нажми «Добавить все из расписания» — и вписывай баллы за лабы, тесты и посещения.")
                }
                ForEach(Array(store.items.enumerated()), id: \.element.id) { i, g in
                    Button { Haptics.tap(); open = g } label: { subjectCard(g) }
                        .buttonStyle(PressableStyle())
                        .staggerIn(i)
                }
                if !missing.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        Button {
                            Haptics.success()
                            withAnimation { store.items += missing.map { SubjectGrades(subject: $0) } }
                        } label: {
                            Label("Добавить все из расписания (\(missing.count))", systemImage: "plus.circle.fill")
                                .font(.subheadline.weight(.semibold))
                        }
                        Menu {
                            ForEach(missing, id: \.self) { s in
                                Button(s) { withAnimation { store.items.append(SubjectGrades(subject: s)) } }
                            }
                        } label: {
                            Label("Добавить один предмет", systemImage: "plus")
                                .font(.subheadline)
                        }
                    }
                    .padding(16)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .glass(20)
                }
                Text("Баллы подтягиваются сами из Sakai (журнал оценок курсов) и Личного кабинета. Что не нашлось — можно вписать руками. Пороги оценок у каждого предмета можно поменять.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("БРС")
        .sheet(item: $open) { g in
            NavigationStack { BRSSubjectView(id: g.id) }
        }
        .sheet(isPresented: $showReport) {
            NavigationStack { SyncReportView() }
        }
        .fullScreenCover(item: $login, onDismiss: {
            // вернулся со входа — сразу проверяем и тянем баллы
            Task {
                await checkLogin()
                await sync()
            }
        }) { r in
            WebScreen(resource: r)
                .environmentObject(Self.loginStore)
                .environmentObject(schedule)
        }
        .task {
            await checkLogin()
            guard autoSync, !syncing else { return }
            if let l = GradeSync.lastRun, Date().timeIntervalSince(l) < 3 * 3600 { return }
            await sync()
        }
    }

    private func sync() async {
        guard !syncing else { return }
        syncing = true
        status = "Смотрю Sakai и Личный кабинет…"
        status = await GradeSync.run(subjects: ScheduleQuery.subjects(schedule.data))
        lkOK = GradeSync.lkLoggedIn
        syncing = false
        Haptics.success()
        GoldIcon.checkUnlock()
    }

    private func checkLogin() async {
        checkingLogin = true
        sakaiUser = await GradeSync.sakaiUser()
        lkOK = GradeSync.lkLoggedIn
        checkingLogin = false
    }

    // MARK: входы

    private var loginCard: some View {
        let allIn = sakaiUser != nil && lkOK
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(allIn ? "Входы в порядке" : "Сначала войди — баллы подтянутся сами")
                    .font(.system(.headline, design: .rounded))
                Spacer()
                if checkingLogin { ProgressView().controlSize(.small) }
            }
            loginRow(icon: "graduationcap.fill", title: "Sakai", ok: sakaiUser != nil,
                     detail: sakaiUser.map { "вход выполнен · \($0)" } ?? "нет входа — журнал оценок курсов не виден",
                     resource: Resource(title: "Sakai", subtitle: "Курсы и задания", url: "https://sakai.narfu.ru",
                                        icon: "graduationcap.fill", category: "Учёба"))
            loginRow(icon: "person.text.rectangle.fill", title: "Личный кабинет", ok: lkOK,
                     detail: lkOK ? "вход выполнен" : "нет входа (или ещё не проверялся) — итоговые баллы не видны",
                     resource: Resource(title: "Личный кабинет", subtitle: "Зачётная книжка", url: "https://lk.narfu.ru",
                                        icon: "person.text.rectangle.fill", category: "Университет"))
            if !allIn {
                VStack(alignment: .leading, spacing: 6) {
                    step(1, "Нажми «Войти» у сайта")
                    step(2, "Логин — почта САФУ, пароль — от учётной записи САФУ")
                    step(3, "Когда откроется твоя страница, закрой сайт крестиком ✕ слева вверху")
                    step(4, "Готово: баллы подтянутся сами, вход запомнится")
                }
                .padding(.top, 2)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func loginRow(icon: String, title: String, ok: Bool, detail: String, resource: Resource) -> some View {
        HStack(spacing: 12) {
            ZStack(alignment: .bottomTrailing) {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                Image(systemName: ok ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(Color.white, ok ? Color.green : Color.orange)
                    .offset(x: 5, y: 5)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.subheadline.weight(.bold))
                Text(detail).font(.caption).foregroundStyle(ok ? Color.green : Color.secondary).lineLimit(2)
            }
            Spacer(minLength: 0)
            Button {
                Haptics.tap()
                login = resource
            } label: {
                Text(ok ? "Открыть" : "Войти")
                    .font(.caption.weight(.bold))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .foregroundStyle(ok ? Color.brand : Color.white)
                    .background {
                        if ok { Capsule().fill(Color.brand.opacity(0.14)) } else { Capsule().fill(brandGradient) }
                    }
            }
            .buttonStyle(PressableStyle())
        }
    }

    private func step(_ n: Int, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text("\(n)")
                .font(.caption2.weight(.heavy))
                .foregroundStyle(.white)
                .frame(width: 18, height: 18)
                .background(Color.brand, in: Circle())
            Text(text).font(.caption).foregroundStyle(.secondary)
        }
    }

    private var syncBar: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(brandGradient)
                    if syncing {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .frame(width: 40, height: 40)
                VStack(alignment: .leading, spacing: 2) {
                    Text(syncing ? "Подтягиваю баллы…" : "Баллы с сайтов")
                        .font(.system(.subheadline, design: .rounded).weight(.bold))
                    Text(status.isEmpty ? (GradeSync.lastRun.map { "обновлено \(Fmt.relative($0))" } ?? "ещё не обновлялось") : status)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                Spacer(minLength: 0)
                Button {
                    Haptics.tap()
                    Task { await sync() }
                } label: {
                    Text("Обновить")
                        .font(.caption.weight(.bold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .foregroundStyle(.white)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .disabled(syncing)
            }
            HStack {
                Toggle("Сами при открытии", isOn: $autoSync)
                    .font(.caption.weight(.semibold))
                    .toggleStyle(.switch)
                    .fixedSize()
                Spacer()
                if !GradeSync.report.isEmpty {
                    Button("Что нашлось") { showReport = true }
                        .font(.caption.weight(.semibold))
                }
            }
        }
        .padding(14)
        .glass(22)
    }

    private var summary: some View {
        let withPoints = store.items.filter { !$0.entries.isEmpty }
        let good = store.items.filter { $0.total >= $0.pass }.count
        let risk = withPoints.filter { $0.total < $0.pass * 0.5 }.count
        return HStack(spacing: 12) {
            tile(BRSFormat.num(store.average.rounded()), "средний балл")
            tile("\(good)/\(store.items.count)", "с зачётом")
            tile("\(risk)", "в зоне риска", color: risk > 0 ? .orange : nil)
        }
    }

    private func tile(_ v: String, _ t: String, color: Color? = nil) -> some View {
        VStack(spacing: 2) {
            Text(v)
                .font(.system(size: 24, weight: .heavy, design: .rounded))
                .foregroundStyle(color.map { AnyShapeStyle($0) } ?? AnyShapeStyle(brandGradient))
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Text(t).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .glass(18)
    }

    private func subjectCard(_ g: SubjectGrades) -> some View {
        HStack(spacing: 14) {
            ProgressRing(value: g.ratio, color: g.statusColor, lineWidth: 5) {
                VStack(spacing: -2) {
                    Text(BRSFormat.num(g.total))
                        .font(.system(size: 15, weight: .heavy, design: .rounded))
                    Text(g.forecast == "—" ? String(g.control.title.lowercased().prefix(3)) + "." : g.forecast)
                        .font(.system(size: 9, weight: .bold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.6)
                }
            }
            .frame(width: 54, height: 54)
            VStack(alignment: .leading, spacing: 3) {
                Text(g.subject)
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                Text(g.nextStep)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(g.statusColor)
                Text("\(g.control.title) · \(g.entries.count) \(g.entries.count == 1 ? "запись" : "записей")")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
        }
        .padding(14)
        .glass(22)
    }
}

/// Кольцо прогресса
struct ProgressRing<Inner: View>: View {
    let value: Double
    var color: Color = .brand
    var lineWidth: CGFloat = 6
    @ViewBuilder var label: () -> Inner

    var body: some View {
        ZStack {
            Circle().stroke(color.opacity(0.15), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: max(0.001, min(1, value)))
                .stroke(color, style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.spring(response: 0.6, dampingFraction: 0.8), value: value)
            label()
        }
    }
}

// MARK: - Предмет

struct BRSSubjectView: View {
    let id: UUID
    @ObservedObject private var store = GradesStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var adding = false
    @State private var newTitle = ""
    @State private var newPoints = ""
    @State private var newMax = ""
    @State private var newDate = Date()

    private var index: Int? { store.items.firstIndex { $0.id == id } }

    var body: some View {
        Group {
            if let i = index {
                form(i)
            } else {
                Text("Предмет удалён").foregroundStyle(.secondary)
            }
        }
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() }.fontWeight(.semibold) }
        }
    }

    private func form(_ i: Int) -> some View {
        let g = store.items[i]
        return Form {
            Section {
                HStack(spacing: 18) {
                    ProgressRing(value: g.ratio, color: g.statusColor, lineWidth: 9) {
                        VStack(spacing: 0) {
                            Text(BRSFormat.num(g.total)).font(.system(size: 26, weight: .heavy, design: .rounded))
                            Text("из \(BRSFormat.num(g.max))").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    .frame(width: 96, height: 96)
                    VStack(alignment: .leading, spacing: 6) {
                        Text(g.control == .credit ? "Прогноз: \(g.forecast)" : "Прогноз: «\(g.forecast)»")
                            .font(.system(.headline, design: .rounded))
                        Text(g.nextStep).font(.subheadline.weight(.semibold)).foregroundStyle(g.statusColor)
                        if g.total < g.auto {
                            Text("До автомата: \(BRSFormat.num(g.auto - g.total))").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.vertical, 6)
                thresholdsBar(g)
            }

            Section {
                ForEach(g.entries.sorted { $0.date > $1.date }) { e in
                    HStack {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(e.title)
                            HStack(spacing: 4) {
                                if !e.source.isEmpty {
                                    Label(e.source, systemImage: "arrow.down.circle.fill")
                                        .font(.caption2.weight(.bold))
                                        .foregroundStyle(Color.brand)
                                }
                                Text(e.date.formatted(.dateTime.day().month())).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        Text(e.outOf > 0 ? "\(BRSFormat.num(e.points))/\(BRSFormat.num(e.outOf))" : "+\(BRSFormat.num(e.points))")
                            .fontWeight(.bold).monospacedDigit()
                            .foregroundStyle(Color.brand)
                    }
                    .swipeActions {
                        Button(role: .destructive) {
                            store.items[i].entries.removeAll { $0.id == e.id }
                        } label: { Label("Удалить", systemImage: "trash") }
                    }
                }
                Button {
                    newTitle = ""; newPoints = ""; newMax = ""; newDate = Date(); adding = true
                } label: { Label("Добавить баллы", systemImage: "plus.circle.fill") }
                HStack(spacing: 8) {
                    ForEach(["Посещение", "Лаба", "Тест", "Доклад"], id: \.self) { t in
                        Button(t) { newTitle = t; newPoints = ""; newMax = ""; newDate = Date(); adding = true }
                            .buttonStyle(.bordered)
                            .font(.caption)
                    }
                }
            } header: {
                Text("Баллы")
            } footer: {
                Text("Смахни запись влево, чтобы удалить. Быстрые кнопки подставляют название.")
            }

            Section {
                Picker("Форма контроля", selection: $store.items[i].control) {
                    ForEach(ControlType.allCases) { Text($0.title).tag($0) }
                }
                Stepper("Максимум: \(BRSFormat.num(g.max))", value: $store.items[i].max, in: 10...200, step: 5)
                Stepper(g.control == .credit ? "Зачёт от \(BRSFormat.num(g.pass))" : "«3» от \(BRSFormat.num(g.pass))",
                        value: $store.items[i].pass, in: 0...g.max, step: 1)
                if g.control != .credit {
                    Stepper("«4» от \(BRSFormat.num(g.good))", value: $store.items[i].good, in: 0...g.max, step: 1)
                    Stepper("«5» от \(BRSFormat.num(g.excellent))", value: $store.items[i].excellent, in: 0...g.max, step: 1)
                }
                Stepper("Автомат от \(BRSFormat.num(g.auto))", value: $store.items[i].auto, in: 0...g.max, step: 1)
            } header: {
                Text("Пороги")
            } footer: {
                Text("Спроси у преподавателя его шкалу и поправь цифры — прогноз станет точным.")
            }

            Section {
                Picker("Итог", selection: $store.items[i].result) {
                    Text("Ещё не сдавал").tag("")
                    Text("Зачёт").tag("зачёт")
                    Text("5").tag("5")
                    Text("4").tag("4")
                    Text("3").tag("3")
                    Text("Пересдача").tag("пересдача")
                }
                .onChange(of: store.items[i].result) { r in
                    if !r.isEmpty && r != "пересдача" { Celebrations.examPassed(subject: g.subject, grade: r) }
                    GoldIcon.checkUnlock()
                }
                Button("Убрать предмет из БРС", role: .destructive) {
                    let sid = id
                    dismiss()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        store.items.removeAll { $0.id == sid }
                    }
                }
            } header: {
                Text("Сессия")
            }
        }
        .navigationTitle(g.subject)
        .navigationBarTitleDisplayMode(.inline)
        .alert("Баллы", isPresented: $adding) {
            TextField("За что (лаба 1, тест…)", text: $newTitle)
            TextField("Сколько баллов", text: $newPoints).keyboardType(.decimalPad)
            TextField("Из скольки (можно пусто)", text: $newMax).keyboardType(.decimalPad)
            Button("Добавить") {
                let p = Double(newPoints.replacingOccurrences(of: ",", with: ".")) ?? 0
                let m = Double(newMax.replacingOccurrences(of: ",", with: ".")) ?? 0
                if let j = index {
                    withAnimation {
                        store.items[j].entries.append(GradeEntry(title: newTitle.isEmpty ? "Работа" : newTitle,
                                                                 points: p, outOf: m, date: newDate))
                    }
                    Haptics.success()
                }
            }
            Button("Отмена", role: .cancel) {}
        }
    }

    /// Шкала с метками порогов
    private func thresholdsBar(_ g: SubjectGrades) -> some View {
        GeometryReader { geo in
            let w = geo.size.width
            let mx = Swift.max(g.max, 1)
            ZStack(alignment: .leading) {
                Capsule().fill(Color.primary.opacity(0.08)).frame(height: 8)
                Capsule().fill(g.statusColor.gradient)
                    .frame(width: Swift.max(8, w * CGFloat(g.ratio)), height: 8)
                ForEach(marks(g), id: \.0) { m in
                    VStack(spacing: 2) {
                        Rectangle().fill(Color.primary.opacity(0.5)).frame(width: 1.5, height: 14)
                        Text(m.0).font(.system(size: 9, weight: .bold)).foregroundStyle(.secondary).fixedSize()
                    }
                    .offset(x: w * CGFloat(m.1 / mx) - 1, y: 10)
                }
            }
        }
        .frame(height: 36)
        .padding(.bottom, 4)
    }

    private func marks(_ g: SubjectGrades) -> [(String, Double)] {
        if g.control == .credit { return [("зач", g.pass), ("авт", g.auto)] }
        return [("3", g.pass), ("4", g.good), ("5", g.excellent)]
    }
}


// MARK: - Отчёт синхронизации

struct SyncReportView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            Text(GradeSync.report)
                .font(.system(.caption, design: .monospaced))
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
        }
        .navigationTitle("Что нашлось")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                ShareLink(item: GradeSync.report) { Image(systemName: "square.and.arrow.up") }
            }
        }
        .safeAreaInset(edge: .bottom) {
            Text("Если баллы не подтянулись или встали не туда — отправь этот отчёт разработчику, он подстроит разбор под сайт.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(12)
                .frame(maxWidth: .infinity)
                .background(.ultraThinMaterial)
        }
    }
}
