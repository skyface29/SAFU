import UIKit
import SwiftUI

// MARK: - Защита данных при запуске сразу после перезагрузки телефона
// iOS может запустить приложение в фоне (обновление расписания, Live Activity, геопозиция) ещё ДО первой
// разблокировки после перезагрузки. В этот момент файлы и настройки приложения зашифрованы и не читаются.
// Раньше приложение видело «пустоту», считало себя только что установленным и записывало пустые настройки
// и расписание поверх настоящих — после перезагрузки приходилось регистрироваться заново.
// Теперь, пока данные недоступны, приложение ничего не читает и не пишет, а ждёт разблокировки.

enum LaunchGuard {
    /// Файл-метка с той же защитой, что у настроек: читается только после первой разблокировки
    private static var marker: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("unlock.marker")
    }

    /// Можно ли сейчас читать и писать данные приложения
    static func dataAvailable() -> Bool {
        let fm = FileManager.default
        let url = marker
        if !fm.fileExists(atPath: url.path) {
            try? fm.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try? Data("ok".utf8).write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            return true
        }
        return (try? Data(contentsOf: url)) != nil
    }
}

/// Хранилища приложения создаются только когда данные доступны
final class Boot: ObservableObject {
    struct Stores {
        let store: ResourceStore
        let tasks: TaskStore
        let schedule: ScheduleStore
        let attendance: AttendanceStore
    }

    @Published private(set) var stores: Stores?
    private var observers: [NSObjectProtocol] = []

    init() {
        if LaunchGuard.dataAvailable() {
            start()
        } else {
            // ждём первой разблокировки
            for name in [UIApplication.protectedDataDidBecomeAvailableNotification,
                         UIApplication.didBecomeActiveNotification,
                         UIApplication.willEnterForegroundNotification] {
                observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                    self?.startIfReady()
                })
            }
        }
    }

    func startIfReady() {
        guard stores == nil, LaunchGuard.dataAvailable() else { return }
        start()
    }

    private func start() {
        for o in observers { NotificationCenter.default.removeObserver(o) }
        observers = []
        RegistrationBackup.restoreIfNeeded()
        FirstLook.applyIfNew()
        ThemeChrome.apply()   // панели темы — до первого экрана
        stores = Stores(store: ResourceStore(), tasks: TaskStore(), schedule: ScheduleStore(), attendance: AttendanceStore())
    }
}

// MARK: - Запасная копия регистрации в связке ключей
// Переживает и сбой настроек, и переустановку приложения через AltStore/Sideloadly:
// группа, школа, ФИО и роль восстанавливаются сами, регистрироваться заново не нужно.

enum RegistrationBackup {
    private static let key = "registration.backup.v1"
    private static let keys = ["onboarded", "user.name", "user.first", "user.last", "user.middle", "group",
                               "user.kind", "teacher.query", "user.role", "commute.enabled",
                               "report.student", "report.school"]

    private struct Payload: Codable {
        var defaults: [String: String]
        var number: String
        var institution: Int
        var groupID: String
        var source: Int
    }

    /// Запомнить (вызывается, когда приложение открыто и регистрация пройдена)
    static func save(_ data: ScheduleData) {
        let d = UserDefaults.standard
        guard d.bool(forKey: "onboarded"), data.usesRuz || !data.lessons.isEmpty else { return }
        var values: [String: String] = [:]
        for k in keys {
            if let v = d.object(forKey: k) { values[k] = "\(v)" }
        }
        let p = Payload(defaults: values, number: data.ruzGroupNumber, institution: data.ruzInstitution,
                        groupID: data.ruzGroupID, source: data.source)
        guard let raw = try? JSONEncoder().encode(p) else { return }
        if Keychain.get(key) != raw { Keychain.set(raw, for: key) }
    }

    /// Настройки пропали, а копия есть — возвращаем регистрацию
    static func restoreIfNeeded() {
        let d = UserDefaults.standard
        let stored = SharedSchedule.load()
        guard !d.bool(forKey: "onboarded"), !(stored.usesRuz || !stored.lessons.isEmpty),
              let raw = Keychain.get(key), let p = try? JSONDecoder().decode(Payload.self, from: raw) else { return }
        for (k, v) in p.defaults {
            switch k {
            case "onboarded", "commute.enabled": d.set(v == "1" || v == "true", forKey: k)
            case "user.role": d.set(Int(v) ?? 0, forKey: k)
            default: d.set(v, forKey: k)
            }
        }
        d.set(true, forKey: "onboarded")
        // не считаем это первым запуском: оформление по умолчанию не навязываем
        d.set(true, forKey: "look.firstDefault")
        var s = stored
        s.source = p.source
        s.ruzGroupNumber = p.number
        s.ruzInstitution = p.institution
        s.ruzGroupID = p.groupID
        s.lastSync = nil
        SharedSchedule.save(s)
    }

    static func clear() { Keychain.delete(key) }
}
