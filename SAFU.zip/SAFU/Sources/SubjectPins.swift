import SwiftUI
import UniformTypeIdentifiers
import QuickLook

// MARK: - «Под рукой»: главные ссылки и файлы каждого предмета
// Курс в Sakai, методичка, таблица с оценками, чат группы — закрепляешь один раз,
// и они всегда в одно касание: на экране предмета и в карточке «Сейчас» на главной.

struct SubjectPin: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    /// Ссылка (https://…) или путь к файлу относительно папки предмета
    var value: String
    var isFile: Bool
}

final class SubjectPinStore: ObservableObject {
    static let shared = SubjectPinStore()
    private let key = "subject.pins.v1"
    @Published private(set) var all: [String: [SubjectPin]] = [:]

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let v = try? JSONDecoder().decode([String: [SubjectPin]].self, from: raw) {
            all = v
        }
    }

    private func k(_ subject: String) -> String { subject.lowercased() }

    func pins(_ subject: String) -> [SubjectPin] { all[k(subject)] ?? [] }

    func add(_ pin: SubjectPin, to subject: String) {
        all[k(subject), default: []].append(pin)
        save()
    }

    func remove(_ pin: SubjectPin, from subject: String) {
        all[k(subject)]?.removeAll { $0.id == pin.id }
        save()
    }

    func move(_ pin: SubjectPin, in subject: String, by delta: Int) {
        guard var list = all[k(subject)], let i = list.firstIndex(of: pin) else { return }
        let j = min(max(i + delta, 0), list.count - 1)
        guard i != j else { return }
        list.swapAt(i, j)
        all[k(subject)] = list
        save()
    }

    func rename(_ pin: SubjectPin, in subject: String, to title: String) {
        guard let i = all[k(subject)]?.firstIndex(where: { $0.id == pin.id }) else { return }
        all[k(subject)]?[i].title = title
        save()
    }

    /// Файл в папке предмета переименовали — закрепы этого файла идут за ним
    func fileRenamed(in subject: String, from old: String, to new: URL) {
        guard var list = all[k(subject)] else { return }
        let oldBase = (old as NSString).deletingPathExtension
        var changed = false
        for i in list.indices where list[i].isFile && list[i].value == old {
            list[i].value = new.lastPathComponent
            // своё название закрепа не трогаем, меняем только то, что было взято из имени файла
            if list[i].title == oldBase || SmartName.isJunk(list[i].title) {
                list[i].title = new.deletingPathExtension().lastPathComponent
            }
            changed = true
        }
        guard changed else { return }
        all[k(subject)] = list
        save()
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(all) { UserDefaults.standard.set(raw, forKey: key) }
    }

    /// Предметы, где уже переименовали файлы с «мусорными» именами (раз за запуск)
    private var tidied = Set<String>()

    /// Один раз за запуск: файлы предмета с именем-хешем получают понятное название
    @MainActor
    func tidyNames(_ subject: String) async {
        guard tidied.insert(k(subject)).inserted else { return }
        let s = subject
        let renamed: [(String, URL)] = await Task.detached(priority: .utility) {
            SubjectFiles.list(s).compactMap { u in
                let n = SmartName.fix(u, subject: s)
                return n == u ? nil : (u.lastPathComponent, n)
            }
        }.value
        for (old, new) in renamed { fileRenamed(in: subject, from: old, to: new) }
        // закрепы, у которых название — хеш, а файл уже с нормальным именем
        if var list = all[k(subject)] {
            var changed = false
            for i in list.indices where list[i].isFile && SmartName.isJunk(list[i].title) {
                let base = (list[i].value as NSString).deletingPathExtension
                if !SmartName.isJunk(base) { list[i].title = base; changed = true }
            }
            if changed { all[k(subject)] = list; save() }
        }
    }

    /// Файл закрепа (nil — файл удалили)
    static func fileURL(_ pin: SubjectPin, subject: String) -> URL? {
        let u = SubjectFolders.url(subject).appendingPathComponent(pin.value)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }
}

/// Одно окно на весь блок: в SwiftUI несколько окон на одном элементе конфликтуют,
/// и срабатывало только одно — из-за этого выбор файла не открывался
private enum PinSheet: Identifiable {
    case link(URL), file(URL), pickFromFolder, browseFolder, importFile
    var id: String {
        switch self {
        case .link(let u): return "link:" + u.absoluteString
        case .file(let u): return "file:" + u.path
        case .pickFromFolder: return "pick"
        case .browseFolder: return "browse"
        case .importFile: return "import"
        }
    }
}

/// Полоса закрепов предмета. editable — с кнопкой «+» и меню у каждого закрепа
struct SubjectPinsStrip: View {
    let subject: String
    var editable = false
    /// Кнопка «Файлы предмета»: всё из папки предмета (учебники, методички) в одно касание
    var showFolder = false
    /// Компактные кнопки в начале ряда (карточка пары на главной): фото доски и ДЗ
    var onPhoto: (() -> Void)? = nil
    var onHomework: (() -> Void)? = nil
    var homeworkCount = 0
    @State private var folderCount = 0
    @ObservedObject private var store = SubjectPinStore.shared
    @State private var sheet: PinSheet?
    @State private var addLink = false
    @State private var linkTitle = ""
    @State private var linkURL = "https://"
    @State private var missing = false
    @State private var renamingPin: SubjectPin?
    @State private var renamingFile: URL?
    @State private var newName = ""

    private var pins: [SubjectPin] { store.pins(subject) }

    var body: some View {
        Group {
            if !pins.isEmpty || editable || showFolder || onPhoto != nil || onHomework != nil {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        if let onHomework {
                            Button {
                                Haptics.tap()
                                onHomework()
                            } label: {
                                Label(homeworkCount > 0 ? "ДЗ · \(homeworkCount)" : "ДЗ", systemImage: "book.closed.fill")
                                    .font(.caption.weight(.bold))
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .foregroundStyle(.white)
                                    .background(brandGradient, in: Capsule())
                            }
                            .buttonStyle(PressableStyle())
                        }
                        if let onPhoto {
                            Button {
                                Haptics.tap()
                                onPhoto()
                            } label: {
                                Label("Доска", systemImage: "camera.fill")
                                    .font(.caption.weight(.semibold))
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(Color.brand.opacity(0.12), in: Capsule())
                            }
                            .buttonStyle(PressableStyle())
                        }
                        if showFolder && folderCount > 0 {
                            Button {
                                Haptics.tap()
                                sheet = .browseFolder
                            } label: {
                                Label("Файлы · \(folderCount)", systemImage: "folder.fill")
                                    .font(.caption.weight(.bold))
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .foregroundStyle(.white)
                                    .background(SubjectColor.color(for: subject).opacity(0.85), in: Capsule())
                            }
                            .buttonStyle(PressableStyle())
                        }
                        ForEach(pins) { p in chip(p) }
                        if editable { addMenu }
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .sheet(item: $sheet) { route in
            switch route {
            case .link(let u): SafariView(url: u).ignoresSafeArea()
            case .file(let u): FilePreviewSheet(url: u)
            case .pickFromFolder: folderPicker
            case .browseFolder: folderBrowser
            case .importFile:
                DocumentPicker { urls in
                    sheet = nil
                    urls.forEach { importAndPin($0) }
                }
                .ignoresSafeArea()
            }
        }
        .alert("Ссылка под рукой", isPresented: $addLink) {
            TextField("Название (курс в Sakai, методичка…)", text: $linkTitle)
            TextField("https://…", text: $linkURL)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Добавить") { saveLink() }
            Button("Отмена", role: .cancel) {}
        }
        .alert("Файл не найден", isPresented: $missing) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text("Похоже, файл удалили из папки предмета. Убери закреп и закрепи заново.")
        }
        .alert("Название", isPresented: Binding(get: { renamingPin != nil }, set: { if !$0 { renamingPin = nil } })) {
            TextField("Название", text: $newName)
            Button("Сохранить") { commitPinRename() }
            Button("Отмена", role: .cancel) { renamingPin = nil }
        } message: {
            Text(renamingPin?.isFile == true ? "Файл в папке предмета тоже переименуется" : "Как закреп будет подписан")
        }
        .task(id: subject) {
            await store.tidyNames(subject)
            guard showFolder else { return }
            // папку читаем в фоне — карточка пары на главной не должна ждать диск
            let s = subject
            folderCount = await Task.detached(priority: .utility) { SubjectFiles.list(s).count }.value
        }
    }

    private func chip(_ p: SubjectPin) -> some View {
        Button {
            Haptics.tap()
            open(p)
        } label: {
            HStack(spacing: 6) {
                if p.isFile, let u = SubjectPinStore.fileURL(p, subject: subject) {
                    // превью первой страницы — сразу видно, что это за файл
                    FileThumb(item: .of(u), size: 22)
                        .clipShape(RoundedRectangle(cornerRadius: 5, style: .continuous))
                } else {
                    Image(systemName: p.isFile ? icon(for: p.value) : "link")
                }
                Text(p.title).frame(maxWidth: 170, alignment: .leading)
            }
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .padding(.leading, p.isFile ? 6 : 12)
                .padding(.trailing, 12)
                .padding(.vertical, p.isFile ? 5 : 8)
                .background(SubjectColor.color(for: subject).opacity(0.16), in: Capsule())
                .foregroundStyle(.primary)
        }
        .buttonStyle(PressableStyle())
        .contextMenu {
            Button { newName = p.title; renamingPin = p } label: { Label("Переименовать", systemImage: "pencil") }
            Button { store.move(p, in: subject, by: -1) } label: { Label("Левее", systemImage: "arrow.left") }
            Button { store.move(p, in: subject, by: 1) } label: { Label("Правее", systemImage: "arrow.right") }
            Button(role: .destructive) { store.remove(p, from: subject) } label: { Label("Убрать", systemImage: "pin.slash") }
        }
    }

    private var addMenu: some View {
        Menu {
            Button { linkTitle = ""; linkURL = "https://"; addLink = true } label: { Label("Ссылка", systemImage: "link") }
            Button { sheet = .pickFromFolder } label: { Label("Файл из папки предмета", systemImage: "folder") }
            Button { sheet = .importFile } label: { Label("Файл с телефона", systemImage: "doc.badge.plus") }
        } label: {
            Label(pins.isEmpty ? (onPhoto != nil || onHomework != nil ? "Закрепить" : "Закрепить учебник, ссылку…") : "Добавить", systemImage: "plus")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.primary.opacity(0.07), in: Capsule())
        }
    }

    private func open(_ p: SubjectPin) {
        if p.isFile {
            if let u = SubjectPinStore.fileURL(p, subject: subject) {
                FileOpen.show(u) { sheet = .file($0) }
            } else { missing = true }
        } else if let u = URL(string: p.value), u.scheme == "https" || u.scheme == "http" {
            // ссылка — мини-приложением, как Sakai и почта
            if SiteTabs.canShowOnTop { QuickOpen.link(u) } else { sheet = .link(u) }
        }
    }

    private func saveLink() {
        var raw = linkURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if !raw.lowercased().hasPrefix("http") { raw = "https://" + raw }
        guard let u = URL(string: raw), u.host != nil else { return }
        let title = linkTitle.trimmingCharacters(in: .whitespaces)
        store.add(SubjectPin(title: title.isEmpty ? (u.host ?? "Ссылка") : title, value: raw, isFile: false), to: subject)
        Haptics.success()
    }

    /// Файлы в папке предмета (без вложенных папок)
    private var folderFiles: [URL] { SubjectFiles.list(subject) }

    private var folderPicker: some View {
        NavigationStack {
            List {
                if folderFiles.isEmpty {
                    Text("В папке предмета пока нет файлов. Добавь файл с телефона.").foregroundStyle(.secondary)
                }
                ForEach(folderFiles, id: \.self) { u in
                    Button {
                        store.add(SubjectPin(title: u.deletingPathExtension().lastPathComponent, value: u.lastPathComponent, isFile: true),
                                  to: subject)
                        Haptics.success()
                        sheet = nil
                    } label: {
                        fileRow(u)
                    }
                }
            }
            .navigationTitle("Закрепить файл")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { sheet = nil } } }
        }
    }

    /// Все файлы предмета: нажал — открылся; закрепить — одним свайпом
    private var folderBrowser: some View {
        NavigationStack {
            let files = folderFiles
            List {
                if !files.isEmpty {
                    Section {
                        ForEach(files, id: \.self) { u in browserRow(u) }
                    } footer: {
                        let bytes = files.reduce(Int64(0)) { $0 + FileItem.of($1).size }
                        Text("\(files.count) \(filesWord(files.count)) · \(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)) на телефоне. Удержи файл — переименовать, закрепить, поделиться.")
                    }
                }
                if files.isEmpty {
                    Text("Файлов нет. Добавь кнопкой «+».").foregroundStyle(.secondary)
                }
            }
            .alert("Название файла", isPresented: Binding(get: { renamingFile != nil }, set: { if !$0 { renamingFile = nil } })) {
                TextField("Название", text: $newName)
                Button("Сохранить") { commitFileRename() }
                Button("Отмена", role: .cancel) { renamingFile = nil }
            }
            .navigationTitle(subject)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Готово") { sheet = nil } }
                ToolbarItem(placement: .primaryAction) {
                    Button { sheet = nil; DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { sheet = .importFile } } label: {
                        Image(systemName: "plus")
                    }
                }
            }
        }
    }

    /// Строка файла: превью первой страницы, название, размер и дата
    private func fileRow(_ u: URL) -> some View {
        let item = FileItem.of(u)
        return HStack(spacing: 12) {
            FileThumb(item: item, size: 44)
            VStack(alignment: .leading, spacing: 2) {
                Text(u.deletingPathExtension().lastPathComponent)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text("\(u.pathExtension.uppercased()) · \(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file)) · \(item.modified.formatted(.dateTime.day().month(.abbreviated)))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
            if pins.contains(where: { $0.isFile && $0.value == u.lastPathComponent }) {
                Image(systemName: "pin.fill").font(.caption).foregroundStyle(.orange)
            }
        }
    }

    private func browserRow(_ u: URL) -> some View {
        Button {
            sheet = nil
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { FileOpen.show(u) { sheet = .file($0) } }
        } label: {
            fileRow(u)
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(role: .destructive) { deleteFile(u) } label: { Label("Удалить", systemImage: "trash") }
            Button { pinFile(u) } label: { Label("Закрепить", systemImage: "pin.fill") }
                .tint(.orange)
        }
        .contextMenu {
            Button { newName = u.deletingPathExtension().lastPathComponent; renamingFile = u } label: {
                Label("Переименовать", systemImage: "pencil")
            }
            Button { pinFile(u) } label: { Label("Закрепить", systemImage: "pin.fill") }
            ShareLink(item: u) { Label("Поделиться", systemImage: "square.and.arrow.up") }
            Button(role: .destructive) { deleteFile(u) } label: { Label("Удалить", systemImage: "trash") }
        } preview: {
            FileThumb(item: .of(u), size: 280)
        }
    }

    private func filesWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "файл" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "файла" }
        return "файлов"
    }

    /// Переименовать файл в папке предмета; закрепы идут за ним
    @discardableResult
    private func renameFile(_ u: URL, to title: String) -> URL? {
        let clean = FileService.sanitize(title)
        guard !clean.isEmpty, clean != u.deletingPathExtension().lastPathComponent else { return nil }
        let ext = u.pathExtension
        let dest = FileService.uniqueURL(in: u.deletingLastPathComponent(), name: ext.isEmpty ? clean : "\(clean).\(ext)")
        guard (try? FileManager.default.moveItem(at: u, to: dest)) != nil else { return nil }
        store.fileRenamed(in: subject, from: u.lastPathComponent, to: dest)
        Haptics.success()
        return dest
    }

    private func commitFileRename() {
        if let u = renamingFile { renameFile(u, to: newName) }
        renamingFile = nil
    }

    private func commitPinRename() {
        guard let p = renamingPin else { return }
        renamingPin = nil
        let title = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty else { return }
        if p.isFile, let u = SubjectPinStore.fileURL(p, subject: subject) {
            // имя файла меняется вместе с закрепом, чтобы в «Файлах» было то же название
            if renameFile(u, to: title) != nil {
                if let fresh = store.pins(subject).first(where: { $0.id == p.id }), fresh.title != title {
                    store.rename(fresh, in: subject, to: title)
                }
                return
            }
        }
        store.rename(p, in: subject, to: title)
        Haptics.success()
    }

    private func pinFile(_ u: URL) {
        store.add(SubjectPin(title: u.deletingPathExtension().lastPathComponent, value: u.lastPathComponent, isFile: true),
                  to: subject)
        Haptics.success()
    }

    /// Удаляет файл из папки предмета вместе с его закрепами
    private func deleteFile(_ u: URL) {
        guard (try? FileManager.default.removeItem(at: u)) != nil else { return }
        for p in pins where p.isFile && p.value == u.lastPathComponent { store.remove(p, from: subject) }
        folderCount = folderFiles.count
        Haptics.tap()
    }

    /// Копирует файл в папку предмета и закрепляет его
    private func importAndPin(_ src: URL) {
        let access = src.startAccessingSecurityScopedResource()
        defer { if access { src.stopAccessingSecurityScopedResource() } }
        let dir = SubjectFolders.url(subject)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var dest = dir.appendingPathComponent(src.lastPathComponent)
        var n = 2
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = dir.appendingPathComponent("\(src.deletingPathExtension().lastPathComponent) \(n).\(src.pathExtension)")
            n += 1
        }
        guard (try? FileManager.default.copyItem(at: src, to: dest)) != nil else { return }
        // имя-хеш из Sakai или мессенджера → понятное название по содержимому
        dest = SmartName.fix(dest, subject: subject)
        folderCount = folderFiles.count
        store.add(SubjectPin(title: dest.deletingPathExtension().lastPathComponent, value: dest.lastPathComponent, isFile: true),
                  to: subject)
        Haptics.success()
    }

    private func icon(for name: String) -> String {
        switch (name as NSString).pathExtension.lowercased() {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled"
        case "jpg", "jpeg", "png", "heic": return "photo.fill"
        default: return "doc.fill"
        }
    }
}

// MARK: - Просмотр файла
// Свой QuickLook в обычном окне: системный .quickLookPreview не открывался,
// когда на экране (или у родителя) уже было другое окно.
struct FilePreviewSheet: View {
    let url: URL
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            QuickLookController(url: url)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle(url.deletingPathExtension().lastPathComponent)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
                    ToolbarItem(placement: .primaryAction) { ShareLink(item: url) { Image(systemName: "square.and.arrow.up") } }
                    // свернуть файл в плашку над вкладками — вернуться к нему можно в любой момент
                    ToolbarItem(placement: .cancellationAction) {
                        Button {
                            SiteTabs.shared.addMinimized(file: url)
                            dismiss()
                        } label: { Image(systemName: "chevron.down") }
                        .accessibilityLabel("Свернуть")
                    }
                }
        }
    }
}

struct QuickLookController: UIViewControllerRepresentable {
    let url: URL

    func makeCoordinator() -> Coordinator { Coordinator(url: url) }

    func makeUIViewController(context: Context) -> QLPreviewController {
        let c = QLPreviewController()
        c.dataSource = context.coordinator
        return c
    }

    func updateUIViewController(_ c: QLPreviewController, context: Context) {
        if context.coordinator.url != url {
            context.coordinator.url = url
            c.reloadData()
        }
    }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        var url: URL
        init(url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
}

extension View {
    /// Замена .quickLookPreview: окно вешается на отдельный фоновый элемент,
    /// поэтому не спорит с другими окнами этого экрана
    /// Файл открывается карточкой поверх приложения, как сайт: его можно свернуть и вернуться.
    /// Если поверх уже открыто другое окно — показываем в окне (там есть кнопка «свернуть»)
    func filePreview(_ url: Binding<URL?>) -> some View {
        modifier(FilePreviewRouter(url: url))
    }
}

private struct FilePreviewRouter: ViewModifier {
    @Binding var url: URL?
    @State private var sheetURL: URL?

    func body(content: Content) -> some View {
        content
            .background(
                Color.clear.sheet(isPresented: Binding(get: { sheetURL != nil },
                                                       set: { if !$0 { sheetURL = nil } })) {
                    if let u = sheetURL { FilePreviewSheet(url: u) }
                }
            )
            .onChange(of: url) { u in
                guard let u else { return }
                url = nil
                FileOpen.show(u) { sheetURL = $0 }
            }
    }
}

enum FileOpen {
    /// Карточкой поверх приложения, а если поверх висит окно — через fallback (обычный просмотр)
    static func show(_ u: URL, fallback: (URL) -> Void) {
        if SiteTabs.canShowOnTop {
            SiteTabs.shared.openFile(u)
        } else {
            fallback(u)
        }
    }
}

/// Файлы из папки предмета — отдельно от экрана, чтобы читать папку в фоне
enum SubjectFiles {
    static func list(_ subject: String) -> [URL] {
        let dir = SubjectFolders.url(subject)
        let items = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles])) ?? []
        // фото доски не показываем — у них свой раздел по парам
        return items.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) != true && !LessonPhotos.isBoardPhoto($0) }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
    }
}
