import SwiftUI
import UniformTypeIdentifiers

// MARK: - «Под рукой»: главные ссылки и файлы каждого предмета
// Курс в Sakai, методичка, таблица с оценками, чат группы — закрепляешь один раз,
// и они всегда в одно касание: на экране предмета и в карточке «Сейчас» на главной.

struct SubjectPin: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    /// Ссылка (https://…) или путь к файлу относительно папки предмета
    var value: String
    var isFile: Bool
}

final class SubjectPinStore: ObservableObject {
    static let shared = SubjectPinStore()
    private let key = "subject.pins.v1"
    @Published private(set) var all: [String: [SubjectPin]] = [:]

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let v = try? JSONDecoder().decode([String: [SubjectPin]].self, from: raw) {
            all = v
        }
    }

    private func k(_ subject: String) -> String { subject.lowercased() }

    func pins(_ subject: String) -> [SubjectPin] { all[k(subject)] ?? [] }

    func add(_ pin: SubjectPin, to subject: String) {
        all[k(subject), default: []].append(pin)
        save()
    }

    func remove(_ pin: SubjectPin, from subject: String) {
        all[k(subject)]?.removeAll { $0.id == pin.id }
        save()
    }

    func move(_ pin: SubjectPin, in subject: String, by delta: Int) {
        guard var list = all[k(subject)], let i = list.firstIndex(of: pin) else { return }
        let j = min(max(i + delta, 0), list.count - 1)
        guard i != j else { return }
        list.swapAt(i, j)
        all[k(subject)] = list
        save()
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(all) { UserDefaults.standard.set(raw, forKey: key) }
    }

    /// Файл закрепа (nil — файл удалили)
    static func fileURL(_ pin: SubjectPin, subject: String) -> URL? {
        let u = SubjectFolders.url(subject).appendingPathComponent(pin.value)
        return FileManager.default.fileExists(atPath: u.path) ? u : nil
    }
}

private struct PinLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Полоса закрепов предмета. editable — с кнопкой «+» и меню у каждого закрепа
struct SubjectPinsStrip: View {
    let subject: String
    var editable = false
    @ObservedObject private var store = SubjectPinStore.shared
    @State private var link: PinLink?
    @State private var preview: URL?
    @State private var addLink = false
    @State private var linkTitle = ""
    @State private var linkURL = "https://"
    @State private var pickFromFolder = false
    @State private var importFile = false
    @State private var missing = false

    private var pins: [SubjectPin] { store.pins(subject) }

    var body: some View {
        Group {
            if !pins.isEmpty || editable {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(pins) { p in chip(p) }
                        if editable { addMenu }
                    }
                    .padding(.vertical, 2)
                }
            }
        }
        .sheet(item: $link) { l in SafariView(url: l.url).ignoresSafeArea() }
        .quickLookPreview($preview)
        .alert("Ссылка под рукой", isPresented: $addLink) {
            TextField("Название (курс в Sakai, методичка…)", text: $linkTitle)
            TextField("https://…", text: $linkURL)
                .keyboardType(.URL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("Добавить") { saveLink() }
            Button("Отмена", role: .cancel) {}
        }
        .alert("Файл не найден", isPresented: $missing) {
            Button("Ок", role: .cancel) {}
        } message: {
            Text("Похоже, файл удалили из папки предмета. Убери закреп и закрепи заново.")
        }
        .sheet(isPresented: $pickFromFolder) { folderPicker }
        .fileImporter(isPresented: $importFile, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
            guard case .success(let urls) = result, let src = urls.first else { return }
            importAndPin(src)
        }
    }

    private func chip(_ p: SubjectPin) -> some View {
        Button {
            Haptics.tap()
            open(p)
        } label: {
            Label(p.title, systemImage: p.isFile ? icon(for: p.value) : "link")
                .font(.caption.weight(.semibold))
                .lineLimit(1)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(SubjectColor.color(for: subject).opacity(0.16), in: Capsule())
                .foregroundStyle(.primary)
        }
        .buttonStyle(PressableStyle())
        .contextMenu {
            Button { store.move(p, in: subject, by: -1) } label: { Label("Левее", systemImage: "arrow.left") }
            Button { store.move(p, in: subject, by: 1) } label: { Label("Правее", systemImage: "arrow.right") }
            Button(role: .destructive) { store.remove(p, from: subject) } label: { Label("Убрать", systemImage: "pin.slash") }
        }
    }

    private var addMenu: some View {
        Menu {
            Button { linkTitle = ""; linkURL = "https://"; addLink = true } label: { Label("Ссылка", systemImage: "link") }
            Button { pickFromFolder = true } label: { Label("Файл из папки предмета", systemImage: "folder") }
            Button { importFile = true } label: { Label("Файл с телефона", systemImage: "doc.badge.plus") }
        } label: {
            Label(pins.isEmpty ? "Закрепить ссылку или файл" : "Добавить", systemImage: "plus")
                .font(.caption.weight(.semibold))
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.primary.opacity(0.07), in: Capsule())
        }
    }

    private func open(_ p: SubjectPin) {
        if p.isFile {
            if let u = SubjectPinStore.fileURL(p, subject: subject) { preview = u } else { missing = true }
        } else if let u = URL(string: p.value), u.scheme == "https" || u.scheme == "http" {
            link = PinLink(url: u)
        }
    }

    private func saveLink() {
        var raw = linkURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if !raw.lowercased().hasPrefix("http") { raw = "https://" + raw }
        guard let u = URL(string: raw), u.host != nil else { return }
        let title = linkTitle.trimmingCharacters(in: .whitespaces)
        store.add(SubjectPin(title: title.isEmpty ? (u.host ?? "Ссылка") : title, value: raw, isFile: false), to: subject)
        Haptics.success()
    }

    /// Файлы в папке предмета (без вложенных папок)
    private var folderFiles: [URL] {
        let dir = SubjectFolders.url(subject)
        let items = (try? FileManager.default.contentsOfDirectory(at: dir, includingPropertiesForKeys: [.isDirectoryKey],
                                                                  options: [.skipsHiddenFiles])) ?? []
        return items.filter { (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) != true }
            .sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
    }

    private var folderPicker: some View {
        NavigationStack {
            List {
                if folderFiles.isEmpty {
                    Text("В папке предмета пока нет файлов. Добавь файл с телефона.").foregroundStyle(.secondary)
                }
                ForEach(folderFiles, id: \.self) { u in
                    Button {
                        store.add(SubjectPin(title: u.deletingPathExtension().lastPathComponent, value: u.lastPathComponent, isFile: true),
                                  to: subject)
                        Haptics.success()
                        pickFromFolder = false
                    } label: {
                        Label(u.lastPathComponent, systemImage: icon(for: u.lastPathComponent))
                    }
                }
            }
            .navigationTitle("Закрепить файл")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Отмена") { pickFromFolder = false } } }
        }
    }

    /// Копирует файл в папку предмета и закрепляет его
    private func importAndPin(_ src: URL) {
        let access = src.startAccessingSecurityScopedResource()
        defer { if access { src.stopAccessingSecurityScopedResource() } }
        let dir = SubjectFolders.url(subject)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        var dest = dir.appendingPathComponent(src.lastPathComponent)
        var n = 2
        while FileManager.default.fileExists(atPath: dest.path) {
            dest = dir.appendingPathComponent("\(src.deletingPathExtension().lastPathComponent) \(n).\(src.pathExtension)")
            n += 1
        }
        guard (try? FileManager.default.copyItem(at: src, to: dest)) != nil else { return }
        store.add(SubjectPin(title: dest.deletingPathExtension().lastPathComponent, value: dest.lastPathComponent, isFile: true),
                  to: subject)
        Haptics.success()
    }

    private func icon(for name: String) -> String {
        switch (name as NSString).pathExtension.lowercased() {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled"
        case "jpg", "jpeg", "png", "heic": return "photo.fill"
        default: return "doc.fill"
        }
    }
}
