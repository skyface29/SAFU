import SwiftUI
import UIKit
import AVFoundation
import UniformTypeIdentifiers

// MARK: - Лекции: запись → расшифровка → конспект
// 1. Запись идёт и при заблокированном экране; «⭐ Важно» отмечает моменты, которые подчеркнул преподаватель.
// 2. Речь распознаёт Whisper прямо на телефоне (см. LectureASR).
// 3. Конспект пишет Claude (нужен свой ключ API) — или простой конспект без ИИ, если ключа нет.
// Всё сохраняется: запись в «Файлы › Лекции», текст и конспект — в приложении. Конспект можно переписать.

struct LectureSummary: Codable, Hashable {
    struct Section: Codable, Hashable {
        var heading: String
        var points: [String]
    }
    struct Term: Codable, Hashable {
        var term: String
        var definition: String
    }
    var title: String
    var summary: String
    var keyPoints: [String]
    var sections: [Section]
    var terms: [Term]
    var formulas: [String]
    var questions: [String]
    var tasks: [String]

    /// Конспект текстом (для редактирования и «поделиться»)
    var markdown: String {
        var s = "# \(title)\n\n\(summary)\n"
        if !keyPoints.isEmpty { s += "\n## Главное\n" + keyPoints.map { "- \($0)" }.joined(separator: "\n") + "\n" }
        for sec in sections {
            s += "\n## \(sec.heading)\n" + sec.points.map { "- \($0)" }.joined(separator: "\n") + "\n"
        }
        if !terms.isEmpty { s += "\n## Термины\n" + terms.map { "- **\($0.term)** — \($0.definition)" }.joined(separator: "\n") + "\n" }
        if !formulas.isEmpty { s += "\n## Формулы\n" + formulas.map { "- \($0)" }.joined(separator: "\n") + "\n" }
        if !questions.isEmpty { s += "\n## Могут спросить\n" + questions.map { "- \($0)" }.joined(separator: "\n") + "\n" }
        if !tasks.isEmpty { s += "\n## Задания и сроки\n" + tasks.map { "- \($0)" }.joined(separator: "\n") + "\n" }
        return s
    }
}

struct Lecture: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String
    var subject: String
    var date: Date
    var duration: Double
    var audioName: String
    var marks: [Double] = []
    var segments: [SpeechSegment] = []
    var summary: LectureSummary?
    var summaryByAI = false
    /// Конспект, переписанный руками (если есть — показывается вместо автоматического)
    var editedNotes: String?

    var audioURL: URL { LectureStore.folder.appendingPathComponent(audioName) }
    var transcript: String { segments.map(\.text).joined(separator: " ") }
    var hasNotes: Bool { summary != nil || !(editedNotes ?? "").isEmpty }

    init(title: String, subject: String, date: Date, duration: Double, audioName: String, marks: [Double]) {
        self.title = title; self.subject = subject; self.date = date
        self.duration = duration; self.audioName = audioName; self.marks = marks
    }

    private enum K: String, CodingKey {
        case id, title, subject, date, duration, audioName, marks, segments, summary, summaryByAI, editedNotes
    }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? "Лекция"
        subject = try c.decodeIfPresent(String.self, forKey: .subject) ?? ""
        date = try c.decodeIfPresent(Date.self, forKey: .date) ?? Date()
        duration = try c.decodeIfPresent(Double.self, forKey: .duration) ?? 0
        audioName = try c.decodeIfPresent(String.self, forKey: .audioName) ?? ""
        marks = try c.decodeIfPresent([Double].self, forKey: .marks) ?? []
        segments = try c.decodeIfPresent([SpeechSegment].self, forKey: .segments) ?? []
        summary = try c.decodeIfPresent(LectureSummary.self, forKey: .summary)
        summaryByAI = try c.decodeIfPresent(Bool.self, forKey: .summaryByAI) ?? false
        editedNotes = try c.decodeIfPresent(String.self, forKey: .editedNotes)
    }
}

// MARK: - Хранилище

final class LectureStore: ObservableObject {
    static let shared = LectureStore()
    @Published var lectures: [Lecture] = [] { didSet { save() } }

    /// Записи лежат в «Файлы › Лекции» — их видно и в файлах приложения
    static var folder: URL {
        let u = FileService.root.appendingPathComponent("Лекции", isDirectory: true)
        try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true)
        return u
    }

    private static var fileURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("lectures.json")
    }

    init() {
        if let raw = try? Data(contentsOf: Self.fileURL),
           let list = try? JSONDecoder().decode([Lecture].self, from: raw) {
            lectures = list
        }
    }

    private func save() {
        let list = lectures
        DispatchQueue.global(qos: .utility).async {
            if let raw = try? JSONEncoder().encode(list) { try? raw.write(to: Self.fileURL, options: .atomic) }
        }
    }

    func lecture(_ id: UUID) -> Lecture? { lectures.first { $0.id == id } }

    func update(_ id: UUID, _ change: (inout Lecture) -> Void) {
        guard let i = lectures.firstIndex(where: { $0.id == id }) else { return }
        change(&lectures[i])
    }

    func add(_ l: Lecture) { lectures.insert(l, at: 0) }

    func delete(_ id: UUID) {
        if let l = lecture(id) { try? FileManager.default.removeItem(at: l.audioURL) }
        lectures.removeAll { $0.id == id }
    }
}

// MARK: - Ключ Claude API (хранится в связке ключей iPhone)

enum ClaudeKey {
    private static let key = "claude.apiKey"
    static var value: String? {
        guard let d = Keychain.get(key), let s = String(data: d, encoding: .utf8), !s.isEmpty else { return nil }
        return s
    }
    static func set(_ s: String) {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { Keychain.delete(key) } else { Keychain.set(Data(t.utf8), for: key) }
    }
}

// MARK: - Конспект

enum LectureStyle: String, CaseIterable, Identifiable {
    case normal, short, detailed
    var id: String { rawValue }
    var title: String {
        switch self {
        case .normal: return "Обычный"
        case .short: return "Шпаргалка"
        case .detailed: return "Подробный"
        }
    }
    var instruction: String {
        switch self {
        case .normal: return "Сделай сбалансированный конспект: суть, структура, главное."
        case .short: return "Сделай очень сжатую шпаргалку: только самое главное, коротко, без воды."
        case .detailed: return "Сделай подробный конспект: сохрани все важные мысли, примеры и пояснения по разделам."
        }
    }
}

enum LectureSummarizer {
    enum Failure: LocalizedError {
        case http(Int, String)
        case refused
        case tooLong
        case badAnswer
        var errorDescription: String? {
            switch self {
            case .http(let code, let msg): return "Claude API ответил \(code): \(msg)"
            case .refused: return "Claude отказался делать конспект по этой записи"
            case .tooLong: return "Конспект не поместился — попробуй стиль «Шпаргалка»"
            case .badAnswer: return "Не удалось разобрать ответ Claude"
            }
        }
    }

    private static func mmss(_ t: Double) -> String {
        let s = Int(t)
        return String(format: "%d:%02d", s / 60, s % 60)
    }

    /// Расшифровка для модели: метки времени и [ВАЖНО] рядом с отметками студента
    static func transcriptForAI(_ l: Lecture) -> String {
        var out = ""
        var nextStamp = 0.0
        for seg in l.segments {
            if seg.start >= nextStamp {
                out += "\n[\(mmss(seg.start))] "
                nextStamp = seg.start + 120
            }
            let important = l.marks.contains { m in seg.end >= m - 5 && seg.start <= m + 40 }
            out += (important ? "[ВАЖНО] " : "") + seg.text + " "
        }
        return out.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static var schema: [String: Any] {
        let str: [String: Any] = ["type": "string"]
        let strs: [String: Any] = ["type": "array", "items": str]
        return [
            "type": "object",
            "additionalProperties": false,
            "required": ["title", "summary", "keyPoints", "sections", "terms", "formulas", "questions", "tasks"],
            "properties": [
                "title": str,
                "summary": str,
                "keyPoints": strs,
                "sections": ["type": "array", "items": [
                    "type": "object", "additionalProperties": false, "required": ["heading", "points"],
                    "properties": ["heading": str, "points": strs],
                ] as [String: Any]] as [String: Any],
                "terms": ["type": "array", "items": [
                    "type": "object", "additionalProperties": false, "required": ["term", "definition"],
                    "properties": ["term": str, "definition": str],
                ] as [String: Any]] as [String: Any],
                "formulas": strs,
                "questions": strs,
                "tasks": strs,
            ] as [String: Any],
        ]
    }

    /// Конспект от Claude (claude-opus-5). Запрос через Messages API, ответ — строго по JSON-схеме.
    static func claude(_ l: Lecture, style: LectureStyle, apiKey: String) async throws -> LectureSummary {
        let system = """
        Ты делаешь конспект университетской лекции для студента САФУ по автоматической расшифровке речи.
        В расшифровке бывают ошибки распознавания — по смыслу исправляй искажённые термины, фамилии и формулы.
        Фрагменты с пометкой [ВАЖНО] студент отметил во время лекции: их обязательно отрази в конспекте.
        Ничего не выдумывай: только то, что было в лекции. Пиши по-русски, ясно и по делу.
        Поля: title — тема лекции; summary — 3–5 предложений о чём лекция; keyPoints — главные мысли;
        sections — разделы лекции с пунктами; terms — определения; formulas — формулы в текстовом виде;
        questions — что вероятно спросят на зачёте/экзамене; tasks — задания, сроки, что подготовить (если звучали).
        Пустые списки — нормально, если такого в лекции не было.
        """
        let user = """
        Предмет: \(l.subject.isEmpty ? "не указан" : l.subject)
        Длительность: \(Int(l.duration / 60)) мин
        \(style.instruction)

        <расшифровка>
        \(transcriptForAI(l))
        </расшифровка>
        """
        let body: [String: Any] = [
            "model": "claude-opus-5",
            "max_tokens": 16000,
            "fallbacks": "default",
            "system": system,
            "messages": [["role": "user", "content": user]],
            "output_config": ["format": ["type": "json_schema", "schema": schema] as [String: Any]] as [String: Any],
        ]
        guard let url = URL(string: "https://api.anthropic.com/v1/messages") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 600
        req.setValue("application/json", forHTTPHeaderField: "content-type")
        req.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        req.setValue("server-side-fallback-2026-07-01", forHTTPHeaderField: "anthropic-beta")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard code == 200, let obj else {
            let msg = ((obj?["error"] as? [String: Any])?["message"] as? String) ?? String(data: data, encoding: .utf8) ?? ""
            throw Failure.http(code, String(msg.prefix(200)))
        }
        // сначала смотрим, чем закончился ответ, и только потом читаем содержимое
        switch obj["stop_reason"] as? String {
        case "refusal": throw Failure.refused
        case "max_tokens": throw Failure.tooLong
        default: break
        }
        let blocks = (obj["content"] as? [[String: Any]]) ?? []
        let text = blocks.filter { ($0["type"] as? String) == "text" }.compactMap { $0["text"] as? String }.joined()
        guard let json = text.data(using: .utf8),
              let s = try? JSONDecoder().decode(LectureSummary.self, from: json) else { throw Failure.badAnswer }
        return s
    }

    // MARK: конспект без ИИ

    private static let stop: Set<String> = ["это", "как", "что", "так", "вот", "для", "при", "его", "она", "они", "мы", "вы",
                                            "или", "если", "то", "там", "тут", "уже", "еще", "ещё", "был", "была", "было",
                                            "будет", "есть", "нет", "все", "всё", "тоже", "также", "когда", "где", "чтобы",
                                            "потому", "можно", "нужно", "очень", "этот", "эта", "эти", "этого", "того",
                                            "который", "которая", "которые", "только", "просто", "значит", "вообще", "ну"]

    private static func words(_ s: String) -> [String] {
        s.lowercased().components(separatedBy: CharacterSet.letters.inverted).filter { $0.count > 3 && !stop.contains($0) }
    }

    /// Простой конспект прямо на телефоне: ключевые фразы, определения, задания
    static func local(_ l: Lecture) -> LectureSummary {
        let text = l.transcript
        let sentences = text.components(separatedBy: CharacterSet(charactersIn: ".!?…"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { $0.split(separator: " ").count >= 6 }
        var freq: [String: Int] = [:]
        for w in words(text) { freq[w, default: 0] += 1 }
        let top = freq.sorted { $0.value > $1.value }.prefix(12).map(\.key)
        let scored = sentences.enumerated().map { (i, s) -> (Int, String, Double) in
            let ws = words(s)
            let score = ws.reduce(0.0) { $0 + Double(freq[$1] ?? 0) } / Double(max(8, ws.count))
            return (i, s, score)
        }
        let best = scored.sorted { $0.2 > $1.2 }.prefix(8).sorted { $0.0 < $1.0 }.map(\.1)
        // отмеченные «важно» — отдельно
        let marked = l.segments.filter { seg in l.marks.contains { seg.end >= $0 - 5 && seg.start <= $0 + 40 } }.map(\.text)
        let terms = sentences.compactMap { s -> LectureSummary.Term? in
            for sep in [" — это ", " - это ", " это ", " называется ", " называют "] {
                if let r = s.range(of: sep), s.distance(from: s.startIndex, to: r.lowerBound) < 40 {
                    let term = String(s[..<r.lowerBound]).trimmingCharacters(in: .whitespaces)
                    let def = String(s[r.upperBound...]).trimmingCharacters(in: .whitespaces)
                    if term.split(separator: " ").count <= 4 && def.count > 10 {
                        return LectureSummary.Term(term: term.capitalizedFirst, definition: def)
                    }
                }
            }
            return nil
        }
        let taskWords = ["домашн", "задани", "сдать", "к следующ", "дедлайн", "срок", "подготов", "контрольн", "лабораторн"]
        let tasks = sentences.filter { s in taskWords.contains { s.lowercased().contains($0) } }.prefix(6).map { $0 }
        return LectureSummary(
            title: l.subject.isEmpty ? l.title : l.subject,
            summary: best.prefix(2).joined(separator: ". ") + (best.isEmpty ? "" : "."),
            keyPoints: Array(best),
            sections: marked.isEmpty ? [] : [LectureSummary.Section(heading: "Отмечено как важное", points: Array(marked.prefix(10)))],
            terms: Array(terms.prefix(10)),
            formulas: [],
            questions: [],
            tasks: Array(tasks)
        )
        .with(keywords: top)
    }
}

private extension LectureSummary {
    /// Ключевые слова — отдельным разделом в простом конспекте
    func with(keywords: [String]) -> LectureSummary {
        var s = self
        if !keywords.isEmpty { s.sections.append(Section(heading: "Ключевые слова", points: [keywords.joined(separator: ", ")])) }
        return s
    }
}

// MARK: - Обработка в фоне

@MainActor
final class LectureProcessor: ObservableObject {
    static let shared = LectureProcessor()

    enum Status: Equatable {
        case transcribing(Date)
        case summarizing
        case failed(String)
    }

    @Published private(set) var status: [UUID: Status] = [:]

    private func setBusy() {
        UIApplication.shared.isIdleTimerDisabled = status.values.contains {
            if case .failed = $0 { return false }
            return true
        }
    }

    /// Полный путь: расшифровка → конспект
    func process(_ id: UUID) {
        guard let l = LectureStore.shared.lecture(id) else { return }
        if case .transcribing = status[id] { return }
        status[id] = .transcribing(Date())
        setBusy()
        let url = l.audioURL
        let model = LectureASR.selected
        Task {
            do {
                let segs = try await LectureASR.transcribe(url: url, model: model)
                LectureStore.shared.update(id) { $0.segments = segs }
                status[id] = nil
                setBusy()
                summarize(id, style: .normal)
            } catch {
                status[id] = .failed("Не удалось распознать: \(error.localizedDescription)")
                setBusy()
            }
        }
    }

    func summarize(_ id: UUID, style: LectureStyle) {
        guard let l = LectureStore.shared.lecture(id), !l.segments.isEmpty else { return }
        status[id] = .summarizing
        setBusy()
        Task {
            if let key = ClaudeKey.value {
                do {
                    let s = try await LectureSummarizer.claude(l, style: style, apiKey: key)
                    LectureStore.shared.update(id) {
                        $0.summary = s
                        $0.summaryByAI = true
                        if $0.title.hasPrefix("Лекция") { $0.title = s.title }
                    }
                    status[id] = nil
                } catch {
                    // без сети или без денег на ключе — хотя бы простой конспект
                    let s = LectureSummarizer.local(l)
                    LectureStore.shared.update(id) {
                        if $0.summary == nil { $0.summary = s; $0.summaryByAI = false }
                    }
                    status[id] = .failed(error.localizedDescription)
                }
            } else {
                let s = LectureSummarizer.local(l)
                LectureStore.shared.update(id) { $0.summary = s; $0.summaryByAI = false }
                status[id] = nil
            }
            setBusy()
            Haptics.success()
        }
    }

    func clearError(_ id: UUID) {
        if case .failed = status[id] { status[id] = nil }
    }
}

// MARK: - Запись

final class LectureRecorder: NSObject, ObservableObject, AVAudioRecorderDelegate {
    @Published var elapsed: Double = 0
    @Published var levels: [Float] = Array(repeating: 0, count: 48)
    @Published var recording = false
    @Published var paused = false
    @Published var marks: [Double] = []
    @Published var denied = false

    private var recorder: AVAudioRecorder?
    private var timer: Timer?
    private var fileName = ""

    func start() {
        AVAudioApplication.requestRecordPermission { granted in
            DispatchQueue.main.async {
                if granted { self.begin() } else { self.denied = true }
            }
        }
    }

    private func begin() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetooth])
        try? session.setActive(true)
        let f = Fmt.formatter("dd.MM.yyyy HH-mm")
        fileName = "Лекция \(f.string(from: Date())).m4a"
        let url = LectureStore.folder.appendingPathComponent(fileName)
        let settings: [String: Any] = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 16_000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue,
        ]
        guard let r = try? AVAudioRecorder(url: url, settings: settings) else { return }
        r.isMeteringEnabled = true
        r.delegate = self
        r.record()
        recorder = r
        recording = true
        paused = false
        timer = Timer.scheduledTimer(withTimeInterval: 0.08, repeats: true) { [weak self] _ in self?.tick() }
    }

    private func tick() {
        guard let r = recorder else { return }
        elapsed = r.currentTime
        guard !paused else { return }
        r.updateMeters()
        let db = r.averagePower(forChannel: 0)
        let level = max(0, min(1, (db + 55) / 55))
        levels.removeFirst()
        levels.append(level)
    }

    func togglePause() {
        guard let r = recorder else { return }
        if paused { r.record() } else { r.pause() }
        paused.toggle()
        Haptics.tap()
    }

    func markImportant() {
        marks.append(elapsed)
        Haptics.success()
    }

    /// Остановить и сохранить. nil — запись пустая
    func stop(subject: String) -> Lecture? {
        guard let r = recorder else { return nil }
        let duration = r.currentTime
        r.stop()
        timer?.invalidate()
        timer = nil
        recorder = nil
        recording = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        guard duration > 3 else {
            try? FileManager.default.removeItem(at: LectureStore.folder.appendingPathComponent(fileName))
            return nil
        }
        let title = subject.isEmpty ? "Лекция \(Fmt.formatter("d MMMM").string(from: Date()))" : subject
        return Lecture(title: title, subject: subject, date: Date(), duration: duration, audioName: fileName, marks: marks)
    }

    func cancel() {
        recorder?.stop()
        timer?.invalidate()
        if !fileName.isEmpty { try? FileManager.default.removeItem(at: LectureStore.folder.appendingPathComponent(fileName)) }
        recorder = nil
        recording = false
    }
}

// MARK: - Проигрыватель

final class LecturePlayer: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var playing = false
    @Published var time: Double = 0
    @Published var duration: Double = 0
    @Published var rate: Float = 1

    private var player: AVAudioPlayer?
    private var timer: Timer?

    func load(_ url: URL) {
        player = try? AVAudioPlayer(contentsOf: url)
        player?.enableRate = true
        player?.delegate = self
        duration = player?.duration ?? 0
    }

    func toggle() {
        guard let p = player else { return }
        if p.isPlaying {
            p.pause()
            playing = false
            timer?.invalidate()
        } else {
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .spokenAudio)
            try? AVAudioSession.sharedInstance().setActive(true)
            p.rate = rate
            p.play()
            playing = true
            timer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
                self?.time = self?.player?.currentTime ?? 0
            }
        }
    }

    func seek(_ t: Double) {
        player?.currentTime = t
        time = t
    }

    func cycleRate() {
        rate = rate >= 2 ? 1 : (rate >= 1.5 ? 2 : 1.5)
        player?.rate = rate
    }

    func stop() {
        player?.stop()
        timer?.invalidate()
        playing = false
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        playing = false
        timer?.invalidate()
    }
}

// MARK: - Экран «Лекции»

struct LecturesView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = LectureStore.shared
    @ObservedObject private var processor = LectureProcessor.shared
    @State private var recording = false
    @State private var open: Lecture?
    @State private var settings = false
    @State private var importing = false

    private var currentSubject: String {
        let r = ScheduleEngine.nowAndNext(at: Date(), data: schedule.data)
        return r.current?.lesson.subject ?? ""
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                recordCard
                if ClaudeKey.value == nil {
                    Button { settings = true } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "sparkles").foregroundStyle(brandGradient)
                            Text("Добавь ключ Claude — конспекты станут умными")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.primary)
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                        }
                        .padding(12)
                        .glass(16)
                    }
                    .buttonStyle(PressableStyle())
                }
                if store.lectures.isEmpty {
                    EmptyState(icon: "waveform.and.mic", title: "Пока нет лекций",
                               text: "Нажми «Записать» на паре. Можно заблокировать экран — запись продолжится.")
                        .padding(.top, 20)
                }
                ForEach(store.lectures) { l in
                    Button {
                        Haptics.tap()
                        open = l
                    } label: {
                        LectureRow(lecture: l, status: processor.status[l.id])
                    }
                    .buttonStyle(PressableStyle())
                    .contextMenu {
                        Button(role: .destructive) {
                            withAnimation { store.delete(l.id) }
                        } label: { Label("Удалить", systemImage: "trash") }
                    }
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Лекции")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Menu {
                    Button { importing = true } label: { Label("Загрузить запись", systemImage: "square.and.arrow.down") }
                    Button { settings = true } label: { Label("Настройки", systemImage: "gearshape") }
                } label: { Image(systemName: "ellipsis.circle") }
            }
        }
        .fullScreenCover(isPresented: $recording) {
            RecorderScreen(subject: currentSubject)
        }
        .sheet(item: $open) { l in
            NavigationStack { LectureDetailView(id: l.id) }
        }
        .sheet(isPresented: $settings) {
            NavigationStack { LectureSettingsView() }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.audio, .mpeg4Audio, .mp3, .wav]) { result in
            guard case .success(let src) = result else { return }
            let ok = src.startAccessingSecurityScopedResource()
            defer { if ok { src.stopAccessingSecurityScopedResource() } }
            let dst = FileService.uniqueURL(in: LectureStore.folder, name: src.lastPathComponent)
            guard (try? FileManager.default.copyItem(at: src, to: dst)) != nil else { return }
            let dur = (try? AVAudioPlayer(contentsOf: dst))?.duration ?? 0
            let l = Lecture(title: src.deletingPathExtension().lastPathComponent, subject: currentSubject,
                            date: Date(), duration: dur, audioName: dst.lastPathComponent, marks: [])
            store.add(l)
            processor.process(l.id)
        }
    }

    private var recordCard: some View {
        Button {
            Haptics.success()
            recording = true
        } label: {
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(Color.red.gradient)
                    Image(systemName: "mic.fill").font(.system(size: 22, weight: .bold)).foregroundStyle(.white)
                }
                .frame(width: 58, height: 58)
                .shadow(color: .red.opacity(0.4), radius: 10, y: 4)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Записать лекцию").font(.system(.title3, design: .rounded).weight(.bold)).foregroundStyle(.primary)
                    Text(currentSubject.isEmpty ? "Потом будет текст и конспект" : "Сейчас: \(currentSubject)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer()
            }
            .padding(16)
            .glass(24)
        }
        .buttonStyle(PressableStyle())
    }
}

private struct LectureRow: View {
    let lecture: Lecture
    let status: LectureProcessor.Status?

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(lecture.title)
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                Spacer()
                Text(Fmt.relative(lecture.date)).font(.caption2).foregroundStyle(.tertiary)
            }
            HStack(spacing: 8) {
                if !lecture.subject.isEmpty && lecture.subject != lecture.title {
                    Text(lecture.subject).font(.caption2.weight(.semibold)).foregroundStyle(Color.brand).lineLimit(1)
                }
                Text("\(Int(lecture.duration / 60)) мин").font(.caption2).foregroundStyle(.secondary)
                if !lecture.marks.isEmpty {
                    Text("⭐ \(lecture.marks.count)").font(.caption2).foregroundStyle(.secondary)
                }
                Spacer()
                badge
            }
            if let s = lecture.summary, status == nil {
                Text(s.summary).font(.caption).foregroundStyle(.secondary).lineLimit(2).multilineTextAlignment(.leading)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(18)
    }

    @ViewBuilder private var badge: some View {
        switch status {
        case .transcribing(let since):
            HStack(spacing: 5) {
                ProgressView().controlSize(.mini)
                Text("Распознаю · \(Int(Date().timeIntervalSince(since) / 60)) мин").font(.caption2.weight(.semibold))
            }
            .foregroundStyle(Color.brand)
        case .summarizing:
            HStack(spacing: 5) {
                ProgressView().controlSize(.mini)
                Text("Пишу конспект").font(.caption2.weight(.semibold))
            }
            .foregroundStyle(Color.brand)
        case .failed:
            Label("Ошибка", systemImage: "exclamationmark.triangle.fill").font(.caption2.weight(.semibold)).foregroundStyle(.orange)
        case nil:
            if lecture.hasNotes {
                Label(lecture.summaryByAI ? "Конспект ✨" : "Конспект", systemImage: "doc.text.fill")
                    .font(.caption2.weight(.semibold)).foregroundStyle(.green)
            } else if lecture.segments.isEmpty {
                Text("Не распознана").font(.caption2).foregroundStyle(.secondary)
            }
        }
    }
}

// MARK: - Запись: экран

struct RecorderScreen: View {
    @State var subject: String
    @Environment(\.dismiss) private var dismiss
    @StateObject private var rec = LectureRecorder()
    @State private var confirmCancel = false

    private func time(_ t: Double) -> String {
        let s = Int(t)
        return s >= 3600 ? String(format: "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60) : String(format: "%02d:%02d", s / 60, s % 60)
    }

    var body: some View {
        VStack(spacing: 24) {
            HStack {
                Button("Отмена") { confirmCancel = true }
                Spacer()
            }
            .padding(.horizontal, 20)

            TextField("Предмет", text: $subject)
                .font(.system(.title3, design: .rounded).weight(.bold))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)

            Spacer()

            Text(time(rec.elapsed))
                .font(.system(size: 64, weight: .heavy, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(rec.paused ? AnyShapeStyle(Color.secondary) : AnyShapeStyle(Color.primary))

            // живая волна
            HStack(alignment: .center, spacing: 3) {
                ForEach(Array(rec.levels.enumerated()), id: \.offset) { _, v in
                    Capsule()
                        .fill(rec.paused ? AnyShapeStyle(Color.secondary.opacity(0.4)) : AnyShapeStyle(Color.red.gradient))
                        .frame(width: 4, height: CGFloat(6 + Double(v) * 90))
                }
            }
            .frame(height: 100)
            .animation(.linear(duration: 0.08), value: rec.levels)

            Text(rec.paused ? "Пауза" : (rec.recording ? "Идёт запись · можно заблокировать экран" : "Готовлю микрофон…"))
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            if rec.denied {
                Text("Нет доступа к микрофону: Настройки → САФУ → Микрофон")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }

            Spacer()

            Button {
                rec.markImportant()
            } label: {
                Text(rec.marks.isEmpty ? "⭐ Важно" : "⭐ Важно · \(rec.marks.count)")
                    .font(.headline)
                    .padding(.horizontal, 22)
                    .padding(.vertical, 12)
                    .background(Color.yellow.opacity(0.25), in: Capsule())
            }
            .buttonStyle(PressableStyle())
            .disabled(!rec.recording)

            HStack(spacing: 40) {
                Button { rec.togglePause() } label: {
                    Image(systemName: rec.paused ? "play.fill" : "pause.fill")
                        .font(.system(size: 26, weight: .bold))
                        .frame(width: 70, height: 70)
                        .background(Color.primary.opacity(0.08), in: Circle())
                }
                .disabled(!rec.recording)
                Button {
                    if let l = rec.stop(subject: subject.trimmingCharacters(in: .whitespaces)) {
                        LectureStore.shared.add(l)
                        LectureProcessor.shared.process(l.id)
                    }
                    Haptics.success()
                    dismiss()
                } label: {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(Color.red)
                        .frame(width: 34, height: 34)
                        .frame(width: 88, height: 88)
                        .background(Circle().strokeBorder(Color.red.opacity(0.4), lineWidth: 5))
                }
                .disabled(!rec.recording)
            }
            .buttonStyle(PressableStyle())
            .padding(.bottom, 30)
        }
        .padding(.top, 20)
        .background(AmbientBackground())
        .onAppear { rec.start() }
        .confirmationDialog("Удалить запись?", isPresented: $confirmCancel, titleVisibility: .visible) {
            Button("Удалить запись", role: .destructive) {
                rec.cancel()
                dismiss()
            }
            Button("Продолжить запись", role: .cancel) {}
        }
        .interactiveDismissDisabled()
    }
}

// MARK: - Лекция: конспект, текст, аудио

struct LectureDetailView: View {
    let id: UUID
    @ObservedObject private var store = LectureStore.shared
    @ObservedObject private var processor = LectureProcessor.shared
    @StateObject private var player = LecturePlayer()
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @State private var editing = false
    @State private var draft = ""
    @State private var query = ""
    @State private var toast: String?

    private var lecture: Lecture? { store.lecture(id) }

    var body: some View {
        Group {
            if let l = lecture {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        header(l)
                        Picker("", selection: $tab) {
                            Text("Конспект").tag(0)
                            Text("Текст").tag(1)
                            Text("Аудио").tag(2)
                        }
                        .pickerStyle(.segmented)
                        switch tab {
                        case 0: notes(l)
                        case 1: transcript(l)
                        default: audio(l)
                        }
                    }
                    .padding(20)
                }
            } else {
                Text("Лекция удалена").foregroundStyle(.secondary)
            }
        }
        .background(AmbientBackground())
        .navigationTitle("Лекция")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() }.fontWeight(.semibold) }
        }
        .sheet(isPresented: $editing) {
            NavigationStack {
                TextEditor(text: $draft)
                    .font(.body)
                    .padding(.horizontal, 12)
                    .navigationTitle("Переписать конспект")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Отмена") { editing = false } }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Сохранить") {
                                store.update(id) { $0.editedNotes = draft }
                                editing = false
                                show("Конспект сохранён")
                            }
                            .fontWeight(.semibold)
                        }
                    }
            }
        }
        .overlay(alignment: .bottom) {
            if let toast {
                Text(toast)
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .glass(18)
                    .padding(.bottom, 30)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onAppear { if let l = lecture { player.load(l.audioURL) } }
        .onDisappear { player.stop() }
    }

    private func show(_ t: String) {
        Haptics.success()
        withAnimation { toast = t }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { withAnimation { toast = nil } }
    }

    private func header(_ l: Lecture) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(l.title).font(.system(.title2, design: .rounded).weight(.heavy))
            HStack(spacing: 8) {
                if !l.subject.isEmpty { Text(l.subject).foregroundStyle(Color.brand) }
                Text(Fmt.formatter("d MMMM, H:mm").string(from: l.date))
                Text("· \(Int(l.duration / 60)) мин")
            }
            .font(.caption.weight(.semibold))
            .foregroundStyle(.secondary)
            statusLine(l)
        }
    }

    @ViewBuilder private func statusLine(_ l: Lecture) -> some View {
        switch processor.status[id] {
        case .transcribing:
            Label("Распознаю речь на телефоне… Не закрывай приложение — обычно это 1/4–1/2 длины записи.",
                  systemImage: "waveform").font(.caption).foregroundStyle(Color.brand)
        case .summarizing:
            Label(ClaudeKey.value == nil ? "Собираю конспект…" : "Claude пишет конспект…", systemImage: "sparkles")
                .font(.caption).foregroundStyle(Color.brand)
        case .failed(let msg):
            VStack(alignment: .leading, spacing: 6) {
                Text(msg).font(.caption).foregroundStyle(.orange)
                Button("Попробовать ещё раз") {
                    processor.clearError(id)
                    if l.segments.isEmpty { processor.process(id) } else { processor.summarize(id, style: .normal) }
                }
                .font(.caption.weight(.bold))
            }
        case nil:
            if l.segments.isEmpty {
                Button {
                    processor.process(id)
                } label: {
                    Label("Распознать запись", systemImage: "waveform.badge.magnifyingglass").font(.caption.weight(.bold))
                }
            }
        }
    }

    // MARK: конспект

    @ViewBuilder private func notes(_ l: Lecture) -> some View {
        if let edited = l.editedNotes, !edited.isEmpty {
            MarkdownLite(text: edited)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .glass(20)
            Text("Твоя версия конспекта").font(.caption).foregroundStyle(.secondary)
        } else if let s = l.summary {
            SummaryView(summary: s, byAI: l.summaryByAI)
        } else if l.segments.isEmpty {
            Text("Конспект появится, когда запись распознается.").font(.subheadline).foregroundStyle(.secondary)
        }
        if l.hasNotes {
            let text = l.editedNotes?.isEmpty == false ? (l.editedNotes ?? "") : (l.summary?.markdown ?? "")
            VStack(spacing: 10) {
                HStack(spacing: 10) {
                    action("pencil", "Переписать") {
                        draft = text
                        editing = true
                    }
                    action("note.text.badge.plus", "В заметки") {
                        NotesStore.shared.upsert(Note(title: l.title, text: text, subject: l.subject))
                        show("Добавлено в заметки")
                    }
                    ShareLink(item: text) {
                        actionLabel("square.and.arrow.up", "Поделиться")
                    }
                }
                Menu {
                    ForEach(LectureStyle.allCases) { st in
                        Button(st.title) {
                            store.update(id) { $0.editedNotes = nil }
                            processor.summarize(id, style: st)
                        }
                    }
                } label: {
                    Label(ClaudeKey.value == nil ? "Собрать конспект заново" : "Claude, перепиши конспект…", systemImage: "arrow.triangle.2.circlepath")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .disabled(l.segments.isEmpty)
            }
        }
    }

    private func actionLabel(_ icon: String, _ title: String) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 17, weight: .semibold))
            Text(title).font(.caption2.weight(.semibold))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .foregroundStyle(Color.brand)
        .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func action(_ icon: String, _ title: String, _ run: @escaping () -> Void) -> some View {
        Button(action: run) { actionLabel(icon, title) }.buttonStyle(PressableStyle())
    }

    // MARK: текст

    @ViewBuilder private func transcript(_ l: Lecture) -> some View {
        if l.segments.isEmpty {
            Text("Текста пока нет.").font(.subheadline).foregroundStyle(.secondary)
        } else {
            TextField("Найти в тексте", text: $query)
                .textFieldStyle(.roundedBorder)
            let q = query.trimmingCharacters(in: .whitespaces).lowercased()
            let segs = q.isEmpty ? l.segments : l.segments.filter { $0.text.lowercased().contains(q) }
            LazyVStack(alignment: .leading, spacing: 10) {
                ForEach(Array(segs.enumerated()), id: \.offset) { _, seg in
                    HStack(alignment: .firstTextBaseline, spacing: 10) {
                        Button {
                            tab = 2
                            player.seek(seg.start)
                            if !player.playing { player.toggle() }
                        } label: {
                            Text(stamp(seg.start)).font(.caption.monospacedDigit().weight(.bold)).foregroundStyle(Color.brand)
                        }
                        let important = l.marks.contains { seg.end >= $0 - 5 && seg.start <= $0 + 40 }
                        Text((important ? "⭐ " : "") + seg.text)
                            .font(.subheadline)
                            .textSelection(.enabled)
                    }
                }
            }
            .padding(16)
            .glass(20)
            ShareLink(item: l.transcript) {
                Label("Поделиться всем текстом", systemImage: "square.and.arrow.up").font(.subheadline.weight(.semibold))
            }
        }
    }

    private func stamp(_ t: Double) -> String {
        let s = Int(t)
        return String(format: "%d:%02d", s / 60, s % 60)
    }

    // MARK: аудио

    private func audio(_ l: Lecture) -> some View {
        VStack(spacing: 16) {
            Slider(value: Binding(get: { player.time }, set: { player.seek($0) }), in: 0...max(1, player.duration))
            HStack {
                Text(stamp(player.time)).monospacedDigit()
                Spacer()
                Text(stamp(player.duration)).monospacedDigit()
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            HStack(spacing: 30) {
                Button { player.seek(max(0, player.time - 15)) } label: { Image(systemName: "gobackward.15").font(.title2) }
                Button { player.toggle() } label: {
                    Image(systemName: player.playing ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 56))
                }
                Button { player.seek(min(player.duration, player.time + 15)) } label: { Image(systemName: "goforward.15").font(.title2) }
                Button { player.cycleRate() } label: {
                    Text(String(format: "%.1f×", player.rate)).font(.subheadline.weight(.bold)).monospacedDigit()
                }
            }
            .foregroundStyle(Color.brand)
            if !l.marks.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Отмечено важным").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(l.marks, id: \.self) { m in
                                Button("⭐ \(stamp(m))") {
                                    player.seek(max(0, m - 10))
                                    if !player.playing { player.toggle() }
                                }
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.yellow.opacity(0.2), in: Capsule())
                            }
                        }
                    }
                }
            }
        }
        .padding(16)
        .glass(20)
    }
}

/// Красивый автоматический конспект
struct SummaryView: View {
    let summary: LectureSummary
    let byAI: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Label(byAI ? "Конспект · Claude" : "Конспект без ИИ", systemImage: byAI ? "sparkles" : "doc.text")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.brand)
                    Spacer()
                }
                Text(summary.title).font(.system(.title3, design: .rounded).weight(.bold))
                Text(summary.summary).font(.subheadline).foregroundStyle(.secondary)
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glass(20)

            block("Главное", "star.fill", summary.keyPoints)
            ForEach(summary.sections, id: \.self) { sec in
                block(sec.heading, "list.bullet", sec.points)
            }
            if !summary.terms.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    Label("Термины", systemImage: "character.book.closed.fill").font(.headline)
                    ForEach(summary.terms, id: \.self) { t in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(t.term).font(.subheadline.weight(.bold)).foregroundStyle(Color.brand)
                            Text(t.definition).font(.subheadline)
                        }
                    }
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .glass(20)
            }
            if !summary.formulas.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    Label("Формулы", systemImage: "function").font(.headline)
                    ForEach(summary.formulas, id: \.self) { f in
                        Text(f)
                            .font(.system(.subheadline, design: .monospaced))
                            .padding(10)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                            .textSelection(.enabled)
                    }
                }
                .padding(16)
                .glass(20)
            }
            block("Могут спросить", "questionmark.bubble.fill", summary.questions)
            block("Задания и сроки", "checklist", summary.tasks)
        }
    }

    @ViewBuilder private func block(_ title: String, _ icon: String, _ items: [String]) -> some View {
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Label(title, systemImage: icon).font(.headline)
                ForEach(items, id: \.self) { i in
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Circle().fill(Color.brand).frame(width: 5, height: 5)
                        Text(i).font(.subheadline).textSelection(.enabled)
                    }
                }
            }
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glass(20)
        }
    }
}

/// Простой показ своего конспекта: # заголовки, - пункты, **жирный**
struct MarkdownLite: View {
    let text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Array(text.components(separatedBy: "\n").enumerated()), id: \.offset) { _, raw in
                let line = raw.trimmingCharacters(in: .whitespaces)
                if line.isEmpty {
                    Spacer().frame(height: 4)
                } else if line.hasPrefix("# ") {
                    Text(inline(String(line.dropFirst(2)))).font(.system(.title3, design: .rounded).weight(.bold))
                } else if line.hasPrefix("## ") {
                    Text(inline(String(line.dropFirst(3)))).font(.headline).padding(.top, 6)
                } else if line.hasPrefix("- ") || line.hasPrefix("• ") {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Circle().fill(Color.brand).frame(width: 5, height: 5)
                        Text(inline(String(line.dropFirst(2)))).font(.subheadline)
                    }
                } else {
                    Text(inline(line)).font(.subheadline)
                }
            }
        }
        .textSelection(.enabled)
    }

    private func inline(_ s: String) -> AttributedString {
        (try? AttributedString(markdown: s)) ?? AttributedString(s)
    }
}

// MARK: - Настройки

struct LectureSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("lecture.model") private var model = LectureASR.models[0].id
    @State private var key = ClaudeKey.value ?? ""

    var body: some View {
        Form {
            Section {
                Picker("Распознавание", selection: $model) {
                    ForEach(LectureASR.models) { m in Text(m.title).tag(m.id) }
                }
                .pickerStyle(.segmented)
                Text(LectureASR.models.first { $0.id == model }?.note ?? "").font(.caption).foregroundStyle(.secondary)
            } header: {
                Text("Речь → текст")
            } footer: {
                Text("Whisper работает прямо на телефоне. Модель скачивается один раз при первой лекции — лучше по Wi-Fi. Запись никуда не отправляется.")
            }
            Section {
                SecureField("sk-ant-…", text: $key)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            } header: {
                Text("Ключ Claude API")
            } footer: {
                Text("С ключом конспект пишет Claude (claude-opus-5): структура, термины, формулы, вопросы к экзамену. Для этого расшифровка (только текст) отправляется в Anthropic. Лекция на 1,5 часа стоит примерно 20–30 центов. Без ключа приложение соберёт простой конспект само. Ключ хранится в связке ключей iPhone.")
            }
        }
        .navigationTitle("Лекции")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Готово") {
                    ClaudeKey.set(key)
                    dismiss()
                }
                .fontWeight(.semibold)
            }
        }
    }
}
