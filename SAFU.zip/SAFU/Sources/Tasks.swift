import SwiftUI
import UserNotifications

// MARK: - Модель

struct StudyTask: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var subject: String
    var due: Date
    var note: String
    var done: Bool = false
    var remind: Bool = true

    static func blank() -> StudyTask {
        let tomorrow = Date().addingTimeInterval(86_400)
        let due = Calendar.current.date(bySettingHour: 23, minute: 59, second: 0, of: tomorrow) ?? tomorrow
        return StudyTask(title: "", subject: "", due: due, note: "")
    }
}

struct TaskGroup: Identifiable {
    let title: String
    let items: [StudyTask]
    var id: String { title }
}

final class TaskStore: ObservableObject {
    private let key = "tasks.v1"

    @Published var tasks: [StudyTask] { didSet { save() } }

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([StudyTask].self, from: data) {
            tasks = decoded
        } else {
            tasks = []
        }
    }

    var active: [StudyTask] {
        tasks.filter { !$0.done }.sorted { $0.due < $1.due }
    }

    var nextOpen: StudyTask? { active.first }

    func contains(_ t: StudyTask) -> Bool {
        tasks.contains { $0.id == t.id }
    }

    func groups() -> [TaskGroup] {
        let now = Date()
        let cal = Calendar.current
        let weekAhead = now.addingTimeInterval(7 * 86_400)
        let list = active
        let overdue = list.filter { $0.due < now }
        let today = list.filter { $0.due >= now && cal.isDateInToday($0.due) }
        let week = list.filter { $0.due >= now && !cal.isDateInToday($0.due) && $0.due < weekAhead }
        let later = list.filter { $0.due >= weekAhead }
        let done = tasks.filter { $0.done }.sorted { $0.due > $1.due }
        return [
            TaskGroup(title: "Просрочено", items: overdue),
            TaskGroup(title: "Сегодня", items: today),
            TaskGroup(title: "На неделе", items: week),
            TaskGroup(title: "Позже", items: later),
            TaskGroup(title: "Выполнено", items: done)
        ].filter { !$0.items.isEmpty }
    }

    func upsert(_ t: StudyTask) {
        if let i = tasks.firstIndex(where: { $0.id == t.id }) {
            tasks[i] = t
        } else {
            tasks.append(t)
        }
        if t.remind { Notifier.requestAuthorization() }
        Notifier.schedule(t)
    }

    func toggle(_ t: StudyTask) {
        guard let i = tasks.firstIndex(where: { $0.id == t.id }) else { return }
        tasks[i].done.toggle()
        if tasks[i].done {
            Haptics.success()
            let left = tasks.filter { !$0.done }.count
            Celebrations.taskDone(title: tasks[i].title, left: left)
        } else { Haptics.tap() }
        Notifier.schedule(tasks[i])
    }

    func delete(_ t: StudyTask) {
        Notifier.cancel(t)
        tasks.removeAll { $0.id == t.id }
    }

    func clearDone() {
        tasks.removeAll { $0.done }
    }

    private func save() {
        if let data = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}

// MARK: - Напоминания

enum Notifier {
    static func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    static func cancel(_ t: StudyTask) {
        let ids = ["\(t.id.uuidString)-0", "\(t.id.uuidString)-1"]
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ids)
    }

    static func schedule(_ t: StudyTask) {
        cancel(t)
        guard t.remind, !t.done else { return }
        let plan: [(TimeInterval, String)] = [(86_400, "Завтра дедлайн"), (3_600, "Через час дедлайн")]
        for (index, item) in plan.enumerated() {
            let fire = t.due.addingTimeInterval(-item.0)
            guard fire > Date() else { continue }
            let content = UNMutableNotificationContent()
            content.title = item.1
            content.body = t.subject.isEmpty ? t.title : "\(t.subject): \(t.title)"
            content.sound = .default
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
            let request = UNNotificationRequest(identifier: "\(t.id.uuidString)-\(index)",
                                                content: content, trigger: trigger)
            UNUserNotificationCenter.current().add(request)
        }
    }
}

// MARK: - Экран

struct TasksView: View {
    @EnvironmentObject private var tasks: TaskStore
    @State private var editing: StudyTask?
    @State private var sakaiLoading = false
    @State private var sakaiMessage: String?

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 26) {
                    ScreenHeader(caption: "Дедлайны и дела", title: "Задачи") {
                        HStack(spacing: 10) {
                            Button {
                                sakaiLoading = true
                                Task {
                                    let msg = await SakaiSync.importInto(tasks)
                                    sakaiLoading = false
                                    sakaiMessage = msg
                                }
                            } label: {
                                ZStack {
                                    CircleIconButton(icon: "graduationcap")
                                    if sakaiLoading { ProgressView() }
                                }
                            }
                            .buttonStyle(PressableStyle())
                            .disabled(sakaiLoading)
                            Button { editing = StudyTask.blank() } label: {
                                CircleIconButton(icon: "plus")
                            }
                            .buttonStyle(PressableStyle())
                        }
                    }

                    if tasks.tasks.isEmpty {
                        EmptyState(icon: "checklist",
                                   title: "Задач пока нет",
                                   text: "Добавь лабу, отчёт или зачёт. Или нажми 🎓 — задания со сроками подтянутся из Sakai. Напомню за день и за час.")
                    }

                    ForEach(tasks.groups()) { group in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                SectionTitle(text: group.title)
                                Spacer()
                                if group.title == "Выполнено" {
                                    Button("Очистить") {
                                        withAnimation { tasks.clearDone() }
                                    }
                                    .font(.subheadline.weight(.semibold))
                                }
                            }
                            ForEach(group.items) { t in
                                TaskRow(task: t,
                                        onToggle: { withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { tasks.toggle(t) } },
                                        onEdit: { editing = t })
                                    .contextMenu {
                                        Button { editing = t } label: { Label("Изменить", systemImage: "pencil") }
                                        Button(role: .destructive) {
                                            withAnimation { tasks.delete(t) }
                                        } label: { Label("Удалить", systemImage: "trash") }
                                    }
                                    .transition(.asymmetric(insertion: .scale(scale: 0.95).combined(with: .opacity),
                                                            removal: .opacity))
                            }
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
                .animation(.spring(response: 0.4, dampingFraction: 0.85), value: tasks.tasks)
            }
        }
        .alert("Sakai", isPresented: Binding(get: { sakaiMessage != nil }, set: { if !$0 { sakaiMessage = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(sakaiMessage ?? "")
        }
        .sheet(item: $editing) { t in
            TaskEditor(task: t,
                       isNew: !tasks.contains(t),
                       onSave: { tasks.upsert($0) },
                       onDelete: { tasks.delete(t) })
        }
    }
}

struct TaskRow: View {
    let task: StudyTask
    let onToggle: () -> Void
    let onEdit: () -> Void

    private var overdue: Bool { !task.done && task.due < Date() }

    var body: some View {
        HStack(spacing: 14) {
            Button(action: onToggle) {
                ZStack {
                    Circle()
                        .strokeBorder(task.done ? Color.brand : Color.secondary.opacity(0.5), lineWidth: 2)
                        .frame(width: 26, height: 26)
                    if task.done {
                        Circle()
                            .fill(brandGradient)
                            .frame(width: 26, height: 26)
                            .transition(.scale)
                        Image(systemName: "checkmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(.white)
                            .transition(.scale)
                    }
                }
                .frame(width: 32, height: 32)
                .contentShape(Circle())
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 3) {
                Text(task.title)
                    .font(.body.weight(.semibold))
                    .strikethrough(task.done)
                    .foregroundStyle(task.done ? Color.secondary : Color.primary)
                    .lineLimit(2)
                HStack(spacing: 6) {
                    if !task.subject.isEmpty {
                        Text(task.subject)
                        Text("·")
                    }
                    Text(Fmt.due(task.due))
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            }

            Spacer(minLength: 8)

            if !task.done {
                Text(Fmt.relative(task.due))
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(overdue ? Color.red : Color.brand)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background((overdue ? Color.red : Color.brand).opacity(0.12), in: Capsule())
            }
        }
        .padding(14)
        .glass(20)
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .onTapGesture(perform: onEdit)
    }
}

struct TaskEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var task: StudyTask
    private let isNew: Bool
    private let onSave: (StudyTask) -> Void
    private let onDelete: () -> Void

    init(task: StudyTask, isNew: Bool,
         onSave: @escaping (StudyTask) -> Void,
         onDelete: @escaping () -> Void) {
        _task = State(initialValue: task)
        self.isNew = isNew
        self.onSave = onSave
        self.onDelete = onDelete
    }

    private var canSave: Bool {
        !task.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Что сделать", text: $task.title)
                        .font(.headline)
                    TextField("Предмет", text: $task.subject)
                }
                Section {
                    DatePicker("Срок", selection: $task.due)
                    Toggle("Напомнить за день и за час", isOn: $task.remind)
                }
                Section("Заметка") {
                    TextField("Аудитория, ссылка, детали…", text: $task.note, axis: .vertical)
                        .lineLimit(3...8)
                }
                if !isNew {
                    Section {
                        Button(role: .destructive) {
                            onDelete()
                            dismiss()
                        } label: {
                            Label("Удалить задачу", systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle(isNew ? "Новая задача" : "Задача")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") {
                        onSave(task)
                        Haptics.success()
                        dismiss()
                    }
                    .disabled(!canSave)
                }
            }
        }
    }
}
