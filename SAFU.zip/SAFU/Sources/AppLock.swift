import SwiftUI
import UIKit
import LocalAuthentication

// MARK: - Вход в приложение по Face ID
// Экран блокировки живёт в отдельном окне поверх всего (и поверх открытых шторок),
// появляется при запуске и каждый раз, когда приложение уходит в фон. Выключается в Профиле → Безопасность.

@MainActor
final class AppLock: ObservableObject {
    static let shared = AppLock()
    nonisolated static let key = "lock.app"

    @Published private(set) var busy = false
    @Published var failed = false
    private var window: UIWindow?

    var enabled: Bool { UserDefaults.standard.bool(forKey: Self.key) }
    var isLocked: Bool { window != nil }

    /// Face ID, Touch ID или просто код-пароль
    nonisolated static var biometryName: String {
        let c = LAContext()
        _ = c.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        switch c.biometryType {
        case .faceID: return "Face ID"
        case .touchID: return "Touch ID"
        default: return "код-пароль"
        }
    }

    func lock() {
        guard enabled, window == nil else { return }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first else { return }
        let w = UIWindow(windowScene: scene)
        w.windowLevel = .alert + 1
        let host = UIHostingController(rootView: AppLockScreen().environmentObject(self))
        host.view.backgroundColor = .clear
        w.rootViewController = host
        w.isHidden = false
        window = w
        failed = false
    }

    func unlock() {
        guard let w = window else { return }
        window = nil   // сразу считаемся открытыми — окно просто доигрывает исчезновение
        UIView.animate(withDuration: 0.35, delay: 0, options: .curveEaseOut) {
            w.alpha = 0
            w.transform = CGAffineTransform(scaleX: 1.08, y: 1.08)
        } completion: { _ in
            w.isHidden = true
        }
    }

    /// Спросить Face ID; без настроенной защиты на телефоне — пускаем сразу
    func authenticate(auto: Bool = false) {
        guard isLocked, !busy, !(auto && failed) else { return }
        let context = LAContext()
        context.localizedFallbackTitle = "Ввести код-пароль"
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            unlock()
            return
        }
        busy = true
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Вход в САФУ") { ok, _ in
            Task { @MainActor in
                self.busy = false
                if ok {
                    Haptics.success()
                    self.unlock()
                } else {
                    self.failed = true
                }
            }
        }
    }

    /// Включение из настроек — только после успешной проверки
    nonisolated static func confirm(_ done: @escaping (Bool) -> Void) {
        let context = LAContext()
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: nil) else { done(false); return }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Включить вход по \(biometryName)") { ok, _ in
            DispatchQueue.main.async { done(ok) }
        }
    }
}

private struct AppLockScreen: View {
    @EnvironmentObject private var lock: AppLock
    @State private var appear = false
    @State private var pulse = false

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThickMaterial).ignoresSafeArea()
            RadialGradient(colors: [Color.brand.opacity(0.35), .clear], center: .center, startRadius: 10, endRadius: 420)
                .ignoresSafeArea()
                .scaleEffect(pulse ? 1.15 : 0.9)
                .opacity(pulse ? 1 : 0.6)

            VStack(spacing: 22) {
                ZStack {
                    Circle().fill(brandGradient)
                        .frame(width: 104, height: 104)
                        .shadow(color: Color.brand.opacity(0.5), radius: 24, y: 8)
                    Image(systemName: "faceid")
                        .font(.system(size: 46, weight: .semibold))
                        .foregroundStyle(.white)
                        .symbolEffect(.pulse, options: .repeating, isActive: lock.busy)
                }
                .scaleEffect(appear ? 1 : 0.6)
                .opacity(appear ? 1 : 0)

                VStack(spacing: 6) {
                    Text("САФУ заблокировано")
                        .font(.system(.title2, design: .rounded).weight(.bold))
                    Text(lock.failed ? "Не получилось. Попробуй ещё раз" : "Оценки, пароли и файлы под защитой")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .contentTransition(.opacity)
                }
                .offset(y: appear ? 0 : 20)
                .opacity(appear ? 1 : 0)

                Button {
                    Haptics.tap()
                    lock.authenticate()
                } label: {
                    Label("Войти по \(AppLock.biometryName)", systemImage: "lock.open.fill")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 26)
                        .padding(.vertical, 15)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .offset(y: appear ? 0 : 30)
                .opacity(appear ? 1 : 0)
            }
            .padding(30)
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.75)) { appear = true }
            withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}
