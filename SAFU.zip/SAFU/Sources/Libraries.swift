import SwiftUI

// MARK: - Библиотеки: электронно-библиотечные системы, которыми пользуются в САФУ
//
// Отдельная плитка «Библиотеки» на панели с Sakai и почтой. Нажал — под панелью раскрываются плитки
// ЭБС (Знаниум, Лань, Юрайт…), каждая открывается карточкой и вырастает прямо из своей плитки.

struct LibraryLink: Identifiable {
    /// Подпись под плиткой — коротко
    let short: String
    let resource: Resource
    var id: UUID { resource.id }

    /// n — постоянный номер: по нему сайт помнит открытую страницу и после перезапуска
    init(_ n: Int, _ short: String, _ title: String, _ about: String, _ url: String, _ icon: String) {
        self.short = short
        let id = UUID(uuidString: String(format: "A7C1B000-0000-4000-8000-%012d", n)) ?? UUID()
        resource = Resource(id: id, title: title, subtitle: about, url: url, icon: icon, category: "Библиотеки")
    }
}

enum Libraries {
    /// Сначала самые ходовые в САФУ: Знаниум, Лань, Юрайт
    static let all: [LibraryLink] = [
        LibraryLink(1, "Знаниум", "Знаниум", "ЭБС: учебники и монографии", "https://znanium.ru", "book.fill"),
        LibraryLink(2, "Лань", "Лань", "ЭБС издательства «Лань»", "https://e.lanbook.com", "books.vertical.fill"),
        LibraryLink(3, "Юрайт", "Юрайт", "Образовательная платформа: учебники и курсы", "https://urait.ru", "text.book.closed.fill"),
        LibraryLink(4, "IPR SMART", "IPR SMART", "ЭБС IPR SMART (IPRbooks)", "https://www.iprbookshop.ru", "book.pages.fill"),
        LibraryLink(5, "Консультант", "Консультант студента", "ЭБС «Консультант студента»", "https://www.studentlibrary.ru", "character.book.closed.fill"),
        LibraryLink(6, "Biblioclub", "Университетская библиотека онлайн", "ЭБС biblioclub.ru", "https://biblioclub.ru", "book.closed.fill"),
        LibraryLink(7, "eLibrary", "eLIBRARY.RU", "Научные статьи и журналы, РИНЦ", "https://elibrary.ru", "doc.text.magnifyingglass"),
        LibraryLink(8, "Киберленинка", "КиберЛенинка", "Научные статьи в открытом доступе", "https://cyberleninka.ru", "magazine.fill"),
        LibraryLink(9, "НЭБ", "НЭБ", "Национальная электронная библиотека", "https://rusneb.ru", "building.2.fill"),
        LibraryLink(10, "Библиотека", "Библиотека САФУ", "Научная библиотека САФУ: каталог и ресурсы", "https://library.narfu.ru", "building.columns.fill"),
    ]
}

/// Плитка «Библиотеки» на панели: раскрывает и прячет плитки ЭБС
struct LibrariesTile: View {
    @Binding var open: Bool
    var size: CGFloat = 50
    var labelFont: Font = .system(size: 11.5, weight: .semibold)

    var body: some View {
        Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.34, dampingFraction: 0.86)) { open.toggle() }
        } label: {
            VStack(spacing: 7) {
                let shape = RoundedRectangle(cornerRadius: SiteTile.radius(size), style: .continuous)
                Image(systemName: open ? "books.vertical.fill" : "books.vertical")
                    .font(.system(size: size * 0.42, weight: .semibold))
                    .foregroundStyle(open ? Color.white : Color.brand)
                    .frame(width: size, height: size)
                    .background(shape.fill(open ? AnyShapeStyle(Color.brand) : AnyShapeStyle(SiteTile.fill)))
                    .overlay(shape.strokeBorder(SiteTile.stroke, lineWidth: 0.5))
                Text("Библиотеки")
                    .font(labelFont)
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(PressableStyle())
        .accessibilityLabel(open ? "Скрыть библиотеки" : "Библиотеки")
    }
}

/// Плитки ЭБС под панелью. Нажал — библиотека вырастает из своей плитки и садится обратно, когда закроешь
struct LibrariesPanel: View {
    @Binding var open: Bool

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 4), count: 4)
    private static let tile: CGFloat = 46

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .firstTextBaseline) {
                Text("Библиотеки")
                    .font(.system(.headline, design: .rounded))
                Text("ЭБС для студентов САФУ")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.34, dampingFraction: 0.86)) { open = false }
                } label: {
                    Image(systemName: "chevron.up")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 30, height: 30)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Скрыть библиотеки")
            }
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(Libraries.all) { lib in
                    Button {
                        SiteTabs.shared.open(lib.resource, origin: "lib:" + lib.id.uuidString,
                                             radius: SiteTile.radius(Self.tile))
                    } label: {
                        VStack(spacing: 6) {
                            SiteAppIcon(resource: lib.resource, size: Self.tile)
                                .background(OriginProbe(key: "lib:" + lib.id.uuidString))
                            Text(lib.short)
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundStyle(.primary)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                        }
                        .frame(maxWidth: .infinity)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(PressableStyle())
                    .accessibilityLabel(lib.resource.title)
                    .accessibilityHint(lib.resource.subtitle)
                }
            }
            Text("Подписку на ЭБС оплачивает университет: зарегистрируйся в нужной библиотеке, подключившись к Wi‑Fi САФУ, — потом вход по своему логину работает и из дома. Что подключено сейчас — на сайте «Библиотека САФУ».")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .glass(24)
    }
}
