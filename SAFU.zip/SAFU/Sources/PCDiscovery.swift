import SwiftUI
import CryptoKit
import UIKit

// MARK: - Компьютер с Арктикой в той же сети: найти сам и связаться без QR-кода
//
// Поиск: телефон спрашивает «кто тут?» (GET /v2/hello) у соседей по Wi‑Fi на порту синхронизации.
// Отвечает только Арктика для Windows: имя компьютера и отпечаток его связки. По отпечатку связанный
// телефон находит «свой» компьютер, даже если тот получил в сети новый адрес.
//
// Связка: у телефона и компьютера по одноразовому ключу X25519, общий секрет → HKDF → ключ AES-256-GCM.
// Компьютер сначала присылает отпечаток своего ключа и только потом сам ключ, оба экрана показывают
// четырёхзначный код из обоих ключей. Человек сверяет и нажимает на компьютере «Разрешить» — тогда
// компьютер присылает постоянный ключ синхронизации, зашифрованный общим. Сервер — windows/electron/syncpair.ts.

/// Компьютер с Арктикой, который нашёлся в сети
struct SyncFound: Identifiable, Equatable, Hashable {
    let host: String
    let port: Int
    let pc: String
    /// Отпечаток связки на компьютере; nil — компьютер ещё ни с кем не связан
    let pair: String?
    var id: String { "\(host):\(port)" }
}

/// Адреса своей домашней сети
enum LocalNet {
    struct Iface { let ip: UInt32; let mask: UInt32 }

    /// Wi‑Fi (en…) и раздача интернета с этого телефона (bridge…); сотовая сеть не нужна
    static func interfaces() -> [Iface] {
        var head: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&head) == 0, let first = head else { return [] }
        defer { freeifaddrs(head) }
        var out: [Iface] = []
        for p in sequence(first: first, next: { $0.pointee.ifa_next }) {
            let f = p.pointee
            guard let a = f.ifa_addr, let m = f.ifa_netmask, a.pointee.sa_family == sa_family_t(AF_INET) else { continue }
            let flags = Int32(bitPattern: f.ifa_flags)
            guard flags & IFF_UP != 0, flags & IFF_LOOPBACK == 0 else { continue }
            let name = String(cString: f.ifa_name)
            guard name.hasPrefix("en") || name.hasPrefix("bridge") else { continue }
            let ip = a.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt32(bigEndian: $0.pointee.sin_addr.s_addr) }
            let mask = m.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { UInt32(bigEndian: $0.pointee.sin_addr.s_addr) }
            guard PCLink.isLocal(dotted(ip)) else { continue }
            out.append(Iface(ip: ip, mask: mask))
        }
        return out
    }

    static func dotted(_ v: UInt32) -> String {
        "\(v >> 24 & 255).\(v >> 16 & 255).\(v >> 8 & 255).\(v & 255)"
    }

    /// Соседи по каждой домашней сети: свои 254 адреса, а wide — остальная сеть, но не больше /22
    /// (у роутеров с «большой» сетью компьютер бывает в соседнем блоке)
    static func neighbours(wide: Bool = false) -> [String] {
        var near: [String] = []
        var far: [String] = []
        var seen = Set<String>()
        for i in interfaces() {
            let mask: UInt32 = i.mask.nonzeroBitCount >= 22 ? i.mask : 0xFFFF_FC00
            let net = i.ip & mask
            let last = net | ~mask
            guard last > net + 1 else { continue }
            let block = i.ip & 0xFFFF_FF00
            for v in (net + 1)..<last where v != i.ip && v & 0xFF != 0 && v & 0xFF != 255 {
                let s = dotted(v)
                guard seen.insert(s).inserted else { continue }
                if v & 0xFFFF_FF00 == block { near.append(s) } else { far.append(s) }
            }
        }
        return wide ? far : near
    }
}

enum PCDiscovery {
    /// Порт синхронизации на компьютере (занят — компьютер берёт следующий, его телефон узнаёт из ответа)
    static let port = 47823

    /// iOS не пустила в локальную сеть (Настройки → Арктика → Локальная сеть выключено)
    private static let deniedFlag = Flag()
    static var localNetworkDenied: Bool { deniedFlag.value }

    final class Flag: @unchecked Sendable {
        private let lock = NSLock()
        private var v = false
        var value: Bool { lock.lock(); defer { lock.unlock() }; return v }
        func set(_ x: Bool) { lock.lock(); v = x; lock.unlock() }
    }

    /// Ошибка из-за запрета «Локальной сети»: iOS пишет это в описании сетевого пути
    static func isLocalNetworkDenied(_ error: Error) -> Bool {
        let ns = error as NSError
        let text = "\(ns.userInfo)" + ((ns.userInfo[NSUnderlyingErrorKey] as? NSError).map { "\($0.userInfo)" } ?? "")
        return text.contains("Local network prohibited") || text.contains("localNetworkDenied")
    }

    private static let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 1.6
        c.timeoutIntervalForResource = 4
        c.waitsForConnectivity = false
        c.urlCache = nil
        return URLSession(configuration: c)
    }()

    /// «Кто тут?» — отвечает только Арктика для Windows
    static func hello(_ host: String, port: Int) async -> SyncFound? {
        guard let url = URL(string: "http://\(host):\(port)/v2/hello") else { return nil }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 1.6)
        req.httpMethod = "GET"
        let r: (Data, URLResponse)
        do { r = try await session.data(for: req) } catch {
            if isLocalNetworkDenied(error) { deniedFlag.set(true) }
            return nil
        }
        guard (r.1 as? HTTPURLResponse)?.statusCode == 200,
              let j = try? JSONSerialization.jsonObject(with: r.0) as? [String: Any],
              j["app"] as? String == "arktika" else { return nil }
        let p = (j["port"] as? NSNumber)?.intValue ?? port
        let name = (j["pc"] as? String).map { String($0.prefix(40)) } ?? ""
        return SyncFound(host: host, port: (1...65535).contains(p) ? p : port,
                         pc: name.isEmpty ? L("Компьютер") : name, pair: j["pair"] as? String)
    }

    /// Обойти сеть: сначала адреса из first, потом соседей. stop — нашли нужный, дальше не ищем
    static func scan(first: [String] = [], ports: [Int] = [PCDiscovery.port], wide: Bool = false,
                     stop: ((SyncFound) -> Bool)? = nil) async -> [SyncFound] {
        var hosts: [String] = []
        var seen = Set<String>()
        for h in first + LocalNet.neighbours(wide: wide) where seen.insert(h).inserted { hosts.append(h) }
        deniedFlag.set(false)
        let targets: [(String, Int)] = hosts.prefix(1100).flatMap { h in ports.map { (h, $0) } }
        var found: [SyncFound] = []
        await withTaskGroup(of: SyncFound?.self) { group in
            var next = 0
            // по 64 сразу: вся домашняя сеть — за несколько секунд
            while next < min(64, targets.count) {
                let t = targets[next]
                group.addTask { await PCDiscovery.hello(t.0, port: t.1) }
                next += 1
            }
            while let r = await group.next() {
                if let r, !found.contains(where: { $0.host == r.host }) {
                    found.append(r)
                    if stop?(r) == true {
                        group.cancelAll()
                        break
                    }
                }
                if next < targets.count {
                    let t = targets[next]
                    group.addTask { await PCDiscovery.hello(t.0, port: t.1) }
                    next += 1
                }
            }
        }
        return found
    }

    /// Компьютер по адресу, который ввели руками: основной порт, потом запасные
    static func find(at host: String) async -> SyncFound? {
        let h = host.trimmingCharacters(in: .whitespacesAndNewlines)
        guard PCLink.isLocal(h) else { return nil }
        deniedFlag.set(false)
        if let f = await hello(h, port: port) { return f }
        return await withTaskGroup(of: SyncFound?.self) { group in
            for p in (port + 1)...(port + 7) { group.addTask { await PCDiscovery.hello(h, port: p) } }
            for await r in group { if let r { group.cancelAll(); return r } }
            return nil
        }
    }

    /// Отпечаток номера связки — так же, как на компьютере (sha256, первые 12 знаков)
    static func tag(_ id: String) -> String {
        String(SHA256.hash(data: Data(id.utf8)).map { String(format: "%02x", $0) }.joined().prefix(12))
    }
}

// MARK: - Связка без QR-кода

enum PCPairing {
    enum Failure: LocalizedError {
        case denied, busy, gone, broken, unreachable

        var errorDescription: String? {
            switch self {
            case .denied: return L("На компьютере нажали «Отклонить».")
            case .busy: return L("На компьютере уже открыт другой запрос — ответь на него и попробуй снова.")
            case .gone: return L("Компьютер долго не отвечал — запрос устарел. Попробуй ещё раз.")
            case .broken: return L("Компьютер ответил что-то не то. Обнови Арктику на компьютере и попробуй снова.")
            case .unreachable: return L("Компьютер перестал отвечать. Проверь, что он в той же сети Wi‑Fi и Арктика на нём запущена.")
            }
        }
    }

    private static func post(_ f: SyncFound, _ step: String, _ body: [String: Any], timeout: TimeInterval) async throws -> [String: Any] {
        guard let url = URL(string: "http://\(f.host):\(f.port)/v2/pair/\(step)") else { throw Failure.broken }
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: timeout)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let r: (Data, URLResponse)
        do { r = try await URLSession.shared.data(for: req) } catch {
            if error is CancellationError || (error as? URLError)?.code == .cancelled { throw CancellationError() }
            throw Failure.unreachable
        }
        let code = (r.1 as? HTTPURLResponse)?.statusCode ?? 0
        if code == 409 { throw Failure.busy }
        if code == 410 { throw Failure.gone }
        guard code == 200, let j = try? JSONSerialization.jsonObject(with: r.0) as? [String: Any] else { throw Failure.broken }
        return j
    }

    /// Код для сверки глазами: одинаковый на обоих экранах, только если ключи никто не подменил
    static func code(_ phonePub: Data, _ pcPub: Data) -> String {
        let d = Array(SHA256.hash(data: Data("arktika-sas|".utf8) + phonePub + pcPub))
        let n = UInt32(d[0]) << 24 | UInt32(d[1]) << 16 | UInt32(d[2]) << 8 | UInt32(d[3])
        return String(format: "%04d", Int(n % 10000))
    }

    /// Связаться с найденным компьютером. Код — в onCode (показать человеку), дальше ждём «Разрешить»
    static func run(_ f: SyncFound, device: String, onCode: @escaping @MainActor (String) -> Void) async throws -> SyncLink {
        let start = try await post(f, "start", ["device": device], timeout: 8)
        guard let sid = start["sid"] as? String, let commit = start["commit"] as? String else { throw Failure.broken }
        let me = Curve25519.KeyAgreement.PrivateKey()
        let myPub = me.publicKey.rawRepresentation
        let answer = try await post(f, "key", ["sid": sid, "pub": myPub.base64EncodedString()], timeout: 8)
        guard let b64 = answer["pub"] as? String, let pcPub = Data(base64Encoded: b64), pcPub.count == 32,
              Data(SHA256.hash(data: pcPub)).base64EncodedString() == commit,
              let pcKey = try? Curve25519.KeyAgreement.PublicKey(rawRepresentation: pcPub),
              let shared = try? me.sharedSecretFromKeyAgreement(with: pcKey) else { throw Failure.broken }
        let key = shared.hkdfDerivedSymmetricKey(using: SHA256.self, salt: Data("arktika-pair-v1".utf8),
                                                 sharedInfo: myPub + pcPub, outputByteCount: 32)
        await onCode(code(myPub, pcPub))
        // компьютер держит запрос, пока человек думает, и отвечает «жди» — спрашиваем снова
        while true {
            try Task.checkCancellation()
            let w = try await post(f, "wait", ["sid": sid], timeout: 40)
            switch w["status"] as? String {
            case "ok":
                guard let boxB64 = w["box"] as? String, let box = Data(base64Encoded: boxB64),
                      let plain = try? PCCrypto.open(box, key: key, aad: "arktika pair"),
                      let j = try? JSONSerialization.jsonObject(with: plain) as? [String: Any],
                      let link = SyncLink(grant: j, found: f) else { throw Failure.broken }
                return link
            case "denied":
                throw Failure.denied
            default:
                continue
            }
        }
    }
}

// MARK: - Связка на экране синхронизации: код и ожидание «Разрешить» на компьютере

struct PCPairPanel: View {
    @ObservedObject private var sync = PCSync.shared

    var body: some View {
        VStack(spacing: 14) {
            switch sync.pairStep {
            case .some(.connecting(let pc)):
                ProgressView()
                Text(L("Связываюсь с «\(pc)»…")).font(.headline)
            case .some(.code(let code, let pc)):
                Text(L("Сверь код с экраном «\(pc)»"))
                    .font(.headline)
                    .multilineTextAlignment(.center)
                HStack(spacing: 10) {
                    ForEach(Array(code.enumerated()), id: \.offset) { _, ch in
                        Text(String(ch))
                            .font(.system(size: 38, weight: .bold, design: .rounded))
                            .monospacedDigit()
                            .foregroundStyle(Color.brand)
                            .frame(width: 54, height: 68)
                            .background(Color.brand.opacity(0.12), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
                .accessibilityElement(children: .ignore)
                .accessibilityLabel(L("Код \(code.map { String($0) }.joined(separator: " "))"))
                Text(L("Если на компьютере тот же код — нажми там «Разрешить». Окно появится само."))
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                HStack(spacing: 8) {
                    ProgressView()
                    Text(L("Жду ответ компьютера…")).font(.footnote).foregroundStyle(.secondary)
                }
            case .some(.failed(let msg)):
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 30))
                    .foregroundStyle(.orange)
                Text(msg)
                    .font(.subheadline.weight(.semibold))
                    .multilineTextAlignment(.center)
            case nil:
                EmptyView()
            }
            Button(isFailed ? L("Понятно") : L("Отмена")) {
                sync.cancelPairing()
            }
            .buttonStyle(.bordered)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
    }

    private var isFailed: Bool {
        if case .some(.failed) = sync.pairStep { return true }
        return false
    }
}

/// Телефон не связан, а рядом нашёлся компьютер с Арктикой — предлагаем один раз.
/// Отдельный невидимый вид: изменения синхронизации не перерисовывают весь экран приложения
struct SyncOfferHost: View {
    @ObservedObject private var sync = PCSync.shared
    @Binding var showSync: Bool

    var body: some View {
        Color.clear
            .allowsHitTesting(false)
            .alert(L("Рядом компьютер с Арктикой"), isPresented: Binding(get: { sync.offer != nil }, set: { if !$0 { sync.offer = nil } }),
                   presenting: sync.offer) { f in
                Button(L("Связать")) {
                    sync.pairWith(f)
                    showSync = true
                }
                Button(L("Не сейчас"), role: .cancel) {}
                Button(L("Больше не предлагать")) { PCSync.neverOffer() }
            } message: { f in
                Text(L("«\(f.pc)» в этой же сети Wi‑Fi. Свяжи их — и ДЗ, задачи и заметки станут общими сами, без QR-кода. На компьютере нужно будет нажать «Разрешить»."))
            }
    }
}

// MARK: - Файлы на компьютер — сами, по связке синхронизации
//
// После удачного обмена ДЗ телефон смотрит, не появилось ли новых файлов: файлы предметов, фото доски,
// записи лекций и фото к ДЗ («ДЗ с iPhone/<номер ДЗ>/…» — на компьютере они прикрепляются к тому же ДЗ).
// Протокол и шифр — как у переноса по QR, только ключ — ключ связки. Компьютер сам говорит, что у него уже
// есть, поэтому идут только новые файлы; оборвалось — докачается с того же места.

extension PCLink {
    /// Канал файлов связанного компьютера: номер связки вместо номера сеанса, ключ связки
    init(pairing p: SyncPairing) {
        self.init(hosts: p.hosts, port: p.port, session: p.id, keyData: p.key, name: p.name)
    }
}

enum PCFileSender {
    static let hwDir = L("ДЗ с iPhone")

    /// Фото к ДЗ как файлы для переноса
    static func homeworkItems(_ list: [Homework]) -> [PCItem] {
        var out: [PCItem] = []
        let fm = FileManager.default
        for h in list {
            for name in h.photos {
                let u = HWFiles.url(h.id, name)
                guard let a = try? fm.attributesOfItem(atPath: u.path) else { continue }
                let size = (a[.size] as? NSNumber)?.int64Value ?? 0
                let mtime = ((a[.modificationDate] as? Date) ?? Date()).timeIntervalSince1970 * 1000
                out.append(PCItem(rel: "\(hwDir)/\(h.id.uuidString.lowercased())/\(name)", url: u, size: size, mtime: mtime, kind: .file))
            }
        }
        return out
    }

    /// Отпечаток набора файлов: не изменился — компьютер и так всё получил
    static func signature(_ items: [PCItem], pair: String) -> String {
        var h = SHA256()
        h.update(data: Data(pair.utf8))
        for i in items.sorted(by: { $0.rel < $1.rel }) {
            h.update(data: Data("\(i.rel)|\(i.size)|\(Int64(i.mtime))\n".utf8))
        }
        return h.finalize().prefix(12).map { String(format: "%02x", $0) }.joined()
    }

    /// Отправить новое. progress(отправлено файлов, всего новых). Возвращает, сколько файлов ушло
    static func send(_ list: [PCItem], client: PCClient, progress: @escaping @MainActor (Int, Int) -> Void) async throws -> Int {
        let files = list.map { ["p": $0.rel, "s": $0.size, "m": $0.mtime] as [String: Any] }
        let planBody = try JSONSerialization.data(withJSONObject: ["files": files, "data": false])
        let (code, plan) = try await client.call("POST", "/v1/plan", body: planBody, timeout: 60)
        guard code == 200 else { throw PCTransferError.rejected(code) }
        var offsets: [Int: Int64] = [:]
        for f in plan["files"] as? [[String: Any]] ?? [] {
            if let i = (f["i"] as? NSNumber)?.intValue, let o = (f["o"] as? NSNumber)?.int64Value { offsets[i] = o }
        }
        var todo: [(Int, PCItem, Int64)] = []
        for (i, item) in list.enumerated() {
            guard let o = offsets[i], o >= 0, o <= item.size else { continue }
            todo.append((i, item, o))
        }
        let total = todo.count
        if total > 0 { await progress(0, total) }
        let key = client.link.key
        let chunk = 4 * 1024 * 1024
        var sent = 0
        for (i, item, start) in todo {
            try Task.checkCancellation()
            var off = start
            while off < item.size {
                try Task.checkCancellation()
                let len = Int(min(Int64(chunk), item.size - off))
                let path = "/v1/file?i=\(i)&o=\(off)"
                let sealed = try PCClient.sealedChunk(item.url, offset: off, length: len, key: key, aad: "PUT \(path)")
                let (c, j) = try await client.send("PUT", path, sealed: sealed, timeout: 60)
                if c != 200 && c != 409 { throw PCTransferError.rejected(c) }
                let now = min(item.size, max(0, (j["o"] as? NSNumber)?.int64Value ?? (off + Int64(len))))
                if now == off || (c == 200 && now < off) { throw PCTransferError.broken }
                off = now
            }
            sent += 1
            await progress(sent, total)
        }
        let doneBody = try JSONSerialization.data(withJSONObject: [String: Any]())
        _ = try await client.call("POST", "/v1/done", body: doneBody)
        return sent
    }
}
