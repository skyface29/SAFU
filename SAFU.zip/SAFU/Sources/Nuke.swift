import SwiftUI
import UIKit
import CoreHaptics
import AVFoundation

// MARK: - Пасхалка «Ядерный гриб»
// 7 тапов по иконке разработчика: экран приложения разлетается осколками,
// ослепляющая вспышка, огненный шар, ударная волна, кольцо конденсации и ядерный гриб.
// С тряской экрана, вибрацией и низким гулом взрыва.

struct NukeShot: Identifiable {
    let id = UUID()
    let image: UIImage?
}

enum Nuke {
    /// Снимок текущего экрана — его и разнесёт взрывом
    static func snapshot() -> UIImage? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first { $0.activationState == .foregroundActive } ?? scenes.first
        guard let win = scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first else { return nil }
        let renderer = UIGraphicsImageRenderer(bounds: win.bounds)
        return renderer.image { _ in _ = win.drawHierarchy(in: win.bounds, afterScreenUpdates: false) }
    }
}

// MARK: - Экран взрыва

struct NukeView: View {
    let snapshot: UIImage?
    @Environment(\.dismiss) private var dismiss
    @State private var start = Date()
    @State private var scene = NukeScene()
    @State private var sound = NukeSound()
    @State private var rumble = NukeRumble()
    @State private var fired = false
    @State private var showHint = false

    var body: some View {
        TimelineView(.animation) { ctx in
            let t = ctx.date.timeIntervalSince(start)
            Canvas { g, size in
                let img = snapshot.map { g.resolve(Image(uiImage: $0)) }
                scene.draw(&g, size: size, t: t, snapshot: img)
            }
        }
        .ignoresSafeArea()
        .background(Color.black)
        .overlay(alignment: .bottom) {
            if showHint {
                VStack(spacing: 6) {
                    Text("☢️ Пасхалка найдена")
                        .font(.system(size: 22, weight: .heavy, design: .rounded))
                    Text("Тап — вернуться в то, что осталось от приложения")
                        .font(.footnote.weight(.semibold))
                        .opacity(0.8)
                }
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 22)
                .padding(.vertical, 14)
                .background(.black.opacity(0.45), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                .padding(.bottom, 40)
                .transition(.opacity.combined(with: .move(edge: .bottom)))
            }
        }
        .contentShape(Rectangle())
        .onTapGesture { if showHint { dismiss() } }
        .statusBarHidden()
        .onAppear {
            guard !fired else { return }
            fired = true
            start = Date()
            DispatchQueue.main.asyncAfter(deadline: .now() + NukeScene.detonate) {
                sound.play()
                rumble.play()
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 6.5) {
                withAnimation(.easeOut(duration: 0.6)) { showHint = true }
            }
        }
        .onDisappear {
            sound.stop()
            rumble.stop()
        }
    }
}

// MARK: - Цвет и случайности

private struct RGB {
    var r: Double, g: Double, b: Double
    init(_ r: Double, _ g: Double, _ b: Double) { self.r = r; self.g = g; self.b = b }

    static func mix(_ a: RGB, _ b: RGB, _ f: Double) -> RGB {
        let f = Swift.min(1, Swift.max(0, f))
        return RGB(a.r + (b.r - a.r) * f, a.g + (b.g - a.g) * f, a.b + (b.b - a.b) * f)
    }

    /// Плавный переход по ключевым точкам времени
    static func ramp(_ t: Double, _ keys: [(Double, RGB)]) -> RGB {
        guard let first = keys.first, let last = keys.last else { return RGB(0, 0, 0) }
        if t <= first.0 { return first.1 }
        if t >= last.0 { return last.1 }
        for i in 1..<keys.count where t <= keys[i].0 {
            let a = keys[i - 1], b = keys[i]
            return mix(a.1, b.1, (t - a.0) / (b.0 - a.0))
        }
        return last.1
    }

    func color(_ opacity: Double = 1) -> Color { Color(red: r, green: g, blue: b).opacity(Swift.max(0, Swift.min(1, opacity))) }
}

private struct Seeded {
    var s: UInt64
    mutating func next() -> Double {
        s &+= 0x9E37_79B9_7F4A_7C15
        var z = s
        z = (z ^ (z >> 30)) &* 0xBF58_476D_1CE4_E5B9
        z = (z ^ (z >> 27)) &* 0x94D0_49BB_1331_11EB
        z = z ^ (z >> 31)
        return Double(z >> 11) / 9_007_199_254_740_992.0
    }
    mutating func r(_ a: Double, _ b: Double) -> Double { a + (b - a) * next() }
}

// MARK: - Сцена

final class NukeScene {
    static let detonate = 0.35

    struct Tile { let col: Int; let row: Int; let jx: Double; let jy: Double; let spin: Double; let power: Double }
    struct Puff { let a: Double; let b: Double; let size: Double; let phase: Double; let speed: Double }
    struct Ember { let angle: Double; let speed: Double; let life: Double; let size: Double; let delay: Double }
    struct Building { let x: Double; let w: Double; let h: Double; let windows: Int }

    static let cols = 7, rows = 14

    private let tiles: [Tile]
    private let dome: [Puff]
    private let ring: [Puff]
    private let stem: [Puff]
    private let base: [Puff]
    private let embers: [Ember]
    private let city: [Building]

    init() {
        var rnd = Seeded(s: 0xA7C3_2026_0150)
        var tl: [Tile] = []
        for row in 0..<Self.rows {
            for col in 0..<Self.cols {
                tl.append(Tile(col: col, row: row, jx: rnd.r(-160, 160), jy: rnd.r(-260, 60),
                               spin: rnd.r(-9, 9), power: rnd.r(0.7, 1.4)))
            }
        }
        tiles = tl

        var d: [Puff] = []
        for _ in 0..<90 {
            let th = rnd.r(-0.12 * .pi, 1.12 * .pi)
            let rho = 0.2 + 0.8 * rnd.next().squareRoot()
            d.append(Puff(a: cos(th) * rho, b: -sin(th) * rho * 0.72 + 0.05,
                          size: rnd.r(0.26, 0.44), phase: rnd.r(0, 6.28), speed: rnd.r(0.6, 1.6)))
        }
        dome = d.sorted { $0.b < $1.b }   // сначала верх, низ (горячий) поверх

        var rg: [Puff] = []
        for i in 0..<44 {
            rg.append(Puff(a: Double(i) / 44 * 2 * .pi + rnd.r(-0.05, 0.05), b: rnd.r(0, 6.28),
                           size: rnd.r(0.8, 1.2), phase: rnd.r(0, 6.28), speed: rnd.r(0.8, 1.3)))
        }
        ring = rg

        var st: [Puff] = []
        for i in 0..<70 {
            st.append(Puff(a: rnd.r(-1, 1), b: Double(i) / 69, size: rnd.r(0.8, 1.25),
                           phase: rnd.r(0, 6.28), speed: rnd.r(0.5, 1.4)))
        }
        stem = st

        var bs: [Puff] = []
        for _ in 0..<70 {
            bs.append(Puff(a: rnd.r(-1, 1), b: rnd.next(), size: rnd.r(0.7, 1.4),
                           phase: rnd.r(0, 6.28), speed: rnd.r(0.5, 1.3)))
        }
        base = bs.sorted { $0.b > $1.b }

        var em: [Ember] = []
        for _ in 0..<150 {
            em.append(Ember(angle: rnd.r(0.08 * .pi, 0.92 * .pi), speed: rnd.r(0.25, 1.35),
                            life: rnd.r(1.2, 3.6), size: rnd.r(1.2, 3.6), delay: rnd.r(0, 0.9)))
        }
        embers = em

        var ct: [Building] = []
        var x = -60.0
        while x < 1400 {
            let bw = rnd.r(16, 48)
            ct.append(Building(x: x, w: bw, h: rnd.r(0.015, 0.075), windows: Int(rnd.r(0, 6))))
            x += bw + rnd.r(0, 10)
        }
        city = ct
    }

    // MARK: рисование

    func draw(_ g: inout GraphicsContext, size: CGSize, t: Double, snapshot: GraphicsContext.ResolvedImage?) {
        let w = Double(size.width), h = Double(size.height)
        let tau = t - Self.detonate
        let cx = w / 2
        let ground = h * 0.80
        let full = CGRect(x: -60, y: -60, width: w + 120, height: h + 120)

        // ——— до детонации: экран приложения и растущая точка света
        if tau < 0 {
            if let snapshot {
                g.draw(snapshot, in: CGRect(origin: .zero, size: size))
            } else {
                g.fill(Path(full), with: .color(.black))
            }
            let k = t / Self.detonate
            let jitter = 3 * k
            g.translateBy(x: CGFloat(sin(t * 70) * jitter), y: CGFloat(cos(t * 53) * jitter))
            let r = 6 + 60 * k * k
            g.fill(Path(ellipseIn: CGRect(x: cx - r, y: ground - r, width: r * 2, height: r * 2)),
                   with: .radialGradient(Gradient(colors: [.white, Color(red: 1, green: 0.92, blue: 0.7).opacity(0.85), .clear]),
                                         center: CGPoint(x: cx, y: ground), startRadius: 0, endRadius: CGFloat(r)))
            g.fill(Path(full), with: .color(.white.opacity(0.25 * k * k)))
            return
        }

        // ——— тряска: взрыв и приход ударной волны
        var amp = 18 * exp(-tau / 0.9)
        if tau > 1.1 { amp += 14 * exp(-(tau - 1.1) / 0.6) * Swift.min(1, (tau - 1.1) / 0.05) }
        amp += 1.2 * exp(-tau / 6)
        g.translateBy(x: CGFloat(sin(t * 57) * amp + sin(t * 23) * amp * 0.5),
                      y: CGFloat(cos(t * 49) * amp * 0.7 + sin(t * 31) * amp * 0.3))

        let rise = 1 - exp(-tau / 2.4)
        let cy = ground - h * 0.08 - h * 0.44 * rise
        let R = w * (0.10 + 0.27 * (1 - exp(-tau / 1.8)))
        let heat = exp(-tau / 2.6)
        let sx = 1 + 0.35 * rise
        let sy = 1 - 0.18 * rise

        // ——— небо
        let top = RGB.ramp(tau, [(0, RGB(1, 1, 1)), (0.5, RGB(1, 0.86, 0.6)), (1.6, RGB(0.55, 0.22, 0.1)),
                                 (4, RGB(0.18, 0.07, 0.06)), (9, RGB(0.07, 0.04, 0.05))])
        let horizon = RGB.ramp(tau, [(0, RGB(1, 1, 1)), (0.5, RGB(1, 0.95, 0.75)), (2, RGB(1, 0.5, 0.16)),
                                     (5, RGB(0.7, 0.22, 0.07)), (9, RGB(0.36, 0.12, 0.06))])
        g.fill(Path(CGRect(x: -60, y: -60, width: w + 120, height: ground + 60)),
               with: .linearGradient(Gradient(colors: [top.color(), horizon.color()]),
                                     startPoint: CGPoint(x: 0, y: -60), endPoint: CGPoint(x: 0, y: ground)))

        // ——— зарево вокруг гриба
        let glow = RGB.mix(RGB(1, 0.55, 0.15), RGB(1, 0.9, 0.6), heat)
        var lighter = g
        lighter.blendMode = .plusLighter
        lighter.fill(Path(ellipseIn: CGRect(x: cx - w * 1.1, y: cy - w * 1.1, width: w * 2.2, height: w * 2.2)),
                     with: .radialGradient(Gradient(colors: [glow.color(0.55 * heat + 0.12), glow.color(0)]),
                                           center: CGPoint(x: cx, y: cy), startRadius: 0, endRadius: CGFloat(w * 1.1)))

        // ——— ударная волна в воздухе (полусфера)
        if tau < 1.4 {
            let sr = w * 1.6 * tau
            let a = 0.45 * (1 - tau / 1.4)
            g.drawLayer { l in
                l.addFilter(.blur(radius: 4))
                l.stroke(Path(ellipseIn: CGRect(x: cx - sr, y: ground - sr, width: sr * 2, height: sr * 2)),
                         with: .color(.white.opacity(a)), lineWidth: 5)
            }
        }

        // ——— ножка гриба
        let stemTop = cy + R * 0.35 * sy
        let stemGrow = 1 - exp(-tau / 2)
        for p in stem {
            let f = p.b
            let y = ground - f * (ground - stemTop)
            let hw = w * (0.03 + 0.05 * stemGrow) * (1 + 1.4 * pow(1 - f, 3) + 0.5 * f * f)
            let x = cx + p.a * hw * 0.7 + sin(tau * 0.9 * p.speed + p.phase + f * 6) * hw * 0.22
            let r = hw * 0.85 * p.size
            let fire = heat * 0.85 * f + 0.18 * f * exp(-tau / 6)
            let smoke = RGB.mix(RGB(0.46, 0.34, 0.26), RGB(0.3, 0.24, 0.22), f)
            let lit = RGB.mix(smoke, fireColor(fire), Swift.min(1, fire * 1.5))
            puff(&g, CGPoint(x: x, y: y), r, lit: lit, edge: RGB.mix(lit, RGB(0.07, 0.05, 0.05), 0.5), alpha: 0.95)
        }

        // ——— кольцо-тор (задняя половина)
        let ringR = R * 0.92
        let minor = R * 0.2
        func ringPuff(_ p: Puff, front: Bool) {
            let psi = p.b + tau * 1.4 * p.speed
            let z = sin(p.a)
            guard (z >= 0) == front else { return }
            let x = cx + (ringR + minor * cos(psi)) * cos(p.a) * sx
            let y = cy + R * 0.3 * sy + ringR * sin(p.a) * 0.2 - minor * sin(psi)
            let r = R * 0.24 * p.size
            let fire = heat * 0.95 + 0.25 * exp(-tau / 5) + 0.15 * Swift.max(0, sin(psi)) * exp(-tau / 4)
            let lit = RGB.mix(RGB(0.36, 0.28, 0.25), fireColor(fire), Swift.min(1, fire * 1.4))
            puff(&g, CGPoint(x: x, y: y), r, lit: lit, edge: RGB.mix(lit, RGB(0.08, 0.05, 0.05), 0.45),
                 alpha: front ? 0.97 : 0.9)
        }
        for p in ring { ringPuff(p, front: false) }

        // ——— шапка гриба
        for p in dome {
            let bx = sin(tau * p.speed + p.phase) * 0.045
            let by = cos(tau * p.speed * 0.8 + p.phase) * 0.035
            let x = cx + (p.a + bx) * R * sx
            let y = cy + (p.b + by) * R * sy
            let r = R * p.size * (1 + 0.07 * sin(tau * 1.3 * p.speed + p.phase))
            let low = Swift.min(1, Swift.max(0, (p.b + 0.7) / 0.95))
            let fire = heat * (0.35 + 0.65 * low) + 0.3 * low * exp(-tau / 6)
            let smoke = RGB.mix(RGB(0.22, 0.18, 0.17), RGB(0.38, 0.3, 0.26), low)
            let lit = RGB.mix(smoke, fireColor(fire), Swift.min(1, fire * 1.5))
            puff(&g, CGPoint(x: x, y: y), r, lit: lit, edge: RGB.mix(lit, RGB(0.06, 0.04, 0.04), 0.5), alpha: 0.97)
        }

        // ——— кольцо-тор (передняя половина)
        for p in ring { ringPuff(p, front: true) }

        // ——— раскалённое ядро
        if tau < 3.5 {
            let a = exp(-tau / 0.9)
            let fr = R * (0.9 + 0.3 * (1 - a))
            lighter.fill(Path(ellipseIn: CGRect(x: cx - fr * sx, y: cy - fr, width: fr * 2 * sx, height: fr * 2)),
                         with: .radialGradient(Gradient(stops: [
                            .init(color: .white.opacity(a), location: 0),
                            .init(color: Color(red: 1, green: 0.9, blue: 0.5).opacity(a * 0.9), location: 0.35),
                            .init(color: Color(red: 1, green: 0.45, blue: 0.1).opacity(a * 0.6), location: 0.7),
                            .init(color: .clear, location: 1)]),
                                               center: CGPoint(x: cx, y: cy + R * 0.1), startRadius: 0, endRadius: CGFloat(fr)))
        }

        // ——— кольцо конденсации (облако Вильсона)
        if tau > 0.6 && tau < 3.4 {
            let k = (tau - 0.6) / 2.8
            let a = sin(.pi * k) * 0.55
            let rr = w * (0.2 + 0.35 * k)
            let yy = ground - h * 0.2 - h * 0.08 * k
            g.drawLayer { l in
                l.addFilter(.blur(radius: 9))
                l.fill(Path(ellipseIn: CGRect(x: cx - rr, y: yy - rr * 0.12, width: rr * 2, height: rr * 0.24)),
                       with: .color(.white.opacity(a * 0.35)))
                l.stroke(Path(ellipseIn: CGRect(x: cx - rr, y: yy - rr * 0.12, width: rr * 2, height: rr * 0.24)),
                         with: .color(.white.opacity(a)), lineWidth: 10)
            }
        }

        // ——— искры и обломки
        for e in embers {
            let te = tau - e.delay
            guard te > 0, te < e.life else { continue }
            let v = e.speed * w * 1.1
            let x = cx + cos(e.angle) * v * te
            let y = ground - h * 0.06 - sin(e.angle) * v * te + 0.5 * h * 0.55 * te * te
            let a = 1 - te / e.life
            let c = RGB.mix(RGB(1, 0.35, 0.08), RGB(1, 0.95, 0.7), a)
            lighter.fill(Path(ellipseIn: CGRect(x: x - e.size, y: y - e.size, width: e.size * 2, height: e.size * 2)),
                         with: .color(c.color(a)))
        }

        // ——— земля и силуэт города
        let groundTop = RGB.mix(RGB(0.12, 0.06, 0.04), RGB(0.6, 0.35, 0.18), heat)
        g.fill(Path(CGRect(x: -60, y: ground, width: w + 120, height: h - ground + 60)),
               with: .linearGradient(Gradient(colors: [groundTop.color(), RGB(0.03, 0.02, 0.02).color()]),
                                     startPoint: CGPoint(x: 0, y: ground), endPoint: CGPoint(x: 0, y: h)))
        let dark = RGB.mix(RGB(0.05, 0.03, 0.03), RGB(0.25, 0.14, 0.08), heat * 0.6)
        let rim = RGB(1, 0.6, 0.25)
        let blast = Swift.min(1, Swift.max(0, (tau - 0.9) / 0.8))   // ударная волна дошла до домов
        for b in city where b.x < w + 60 {
            let bh = h * b.h * (1 - 0.35 * blast * (abs(b.x - cx) < w * 0.35 ? 1 : 0.4))
            let rect = CGRect(x: b.x, y: ground - bh, width: b.w, height: bh + 1)
            g.fill(Path(rect), with: .color(dark.color()))
            g.fill(Path(CGRect(x: b.x, y: ground - bh, width: b.w, height: 1.5)), with: .color(rim.color(0.35 + 0.6 * heat)))
            if b.windows > 2 && tau < 1.0 {
                g.fill(Path(CGRect(x: b.x + 4, y: ground - bh + 5, width: 4, height: 4)),
                       with: .color(Color.yellow.opacity(0.6 * (1 - tau))))
            }
        }

        // ——— пылевая волна у земли
        let spread = w * 1.15 * (1 - exp(-Swift.max(0, tau - 0.25) / 1.7))
        for p in base {
            let x = cx + p.a * spread + sin(tau * p.speed + p.phase) * 8
            let y = ground - p.b * h * 0.05 * (0.6 + rise) + 4
            let r = w * 0.055 * p.size * (0.5 + 0.9 * Swift.min(1, tau / 2))
            let lit = RGB.mix(RGB(0.42, 0.31, 0.24), RGB(1, 0.55, 0.2), 0.45 * heat)
            puff(&g, CGPoint(x: x, y: y), r, lit: lit, edge: RGB.mix(lit, RGB(0.08, 0.05, 0.04), 0.5),
                 alpha: 0.9 * (1 - 0.35 * abs(p.a)))
        }

        // ——— ударная волна по земле
        if tau < 1.8 {
            let rx = w * 1.3 * tau
            let a = 0.85 * (1 - tau / 1.8)
            g.drawLayer { l in
                l.addFilter(.blur(radius: 3))
                l.stroke(Path(ellipseIn: CGRect(x: cx - rx, y: ground - rx * 0.09, width: rx * 2, height: rx * 0.18)),
                         with: .color(Color(red: 1, green: 0.95, blue: 0.8).opacity(a)), lineWidth: 4)
            }
        }

        // ——— осколки экрана приложения
        if let snapshot, tau < 2.4 {
            let tw = w / Double(Self.cols), th = h / Double(Self.rows)
            for tile in tiles {
                let c0x = (Double(tile.col) + 0.5) * tw
                let c0y = (Double(tile.row) + 0.5) * th
                let dx = c0x - cx, dy = c0y - ground
                let dist = Swift.max(1, (dx * dx + dy * dy).squareRoot())
                let tt = Swift.max(0, tau - dist / h * 0.18)
                let v = 1500 * tile.power / (0.45 + dist / h)
                let px = c0x + dx / dist * v * tt + tile.jx * tt
                let py = c0y + dy / dist * v * tt + tile.jy * tt + 900 * tt * tt
                let alpha = Swift.max(0, 1 - tt / 1.4)
                guard alpha > 0 else { continue }
                var c = g
                c.opacity = alpha
                c.translateBy(x: CGFloat(px), y: CGFloat(py))
                c.rotate(by: .radians(tile.spin * tt))
                let s = 1 - 0.3 * Swift.min(1, tt)
                c.scaleBy(x: CGFloat(s), y: CGFloat(s))
                let local = CGRect(x: -tw / 2, y: -th / 2, width: tw, height: th)
                c.clip(to: Path(local))
                c.draw(snapshot, in: CGRect(x: -tw / 2 - Double(tile.col) * tw, y: -th / 2 - Double(tile.row) * th,
                                            width: w, height: h))
                c.fill(Path(local), with: .color(Color(red: 1, green: 0.5, blue: 0.1).opacity(0.5 * Swift.min(1, tt * 3) * (1 - Swift.min(1, tt)))))
                c.fill(Path(local), with: .color(.black.opacity(Swift.min(0.7, tt * 0.8))))
            }
        }

        // ——— виньетка
        g.fill(Path(full), with: .radialGradient(Gradient(colors: [.clear, .black.opacity(0.55)]),
                                                 center: CGPoint(x: cx, y: h * 0.45), startRadius: CGFloat(w * 0.45),
                                                 endRadius: CGFloat(Swift.max(w, h) * 0.85)))

        // ——— вспышка
        let flash = tau < 0.06 ? tau / 0.06 : exp(-(tau - 0.06) / 0.4)
        if flash > 0.005 {
            g.fill(Path(full), with: .color(Color(red: 1, green: 0.99, blue: 0.94).opacity(flash)))
        }
    }

    private func fireColor(_ f: Double) -> RGB {
        RGB.ramp(f, [(0, RGB(0.55, 0.16, 0.06)), (0.3, RGB(0.95, 0.35, 0.08)),
                     (0.6, RGB(1, 0.62, 0.18)), (0.85, RGB(1, 0.88, 0.5)), (1, RGB(1, 0.98, 0.85))])
    }

    private func puff(_ g: inout GraphicsContext, _ p: CGPoint, _ r: Double, lit: RGB, edge: RGB, alpha: Double) {
        guard r > 0.5 else { return }
        let rect = CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2)
        let grad = Gradient(stops: [
            .init(color: lit.color(alpha), location: 0),
            .init(color: edge.color(alpha * 0.95), location: 0.62),
            .init(color: edge.color(0), location: 1),
        ])
        g.fill(Path(ellipseIn: rect),
               with: .radialGradient(grad, center: CGPoint(x: p.x, y: p.y + r * 0.3), startRadius: 0, endRadius: CGFloat(r * 1.15)))
    }
}

// MARK: - Гул взрыва (синтез, без файлов)

final class NukeSound {
    private let engine = AVAudioEngine()
    private var node: AVAudioSourceNode?

    func play() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, options: [.mixWithOthers])
        try? session.setActive(true)

        let hw = engine.outputNode.outputFormat(forBus: 0).sampleRate
        let sr = hw > 0 ? hw : 44_100
        guard let format = AVAudioFormat(standardFormatWithSampleRate: sr, channels: 1) else { return }

        var frame = 0.0
        var brown = 0.0
        var deep = 0.0
        let node = AVAudioSourceNode(format: format) { _, _, frameCount, audioBufferList -> OSStatus in
            let buffers = UnsafeMutableAudioBufferListPointer(audioBufferList)
            for i in 0..<Int(frameCount) {
                let t = frame / sr
                frame += 1
                let white = Double.random(in: -1...1)
                brown = (brown + 0.02 * white) / 1.02
                deep = (deep + 0.004 * white) / 1.004
                // удар → долгий гул → второй удар (ударная волна) → затихание
                var env = t < 0.015 ? t / 0.015 : exp(-(t - 0.015) / 1.7)
                if t > 1.1 { env += 0.85 * exp(-(t - 1.1) / 1.3) * Swift.min(1, (t - 1.1) / 0.03) }
                env += 0.22 * exp(-t / 5)
                var s = (brown * 3.4 + deep * 11) * env
                if Double.random(in: 0...1) < 0.0015 * exp(-t / 2.5) { s += Double.random(in: -0.5...0.5) }
                let v = Float(tanh(s * 1.5) * 0.95)
                for b in buffers {
                    guard let p = b.mData?.assumingMemoryBound(to: Float.self) else { continue }
                    p[i] = v
                }
            }
            return noErr
        }
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: format)
        engine.mainMixerNode.outputVolume = 1
        do { try engine.start() } catch { return }
        self.node = node
    }

    func stop() {
        guard node != nil else { return }
        engine.stop()
        node = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}

// MARK: - Вибрация

final class NukeRumble {
    private var engine: CHHapticEngine?

    func play() {
        guard UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true else { return }
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { fallback(); return }
        do {
            let e = try CHHapticEngine()
            try e.start()
            func p(_ id: CHHapticEvent.ParameterID, _ v: Float) -> CHHapticEventParameter {
                CHHapticEventParameter(parameterID: id, value: v)
            }
            let events = [
                CHHapticEvent(eventType: .hapticTransient, parameters: [p(.hapticIntensity, 1), p(.hapticSharpness, 1)], relativeTime: 0),
                CHHapticEvent(eventType: .hapticContinuous, parameters: [p(.hapticIntensity, 1), p(.hapticSharpness, 0.15)],
                              relativeTime: 0.02, duration: 1.1),
                CHHapticEvent(eventType: .hapticTransient, parameters: [p(.hapticIntensity, 1), p(.hapticSharpness, 0.7)], relativeTime: 1.1),
                CHHapticEvent(eventType: .hapticContinuous, parameters: [p(.hapticIntensity, 1), p(.hapticSharpness, 0.05)],
                              relativeTime: 1.12, duration: 3.5),
            ]
            let curve = CHHapticParameterCurve(parameterID: .hapticIntensityControl, controlPoints: [
                .init(relativeTime: 0, value: 1),
                .init(relativeTime: 1.0, value: 0.5),
                .init(relativeTime: 1.12, value: 1),
                .init(relativeTime: 2.5, value: 0.55),
                .init(relativeTime: 4.6, value: 0),
            ], relativeTime: 0)
            let pattern = try CHHapticPattern(events: events, parameterCurves: [curve])
            let player = try e.makePlayer(with: pattern)
            try player.start(atTime: CHHapticTimeImmediate)
            engine = e
        } catch {
            fallback()
        }
    }

    private func fallback() {
        let gen = UIImpactFeedbackGenerator(style: .heavy)
        for (i, d) in [0.0, 0.08, 0.16, 0.3, 1.1, 1.2, 1.35, 1.6].enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + d) { gen.impactOccurred(intensity: i < 2 || i == 4 ? 1 : 0.7) }
        }
    }

    func stop() {
        engine?.stop()
        engine = nil
    }
}
