import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

// MARK: - ИИ Apple прямо на телефоне (iOS 26, Apple Intelligence)
// Бесплатно и без интернета. Работает, только если на iPhone включён Apple Intelligence
// и модель поддерживает русский — иначе приложение само выберет другой способ.

enum AppleLLM {
    static var isAvailable: Bool { status.ok }

    private static var cached: (value: (ok: Bool, text: String), at: Date)?

    /// Доступен ли ИИ Apple и почему нет (запоминаем на минуту)
    static var status: (ok: Bool, text: String) {
        if let c = cached, Date().timeIntervalSince(c.at) < 60 { return c.value }
        let v = readStatus()
        cached = (v, Date())
        return v
    }

    private static func readStatus() -> (ok: Bool, text: String) {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let m = SystemLanguageModel.default
            switch m.availability {
            case .available:
                let ru = m.supportedLanguages.contains { $0.languageCode?.identifier == "ru" }
                return ru ? (true, "Доступен") : (false, "Модель Apple пока не знает русский")
            case .unavailable(.deviceNotEligible):
                return (false, "Этот iPhone не поддерживает Apple Intelligence (нужен 15 Pro или новее)")
            case .unavailable(.appleIntelligenceNotEnabled):
                return (false, "Включи Apple Intelligence: Настройки → Apple Intelligence и Siri")
            case .unavailable(.modelNotReady):
                return (false, "Модель ещё скачивается — подожди на Wi-Fi и на зарядке")
            case .unavailable:
                return (false, "ИИ Apple недоступен")
            @unknown default:
                return (false, "ИИ Apple недоступен")
            }
        }
        #endif
        return (false, "Нужен iOS 26 и Apple Intelligence")
    }

    static func complete(system: String, user: String) async throws -> String {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let session = LanguageModelSession(instructions: system)
            let response = try await session.respond(to: user)
            return response.content
        }
        #endif
        throw NSError(domain: "AppleLLM", code: 1,
                      userInfo: [NSLocalizedDescriptionKey: "ИИ Apple недоступен на этом iPhone"])
    }
}
