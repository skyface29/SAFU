import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

// MARK: - ИИ Apple прямо на телефоне (iOS 26, Apple Intelligence)
// Бесплатно и без интернета. Работает, только если на iPhone включён Apple Intelligence
// и модель поддерживает русский — иначе приложение само выберет другой способ.

enum AppleLLM {
    static var isAvailable: Bool {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let m = SystemLanguageModel.default
            guard m.isAvailable else { return false }
            return m.supportedLanguages.contains { $0.languageCode?.identifier == "ru" }
        }
        #endif
        return false
    }

    static func complete(system: String, user: String) async throws -> String {
        #if canImport(FoundationModels)
        if #available(iOS 26.0, *) {
            let session = LanguageModelSession(instructions: system)
            let response = try await session.respond(to: user)
            return response.content
        }
        #endif
        throw NSError(domain: "AppleLLM", code: 1,
                      userInfo: [NSLocalizedDescriptionKey: "ИИ Apple недоступен на этом iPhone"])
    }
}
