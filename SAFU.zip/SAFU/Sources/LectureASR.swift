import Foundation
import WhisperKit

// MARK: - Распознавание речи лекции: Whisper на телефоне (WhisperKit)
// Модель скачивается один раз с Hugging Face, дальше всё работает без интернета.

struct SpeechSegment: Codable, Hashable {
    var start: Double
    var end: Double
    var text: String
}

enum LectureASR {
    struct Model: Identifiable, Hashable {
        let id: String
        let title: String
        let note: String
    }

    static let models: [Model] = [
        Model(id: "openai_whisper-large-v3-v20240930_turbo_632MB", title: "Точная",
              note: "Whisper Large v3 Turbo · ~630 МБ · лучше всего понимает русский"),
        Model(id: "openai_whisper-small", title: "Быстрая",
              note: "Whisper Small · ~250 МБ · быстрее, но ошибается чаще"),
    ]

    static var selected: String {
        UserDefaults.standard.string(forKey: "lecture.model") ?? models[0].id
    }

    /// Расшифровка файла: список фраз с временем начала и конца
    static func transcribe(url: URL, model: String) async throws -> [SpeechSegment] {
        let pipe = try await WhisperKit(WhisperKitConfig(model: model))
        let options = DecodingOptions(language: "ru", skipSpecialTokens: true, chunkingStrategy: .vad)
        let results = try await pipe.transcribe(audioPath: url.path, decodeOptions: options)
        var out: [SpeechSegment] = []
        for r in results {
            for s in r.segments {
                let text = clean(s.text)
                if !text.isEmpty { out.append(SpeechSegment(start: Double(s.start), end: Double(s.end), text: text)) }
            }
        }
        return out.sorted { $0.start < $1.start }
    }

    /// Убираем служебные метки модели вида <|0.00|> и лишние пробелы
    static func clean(_ s: String) -> String {
        s.replacingOccurrences(of: "<\\|[^|]*\\|>", with: "", options: .regularExpression)
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
