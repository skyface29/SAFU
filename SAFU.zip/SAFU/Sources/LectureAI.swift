import Foundation
import Security

// MARK: - Кто пишет конспект
// GigaChat (Сбер) — бесплатный пакет для физлиц, работает в России без VPN.
// ИИ Apple — прямо на телефоне (iOS 26, iPhone 15 Pro и новее), если поддерживает русский.
// Claude — если есть свой ключ. Без ИИ — простой конспект на телефоне.

enum LectureAI: String, CaseIterable, Identifiable {
    case auto, gigachat, apple, claude, local
    var id: String { rawValue }
    var title: String {
        switch self {
        case .auto: return "Авто"
        case .gigachat: return "GigaChat"
        case .apple: return "ИИ Apple"
        case .claude: return "Claude"
        case .local: return "Без ИИ"
        }
    }

    static var selected: LectureAI {
        LectureAI(rawValue: UserDefaults.standard.string(forKey: "lecture.ai") ?? "") ?? .auto
    }

    /// Что реально будет работать сейчас
    static func resolved() -> LectureAI {
        switch selected {
        case .auto:
            if GigaKey.value != nil { return .gigachat }
            if AppleLLM.isAvailable { return .apple }
            if ClaudeKey.value != nil { return .claude }
            return .local
        case .gigachat: return GigaKey.value != nil ? .gigachat : .local
        case .apple: return AppleLLM.isAvailable ? .apple : .local
        case .claude: return ClaudeKey.value != nil ? .claude : .local
        case .local: return .local
        }
    }

    var badge: String {
        switch self {
        case .gigachat: return "GigaChat"
        case .apple: return "ИИ Apple"
        case .claude: return "Claude"
        default: return "без ИИ"
        }
    }
}

// MARK: - Пересказ длинной лекции кусками (для моделей с небольшим контекстом)

enum LectureMapReduce {
    typealias Complete = (_ system: String, _ user: String) async throws -> String

    private static func words(_ s: String) -> [Substring] { s.split(whereSeparator: { $0 == " " || $0 == "\n" }) }

    private static func chunks(_ text: String, size: Int) -> [String] {
        let w = words(text)
        guard w.count > size else { return [text] }
        return stride(from: 0, to: w.count, by: size).map { w[$0..<min($0 + size, w.count)].joined(separator: " ") }
    }

    static let chunkSystem = """
    Ты помогаешь студенту конспектировать лекцию по автоматической расшифровке речи (в ней бывают ошибки — исправляй по смыслу).
    Выпиши из фрагмента главное: ключевые мысли, определения, формулы, примеры, задания и сроки.
    Пометка [ВАЖНО] — это студент отметил как важное: сохрани обязательно. Пиши кратко, списком, по-русски. Ничего не выдумывай.
    """

    static func finalSystem(_ style: LectureStyle) -> String {
        """
        Ты делаешь конспект университетской лекции для студента САФУ. \(style.instruction)
        Ничего не выдумывай — только то, что было в лекции. Пиши по-русски.
        Верни ТОЛЬКО JSON без пояснений и без markdown, строго такого вида:
        {"title":"тема","summary":"3–5 предложений о чём лекция","keyPoints":["главная мысль"],"sections":[{"heading":"раздел","points":["пункт"]}],"terms":[{"term":"термин","definition":"определение"}],"formulas":["формула"],"questions":["что могут спросить на экзамене"],"tasks":["задание или срок"]}
        Если чего-то в лекции не было — оставь пустой список.
        """
    }

    /// Возвращает готовый конспект, а если модель не выдала JSON — её текст как есть
    static func run(_ l: Lecture, style: LectureStyle, chunkWords: Int, finalWords: Int,
                    complete: Complete) async throws -> (LectureSummary?, String) {
        var notes = LectureSummarizer.transcriptForAI(l)
        // сжимаем, пока не влезет в одну финальную просьбу
        var round = 0
        while words(notes).count > finalWords && round < 4 {
            let parts = chunks(notes, size: chunkWords)
            var out: [String] = []
            for (i, p) in parts.enumerated() {
                let r = try await complete(chunkSystem, "Фрагмент \(i + 1) из \(parts.count):\n\n\(p)")
                out.append(r)
            }
            notes = out.joined(separator: "\n")
            round += 1
        }
        let subject = l.subject.isEmpty ? "не указан" : l.subject
        let answer = try await complete(finalSystem(style), "Предмет: \(subject)\n\nМатериал лекции:\n\n\(notes)")
        return (parse(answer), answer)
    }

    static func parse(_ text: String) -> LectureSummary? {
        guard let a = text.firstIndex(of: "{"), let b = text.lastIndex(of: "}"), a < b else { return nil }
        let json = String(text[a...b])
        return json.data(using: .utf8).flatMap { try? JSONDecoder().decode(LectureSummary.self, from: $0) }
    }
}

// MARK: - GigaChat (Сбер)

enum GigaKey {
    private static let key = "gigachat.key"
    static var value: String? {
        guard let d = Keychain.get(key), let s = String(data: d, encoding: .utf8), !s.isEmpty else { return nil }
        return s
    }
    static func set(_ s: String) {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { Keychain.delete(key) } else { Keychain.set(Data(t.utf8), for: key) }
    }
}

/// Серверы GigaChat подписаны сертификатом «Russian Trusted Root CA» (Минцифры), которому iOS по умолчанию не доверяет.
/// Доверяем ему только для доменов Сбера. SHA-256: D2:6D:2D:02:31:B7:C3:9F:92:CC:73:85:12:BA:54:10:35:19:E4:40:5D:68:B5:BD:70:3E:97:88:CA:8E:CF:31
final class GigaTrust: NSObject, URLSessionDelegate {
    private static let rootB64 = "MIIFwjCCA6qgAwIBAgICEAAwDQYJKoZIhvcNAQELBQAwcDELMAkGA1UEBhMCUlUxPzA9BgNVBAoMNlRoZSBNaW5pc3RyeSBvZiBEaWdpdGFsIERldmVsb3BtZW50IGFuZCBDb21tdW5pY2F0aW9uczEgMB4GA1UEAwwXUnVzc2lhbiBUcnVzdGVkIFJvb3QgQ0EwHhcNMjIwMzAxMjEwNDE1WhcNMzIwMjI3MjEwNDE1WjBwMQswCQYDVQQGEwJSVTE/MD0GA1UECgw2VGhlIE1pbmlzdHJ5IG9mIERpZ2l0YWwgRGV2ZWxvcG1lbnQgYW5kIENvbW11bmljYXRpb25zMSAwHgYDVQQDDBdSdXNzaWFuIFRydXN0ZWQgUm9vdCBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMfFOZ8pUAL3+r2nqqE0Zp52selXsKGFYoG0GM5bwz1bSFtCt+AZQMhkWQheI3poZAToYJu69pHLKS6QXBiwBC1cvzYmUYKMYZC7jE5YhEU2bSL0mX7NaMxMDmH2/NwuOVRj8OImVa5s1F4Uzn4Kv3PFlDBjjSjXKVY9kmjUBsXQrIHeaqmUIsPIlNWUnimXS0I0abExqkbdrXbXYwCOXhOO2pDUx3ckmJlCMUGacUTnylyQW2VsJIyIGA8V0xzdaeUXg0VZ6ZmNUr5YBer/EAOLPb8NYpsAhJe2mXjMB/J9HNsoFMBFJ0lLOT/+dQvjbdRZoOT8eqJpWnVDU+QL/qEZnz57N88OWM3rabJkRNdU/Z7x5SFIM9FrqtN8xewsiBWBI0K6XFuOBOTD4V08o4TzJ8+Ccq5XlCUW2L48pZNCYuBDfBh7FxkB7qDgGDiaftEkZZfApRg2E+M9G8wkNKTPLDc4wH0FDTijhgxR3Y4PiS1HL2Zhw7bD3CbslmEGgfnnZojNkJtcLeBHBLa52/dSwNU4WWLubaYSiAmA9IUMX1/RpfpxOxd4Ykmhz97oFbUaDJFipIggx5sXePAlkTdWnv+RWBxlJwMQ25oEHmRguNYf4Zr/Rxr9cS93Y+mdXIZaBEE0KS2iLRqaOiWBki9IMQU4phqPOBAaG7A+eP8PAgMBAAGjZjBkMB0GA1UdDgQWBBTh0YHlzlpfBKrS6badZrHF+qwshzAfBgNVHSMEGDAWgBTh0YHlzlpfBKrS6badZrHF+qwshzASBgNVHRMBAf8ECDAGAQH/AgEEMA4GA1UdDwEB/wQEAwIBhjANBgkqhkiG9w0BAQsFAAOCAgEAALIY1wkilt/urfEVM5vKzr6utOeDWCUczmWX/RX4ljpRdgF+5fAIS4vHtmXkqpSCOVeWUrJV9QvZn6L227ZwuE15cWi8DCDal3Ue90WgAJJZMfTshN4OI8cqW9E4EG9wglbEtMnObHlms8F3CHmrw3k6KmUkWGoa+/ENmcVl68u/cMRl1JbW2bM+/3A+SAg2c6iPDlehczKx2oa95QW0SkPPWGuNA/CE8CpyANIhu9XFrj3RQ3EqeRcSAQQod1RNuHpfETLU/A2gMmvn/w/sx7TB3W5BPs6rprOA37tutPq9u6FTZOcG1OqjC/B7yTqgI7rbyvox7DEXoX7rIiEqyNNUguTk/u3SZ4VXE2kmxdmSh3TQvybfbnXV4JbCZVaqiZraqc7oZMnRoWrXRG3ztbnbes/9qhRGI7PqXqeKJBztxRTEVj8ONs1dWN5szTwaPIvhkhO3CO5ErU2rVdUr89wKpNXbBODFKRtgxUT70YpmJ46VVaqdAhOZD9EUUn4YaeLaS8AjSF/h7UkjOibNc4qVDiPP+rkehFWM66PVnP1Msh93tc+taIfCEYVMxjh8zNbFuoc7fzvvrFILLe7ifvEIUqSVIC/AzplM/Jxw7buXFeGP1qVCBEHq391d/9RAfaZ12zkwFsl+IKwE/OZxW8AHa9i1p4GO0YSNuczzEm4="
    static let root: SecCertificate? = Data(base64Encoded: rootB64).flatMap { SecCertificateCreateWithData(nil, $0 as CFData) }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        let space = challenge.protectionSpace
        guard space.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = space.serverTrust,
              space.host == "ngw.devices.sberbank.ru" || space.host == "gigachat.devices.sberbank.ru",
              let root = Self.root else {
            completionHandler(.performDefaultHandling, nil)
            return
        }
        SecTrustSetAnchorCertificates(trust, [root] as CFArray)
        SecTrustSetAnchorCertificatesOnly(trust, false)
        var error: CFError?
        if SecTrustEvaluateWithError(trust, &error) {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}

enum GigaChat {
    enum Failure: LocalizedError {
        case http(Int, String)
        case badAnswer
        var errorDescription: String? {
            switch self {
            case .http(401, _): return "GigaChat не принял ключ авторизации — проверь его в настройках"
            case .http(402, _): return "Закончились бесплатные токены GigaChat в этом месяце"
            case .http(429, _): return "GigaChat просит подождать — слишком много запросов"
            case .http(let c, let m): return "GigaChat ответил \(c): \(m)"
            case .badAnswer: return "Не удалось разобрать ответ GigaChat"
            }
        }
    }

    static let models: [(id: String, title: String)] = [("GigaChat", "Lite"), ("GigaChat-Pro", "Pro"), ("GigaChat-Max", "Max")]
    static var model: String { UserDefaults.standard.string(forKey: "gigachat.model") ?? "GigaChat" }

    private static let session = URLSession(configuration: .default, delegate: GigaTrust(), delegateQueue: nil)
    private static var token: (value: String, until: Date)?

    private static func accessToken(_ authKey: String) async throws -> String {
        if let t = token, t.until > Date().addingTimeInterval(60) { return t.value }
        guard let url = URL(string: "https://ngw.devices.sberbank.ru:9443/api/v2/oauth") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        let basic = authKey.hasPrefix("Basic ") ? authKey : "Basic \(authKey)"
        req.setValue(basic, forHTTPHeaderField: "Authorization")
        req.setValue(UUID().uuidString, forHTTPHeaderField: "RqUID")
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.httpBody = Data("scope=GIGACHAT_API_PERS".utf8)
        let (data, resp) = try await session.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        guard code == 200, let value = obj?["access_token"] as? String else {
            throw Failure.http(code, String((String(data: data, encoding: .utf8) ?? "").prefix(200)))
        }
        let ms = (obj?["expires_at"] as? Double) ?? (Date().timeIntervalSince1970 + 1500) * 1000
        token = (value, Date(timeIntervalSince1970: ms / 1000))
        return value
    }

    static func complete(system: String, user: String) async throws -> String {
        guard let key = GigaKey.value else { throw Failure.http(401, "") }
        let t = try await accessToken(key)
        guard let url = URL(string: "https://gigachat.devices.sberbank.ru/api/v1/chat/completions") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 180
        req.setValue("Bearer \(t)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let body: [String: Any] = [
            "model": model,
            "messages": [["role": "system", "content": system], ["role": "user", "content": user]],
            "max_tokens": 3000,
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, resp) = try await session.data(for: req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        if code == 401 { token = nil }
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        guard code == 200,
              let choices = obj?["choices"] as? [[String: Any]],
              let msg = choices.first?["message"] as? [String: Any],
              let content = msg["content"] as? String else {
            throw Failure.http(code, String(((obj?["message"] as? String) ?? String(data: data, encoding: .utf8) ?? "").prefix(200)))
        }
        return content
    }
}
