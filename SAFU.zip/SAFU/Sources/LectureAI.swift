import Foundation
import Security

// MARK: - Кто пишет конспект
// GigaChat (Сбер) — бесплатный пакет для физлиц, работает в России без VPN.
// ИИ Apple — прямо на телефоне (iOS 26, iPhone 15 Pro и новее), если поддерживает русский.
// Claude — если есть свой ключ. Без ИИ — простой конспект на телефоне.

enum LectureAI: String, CaseIterable, Identifiable {
    case auto, gigachat, apple, claude, local
    var id: String { rawValue }
    var title: String {
        switch self {
        case .auto: return "Авто"
        case .gigachat: return "GigaChat"
        case .apple: return "ИИ Apple"
        case .claude: return "Claude"
        case .local: return "Без ИИ"
        }
    }

    static var selected: LectureAI {
        LectureAI(rawValue: UserDefaults.standard.string(forKey: "lecture.ai") ?? "") ?? .auto
    }

    /// Что реально будет работать сейчас
    static func resolved() -> LectureAI {
        switch selected {
        case .auto:
            if GigaKey.value != nil { return .gigachat }
            if AppleLLM.isAvailable { return .apple }
            if ClaudeKey.value != nil { return .claude }
            return .local
        case .gigachat: return GigaKey.value != nil ? .gigachat : .local
        case .apple: return AppleLLM.isAvailable ? .apple : .local
        case .claude: return ClaudeKey.value != nil ? .claude : .local
        case .local: return .local
        }
    }

    var badge: String {
        switch self {
        case .gigachat: return "GigaChat"
        case .apple: return "ИИ Apple"
        case .claude: return "Claude"
        default: return "без ИИ"
        }
    }
}

// MARK: - Пересказ длинной лекции кусками (для моделей с небольшим контекстом)

enum LectureMapReduce {
    typealias Complete = (_ system: String, _ user: String) async throws -> String

    private static func words(_ s: String) -> [Substring] { s.split(whereSeparator: { $0 == " " || $0 == "\n" }) }

    private static func chunks(_ text: String, size: Int) -> [String] {
        let w = words(text)
        guard w.count > size else { return [text] }
        return stride(from: 0, to: w.count, by: size).map { w[$0..<min($0 + size, w.count)].joined(separator: " ") }
    }

    static let chunkSystem = """
    Ты помогаешь студенту конспектировать лекцию по автоматической расшифровке речи (в ней бывают ошибки — исправляй по смыслу).
    Выпиши из фрагмента главное: ключевые мысли, определения, формулы, примеры, задания и сроки.
    Пометка [ВАЖНО] — это студент отметил как важное: сохрани обязательно. Пиши кратко, списком, по-русски. Ничего не выдумывай.
    """

    static func finalSystem(_ style: LectureStyle) -> String {
        """
        Ты делаешь конспект университетской лекции для студента САФУ. \(style.instruction)
        Ничего не выдумывай — только то, что было в лекции. Пиши по-русски.
        Верни ТОЛЬКО JSON без пояснений и без markdown, строго такого вида:
        {"title":"тема","summary":"3–5 предложений о чём лекция","keyPoints":["главная мысль"],"sections":[{"heading":"раздел","points":["пункт"]}],"terms":[{"term":"термин","definition":"определение"}],"formulas":["формула"],"questions":["что могут спросить на экзамене"],"tasks":["задание или срок"]}
        Если чего-то в лекции не было — оставь пустой список.
        """
    }

    /// Возвращает готовый конспект, а если модель не выдала JSON — её текст как есть
    static func run(_ l: Lecture, style: LectureStyle, chunkWords: Int, finalWords: Int,
                    complete: Complete) async throws -> (LectureSummary?, String) {
        var notes = LectureSummarizer.transcriptForAI(l)
        // сжимаем, пока не влезет в одну финальную просьбу
        var round = 0
        while words(notes).count > finalWords && round < 4 {
            let parts = chunks(notes, size: chunkWords)
            var out: [String] = []
            for (i, p) in parts.enumerated() {
                let r = try await complete(chunkSystem, "Фрагмент \(i + 1) из \(parts.count):\n\n\(p)")
                out.append(r)
            }
            notes = out.joined(separator: "\n")
            round += 1
        }
        let subject = l.subject.isEmpty ? "не указан" : l.subject
        let answer = try await complete(finalSystem(style), "Предмет: \(subject)\n\nМатериал лекции:\n\n\(notes)")
        return (parse(answer), answer)
    }

    /// Разбор без строгости: GigaChat и ИИ Apple иногда пропускают поля или оборачивают JSON в текст
    static func parse(_ text: String) -> LectureSummary? {
        guard let a = text.firstIndex(of: "{"), let b = text.lastIndex(of: "}"), a < b,
              let data = String(text[a...b]).data(using: .utf8),
              let o = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return nil }
        func str(_ v: Any?) -> String { (v as? String)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "" }
        func list(_ v: Any?) -> [String] {
            ((v as? [Any]) ?? []).compactMap { (item: Any) -> String? in
                if let s = item as? String { return s }
                if let d = item as? [String: Any] { return d.values.compactMap { $0 as? String }.joined(separator: " — ") }
                return nil
            }.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        }
        let sections = ((o["sections"] as? [[String: Any]]) ?? []).compactMap { d -> LectureSummary.Section? in
            let pts = list(d["points"])
            return pts.isEmpty ? nil : LectureSummary.Section(heading: str(d["heading"]).isEmpty ? "Раздел" : str(d["heading"]), points: pts)
        }
        let terms = ((o["terms"] as? [[String: Any]]) ?? []).compactMap { d -> LectureSummary.Term? in
            let t = str(d["term"])
            return t.isEmpty ? nil : LectureSummary.Term(term: t, definition: str(d["definition"]))
        }
        let s = LectureSummary(title: str(o["title"]).isEmpty ? "Лекция" : str(o["title"]), summary: str(o["summary"]),
                               keyPoints: list(o["keyPoints"]), sections: sections, terms: terms,
                               formulas: list(o["formulas"]), questions: list(o["questions"]), tasks: list(o["tasks"]))
        if s.summary.isEmpty && s.keyPoints.isEmpty && s.sections.isEmpty { return nil }
        return s
    }
}

// MARK: - GigaChat (Сбер)

enum GigaKey {
    private static let key = "gigachat.key"
    static var value: String? {
        guard let d = Keychain.get(key), let s = String(data: d, encoding: .utf8), !s.isEmpty else { return nil }
        return s
    }
    static func set(_ s: String) {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t == (value ?? "") { return }
        if t.isEmpty { Keychain.delete(key) } else { Keychain.set(Data(t.utf8), for: key) }
        GigaChat.resetToken()
    }
}

/// Серверы GigaChat подписаны сертификатом «Russian Trusted Root CA» (Минцифры), которому iOS по умолчанию не доверяет.
/// Доверяем ему только для доменов Сбера. SHA-256: D2:6D:2D:02:31:B7:C3:9F:92:CC:73:85:12:BA:54:10:35:19:E4:40:5D:68:B5:BD:70:3E:97:88:CA:8E:CF:31
final class GigaTrust: NSObject, URLSessionDelegate {
    private static let rootB64 = "MIIFwjCCA6qgAwIBAgICEAAwDQYJKoZIhvcNAQELBQAwcDELMAkGA1UEBhMCUlUxPzA9BgNVBAoMNlRoZSBNaW5pc3RyeSBvZiBEaWdpdGFsIERldmVsb3BtZW50IGFuZCBDb21tdW5pY2F0aW9uczEgMB4GA1UEAwwXUnVzc2lhbiBUcnVzdGVkIFJvb3QgQ0EwHhcNMjIwMzAxMjEwNDE1WhcNMzIwMjI3MjEwNDE1WjBwMQswCQYDVQQGEwJSVTE/MD0GA1UECgw2VGhlIE1pbmlzdHJ5IG9mIERpZ2l0YWwgRGV2ZWxvcG1lbnQgYW5kIENvbW11bmljYXRpb25zMSAwHgYDVQQDDBdSdXNzaWFuIFRydXN0ZWQgUm9vdCBDQTCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMfFOZ8pUAL3+r2nqqE0Zp52selXsKGFYoG0GM5bwz1bSFtCt+AZQMhkWQheI3poZAToYJu69pHLKS6QXBiwBC1cvzYmUYKMYZC7jE5YhEU2bSL0mX7NaMxMDmH2/NwuOVRj8OImVa5s1F4Uzn4Kv3PFlDBjjSjXKVY9kmjUBsXQrIHeaqmUIsPIlNWUnimXS0I0abExqkbdrXbXYwCOXhOO2pDUx3ckmJlCMUGacUTnylyQW2VsJIyIGA8V0xzdaeUXg0VZ6ZmNUr5YBer/EAOLPb8NYpsAhJe2mXjMB/J9HNsoFMBFJ0lLOT/+dQvjbdRZoOT8eqJpWnVDU+QL/qEZnz57N88OWM3rabJkRNdU/Z7x5SFIM9FrqtN8xewsiBWBI0K6XFuOBOTD4V08o4TzJ8+Ccq5XlCUW2L48pZNCYuBDfBh7FxkB7qDgGDiaftEkZZfApRg2E+M9G8wkNKTPLDc4wH0FDTijhgxR3Y4PiS1HL2Zhw7bD3CbslmEGgfnnZojNkJtcLeBHBLa52/dSwNU4WWLubaYSiAmA9IUMX1/RpfpxOxd4Ykmhz97oFbUaDJFipIggx5sXePAlkTdWnv+RWBxlJwMQ25oEHmRguNYf4Zr/Rxr9cS93Y+mdXIZaBEE0KS2iLRqaOiWBki9IMQU4phqPOBAaG7A+eP8PAgMBAAGjZjBkMB0GA1UdDgQWBBTh0YHlzlpfBKrS6badZrHF+qwshzAfBgNVHSMEGDAWgBTh0YHlzlpfBKrS6badZrHF+qwshzASBgNVHRMBAf8ECDAGAQH/AgEEMA4GA1UdDwEB/wQEAwIBhjANBgkqhkiG9w0BAQsFAAOCAgEAALIY1wkilt/urfEVM5vKzr6utOeDWCUczmWX/RX4ljpRdgF+5fAIS4vHtmXkqpSCOVeWUrJV9QvZn6L227ZwuE15cWi8DCDal3Ue90WgAJJZMfTshN4OI8cqW9E4EG9wglbEtMnObHlms8F3CHmrw3k6KmUkWGoa+/ENmcVl68u/cMRl1JbW2bM+/3A+SAg2c6iPDlehczKx2oa95QW0SkPPWGuNA/CE8CpyANIhu9XFrj3RQ3EqeRcSAQQod1RNuHpfETLU/A2gMmvn/w/sx7TB3W5BPs6rprOA37tutPq9u6FTZOcG1OqjC/B7yTqgI7rbyvox7DEXoX7rIiEqyNNUguTk/u3SZ4VXE2kmxdmSh3TQvybfbnXV4JbCZVaqiZraqc7oZMnRoWrXRG3ztbnbes/9qhRGI7PqXqeKJBztxRTEVj8ONs1dWN5szTwaPIvhkhO3CO5ErU2rVdUr89wKpNXbBODFKRtgxUT70YpmJ46VVaqdAhOZD9EUUn4YaeLaS8AjSF/h7UkjOibNc4qVDiPP+rkehFWM66PVnP1Msh93tc+taIfCEYVMxjh8zNbFuoc7fzvvrFILLe7ifvEIUqSVIC/AzplM/Jxw7buXFeGP1qVCBEHq391d/9RAfaZ12zkwFsl+IKwE/OZxW8AHa9i1p4GO0YSNuczzEm4="
    static let root: SecCertificate? = Data(base64Encoded: rootB64).flatMap { SecCertificateCreateWithData(nil, $0 as CFData) }

    /// Хосты, для которых добавляем корень Минцифры (gu-st.ru — сайт, откуда докачиваем промежуточный сертификат)
    static let hosts: Set<String> = ["ngw.devices.sberbank.ru", "gigachat.devices.sberbank.ru", "gu-st.ru"]

    /// Почему не удалось проверить соединение в последний раз (для экрана проверки)
    static var lastError: String?

    private static var cacheURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("russian_trusted_sub_ca.der")
    }

    /// Промежуточный сертификат «Russian Trusted Sub CA»: из сборки или скачанный раньше
    static var intermediates: [SecCertificate] {
        var out: [SecCertificate] = []
        if let u = Bundle.main.url(forResource: "RussianTrustedSub", withExtension: "cer"),
           let d = try? Data(contentsOf: u), let c = SecCertificateCreateWithData(nil, d as CFData) { out.append(c) }
        if let d = try? Data(contentsOf: cacheURL), let c = SecCertificateCreateWithData(nil, d as CFData) { out.append(c) }
        return out
    }

    /// Подписан ли сертификат корнем Минцифры
    static func signedByRoot(_ cert: SecCertificate) -> Bool {
        guard let root else { return false }
        var trust: SecTrust?
        guard SecTrustCreateWithCertificates(cert, SecPolicyCreateBasicX509(), &trust) == errSecSuccess, let trust else { return false }
        SecTrustSetAnchorCertificates(trust, [root] as CFArray)
        SecTrustSetAnchorCertificatesOnly(trust, true)
        return SecTrustEvaluateWithError(trust, nil)
    }

    /// Докачиваем промежуточный сертификат с сайта Минцифры и сохраняем, только если его подписал корень
    static func fetchIntermediate(session: URLSession) async -> Bool {
        let urls = ["https://gu-st.ru/content/lending/russian_trusted_sub_ca_pem.crt",
                    "https://gu-st.ru/content/Other/doc/russian_trusted_sub_ca.cer"]
        for s in urls {
            guard let url = URL(string: s), let res = try? await session.data(from: url) else { continue }
            let data = res.0
            var der = data
            if let text = String(data: data, encoding: .ascii), text.contains("BEGIN CERTIFICATE") {
                let b64 = text.components(separatedBy: "\n").filter { !$0.hasPrefix("-----") }.joined()
                der = Data(base64Encoded: b64, options: .ignoreUnknownCharacters) ?? Data()
            }
            if let c = SecCertificateCreateWithData(nil, der as CFData), signedByRoot(c) {
                try? der.write(to: cacheURL, options: .atomic)
                return true
            }
        }
        return false
    }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        let space = challenge.protectionSpace
        guard space.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = space.serverTrust,
              Self.hosts.contains(space.host),
              let root = Self.root else {
            completionHandler(.performDefaultHandling, nil)
            return
        }
        // цепочка от сервера + промежуточный сертификат, якорь — только корень Минцифры (плюс обычные корни iOS)
        var certs = (SecTrustCopyCertificateChain(trust) as? [SecCertificate]) ?? []
        certs += Self.intermediates
        var check: SecTrust?
        guard SecTrustCreateWithCertificates(certs as CFArray, SecPolicyCreateSSL(true, space.host as CFString), &check) == errSecSuccess,
              let check else {
            completionHandler(.cancelAuthenticationChallenge, nil)
            return
        }
        SecTrustSetAnchorCertificates(check, [root] as CFArray)
        SecTrustSetAnchorCertificatesOnly(check, false)
        // если промежуточного нет — iOS может докачать его сама
        SecTrustSetNetworkFetchAllowed(check, true)
        var error: CFError?
        if SecTrustEvaluateWithError(check, &error) {
            Self.lastError = nil
            completionHandler(.useCredential, URLCredential(trust: check))
        } else {
            Self.lastError = error.map { CFErrorCopyDescription($0) as String }
            completionHandler(.cancelAuthenticationChallenge, nil)
        }
    }
}

enum GigaChat {
    enum Failure: LocalizedError {
        case http(Int, String)
        case badAnswer
        var errorDescription: String? {
            switch self {
            case .http(401, _): return "GigaChat не принял ключ авторизации — проверь его в настройках"
            case .http(402, _): return "Закончились бесплатные токены GigaChat в этом месяце"
            case .http(429, _): return "GigaChat просит подождать — слишком много запросов"
            case .http(let c, let m): return "GigaChat ответил \(c): \(m)"
            case .badAnswer: return "Не удалось разобрать ответ GigaChat"
            }
        }
    }

    static let models: [(id: String, title: String)] = [("GigaChat", "Lite"), ("GigaChat-Pro", "Pro"), ("GigaChat-Max", "Max")]
    static var model: String { UserDefaults.standard.string(forKey: "gigachat.model") ?? "GigaChat" }

    private static let session = URLSession(configuration: .default, delegate: GigaTrust(), delegateQueue: nil)
    private static var token: (value: String, until: Date)?

    /// Запрос с одной повторной попыткой: если соединение не проверилось, докачиваем промежуточный сертификат
    private static func send(_ req: URLRequest) async throws -> (Data, URLResponse) {
        do {
            return try await session.data(for: req)
        } catch let e as URLError where e.code == .cancelled || e.code == .secureConnectionFailed
                                        || e.code == .serverCertificateUntrusted || e.code == .serverCertificateHasUnknownRoot {
            guard await GigaTrust.fetchIntermediate(session: session) else { throw e }
            return try await session.data(for: req)
        }
    }

    private static func accessToken(_ authKey: String) async throws -> String {
        if let t = token, t.until > Date().addingTimeInterval(60) { return t.value }
        guard let url = URL(string: "https://ngw.devices.sberbank.ru:9443/api/v2/oauth") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 30
        let basic = authKey.hasPrefix("Basic ") ? authKey : "Basic \(authKey)"
        req.setValue(basic, forHTTPHeaderField: "Authorization")
        req.setValue(UUID().uuidString, forHTTPHeaderField: "RqUID")
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.httpBody = Data("scope=GIGACHAT_API_PERS".utf8)
        let (data, resp) = try await send(req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        guard code == 200, let value = obj?["access_token"] as? String else {
            throw Failure.http(code, String((String(data: data, encoding: .utf8) ?? "").prefix(200)))
        }
        let ms = (obj?["expires_at"] as? Double) ?? (Date().timeIntervalSince1970 + 1500) * 1000
        token = (value, Date(timeIntervalSince1970: ms / 1000))
        return value
    }

    static func resetToken() { token = nil }

    /// Проверка подключения: получаем токен и список моделей (бесплатно, токены не тратятся)
    static func check() async throws -> [String] {
        guard let key = GigaKey.value else { throw Failure.http(401, "") }
        token = nil
        let t = try await accessToken(key)
        guard let url = URL(string: "https://gigachat.devices.sberbank.ru/api/v1/models") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.timeoutInterval = 20
        req.setValue("Bearer \(t)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, resp) = try await send(req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        guard code == 200 else { throw Failure.http(code, String((String(data: data, encoding: .utf8) ?? "").prefix(200))) }
        return ((obj?["data"] as? [[String: Any]]) ?? []).compactMap { $0["id"] as? String }
    }

    static func complete(system: String, user: String) async throws -> String {
        guard let key = GigaKey.value else { throw Failure.http(401, "") }
        let t = try await accessToken(key)
        guard let url = URL(string: "https://gigachat.devices.sberbank.ru/api/v1/chat/completions") else { throw Failure.badAnswer }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 180
        req.setValue("Bearer \(t)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        let body: [String: Any] = [
            "model": model,
            "messages": [["role": "system", "content": system], ["role": "user", "content": user]],
            "max_tokens": 4000,
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, resp) = try await send(req)
        let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
        if code == 401 { token = nil }
        let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        guard code == 200,
              let choices = obj?["choices"] as? [[String: Any]],
              let msg = choices.first?["message"] as? [String: Any],
              let content = msg["content"] as? String else {
            throw Failure.http(code, String(((obj?["message"] as? String) ?? String(data: data, encoding: .utf8) ?? "").prefix(200)))
        }
        return content
    }
}

// MARK: - Проверка подключения ИИ

struct AIProbe: Equatable {
    enum State: Equatable { case ok, warn, fail }
    var state: State
    var text: String
}

enum LectureAIProbe {
    /// Понятный текст для сетевых ошибок
    static func describe(_ error: Error, vpnHint: Bool) -> String {
        if let u = error as? URLError {
            switch u.code {
            case .notConnectedToInternet, .networkConnectionLost, .dataNotAllowed:
                return "Нет интернета"
            case .timedOut, .cannotConnectToHost, .cannotFindHost:
                return vpnHint ? "Сервер недоступен — из России нужен VPN" : "Сервер не отвечает, попробуй позже"
            case .serverCertificateUntrusted, .serverCertificateHasBadDate, .serverCertificateNotYetValid,
                 .serverCertificateHasUnknownRoot, .secureConnectionFailed, .cancelled:
                return "Не удалось проверить защищённое соединение"
            default:
                return u.localizedDescription
            }
        }
        return error.localizedDescription
    }

    static func gigachat() async -> AIProbe {
        guard GigaKey.value != nil else { return AIProbe(state: .warn, text: "Ключ не введён") }
        let start = Date()
        do {
            let models = try await GigaChat.check()
            let ms = Int(Date().timeIntervalSince(start) * 1000)
            let chosen = GigaChat.model
            if !models.isEmpty && !models.contains(chosen) {
                return AIProbe(state: .warn, text: "Подключено, но модель \(chosen) недоступна на твоём тарифе — выбери Lite")
            }
            return AIProbe(state: .ok, text: "Подключено · \(chosen) · \(ms) мс")
        } catch {
            var text = describe(error, vpnHint: false)
            if let why = GigaTrust.lastError { text += "\n\(why)" }
            return AIProbe(state: .fail, text: text)
        }
    }

    static func apple() async -> AIProbe {
        let (ok, text) = AppleLLM.status
        guard ok else { return AIProbe(state: .fail, text: text) }
        do {
            let r = try await AppleLLM.complete(system: "Отвечай одним словом.", user: "Скажи по-русски: готово")
            return AIProbe(state: .ok, text: "Работает на телефоне · ответ: «\(r.trimmingCharacters(in: .whitespacesAndNewlines).prefix(20))»")
        } catch {
            return AIProbe(state: .fail, text: "Модель есть, но не ответила: \(error.localizedDescription)")
        }
    }

    /// Ключ Claude проверяем бесплатным запросом информации о модели
    static func claude() async -> AIProbe {
        guard let key = ClaudeKey.value else { return AIProbe(state: .warn, text: "Ключ не введён (необязательно)") }
        guard let url = URL(string: "https://api.anthropic.com/v1/models/claude-opus-5") else { return AIProbe(state: .fail, text: "") }
        var req = URLRequest(url: url)
        req.timeoutInterval = 15
        req.setValue(key, forHTTPHeaderField: "x-api-key")
        req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            switch (resp as? HTTPURLResponse)?.statusCode ?? 0 {
            case 200: return AIProbe(state: .ok, text: "Подключено · claude-opus-5")
            case 401: return AIProbe(state: .fail, text: "Ключ неверный")
            case 403: return AIProbe(state: .fail, text: "Доступ запрещён — из России нужен VPN")
            case 404: return AIProbe(state: .fail, text: "Модель недоступна для этого ключа")
            case let c: return AIProbe(state: .fail, text: "Anthropic ответил \(c)")
            }
        } catch {
            return AIProbe(state: .fail, text: describe(error, vpnHint: true))
        }
    }
}
