// Эффекты видеокарты для SwiftUI (iOS 17+): волна от пальца, блик на текущей паре, рассыпание сделанного ДЗ.
// Каждый эффект — несколько строк для видеокарты: вес приложения почти не меняется.

#include <metal_stdlib>
#include <SwiftUI/SwiftUI.h>
using namespace metal;

/// Волна от точки касания: пиксели смещаются по кругу, гребни чуть светлее
[[ stitchable ]] half4 arkRipple(float2 position, SwiftUI::Layer layer, float2 origin, float time,
                                 float amplitude, float frequency, float decay, float speed) {
    float dist = length(position - origin);
    float t = max(0.0, time - dist / speed);
    float wave = amplitude * sin(frequency * t) * exp(-decay * t);
    float2 dir = dist > 0.001 ? (position - origin) / dist : float2(0.0);
    half4 color = layer.sample(position + wave * dir);
    color.rgb += half(0.28 * (wave / amplitude)) * color.a;
    return color;
}

/// Блик: косая светлая полоса проходит по карточке (progress 0 → 1.2). Рисуется на белом слое поверх
[[ stitchable ]] half4 arkSheen(float2 position, half4 color, float4 bounds, float progress) {
    float2 uv = (position - bounds.xy) / max(bounds.zw, float2(1.0));
    float d = (uv.x + uv.y * 0.45) - (progress * 1.9 - 0.45);
    float band = exp(-d * d * 70.0) * 0.16;
    float glint = exp(-d * d * 1400.0) * 0.45;
    float a = band + glint;
    return half4(half3(1.0), 1.0) * half(a);
}

/// Рассыпание: строка слева направо распадается на крошки, которые уносит вверх, и тает
[[ stitchable ]] half4 arkDissolve(float2 position, SwiftUI::Layer layer, float4 bounds, float progress) {
    float2 uv = (position - bounds.xy) / max(bounds.zw, float2(1.0));
    float2 cell = floor(position / 3.0);
    float n = fract(sin(dot(cell, float2(12.9898, 78.233))) * 43758.5453);
    float t = clamp(progress * 1.7 - uv.x * 0.7, 0.0, 1.0);
    float2 from = position + float2(-t * 24.0 * (n - 0.35), t * 44.0 * (0.4 + n));
    half4 c = layer.sample(from);
    float keep = 1.0 - smoothstep(n * 0.8, n * 0.8 + 0.2, t);
    return c * half(keep);
}
