import SwiftUI

enum Maps {
    static func url(for address: String) -> URL? {
        var q = address
        if !q.lowercased().contains("архангельск") { q = "Архангельск, " + q }
        let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "https://yandex.ru/maps/?text=\(encoded)")
    }

    static func appleURL(for address: String) -> URL? {
        var q = address
        if !q.lowercased().contains("архангельск") { q = "Архангельск, " + q }
        let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "https://maps.apple.com/?q=\(encoded)")
    }
}

private func hm(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

// MARK: - Экран расписания

struct ScheduleView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.openURL) private var openURL
    @Namespace private var ns

    @State private var day: Int = ScheduleView.todayIndex
    @State private var weekOffset = 0
    @State private var forward = true
    @State private var editing: Lesson?
    @State private var showBuildings = false
    @State private var showExport = false

    /// Сегодняшний день 1…6 (в воскресенье показываем понедельник следующей недели)
    private static var todayIndex: Int {
        let wd = ScheduleEngine.weekday(of: Date())
        return wd == 7 ? 1 : wd
    }

    /// Понедельник текущей учебной недели
    private var baseMonday: Date {
        let monday = WeekKey.monday(of: Date())
        return ScheduleEngine.weekday(of: Date()) == 7
            ? (Calendar.current.date(byAdding: .day, value: 7, to: monday) ?? monday)
            : monday
    }

    private func date(for d: Int, offset: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: offset * 7 + d - 1, to: baseMonday) ?? baseMonday
    }

    private var dateForSelectedDay: Date { date(for: day, offset: weekOffset) }

    private var isToday: Bool { weekOffset == 0 && day == ScheduleView.todayIndex }

    private var weekCaption: String {
        guard let w = Academic.week(from: schedule.data.semesterStart, now: dateForSelectedDay) else {
            return "Вне семестра"
        }
        return "Неделя \(w) · \(w % 2 == 0 ? "чётная" : "нечётная")"
    }

    private var weekRange: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "d MMM"
        let a = date(for: 1, offset: weekOffset)
        let b = date(for: 6, offset: weekOffset)
        return "\(f.string(from: a)) – \(f.string(from: b))"
    }

    private var weekTitle: String {
        switch weekOffset {
        case 0: return "Эта неделя"
        case -1: return "Прошлая неделя"
        case 1: return "Следующая неделя"
        default: return weekOffset < 0 ? "\(-weekOffset) нед. назад" : "Через \(weekOffset) нед."
        }
    }

    private func shift(days delta: Int) {
        var d = day + delta
        var w = weekOffset
        if d < 1 { d = 6; w -= 1 }
        if d > 6 { d = 1; w += 1 }
        forward = delta > 0
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            day = d
            weekOffset = w
        }
    }

    private func shift(weeks delta: Int) {
        forward = delta > 0
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            weekOffset += delta
        }
    }

    private func goToday() {
        forward = weekOffset < 0 || (weekOffset == 0 && day < ScheduleView.todayIndex)
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            weekOffset = 0
            day = ScheduleView.todayIndex
        }
    }

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    ScreenHeader(caption: weekCaption, title: "Пары") {
                        Menu {
                            Button { editing = newLesson() } label: {
                                Label("Добавить пару", systemImage: "plus")
                            }
                            Button { showBuildings = true } label: {
                                Label("Корпуса и адреса", systemImage: "building.2")
                            }
                            Button { showExport = true } label: {
                                Label("В Календарь iPhone", systemImage: "calendar.badge.plus")
                            }
                        } label: {
                            CircleIconButton(icon: "plus")
                        }
                    }

                    weekNavigator

                    daySelector

                    dayContent
                        .id("\(weekOffset)-\(day)")
                        .transition(.asymmetric(
                            insertion: .move(edge: forward ? .trailing : .leading).combined(with: .opacity),
                            removal: .opacity))
                        .contentShape(Rectangle())
                        .simultaneousGesture(
                            DragGesture(minimumDistance: 30)
                                .onEnded { value in
                                    guard abs(value.translation.width) > abs(value.translation.height) * 1.5,
                                          abs(value.translation.width) > 60 else { return }
                                    shift(days: value.translation.width < 0 ? 1 : -1)
                                }
                        )

                    bellsCard
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
        }
        .sheet(item: $editing) { l in
            LessonEditor(lesson: l,
                         isNew: !schedule.contains(l),
                         buildings: schedule.data.buildings,
                         onSave: { schedule.upsert($0) },
                         onDelete: { schedule.delete(l) })
        }
        .sheet(isPresented: $showBuildings) {
            BuildingsSheet().environmentObject(schedule)
        }
        .sheet(isPresented: $showExport) {
            ExportSheet().environmentObject(schedule)
        }
    }

    private func newLesson() -> Lesson {
        Lesson(subject: "", weekday: day, pair: 1)
    }

    // MARK: недели

    private var weekNavigator: some View {
        HStack(spacing: 10) {
            Button { shift(weeks: -1) } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())

            VStack(spacing: 2) {
                Text(weekTitle)
                    .font(.subheadline.weight(.bold))
                Text(weekRange)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .contentTransition(.opacity)

            if !isToday {
                Button(action: goToday) {
                    Text("Сегодня")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .frame(height: 32)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .transition(.scale.combined(with: .opacity))
            }

            Button { shift(weeks: 1) } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: isToday)
    }

    // MARK: дни

    private var daySelector: some View {
        HStack(spacing: 4) {
            ForEach(1...6, id: \.self) { d in
                Button {
                    Haptics.tap()
                    forward = d > day
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { day = d }
                } label: {
                    VStack(spacing: 4) {
                        Text(Lesson.dayNames[d - 1])
                            .font(.caption.weight(.semibold))
                        Text(dayNumber(d))
                            .font(.system(.headline, design: .rounded))
                            .underline(weekOffset == 0 && d == ScheduleView.todayIndex && day != d)
                        Circle()
                            .fill(hasLessons(on: d) ? (day == d ? Color.white : Color.brand) : Color.clear)
                            .frame(width: 5, height: 5)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .foregroundStyle(day == d ? Color.white : Color.primary)
                    .background {
                        if day == d {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(brandGradient)
                                .matchedGeometryEffect(id: "day", in: ns)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .glass(22)
    }

    private func dayNumber(_ d: Int) -> String {
        "\(Calendar.current.component(.day, from: date(for: d, offset: weekOffset)))"
    }

    private func hasLessons(on d: Int) -> Bool {
        !ScheduleEngine.slots(on: date(for: d, offset: weekOffset), data: schedule.data).isEmpty
    }

    // MARK: пары дня

    @ViewBuilder private var dayContent: some View {
        let slots = ScheduleEngine.slots(on: dateForSelectedDay, data: schedule.data)
        if !schedule.hasLessons {
            VStack(spacing: 14) {
                EmptyState(icon: "calendar.badge.plus",
                           title: "Внеси своё расписание",
                           text: "Один раз перенеси пары из Модеуса, и приложение будет показывать текущую пару, аудиторию и адрес корпуса. Есть виджет для экрана «Домой» и блокировки.")
                Button { editing = newLesson() } label: {
                    Label("Добавить первую пару", systemImage: "plus")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .buttonStyle(PressableStyle())
            }
        } else if slots.isEmpty {
            EmptyState(icon: "sun.max.fill", title: "Пар нет", text: "В этот день свободно.")
        } else {
            VStack(spacing: 10) {
                if schedule.data.isArchived(dateForSelectedDay) {
                    Label("Расписание из архива: так было на этой неделе", systemImage: "clock.arrow.circlepath")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                ForEach(slots, id: \.lesson.id) { s in
                    SlotRow(slot: s, onMap: { openMap(s.address) })
                        .onTapGesture { editing = s.lesson }
                        .contextMenu {
                            Button { editing = s.lesson } label: { Label("Изменить", systemImage: "pencil") }
                            if !s.address.isEmpty {
                                Button { openMap(s.address) } label: { Label("Яндекс Карты", systemImage: "map") }
                                Button {
                                    if let u = Maps.appleURL(for: s.address) { openURL(u) }
                                } label: { Label("Apple Карты", systemImage: "map.fill") }
                            }
                            Button {
                                var copy = s.lesson
                                copy.id = UUID()
                                editing = copy
                            } label: { Label("Дублировать", systemImage: "plus.square.on.square") }
                            Button(role: .destructive) {
                                withAnimation { schedule.delete(s.lesson) }
                            } label: { Label("Удалить", systemImage: "trash") }
                        }
                        .transition(.opacity.combined(with: .scale(scale: 0.97)))
                }
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.85), value: day)
        }
    }

    private func openMap(_ address: String) {
        guard !address.isEmpty, let u = Maps.url(for: address) else { return }
        Haptics.tap()
        openURL(u)
    }

    private var bellsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: "Звонки")
            VStack(spacing: 8) {
                ForEach(1...Bells.times.count, id: \.self) { p in
                    HStack {
                        Text("\(p) пара")
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text(Bells.label(p))
                            .monospacedDigit()
                            .fontWeight(.semibold)
                    }
                    .font(.subheadline)
                }
                Text("После 3-й пары обед 55 минут.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
            .glass(22)
        }
    }
}

// MARK: - Строка пары

struct SlotRow: View {
    let slot: LessonSlot
    let onMap: () -> Void

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            row(now: ctx.date)
        }
    }

    private func row(now: Date) -> some View {
        let active = slot.start <= now && now < slot.end
        let past = now >= slot.end
        let total = slot.end.timeIntervalSince(slot.start)
        let progress = total > 0 ? min(max(now.timeIntervalSince(slot.start) / total, 0), 1) : 0
        let minutesLeft = Int(ceil(slot.end.timeIntervalSince(now) / 60))

        return HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(hm(slot.start))
                    .font(.subheadline.weight(.bold))
                    .monospacedDigit()
                Text(hm(slot.end))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
                Text("\(slot.lesson.pair) пара")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .frame(width: 54, alignment: .leading)

            Capsule()
                .fill(active ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary.opacity(0.3)))
                .frame(width: 3)

            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 6) {
                    Text(slot.lesson.kind)
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.brand.opacity(0.14), in: Capsule())
                    if slot.lesson.parity != 0 {
                        Text(slot.lesson.parity == 1 ? "нечёт" : "чёт")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    if active {
                        Text("СЕЙЧАС")
                            .font(.caption2.weight(.heavy))
                            .foregroundStyle(Color.brand)
                    }
                }
                Text(slot.lesson.subject)
                    .font(.headline)
                    .lineLimit(2)
                if !slot.place.isEmpty {
                    Button(action: onMap) {
                        Label(slot.place, systemImage: "mappin.and.ellipse")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .buttonStyle(.plain)
                }
                if !slot.lesson.teacher.isEmpty {
                    Label(slot.lesson.teacher, systemImage: "person")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                if active {
                    ProgressView(value: progress)
                        .tint(Color.brand)
                    Text("до конца \(minutesLeft) мин")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(Color.brand)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .glass(20)
        .opacity(past ? 0.55 : 1)
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

// MARK: - Карточка «Сейчас» на главной

struct NowCard: View {
    let data: ScheduleData
    let onOpen: () -> Void
    let onMap: (String) -> Void

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            card(now: ctx.date)
        }
    }

    private func card(now: Date) -> some View {
        let r = ScheduleEngine.nowAndNext(at: now, data: data)
        return VStack(alignment: .leading, spacing: 12) {
            if let c = r.current {
                header("СЕЙЧАС", "ещё \(Int(ceil(c.end.timeIntervalSince(now) / 60))) мин")
                lessonBlock(c)
                ProgressView(value: progress(c, now))
                    .tint(Color.brand)
                if let n = r.next {
                    Divider().opacity(0.4)
                    HStack(spacing: 6) {
                        Text("Потом")
                            .foregroundStyle(.secondary)
                        Text(n.lesson.subject)
                            .fontWeight(.semibold)
                            .lineLimit(1)
                        Spacer(minLength: 4)
                        Text(when(n, now))
                            .foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                }
            } else if let n = r.next {
                header("СЛЕДУЮЩАЯ ПАРА", when(n, now))
                lessonBlock(n)
            } else {
                header("ПАРЫ", "")
                Text("На ближайшую неделю пар нет")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(18)
        .glass(28)
        .contentShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .onTapGesture(perform: onOpen)
    }

    private func header(_ title: String, _ trailing: String) -> some View {
        HStack {
            HStack(spacing: 5) {
                Image(systemName: "snowflake")
                Text(title)
            }
            .font(.caption.weight(.heavy))
            .foregroundStyle(Color.brand)
            Spacer()
            Text(trailing)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
        }
    }

    private func lessonBlock(_ s: LessonSlot) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(s.lesson.subject)
                .font(.system(.title3, design: .rounded).weight(.bold))
                .lineLimit(2)
            HStack(spacing: 8) {
                Text("\(hm(s.start))–\(hm(s.end))")
                    .monospacedDigit()
                Text("·")
                Text(s.lesson.kind)
            }
            .font(.subheadline)
            .foregroundStyle(.secondary)
            if !s.place.isEmpty || !s.address.isEmpty {
                Button {
                    onMap(s.address)
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title3)
                            .foregroundStyle(brandGradient)
                        VStack(alignment: .leading, spacing: 1) {
                            if !s.place.isEmpty {
                                Text(s.place)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                            }
                            if !s.address.isEmpty {
                                Text(s.address)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .lineLimit(1)
                        Spacer(minLength: 0)
                        if !s.address.isEmpty {
                            Image(systemName: "arrow.up.right")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(10)
                    .background(Color.brand.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(PressableStyle())
                .disabled(s.address.isEmpty)
            }
        }
    }

    private func progress(_ s: LessonSlot, _ now: Date) -> Double {
        let total = s.end.timeIntervalSince(s.start)
        guard total > 0 else { return 0 }
        return min(max(now.timeIntervalSince(s.start) / total, 0), 1)
    }

    private func when(_ s: LessonSlot, _ now: Date) -> String {
        let cal = Calendar.current
        let minutes = Int(ceil(s.start.timeIntervalSince(now) / 60))
        if cal.isDate(s.start, inSameDayAs: now) {
            return minutes <= 90 ? "через \(minutes) мин" : "в \(hm(s.start))"
        }
        if cal.isDateInTomorrow(s.start) { return "завтра в \(hm(s.start))" }
        let wd = ScheduleEngine.weekday(of: s.start)
        return "\(Lesson.dayFullNames[wd - 1]) в \(hm(s.start))"
    }
}

// MARK: - Редактор пары

struct LessonEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var lesson: Lesson
    @State private var savedCount = 0
    private let isNew: Bool
    private let buildings: [Building]
    private let onSave: (Lesson) -> Void
    private let onDelete: () -> Void

    init(lesson: Lesson, isNew: Bool, buildings: [Building],
         onSave: @escaping (Lesson) -> Void,
         onDelete: @escaping () -> Void) {
        _lesson = State(initialValue: lesson)
        self.isNew = isNew
        self.buildings = buildings
        self.onSave = onSave
        self.onDelete = onDelete
    }

    private var canSave: Bool {
        !lesson.subject.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Предмет", text: $lesson.subject)
                        .font(.headline)
                    Picker("Тип", selection: $lesson.kind) {
                        ForEach(Lesson.kinds, id: \.self) { Text($0).tag($0) }
                    }
                }

                Section("Когда") {
                    Picker("День", selection: $lesson.weekday) {
                        ForEach(1...6, id: \.self) { d in
                            Text(Lesson.dayNames[d - 1]).tag(d)
                        }
                    }
                    .pickerStyle(.segmented)
                    Picker("Пара", selection: $lesson.pair) {
                        ForEach(1...Bells.times.count, id: \.self) { p in
                            Text("\(p) пара · \(Bells.label(p))").tag(p)
                        }
                    }
                    Picker("Неделя", selection: $lesson.parity) {
                        Text("Каждую").tag(0)
                        Text("Нечётная").tag(1)
                        Text("Чётная").tag(2)
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    TextField("Аудитория, например 3104", text: $lesson.room)
                    Picker("Корпус", selection: $lesson.building) {
                        Text("Не указан").tag("")
                        ForEach(buildings) { b in
                            Text(b.name).tag(b.name)
                        }
                    }
                } header: {
                    Text("Где")
                } footer: {
                    Text("Корпуса и их адреса настраиваются в меню «+» на экране «Пары».")
                }

                Section {
                    TextField("Преподаватель", text: $lesson.teacher)
                }

                if isNew {
                    Section {
                        Button {
                            onSave(lesson)
                            Haptics.success()
                            savedCount += 1
                            var next = lesson
                            next.id = UUID()
                            next.subject = ""
                            next.teacher = ""
                            next.room = ""
                            next.pair = min(lesson.pair + 1, Bells.times.count)
                            lesson = next
                        } label: {
                            Label("Сохранить и добавить следующую", systemImage: "plus.circle")
                        }
                        .disabled(!canSave)
                    } footer: {
                        if savedCount > 0 {
                            Text("Добавлено пар: \(savedCount)")
                        }
                    }
                } else {
                    Section {
                        Button(role: .destructive) {
                            onDelete()
                            dismiss()
                        } label: {
                            Label("Удалить пару", systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle(isNew ? "Новая пара" : "Пара")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(savedCount > 0 ? "Закрыть" : "Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") {
                        onSave(lesson)
                        Haptics.success()
                        dismiss()
                    }
                    .disabled(!canSave)
                }
            }
        }
    }
}

// MARK: - Корпуса

struct BuildingsSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach($schedule.data.buildings) { $b in
                        VStack(alignment: .leading, spacing: 6) {
                            TextField("Название", text: $b.name)
                                .font(.headline)
                            TextField("Адрес", text: $b.address)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                    .onDelete { schedule.data.buildings.remove(atOffsets: $0) }

                    Button {
                        schedule.data.buildings.append(Building(name: "Корпус \(schedule.data.buildings.count + 1)",
                                                                address: "Архангельск, "))
                    } label: {
                        Label("Добавить корпус", systemImage: "plus")
                    }
                } footer: {
                    Text("Адрес открывается в Яндекс Картах. Если переименуешь корпус, выбери его заново в парах.")
                }
            }
            .navigationTitle("Корпуса")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Экспорт в Календарь

struct ExportSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @State private var weeks = 8
    @State private var alert = true
    @State private var status: String?
    @State private var working = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Stepper("Недель вперёд: \(weeks)", value: $weeks, in: 1...20)
                    Toggle("Напоминание за 15 минут", isOn: $alert)
                } footer: {
                    Text("Создам отдельный календарь «\(CalendarExporter.calendarTitle)». Стандартный виджет «Календарь» будет показывать следующую пару с аудиторией и адресом, а Карты подскажут, когда выходить. Повторный экспорт заменяет старые пары.")
                }

                Section {
                    Button {
                        run()
                    } label: {
                        HStack {
                            Label("Добавить в Календарь", systemImage: "calendar.badge.plus")
                            Spacer()
                            if working { ProgressView() }
                        }
                    }
                    .disabled(working || !schedule.hasLessons)
                } footer: {
                    if let status {
                        Text(status)
                    } else if !schedule.hasLessons {
                        Text("Сначала добавь пары.")
                    }
                }
            }
            .navigationTitle("Календарь")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }

    private func run() {
        working = true
        status = nil
        let data = schedule.data
        let w = weeks
        let a = alert
        Task {
            do {
                let count = try await CalendarExporter.export(data: data, weeks: w, alert: a)
                await MainActor.run {
                    working = false
                    status = "Готово: добавлено пар — \(count)."
                    Haptics.success()
                }
            } catch {
                await MainActor.run {
                    working = false
                    status = error.localizedDescription
                }
            }
        }
    }
}
