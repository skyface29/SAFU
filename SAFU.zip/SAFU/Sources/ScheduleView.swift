import SwiftUI
import UIKit
import CoreLocation

enum Maps {
    /// Нормальный адрес для поиска на карте: код корпуса («А-НСД17/1405») → улица и дом
    static func query(for raw: String) -> String? {
        let t = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, !AddressFormat.isRemote(t) else { return nil }
        var q = AddressFormat.full(t)
        // «учебный корпус № 10, просп. Ломоносова, д. 2» → «просп. Ломоносова, д. 2»
        if q.hasPrefix("учебный корпус"), let r = q.range(of: ", ") { q = String(q[r.upperBound...]) }
        q = q.replacingOccurrences(of: ", д. ", with: ", ")
        if !q.lowercased().contains("архангельск") { q = L("Архангельск, ") + q }
        return q
    }

    /// Кодирование для параметра URL: запятые, & и + тоже экранируем
    private static func enc(_ s: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "&+=,?#")
        return s.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
    }

    static func url(for address: String) -> URL? {
        guard let q = query(for: address) else { return nil }
        return URL(string: "https://yandex.ru/maps/?text=\(enc(q))")
    }

    static func appleURL(for address: String) -> URL? {
        guard let q = query(for: address) else { return nil }
        return URL(string: "https://maps.apple.com/?q=\(enc(q))")
    }

    /// Синхронный вариант (без маршрута): поиск адреса
    static func smartURL(for address: String) -> URL? {
        FeatureFlags.mapsProvider == 1 ? appleURL(for: address) : url(for: address)
    }

    /// Открыть адрес с учётом настроек: Яндекс или Apple, точка или маршрут от тебя.
    /// Яндекс не умеет строить маршрут до текста — сначала находим координаты, потом прокладываем путь.
    static func open(_ address: String) {
        guard let q = query(for: address) else { return }
        Task { @MainActor in await openNow(q) }
    }

    @MainActor
    private static func openNow(_ q: String) async {
        let transit = FeatureFlags.mapsMode == 0
        let route = FeatureFlags.mapsRoute
        let e = enc(q)

        if FeatureFlags.mapsProvider == 1 {
            let s = route
                ? "https://maps.apple.com/?daddr=\(e)&dirflg=\(transit ? "r" : "w")"
                : "https://maps.apple.com/?q=\(e)"
            if let u = URL(string: s) { _ = await UIApplication.shared.open(u) }
            return
        }

        // Яндекс: без вопросов и без маршрута — адрес сразу в строке поиска и точкой на карте.
        // Если координаты уже известны — карта сразу центрируется на корпусе крупно
        var extra = "&z=17"
        if let c = cachedCoordinate(for: q) { extra += "&ll=\(c.longitude),\(c.latitude)" }
        openYandex(app: "yandexmaps://maps.yandex.ru/?text=\(e)\(extra)",
                   web: "https://yandex.ru/maps/?text=\(e)\(extra)")
        // координаты запоминаем на следующий раз (в фоне, открытие не ждёт)
        if cachedCoordinate(for: q) == nil { _ = await coordinate(for: q) }
    }

    private static func cachedCoordinate(for q: String) -> CLLocationCoordinate2D? {
        let cache = (UserDefaults.standard.dictionary(forKey: "maps.geo.cache") as? [String: [Double]]) ?? [:]
        guard let c = cache[q], c.count == 2 else { return nil }
        return CLLocationCoordinate2D(latitude: c[0], longitude: c[1])
    }

    /// Сначала приложение Яндекс Карт, если его нет — сайт
    @MainActor
    private static func openYandex(app: String, web: String) {
        guard let a = URL(string: app) else {
            if let w = URL(string: web) { UIApplication.shared.open(w) }
            return
        }
        UIApplication.shared.open(a) { ok in
            if !ok, let w = URL(string: web) { UIApplication.shared.open(w) }
        }
    }

    /// Координаты адреса (с кэшем, чтобы второй раз открывалось мгновенно)
    private static func coordinate(for q: String) async -> CLLocationCoordinate2D? {
        let key = "maps.geo.cache"
        var cache = (UserDefaults.standard.dictionary(forKey: key) as? [String: [Double]]) ?? [:]
        if let c = cache[q], c.count == 2 { return CLLocationCoordinate2D(latitude: c[0], longitude: c[1]) }
        guard let loc = try? await CLGeocoder().geocodeAddressString(q).first?.location else { return nil }
        cache[q] = [loc.coordinate.latitude, loc.coordinate.longitude]
        UserDefaults.standard.set(cache, forKey: key)
        return loc.coordinate
    }
}

private func hm(_ d: Date) -> String { LiveFormat.hmText(d) }

// MARK: - Экран расписания

struct ScheduleView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.openURL) private var openURL
    @Namespace private var ns

    @State private var day: Int = ScheduleView.todayIndex
    @State private var weekOffset = 0
    @State private var forward = true
    @State private var editing: Lesson?
    @State private var detail: LessonSlot?
    @State private var showBuildings = false
    @State private var showExport = false
    @State private var showSettings = false
    @State private var showChanges = false
    @State private var tool: Tool?
    /// «Отправить ребятам»: картинка или текст для окна «Поделиться»
    @State private var share: ShareItem?
    @ObservedObject private var jump = ScheduleJump.shared
    /// Куда прокрутить после перехода из домашки
    @State private var scrollTo: Date?

    /// Сегодняшний день 1…6 (в воскресенье показываем понедельник следующей недели)
    static var todayIndex: Int {
        let wd = ScheduleEngine.weekday(of: Date())
        return wd == 7 ? 1 : wd
    }

    private var baseMonday: Date {
        let monday = WeekKey.monday(of: Date())
        return ScheduleEngine.weekday(of: Date()) == 7
            ? (Calendar.current.date(byAdding: .day, value: 7, to: monday) ?? monday)
            : monday
    }

    private func date(for d: Int, offset: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: offset * 7 + d - 1, to: baseMonday) ?? baseMonday
    }

    private var selectedDate: Date { date(for: day, offset: weekOffset) }
    private var isToday: Bool { weekOffset == 0 && day == ScheduleView.todayIndex }

    private var weekCaption: String {
        if schedule.data.usesRuz {
            return schedule.data.ruzGroupNumber.isEmpty ? L("РУЗ") : L("Группа \(schedule.data.ruzGroupNumber) · РУЗ")
        }
        guard let w = Academic.week(from: schedule.data.semesterStart, now: selectedDate) else { return L("Вне семестра") }
        return L("Неделя \(w) · \(w % 2 == 0 ? L("чётная") : L("нечётная"))")
    }

    private var weekRange: String {
        let f = Fmt.formatter("d MMM")
        return "\(f.string(from: date(for: 1, offset: weekOffset))) – \(f.string(from: date(for: 6, offset: weekOffset)))"
    }

    private var weekTitle: String {
        switch weekOffset {
        case 0: return L("Эта неделя")
        case -1: return L("Прошлая неделя")
        case 1: return L("Следующая неделя")
        default: return weekOffset < 0 ? L("\(-weekOffset) нед. назад") : L("Через \(weekOffset) нед.")
        }
    }

    // MARK: навигация

    private func shift(days delta: Int) {
        var d = day + delta
        var w = weekOffset
        if d < 1 { d = 6; w -= 1 }
        if d > 6 { d = 1; w += 1 }
        forward = delta > 0
        Haptics.tap()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            day = d
            weekOffset = w
        }
    }

    private func shift(weeks delta: Int) {
        forward = delta > 0
        Haptics.tap()
        let newOffset = weekOffset + delta
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            weekOffset = newOffset
            // другая неделя всегда открывается с понедельника, своя — с сегодняшнего дня
            day = newOffset == 0 ? ScheduleView.todayIndex : 1
        }
    }

    /// Открыть неделю и день нужной даты (переход из домашки)
    private func applyJump() {
        guard let d = jump.target else { return }
        // сбрасываем чуть позже, чтобы корень приложения успел переключить вкладку
        DispatchQueue.main.async { ScheduleJump.shared.target = nil }
        let cal = Calendar.current
        let days = cal.dateComponents([.day], from: baseMonday, to: WeekKey.monday(of: d)).day ?? 0
        let weeks = Int((Double(days) / 7).rounded())
        var wd = ScheduleEngine.weekday(of: d)
        if wd == 7 { wd = 6 }
        forward = weeks > weekOffset || (weeks == weekOffset && wd > day)
        withAnimation(.spring(response: 0.39, dampingFraction: 0.85)) {
            weekOffset = weeks
            day = wd
        }
        scrollTo = d
    }

    /// Без анимации и вибрации: вкладка просто открывается на сегодня
    private func showTodayInstantly() {
        guard weekOffset != 0 || day != ScheduleView.todayIndex else { return }
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t) {
            weekOffset = 0
            day = ScheduleView.todayIndex
        }
    }

    private func goToday() {
        forward = weekOffset < 0 || (weekOffset == 0 && day < ScheduleView.todayIndex)
        Haptics.tap()
        withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
            weekOffset = 0
            day = ScheduleView.todayIndex
        }
    }

    // MARK: body

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollViewReader { proxy in
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    ScreenHeader(caption: weekCaption, title: L("Пары")) {
                        HStack(spacing: 10) {
                            if schedule.isConfigured { shareMenu }
                            menu
                        }
                    }

                    if schedule.data.usesRuz { syncChip }

                    if !schedule.changes.isEmpty {
                        Button {
                            schedule.markChangesSeen()
                            showChanges = true
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "exclamationmark.arrow.triangle.2.circlepath")
                                    .font(.headline)
                                    .foregroundStyle(schedule.unseenChanges > 0 ? Color.orange : Color.secondary)
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(schedule.unseenChanges > 0 ? L("Расписание изменилось: \(schedule.unseenChanges)") : L("Журнал изменений"))
                                        .font(.subheadline.weight(.bold))
                                        .foregroundStyle(.primary)
                                    Text(schedule.changes.first?.text ?? "")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.secondary)
                            }
                            .padding(14)
                            .glass(18, interactive: true)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }

                    if schedule.isConfigured {
                        if weekOffset != 0 {
                            weekBadge
                                .id(weekOffset)
                                .transition(.scale(scale: 0.7, anchor: .leading).combined(with: .opacity))
                        }
                        weekNavigator
                        daySelector
                        // старый и новый день — друг на друге: в общей колонке на время смены они вставали
                        // один под другим, и всё ниже (звонки) прыгало вниз и обратно — это и было похоже на рывок
                        ZStack(alignment: .top) {
                            dayContent
                                .id("\(weekOffset)-\(day)-\(schedule.data.ruzEvents.count)")
                                .transition(.asymmetric(
                                    insertion: .move(edge: forward ? .trailing : .leading).combined(with: .opacity),
                                    removal: .opacity))
                        }
                        .contentShape(Rectangle())
                        .simultaneousGesture(
                            DragGesture(minimumDistance: 30).onEnded { value in
                                guard abs(value.translation.width) > abs(value.translation.height) * 1.5,
                                      abs(value.translation.width) > 60 else { return }
                                shift(days: value.translation.width < 0 ? 1 : -1)
                            }
                        )
                        bellsCard
                    } else {
                        SetupCard(onManual: { editing = Lesson(subject: "", weekday: day, pair: 1) })
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
            .pausesAmbientWhileScrolling()
            .statusBarScrim()
            .refreshable { await schedule.sync(force: true) }
            // расписание всех групп (если уже собиралось) — для строки «Поток» на парах
            .task(id: schedule.data.ruzInstitution) {
                await SchoolTimetable.shared.load(schedule.data.ruzInstitution > 0 ? schedule.data.ruzInstitution : 3)
            }
            // после перехода из домашки — докручиваем до нужной пары, когда день уже сменился
            .onChange(of: scrollTo) {
                guard let d = scrollTo else { return }
                scrollTo = nil
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                    withAnimation(.spring(response: 0.42, dampingFraction: 0.85)) {
                        proxy.scrollTo("slot-\(Int(d.timeIntervalSince1970))", anchor: .center)
                    }
                }
            }
            }
        }
        .task { await schedule.sync() }
        // открыл вкладку — всегда сегодняшний день; переход из домашки — неделя и день нужной пары
        .onAppear {
            if jump.target != nil { applyJump() } else { showTodayInstantly() }
        }
        .onChange(of: jump.target) { applyJump() }
        .task(id: weekOffset) {
            if weekOffset < 0 && schedule.data.usesRuz {
                await schedule.loadArchiveWeek(date(for: 1, offset: weekOffset))
            }
        }
        .sheet(item: $editing) { l in
            LessonEditor(lesson: l,
                         isNew: !schedule.contains(l),
                         buildings: schedule.data.buildings,
                         onSave: { schedule.upsert($0) },
                         onDelete: { schedule.delete(l) })
        }
        .sheet(item: Binding(get: { detail.map { SlotBox(slot: $0) } },
                             set: { detail = $0?.slot })) { box in
            LessonDetailSheet(slot: box.slot,
                              isManual: !schedule.data.usesRuz,
                              onEdit: { editing = box.slot.lesson })
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(isPresented: $showBuildings) { BuildingsSheet().environmentObject(schedule) }
        .sheet(isPresented: $showExport) { ExportSheet().environmentObject(schedule) }
        .sheet(isPresented: $showSettings) { ScheduleSettingsSheet().environmentObject(schedule) }
        .sheet(isPresented: $showChanges) { ChangesSheet().environmentObject(schedule) }
        .sheet(item: $tool) { t in
            ToolSheet(tool: t).environmentObject(schedule).environmentObject(tasks).environmentObject(attendance)
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
    }

    // MARK: отправить ребятам — день или неделя, как ДЗ

    /// Кнопка с бумажным самолётиком в шапке: выбранный день или неделя — картинкой или текстом
    private var shareMenu: some View {
        Menu { shareItems } label: { CircleIconButton(icon: "paperplane") }
            .accessibilityLabel(L("Отправить ребятам"))
    }

    @ViewBuilder
    private var shareItems: some View {
        let day = ScheduleSpan.day(selectedDate)
        let week = ScheduleSpan.week(selectedDate)
        Section(Fmt.formatter("EEEE, d MMMM").string(from: selectedDate).capitalizedFirst) {
            Button { shareImage(day) } label: { Label(L("День картинкой"), systemImage: "photo") }
            Button { shareText(day) } label: { Label(L("День текстом"), systemImage: "text.alignleft") }
        }
        Section(L("Неделя · \(weekRange)")) {
            Button { shareImage(week) } label: { Label(L("Неделю картинкой"), systemImage: "photo.stack") }
            Button { shareText(week) } label: { Label(L("Неделю текстом"), systemImage: "text.alignleft") }
        }
    }

    private func shareImage(_ span: ScheduleSpan) {
        Haptics.tap()
        share = ShareItem(items: ScheduleShare.imageItems(span, data: schedule.data))
    }

    private func shareText(_ span: ScheduleSpan) {
        Haptics.tap()
        share = ShareItem(items: [ScheduleShare.text(span, data: schedule.data)])
    }

    private var menu: some View {
        Menu {
            if schedule.data.usesRuz {
                Button { Task { await schedule.sync(force: true) } } label: {
                    Label(L("Обновить из РУЗ"), systemImage: "arrow.clockwise")
                }
                if let u = RuzClient.timetableURL(groupID: schedule.data.ruzGroupID), !schedule.data.ruzGroupID.isEmpty {
                    Button { openURL(u) } label: { Label(L("Открыть группу в РУЗ"), systemImage: "safari") }
                }
                Button { showBuildings = true } label: { Label(L("Коды корпусов и адреса"), systemImage: "building.2") }
            } else {
                Button { editing = Lesson(subject: "", weekday: day, pair: 1) } label: {
                    Label(L("Добавить пару"), systemImage: "plus")
                }
                Button { showBuildings = true } label: { Label(L("Корпуса и адреса"), systemImage: "building.2") }
            }
            Button { showExport = true } label: { Label(L("В Календарь iPhone"), systemImage: "calendar.badge.plus") }
            Divider()
            Button { tool = .session } label: { Label(L("Сессия"), systemImage: "graduationcap") }
            Button { tool = .subjects } label: { Label(L("Предметы"), systemImage: "books.vertical") }
            Button { tool = .teachers } label: { Label(L("Преподаватели"), systemImage: "person.2") }
            Button { tool = .map } label: { Label(L("Карта корпусов"), systemImage: "map") }
            Button { showChanges = true } label: { Label(L("Журнал изменений"), systemImage: "clock.arrow.circlepath") }
            Menu { shareItems } label: { Label(L("Отправить ребятам"), systemImage: "paperplane") }
            Divider()
            Button { showSettings = true } label: { Label(L("Настройки расписания"), systemImage: "slider.horizontal.3") }
        } label: {
            CircleIconButton(icon: "ellipsis")
        }
    }

    // MARK: статус синхронизации

    private var syncChip: some View {
        Button { Task { await schedule.sync(force: true) } } label: {
            HStack(spacing: 8) {
                SpinningIcon(spinning: schedule.syncing)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.brand)
                Text(schedule.syncing ? L("Обновляю из РУЗ…") : schedule.lastSyncText.capitalizedFirst)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                if !schedule.data.syncInfo.isEmpty && !schedule.syncing {
                    Text("· " + schedule.data.syncInfo)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .glass(16, interactive: true)
        }
        .buttonStyle(PressableStyle())
        .animation(.easeInOut(duration: 0.25), value: schedule.syncing)
    }

    // MARK: недели и дни

    /// Цвет «не этой» недели: будущая — оранжевая, прошлая — серая
    private var weekColor: Color {
        weekOffset > 0 ? Color.orange : Color(white: 0.55)
    }

    /// Плашка в левом углу: сразу видно, что смотришь не текущую неделю
    private var weekBadge: some View {
        HStack(spacing: 6) {
            Image(systemName: weekOffset > 0 ? "arrow.forward.circle.fill" : "clock.arrow.circlepath")
            Text(weekTitle.uppercased())
                .tracking(0.6)
            Text("· \(weekRange)")
                .fontWeight(.semibold)
                .opacity(0.9)
        }
        .font(.caption.weight(.heavy))
        .foregroundStyle(.white)
        .lineLimit(1)
        .minimumScaleFactor(0.8)
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(weekColor.gradient, in: Capsule())
        .shadow(color: weekColor.opacity(0.45), radius: 8, y: 3)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityLabel(L("Смотришь: \(weekTitle), \(weekRange)"))
    }

    private var weekNavigator: some View {
        HStack(spacing: 10) {
            Button { shift(weeks: -1) } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())

            VStack(spacing: 2) {
                Text(weekTitle)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(weekOffset == 0 ? Color.primary : weekColor)
                Text(weekRange).font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)

            if !isToday {
                Button(action: goToday) {
                    Text(L("Сегодня"))
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .frame(height: 32)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .transition(.scale.combined(with: .opacity))
            }

            Button { shift(weeks: 1) } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())
        }
        .animation(.spring(response: 0.32, dampingFraction: 0.8), value: isToday)
    }

    private var daySelector: some View {
        HStack(spacing: 4) {
            ForEach(1...6, id: \.self) { d in
                Button {
                    Haptics.tap()
                    forward = d > day
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.8)) { day = d }
                } label: {
                    VStack(spacing: 4) {
                        Text(Lesson.dayNames[d - 1]).font(.caption.weight(.semibold))
                        Text(dayNumber(d))
                            .font(.system(.headline, design: .rounded))
                            .underline(weekOffset == 0 && d == ScheduleView.todayIndex && day != d)
                        Circle()
                            .fill(hasLessons(on: d) ? (day == d ? Color.white : Color.brand) : Color.clear)
                            .frame(width: 5, height: 5)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .foregroundStyle(day == d ? Color.white : Color.primary)
                    .background {
                        if day == d {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(brandGradient)
                                .matchedGeometryEffect(id: "day", in: ns)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .glass(22)
    }

    private func dayNumber(_ d: Int) -> String {
        "\(Calendar.current.component(.day, from: date(for: d, offset: weekOffset)))"
    }

    private func hasLessons(on d: Int) -> Bool {
        !ScheduleEngine.slots(on: date(for: d, offset: weekOffset), data: schedule.data).isEmpty
    }

    // MARK: пары дня

    @ViewBuilder private var dayContent: some View {
        let slots = ScheduleEngine.slots(on: selectedDate, data: schedule.data)
        if slots.isEmpty {
            let busy = schedule.syncing || schedule.loadingWeek
            EmptyState(icon: busy ? "arrow.triangle.2.circlepath" : (isPastUnknown ? "clock.badge.questionmark" : "sun.max.fill"),
                       title: busy ? L("Ищу в РУЗ…") : (isPastUnknown ? L("Эта неделя не сохранена") : L("Пар нет")),
                       text: emptyText)
        } else {
            VStack(spacing: 10) {
                if !schedule.data.usesRuz && schedule.data.isArchived(selectedDate) {
                    Label(L("Расписание из архива: так было на этой неделе"), systemImage: "clock.arrow.circlepath")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                if schedule.data.usesRuz && selectedDate < Calendar.current.startOfDay(for: Date()) {
                    Label(L("Из памяти приложения"), systemImage: "externaldrive.fill.badge.checkmark")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                ForEach(Array(slots.enumerated()), id: \.element.key) { index, s in
                    SlotRow(slot: s, onMap: { openMap(s.address) })
                        .overlay {
                            if jump.isHighlighted(s) {
                                PairHighlight(color: SubjectColor.color(for: s.lesson.subject))
                                    .transition(.opacity)
                            }
                        }
                        .id("slot-\(Int(s.start.timeIntervalSince1970))")
                        .onTapGesture {
                            Haptics.tap()
                            detail = s
                        }
                        .contextMenu {
                            if !schedule.data.usesRuz {
                                Button { editing = s.lesson } label: { Label(L("Изменить"), systemImage: "pencil") }
                            }
                            if !s.address.isEmpty {
                                Button { openMap(s.address) } label: { Label(L("Яндекс Карты"), systemImage: "map") }
                                Button {
                                    if let u = Maps.appleURL(for: s.address) { openURL(u) }
                                } label: { Label(L("Apple Карты"), systemImage: "map.fill") }
                            }
                            if !schedule.data.usesRuz {
                                Button(role: .destructive) {
                                    withAnimation { schedule.delete(s.lesson) }
                                } label: { Label(L("Удалить"), systemImage: "trash") }
                            }
                        }
                }
            }
        }
    }

    /// Прошлая неделя, которую приложение не успело запомнить
    private var isPastUnknown: Bool {
        schedule.data.usesRuz
            && selectedDate < Calendar.current.startOfDay(for: Date())
            && !schedule.hasEvents(inWeekOf: selectedDate)
    }

    private var emptyText: String {
        if isPastUnknown {
            let f = Fmt.formatter("d MMMM")
            let since = schedule.memorySince.map { L(" Сейчас в памяти всё с \(f.string(from: $0)).") } ?? ""
            return L("РУЗ показывает только текущую и будущие недели, а приложение запоминает расписание с момента подключения. Каждая следующая неделя сохранится автоматически.\(since)")
        }
        if schedule.data.usesRuz {
            let cal = Calendar.current
            if let last = schedule.data.ruzEvents.last?.start, selectedDate > last,
               !cal.isDate(selectedDate, inSameDayAs: last) {
                return L("РУЗ пока не выложил пары на эти даты.")
            }
            return L("В этот день свободно.")
        }
        return L("В этот день свободно.")
    }

    private func openMap(_ address: String) {
        guard !address.isEmpty else { return }
        Haptics.tap()
        Maps.open(address)
    }

    private var bellsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: L("Звонки"))
            VStack(spacing: 8) {
                ForEach(1...Bells.times.count, id: \.self) { p in
                    HStack {
                        Text(L("\(p) пара")).foregroundStyle(.secondary)
                        Spacer()
                        Text(Bells.label(p)).monospacedDigit().fontWeight(.semibold)
                    }
                    .font(.subheadline)
                }
                Text(L("После 3-й пары обед 55 минут."))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
            .glass(22)
        }
    }
}

struct ChangesSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if schedule.changes.isEmpty {
                    Text(L("Изменений пока не было. Когда РУЗ отменит, добавит пару или сменит аудиторию, это появится здесь и придёт уведомление."))
                        .foregroundStyle(.secondary)
                }
                ForEach(schedule.changes) { c in
                    Label(c.text, systemImage: icon(for: c.text))
                        .font(.subheadline)
                }
            }
            .navigationTitle(L("Изменения"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L("Очистить")) { schedule.clearChanges() }.disabled(schedule.changes.isEmpty)
                }
                ToolbarItem(placement: .primaryAction) {
                    ShareLink(item: shareText) { Image(systemName: "square.and.arrow.up") }
                        .disabled(schedule.changes.isEmpty)
                }
                ToolbarItem(placement: .confirmationAction) { Button(L("Готово")) { dismiss() } }
            }
        }
    }

    /// Готовое сообщение для беседы группы
    private var shareText: String {
        let list = schedule.changes.filter { $0.date > Date().addingTimeInterval(-86_400) }.prefix(10)
        let body = list.map { "• " + $0.text }.joined(separator: "\n")
        return L("📢 Изменения в расписании (РУЗ):\n") + (body.isEmpty ? "—" : body)
    }

    private func icon(for text: String) -> String {
        if text.hasPrefix("Отменена") || text.hasPrefix("Cancelled") { return "xmark.circle" }
        if text.hasPrefix("Добавлена") || text.hasPrefix("Added") { return "plus.circle" }
        return "arrow.left.arrow.right.circle"
    }
}

private struct SlotBox: Identifiable {
    let slot: LessonSlot
    var id: String { slot.key }
}

extension String {
    var capitalizedFirst: String { prefix(1).uppercased() + dropFirst() }
}

// MARK: - Первая настройка

struct SetupCard: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("group") private var group = ""
    @State private var institution = 3
    let onManual: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 52, height: 52)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(L("Расписание из РУЗ"))
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text(L("Подтягивается с ruz.narfu.ru, обновляется само и хранится офлайн"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            VStack(spacing: 10) {
                HStack {
                    Text(L("Группа")).foregroundStyle(.secondary)
                    Spacer()
                    TextField(L("Номер группы"), text: $group)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                        .font(.headline.monospacedDigit())
                }
                Divider()
                HStack {
                    Text(L("Высшая школа")).foregroundStyle(.secondary)
                    Spacer()
                    Picker("", selection: $institution) {
                        ForEach(RuzClient.institutions, id: \.0) { item in
                            Text(item.1).tag(item.0)
                        }
                    }
                    .pickerStyle(.menu)
                }
            }
            .padding(14)
            .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

            Button {
                Haptics.success()
                schedule.connectRuz(number: group, institution: institution)
                Task { await schedule.sync(force: true) }
            } label: {
                Label(L("Подключить"), systemImage: "link")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .disabled(group.trimmingCharacters(in: .whitespaces).isEmpty)

            Button(action: onManual) {
                Text(L("Внести пары вручную"))
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .foregroundStyle(Color.brand)
        }
        .padding(18)
        .glass(28)
    }
}

// MARK: - Строка пары

struct SlotRow: View {
    let slot: LessonSlot
    let onMap: () -> Void
    @ObservedObject private var school = SchoolTimetable.shared
    @AppStorage("group") private var ownGroup = ""
    @AppStorage("schedule.teacher") private var showTeacher = true
    @AppStorage("schedule.compact") private var compact = false
    @ObservedObject private var hwStore = HomeworkStore.shared

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            row(now: ctx.date)
        }
    }

    /// ДЗ, которое сдавать на этой паре
    @ViewBuilder
    private var homeworkLine: some View {
        let due = hwStore.due(at: slot)
        let open = due.filter { !$0.done }
        let doneCount = due.count - open.count
        if !open.isEmpty {
            Label(open.count == 1 ? L("ДЗ: \(open[0].title)") : L("ДЗ к паре: \(HWText.tasks(open.count))"),
                  systemImage: "book.closed.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(open.contains(where: \.important) ? Color.orange : Color.brand)
                .lineLimit(1)
        } else if doneCount > 0 {
            Label(L("ДЗ сделано"), systemImage: "checkmark.seal.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.green)
        }
    }

    private func row(now: Date) -> some View {
        let active = slot.start <= now && now < slot.end
        let past = now >= slot.end
        let total = slot.end.timeIntervalSince(slot.start)
        let progress = total > 0 ? min(max(now.timeIntervalSince(slot.start) / total, 0), 1) : 0
        let minutesLeft = Int(ceil(slot.end.timeIntervalSince(now) / 60))
        let color = SubjectColor.color(for: slot.lesson.subject)

        return HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(hm(slot.start)).font(.subheadline.weight(.bold)).monospacedDigit()
                Text(hm(slot.end)).font(.caption).foregroundStyle(.secondary).monospacedDigit()
                if !compact {
                    Text(L("\(slot.lesson.pair) пара")).font(.caption2).foregroundStyle(.secondary)
                }
            }
            .frame(width: 50, alignment: .leading)

            Capsule()
                .fill(color.gradient)
                .frame(width: 4)
                .opacity(active ? 1 : 0.7)

            VStack(alignment: .leading, spacing: compact ? 3 : 5) {
                HStack(spacing: 6) {
                    KindBadge(kind: slot.lesson.kind, size: 10)
                    if slot.lesson.parity != 0 {
                        Text(slot.lesson.parity == 1 ? L("нечёт") : L("чёт")).font(.caption2).foregroundStyle(.secondary)
                    }
                    if active {
                        PulsingDot(color: color)
                        Text(L("СЕЙЧАС")).font(.caption2.weight(.heavy)).foregroundStyle(color)
                    }
                }
                Text(slot.lesson.subject)
                    .font(compact ? .subheadline.weight(.semibold) : .headline)
                    .lineLimit(2)
                if !slot.lesson.room.isEmpty || !slot.address.isEmpty {
                    Button(action: onMap) {
                        VStack(alignment: .leading, spacing: 2) {
                            if !slot.lesson.room.isEmpty {
                                Label(L("ауд. \(slot.lesson.room)"), systemImage: "door.left.hand.open")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.primary)
                            }
                            if !slot.address.isEmpty {
                                Label(AddressFormat.full(slot.address), systemImage: "mappin.and.ellipse")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.leading)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                }
                if showTeacher && !slot.lesson.teacher.isEmpty {
                    Label(slot.lesson.teacher, systemImage: "person.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.primary.opacity(0.8))
                        .lineLimit(1)
                }
                let stream = StreamInfo.groups(for: slot, own: ownGroup)
                if stream.count > 1 {
                    Label(L("Поток: \(StreamInfo.short(stream, limit: 3))"), systemImage: "person.3.fill")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                homeworkLine
                if active {
                    ProgressView(value: progress).tint(color)
                    Text(L("до конца \(minutesLeft) мин"))
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(color)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(compact ? 11 : 14)
        .glassRow(20)
        .overlay(alignment: .leading) {
            // цветная полоса типа пары слева
            UnevenRoundedRectangle(topLeadingRadius: 20, bottomLeadingRadius: 20, style: .continuous)
                .fill(KindStyle.of(slot.lesson.kind).color)
                .frame(width: 5)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(color.opacity(active ? 0.6 : 0), lineWidth: 1.5)
        )
        .opacity(past ? 0.55 : 1)
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private var placeText: String {
        var parts: [String] = []
        if !slot.lesson.room.isEmpty { parts.append(L("ауд. \(slot.lesson.room)")) }
        if !slot.address.isEmpty { parts.append(slot.address) }
        return parts.joined(separator: " · ")
    }
}

// MARK: - Подробности пары

struct LessonDetailSheet: View {
    let slot: LessonSlot
    let isManual: Bool
    let onEdit: () -> Void
    @EnvironmentObject private var tasks: TaskStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var taskDraft: StudyTask?
    @State private var hwRoute: HWEditorRoute?
    @State private var showAttendance = false
    @State private var showCamera = false
    @State private var photoSaved = false
    @AppStorage("user.role") private var role = 0
    @EnvironmentObject private var attendance: AttendanceStore
    @EnvironmentObject private var schedule: ScheduleStore

    private var color: Color { SubjectColor.color(for: slot.lesson.subject) }
    @State private var boardBatch: BoardBatch?
    @ObservedObject private var school = SchoolTimetable.shared
    @State private var schoolProgress: Double?

    private var stream: [String] { StreamInfo.groups(for: slot, own: schedule.data.ruzGroupNumber) }
    private var schoolInst: Int { schedule.data.ruzInstitution > 0 ? schedule.data.ruzInstitution : 3 }

    /// Один раз собрать расписание всех групп (потом хранится на телефоне 12 часов)
    private func scanStream() async {
        schoolProgress = 0
        await school.ensure(institution: schoolInst) { done, total in
            schoolProgress = total > 0 ? Double(done) / Double(total) : 0
        }
        schoolProgress = nil
    }

    private var dateText: String {
        let f = Fmt.formatter("EEEE, d MMMM")
        return f.string(from: slot.start)
    }

    /// Фото доски этой пары: обход папки предмета — не на главном потоке
    private func loadBoard() async {
        let s = slot
        let data = schedule.data
        let b = await Task.detached(priority: .userInitiated) { LessonPhotos.batch(for: s, data: data) }.value
        boardBatch = b
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        KindBadge(kind: slot.lesson.kind, size: 12)
                        Text(slot.lesson.subject)
                            .font(.system(.title2, design: .rounded).weight(.bold))
                        Text(L("\(dateText) · \(hm(slot.start))–\(hm(slot.end)) · \(slot.lesson.pair) пара"))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 24, style: .continuous))

                    VStack(spacing: 0) {
                        if !slot.lesson.teacher.isEmpty {
                            infoRow(icon: "person.fill", title: L("Преподаватель"), value: slot.lesson.teacher)
                        }
                        if !slot.lesson.room.isEmpty {
                            infoRow(icon: "door.left.hand.open", title: L("Аудитория"), value: slot.lesson.room)
                        }
                        if !slot.address.isEmpty {
                            infoRow(icon: "mappin.and.ellipse", title: L("Адрес"), value: AddressFormat.full(slot.address))
                        }
                        if stream.count > 1 {
                            infoRow(icon: "person.3.fill", title: L("Поток · \(stream.count) групп\(stream.count < 5 ? L("ы") : "")"),
                                    value: stream.joined(separator: ", "))
                        }
                        if !slot.note.isEmpty {
                            infoRow(icon: "text.alignleft", title: L("Подробности"), value: slot.note)
                        }
                    }
                    .glass(22)
                    .task { await school.load(schoolInst) }

                    if stream.count <= 1 && schoolProgress == nil && !SchoolTimetable.shared.isFresh(schoolInst) {
                        actionButton(L("Какие группы ещё на этой паре"), icon: "person.3") {
                            Task { await scanStream() }
                        }
                    } else if let p = schoolProgress {
                        HStack(spacing: 8) {
                            ProgressView(value: p)
                            Text(L("Ищу группы по РУЗ… \(Int(p * 100))%")).font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.horizontal, 4)
                    }

                    HWPairSection(slot: slot,
                                  onAdd: { hwRoute = HWEditorRoute(homework: nil, slot: slot, subject: nil) },
                                  onOpen: { hwRoute = HWEditorRoute(homework: $0, slot: nil, subject: nil, preview: true) })

                    if !slot.address.isEmpty {
                        HStack(spacing: 10) {
                            actionButton(L("Яндекс Карты"), icon: "map") {
                                Maps.open(slot.address)
                            }
                            actionButton(L("Apple Карты"), icon: "map.fill") {
                                if let u = Maps.appleURL(for: slot.address) { openURL(u) }
                            }
                        }
                    }

                    if role > 0 {
                        actionButton(L("Отметить посещаемость"), icon: "person.crop.circle.badge.checkmark") {
                            showAttendance = true
                        }
                    }

                    actionButton(L("Фото доски в папку предмета"), icon: "camera.fill") {
                        showCamera = true
                    }

                    if let b = boardBatch, !b.shots.isEmpty {
                        NavigationLink {
                            BoardBatchView(batch: b)
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "photo.stack.fill").foregroundStyle(brandGradient)
                                Text(L("Фото этой пары (\(b.shots.count)) — отправить PDF"))
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                            }
                            .padding(14)
                            .glass(18)
                        }
                        .buttonStyle(PressableStyle())
                    }

                    actionButton(L("Задача по этому предмету"), icon: "checklist") {
                        var t = StudyTask.blank()
                        t.subject = slot.lesson.subject
                        taskDraft = t
                    }

                    if isManual {
                        actionButton(L("Изменить пару"), icon: "pencil") {
                            dismiss()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { onEdit() }
                        }
                    }
                }
                .padding(20)
            }
            .navigationTitle(L("Пара"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("Готово")) { dismiss() }
                }
            }
            .sheet(item: $taskDraft) { t in
                TaskEditor(task: t, isNew: true, onSave: { tasks.upsert($0) }, onDelete: {})
            }
            .sheet(item: $hwRoute) { r in
                HomeworkSheet(route: r, data: schedule.data)
                    .environmentObject(schedule)
            }
            .fullScreenCover(isPresented: $showCamera) {
                CameraPicker { image in
                    showCamera = false
                    if let image, BoardPhoto.save(image, subject: slot.lesson.subject) != nil {
                        Haptics.success()
                        photoSaved = true
                    }
                }
                .ignoresSafeArea()
            }
            // фото пары ищутся в фоне — карточка пары открывается без задержки
            .task { await loadBoard() }
            .onReceive(NotificationCenter.default.publisher(for: .boardPhotoWritten)) { _ in
                Task { await loadBoard() }
            }
            .alert(L("Фото сохранено"), isPresented: $photoSaved) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(L("Лежит в «Файлы › Предметы › \(slot.lesson.subject)»."))
            }
            .sheet(isPresented: $showAttendance) {
                NavigationStack {
                    AttendanceView(slot: slot)
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) { Button(L("Готово")) { showAttendance = false } }
                        }
                }
                .environmentObject(attendance)
                .environmentObject(schedule)
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func infoRow(icon: String, title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.subheadline)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
    }

    private func actionButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .glass(18, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - Настройки расписания

struct ScheduleSettingsSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @AppStorage("schedule.teacher") private var showTeacher = true
    @AppStorage("schedule.compact") private var compact = false
    @AppStorage("schedule.colors") private var colors = true
    @State private var group = ""
    @State private var institution = 3
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker(L("Источник"), selection: Binding(
                        get: { schedule.data.source },
                        set: { v in
                            if v == 1 {
                                schedule.connectRuz(number: group, institution: institution, id: schedule.data.ruzGroupID)
                                Task { await schedule.sync(force: true) }
                            } else {
                                schedule.useManual()
                            }
                        })) {
                        Text(L("РУЗ")).tag(1)
                        Text(L("Вручную")).tag(0)
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text(L("Откуда брать пары"))
                }

                if schedule.data.usesRuz {
                    Section {
                        HStack {
                            Text(L("Группа"))
                            Spacer()
                            TextField(L("Номер группы"), text: $group)
                                .keyboardType(.numberPad)
                                .multilineTextAlignment(.trailing)
                        }
                        Picker(L("Высшая школа"), selection: $institution) {
                            ForEach(RuzClient.institutions, id: \.0) { item in
                                Text(item.1).tag(item.0)
                            }
                        }
                        Button {
                            schedule.connectRuz(number: group, institution: institution)
                            Task { await schedule.sync(force: true) }
                        } label: {
                            Label(L("Сохранить и обновить"), systemImage: "arrow.clockwise")
                        }
                    } header: {
                        Text(L("РУЗ"))
                    } footer: {
                        Text(L("\(schedule.lastSyncText.capitalizedFirst). \(schedule.data.syncInfo) В памяти: \(schedule.data.ruzEvents.count) пар, \(schedule.rememberedWeeks) нед. Если группа не находится, открой РУЗ на главной, найди свою группу и нажми «Сделать моим расписанием»."))
                    }

                    Section {
                        if let u = RuzClient.timetableURL(groupID: schedule.data.ruzGroupID), !schedule.data.ruzGroupID.isEmpty {
                            Button { openURL(u) } label: { Label(L("Открыть мою группу в РУЗ"), systemImage: "safari") }
                        }
                        Button(role: .destructive) { confirmClear = true } label: {
                            Label(L("Очистить кеш РУЗ"), systemImage: "trash")
                        }
                    }
                }

                Section(L("Вид")) {
                    Toggle(L("Цвета предметов"), isOn: $colors)
                    Toggle(L("Показывать преподавателя"), isOn: $showTeacher)
                    Toggle(L("Компактные карточки"), isOn: $compact)
                }
            }
            .navigationTitle(L("Расписание"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("Готово")) { dismiss() }
                }
            }
            .confirmationDialog(L("Удалить все сохранённые пары из РУЗ?"), isPresented: $confirmClear, titleVisibility: .visible) {
                Button(L("Очистить"), role: .destructive) { schedule.clearRuzCache() }
            }
            .onAppear {
                group = schedule.data.ruzGroupNumber.isEmpty
                    ? (UserDefaults.standard.string(forKey: "group") ?? "")
                    : schedule.data.ruzGroupNumber
                institution = schedule.data.ruzInstitution
            }
        }
    }
}

// MARK: - Карточка «Сейчас» на главной

/// Рамка ряда кнопок и файлов внутри карточки «Сейчас»
private struct StripFrameKey: PreferenceKey {
    static let defaultValue: CGRect = .zero
    static func reduce(value: inout CGRect, nextValue: () -> CGRect) {
        let n = nextValue()
        if n != .zero { value = n }
    }
}

struct NowCard: View {
    let data: ScheduleData
    let onOpen: () -> Void
    let onMap: (String) -> Void
    var onPhoto: ((LessonSlot) -> Void)? = nil
    /// «Где пара»: аудитория, этаж, как найти, маршрут
    var onPlace: ((LessonSlot) -> Void)? = nil
    /// Записать ДЗ с этой пары
    var onHomework: ((LessonSlot) -> Void)? = nil
    /// Сколько невыполненных ДЗ по предмету (для счётчика на кнопке)
    var homeworkCount: ((String) -> Int)? = nil
    /// Листание свайпом: nil — текущая/следующая пара, иначе начало выбранной пары
    /// (запоминаем саму пару, а не сдвиг: иначе с концом пары выбранная карточка «уезжала» на соседнюю)
    @State private var picked: Date?
    /// Где на карточке ряд кнопок и файлов: его листают пальцем, и пара при этом перелистываться не должна
    @State private var stripFrame: CGRect = .zero
    /// Счётчик ДЗ на кнопке: правка домашки обновляет только эту карточку, а не всю главную
    @ObservedObject private var hwStore = HomeworkStore.shared

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            card(now: ctx.date)
        }
    }

    /// Пары за неделю назад и вперёд и индекс «главной» (идёт сейчас или ближайшая)
    private func around(_ now: Date) -> (all: [LessonSlot], base: Int) {
        let all = ScheduleQuery.slots(data, from: -7, days: 15).sorted { $0.start < $1.start }
        let base = all.firstIndex { $0.end > now } ?? all.count
        return (all, base)
    }

    private func step(_ d: Int) {
        let a = around(Date())
        let cur = picked.flatMap { p in a.all.firstIndex { $0.start == p } } ?? a.base
        let target = cur + d
        // дальше краёв не листаем (раньше «Дальше» после последней пары уводило назад)
        guard a.all.indices.contains(target) else { return }
        Haptics.tap()
        withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) {
            picked = target == a.base ? nil : a.all[target].start
        }
    }

    private var swipe: some Gesture {
        DragGesture(minimumDistance: 24, coordinateSpace: .named(Self.space))
            .onEnded { v in
                // свайп начался на ряду файлов — это прокрутка ряда, а не смена пары
                guard !stripFrame.insetBy(dx: -4, dy: -8).contains(v.startLocation) else { return }
                let w = v.translation.width, h = v.translation.height
                guard abs(w) > 50, abs(w) > abs(h) * 1.4 else { return }
                step(w < 0 ? 1 : -1)
            }
    }

    private func card(now: Date) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            if picked == nil {
                live(now: now)
            } else {
                browsed(now: now)
            }
            pager
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .glass(28)
        .contentShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .onTapGesture(perform: onOpen)
        .simultaneousGesture(swipe)
        .onPreferenceChange(StripFrameKey.self) { stripFrame = $0 }
        .coordinateSpace(name: Self.space)
    }

    private static let space = "nowCard"


    /// Стрелки ‹ › под карточкой — листать можно и нажатием
    private var pager: some View {
        HStack {
            Button { step(-1) } label: {
                Label(L("Раньше"), systemImage: "chevron.left")
            }
            Spacer()
            if picked != nil {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) { picked = nil }
                } label: {
                    Label(L("К текущей"), systemImage: "arrow.uturn.backward")
                }
                Spacer()
            }
            Button { step(1) } label: {
                HStack(spacing: 4) { Text(L("Дальше")); Image(systemName: "chevron.right") }
            }
        }
        .font(.caption.weight(.semibold))
        .foregroundStyle(.secondary)
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func browsed(now: Date) -> some View {
        let a = around(now)
        if let s = a.all.first(where: { $0.start == picked }) {
            let past = s.end <= now
            let color = SubjectColor.color(for: s.lesson.subject)
            HStack(alignment: .top) {
                header(past ? L("ПРОШЛА") : (s.start <= now ? L("СЕЙЧАС") : L("ВПЕРЕДИ")), live: false, color: color)
                Spacer()
                Text(dayLabel(s, now))
                    .font(.caption.weight(.bold))
                    .foregroundStyle(color)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(color.opacity(0.14), in: Capsule())
            }
            lessonTitle(s)
            placeButton(s)
            actions(s, photo: past)
        } else {
            header(L("ПАРЫ"), live: false, color: .brand)
            Text(L("Эта пара пропала из расписания"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    private func dayLabel(_ s: LessonSlot, _ now: Date) -> String {
        let cal = Calendar.current
        let t = hm(s.start)
        if cal.isDate(s.start, inSameDayAs: now) { return L("сегодня · \(t)") }
        if cal.isDateInYesterday(s.start) { return L("вчера · \(t)") }
        if cal.isDateInTomorrow(s.start) { return L("завтра · \(t)") }
        let wd = ScheduleEngine.weekday(of: s.start)
        return "\(Lesson.dayFullNames[wd - 1]) · \(t)"
    }

    @ViewBuilder
    private func live(now: Date) -> some View {
        let r = ScheduleEngine.nowAndNext(at: now, data: data)
            if let c = r.current {
                HStack(alignment: .center, spacing: 14) {
                    VStack(alignment: .leading, spacing: 6) {
                        header(L("СЕЙЧАС"), live: true, color: SubjectColor.color(for: c.lesson.subject))
                        lessonTitle(c)
                    }
                    Spacer(minLength: 4)
                    ring(progress: progress(c, now),
                         minutes: Int(ceil(c.end.timeIntervalSince(now) / 60)),
                         color: SubjectColor.color(for: c.lesson.subject))
                }
                placeButton(c)
                // ДЗ, фото доски и закреплённые ссылки — одной строкой, чтобы карточка не разрасталась
                actions(c, photo: true)
                if let n = r.next {
                    Divider().opacity(0.4)
                    HStack(spacing: 6) {
                        Text(L("Потом")).foregroundStyle(.secondary)
                        Text(n.lesson.subject).fontWeight(.semibold).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(when(n, now)).foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                }
            } else if let n = r.next {
                HStack(alignment: .top) {
                    header(L("СЛЕДУЮЩАЯ ПАРА"), live: false, color: SubjectColor.color(for: n.lesson.subject))
                    Spacer()
                    Text(when(n, now))
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.brand.opacity(0.14), in: Capsule())
                }
                lessonTitle(n)
                placeButton(n)
                actions(n, photo: false)
            } else {
                header(L("ПАРЫ"), live: false, color: .brand)
                Text(L("На ближайшую неделю пар нет"))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
    }

    /// Ряд действий под парой: ДЗ, фото доски, файлы и закрепы
    private func actions(_ s: LessonSlot, photo: Bool) -> some View {
        let photoAction: (() -> Void)? = (photo && onPhoto != nil) ? { onPhoto?(s) } : nil
        let homeworkAction: (() -> Void)? = onHomework != nil ? { onHomework?(s) } : nil
        return SubjectPinsStrip(subject: s.lesson.subject, editable: true, showFolder: true,
                                onPhoto: photoAction,
                                onHomework: homeworkAction,
                                homeworkCount: homeworkCount?(s.lesson.subject) ?? 0)
            .background(GeometryReader { g in
                Color.clear.preference(key: StripFrameKey.self, value: g.frame(in: .named(Self.space)))
            })
    }

    private func header(_ title: String, live: Bool, color: Color) -> some View {
        HStack(spacing: 6) {
            if live {
                PulsingDot(color: color)
            } else {
                Image(systemName: "snowflake")
            }
            Text(title)
        }
        .font(.caption.weight(.heavy))
        .foregroundStyle(color)
    }

    private func lessonTitle(_ s: LessonSlot) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            KindBadge(kind: s.lesson.kind, size: 11)
            Text(s.lesson.subject)
                .font(.system(.title3, design: .rounded).weight(.bold))
                .lineLimit(2)
            Text("\(hm(s.start))–\(hm(s.end))\(s.lesson.teacher.isEmpty ? "" : " · \(s.lesson.teacher)")")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private func placeButton(_ s: LessonSlot) -> some View {
        if !s.lesson.room.isEmpty || !s.address.isEmpty {
            Button {
                if let onPlace { onPlace(s) } else { onMap(s.address) }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.title3)
                        .foregroundStyle(brandGradient)
                    VStack(alignment: .leading, spacing: 1) {
                        if !s.lesson.room.isEmpty {
                            Text(L("ауд. \(s.lesson.room)"))
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary)
                        }
                        if !s.address.isEmpty {
                            Text(AddressFormat.full(s.address))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Spacer(minLength: 0)
                    if !s.address.isEmpty {
                        Image(systemName: "arrow.up.right")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(Color.brand.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .disabled(s.address.isEmpty && onPlace == nil)
        }
    }

    private func ring(progress: Double, minutes: Int, color: Color) -> some View {
        ZStack {
            Circle().stroke(color.opacity(0.18), lineWidth: 6)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(color.gradient, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut(duration: 0.8), value: progress)
            VStack(spacing: 0) {
                Text("\(minutes)")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                    .monospacedDigit()
                Text(L("мин"))
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: 56, height: 56)
    }

    private func progress(_ s: LessonSlot, _ now: Date) -> Double {
        let total = s.end.timeIntervalSince(s.start)
        guard total > 0 else { return 0 }
        return min(max(now.timeIntervalSince(s.start) / total, 0), 1)
    }

    private func when(_ s: LessonSlot, _ now: Date) -> String {
        let cal = Calendar.current
        let minutes = Int(ceil(s.start.timeIntervalSince(now) / 60))
        if cal.isDate(s.start, inSameDayAs: now) {
            return minutes <= 90 ? L("через \(minutes) мин") : L("в \(hm(s.start))")
        }
        if cal.isDateInTomorrow(s.start) { return L("завтра в \(hm(s.start))") }
        let wd = ScheduleEngine.weekday(of: s.start)
        return L("\(Lesson.dayFullNames[wd - 1]) в \(hm(s.start))")
    }
}

// MARK: - Редактор пары

struct LessonEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var lesson: Lesson
    @State private var savedCount = 0
    private let isNew: Bool
    private let buildings: [Building]
    private let onSave: (Lesson) -> Void
    private let onDelete: () -> Void

    init(lesson: Lesson, isNew: Bool, buildings: [Building],
         onSave: @escaping (Lesson) -> Void,
         onDelete: @escaping () -> Void) {
        _lesson = State(initialValue: lesson)
        self.isNew = isNew
        self.buildings = buildings
        self.onSave = onSave
        self.onDelete = onDelete
    }

    private var canSave: Bool {
        !lesson.subject.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField(L("Предмет"), text: $lesson.subject)
                        .font(.headline)
                    Picker(L("Тип"), selection: $lesson.kind) {
                        ForEach(Lesson.kinds, id: \.self) { Text(KindStyle.display($0)).tag($0) }
                    }
                }

                Section(L("Когда")) {
                    Picker(L("День"), selection: $lesson.weekday) {
                        ForEach(1...6, id: \.self) { d in
                            Text(Lesson.dayNames[d - 1]).tag(d)
                        }
                    }
                    .pickerStyle(.segmented)
                    Picker(L("Пара"), selection: $lesson.pair) {
                        ForEach(1...Bells.times.count, id: \.self) { p in
                            Text(L("\(p) пара · \(Bells.label(p))")).tag(p)
                        }
                    }
                    Picker(L("Неделя"), selection: $lesson.parity) {
                        Text(L("Каждую")).tag(0)
                        Text(L("Нечётная")).tag(1)
                        Text(L("Чётная")).tag(2)
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    TextField(L("Аудитория, например 3104"), text: $lesson.room)
                    Picker(L("Корпус"), selection: $lesson.building) {
                        Text(L("Не указан")).tag("")
                        ForEach(buildings) { b in
                            Text(b.name).tag(b.name)
                        }
                    }
                } header: {
                    Text(L("Где"))
                } footer: {
                    Text(L("Корпуса и их адреса настраиваются в меню «+» на экране «Пары»."))
                }

                Section {
                    TextField(L("Преподаватель"), text: $lesson.teacher)
                }

                if isNew {
                    Section {
                        Button {
                            onSave(lesson)
                            Haptics.success()
                            savedCount += 1
                            var next = lesson
                            next.id = UUID()
                            next.subject = ""
                            next.teacher = ""
                            next.room = ""
                            next.pair = min(lesson.pair + 1, Bells.times.count)
                            lesson = next
                        } label: {
                            Label(L("Сохранить и добавить следующую"), systemImage: "plus.circle")
                        }
                        .disabled(!canSave)
                    } footer: {
                        if savedCount > 0 {
                            Text(L("Добавлено пар: \(savedCount)"))
                        }
                    }
                } else {
                    Section {
                        Button(role: .destructive) {
                            onDelete()
                            dismiss()
                        } label: {
                            Label(L("Удалить пару"), systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle(isNew ? L("Новая пара") : L("Пара"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(savedCount > 0 ? L("Закрыть") : L("Отмена")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("Готово")) {
                        onSave(lesson)
                        Haptics.success()
                        dismiss()
                    }
                    .disabled(!canSave)
                }
            }
        }
    }
}

// MARK: - Корпуса

struct BuildingsSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach($schedule.data.buildings) { $b in
                        VStack(alignment: .leading, spacing: 6) {
                            TextField(L("Название"), text: $b.name)
                                .font(.headline)
                            TextField(L("Адрес"), text: $b.address)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                    .onDelete { schedule.data.buildings.remove(atOffsets: $0) }

                    Button {
                        schedule.data.buildings.append(Building(name: L("Корпус \(schedule.data.buildings.count + 1)"),
                                                                address: L("Архангельск, ")))
                    } label: {
                        Label(L("Добавить корпус"), systemImage: "plus")
                    }
                } footer: {
                    Text(L("Для расписания из РУЗ: в названии укажи код корпуса, как он пишется в РУЗ (например, А-НСД17), а в адресе — как его показывать. Аудитория из кода подставится сама."))
                }
            }
            .navigationTitle(L("Корпуса"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("Готово")) { dismiss() }
                }
            }
        }
    }
}

// MARK: - Экспорт в Календарь

struct ExportSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @State private var weeks = 8
    @State private var alert = true
    @State private var status: String?
    @State private var working = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Stepper(L("Недель вперёд: \(weeks)"), value: $weeks, in: 1...20)
                    Toggle(L("Напоминание за 15 минут"), isOn: $alert)
                } footer: {
                    Text(L("Создам отдельный календарь «\(CalendarExporter.calendarTitle)». Стандартный виджет «Календарь» будет показывать следующую пару с аудиторией и адресом, а Карты подскажут, когда выходить. Повторный экспорт заменяет старые пары."))
                }

                Section {
                    Button {
                        run()
                    } label: {
                        HStack {
                            Label(L("Добавить в Календарь"), systemImage: "calendar.badge.plus")
                            Spacer()
                            if working { ProgressView() }
                        }
                    }
                    .disabled(working || !schedule.hasLessons)
                } footer: {
                    if let status {
                        Text(status)
                    } else if !schedule.hasLessons {
                        Text(L("Сначала добавь пары."))
                    }
                }
            }
            .navigationTitle(L("Календарь"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(L("Готово")) { dismiss() }
                }
            }
        }
    }

    private func run() {
        working = true
        status = nil
        let data = schedule.data
        let w = weeks
        let a = alert
        Task {
            do {
                let count = try await CalendarExporter.export(data: data, weeks: w, alert: a)
                await MainActor.run {
                    working = false
                    status = L("Готово: добавлено пар — \(count).")
                    Haptics.success()
                }
            } catch {
                await MainActor.run {
                    working = false
                    status = error.localizedDescription
                }
            }
        }
    }
}
