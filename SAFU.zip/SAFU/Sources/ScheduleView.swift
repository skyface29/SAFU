import SwiftUI

enum Maps {
    static func url(for address: String) -> URL? {
        if AddressFormat.isRemote(address) { return nil }
        var q = address
        if !q.lowercased().contains("архангельск") { q = "Архангельск, " + q }
        let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "https://yandex.ru/maps/?text=\(encoded)")
    }

    static func appleURL(for address: String) -> URL? {
        if AddressFormat.isRemote(address) { return nil }
        var q = address
        if !q.lowercased().contains("архангельск") { q = "Архангельск, " + q }
        let encoded = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        return URL(string: "https://maps.apple.com/?q=\(encoded)")
    }
}

private func hm(_ d: Date) -> String { LiveFormat.hmText(d) }

// MARK: - Экран расписания

struct ScheduleView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @EnvironmentObject private var tasks: TaskStore
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.openURL) private var openURL
    @Namespace private var ns

    @State private var day: Int = ScheduleView.todayIndex
    @State private var weekOffset = 0
    @State private var forward = true
    @State private var editing: Lesson?
    @State private var detail: LessonSlot?
    @State private var showBuildings = false
    @State private var showExport = false
    @State private var showSettings = false
    @State private var showChanges = false
    @State private var tool: Tool?

    /// Сегодняшний день 1…6 (в воскресенье показываем понедельник следующей недели)
    static var todayIndex: Int {
        let wd = ScheduleEngine.weekday(of: Date())
        return wd == 7 ? 1 : wd
    }

    private var baseMonday: Date {
        let monday = WeekKey.monday(of: Date())
        return ScheduleEngine.weekday(of: Date()) == 7
            ? (Calendar.current.date(byAdding: .day, value: 7, to: monday) ?? monday)
            : monday
    }

    private func date(for d: Int, offset: Int) -> Date {
        Calendar.current.date(byAdding: .day, value: offset * 7 + d - 1, to: baseMonday) ?? baseMonday
    }

    private var selectedDate: Date { date(for: day, offset: weekOffset) }
    private var isToday: Bool { weekOffset == 0 && day == ScheduleView.todayIndex }

    private var weekCaption: String {
        if schedule.data.usesRuz {
            return schedule.data.ruzGroupNumber.isEmpty ? "РУЗ" : "Группа \(schedule.data.ruzGroupNumber) · РУЗ"
        }
        guard let w = Academic.week(from: schedule.data.semesterStart, now: selectedDate) else { return "Вне семестра" }
        return "Неделя \(w) · \(w % 2 == 0 ? "чётная" : "нечётная")"
    }

    private var weekRange: String {
        let f = Fmt.formatter("d MMM")
        return "\(f.string(from: date(for: 1, offset: weekOffset))) – \(f.string(from: date(for: 6, offset: weekOffset)))"
    }

    private var dayShareText: String {
        let f = Fmt.formatter("EEEE, d MMMM")
        let slots = ScheduleEngine.slots(on: selectedDate, data: schedule.data)
        var lines = ["📅 \(f.string(from: selectedDate).capitalizedFirst)"]
        if slots.isEmpty { lines.append("Пар нет") }
        for s in slots {
            let place = [s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)", AddressFormat.full(s.address)]
                .filter { !$0.isEmpty }.joined(separator: ", ")
            lines.append("\(s.lesson.pair). \(hm(s.start))–\(hm(s.end)) \(s.lesson.subject) (\(KindStyle.of(s.lesson.kind).label.lowercased()))" + (place.isEmpty ? "" : " — \(place)"))
        }
        return lines.joined(separator: "\n")
    }

    private var weekTitle: String {
        switch weekOffset {
        case 0: return "Эта неделя"
        case -1: return "Прошлая неделя"
        case 1: return "Следующая неделя"
        default: return weekOffset < 0 ? "\(-weekOffset) нед. назад" : "Через \(weekOffset) нед."
        }
    }

    // MARK: навигация

    private func shift(days delta: Int) {
        var d = day + delta
        var w = weekOffset
        if d < 1 { d = 6; w -= 1 }
        if d > 6 { d = 1; w += 1 }
        forward = delta > 0
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            day = d
            weekOffset = w
        }
    }

    private func shift(weeks delta: Int) {
        forward = delta > 0
        Haptics.tap()
        let newOffset = weekOffset + delta
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            weekOffset = newOffset
            // другая неделя всегда открывается с понедельника, своя — с сегодняшнего дня
            day = newOffset == 0 ? ScheduleView.todayIndex : 1
        }
    }

    private func goToday() {
        forward = weekOffset < 0 || (weekOffset == 0 && day < ScheduleView.todayIndex)
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            weekOffset = 0
            day = ScheduleView.todayIndex
        }
    }

    // MARK: body

    var body: some View {
        ZStack {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    ScreenHeader(caption: weekCaption, title: "Пары") { menu }

                    if schedule.data.usesRuz { syncChip }

                    if !schedule.changes.isEmpty {
                        Button {
                            schedule.markChangesSeen()
                            showChanges = true
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "exclamationmark.arrow.triangle.2.circlepath")
                                    .font(.headline)
                                    .foregroundStyle(schedule.unseenChanges > 0 ? Color.orange : Color.secondary)
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(schedule.unseenChanges > 0 ? "Расписание изменилось: \(schedule.unseenChanges)" : "Журнал изменений")
                                        .font(.subheadline.weight(.bold))
                                        .foregroundStyle(.primary)
                                    Text(schedule.changes.first?.text ?? "")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(1)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: "chevron.right")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.secondary)
                            }
                            .padding(14)
                            .glass(18, interactive: true)
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }

                    if schedule.isConfigured {
                        weekNavigator
                        daySelector
                        dayContent
                            .id("\(weekOffset)-\(day)-\(schedule.data.ruzEvents.count)")
                            .transition(.asymmetric(
                                insertion: .move(edge: forward ? .trailing : .leading).combined(with: .opacity),
                                removal: .opacity))
                            .contentShape(Rectangle())
                            .simultaneousGesture(
                                DragGesture(minimumDistance: 30).onEnded { value in
                                    guard abs(value.translation.width) > abs(value.translation.height) * 1.5,
                                          abs(value.translation.width) > 60 else { return }
                                    shift(days: value.translation.width < 0 ? 1 : -1)
                                }
                            )
                        bellsCard
                    } else {
                        SetupCard(onManual: { editing = Lesson(subject: "", weekday: day, pair: 1) })
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 40)
            }
            .refreshable { await schedule.sync(force: true) }
        }
        .task { await schedule.sync() }
        .task(id: weekOffset) {
            if weekOffset < 0 && schedule.data.usesRuz {
                await schedule.loadArchiveWeek(date(for: 1, offset: weekOffset))
            }
        }
        .sheet(item: $editing) { l in
            LessonEditor(lesson: l,
                         isNew: !schedule.contains(l),
                         buildings: schedule.data.buildings,
                         onSave: { schedule.upsert($0) },
                         onDelete: { schedule.delete(l) })
        }
        .sheet(item: Binding(get: { detail.map { SlotBox(slot: $0) } },
                             set: { detail = $0?.slot })) { box in
            LessonDetailSheet(slot: box.slot,
                              isManual: !schedule.data.usesRuz,
                              onEdit: { editing = box.slot.lesson })
                .environmentObject(tasks)
                .environmentObject(schedule)
                .environmentObject(attendance)
        }
        .sheet(isPresented: $showBuildings) { BuildingsSheet().environmentObject(schedule) }
        .sheet(isPresented: $showExport) { ExportSheet().environmentObject(schedule) }
        .sheet(isPresented: $showSettings) { ScheduleSettingsSheet().environmentObject(schedule) }
        .sheet(isPresented: $showChanges) { ChangesSheet().environmentObject(schedule) }
        .sheet(item: $tool) { t in
            ToolSheet(tool: t).environmentObject(schedule).environmentObject(tasks).environmentObject(attendance)
        }
    }

    private var menu: some View {
        Menu {
            if schedule.data.usesRuz {
                Button { Task { await schedule.sync(force: true) } } label: {
                    Label("Обновить из РУЗ", systemImage: "arrow.clockwise")
                }
                if let u = RuzClient.timetableURL(groupID: schedule.data.ruzGroupID), !schedule.data.ruzGroupID.isEmpty {
                    Button { openURL(u) } label: { Label("Открыть группу в РУЗ", systemImage: "safari") }
                }
                Button { showBuildings = true } label: { Label("Коды корпусов и адреса", systemImage: "building.2") }
            } else {
                Button { editing = Lesson(subject: "", weekday: day, pair: 1) } label: {
                    Label("Добавить пару", systemImage: "plus")
                }
                Button { showBuildings = true } label: { Label("Корпуса и адреса", systemImage: "building.2") }
            }
            Button { showExport = true } label: { Label("В Календарь iPhone", systemImage: "calendar.badge.plus") }
            Divider()
            Button { tool = .session } label: { Label("Сессия", systemImage: "graduationcap") }
            Button { tool = .subjects } label: { Label("Предметы", systemImage: "books.vertical") }
            Button { tool = .teachers } label: { Label("Преподаватели", systemImage: "person.2") }
            Button { tool = .map } label: { Label("Карта корпусов", systemImage: "map") }
            Button { showChanges = true } label: { Label("Журнал изменений", systemImage: "clock.arrow.circlepath") }
            ShareLink(item: dayShareText) { Label("Отправить расписание дня", systemImage: "square.and.arrow.up") }
            Divider()
            Button { showSettings = true } label: { Label("Настройки расписания", systemImage: "slider.horizontal.3") }
        } label: {
            CircleIconButton(icon: "ellipsis")
        }
    }

    // MARK: статус синхронизации

    private var syncChip: some View {
        Button { Task { await schedule.sync(force: true) } } label: {
            HStack(spacing: 8) {
                SpinningIcon(spinning: schedule.syncing)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(Color.brand)
                Text(schedule.syncing ? "Обновляю из РУЗ…" : schedule.lastSyncText.capitalizedFirst)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.primary)
                if !schedule.data.syncInfo.isEmpty && !schedule.syncing {
                    Text("· " + schedule.data.syncInfo)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .glass(16, interactive: true)
        }
        .buttonStyle(PressableStyle())
        .animation(.easeInOut(duration: 0.25), value: schedule.syncing)
    }

    // MARK: недели и дни

    private var weekNavigator: some View {
        HStack(spacing: 10) {
            Button { shift(weeks: -1) } label: {
                Image(systemName: "chevron.left")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())

            VStack(spacing: 2) {
                Text(weekTitle).font(.subheadline.weight(.bold))
                Text(weekRange).font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)

            if !isToday {
                Button(action: goToday) {
                    Text("Сегодня")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .frame(height: 32)
                        .background(brandGradient, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .transition(.scale.combined(with: .opacity))
            }

            Button { shift(weeks: 1) } label: {
                Image(systemName: "chevron.right")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 40, height: 40)
                    .glass(20, interactive: true)
            }
            .buttonStyle(PressableStyle())
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: isToday)
    }

    private var daySelector: some View {
        HStack(spacing: 4) {
            ForEach(1...6, id: \.self) { d in
                Button {
                    Haptics.tap()
                    forward = d > day
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { day = d }
                } label: {
                    VStack(spacing: 4) {
                        Text(Lesson.dayNames[d - 1]).font(.caption.weight(.semibold))
                        Text(dayNumber(d))
                            .font(.system(.headline, design: .rounded))
                            .underline(weekOffset == 0 && d == ScheduleView.todayIndex && day != d)
                        Circle()
                            .fill(hasLessons(on: d) ? (day == d ? Color.white : Color.brand) : Color.clear)
                            .frame(width: 5, height: 5)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .foregroundStyle(day == d ? Color.white : Color.primary)
                    .background {
                        if day == d {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(brandGradient)
                                .matchedGeometryEffect(id: "day", in: ns)
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .glass(22)
    }

    private func dayNumber(_ d: Int) -> String {
        "\(Calendar.current.component(.day, from: date(for: d, offset: weekOffset)))"
    }

    private func hasLessons(on d: Int) -> Bool {
        !ScheduleEngine.slots(on: date(for: d, offset: weekOffset), data: schedule.data).isEmpty
    }

    // MARK: пары дня

    @ViewBuilder private var dayContent: some View {
        let slots = ScheduleEngine.slots(on: selectedDate, data: schedule.data)
        if slots.isEmpty {
            let busy = schedule.syncing || schedule.loadingWeek
            EmptyState(icon: busy ? "arrow.triangle.2.circlepath" : (isPastUnknown ? "clock.badge.questionmark" : "sun.max.fill"),
                       title: busy ? "Ищу в РУЗ…" : (isPastUnknown ? "Эта неделя не сохранена" : "Пар нет"),
                       text: emptyText)
        } else {
            VStack(spacing: 10) {
                if !schedule.data.usesRuz && schedule.data.isArchived(selectedDate) {
                    Label("Расписание из архива: так было на этой неделе", systemImage: "clock.arrow.circlepath")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                if schedule.data.usesRuz && selectedDate < Calendar.current.startOfDay(for: Date()) {
                    Label("Из памяти приложения", systemImage: "externaldrive.fill.badge.checkmark")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                ForEach(Array(slots.enumerated()), id: \.element.key) { index, s in
                    SlotRow(slot: s, onMap: { openMap(s.address) })
                        .staggerIn(index)
                        .onTapGesture {
                            Haptics.tap()
                            detail = s
                        }
                        .contextMenu {
                            if !schedule.data.usesRuz {
                                Button { editing = s.lesson } label: { Label("Изменить", systemImage: "pencil") }
                            }
                            if !s.address.isEmpty {
                                Button { openMap(s.address) } label: { Label("Яндекс Карты", systemImage: "map") }
                                Button {
                                    if let u = Maps.appleURL(for: s.address) { openURL(u) }
                                } label: { Label("Apple Карты", systemImage: "map.fill") }
                            }
                            if !schedule.data.usesRuz {
                                Button(role: .destructive) {
                                    withAnimation { schedule.delete(s.lesson) }
                                } label: { Label("Удалить", systemImage: "trash") }
                            }
                        }
                }
            }
        }
    }

    /// Прошлая неделя, которую приложение не успело запомнить
    private var isPastUnknown: Bool {
        schedule.data.usesRuz
            && selectedDate < Calendar.current.startOfDay(for: Date())
            && !schedule.hasEvents(inWeekOf: selectedDate)
    }

    private var emptyText: String {
        if isPastUnknown {
            let f = Fmt.formatter("d MMMM")
            let since = schedule.memorySince.map { " Сейчас в памяти всё с \(f.string(from: $0))." } ?? ""
            return "РУЗ показывает только текущую и будущие недели, а приложение запоминает расписание с момента подключения. Каждая следующая неделя сохранится автоматически.\(since)"
        }
        if schedule.data.usesRuz {
            let cal = Calendar.current
            if let last = schedule.data.ruzEvents.last?.start, selectedDate > last,
               !cal.isDate(selectedDate, inSameDayAs: last) {
                return "РУЗ пока не выложил пары на эти даты."
            }
            return "В этот день свободно."
        }
        return "В этот день свободно."
    }

    private func openMap(_ address: String) {
        guard !address.isEmpty, let u = Maps.smartURL(for: address) else { return }
        Haptics.tap()
        openURL(u)
    }

    private var bellsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionTitle(text: "Звонки")
            VStack(spacing: 8) {
                ForEach(1...Bells.times.count, id: \.self) { p in
                    HStack {
                        Text("\(p) пара").foregroundStyle(.secondary)
                        Spacer()
                        Text(Bells.label(p)).monospacedDigit().fontWeight(.semibold)
                    }
                    .font(.subheadline)
                }
                Text("После 3-й пары обед 55 минут.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(16)
            .glass(22)
        }
    }
}

struct ChangesSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if schedule.changes.isEmpty {
                    Text("Изменений пока не было. Когда РУЗ отменит, добавит пару или сменит аудиторию, это появится здесь и придёт уведомление.")
                        .foregroundStyle(.secondary)
                }
                ForEach(schedule.changes) { c in
                    Label(c.text, systemImage: icon(for: c.text))
                        .font(.subheadline)
                }
            }
            .navigationTitle("Изменения")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Очистить") { schedule.clearChanges() }.disabled(schedule.changes.isEmpty)
                }
                ToolbarItem(placement: .primaryAction) {
                    ShareLink(item: shareText) { Image(systemName: "square.and.arrow.up") }
                        .disabled(schedule.changes.isEmpty)
                }
                ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
            }
        }
    }

    /// Готовое сообщение для беседы группы
    private var shareText: String {
        let list = schedule.changes.filter { $0.date > Date().addingTimeInterval(-86_400) }.prefix(10)
        let body = list.map { "• " + $0.text }.joined(separator: "\n")
        return "📢 Изменения в расписании (РУЗ):\n" + (body.isEmpty ? "—" : body)
    }

    private func icon(for text: String) -> String {
        if text.hasPrefix("Отменена") { return "xmark.circle" }
        if text.hasPrefix("Добавлена") { return "plus.circle" }
        return "arrow.left.arrow.right.circle"
    }
}

private struct SlotBox: Identifiable {
    let slot: LessonSlot
    var id: String { slot.key }
}

extension String {
    var capitalizedFirst: String { prefix(1).uppercased() + dropFirst() }
}

// MARK: - Первая настройка

struct SetupCard: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("group") private var group = ""
    @State private var institution = 3
    let onManual: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 52, height: 52)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Расписание из РУЗ")
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Text("Подтягивается с ruz.narfu.ru, обновляется само и хранится офлайн")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            VStack(spacing: 10) {
                HStack {
                    Text("Группа").foregroundStyle(.secondary)
                    Spacer()
                    TextField("151621", text: $group)
                        .keyboardType(.numberPad)
                        .multilineTextAlignment(.trailing)
                        .font(.headline.monospacedDigit())
                }
                Divider()
                HStack {
                    Text("Высшая школа").foregroundStyle(.secondary)
                    Spacer()
                    Picker("", selection: $institution) {
                        ForEach(RuzClient.institutions, id: \.0) { item in
                            Text(item.1).tag(item.0)
                        }
                    }
                    .pickerStyle(.menu)
                }
            }
            .padding(14)
            .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

            Button {
                Haptics.success()
                schedule.connectRuz(number: group, institution: institution)
                Task { await schedule.sync(force: true) }
            } label: {
                Label("Подключить", systemImage: "link")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .disabled(group.trimmingCharacters(in: .whitespaces).isEmpty)

            Button(action: onManual) {
                Text("Внести пары вручную")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .foregroundStyle(Color.brand)
        }
        .padding(18)
        .glass(28)
    }
}

// MARK: - Строка пары

struct SlotRow: View {
    let slot: LessonSlot
    let onMap: () -> Void
    @AppStorage("schedule.teacher") private var showTeacher = true
    @AppStorage("schedule.compact") private var compact = false

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            row(now: ctx.date)
        }
    }

    private func row(now: Date) -> some View {
        let active = slot.start <= now && now < slot.end
        let past = now >= slot.end
        let total = slot.end.timeIntervalSince(slot.start)
        let progress = total > 0 ? min(max(now.timeIntervalSince(slot.start) / total, 0), 1) : 0
        let minutesLeft = Int(ceil(slot.end.timeIntervalSince(now) / 60))
        let color = SubjectColor.color(for: slot.lesson.subject)

        return HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text(hm(slot.start)).font(.subheadline.weight(.bold)).monospacedDigit()
                Text(hm(slot.end)).font(.caption).foregroundStyle(.secondary).monospacedDigit()
                if !compact {
                    Text("\(slot.lesson.pair) пара").font(.caption2).foregroundStyle(.secondary)
                }
            }
            .frame(width: 50, alignment: .leading)

            Capsule()
                .fill(color.gradient)
                .frame(width: 4)
                .opacity(active ? 1 : 0.7)

            VStack(alignment: .leading, spacing: compact ? 3 : 5) {
                HStack(spacing: 6) {
                    KindBadge(kind: slot.lesson.kind, size: 10)
                    if slot.lesson.parity != 0 {
                        Text(slot.lesson.parity == 1 ? "нечёт" : "чёт").font(.caption2).foregroundStyle(.secondary)
                    }
                    if active {
                        PulsingDot(color: color)
                        Text("СЕЙЧАС").font(.caption2.weight(.heavy)).foregroundStyle(color)
                    }
                }
                Text(slot.lesson.subject)
                    .font(compact ? .subheadline.weight(.semibold) : .headline)
                    .lineLimit(2)
                if !slot.lesson.room.isEmpty || !slot.address.isEmpty {
                    Button(action: onMap) {
                        VStack(alignment: .leading, spacing: 2) {
                            if !slot.lesson.room.isEmpty {
                                Label("ауд. \(slot.lesson.room)", systemImage: "door.left.hand.open")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.primary)
                            }
                            if !slot.address.isEmpty {
                                Label(AddressFormat.full(slot.address), systemImage: "mappin.and.ellipse")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.leading)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                    .buttonStyle(.plain)
                }
                if showTeacher && !slot.lesson.teacher.isEmpty {
                    Label(slot.lesson.teacher, systemImage: "person.fill")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.primary.opacity(0.8))
                        .lineLimit(1)
                }
                if active {
                    ProgressView(value: progress).tint(color)
                    Text("до конца \(minutesLeft) мин")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(color)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(compact ? 11 : 14)
        .glass(20)
        .overlay(alignment: .leading) {
            // цветная полоса типа пары слева
            UnevenRoundedRectangle(topLeadingRadius: 20, bottomLeadingRadius: 20, style: .continuous)
                .fill(KindStyle.of(slot.lesson.kind).color)
                .frame(width: 5)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(color.opacity(active ? 0.6 : 0), lineWidth: 1.5)
        )
        .opacity(past ? 0.55 : 1)
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }

    private var placeText: String {
        var parts: [String] = []
        if !slot.lesson.room.isEmpty { parts.append("ауд. \(slot.lesson.room)") }
        if !slot.address.isEmpty { parts.append(slot.address) }
        return parts.joined(separator: " · ")
    }
}

// MARK: - Подробности пары

struct LessonDetailSheet: View {
    let slot: LessonSlot
    let isManual: Bool
    let onEdit: () -> Void
    @EnvironmentObject private var tasks: TaskStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var taskDraft: StudyTask?
    @State private var showAttendance = false
    @State private var showCamera = false
    @State private var photoSaved = false
    @AppStorage("user.role") private var role = 0
    @EnvironmentObject private var attendance: AttendanceStore
    @EnvironmentObject private var schedule: ScheduleStore

    private var color: Color { SubjectColor.color(for: slot.lesson.subject) }
    @State private var boardBatch: BoardBatch?

    private var dateText: String {
        let f = Fmt.formatter("EEEE, d MMMM")
        return f.string(from: slot.start)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 8) {
                        KindBadge(kind: slot.lesson.kind, size: 12)
                        Text(slot.lesson.subject)
                            .font(.system(.title2, design: .rounded).weight(.bold))
                        Text("\(dateText) · \(hm(slot.start))–\(hm(slot.end)) · \(slot.lesson.pair) пара")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .background(color.opacity(0.14), in: RoundedRectangle(cornerRadius: 24, style: .continuous))

                    VStack(spacing: 0) {
                        if !slot.lesson.teacher.isEmpty {
                            infoRow(icon: "person.fill", title: "Преподаватель", value: slot.lesson.teacher)
                        }
                        if !slot.lesson.room.isEmpty {
                            infoRow(icon: "door.left.hand.open", title: "Аудитория", value: slot.lesson.room)
                        }
                        if !slot.address.isEmpty {
                            infoRow(icon: "mappin.and.ellipse", title: "Адрес", value: AddressFormat.full(slot.address))
                        }
                        if !slot.note.isEmpty {
                            infoRow(icon: "text.alignleft", title: "Подробности", value: slot.note)
                        }
                    }
                    .glass(22)

                    if !slot.address.isEmpty {
                        HStack(spacing: 10) {
                            actionButton("Яндекс Карты", icon: "map") {
                                if let u = Maps.smartURL(for: slot.address) { openURL(u) }
                            }
                            actionButton("Apple Карты", icon: "map.fill") {
                                if let u = Maps.appleURL(for: slot.address) { openURL(u) }
                            }
                        }
                    }

                    if role > 0 {
                        actionButton("Отметить посещаемость", icon: "person.crop.circle.badge.checkmark") {
                            showAttendance = true
                        }
                    }

                    actionButton("Фото доски в папку предмета", icon: "camera.fill") {
                        showCamera = true
                    }

                    if let b = boardBatch, !b.shots.isEmpty {
                        NavigationLink {
                            BoardBatchView(batch: b)
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "photo.stack.fill").foregroundStyle(brandGradient)
                                Text("Фото этой пары (\(b.shots.count)) — отправить PDF")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                            }
                            .padding(14)
                            .glass(18)
                        }
                        .buttonStyle(PressableStyle())
                    }

                    actionButton("Задача по этому предмету", icon: "checklist") {
                        var t = StudyTask.blank()
                        t.subject = slot.lesson.subject
                        taskDraft = t
                    }

                    if isManual {
                        actionButton("Изменить пару", icon: "pencil") {
                            dismiss()
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { onEdit() }
                        }
                    }
                }
                .padding(20)
            }
            .navigationTitle("Пара")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
            .sheet(item: $taskDraft) { t in
                TaskEditor(task: t, isNew: true, onSave: { tasks.upsert($0) }, onDelete: {})
            }
            .fullScreenCover(isPresented: $showCamera) {
                CameraPicker { image in
                    showCamera = false
                    if let image, BoardPhoto.save(image, subject: slot.lesson.subject) != nil {
                        Haptics.success()
                        photoSaved = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            boardBatch = LessonPhotos.batch(for: slot, data: schedule.data)
                        }
                    }
                }
                .ignoresSafeArea()
            }
            .onAppear { boardBatch = LessonPhotos.batch(for: slot, data: schedule.data) }
            .alert("Фото сохранено", isPresented: $photoSaved) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Лежит в «Файлы › Предметы › \(slot.lesson.subject)».")
            }
            .sheet(isPresented: $showAttendance) {
                NavigationStack {
                    AttendanceView(slot: slot)
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) { Button("Готово") { showAttendance = false } }
                        }
                }
                .environmentObject(attendance)
                .environmentObject(schedule)
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func infoRow(icon: String, title: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.subheadline)
            }
            Spacer(minLength: 0)
        }
        .padding(14)
    }

    private func actionButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .glass(18, interactive: true)
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - Настройки расписания

struct ScheduleSettingsSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @AppStorage("schedule.teacher") private var showTeacher = true
    @AppStorage("schedule.compact") private var compact = false
    @AppStorage("schedule.colors") private var colors = true
    @State private var group = ""
    @State private var institution = 3
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Источник", selection: Binding(
                        get: { schedule.data.source },
                        set: { v in
                            if v == 1 {
                                schedule.connectRuz(number: group, institution: institution, id: schedule.data.ruzGroupID)
                                Task { await schedule.sync(force: true) }
                            } else {
                                schedule.useManual()
                            }
                        })) {
                        Text("РУЗ").tag(1)
                        Text("Вручную").tag(0)
                    }
                    .pickerStyle(.segmented)
                } header: {
                    Text("Откуда брать пары")
                }

                if schedule.data.usesRuz {
                    Section {
                        HStack {
                            Text("Группа")
                            Spacer()
                            TextField("151621", text: $group)
                                .keyboardType(.numberPad)
                                .multilineTextAlignment(.trailing)
                        }
                        Picker("Высшая школа", selection: $institution) {
                            ForEach(RuzClient.institutions, id: \.0) { item in
                                Text(item.1).tag(item.0)
                            }
                        }
                        Button {
                            schedule.connectRuz(number: group, institution: institution)
                            Task { await schedule.sync(force: true) }
                        } label: {
                            Label("Сохранить и обновить", systemImage: "arrow.clockwise")
                        }
                    } header: {
                        Text("РУЗ")
                    } footer: {
                        Text("\(schedule.lastSyncText.capitalizedFirst). \(schedule.data.syncInfo) В памяти: \(schedule.data.ruzEvents.count) пар, \(schedule.rememberedWeeks) нед. Если группа не находится, открой РУЗ на главной, найди свою группу и нажми «Сделать моим расписанием».")
                    }

                    Section {
                        if let u = RuzClient.timetableURL(groupID: schedule.data.ruzGroupID), !schedule.data.ruzGroupID.isEmpty {
                            Button { openURL(u) } label: { Label("Открыть мою группу в РУЗ", systemImage: "safari") }
                        }
                        Button(role: .destructive) { confirmClear = true } label: {
                            Label("Очистить кеш РУЗ", systemImage: "trash")
                        }
                    }
                }

                Section("Вид") {
                    Toggle("Цвета предметов", isOn: $colors)
                    Toggle("Показывать преподавателя", isOn: $showTeacher)
                    Toggle("Компактные карточки", isOn: $compact)
                }
            }
            .navigationTitle("Расписание")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
            .confirmationDialog("Удалить все сохранённые пары из РУЗ?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Очистить", role: .destructive) { schedule.clearRuzCache() }
            }
            .onAppear {
                group = schedule.data.ruzGroupNumber.isEmpty
                    ? (UserDefaults.standard.string(forKey: "group") ?? "")
                    : schedule.data.ruzGroupNumber
                institution = schedule.data.ruzInstitution
            }
        }
    }
}

// MARK: - Карточка «Сейчас» на главной

struct NowCard: View {
    let data: ScheduleData
    let onOpen: () -> Void
    let onMap: (String) -> Void
    var onPhoto: ((LessonSlot) -> Void)? = nil
    /// «Где пара»: аудитория, этаж, как найти, маршрут
    var onPlace: ((LessonSlot) -> Void)? = nil

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            card(now: ctx.date)
        }
    }

    private func card(now: Date) -> some View {
        let r = ScheduleEngine.nowAndNext(at: now, data: data)
        return VStack(alignment: .leading, spacing: 14) {
            if let c = r.current {
                HStack(alignment: .center, spacing: 14) {
                    VStack(alignment: .leading, spacing: 6) {
                        header("СЕЙЧАС", live: true, color: SubjectColor.color(for: c.lesson.subject))
                        lessonTitle(c)
                    }
                    Spacer(minLength: 4)
                    ring(progress: progress(c, now),
                         minutes: Int(ceil(c.end.timeIntervalSince(now) / 60)),
                         color: SubjectColor.color(for: c.lesson.subject))
                }
                placeButton(c)
                if let onPhoto {
                    Button { onPhoto(c) } label: {
                        Label("Фото доски в папку предмета", systemImage: "camera.fill")
                            .font(.caption.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.brand.opacity(0.12), in: Capsule())
                    }
                    .buttonStyle(PressableStyle())
                }
                if let n = r.next {
                    Divider().opacity(0.4)
                    HStack(spacing: 6) {
                        Text("Потом").foregroundStyle(.secondary)
                        Text(n.lesson.subject).fontWeight(.semibold).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(when(n, now)).foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                }
            } else if let n = r.next {
                HStack(alignment: .top) {
                    header("СЛЕДУЮЩАЯ ПАРА", live: false, color: SubjectColor.color(for: n.lesson.subject))
                    Spacer()
                    Text(when(n, now))
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.brand.opacity(0.14), in: Capsule())
                }
                lessonTitle(n)
                placeButton(n)
            } else {
                header("ПАРЫ", live: false, color: .brand)
                Text("На ближайшую неделю пар нет")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(18)
        .glass(28)
        .contentShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .onTapGesture(perform: onOpen)
    }

    private func header(_ title: String, live: Bool, color: Color) -> some View {
        HStack(spacing: 6) {
            if live {
                PulsingDot(color: color)
            } else {
                Image(systemName: "snowflake")
            }
            Text(title)
        }
        .font(.caption.weight(.heavy))
        .foregroundStyle(color)
    }

    private func lessonTitle(_ s: LessonSlot) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            KindBadge(kind: s.lesson.kind, size: 11)
            Text(s.lesson.subject)
                .font(.system(.title3, design: .rounded).weight(.bold))
                .lineLimit(2)
            Text("\(hm(s.start))–\(hm(s.end))\(s.lesson.teacher.isEmpty ? "" : " · \(s.lesson.teacher)")")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private func placeButton(_ s: LessonSlot) -> some View {
        if !s.lesson.room.isEmpty || !s.address.isEmpty {
            Button {
                if let onPlace { onPlace(s) } else { onMap(s.address) }
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.title3)
                        .foregroundStyle(brandGradient)
                    VStack(alignment: .leading, spacing: 1) {
                        if !s.lesson.room.isEmpty {
                            Text("ауд. \(s.lesson.room)")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.primary)
                        }
                        if !s.address.isEmpty {
                            Text(AddressFormat.full(s.address))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    Spacer(minLength: 0)
                    if !s.address.isEmpty {
                        Image(systemName: "arrow.up.right")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.secondary)
                    }
                }
                .padding(10)
                .background(Color.brand.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .disabled(s.address.isEmpty && onPlace == nil)
        }
    }

    private func ring(progress: Double, minutes: Int, color: Color) -> some View {
        ZStack {
            Circle().stroke(color.opacity(0.18), lineWidth: 6)
            Circle()
                .trim(from: 0, to: progress)
                .stroke(color.gradient, style: StrokeStyle(lineWidth: 6, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .animation(.easeInOut(duration: 0.8), value: progress)
            VStack(spacing: 0) {
                Text("\(minutes)")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                    .monospacedDigit()
                Text("мин")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: 64, height: 64)
    }

    private func progress(_ s: LessonSlot, _ now: Date) -> Double {
        let total = s.end.timeIntervalSince(s.start)
        guard total > 0 else { return 0 }
        return min(max(now.timeIntervalSince(s.start) / total, 0), 1)
    }

    private func when(_ s: LessonSlot, _ now: Date) -> String {
        let cal = Calendar.current
        let minutes = Int(ceil(s.start.timeIntervalSince(now) / 60))
        if cal.isDate(s.start, inSameDayAs: now) {
            return minutes <= 90 ? "через \(minutes) мин" : "в \(hm(s.start))"
        }
        if cal.isDateInTomorrow(s.start) { return "завтра в \(hm(s.start))" }
        let wd = ScheduleEngine.weekday(of: s.start)
        return "\(Lesson.dayFullNames[wd - 1]) в \(hm(s.start))"
    }
}

// MARK: - Редактор пары

struct LessonEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var lesson: Lesson
    @State private var savedCount = 0
    private let isNew: Bool
    private let buildings: [Building]
    private let onSave: (Lesson) -> Void
    private let onDelete: () -> Void

    init(lesson: Lesson, isNew: Bool, buildings: [Building],
         onSave: @escaping (Lesson) -> Void,
         onDelete: @escaping () -> Void) {
        _lesson = State(initialValue: lesson)
        self.isNew = isNew
        self.buildings = buildings
        self.onSave = onSave
        self.onDelete = onDelete
    }

    private var canSave: Bool {
        !lesson.subject.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Предмет", text: $lesson.subject)
                        .font(.headline)
                    Picker("Тип", selection: $lesson.kind) {
                        ForEach(Lesson.kinds, id: \.self) { Text($0).tag($0) }
                    }
                }

                Section("Когда") {
                    Picker("День", selection: $lesson.weekday) {
                        ForEach(1...6, id: \.self) { d in
                            Text(Lesson.dayNames[d - 1]).tag(d)
                        }
                    }
                    .pickerStyle(.segmented)
                    Picker("Пара", selection: $lesson.pair) {
                        ForEach(1...Bells.times.count, id: \.self) { p in
                            Text("\(p) пара · \(Bells.label(p))").tag(p)
                        }
                    }
                    Picker("Неделя", selection: $lesson.parity) {
                        Text("Каждую").tag(0)
                        Text("Нечётная").tag(1)
                        Text("Чётная").tag(2)
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    TextField("Аудитория, например 3104", text: $lesson.room)
                    Picker("Корпус", selection: $lesson.building) {
                        Text("Не указан").tag("")
                        ForEach(buildings) { b in
                            Text(b.name).tag(b.name)
                        }
                    }
                } header: {
                    Text("Где")
                } footer: {
                    Text("Корпуса и их адреса настраиваются в меню «+» на экране «Пары».")
                }

                Section {
                    TextField("Преподаватель", text: $lesson.teacher)
                }

                if isNew {
                    Section {
                        Button {
                            onSave(lesson)
                            Haptics.success()
                            savedCount += 1
                            var next = lesson
                            next.id = UUID()
                            next.subject = ""
                            next.teacher = ""
                            next.room = ""
                            next.pair = min(lesson.pair + 1, Bells.times.count)
                            lesson = next
                        } label: {
                            Label("Сохранить и добавить следующую", systemImage: "plus.circle")
                        }
                        .disabled(!canSave)
                    } footer: {
                        if savedCount > 0 {
                            Text("Добавлено пар: \(savedCount)")
                        }
                    }
                } else {
                    Section {
                        Button(role: .destructive) {
                            onDelete()
                            dismiss()
                        } label: {
                            Label("Удалить пару", systemImage: "trash")
                        }
                    }
                }
            }
            .navigationTitle(isNew ? "Новая пара" : "Пара")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(savedCount > 0 ? "Закрыть" : "Отмена") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") {
                        onSave(lesson)
                        Haptics.success()
                        dismiss()
                    }
                    .disabled(!canSave)
                }
            }
        }
    }
}

// MARK: - Корпуса

struct BuildingsSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach($schedule.data.buildings) { $b in
                        VStack(alignment: .leading, spacing: 6) {
                            TextField("Название", text: $b.name)
                                .font(.headline)
                            TextField("Адрес", text: $b.address)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                    .onDelete { schedule.data.buildings.remove(atOffsets: $0) }

                    Button {
                        schedule.data.buildings.append(Building(name: "Корпус \(schedule.data.buildings.count + 1)",
                                                                address: "Архангельск, "))
                    } label: {
                        Label("Добавить корпус", systemImage: "plus")
                    }
                } footer: {
                    Text("Для расписания из РУЗ: в названии укажи код корпуса, как он пишется в РУЗ (например, А-НСД17), а в адресе — как его показывать. Аудитория из кода подставится сама.")
                }
            }
            .navigationTitle("Корпуса")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }
}

// MARK: - Экспорт в Календарь

struct ExportSheet: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @State private var weeks = 8
    @State private var alert = true
    @State private var status: String?
    @State private var working = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Stepper("Недель вперёд: \(weeks)", value: $weeks, in: 1...20)
                    Toggle("Напоминание за 15 минут", isOn: $alert)
                } footer: {
                    Text("Создам отдельный календарь «\(CalendarExporter.calendarTitle)». Стандартный виджет «Календарь» будет показывать следующую пару с аудиторией и адресом, а Карты подскажут, когда выходить. Повторный экспорт заменяет старые пары.")
                }

                Section {
                    Button {
                        run()
                    } label: {
                        HStack {
                            Label("Добавить в Календарь", systemImage: "calendar.badge.plus")
                            Spacer()
                            if working { ProgressView() }
                        }
                    }
                    .disabled(working || !schedule.hasLessons)
                } footer: {
                    if let status {
                        Text(status)
                    } else if !schedule.hasLessons {
                        Text("Сначала добавь пары.")
                    }
                }
            }
            .navigationTitle("Календарь")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
        }
    }

    private func run() {
        working = true
        status = nil
        let data = schedule.data
        let w = weeks
        let a = alert
        Task {
            do {
                let count = try await CalendarExporter.export(data: data, weeks: w, alert: a)
                await MainActor.run {
                    working = false
                    status = "Готово: добавлено пар — \(count)."
                    Haptics.success()
                }
            } catch {
                await MainActor.run {
                    working = false
                    status = error.localizedDescription
                }
            }
        }
    }
}
