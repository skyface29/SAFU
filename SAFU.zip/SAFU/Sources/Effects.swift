import SwiftUI
import CoreMotion

// MARK: - Эффекты видеокарты: волна от пальца, блик, стеклянный отблеск от наклона, рассыпание
//
// Шейдеры — в Shaders.metal. Всё выключается само при «Уменьшении движения», в режиме энергосбережения
// и когда телефон нагрелся, а вручную — в «Оформлении» («Эффекты»).

enum FX {
    static var on: Bool {
        (UserDefaults.standard.object(forKey: "fx.shaders") as? Bool ?? true)
            && (UserDefaults.standard.object(forKey: "animations") as? Bool ?? true)
            && !UIAccessibility.isReduceMotionEnabled
            && !ProcessInfo.processInfo.isLowPowerModeEnabled
            && ProcessInfo.processInfo.thermalState.rawValue < ProcessInfo.ThermalState.serious.rawValue
    }
}

// MARK: волна от пальца

private struct RippleShader: ViewModifier {
    var origin: CGPoint
    var time: Double
    var duration: Double

    func body(content: Content) -> some View {
        content.layerEffect(
            ShaderLibrary.arkRipple(.float2(origin), .float(time), .float(9), .float(15), .float(5.5), .float(800)),
            maxSampleOffset: CGSize(width: 9, height: 9),
            isEnabled: time > 0 && time < duration)
    }
}

private struct RippleOnTap: ViewModifier {
    @State private var origin: CGPoint = .zero
    @State private var count = 0
    private let duration = 1.5

    func body(content: Content) -> some View {
        content
            .keyframeAnimator(initialValue: 0.0, trigger: count) { [origin, duration] view, t in
                view.modifier(RippleShader(origin: origin, time: t, duration: duration))
            } keyframes: { _ in
                MoveKeyframe(0)
                LinearKeyframe(duration, duration: duration)
            }
            // вместе с нажатием кнопки, а не вместо него
            .simultaneousGesture(SpatialTapGesture().onEnded { v in
                guard FX.on else { return }
                origin = v.location
                count += 1
            })
    }
}

extension View {
    /// По нажатию от пальца по всему блоку расходится волна, как по воде.
    /// Только для блоков без стекла внутри: материалы в шейдер не попадают
    func rippleOnTap() -> some View { modifier(RippleOnTap()) }

    /// Блик пробегает по карточке раз в несколько секунд, пока active
    func liveSheen(_ active: Bool, radius: CGFloat) -> some View {
        overlay { LiveSheen(active: active, radius: radius) }
    }

    /// Стеклянный отблеск: светлое пятно и кромка поворачиваются за наклоном телефона
    func tiltGlare(radius: CGFloat) -> some View {
        overlay { TiltGlare(radius: radius) }
    }
}

// MARK: блик

private struct LiveSheen: View {
    let active: Bool
    let radius: CGFloat
    @State private var run = 0

    var body: some View {
        RoundedRectangle(cornerRadius: radius, style: .continuous)
            .fill(.white)
            .keyframeAnimator(initialValue: 0.0, trigger: run) { view, p in
                view.colorEffect(ShaderLibrary.arkSheen(.boundingRect, .float(p)), isEnabled: p > 0.001 && p < 1.199)
                    .opacity(p > 0.001 && p < 1.199 ? 1 : 0)
            } keyframes: { _ in
                MoveKeyframe(0)
                CubicKeyframe(1.2, duration: 1.4)
            }
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .task(id: active) {
                guard active else { return }
                try? await Task.sleep(for: .seconds(1.2))
                while !Task.isCancelled {
                    if FX.on { run += 1 }
                    try? await Task.sleep(for: .seconds(7))
                }
            }
    }
}

// MARK: отблеск от наклона

/// Наклон телефона для отблесков. Датчик работает, только пока на экране есть хоть один отблеск
final class TiltMotion: ObservableObject {
    static let shared = TiltMotion()
    @Published private(set) var tilt = CGPoint.zero
    private let manager = CMMotionManager()
    private var users = 0
    private var smooth = CGPoint.zero

    func start() {
        users += 1
        guard users == 1, manager.isDeviceMotionAvailable, FX.on else { return }
        manager.deviceMotionUpdateInterval = 1.0 / 30.0
        manager.startDeviceMotionUpdates(to: .main) { [weak self] m, _ in
            guard let self, let g = m?.gravity else { return }
            // телефон держат с наклоном к себе — «ровно» считаем y ≈ −0.6
            let raw = CGPoint(x: max(-1, min(1, g.x * 1.8)), y: max(-1, min(1, (g.y + 0.6) * 1.8)))
            self.smooth.x += (raw.x - self.smooth.x) * 0.25
            self.smooth.y += (raw.y - self.smooth.y) * 0.25
            // мелкое дрожание руки не перерисовывает
            if abs(self.smooth.x - self.tilt.x) + abs(self.smooth.y - self.tilt.y) > 0.01 { self.tilt = self.smooth }
        }
    }

    func stop() {
        users = max(0, users - 1)
        if users == 0 { manager.stopDeviceMotionUpdates() }
    }
}

private struct TiltGlare: View {
    let radius: CGFloat
    @ObservedObject private var motion = TiltMotion.shared
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let t = motion.tilt
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        let strength = scheme == .dark ? 1.0 : 0.7
        ZStack {
            // мягкое пятно света бегает по стеклу против наклона, как отражение лампы
            shape.fill(RadialGradient(colors: [.white.opacity(0.16 * strength), .white.opacity(0)],
                                      center: UnitPoint(x: 0.5 - t.x * 0.5, y: 0.25 - t.y * 0.45),
                                      startRadius: 0, endRadius: 220))
            // светлая кромка с той стороны, куда «падает свет»
            shape.strokeBorder(
                AngularGradient(colors: [.white.opacity(0), .white.opacity(0.5 * strength), .white.opacity(0),
                                         .white.opacity(0), .white.opacity(0.22 * strength), .white.opacity(0)],
                                center: .center, angle: .radians(Double(atan2(t.y, t.x)) + .pi * 1.25)),
                lineWidth: 1)
        }
        .opacity(FX.on ? 1 : 0)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear { motion.start() }
        .onDisappear { motion.stop() }
    }
}

// MARK: рассыпание

private struct DissolveModifier: ViewModifier, Animatable {
    var progress: Double
    var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }

    func body(content: Content) -> some View {
        content.layerEffect(ShaderLibrary.arkDissolve(.boundingRect, .float(progress)),
                            maxSampleOffset: CGSize(width: 30, height: 50),
                            isEnabled: progress > 0.001)
    }
}

extension AnyTransition {
    /// Сделанное ДЗ уходит из списка: рассыпается на крошки, которые уносит вверх
    static var arkDissolve: AnyTransition {
        guard FX.on else { return .opacity }
        return .asymmetric(insertion: .opacity,
                           removal: .modifier(active: DissolveModifier(progress: 1), identity: DissolveModifier(progress: 0))
                               .animation(.easeIn(duration: 0.85)))
    }
}
