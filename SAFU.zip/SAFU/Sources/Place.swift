import SwiftUI
import UIKit

// MARK: - «Где пара»: аудитория, корпус, этаж, как найти, маршрут
// MARK: - «Свободные аудитории»: по расписанию всех групп школы из РУЗ

struct PlaceRef: Identifiable {
    let slot: LessonSlot
    var id: String { slot.key }
}

/// Свои заметки «как найти аудиторию» — один раз записал, дальше подсказка всегда под рукой
enum RoomNotes {
    private static let key = "room.notes"

    static func key(room: String, address: String) -> String {
        "\(AddressFormat.full(address).lowercased())|\(room.lowercased())"
    }

    static func get(room: String, address: String) -> String {
        let all = UserDefaults.standard.dictionary(forKey: key) as? [String: String] ?? [:]
        return all[key(room: room, address: address)] ?? ""
    }

    static func set(_ text: String, room: String, address: String) {
        var all = UserDefaults.standard.dictionary(forKey: key) as? [String: String] ?? [:]
        let k = key(room: room, address: address)
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { all.removeValue(forKey: k) } else { all[k] = t }
        UserDefaults.standard.set(all, forKey: key)
    }

    /// Этаж по номеру аудитории: у трёхзначных номеров первая цифра — этаж
    static func floorHint(_ room: String) -> String? {
        let digits = room.prefix { $0.isNumber }
        guard digits.count == 3, let f = digits.first, let n = Int(String(f)), n > 0 else { return nil }
        return "\(n) этаж"
    }
}

struct PairPlaceView: View {
    let slot: LessonSlot
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var note = ""
    @State private var copied = false

    private var room: String { slot.lesson.room }
    private var remote: Bool { AddressFormat.isRemote(slot.address) }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    hero
                    info
                    actions
                    noteCard
                    NavigationLink {
                        FreeRoomsView(preferredAddress: slot.address)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "door.left.hand.open")
                                .font(.title3)
                                .foregroundStyle(brandGradient)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Свободные аудитории рядом").font(.subheadline.weight(.bold)).foregroundStyle(.primary)
                                Text("Где посидеть в окно между парами").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(.tertiary)
                        }
                        .padding(16)
                        .glass(22)
                    }
                    .buttonStyle(PressableStyle())
                }
                .padding(20)
            }
            .background(AmbientBackground())
            .navigationTitle("Где пара")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() }.fontWeight(.semibold) }
            }
            .onAppear { note = RoomNotes.get(room: room, address: slot.address) }
            .onDisappear { RoomNotes.set(note, room: room, address: slot.address) }
        }
    }

    private var hero: some View {
        VStack(spacing: 8) {
            Image(systemName: remote ? "laptopcomputer" : "mappin.and.ellipse")
                .font(.system(size: 30, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 70, height: 70)
                .background(brandGradient, in: Circle())
                .shadow(color: Color.brand.opacity(0.4), radius: 14, y: 5)
            Text(room.isEmpty ? (remote ? "Дистанционно" : "Аудитория не указана") : "ауд. \(room)")
                .font(.system(size: 34, weight: .heavy, design: .rounded))
                .multilineTextAlignment(.center)
            Text(slot.lesson.subject)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Text(timeText)
                .font(.caption.weight(.bold))
                .foregroundStyle(Color.brand)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
        .glass(26)
    }

    private var timeText: String {
        let f = Fmt.formatter(Calendar.current.isDateInToday(slot.start) ? "'сегодня', H:mm" : "EEEE d MMMM, H:mm")
        let e = Fmt.formatter("H:mm")
        return "\(f.string(from: slot.start))–\(e.string(from: slot.end))"
    }

    private var info: some View {
        VStack(alignment: .leading, spacing: 12) {
            row("building.2.fill", "Корпус", slot.address.isEmpty ? "не указан в расписании" : AddressFormat.full(slot.address))
            if let f = RoomNotes.floorHint(room) {
                Divider().opacity(0.4)
                row("stairs", "Этаж", "\(f) (по номеру аудитории)")
            }
            if !slot.lesson.teacher.isEmpty {
                Divider().opacity(0.4)
                row("person.fill", "Преподаватель", slot.lesson.teacher)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }

    private func row(_ icon: String, _ title: String, _ value: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(brandGradient)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.subheadline.weight(.semibold)).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
    }

    private var actions: some View {
        HStack(spacing: 10) {
            Button {
                Haptics.tap()
                if let u = Maps.smartURL(for: slot.address) { openURL(u) }
            } label: {
                Label("Маршрут", systemImage: "figure.walk")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .foregroundStyle(.white)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(PressableStyle())
            .disabled(slot.address.isEmpty || remote)
            .opacity(slot.address.isEmpty || remote ? 0.5 : 1)

            Button {
                var parts: [String] = []
                if !room.isEmpty { parts.append("ауд. \(room)") }
                if !slot.address.isEmpty { parts.append(AddressFormat.full(slot.address)) }
                UIPasteboard.general.string = parts.joined(separator: ", ")
                Haptics.success()
                withAnimation { copied = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { withAnimation { copied = false } }
            } label: {
                Label(copied ? "Скопировано" : "Скопировать", systemImage: copied ? "checkmark" : "doc.on.doc")
                    .font(.subheadline.weight(.bold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .foregroundStyle(Color.brand)
                    .background(Color.brand.opacity(0.14), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(PressableStyle())
        }
    }

    private var noteCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Как найти", systemImage: "signpost.right.fill")
                .font(.system(.headline, design: .rounded))
            TextField("Например: 3 этаж, от лестницы направо, дверь в конце", text: $note, axis: .vertical)
                .lineLimit(2...5)
                .font(.subheadline)
            Text("Запиши один раз — подсказка будет появляться у этой аудитории всегда.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(22)
    }
}

// MARK: - Свободные аудитории

struct RoomBusy: Codable, Hashable {
    let room: String
    let address: String
    let start: Date
    let end: Date
    /// Как аудитория записана в РУЗ целиком («А-НСД2/1016» и т.п.)
    var code: String? = nil
}

struct FreeRoom: Identifiable {
    let room: String
    let code: String
    let until: Date?
    var id: String { room }
}

@MainActor
final class FreeRoomsStore: ObservableObject {
    static let shared = FreeRoomsStore()

    @Published private(set) var busy: [RoomBusy] = []
    @Published private(set) var scannedAt: Date?
    @Published private(set) var institution = 0
    @Published private(set) var scanning = false
    @Published private(set) var done = 0
    @Published private(set) var total = 0
    @Published var error: String?

    private struct Blob: Codable {
        var busy: [RoomBusy]
        var scannedAt: Date
        var institution: Int
    }

    private static var fileURL: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("free-rooms.v3.json")
    }

    init() {
        if let raw = try? Data(contentsOf: Self.fileURL),
           let b = try? JSONDecoder().decode(Blob.self, from: raw) {
            busy = b.busy
            scannedAt = b.scannedAt
            institution = b.institution
        }
    }

    func isFresh(for inst: Int) -> Bool {
        guard inst == institution, let s = scannedAt else { return false }
        return Date().timeIntervalSince(s) < 12 * 3600
    }

    /// Корпуса, которые встречаются в расписании школы (самые загруженные сверху)
    var addresses: [String] {
        var counts: [String: Int] = [:]
        for b in busy { counts[b.address, default: 0] += 1 }
        return counts.sorted { $0.value > $1.value }.map(\.key)
    }

    /// Аудитории корпуса, свободные весь промежуток; до скольки свободна — если дальше в этот день есть пара
    func free(address: String, from: Date, to: Date) -> [FreeRoom] {
        let here = busy.filter { $0.address == address }
        let rooms = Set(here.map(\.room))
        let dayEnd = Calendar.current.startOfDay(for: from).addingTimeInterval(86_400)
        var out: [FreeRoom] = []
        for r in rooms {
            let list = here.filter { $0.room == r }
            if list.contains(where: { $0.start < to && $0.end > from }) { continue }
            let next = list.filter { $0.start >= to && $0.start < dayEnd }.map(\.start).min()
            let code = list.compactMap(\.code).first(where: { !$0.isEmpty }) ?? ""
            out.append(FreeRoom(room: r, code: code, until: next))
        }
        return out.sorted { $0.room.localizedStandardCompare($1.room) == .orderedAscending }
    }

    /// Даты, на которые в РУЗ есть данные
    var coveredRange: ClosedRange<Date>? {
        guard let lo = busy.map(\.start).min(), let hi = busy.map(\.end).max() else { return nil }
        return lo...hi
    }

    func scan(institution inst: Int, buildings: [Building]) async {
        guard !scanning else { return }
        scanning = true
        error = nil
        done = 0
        total = 0
        defer { scanning = false }

        guard let url = URL(string: "\(RuzClient.base)?groups&institution=\(inst)"),
              let html = try? await RuzClient.fetch(url) else {
            error = "Нет связи с РУЗ. Попробуй позже."
            return
        }
        var ids: [String] = []
        var seen = Set<String>()
        for m in html.rx("group=(\\d+)") {
            let id = html.sub(m.range(at: 1))
            if seen.insert(id).inserted { ids.append(id) }
        }
        guard !ids.isEmpty else {
            error = "Не нашёл группы этой школы в РУЗ."
            return
        }
        total = ids.count

        var result: [RoomBusy] = []
        var start = 0
        while start < ids.count {
            let chunk = Array(ids[start..<min(start + 8, ids.count)])
            let part = await withTaskGroup(of: [RoomBusy].self) { group -> [RoomBusy] in
                for id in chunk {
                    group.addTask { await FreeRoomsStore.fetchBusy(groupID: id, buildings: buildings) }
                }
                var acc: [RoomBusy] = []
                for await p in group { acc += p }
                return acc
            }
            result += part
            start += chunk.count
            done = start
        }
        busy = Array(Set(result))
        scannedAt = Date()
        institution = inst
        if busy.isEmpty { error = "В РУЗ не нашлось пар с аудиториями." }
        let blob = Blob(busy: busy, scannedAt: Date(), institution: inst)
        let fileURL = Self.fileURL
        DispatchQueue.global(qos: .utility).async {
            if let raw = try? JSONEncoder().encode(blob) { try? raw.write(to: fileURL, options: .atomic) }
        }
    }

    nonisolated private static func fetchBusy(groupID: String, buildings: [Building]) async -> [RoomBusy] {
        guard let url = RuzClient.timetableURL(groupID: groupID),
              let html = try? await RuzClient.fetch(url) else { return [] }
        return RuzClient.parseHTML(html).compactMap { e -> RoomBusy? in
            guard !AddressFormat.isRemote(e.address) else { return nil }
            let loc = AddressFormat.decode(room: e.room, address: e.address, buildings: buildings)
            let room = loc.room.trimmingCharacters(in: .whitespaces)
            guard !room.isEmpty, !loc.address.isEmpty else { return nil }
            // как аудитория записана в РУЗ целиком: «ауд. 1016, А-НСД2/1016»
            var parts: [String] = []
            let rawRoom = e.room.trimmingCharacters(in: .whitespaces)
            let rawAddr = e.address.trimmingCharacters(in: .whitespaces)
            if !rawRoom.isEmpty { parts.append("ауд. \(rawRoom)") }
            if !rawAddr.isEmpty { parts.append(rawAddr) }
            let code = parts.joined(separator: ", ")
            return RoomBusy(room: room, address: loc.address, start: e.start, end: e.end, code: code)
        }
    }
}

struct FreeRoomsView: View {
    var preferredAddress: String? = nil
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var store = FreeRoomsStore.shared
    @State private var institution = 0
    @State private var address = ""
    @State private var from = Date()
    @State private var span = 95

    private let columns = [GridItem(.adaptive(minimum: 150), spacing: 10)]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header
                if !store.busy.isEmpty {
                    filters
                    results
                }
                Text("Считается по расписанию всех групп выбранной школы в РУЗ. Аудиторию могут занять другие школы, консультации или мероприятия — это подсказка, а не гарантия.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Свободные аудитории")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if institution == 0 {
                let mine = schedule.data.ruzInstitution
                institution = mine > 0 ? mine : (RuzClient.institutions.first?.0 ?? 3)
            }
            pickAddress()
            if !store.isFresh(for: institution) { Task { await rescan() } }
        }
    }

    private func rescan() async {
        await store.scan(institution: institution, buildings: schedule.data.buildings)
        pickAddress()
    }

    /// Корпуса из твоего расписания — их показываем первыми и выбираем по умолчанию
    private var myAddresses: [String] {
        var seen = Set<String>()
        return ScheduleQuery.slots(schedule.data, days: 14).compactMap { s -> String? in
            let a = s.address
            guard !a.isEmpty, !AddressFormat.isRemote(a), seen.insert(a).inserted else { return nil }
            return a
        }
    }

    /// Все корпуса школы, но твои — сверху
    private var sortedAddresses: [String] {
        let mine = Set(myAddresses.map { AddressFormat.full($0) })
        let all = store.addresses
        return all.filter { mine.contains(AddressFormat.full($0)) } + all.filter { !mine.contains(AddressFormat.full($0)) }
    }

    private func pickAddress() {
        let list = store.addresses
        guard !list.isEmpty else { return }
        if !address.isEmpty && list.contains(address) { return }
        if preferredAddress == nil || preferredAddress?.isEmpty == true {
            let mine = myAddresses.map { AddressFormat.full($0) }
            if let hit = list.first(where: { mine.contains(AddressFormat.full($0)) }) {
                address = hit
                return
            }
        }
        if let p = preferredAddress, !p.isEmpty {
            let loc = AddressFormat.decode(room: "", address: p, buildings: schedule.data.buildings).address
            if let hit = list.first(where: { $0 == p || $0 == loc || AddressFormat.full($0) == AddressFormat.full(p) }) {
                address = hit
                return
            }
        }
        address = list[0]
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Picker("Школа", selection: $institution) {
                    ForEach(RuzClient.institutions, id: \.0) { Text($0.1).tag($0.0) }
                }
                .pickerStyle(.menu)
                .onChange(of: institution) { v in
                    if store.isFresh(for: v) { pickAddress() } else { Task { await rescan() } }
                }
                Spacer()
                Button {
                    Haptics.tap()
                    Task { await rescan() }
                } label: {
                    Label("Обновить", systemImage: "arrow.clockwise")
                        .font(.caption.weight(.bold))
                }
                .disabled(store.scanning)
            }
            if store.scanning {
                ProgressView(value: Double(store.done), total: Double(max(1, store.total)))
                    .tint(Color.brand)
                Text(store.total == 0 ? "Загружаю список групп…" : "Смотрю расписания групп: \(store.done) из \(store.total)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else if let e = store.error {
                Text(e).font(.caption).foregroundStyle(.orange)
            } else if let s = store.scannedAt {
                Text("Обновлено \(Fmt.relative(s)) · аудиторий: \(Set(store.busy.map { $0.address + $0.room }).count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .glass(22)
    }

    private var filters: some View {
        VStack(alignment: .leading, spacing: 12) {
            Menu {
                ForEach(sortedAddresses, id: \.self) { a in
                    Button(AddressFormat.full(a)) { address = a }
                }
            } label: {
                HStack {
                    Image(systemName: "building.2.fill").foregroundStyle(brandGradient)
                    Text(address.isEmpty ? "Выбери корпус" : AddressFormat.full(address))
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Image(systemName: "chevron.up.chevron.down").font(.caption).foregroundStyle(.secondary)
                }
            }
            DatePicker("Когда", selection: $from)
                .font(.subheadline)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    chip("Сейчас") { from = Date() }
                    ForEach(Array(Bells.times.enumerated()), id: \.offset) { i, _ in
                        chip("\(i + 1) пара") {
                            if let iv = Bells.interval(pair: i + 1, on: from) { from = iv.0; span = 95 }
                        }
                    }
                }
            }
            Picker("На сколько", selection: $span) {
                Text("30 мин").tag(30)
                Text("Пара").tag(95)
                Text("Две пары").tag(200)
            }
            .pickerStyle(.segmented)
        }
        .padding(16)
        .glass(22)
    }

    private func chip(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            Text(title)
                .font(.caption.weight(.bold))
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .foregroundStyle(Color.brand)
                .background(Color.brand.opacity(0.14), in: Capsule())
        }
        .buttonStyle(PressableStyle())
    }

    @ViewBuilder private var results: some View {
        let to = from.addingTimeInterval(Double(span) * 60)
        let list = address.isEmpty ? [] : store.free(address: address, from: from, to: to)
        let covered = store.coveredRange.map { $0.contains(from) } ?? false
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Свободно: \(list.count)").font(.system(.headline, design: .rounded))
                Spacer()
            }
            if !covered {
                Text("На эту дату в РУЗ пока нет расписания — обычно там только эта и следующая неделя.")
                    .font(.caption)
                    .foregroundStyle(.orange)
            } else if list.isEmpty {
                Text("Всё занято. Попробуй другое время или корпус.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(list) { r in
                        VStack(alignment: .leading, spacing: 4) {
                            Text("ауд. \(r.room)")
                                .font(.system(.headline, design: .rounded).weight(.heavy))
                                .lineLimit(1)
                                .minimumScaleFactor(0.6)
                            Text(roomPlace(r))
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .lineLimit(2)
                                .fixedSize(horizontal: false, vertical: true)
                            Text(r.until.map { "свободна до \(hm($0))" } ?? "свободна до вечера")
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(r.until == nil ? Color.green : Color.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                        .glass(16)
                        .contextMenu {
                            Button {
                                UIPasteboard.general.string = "ауд. \(r.room), \(AddressFormat.full(address))"
                            } label: { Label("Скопировать", systemImage: "doc.on.doc") }
                        }
                    }
                }
            }
        }
    }

    private func hm(_ d: Date) -> String {
        Fmt.formatter("H:mm").string(from: d)
    }

    /// Корпус и код РУЗ под номером аудитории
    private func roomPlace(_ r: FreeRoom) -> String {
        let place = AddressFormat.full(address)
        if r.code.isEmpty || r.code == "ауд. \(r.room)" { return place }
        return "\(r.code) · \(place)"
    }
}
