import SwiftUI
import UIKit

// MARK: - Темы-пакеты
// Один тап — и меняется всё: цвет, фон, карточки, шрифт, светлая/тёмная, панели сверху и снизу, иконка.
// После этого любую мелочь можно докрутить в «Оформлении» как обычно.

enum ThemePack: String, CaseIterable, Identifiable {
    case none, clear, ios6, machinarium

    var id: String { rawValue }

    var title: String {
        switch self {
        case .none: return "Своя"
        case .clear: return "Ясный"
        case .ios6: return "iOS 6"
        case .machinarium: return "Machinarium"
        }
    }

    var subtitle: String {
        switch self {
        case .none: return "Всё настраиваешь сам"
        case .clear: return "Чистый и спокойный: ничего лишнего, всё читается сразу"
        case .ios6: return "Глянцевые панели, полоски и ячейки как в 2012-м"
        case .machinarium: return "Свалка в смоге: горы ржавого хлама, дирижабль, туман"
        }
    }

    /// Иконка приложения темы (nil — не менять)
    var appIcon: String? {
        switch self {
        case .none, .clear: return nil
        case .ios6: return "AppIcon-iOS6"
        case .machinarium: return "AppIcon-Machinarium"
        }
    }

    var preview: String {
        switch self {
        case .none: return "IconPreview-Classic"
        case .clear: return "IconPreview-Mono"
        case .ios6: return "IconPreview-iOS6"
        case .machinarium: return "IconPreview-Machinarium"
        }
    }

    /// Шрифт заголовков темы (nil — системный)
    var titleFont: String? {
        switch self {
        case .none, .clear: return nil
        case .ios6: return "Helvetica-Bold"
        case .machinarium: return "Noteworthy-Bold"
        }
    }

    static var current: ThemePack {
        ThemePack(rawValue: UserDefaults.standard.string(forKey: "look.pack") ?? "") ?? .none
    }

    /// Все настройки оформления разом
    func apply() {
        let d = UserDefaults.standard
        d.set(rawValue, forKey: "look.pack")
        guard self != .none else {
            ThemeChrome.apply()
            return
        }
        let set: (AccentTheme, BackdropStyle, CardStyle, AppFont, Double, Int) = {
            switch self {
            case .none, .clear: return (.blue, .soft, .clean, .standard, 0.85, 0)
            case .ios6: return (.ios6, .linen, .skeuo, .standard, 0.45, 1)
            case .machinarium: return (.rust, .workshop, .rusty, .rounded, 0.6, 1)
            }
        }()
        d.set(false, forKey: "theme.seasonal")
        d.set(set.0.rawValue, forKey: "theme")
        d.set(set.1.rawValue, forKey: "bg.style")
        d.set(set.2.rawValue, forKey: "cardStyle")
        d.set(set.3.rawValue, forKey: "ui.font")
        d.set(set.4, forKey: "ui.radius")
        d.set(set.5, forKey: "ui.scheme")
        d.set(false, forKey: "ui.gradTitle")
        d.set(1.0, forKey: "bg.intensity")
        ThemeChrome.apply()
    }
}

// MARK: - Панели сверху и снизу (UIKit)

enum ThemeChrome {
    private static func rgb(_ r: Double, _ g: Double, _ b: Double, _ a: Double = 1) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: a)
    }

    /// Вертикальный градиент-картинка для фона панели; gloss — блик на верхней половине
    private static func gradient(_ colors: [UIColor], gloss: Bool = false) -> UIImage {
        let size = CGSize(width: 4, height: 100)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            let cg = colors.map(\.cgColor) as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cg, locations: nil) {
                ctx.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])
            }
            if gloss {
                UIColor.white.withAlphaComponent(0.10).setFill()
                ctx.fill(CGRect(x: 0, y: 0, width: size.width, height: size.height / 2))
            }
        }
        return img.resizableImage(withCapInsets: .zero, resizingMode: .stretch)
    }

    private static func font(_ name: String, _ size: CGFloat) -> UIFont {
        UIFont(name: name, size: size) ?? .boldSystemFont(ofSize: size)
    }

    static func apply() {
        let pack = ThemePack.current
        let nav = UINavigationBarAppearance()
        let tab = UITabBarAppearance()
        var tint: UIColor?

        switch pack {
        case .none, .clear:
            nav.configureWithDefaultBackground()
            tab.configureWithDefaultBackground()
        case .ios6:
            nav.configureWithOpaqueBackground()
            nav.backgroundImage = gradient([rgb(0.70, 0.76, 0.84), rgb(0.53, 0.62, 0.74), rgb(0.43, 0.52, 0.64)], gloss: true)
            nav.shadowColor = rgb(0.18, 0.21, 0.26)
            let sh = NSShadow()
            sh.shadowColor = UIColor.black.withAlphaComponent(0.45)
            sh.shadowOffset = CGSize(width: 0, height: -1)
            nav.titleTextAttributes = [.foregroundColor: UIColor.white, .font: font("Helvetica-Bold", 20), .shadow: sh]
            nav.largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: font("Helvetica-Bold", 32), .shadow: sh]
            tab.configureWithOpaqueBackground()
            tab.backgroundImage = gradient([rgb(0.24, 0.24, 0.24), rgb(0.07, 0.07, 0.07), rgb(0.0, 0.0, 0.0)], gloss: true)
            tab.shadowColor = .black
            tint = .white
            styleItems(tab, normal: rgb(0.55, 0.55, 0.55), selected: rgb(0.45, 0.72, 1.0))
        case .machinarium:
            nav.configureWithOpaqueBackground()
            nav.backgroundImage = gradient([rgb(0.60, 0.60, 0.48), rgb(0.47, 0.47, 0.36)])
            nav.shadowColor = rgb(0.15, 0.14, 0.10)
            let ink = rgb(0.13, 0.12, 0.08)
            nav.titleTextAttributes = [.foregroundColor: ink, .font: font("Noteworthy-Bold", 20)]
            nav.largeTitleTextAttributes = [.foregroundColor: ink, .font: font("Noteworthy-Bold", 32)]
            tab.configureWithOpaqueBackground()
            tab.backgroundImage = gradient([rgb(0.25, 0.25, 0.19), rgb(0.13, 0.13, 0.10)])
            tab.shadowColor = rgb(0.08, 0.08, 0.06)
            tint = ink
            styleItems(tab, normal: rgb(0.60, 0.60, 0.48), selected: rgb(0.86, 0.58, 0.28))
        }

        let navProxy = UINavigationBar.appearance()
        navProxy.standardAppearance = nav
        navProxy.compactAppearance = nav
        navProxy.scrollEdgeAppearance = (pack == .none || pack == .clear) ? nil : nav
        navProxy.tintColor = tint
        let tabProxy = UITabBar.appearance()
        tabProxy.standardAppearance = tab
        tabProxy.scrollEdgeAppearance = (pack == .none || pack == .clear) ? nil : tab
    }

    private static func styleItems(_ tab: UITabBarAppearance, normal: UIColor, selected: UIColor) {
        for layout in [tab.stackedLayoutAppearance, tab.inlineLayoutAppearance, tab.compactInlineLayoutAppearance] {
            layout.normal.iconColor = normal
            layout.normal.titleTextAttributes = [.foregroundColor: normal]
            layout.selected.iconColor = selected
            layout.selected.titleTextAttributes = [.foregroundColor: selected]
        }
    }
}

// MARK: - Карточки тем

/// iOS 6: белая ячейка с серой рамкой и «вдавленной» тенью
struct SkeuoCard<C: View>: View {
    let content: C
    let shape: RoundedRectangle

    var body: some View {
        content
            .environment(\.colorScheme, .light)
            .background(LinearGradient(colors: [.white, Color(white: 0.955)], startPoint: .top, endPoint: .bottom), in: shape)
            .overlay(shape.strokeBorder(Color(red: 0.67, green: 0.70, blue: 0.74), lineWidth: 1))
            .shadow(color: .white.opacity(0.9), radius: 0, y: 1)
            .shadow(color: .black.opacity(0.10), radius: 1.5, y: 1)
    }
}

/// Цвет «чернил» Machinarium (в generic-типе нельзя хранить static)
private let rustyInk = Color(red: 0.15, green: 0.14, blue: 0.09)

/// Machinarium: старая оливковая жесть, рыжие потёки, рисованный контур и заклёпки
struct RustyCard<C: View>: View {
    let content: C
    let shape: RoundedRectangle

    private var ink: Color { rustyInk }

    private var rivet: some View {
        Circle()
            .fill(RadialGradient(colors: [Color(red: 0.85, green: 0.64, blue: 0.42), Color(red: 0.36, green: 0.22, blue: 0.12)],
                                 center: UnitPoint(x: 0.35, y: 0.3), startRadius: 0, endRadius: 4.5))
            .frame(width: 7, height: 7)
            .overlay(Circle().stroke(ink.opacity(0.7), lineWidth: 0.6))
    }

    var body: some View {
        content
            .environment(\.colorScheme, .light)
            .foregroundStyle(ink)
            .background(LinearGradient(colors: [Color(red: 0.81, green: 0.80, blue: 0.69), Color(red: 0.64, green: 0.63, blue: 0.51)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), in: shape)
            .background {
                // ржавые потёки в углу
                shape.fill(RadialGradient(colors: [Color(red: 0.62, green: 0.32, blue: 0.12).opacity(0.28), .clear],
                                          center: .bottomTrailing, startRadius: 0, endRadius: 180))
            }
            .overlay(shape.strokeBorder(ink, lineWidth: 1.6))
            .overlay(shape.strokeBorder(ink.opacity(0.3), lineWidth: 1).offset(x: 1.2, y: 1.0))   // «от руки»: второй штрих
            .overlay(alignment: .topLeading) { rivet.padding(7) }
            .overlay(alignment: .topTrailing) { rivet.padding(7) }
            .overlay(alignment: .bottomLeading) { rivet.padding(7) }
            .overlay(alignment: .bottomTrailing) { rivet.padding(7) }
            .shadow(color: Color(red: 0.25, green: 0.15, blue: 0.05).opacity(0.3), radius: 6, y: 3)
    }
}

// MARK: - Фон iOS 6: полоски как в «Настройках»

struct PinstripeLayer: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        Canvas { ctx, size in
            let dark = scheme == .dark
            let base = dark ? Color(red: 0.19, green: 0.20, blue: 0.22) : Color(red: 0.776, green: 0.804, blue: 0.835)
            let stripe = dark ? Color(red: 0.22, green: 0.23, blue: 0.25) : Color(red: 0.800, green: 0.827, blue: 0.855)
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(base))
            var x: CGFloat = 0
            var path = Path()
            while x < size.width {
                path.addRect(CGRect(x: x, y: 0, width: 4, height: size.height))
                x += 7
            }
            ctx.fill(path, with: .color(stripe))
        }
        .drawingGroup()
    }
}

// MARK: - Фон Machinarium: живая картина свалки
// Картина (MachScene) нарисована заранее; дирижабль (MachShip) — отдельный слой: плывёт и покачивается.
// Поверх — ползущий туман и пыль.

struct WorkshopLayer: View {
    let animated: Bool
    let strength: Double

    /// Размер исходной картины и место дирижабля на ней
    private static let scene = CGSize(width: 1290, height: 2796)
    private static let ship = CGRect(x: 631, y: 447, width: 642, height: 475)

    var body: some View {
        GeometryReader { geo in
            let w = Double(geo.size.width), h = Double(geo.size.height)
            let k = max(w / Double(Self.scene.width), h / Double(Self.scene.height))
            let ox = (w - Double(Self.scene.width) * k) / 2
            let oy = (h - Double(Self.scene.height) * k) / 2
            ZStack(alignment: .topLeading) {
                Image("MachScene")
                    .resizable()
                    .interpolation(.high)
                    .frame(width: Double(Self.scene.width) * k, height: Double(Self.scene.height) * k)
                    .offset(x: ox, y: oy)
                TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { ctx in
                    let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 3600) : 0
                    // дирижабль плывёт в шапке экрана — там его не закрывают карточки
                    let sw = min(w * 0.34, Double(Self.ship.width) * k * 0.7)
                    let sh = sw * Double(Self.ship.height) / Double(Self.ship.width)
                    let cx = w * 0.72 + sin(t * 0.06) * w * 0.1
                    let cy = sh * 0.36 + sin(t * 0.55) * 5
                    ZStack(alignment: .topLeading) {
                        Image("MachShip")
                            .resizable()
                            .interpolation(.high)
                            .frame(width: sw, height: sh)
                            .rotationEffect(.degrees(sin(t * 0.4) * 1.6))
                            .position(x: cx, y: cy)
                        Canvas { g, size in
                            MachAir.draw(&g, size: size, t: t, strength: strength)
                        }
                    }
                }
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .topLeading)
            .clipped()
        }
    }
}

/// Туман и пыль поверх картины
enum MachAir {
    private static func noise(_ i: Int) -> Double {
        let v = sin(Double(i) * 12.9898 + 78.233) * 43758.5453
        return v - v.rounded(.down)
    }

    static func draw(_ g: inout GraphicsContext, size: CGSize, t: Double, strength k: Double) {
        let w = Double(size.width), h = Double(size.height)
        // полосы тумана медленно ползут
        for i in 0..<4 {
            let y = h * (0.45 + Double(i) * 0.14)
            let fw = w * (1.1 + noise(i) * 0.6)
            let x = (t * (6 + noise(i + 10) * 8) + noise(i + 20) * w).truncatingRemainder(dividingBy: w + fw) - fw
            let rect = CGRect(x: x, y: y - 60, width: fw, height: 120)
            g.fill(Path(ellipseIn: rect),
                   with: .radialGradient(Gradient(colors: [Color(red: 0.66, green: 0.67, blue: 0.56).opacity(0.22 * k), .clear]),
                                         center: CGPoint(x: rect.midX, y: rect.midY), startRadius: 0, endRadius: CGFloat(fw / 2)))
        }
        // пыль и хлопья гари
        var dust = Path()
        for i in 0..<40 {
            let x = (noise(i + 100) * w + t * (3 + noise(i + 200) * 6)).truncatingRemainder(dividingBy: w)
            var y = (noise(i + 300) * h + t * (4 + noise(i + 400) * 7)).truncatingRemainder(dividingBy: h)
            y += sin(t * 0.8 + Double(i)) * 6
            let r = 0.8 + noise(i + 500) * 1.8
            dust.addEllipse(in: CGRect(x: x, y: y, width: r, height: r))
        }
        g.fill(dust, with: .color(Color(red: 0.16, green: 0.15, blue: 0.10).opacity(0.45 * k)))
    }
}

// MARK: - Выбор темы в «Оформлении»

struct ThemePacksSection: View {
    @AppStorage("look.pack") private var packRaw = ThemePack.none.rawValue
    @State private var iconDone = false

    private var pack: ThemePack { ThemePack(rawValue: packRaw) ?? .none }

    var body: some View {
        Section {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(ThemePack.allCases) { p in
                        Button {
                            Haptics.success()
                            withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) {
                                p.apply()
                                packRaw = p.rawValue
                                iconDone = false
                            }
                        } label: {
                            VStack(spacing: 6) {
                                Image(p.preview)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 70, height: 70)
                                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous)
                                        .strokeBorder(pack == p ? Color.brand : .clear, lineWidth: 3).padding(-5))
                                    .shadow(color: .black.opacity(0.25), radius: 5, y: 3)
                                Text(p.title)
                                    .font(.caption2.weight(pack == p ? .bold : .semibold))
                                    .foregroundStyle(pack == p ? Color.brand : .primary)
                                    .lineLimit(1)
                            }
                            .frame(width: 84)
                        }
                        .buttonStyle(PressableStyle())
                    }
                }
                .padding(.vertical, 8)
            }
            Text(pack.subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
            if let icon = pack.appIcon {
                Button {
                    guard UIApplication.shared.supportsAlternateIcons else { return }
                    UIApplication.shared.setAlternateIconName(icon) { error in
                        DispatchQueue.main.async {
                            if error == nil { iconDone = true; Haptics.success() }
                        }
                    }
                } label: {
                    Label(iconDone ? "Иконка темы стоит" : "Поставить иконку темы", systemImage: iconDone ? "checkmark.circle.fill" : "app.badge.fill")
                }
            }
        } header: {
            Text("Темы")
        } footer: {
            Text("Тема меняет всё сразу: цвет, фон, карточки, шрифт, панели. Потом можно докрутить любую мелочь ниже — тема останется.")
        }
    }
}
