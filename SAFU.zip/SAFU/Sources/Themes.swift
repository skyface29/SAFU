import SwiftUI
import UIKit

// MARK: - Темы-пакеты
// Один тап — и меняется всё: цвет, фон, карточки, шрифт, светлая/тёмная, панели сверху и снизу, иконка.
// После этого любую мелочь можно докрутить в «Оформлении» как обычно.

enum ThemePack: String, CaseIterable, Identifiable {
    case none, clear, ios6, bond, machinarium

    var id: String { rawValue }

    var title: String {
        switch self {
        case .none: return "Своя"
        case .clear: return "Ясный"
        case .ios6: return "iOS 6"
        case .bond: return "Агент 007"
        case .machinarium: return "Machinarium"
        }
    }

    var subtitle: String {
        switch self {
        case .none: return "Всё настраиваешь сам"
        case .clear: return "Чистый и спокойный: ничего лишнего, всё читается сразу"
        case .ios6: return "Глянцевые панели, полоски и ячейки как в 2012-м"
        case .bond: return "Чёрный смокинг, золото и ствол, который смотрит на тебя"
        case .machinarium: return "Ржавая мастерская: шестерёнки, трубы и маленький робот"
        }
    }

    /// Иконка приложения темы (nil — не менять)
    var appIcon: String? {
        switch self {
        case .none, .clear: return nil
        case .ios6: return "AppIcon-iOS6"
        case .bond: return "AppIcon-Bond"
        case .machinarium: return "AppIcon-Machinarium"
        }
    }

    var preview: String {
        switch self {
        case .none: return "IconPreview-Classic"
        case .clear: return "IconPreview-Mono"
        case .ios6: return "IconPreview-iOS6"
        case .bond: return "IconPreview-Bond"
        case .machinarium: return "IconPreview-Machinarium"
        }
    }

    /// Шрифт заголовков темы (nil — системный)
    var titleFont: String? {
        switch self {
        case .none, .clear: return nil
        case .ios6: return "Helvetica-Bold"
        case .bond: return "Didot-Bold"
        case .machinarium: return "Noteworthy-Bold"
        }
    }

    static var current: ThemePack {
        ThemePack(rawValue: UserDefaults.standard.string(forKey: "look.pack") ?? "") ?? .none
    }

    /// Все настройки оформления разом
    func apply() {
        let d = UserDefaults.standard
        d.set(rawValue, forKey: "look.pack")
        guard self != .none else {
            ThemeChrome.apply()
            return
        }
        let set: (AccentTheme, BackdropStyle, CardStyle, AppFont, Double, Int) = {
            switch self {
            case .none, .clear: return (.blue, .soft, .clean, .standard, 0.85, 0)
            case .ios6: return (.ios6, .linen, .skeuo, .standard, 0.45, 1)
            case .bond: return (.bond, .barrel, .tuxedo, .serif, 0.5, 2)
            case .machinarium: return (.rust, .workshop, .rusty, .rounded, 0.6, 1)
            }
        }()
        d.set(false, forKey: "theme.seasonal")
        d.set(set.0.rawValue, forKey: "theme")
        d.set(set.1.rawValue, forKey: "bg.style")
        d.set(set.2.rawValue, forKey: "cardStyle")
        d.set(set.3.rawValue, forKey: "ui.font")
        d.set(set.4, forKey: "ui.radius")
        d.set(set.5, forKey: "ui.scheme")
        d.set(false, forKey: "ui.gradTitle")
        d.set(1.0, forKey: "bg.intensity")
        ThemeChrome.apply()
    }
}

// MARK: - Панели сверху и снизу (UIKit)

enum ThemeChrome {
    private static func rgb(_ r: Double, _ g: Double, _ b: Double, _ a: Double = 1) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: a)
    }

    /// Вертикальный градиент-картинка для фона панели; gloss — блик на верхней половине
    private static func gradient(_ colors: [UIColor], gloss: Bool = false) -> UIImage {
        let size = CGSize(width: 4, height: 100)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            let cg = colors.map(\.cgColor) as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: cg, locations: nil) {
                ctx.cgContext.drawLinearGradient(g, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])
            }
            if gloss {
                UIColor.white.withAlphaComponent(0.10).setFill()
                ctx.fill(CGRect(x: 0, y: 0, width: size.width, height: size.height / 2))
            }
        }
        return img.resizableImage(withCapInsets: .zero, resizingMode: .stretch)
    }

    private static func font(_ name: String, _ size: CGFloat) -> UIFont {
        UIFont(name: name, size: size) ?? .boldSystemFont(ofSize: size)
    }

    static func apply() {
        let pack = ThemePack.current
        let nav = UINavigationBarAppearance()
        let tab = UITabBarAppearance()
        var tint: UIColor?

        switch pack {
        case .none, .clear:
            nav.configureWithDefaultBackground()
            tab.configureWithDefaultBackground()
        case .ios6:
            nav.configureWithOpaqueBackground()
            nav.backgroundImage = gradient([rgb(0.70, 0.76, 0.84), rgb(0.53, 0.62, 0.74), rgb(0.43, 0.52, 0.64)], gloss: true)
            nav.shadowColor = rgb(0.18, 0.21, 0.26)
            let sh = NSShadow()
            sh.shadowColor = UIColor.black.withAlphaComponent(0.45)
            sh.shadowOffset = CGSize(width: 0, height: -1)
            nav.titleTextAttributes = [.foregroundColor: UIColor.white, .font: font("Helvetica-Bold", 20), .shadow: sh]
            nav.largeTitleTextAttributes = [.foregroundColor: UIColor.white, .font: font("Helvetica-Bold", 32), .shadow: sh]
            tab.configureWithOpaqueBackground()
            tab.backgroundImage = gradient([rgb(0.24, 0.24, 0.24), rgb(0.07, 0.07, 0.07), rgb(0.0, 0.0, 0.0)], gloss: true)
            tab.shadowColor = .black
            tint = .white
            styleItems(tab, normal: rgb(0.55, 0.55, 0.55), selected: rgb(0.45, 0.72, 1.0))
        case .bond:
            nav.configureWithOpaqueBackground()
            nav.backgroundColor = .black
            nav.shadowColor = rgb(0.83, 0.67, 0.33, 0.35)
            let gold = rgb(0.86, 0.72, 0.40)
            nav.titleTextAttributes = [.foregroundColor: gold, .font: font("Didot-Bold", 19), .kern: 2.5]
            nav.largeTitleTextAttributes = [.foregroundColor: gold, .font: font("Didot-Bold", 32), .kern: 1.5]
            tab.configureWithOpaqueBackground()
            tab.backgroundColor = .black
            tab.shadowColor = rgb(0.83, 0.67, 0.33, 0.35)
            tint = gold
            styleItems(tab, normal: rgb(0.45, 0.45, 0.45), selected: gold)
        case .machinarium:
            nav.configureWithOpaqueBackground()
            nav.backgroundImage = gradient([rgb(0.83, 0.74, 0.56), rgb(0.74, 0.63, 0.45)])
            nav.shadowColor = rgb(0.29, 0.20, 0.12)
            let ink = rgb(0.25, 0.16, 0.09)
            nav.titleTextAttributes = [.foregroundColor: ink, .font: font("Noteworthy-Bold", 20)]
            nav.largeTitleTextAttributes = [.foregroundColor: ink, .font: font("Noteworthy-Bold", 32)]
            tab.configureWithOpaqueBackground()
            tab.backgroundImage = gradient([rgb(0.30, 0.21, 0.13), rgb(0.19, 0.13, 0.08)])
            tab.shadowColor = rgb(0.12, 0.08, 0.05)
            tint = ink
            styleItems(tab, normal: rgb(0.62, 0.52, 0.38), selected: rgb(0.95, 0.66, 0.30))
        }

        let navProxy = UINavigationBar.appearance()
        navProxy.standardAppearance = nav
        navProxy.compactAppearance = nav
        navProxy.scrollEdgeAppearance = (pack == .none || pack == .clear) ? nil : nav
        navProxy.tintColor = tint
        let tabProxy = UITabBar.appearance()
        tabProxy.standardAppearance = tab
        tabProxy.scrollEdgeAppearance = (pack == .none || pack == .clear) ? nil : tab
    }

    private static func styleItems(_ tab: UITabBarAppearance, normal: UIColor, selected: UIColor) {
        for layout in [tab.stackedLayoutAppearance, tab.inlineLayoutAppearance, tab.compactInlineLayoutAppearance] {
            layout.normal.iconColor = normal
            layout.normal.titleTextAttributes = [.foregroundColor: normal]
            layout.selected.iconColor = selected
            layout.selected.titleTextAttributes = [.foregroundColor: selected]
        }
    }
}

// MARK: - Карточки тем

/// iOS 6: белая ячейка с серой рамкой и «вдавленной» тенью
struct SkeuoCard<C: View>: View {
    let content: C
    let shape: RoundedRectangle

    var body: some View {
        content
            .environment(\.colorScheme, .light)
            .background(LinearGradient(colors: [.white, Color(white: 0.955)], startPoint: .top, endPoint: .bottom), in: shape)
            .overlay(shape.strokeBorder(Color(red: 0.67, green: 0.70, blue: 0.74), lineWidth: 1))
            .shadow(color: .white.opacity(0.9), radius: 0, y: 1)
            .shadow(color: .black.opacity(0.10), radius: 1.5, y: 1)
    }
}

/// Агент 007: чёрный атлас, золотая кайма
struct TuxedoCard<C: View>: View {
    let content: C
    let shape: RoundedRectangle

    var body: some View {
        content
            .environment(\.colorScheme, .dark)
            .background(LinearGradient(colors: [Color(white: 0.13), Color(white: 0.035)], startPoint: .top, endPoint: .bottom), in: shape)
            .overlay(shape.strokeBorder(LinearGradient(colors: [AccentTheme.bond.color.opacity(0.95), AccentTheme.bond.color.opacity(0.25),
                                                                AccentTheme.bond.color.opacity(0.7)],
                                                       startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.9))
            .overlay(alignment: .top) {
                // атласный блик сверху
                shape.fill(LinearGradient(colors: [.white.opacity(0.07), .clear], startPoint: .top, endPoint: .center))
                    .allowsHitTesting(false)
            }
            .shadow(color: .black.opacity(0.6), radius: 12, y: 6)
    }
}

/// Machinarium: пластина старой бумаги-жести, рыжие потёки, рисованный контур и заклёпки
struct RustyCard<C: View>: View {
    let content: C
    let shape: RoundedRectangle

    private static let ink = Color(red: 0.27, green: 0.18, blue: 0.10)

    private var rivet: some View {
        Circle()
            .fill(RadialGradient(colors: [Color(red: 0.85, green: 0.64, blue: 0.42), Color(red: 0.36, green: 0.22, blue: 0.12)],
                                 center: UnitPoint(x: 0.35, y: 0.3), startRadius: 0, endRadius: 4.5))
            .frame(width: 7, height: 7)
            .overlay(Circle().stroke(Self.ink.opacity(0.7), lineWidth: 0.6))
    }

    var body: some View {
        content
            .environment(\.colorScheme, .light)
            .foregroundStyle(Self.ink)
            .background(LinearGradient(colors: [Color(red: 0.94, green: 0.87, blue: 0.71), Color(red: 0.85, green: 0.74, blue: 0.56)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing), in: shape)
            .background {
                // ржавые потёки в углу
                shape.fill(RadialGradient(colors: [Color(red: 0.62, green: 0.32, blue: 0.12).opacity(0.28), .clear],
                                          center: .bottomTrailing, startRadius: 0, endRadius: 180))
            }
            .overlay(shape.strokeBorder(Self.ink, lineWidth: 1.6))
            .overlay(shape.strokeBorder(Self.ink.opacity(0.3), lineWidth: 1).offset(x: 1.2, y: 1.0))   // «от руки»: второй штрих
            .overlay(alignment: .topLeading) { rivet.padding(7) }
            .overlay(alignment: .topTrailing) { rivet.padding(7) }
            .overlay(alignment: .bottomLeading) { rivet.padding(7) }
            .overlay(alignment: .bottomTrailing) { rivet.padding(7) }
            .shadow(color: Color(red: 0.25, green: 0.15, blue: 0.05).opacity(0.3), radius: 6, y: 3)
    }
}

// MARK: - Фон iOS 6: полоски как в «Настройках»

struct PinstripeLayer: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        Canvas { ctx, size in
            let dark = scheme == .dark
            let base = dark ? Color(red: 0.19, green: 0.20, blue: 0.22) : Color(red: 0.776, green: 0.804, blue: 0.835)
            let stripe = dark ? Color(red: 0.22, green: 0.23, blue: 0.25) : Color(red: 0.800, green: 0.827, blue: 0.855)
            ctx.fill(Path(CGRect(origin: .zero, size: size)), with: .color(base))
            var x: CGFloat = 0
            var path = Path()
            while x < size.width {
                path.addRect(CGRect(x: x, y: 0, width: 4, height: size.height))
                x += 7
            }
            ctx.fill(path, with: .color(stripe))
        }
        .drawingGroup()
    }
}

// MARK: - Фон «Агент 007»: ствол с нарезами

struct GunBarrelLayer: View {
    let animated: Bool
    let strength: Double

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { ctx in
            let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 3600) : 0
            Canvas { g, size in
                draw(&g, size: size, t: t)
            }
        }
    }

    private func draw(_ g: inout GraphicsContext, size: CGSize, t: Double) {
        let w = Double(size.width), h = Double(size.height)
        g.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.black))
        let cx = w / 2, cy = h * 0.34
        let c = CGPoint(x: cx, y: cy)
        let R = w * 0.78
        let rot = t * (2 * .pi / 90)   // оборот за полторы минуты

        // тело ствола
        g.fill(Path(ellipseIn: CGRect(x: cx - R, y: cy - R, width: R * 2, height: R * 2)),
               with: .radialGradient(Gradient(colors: [Color(white: 0.22), Color(white: 0.10), Color(white: 0.03)]),
                                     center: c, startRadius: 0, endRadius: CGFloat(R)))

        // нарезы: широкие спиральные «поля» от центра к краю
        let grooves = 8
        let steps = 36
        let span = 2 * Double.pi / Double(grooves) * 0.5
        for k in 0..<grooves {
            let base = Double(k) / Double(grooves) * 2 * .pi + rot
            var outer: [CGPoint] = []
            var inner: [CGPoint] = []
            for i in 0...steps {
                let f = Double(i) / Double(steps)
                let r = R * (0.16 + 0.84 * f)
                let a = base + f * 1.7
                outer.append(CGPoint(x: cx + cos(a) * r, y: cy + sin(a) * r))
                inner.append(CGPoint(x: cx + cos(a + span) * r, y: cy + sin(a + span) * r))
            }
            var band = Path()
            band.addLines(outer + inner.reversed())
            band.closeSubpath()
            g.fill(band, with: .radialGradient(Gradient(colors: [Color(white: 0.55).opacity(strength), Color(white: 0.14).opacity(strength)]),
                                               center: c, startRadius: 0, endRadius: CGFloat(R)))
            var edge = Path()
            edge.addLines(inner)
            g.stroke(edge, with: .color(.black.opacity(0.8)), lineWidth: 3)
        }
        // глубина: к краю темнее
        g.fill(Path(ellipseIn: CGRect(x: cx - R, y: cy - R, width: R * 2, height: R * 2)),
               with: .radialGradient(Gradient(colors: [.clear, .black.opacity(0.15), .black.opacity(0.75)]),
                                     center: c, startRadius: 0, endRadius: CGFloat(R)))

        // кольца глубины
        for i in 1...5 {
            let r = R * (0.16 + Double(i) * 0.15)
            g.stroke(Path(ellipseIn: CGRect(x: cx - r, y: cy - r, width: r * 2, height: r * 2)),
                     with: .color(.white.opacity(0.025 * strength)), lineWidth: 1)
        }

        // свет в конце ствола
        let hole = R * 0.16
        g.fill(Path(ellipseIn: CGRect(x: cx - hole * 2.2, y: cy - hole * 2.2, width: hole * 4.4, height: hole * 4.4)),
               with: .radialGradient(Gradient(colors: [.white.opacity(0.22 * strength), .clear]), center: c, startRadius: 0,
                                     endRadius: CGFloat(hole * 2.2)))
        g.fill(Path(ellipseIn: CGRect(x: cx - hole, y: cy - hole, width: hole * 2, height: hole * 2)),
               with: .radialGradient(Gradient(colors: [Color(white: 0.95), Color(white: 0.75)]), center: c, startRadius: 0,
                                     endRadius: CGFloat(hole)))

        // бегущая «точка прицела», как в заставке — раз в 20 секунд
        let cycle = t.truncatingRemainder(dividingBy: 20)
        if cycle < 3 {
            let x = -40 + (w + 80) * cycle / 3
            let dot = CGRect(x: x - 18, y: h * 0.86 - 18, width: 36, height: 36)
            g.fill(Path(ellipseIn: dot), with: .color(.white.opacity(0.8)))
        }

        // кровавый отсвет снизу и виньетка
        g.fill(Path(CGRect(origin: .zero, size: size)),
               with: .linearGradient(Gradient(colors: [.clear, Color(red: 0.35, green: 0.02, blue: 0.03).opacity(0.25 * strength)]),
                                     startPoint: CGPoint(x: 0, y: h * 0.6), endPoint: CGPoint(x: 0, y: h)))
        g.fill(Path(CGRect(origin: .zero, size: size)),
               with: .radialGradient(Gradient(colors: [.clear, .black.opacity(0.7)]), center: CGPoint(x: w / 2, y: h * 0.4),
                                     startRadius: CGFloat(w * 0.4), endRadius: CGFloat(max(w, h) * 0.8)))
    }
}

// MARK: - Фон Machinarium: мастерская

struct WorkshopLayer: View {
    let animated: Bool
    let strength: Double
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24, paused: !animated)) { ctx in
            let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 3600) : 0
            Canvas { g, size in
                Workshop.draw(&g, size: size, t: t, strength: strength, dark: scheme == .dark)
            }
        }
    }
}

enum Workshop {
    static let ink = Color(red: 0.25, green: 0.16, blue: 0.09)

    private static func noise(_ i: Int) -> Double {
        let v = sin(Double(i) * 12.9898 + 78.233) * 43758.5453
        return v - v.rounded(.down)
    }

    static func draw(_ g: inout GraphicsContext, size: CGSize, t: Double, strength k: Double, dark: Bool) {
        let w = Double(size.width), h = Double(size.height)

        // бумага сепии
        let top = dark ? Color(red: 0.22, green: 0.18, blue: 0.13) : Color(red: 0.89, green: 0.82, blue: 0.66)
        let bottom = dark ? Color(red: 0.12, green: 0.09, blue: 0.06) : Color(red: 0.76, green: 0.66, blue: 0.48)
        g.fill(Path(CGRect(origin: .zero, size: size)),
               with: .linearGradient(Gradient(colors: [top, bottom]), startPoint: .zero, endPoint: CGPoint(x: w * 0.3, y: h)))

        // пятна и зерно
        for i in 0..<7 {
            let x = noise(i) * w, y = noise(i + 40) * h, r = 60 + noise(i + 80) * 140
            g.fill(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)),
                   with: .radialGradient(Gradient(colors: [Color(red: 0.45, green: 0.28, blue: 0.12).opacity(0.10 * k), .clear]),
                                         center: CGPoint(x: x, y: y), startRadius: 0, endRadius: CGFloat(r)))
        }
        var specks = Path()
        for i in 0..<260 {
            let x = noise(i + 200) * w, y = noise(i + 900) * h, r = 0.4 + noise(i + 1500) * 1.1
            specks.addEllipse(in: CGRect(x: x, y: y, width: r, height: r))
        }
        g.fill(specks, with: .color(ink.opacity(0.18 * k)))

        // трубы
        pipe(&g, from: CGPoint(x: -10, y: h * 0.055), to: CGPoint(x: w + 10, y: h * 0.055), k: k)
        pipe(&g, from: CGPoint(x: w * 0.06, y: h * 0.055), to: CGPoint(x: w * 0.06, y: h * 0.42), k: k)

        // шестерёнки (сцеплены: малая крутится в обратную сторону)
        let bigR = w * 0.34
        let bx = w * 0.98, by = h * 0.80
        let smallR = w * 0.16
        let dist = (bigR + smallR) * 0.93
        let big = CGPoint(x: bx, y: by)
        let small = CGPoint(x: bx - 0.86 * dist, y: by - 0.51 * dist)
        let a = t * 0.12
        gear(&g, center: big, radius: bigR, teeth: 16, angle: a, k: k)
        gear(&g, center: small, radius: smallR, teeth: 8, angle: -a * 2 + 0.2, k: k)
        gear(&g, center: CGPoint(x: w * 0.02, y: h * 0.62), radius: w * 0.2, teeth: 10, angle: -a * 0.8, k: k)

        // маленький робот сидит на трубе и моргает
        robot(&g, at: CGPoint(x: w * 0.72, y: h * 0.055 - 4), t: t, k: k)

        // пыль в воздухе
        for i in 0..<18 {
            let x = (noise(i + 3000) * w + t * (4 + noise(i) * 6)).truncatingRemainder(dividingBy: w)
            let y = (noise(i + 4000) * h - t * (3 + noise(i + 7) * 4)).truncatingRemainder(dividingBy: h)
            let yy = y < 0 ? y + h : y
            g.fill(Path(ellipseIn: CGRect(x: x, y: yy, width: 2.2, height: 2.2)), with: .color(ink.opacity(0.18 * k)))
        }

        // виньетка
        g.fill(Path(CGRect(origin: .zero, size: size)),
               with: .radialGradient(Gradient(colors: [.clear, Color(red: 0.30, green: 0.18, blue: 0.08).opacity(0.35 * k)]),
                                     center: CGPoint(x: w / 2, y: h * 0.45), startRadius: CGFloat(w * 0.45),
                                     endRadius: CGFloat(max(w, h) * 0.8)))
    }

    /// Контур «от руки»: основной штрих и чуть сдвинутый второй
    private static func sketch(_ g: inout GraphicsContext, _ p: Path, width: CGFloat, k: Double) {
        g.stroke(p, with: .color(ink.opacity(0.75 * k)), style: StrokeStyle(lineWidth: width, lineCap: .round, lineJoin: .round))
        var c = g
        c.translateBy(x: 0.9, y: 0.7)
        c.stroke(p, with: .color(ink.opacity(0.25 * k)), style: StrokeStyle(lineWidth: width * 0.6, lineCap: .round, lineJoin: .round))
    }

    private static func pipe(_ g: inout GraphicsContext, from a: CGPoint, to b: CGPoint, k: Double) {
        let horizontal = abs(a.y - b.y) < 1
        let th: CGFloat = 16
        let rect = horizontal
            ? CGRect(x: min(a.x, b.x), y: a.y - th / 2, width: abs(b.x - a.x), height: th)
            : CGRect(x: a.x - th / 2, y: min(a.y, b.y), width: th, height: abs(b.y - a.y))
        let metal = Gradient(colors: [Color(red: 0.55, green: 0.62, blue: 0.52), Color(red: 0.36, green: 0.44, blue: 0.38),
                                      Color(red: 0.24, green: 0.30, blue: 0.26)])
        g.fill(Path(rect), with: .linearGradient(metal,
                                                 startPoint: horizontal ? CGPoint(x: 0, y: rect.minY) : CGPoint(x: rect.minX, y: 0),
                                                 endPoint: horizontal ? CGPoint(x: 0, y: rect.maxY) : CGPoint(x: rect.maxX, y: 0)))
        // ржавые пятна по трубе
        let len = horizontal ? rect.width : rect.height
        var i = 0
        var pos: CGFloat = 30
        while pos < len {
            let s = CGFloat(8 + noise(i + 500) * 18)
            let center = horizontal ? CGPoint(x: rect.minX + pos, y: rect.midY) : CGPoint(x: rect.midX, y: rect.minY + pos)
            g.fill(Path(ellipseIn: CGRect(x: center.x - s / 2, y: center.y - s / 3, width: s, height: s * 0.66)),
                   with: .color(Color(red: 0.62, green: 0.33, blue: 0.12).opacity(0.45 * k)))
            pos += CGFloat(60 + noise(i + 900) * 90)
            i += 1
        }
        sketch(&g, Path(rect), width: 1.4, k: k)
        // фланцы с заклёпками
        var f: CGFloat = 70
        while f < len {
            let fr = horizontal ? CGRect(x: rect.minX + f - 5, y: rect.minY - 4, width: 10, height: th + 8)
                                : CGRect(x: rect.minX - 4, y: rect.minY + f - 5, width: th + 8, height: 10)
            g.fill(Path(roundedRect: fr, cornerRadius: 2), with: .color(Color(red: 0.42, green: 0.36, blue: 0.28)))
            sketch(&g, Path(roundedRect: fr, cornerRadius: 2), width: 1.1, k: k)
            f += 150
        }
    }

    private static func gear(_ g: inout GraphicsContext, center c: CGPoint, radius R: Double, teeth: Int, angle: Double, k: Double) {
        let cx = Double(c.x), cy = Double(c.y)
        var p = Path()
        let inner = R * 0.84
        let n = teeth * 4
        for i in 0...n {
            let a = angle + Double(i) / Double(n) * 2 * .pi
            let phase = i % 4
            let r = (phase == 1 || phase == 2) ? R : inner
            let pt = CGPoint(x: cx + cos(a) * r, y: cy + sin(a) * r)
            if i == 0 { p.move(to: pt) } else { p.addLine(to: pt) }
        }
        p.closeSubpath()
        // дырки-спицы
        for i in 0..<5 {
            let a = angle + Double(i) / 5 * 2 * .pi
            let hr = R * 0.17
            let hx = cx + cos(a) * R * 0.5, hy = cy + sin(a) * R * 0.5
            p.addEllipse(in: CGRect(x: hx - hr, y: hy - hr, width: hr * 2, height: hr * 2))
        }
        let hub = R * 0.12
        p.addEllipse(in: CGRect(x: cx - hub, y: cy - hub, width: hub * 2, height: hub * 2))
        g.fill(p, with: .radialGradient(Gradient(colors: [Color(red: 0.70, green: 0.45, blue: 0.24).opacity(0.55 * k),
                                                          Color(red: 0.42, green: 0.24, blue: 0.11).opacity(0.55 * k)]),
                                        center: CGPoint(x: cx - R * 0.3, y: cy - R * 0.3), startRadius: 0, endRadius: CGFloat(R * 1.3)),
               style: FillStyle(eoFill: true))
        sketch(&g, p, width: 1.6, k: k)
    }

    /// Маленький робот: бочка-голова, большие глаза, антенна с огоньком. Моргает и смотрит по сторонам.
    private static func robot(_ g: inout GraphicsContext, at base: CGPoint, t: Double, k: Double) {
        let s: CGFloat = 1.0
        var c = g
        c.translateBy(x: base.x, y: base.y)
        c.scaleBy(x: s, y: s)
        let body = CGRect(x: -16, y: -40, width: 32, height: 30)
        let head = CGRect(x: -14, y: -70, width: 28, height: 30)
        let rust = Gradient(colors: [Color(red: 0.82, green: 0.52, blue: 0.26), Color(red: 0.50, green: 0.27, blue: 0.12)])
        // ножки свисают с трубы и болтаются
        let swing = sin(t * 2.2) * 4
        var legs = Path()
        legs.move(to: CGPoint(x: -8, y: -10)); legs.addLine(to: CGPoint(x: -9 + swing, y: 14))
        legs.move(to: CGPoint(x: 8, y: -10)); legs.addLine(to: CGPoint(x: 9 - swing, y: 14))
        c.stroke(legs, with: .color(ink.opacity(0.85 * k)), style: StrokeStyle(lineWidth: 3, lineCap: .round))
        c.fill(Path(roundedRect: body, cornerRadius: 6), with: .linearGradient(rust, startPoint: CGPoint(x: -16, y: -40), endPoint: CGPoint(x: 16, y: -10)))
        sketch(&c, Path(roundedRect: body, cornerRadius: 6), width: 1.4, k: k)
        c.fill(Path(roundedRect: head, cornerRadius: 9), with: .linearGradient(rust, startPoint: CGPoint(x: -14, y: -70), endPoint: CGPoint(x: 14, y: -40)))
        sketch(&c, Path(roundedRect: head, cornerRadius: 9), width: 1.4, k: k)
        // заклёпки
        for x in [-10.0, 10.0] {
            c.fill(Path(ellipseIn: CGRect(x: x - 1.5, y: -36, width: 3, height: 3)), with: .color(ink.opacity(0.8 * k)))
        }
        // антенна с огоньком
        var ant = Path()
        ant.move(to: CGPoint(x: 0, y: -70)); ant.addLine(to: CGPoint(x: 2, y: -84))
        c.stroke(ant, with: .color(ink.opacity(0.85 * k)), lineWidth: 1.6)
        let glow = 0.5 + 0.5 * sin(t * 3)
        c.fill(Path(ellipseIn: CGRect(x: -2, y: -90, width: 8, height: 8)),
               with: .color(Color(red: 1.0, green: 0.75, blue: 0.3).opacity((0.5 + 0.5 * glow) * k)))
        // глаза: моргают раз в 4 с, зрачки ходят
        let blink = t.truncatingRemainder(dividingBy: 4) < 0.15
        let look = sin(t * 0.7) * 2.5
        for x in [-6.5, 6.5] {
            let eye = CGRect(x: x - 5.5, y: -63, width: 11, height: blink ? 2 : 11)
            c.fill(Path(ellipseIn: eye), with: .color(Color(red: 0.98, green: 0.96, blue: 0.88).opacity(k)))
            sketch(&c, Path(ellipseIn: eye), width: 1.2, k: k)
            if !blink {
                c.fill(Path(ellipseIn: CGRect(x: x - 2 + look, y: -59.5, width: 4, height: 4)), with: .color(ink.opacity(k)))
            }
        }
    }
}

// MARK: - Выбор темы в «Оформлении»

struct ThemePacksSection: View {
    @AppStorage("look.pack") private var packRaw = ThemePack.none.rawValue
    @State private var iconDone = false

    private var pack: ThemePack { ThemePack(rawValue: packRaw) ?? .none }

    var body: some View {
        Section {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(ThemePack.allCases) { p in
                        Button {
                            Haptics.success()
                            withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) {
                                p.apply()
                                packRaw = p.rawValue
                                iconDone = false
                            }
                        } label: {
                            VStack(spacing: 6) {
                                Image(p.preview)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 70, height: 70)
                                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous)
                                        .strokeBorder(pack == p ? Color.brand : .clear, lineWidth: 3).padding(-5))
                                    .shadow(color: .black.opacity(0.25), radius: 5, y: 3)
                                Text(p.title)
                                    .font(.caption2.weight(pack == p ? .bold : .semibold))
                                    .foregroundStyle(pack == p ? Color.brand : .primary)
                                    .lineLimit(1)
                            }
                            .frame(width: 84)
                        }
                        .buttonStyle(PressableStyle())
                    }
                }
                .padding(.vertical, 8)
            }
            Text(pack.subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
            if let icon = pack.appIcon {
                Button {
                    guard UIApplication.shared.supportsAlternateIcons else { return }
                    UIApplication.shared.setAlternateIconName(icon) { error in
                        DispatchQueue.main.async {
                            if error == nil { iconDone = true; Haptics.success() }
                        }
                    }
                } label: {
                    Label(iconDone ? "Иконка темы стоит" : "Поставить иконку темы", systemImage: iconDone ? "checkmark.circle.fill" : "app.badge.fill")
                }
            }
        } header: {
            Text("Темы")
        } footer: {
            Text("Тема меняет всё сразу: цвет, фон, карточки, шрифт, панели. Потом можно докрутить любую мелочь ниже — тема останется.")
        }
    }
}
