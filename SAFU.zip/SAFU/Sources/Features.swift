import SwiftUI
import UIKit
import ActivityKit
import UserNotifications
import AppIntents

// MARK: - Настройки функций (всё можно включать и выключать)

enum FeatureFlags {
    private static var d: UserDefaults { .standard }
    private static func bool(_ k: String, _ def: Bool) -> Bool { d.object(forKey: k) as? Bool ?? def }
    private static func int(_ k: String, _ def: Int) -> Int { d.object(forKey: k) as? Int ?? def }

    // утренняя сводка
    static var briefOn: Bool { bool("brief.on", true) }
    static var briefMode: Int { int("brief.mode", 1) }          // 0 — фиксированное время, 1 — перед выходом из дома
    static var briefMinutes: Int { int("brief.time", 6 * 60 + 30) }
    static var briefLead: Int { int("brief.lead", 15) }
    static var briefPairs: Bool { bool("brief.pairs", true) }
    static var briefBus: Bool { bool("brief.bus", true) }
    static var briefTasks: Bool { bool("brief.tasks", true) }

    // Live Activity автобуса
    static var busLiveOn: Bool { bool("busLive.on", true) }
    static var busLiveAuto: Bool { bool("busLive.auto", true) }
    static var busLiveWindow: Int { int("busLive.window", 60) }

    // маршруты
    static var mapsProvider: Int { int("maps.provider", 0) }   // 0 — Яндекс, 1 — Apple
    static var mapsRoute: Bool { bool("maps.route", true) }
    static var mapsMode: Int { int("maps.mode", 0) }           // 0 — общественный транспорт, 1 — пешком

    // инструменты
    static func toolOn(_ t: Tool) -> Bool { bool("tool.\(t.rawValue)", true) }
}

// MARK: - Утренняя сводка

enum MorningBrief {
    static func schedule(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { reqs in
            center.removePendingNotificationRequests(withIdentifiers: reqs.map(\.identifier).filter { $0.hasPrefix("brief-") })
            guard FeatureFlags.briefOn else { return }
            let cal = Calendar.current
            let now = Date()
            for offset in 0..<7 {
                guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: now)) else { continue }
                let slots = ScheduleEngine.slots(on: day, data: data)
                guard let first = slots.first else { continue }
                guard let fire = fireDate(day: day, data: data), fire > now, fire < first.start else { continue }
                let c = content(day: day, slots: slots, data: data)
                let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                center.add(UNNotificationRequest(identifier: "brief-\(offset)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            }
        }
    }

    static func fireDate(day: Date, data: ScheduleData) -> Date? {
        let cal = Calendar.current
        if FeatureFlags.briefMode == 1, let f = CommutePlanner.firstPair(on: day, data: data),
           let trip = CommutePlanner.morning(for: f) {
            let leave = trip.departure.addingTimeInterval(-Double(CommuteSettings.homeMinutes) * 60)
            return leave.addingTimeInterval(-Double(FeatureFlags.briefLead) * 60)
        }
        let m = FeatureFlags.briefMinutes
        return cal.date(bySettingHour: m / 60, minute: m % 60, second: 0, of: day)
    }

    static func content(day: Date, slots: [LessonSlot], data: ScheduleData) -> UNMutableNotificationContent {
        var lines: [String] = []
        if FeatureFlags.briefPairs {
            let first = slots.first!
            let place = first.lesson.room.isEmpty ? "" : ", ауд. \(first.lesson.room)"
            lines.append("Пар: \(slots.count). Первая в \(hmString(first.start)) — \(first.lesson.subject)\(place)")
        }
        if FeatureFlags.briefBus, CommuteSettings.enabled,
           let f = CommutePlanner.firstPair(on: day, data: data), let trip = CommutePlanner.morning(for: f) {
            let leave = trip.departure.addingTimeInterval(-Double(CommuteSettings.homeMinutes) * 60)
            lines.append("🚌 Автобус \(BusRoutes.active.number) в \(hmString(trip.departure)), выйти в \(hmString(leave))")
        }
        if FeatureFlags.briefTasks,
           let raw = UserDefaults.standard.data(forKey: "tasks.v1"),
           let tasks = try? JSONDecoder().decode([StudyTask].self, from: raw) {
            let soon = tasks.filter { !$0.done && $0.due >= day && $0.due < day.addingTimeInterval(2 * 86_400) }
            if let t = soon.first {
                lines.append("⏰ Дедлайн: \(t.title)" + (soon.count > 1 ? " и ещё \(soon.count - 1)" : ""))
            }
        }
        let c = UNMutableNotificationContent()
        c.title = "Доброе утро ☀️"
        c.body = lines.isEmpty ? "Сегодня есть пары" : lines.joined(separator: "\n")
        c.sound = .default
        return c
    }

    /// Пример прямо сейчас (через 5 секунд)
    static func test(data: ScheduleData) {
        let cal = Calendar.current
        var day = cal.startOfDay(for: Date())
        for i in 0..<8 {
            if let d = cal.date(byAdding: .day, value: i, to: day), !ScheduleEngine.slots(on: d, data: data).isEmpty { day = d; break }
        }
        let slots = ScheduleEngine.slots(on: day, data: data)
        let c: UNMutableNotificationContent
        if slots.isEmpty {
            c = UNMutableNotificationContent()
            c.title = "Доброе утро ☀️"
            c.body = "На неделе пар не найдено"
        } else {
            c = content(day: day, slots: slots, data: data)
        }
        UNUserNotificationCenter.current().add(UNNotificationRequest(
            identifier: "brief-test", content: c,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)))
    }
}

// MARK: - Live Activity автобуса

enum BusLiveManager {
    static var isRunning: Bool { !Activity<BusActivityAttributes>.activities.isEmpty }

    static func start(departure: Date, direction: BusDirection) {
        guard FeatureFlags.busLiveOn, ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let route = BusRoutes.active
        let arrival = departure.addingTimeInterval(Double(route.travelMinutes) * 60)
        let from = route.fromStop(direction).isEmpty ? route.fromCity(direction) : route.fromStop(direction)
        let state = BusActivityAttributes.ContentState(
            departure: departure, arrival: arrival,
            from: from,
            to: route.toCity(direction).isEmpty ? route.toStop(direction) : route.toCity(direction),
            theme: UserDefaults.standard.string(forKey: "live.theme") ?? LiveTheme.night.rawValue)
        let attrs = BusActivityAttributes(route: route.number, colorHex: route.colorHex, direction: direction.rawValue)
        let content = ActivityContent(state: state, staleDate: arrival)
        Task {
            for a in Activity<BusActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
            _ = try? Activity.request(attributes: attrs, content: content, pushType: nil)
        }
        UserDefaults.standard.set(departure.timeIntervalSince1970, forKey: "busLive.lastStarted")
    }

    /// Просто закрыть (например, сменил автобус или выключил функцию)
    static func stop() {
        Task {
            for a in Activity<BusActivityAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) }
        }
    }

    /// Пользователь сам убрал — сегодня в эту сторону больше не запускаем
    static func stopByUser() {
        BusLiveDismissal.markAllDismissed()
        stop()
    }

    /// Автозапуск при открытии приложения: ближайший нужный рейс в пределах окна
    static func auto(data: ScheduleData) {
        // приехали — убираем
        for a in Activity<BusActivityAttributes>.activities where a.content.state.arrival < Date() {
            Task { await a.end(nil, dismissalPolicy: .immediate) }
        }
        guard FeatureFlags.busLiveOn else { stop(); return }
        guard FeatureFlags.busLiveAuto, !isRunning, CommuteSettings.enabled else { return }
        let route = BusRoutes.active
        let now = Date()
        let window = Double(FeatureFlags.busLiveWindow) * 60
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let city = route.useGeo ? CityLocator.shared.city : nil
        var candidate: (Date, BusDirection)?
        // утро: едем на пары
        if let upcoming = ScheduleEngine.slots(on: today, data: data).first(where: { !AddressFormat.isRemote($0.address) && $0.start > now }),
           let trip = CommutePlanner.morning(for: upcoming), trip.departure > now,
           city != .arkhangelsk {
            candidate = (trip.departure, .toCampus)
        }
        // после пар: домой
        if candidate == nil, let last = CommutePlanner.lastPair(on: today, data: data), now > last.end.addingTimeInterval(-30 * 60),
           city != .severodvinsk,
           let b = CommutePlanner.afterClasses(from: max(now, last.end), count: 1).first {
            candidate = (b.departure, .toHome)
        }
        guard let c = candidate, c.0.timeIntervalSince(now) <= window else { return }
        let dep = c.0, dir = c.1
        // сам убрал сегодня в эту сторону — не навязываемся
        if BusLiveDismissal.isDismissed(direction: dir.rawValue) { return }
        // уже запускали на этот рейс и пользователь закрыл смахиванием — тоже не навязываемся
        if UserDefaults.standard.double(forKey: "busLive.lastStarted") == dep.timeIntervalSince1970 { return }
        start(departure: dep, direction: dir)
    }
}

// MARK: - Маршрут до корпуса

extension Maps {
    /// Открыть адрес с учётом настроек: Яндекс или Apple, точка или маршрут от тебя
    static func smartURL(for address: String) -> URL? {
        if AddressFormat.isRemote(address) { return nil }
        var q = address
        if !q.lowercased().contains("архангельск") { q = "Архангельск, " + q }
        let e = q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let transit = FeatureFlags.mapsMode == 0
        if FeatureFlags.mapsProvider == 1 {
            return FeatureFlags.mapsRoute
                ? URL(string: "https://maps.apple.com/?daddr=\(e)&dirflg=\(transit ? "r" : "w")")
                : URL(string: "https://maps.apple.com/?q=\(e)")
        }
        return FeatureFlags.mapsRoute
            ? URL(string: "https://yandex.ru/maps/?rtext=~\(e)&rtt=\(transit ? "mt" : "pd")")
            : URL(string: "https://yandex.ru/maps/?text=\(e)")
    }
}

// MARK: - Рассылка группе (староста / зам)

struct BroadcastView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var kind = 0
    @State private var slotKey = ""
    @State private var newRoom = ""
    @State private var newTime = Date()
    @State private var extra = ""

    private let kinds = ["Перенос", "Отмена", "Другая аудитория", "Напоминание", "Своё"]

    private var slots: [LessonSlot] { ScheduleQuery.slots(schedule.data, days: 14).filter { $0.end > Date() } }
    private var slot: LessonSlot? { slots.first { $0.key == slotKey } ?? slots.first }

    private var text: String {
        guard let s = slot else { return extra }
        let f = Fmt.formatter("EEEE, d MMMM")
        let when = "\(f.string(from: s.start)) в \(hmString(s.start))"
        let what = "«\(s.lesson.subject)» (\(KindStyle.of(s.lesson.kind).label.lowercased()))"
        var t: String
        switch kind {
        case 0:
            t = "📢 Перенос: пара \(what), \(when), переносится на \(f.string(from: newTime)) в \(hmString(newTime))."
        case 1: t = "❌ Отмена: пары \(what), \(when), не будет."
        case 2: t = "🚪 Аудитория: пара \(what), \(when), пройдёт в ауд. \(newRoom.isEmpty ? "…" : newRoom)."
        case 3: t = "⏰ Напоминание: \(when) — \(what)" + (s.lesson.room.isEmpty ? "" : ", ауд. \(s.lesson.room)") + "."
        default: t = ""
        }
        if !extra.isEmpty { t += (t.isEmpty ? "" : "\n") + extra }
        return t
    }

    var body: some View {
        Form {
            Section("Что случилось") {
                Picker("Тип", selection: $kind) {
                    ForEach(kinds.indices, id: \.self) { Text(kinds[$0]).tag($0) }
                }
                if kind != 4 {
                    Picker("Пара", selection: $slotKey) {
                        ForEach(slots, id: \.key) { s in
                            Text("\(hmString(s.start)) \(s.start.formatted(.dateTime.day().month())) · \(s.lesson.subject)").tag(s.key)
                        }
                    }
                }
                if kind == 0 { DatePicker("Новое время", selection: $newTime) }
                if kind == 2 { TextField("Новая аудитория", text: $newRoom) }
                TextField("Добавить от себя", text: $extra, axis: .vertical)
            }
            Section("Сообщение") {
                Text(text.isEmpty ? "Заполни поля выше" : text)
                    .textSelection(.enabled)
                ShareLink(item: text) {
                    Label("Отправить в чат группы", systemImage: "paperplane.fill")
                }
                .disabled(text.isEmpty)
                Button {
                    UIPasteboard.general.string = text
                    Haptics.success()
                } label: {
                    Label("Скопировать", systemImage: "doc.on.doc")
                }
                .disabled(text.isEmpty)
            }
        }
        .navigationTitle("Рассылка группе")
        .onAppear { if slotKey.isEmpty { slotKey = slots.first?.key ?? "" } }
    }
}

// MARK: - Статистика семестра

struct SemesterStats {
    var done = 0
    var left = 0
    var hours: Double = 0
    /// предмет → (прошло, всего в расписании семестра)
    var bySubject: [(String, Int, Int)] = []
    var byKind: [(String, Int)] = []
    var busiestDay = ""
}

struct StatsView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var stats: SemesterStats?

    var body: some View {
        ScrollView {
            if let s = stats {
                VStack(alignment: .leading, spacing: 16) {
                    HStack(spacing: 12) {
                        tile("\(s.done)", "пар прошло")
                        tile("\(s.left)", "осталось")
                        tile("\(Int(s.hours))", "часов в универе")
                    }
                    if !s.busiestDay.isEmpty {
                        Label("Самый загруженный день — \(s.busiestDay)", systemImage: "flame.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.orange)
                    }
                    subjectBars(s.bySubject)
                    bars("По типам занятий", s.byKind)
                }
                .padding(20)
            } else {
                ProgressView("Считаю…").padding(40)
            }
        }
        .background(AmbientBackground())
        .navigationTitle("Статистика")
        .task { await compute() }
    }

    private func tile(_ v: String, _ t: String) -> some View {
        VStack(spacing: 2) {
            Text(v).font(.system(size: 26, weight: .heavy, design: .rounded)).foregroundStyle(brandGradient)
            Text(t).font(.caption2.weight(.semibold)).foregroundStyle(.secondary).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .glass(18)
    }

    /// По предметам: сколько пар уже прошло из всех, что есть в расписании семестра
    private func subjectBars(_ list: [(String, Int, Int)]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("По предметам").font(.system(.headline, design: .rounded))
                Text("Сколько пар уже прошло из всех в расписании семестра")
                    .font(.caption).foregroundStyle(.secondary)
            }
            ForEach(list, id: \.0) { item in
                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(item.0).font(.caption.weight(.semibold)).lineLimit(1)
                        Spacer()
                        Text("\(item.1)").font(.caption.weight(.heavy)).monospacedDigit()
                            + Text(" из \(item.2)").font(.caption2).foregroundColor(.secondary)
                    }
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.primary.opacity(0.08))
                            Capsule().fill(SubjectColor.color(for: item.0).gradient)
                                .frame(width: max(6, g.size.width * CGFloat(item.1) / CGFloat(max(item.2, 1))))
                        }
                    }
                    .frame(height: 7)
                }
            }
        }
        .padding(16)
        .glass(22)
    }

    private func bars(_ title: String, _ list: [(String, Int)]) -> some View {
        let top = list.first?.1 ?? 1
        return VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.system(.headline, design: .rounded))
            ForEach(list.prefix(10), id: \.0) { item in
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                        Text(item.0).font(.caption.weight(.semibold)).lineLimit(1)
                        Spacer()
                        Text("\(item.1)").font(.caption.weight(.bold)).monospacedDigit()
                    }
                    GeometryReader { g in
                        Capsule().fill(brandGradient)
                            .frame(width: max(6, g.size.width * CGFloat(item.1) / CGFloat(max(top, 1))))
                    }
                    .frame(height: 7)
                }
            }
        }
        .padding(16)
        .glass(22)
    }

    private func compute() async {
        let data = schedule.data
        let result = await Task.detached(priority: .userInitiated) { () -> SemesterStats in
            let cal = Calendar.current
            let now = Date()
            let today = cal.startOfDay(for: now)
            // семестр: примерно сентябрь–январь или февраль–июнь
            let month = cal.component(.month, from: now)
            let year = cal.component(.year, from: now)
            let startMonth = (month >= 8 || month == 1) ? 9 : 2
            let startYear = month == 1 ? year - 1 : year
            let start = cal.date(from: DateComponents(year: startYear, month: startMonth, day: 1)) ?? today
            let end = cal.date(byAdding: .month, value: startMonth == 9 ? 5 : 5, to: start) ?? today
            var s = SemesterStats()
            var subj: [String: Int] = [:], subjTotal: [String: Int] = [:], kinds: [String: Int] = [:], wd: [Int: Int] = [:]
            var d = start
            while d < end {
                for slot in ScheduleEngine.slots(on: d, data: data) {
                    subjTotal[slot.lesson.subject, default: 0] += 1
                    if slot.end <= now {
                        s.done += 1
                        s.hours += slot.end.timeIntervalSince(slot.start) / 3600
                        subj[slot.lesson.subject, default: 0] += 1
                        kinds[KindStyle.of(slot.lesson.kind).label, default: 0] += 1
                        wd[ScheduleEngine.weekday(of: slot.start), default: 0] += 1
                    } else {
                        s.left += 1
                    }
                }
                d = cal.date(byAdding: .day, value: 1, to: d) ?? end
            }
            s.bySubject = subjTotal.keys
                .map { ($0, subj[$0] ?? 0, subjTotal[$0] ?? 0) }
                .sorted { $0.1 != $1.1 ? $0.1 > $1.1 : $0.2 > $1.2 }
            s.byKind = kinds.sorted { $0.value > $1.value }.map { ($0.key, $0.value) }
            let names = ["", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
            if let top = wd.max(by: { $0.value < $1.value }), top.key < names.count { s.busiestDay = names[top.key] }
            return s
        }.value
        stats = result
    }
}

// MARK: - Siri и Команды

struct NextBusIntent: AppIntent {
    static var title: LocalizedStringResource = "Мой автобус"
    static var description = IntentDescription("Когда ближайший нужный автобус")

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let data = SharedSchedule.load()
        let now = Date()
        let today = Calendar.current.startOfDay(for: now)
        let r = BusRoutes.active
        if !(r.useGeo && CityLocator.shared.city == .arkhangelsk),
           let p = ScheduleEngine.slots(on: today, data: data).first(where: { !AddressFormat.isRemote($0.address) && $0.start > now }),
           let trip = CommutePlanner.morning(for: p), trip.departure > now {
            return .result(dialog: "Автобус \(r.number) в \(hmString(trip.departure)), успеешь к паре в \(hmString(p.start))")
        }
        if let b = CommutePlanner.afterClasses(from: now, count: 1).first {
            return .result(dialog: "Ближайший \(r.number) домой в \(hmString(b.departure))")
        }
        return .result(dialog: "Сегодня подходящих рейсов больше нет")
    }
}

// MARK: - Экран «Функции»

struct FeaturesView: View {
    @EnvironmentObject private var schedule: ScheduleStore

    @AppStorage("brief.on") private var briefOn = true
    @AppStorage("brief.mode") private var briefMode = 1
    @AppStorage("brief.time") private var briefTime = 6 * 60 + 30
    @AppStorage("brief.lead") private var briefLead = 15
    @AppStorage("brief.pairs") private var briefPairs = true
    @AppStorage("brief.bus") private var briefBus = true
    @AppStorage("brief.tasks") private var briefTasks = true

    @AppStorage("busLive.on") private var busLiveOn = true
    @AppStorage("busLive.auto") private var busLiveAuto = true
    @AppStorage("busLive.window") private var busLiveWindow = 60

    @AppStorage("maps.provider") private var mapsProvider = 0
    @AppStorage("maps.route") private var mapsRoute = true
    @AppStorage("maps.mode") private var mapsMode = 0

    @AppStorage("user.role") private var role = 0
    @AppStorage("home.order") private var homeOrder = HomeSection.defaultRaw

    @State private var busRunning = BusLiveManager.isRunning
    @AppStorage("session.mode") private var sessionMode = 0
    @AppStorage("session.window") private var sessionWindow = 21

    private var briefTimeBinding: Binding<Date> {
        Binding(get: {
            Calendar.current.date(bySettingHour: briefTime / 60, minute: briefTime % 60, second: 0, of: Date()) ?? Date()
        }, set: { d in
            let c = Calendar.current.dateComponents([.hour, .minute], from: d)
            briefTime = (c.hour ?? 6) * 60 + (c.minute ?? 30)
        })
    }

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $briefOn) { Label("Утренняя сводка", systemImage: "sun.max.fill") }
                if briefOn {
                    Picker("Когда", selection: $briefMode) {
                        Text("Перед выходом").tag(1)
                        Text("В своё время").tag(0)
                    }
                    if briefMode == 1 {
                        Stepper("За \(briefLead) мин до выхода", value: $briefLead, in: 5...60, step: 5)
                    } else {
                        DatePicker("Время", selection: briefTimeBinding, displayedComponents: .hourAndMinute)
                    }
                    Toggle("Пары на день", isOn: $briefPairs)
                    Toggle("Автобус и когда выходить", isOn: $briefBus)
                    Toggle("Горящие дедлайны", isOn: $briefTasks)
                    Button("Прислать пример через 5 сек") {
                        Notifier.requestAuthorization()
                        MorningBrief.test(data: schedule.data)
                        Haptics.success()
                    }
                }
            } header: { Text("Утро") } footer: {
                Text("Одно уведомление только в учебные дни. «Перед выходом» считается от автобуса к первой паре.")
            }

            Section {
                Toggle(isOn: $busLiveOn) { Label("Live Activity автобуса", systemImage: "bus.fill") }
                if busLiveOn {
                    Toggle("Запускать сама", isOn: $busLiveAuto)
                    if busLiveAuto {
                        Stepper("За \(busLiveWindow) мин до рейса", value: $busLiveWindow, in: 15...120, step: 15)
                    }
                    if busRunning {
                        Button("Остановить сейчас", role: .destructive) {
                            BusLiveManager.stopByUser(); busRunning = false
                        }
                    }
                }
            } header: { Text("Автобус на экране блокировки") } footer: {
                Text("Отсчёт до отправления и полоска поездки на экране блокировки и в Dynamic Island. «Сама» — при открытии приложения незадолго до рейса. Убрать — крестик на самой плашке: пара при этом останется. Тема — как у пары.")
            }

            Section {
                Picker("Роль", selection: $role) {
                    Text("Студент").tag(0)
                    Text("Староста").tag(1)
                    Text("Зам. старосты").tag(2)
                }
                if role > 0 {
                    NavigationLink { AttendanceView() } label: { Label("Посещаемость", systemImage: "person.crop.circle.badge.checkmark") }
                    NavigationLink { BroadcastView().environmentObject(schedule) } label: { Label("Рассылка группе", systemImage: "megaphone.fill") }
                }
            } header: { Text("Группа") } footer: {
                Text("Старосте и заму открываются посещаемость и готовые сообщения для чата группы: перенос, отмена, другая аудитория.")
            }

            Section {
                Picker("Карты", selection: $mapsProvider) {
                    Text("Яндекс").tag(0)
                    Text("Apple").tag(1)
                }
                .pickerStyle(.segmented)
                Toggle("Строить маршрут от меня", isOn: $mapsRoute)
                if mapsRoute {
                    Picker("Как", selection: $mapsMode) {
                        Text("Транспорт").tag(0)
                        Text("Пешком").tag(1)
                    }
                    .pickerStyle(.segmented)
                }
            } header: { Text("Маршрут до корпуса") } footer: {
                Text("Срабатывает при нажатии на адрес пары.")
            }

            Section {
                Picker(selection: $sessionMode) {
                    Text("Сам").tag(0)
                    Text("Всегда").tag(1)
                    Text("Выключен").tag(2)
                } label: { Label("Режим сессии", systemImage: "graduationcap.fill") }
                if sessionMode == 0 {
                    Stepper("За \(sessionWindow) дн. до экзамена", value: $sessionWindow, in: 3...60)
                }
                NavigationLink {
                    CelebrationSettingsView()
                } label: {
                    Label("Праздники и анимации", systemImage: "party.popper.fill")
                }
            } header: { Text("Сессия и праздники") } footer: {
                Text("В режиме сессии блок с экзаменами и билетами поднимается наверх главной.")
            }

            Section("На главной") {
                Toggle(isOn: homeBinding(.session)) { Label("Отсчёт до сессии", systemImage: "graduationcap.fill") }
                Toggle(isOn: homeBinding(.commute)) { Label("Дорога (мой автобус)", systemImage: "bus.fill") }
            }

            Section {
                ForEach(Tool.allCases) { t in ToolToggle(tool: t) }
            } header: { Text("Инструменты") } footer: {
                Text("Выключенные пропадут из сетки на главной.")
            }

            Section {
                Label("«Следующая пара в САФУ»", systemImage: "calendar")
                Label("«Автобус в САФУ»", systemImage: "bus.fill")
            } header: { Text("Siri и Команды") } footer: {
                Text("Скажи Siri или добавь в приложении «Команды». Можно повесить на кнопку действия. Если Siri не понимает название, используй то, что написано под иконкой приложения.")
            }
        }
        .navigationTitle("Функции")
        .onChange(of: briefOn) { _ in schedule.refreshSideEffects() }
        .onChange(of: briefMode) { _ in schedule.refreshSideEffects() }
        .onChange(of: briefTime) { _ in schedule.refreshSideEffects() }
        .onChange(of: briefLead) { _ in schedule.refreshSideEffects() }
        .onChange(of: busLiveOn) { on in if !on { BusLiveManager.stop(); busRunning = false } }
        .onAppear { busRunning = BusLiveManager.isRunning }
    }

    private func homeBinding(_ s: HomeSection) -> Binding<Bool> {
        Binding(get: { HomeSection.parse(homeOrder).contains(s) }, set: { on in
            var list = HomeSection.parse(homeOrder)
            if on, !list.contains(s) {
                let i = (list.firstIndex(of: .now) ?? -1) + 1
                list.insert(s, at: min(i, list.count))
            } else if !on {
                list.removeAll { $0 == s }
            }
            homeOrder = list.map(\.rawValue).joined(separator: ",")
        })
    }

}

private struct ToolToggle: View {
    let tool: Tool
    @AppStorage private var on: Bool
    init(tool: Tool) {
        self.tool = tool
        _on = AppStorage(wrappedValue: true, "tool.\(tool.rawValue)")
    }
    var body: some View {
        Toggle(isOn: $on) { Label(tool.title, systemImage: tool.icon) }
            .onChange(of: on) { _ in UserDefaults.standard.set(UUID().uuidString, forKey: "tools.rev") }
    }
}
