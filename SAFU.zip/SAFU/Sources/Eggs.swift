import SwiftUI
import UIKit

// MARK: - Пасхалки

enum Egg: String, CaseIterable {
    case nuke, hacker, oracle, game, arrived

    var title: String {
        switch self {
        case .nuke: return "Ядерный гриб"
        case .game: return "Трасса 150"
        case .hacker: return "Режим хакера"
        case .oracle: return "Шар предсказаний"
        case .arrived: return "Успел на пару"
        }
    }

    var hint: String {
        switch self {
        case .nuke: return "Автор любит, когда его трогают. Много раз. Последствия на твоей совести."
        case .game: return "Мелкий шрифт тоже кто-то читает. Там, где ждут автобус. И не торопись."
        case .hacker: return "Версия приложения тоже любит внимание."
        case .oracle: return "Сомневаешься перед парой? Встряхни всё как следует."
        case .arrived: return "Доедь до Архангельска и не попади в яму."
        }
    }

    var icon: String {
        switch self {
        case .nuke: return "atom"
        case .game: return "gamecontroller.fill"
        case .hacker: return "terminal.fill"
        case .oracle: return "sparkles"
        case .arrived: return "flag.checkered"
        }
    }
}

enum Eggs {
    private static let key = "eggs.found"

    static var all: Set<String> { Set(UserDefaults.standard.stringArray(forKey: key) ?? []) }
    static func has(_ e: Egg) -> Bool { all.contains(e.rawValue) }

    /// true — найдена впервые
    @discardableResult
    static func mark(_ e: Egg) -> Bool {
        var f = all
        guard f.insert(e.rawValue).inserted else { return false }
        UserDefaults.standard.set(Array(f), forKey: key)
        return true
    }
}

// MARK: - Встряхнуть телефон → шар предсказаний

extension Notification.Name {
    static let deviceDidShake = Notification.Name("safu.deviceDidShake")
}

extension UIWindow {
    open override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            NotificationCenter.default.post(name: .deviceDidShake, object: nil)
        }
        super.motionEnded(motion, with: event)
    }
}

enum Oracle {
    static let answers = [
        "Сегодня спросят именно тебя. Шучу. Или нет",
        "Препод опоздает на 15 минут",
        "Автобус придёт вовремя. Редкий день — цени",
        "Лабу примут с первого раза",
        "Сегодня лучше сесть на первую парту",
        "Автомат близко. Не расслабляйся",
        "Звёзды советуют открыть конспект",
        "Пара отменится… в параллельной вселенной",
        "Кофе перед парой обязателен",
        "Всё получится. Шар уверен на 146%",
        "Сегодня день, чтобы сдать долг",
        "Спроси старосту — он знает",
        "Лучше выйти на один автобус раньше",
        "Ответ туманен. Встряхни ещё раз",
    ]

    static func fire() {
        let first = Eggs.mark(.oracle)
        CelebrationCenter.shared.fire(Celebration(
            title: "🔮 " + (answers.randomElement() ?? ""),
            subtitle: first ? "Пасхалка найдена! Встряхивай, когда сомневаешься" : "Шар предсказаний · встряхни ещё",
            style: .emoji(["🔮", "✨", "⭐️"]), force: true))
    }
}

// MARK: - Режим хакера: матрица

enum HackerMode {
    static func toggle() {
        let d = UserDefaults.standard
        let on = !(d.bool(forKey: "egg.hackerOn"))
        d.set(on, forKey: "egg.hackerOn")
        if on {
            Eggs.mark(.hacker)
            d.set(d.string(forKey: "bg.style") ?? "", forKey: "egg.prevBg")
            d.set(d.string(forKey: "theme") ?? "", forKey: "egg.prevTheme")
            d.set(BackdropStyle.matrix.rawValue, forKey: "bg.style")
            d.set(AccentTheme.lime.rawValue, forKey: "theme")
            d.set(AppFont.mono.rawValue, forKey: "ui.font")
            d.set(2, forKey: "ui.scheme")
            d.set(false, forKey: "theme.seasonal")
            CelebrationCenter.shared.fire(Celebration(title: "> access granted_",
                                                      subtitle: "Режим хакера включён. Повтори, чтобы выйти",
                                                      style: .emoji(["💻", "🔐", "🟩", "0️⃣", "1️⃣"]), force: true))
        } else {
            d.set(d.string(forKey: "egg.prevBg") ?? BackdropStyle.glow.rawValue, forKey: "bg.style")
            d.set(d.string(forKey: "egg.prevTheme") ?? AccentTheme.blue.rawValue, forKey: "theme")
            d.set(AppFont.rounded.rawValue, forKey: "ui.font")
            d.set(0, forKey: "ui.scheme")
            CelebrationCenter.shared.fire(Celebration(title: "> logout_", subtitle: "Обычный режим", style: .confetti, force: true))
        }
    }
}

/// Цифровой дождь
struct MatrixLayer: View {
    let animated: Bool
    let strength: Double

    private static let glyphs = Array("01アイウエオカキクケコサシスセソタチツテトナニヌネ0101")

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !animated)) { ctx in
            let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 10_000) : 500
            Canvas { g, size in
                let green = Color(red: 0.25, green: 1.0, blue: 0.45)
                let resolved = Self.glyphs.map { g.resolve(Text(String($0)).font(.system(size: 13, weight: .medium, design: .monospaced)).foregroundColor(green)) }
                let head = g.resolve(Text("1").font(.system(size: 13, weight: .bold, design: .monospaced)).foregroundColor(.white))
                let step: CGFloat = 16
                let cols = Int(size.width / step) + 1
                for col in 0..<cols {
                    let seed = Double((col * 7919) % 101) / 101
                    let speed = 70 + seed * 110
                    let span = Double(size.height) + 320
                    let headY = (seed * span + t * speed).truncatingRemainder(dividingBy: span) - 160
                    for k in 0..<16 {
                        let y = headY - Double(k) * 16
                        guard y > -16, y < Double(size.height) + 16 else { continue }
                        var c = g
                        c.opacity = (k == 0 ? 0.9 : max(0, 0.55 - Double(k) * 0.035)) * strength
                        let x = CGFloat(col) * step + step / 2
                        if k == 0 {
                            c.draw(head, at: CGPoint(x: x, y: y))
                        } else {
                            let idx = (col * 31 + k * 17 + Int(t * 5)) % resolved.count
                            c.draw(resolved[abs(idx)], at: CGPoint(x: x, y: y))
                        }
                    }
                }
            }
        }
    }
}
