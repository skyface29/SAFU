import SwiftUI
import UIKit
import CryptoKit

// MARK: - Пасхалки

enum Egg: String, CaseIterable {
    case nuke, hacker, oracle, game, arrived, gold

    var title: String {
        switch self {
        case .nuke: return "Ядерный гриб"
        case .game: return "Трасса 150"
        case .hacker: return "Режим хакера"
        case .oracle: return "Шар предсказаний"
        case .arrived: return "Успел на пару"
        case .gold: return "Золотая сессия"
        }
    }

    var hint: String {
        switch self {
        case .nuke: return "Автор любит, когда его трогают. Много раз. Последствия на твоей совести."
        case .game: return "Мелкий шрифт тоже кто-то читает. Там, где ждут автобус. И не торопись."
        case .hacker: return "Версия приложения тоже любит внимание."
        case .oracle: return "Сомневаешься перед парой? Встряхни всё как следует."
        case .arrived: return "Доедь до Архангельска и не попади в яму."
        case .gold: return "Закрой все предметы в БРС на «5». Награда блестит."
        }
    }

    var icon: String {
        switch self {
        case .nuke: return "atom"
        case .game: return "gamecontroller.fill"
        case .hacker: return "terminal.fill"
        case .oracle: return "sparkles"
        case .arrived: return "flag.checkered"
        case .gold: return "trophy.fill"
        }
    }
}

enum Eggs {
    private static let key = "eggs.found"

    static var all: Set<String> { Set(UserDefaults.standard.stringArray(forKey: key) ?? []) }
    static func has(_ e: Egg) -> Bool { all.contains(e.rawValue) }

    /// true — найдена впервые
    @discardableResult
    static func mark(_ e: Egg) -> Bool {
        var f = all
        guard f.insert(e.rawValue).inserted else { return false }
        UserDefaults.standard.set(Array(f), forKey: key)
        VipIcons.checkReward()
        return true
    }
}

// MARK: - Секретные иконки

enum GoldIcon {
    static var unlocked: Bool { UserDefaults.standard.bool(forKey: "icon.gold") }

    /// Все предметы с баллами или итогом — на «5» (зачёты — сданы), и хотя бы один экзамен
    static func allExcellent() -> Bool {
        let list = GradesStore.shared.items.filter { !$0.entries.isEmpty || !$0.result.isEmpty }
        guard list.count >= 2, list.contains(where: { $0.control != .credit }) else { return false }
        return list.allSatisfy { g in
            if g.control == .credit { return g.result == "зачёт" || (g.result.isEmpty && g.total >= g.pass) }
            return g.result == "5" || (g.result.isEmpty && g.forecast == "5")
        }
    }

    static func checkUnlock() {
        guard !unlocked, allExcellent() else { return }
        UserDefaults.standard.set(true, forKey: "icon.gold")
        Eggs.mark(.gold)
        CelebrationCenter.shared.fire(Celebration(title: "Сессия на «5» 🏆",
                                                  subtitle: "Открыта золотая иконка — выбери её в разделе «Иконка»",
                                                  style: .emoji(["🏆", "🥇", "⭐️", "✨"]), force: true))
    }
}

/// Эксклюзивные иконки (Бриллиант, Зачётка, Сталь, Значок, Билет) — только по секретному коду.
/// В приложении хранится лишь SHA-256 от кода: по исходникам его не узнать.
/// Эксклюзивные иконки — награда за найденные пасхалки (как достижение в игре).
/// Секретных кодов нет: App Store не разрешает открывать возможности своими кодами (правило 3.1.1)
enum VipIcons {
    /// Сколько пасхалок нужно найти
    static let needed = 4

    /// Открыты раньше (кодом в прошлых версиях) или найдено достаточно пасхалок
    static var unlocked: Bool {
        UserDefaults.standard.bool(forKey: "icon.vip") || Egg.allCases.filter { Eggs.has($0) }.count >= needed
    }

    /// Нашёл нужное число пасхалок — иконки открываются, салют
    static func checkReward() {
        let d = UserDefaults.standard
        guard !d.bool(forKey: "icon.vip"), Egg.allCases.filter({ Eggs.has($0) }).count >= needed else { return }
        d.set(true, forKey: "icon.vip")
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.6) {
            CelebrationCenter.shared.fire(Celebration(title: "Эксклюзив открыт 💎",
                                                      subtitle: "Бриллиант, Зачётка, Сталь, Значок и Билет — в разделе «Иконка»",
                                                      style: .emoji(["💎", "👑", "✨", "🔐"]), force: true))
        }
    }
}

// MARK: - Встряхнуть телефон → шар предсказаний

extension Notification.Name {
    static let deviceDidShake = Notification.Name("safu.deviceDidShake")
}

extension UIWindow {
    open override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        if motion == .motionShake {
            NotificationCenter.default.post(name: .deviceDidShake, object: nil)
        }
        super.motionEnded(motion, with: event)
    }
}

enum Oracle {
    static let answers = [
        "Сегодня спросят именно тебя. Шучу. Или нет",
        "Препод опоздает на 15 минут",
        "Автобус придёт вовремя. Редкий день — цени",
        "Лабу примут с первого раза",
        "Сегодня лучше сесть на первую парту",
        "Автомат близко. Не расслабляйся",
        "Звёзды советуют открыть конспект",
        "Пара отменится… в параллельной вселенной",
        "Кофе перед парой обязателен",
        "Всё получится. Шар уверен на 146%",
        "Сегодня день, чтобы сдать долг",
        "Спроси старосту — он знает",
        "Лучше выйти на один автобус раньше",
        "Ответ туманен. Встряхни ещё раз",
    ]

    static func fire() {
        let first = Eggs.mark(.oracle)
        CelebrationCenter.shared.fire(Celebration(
            title: "🔮 " + (answers.randomElement() ?? ""),
            subtitle: first ? "Пасхалка найдена! Встряхивай, когда сомневаешься" : "Шар предсказаний · встряхни ещё",
            style: .emoji(["🔮", "✨", "⭐️"]), force: true))
    }
}

// MARK: - Режим хакера: матрица

enum HackerMode {
    static func toggle() {
        let d = UserDefaults.standard
        let on = !(d.bool(forKey: "egg.hackerOn"))
        d.set(on, forKey: "egg.hackerOn")
        if on {
            Eggs.mark(.hacker)
            d.set(d.string(forKey: "bg.style") ?? "", forKey: "egg.prevBg")
            d.set(d.string(forKey: "theme") ?? "", forKey: "egg.prevTheme")
            d.set(BackdropStyle.matrix.rawValue, forKey: "bg.style")
            d.set(AccentTheme.lime.rawValue, forKey: "theme")
            d.set(AppFont.mono.rawValue, forKey: "ui.font")
            d.set(2, forKey: "ui.scheme")
            d.set(false, forKey: "theme.seasonal")
            CelebrationCenter.shared.fire(Celebration(title: "> access granted_",
                                                      subtitle: "Режим хакера включён. Повтори, чтобы выйти",
                                                      style: .emoji(["💻", "🔐", "🟩", "0️⃣", "1️⃣"]), force: true))
        } else {
            d.set(d.string(forKey: "egg.prevBg") ?? BackdropStyle.glow.rawValue, forKey: "bg.style")
            d.set(d.string(forKey: "egg.prevTheme") ?? AccentTheme.blue.rawValue, forKey: "theme")
            d.set(AppFont.rounded.rawValue, forKey: "ui.font")
            d.set(0, forKey: "ui.scheme")
            CelebrationCenter.shared.fire(Celebration(title: "> logout_", subtitle: "Обычный режим", style: .confetti, force: true))
        }
    }
}

// Цифровой дождь фона «Матрица» — в Design.swift (ParticleField .matrix): его ведёт Core Animation
