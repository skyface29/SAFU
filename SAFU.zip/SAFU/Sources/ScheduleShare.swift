import SwiftUI
import UIKit

// MARK: - Расписание ребятам: карточкой, как ДЗ
//
// На экране «Пары» — «Отправить ребятам»: выбранный день или вся неделя красивой картинкой
// для чата группы (или текстом). Карточка в том же стиле, что и у ДЗ: цветная шапка,
// белый лист с парами и подпись «Арктика».

/// Что отправить: один день или неделю (любая дата внутри недели)
enum ScheduleSpan: Hashable {
    case day(Date)
    case week(Date)

    var isWeek: Bool {
        if case .week = self { return true }
        return false
    }
}

/// День для карточки: дата и пары по порядку
struct ShareDay: Identifiable {
    let date: Date
    let slots: [LessonSlot]
    var id: Date { date }
}

enum ScheduleShare {
    /// Дни для карточки. В неделе пн–пт всегда, суббота — только если в неё есть пары
    static func days(_ span: ScheduleSpan, data: ScheduleData) -> [ShareDay] {
        let cal = Calendar.current
        switch span {
        case .day(let d):
            let day = cal.startOfDay(for: d)
            return [ShareDay(date: day, slots: sorted(ScheduleEngine.slots(on: day, data: data)))]
        case .week(let any):
            let monday = WeekKey.monday(of: any)
            var out: [ShareDay] = []
            for i in 0..<6 {
                guard let d = cal.date(byAdding: .day, value: i, to: monday) else { continue }
                let slots = sorted(ScheduleEngine.slots(on: d, data: data))
                if i == 5 && slots.isEmpty { continue }
                out.append(ShareDay(date: d, slots: slots))
            }
            return out
        }
    }

    private static func sorted(_ s: [LessonSlot]) -> [LessonSlot] { s.sorted { $0.start < $1.start } }

    /// Номер группы: из РУЗ, а если расписание своё — из профиля
    static func group(_ data: ScheduleData) -> String {
        let g = data.ruzGroupNumber.trimmingCharacters(in: .whitespaces)
        if !g.isEmpty { return g }
        return (UserDefaults.standard.string(forKey: "group") ?? "").trimmingCharacters(in: .whitespaces)
    }

    // MARK: подписи

    static func caption(_ span: ScheduleSpan) -> String {
        switch span {
        case .day(let d):
            let cal = Calendar.current
            if cal.isDateInToday(d) { return L("ПАРЫ НА СЕГОДНЯ") }
            if cal.isDateInTomorrow(d) { return L("ПАРЫ НА ЗАВТРА") }
            return L("ПАРЫ НА ДЕНЬ")
        case .week:
            return L("ПАРЫ НА НЕДЕЛЮ")
        }
    }

    /// «Вторник, 28 октября» или «27 октября – 1 ноября»
    static func title(_ span: ScheduleSpan, days: [ShareDay]) -> String {
        switch span {
        case .day(let d):
            return Fmt.formatter("EEEE, d MMMM").string(from: d).capitalizedFirst
        case .week:
            guard let a = days.first?.date, let b = days.last?.date else { return L("Неделя") }
            return range(a, b)
        }
    }

    static func range(_ a: Date, _ b: Date) -> String {
        let cal = Calendar.current
        let full = Fmt.formatter("d MMMM")
        if cal.component(.month, from: a) == cal.component(.month, from: b) {
            return "\(cal.component(.day, from: a)) – \(full.string(from: b))"
        }
        return "\(full.string(from: a)) – \(full.string(from: b))"
    }

    static func pairs(_ n: Int) -> String { "\(n) \(HWText.plural(n, L("пара"), L("пары"), L("пар")))" }

    /// «4 пары · 8:20 – 16:05» или «18 пар · 5 учебных дней»
    static func summary(_ span: ScheduleSpan, days: [ShareDay]) -> String {
        let all = days.flatMap(\.slots)
        guard !all.isEmpty,
              let start = all.map(\.start).min(),
              let end = all.map(\.end).max() else { return L("Пар нет") }
        switch span {
        case .day:
            return "\(pairs(all.count)) · \(hmString(start)) – \(hmString(end))"
        case .week:
            let busy = days.filter { !$0.slots.isEmpty }.count
            return "\(pairs(all.count)) · \(busy) \(HWText.plural(busy, L("учебный день"), L("учебных дня"), L("учебных дней")))"
        }
    }

    /// «Иванов Иван Иванович» → «Иванов И. И.»; уже сокращённое и несколько через запятую — как есть по смыслу
    static func teacher(_ raw: String) -> String {
        raw.split(separator: ",").map { person -> String in
            let w = person.split(separator: " ").map(String.init)
            guard w.count == 3, w[1].count > 2, w[2].count > 2 else {
                return person.trimmingCharacters(in: .whitespaces)
            }
            return "\(w[0]) \(w[1].prefix(1)). \(w[2].prefix(1))."
        }
        .filter { !$0.isEmpty }
        .joined(separator: ", ")
    }

    /// «ауд. 1405», «спортзал» или «дистант»
    static func room(_ s: LessonSlot) -> String {
        if s.isRemote { return L("дистант") }
        let r = s.lesson.room.trimmingCharacters(in: .whitespaces)
        if r.isEmpty { return "" }
        return r.first?.isNumber == true ? L("ауд. \(r)") : r
    }

    /// Адрес корпуса — пригодится тем, кто не помнит, где «НСД 17»
    static func address(_ s: LessonSlot) -> String {
        if s.isRemote { return "" }
        let a = AddressFormat.full(s.address)
        if !a.isEmpty { return a }
        return s.lesson.building.trimmingCharacters(in: .whitespaces)
    }

    /// Окно между парами (обед после 3-й пары — 55 минут — окном не считаем)
    static func window(after a: LessonSlot, before b: LessonSlot) -> String? {
        let minutes = Int(b.start.timeIntervalSince(a.end) / 60)
        guard minutes > 60 else { return nil }
        let h = minutes / 60, m = minutes % 60
        return L("Окно ") + (m == 0 ? L("\(h) ч") : L("\(h) ч \(m) мин"))
    }

    // MARK: текстом

    private static func line(_ s: LessonSlot) -> String {
        let kind = KindStyle.of(s.lesson.kind).label.lowercased()
        let place = [room(s), address(s)].filter { !$0.isEmpty }.joined(separator: ", ")
        var out = "\(hmString(s.start))–\(hmString(s.end)) \(s.lesson.subject) (\(kind))"
        if !place.isEmpty { out += " — \(place)" }
        let t = teacher(s.lesson.teacher)
        if !t.isEmpty { out += ", \(t)" }
        return out
    }

    static func text(_ span: ScheduleSpan, data: ScheduleData) -> String {
        let list = Self.days(span, data: data)
        let g = Self.group(data)
        var lines: [String] = []
        switch span {
        case .day(let d):
            lines.append("📅 \(Fmt.formatter("EEEE, d MMMM").string(from: d).capitalizedFirst)" + (g.isEmpty ? "" : " · \(g)"))
            let slots = list.first?.slots ?? []
            if slots.isEmpty { lines.append(L("Пар нет 🎉")) }
            for (i, s) in slots.enumerated() { lines.append("\(i + 1). \(line(s))") }
        case .week:
            lines.append(L("📅 Пары на неделю: \(title(span, days: list))") + (g.isEmpty ? "" : " · \(g)"))
            for d in list {
                lines.append("")
                lines.append("▫️ \(Fmt.formatter("EEEE, d MMMM").string(from: d.date).capitalizedFirst)")
                if d.slots.isEmpty { lines.append(L("пар нет")) }
                for s in d.slots { lines.append(line(s)) }
            }
        }
        return lines.joined(separator: "\n")
    }

    // MARK: картинкой

    @MainActor
    static func image(_ span: ScheduleSpan, data: ScheduleData) -> UIImage? {
        let card = ScheduleShareCard(span: span, days: Self.days(span, data: data), group: Self.group(data))
        let r = ImageRenderer(content: card.environment(\.colorScheme, .light))
        r.scale = 3
        return r.uiImage
    }

    /// Для окна «Поделиться»: картинка, а если не нарисовалась — текст
    @MainActor
    static func imageItems(_ span: ScheduleSpan, data: ScheduleData) -> [Any] {
        if let img = image(span, data: data) { return [img] }
        return [text(span, data: data)]
    }
}

// MARK: - Карточка для чата группы

/// Аккуратная карточка расписания: цветная шапка с датой, пары по порядку, подпись — как у ДЗ
struct ScheduleShareCard: View {
    let span: ScheduleSpan
    let days: [ShareDay]
    let group: String

    private let ink = Color(white: 0.1)
    private let muted = Color(white: 0.5)

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            header

            Group {
                if span.isWeek { weekContent } else { dayContent }
            }
            .padding(span.isWeek ? 16 : 18)
            .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 5) {
                Image(systemName: "snowflake")
                Text(AppInfo.name)
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(Color(white: 0.6))
            .padding(.horizontal, 20)
            .padding(.bottom, 14)
        }
        .frame(width: 360)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .shadow(color: .black.opacity(0.12), radius: 14, y: 6)
        .padding(18)
        .background(LinearGradient(colors: [Color.brand2.opacity(0.16), Color.brand.opacity(0.10)],
                                   startPoint: .topLeading, endPoint: .bottomTrailing))
        .background(Color.white)
    }

    // MARK: шапка

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "calendar")
                Text(ScheduleShare.caption(span))
                    .tracking(1.2)
                Spacer()
                if !group.isEmpty {
                    Text(group)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(.white.opacity(0.25), in: Capsule())
                }
            }
            .font(.system(size: 11, weight: .heavy))
            .foregroundStyle(.white.opacity(0.9))

            Text(ScheduleShare.title(span, days: days))
                .font(.system(size: 24, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 6) {
                Image(systemName: "clock")
                Text(ScheduleShare.summary(span, days: days))
            }
            .font(.system(size: 14, weight: .semibold))
            .foregroundStyle(.white.opacity(0.95))
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [Color.brand2, Color.brand],
                                   startPoint: .topLeading, endPoint: .bottomTrailing))
    }

    // MARK: один день — подробно

    @ViewBuilder
    private var dayContent: some View {
        let slots = days.first?.slots ?? []
        if slots.isEmpty {
            restNote(L("Пар нет — отдыхаем 🎉"))
        } else {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(Array(slots.enumerated()), id: \.element.key) { i, s in
                    if i > 0, let gap = ScheduleShare.window(after: slots[i - 1], before: s) {
                        gapRow(gap)
                    }
                    dayRow(s)
                }
            }
        }
    }

    private func dayRow(_ s: LessonSlot) -> some View {
        let st = KindStyle.of(s.lesson.kind)
        let room = ScheduleShare.room(s)
        let address = ScheduleShare.address(s)
        let teacher = ScheduleShare.teacher(s.lesson.teacher)
        let note = s.note.trimmingCharacters(in: .whitespacesAndNewlines)
        return HStack(alignment: .top, spacing: 12) {
            VStack(alignment: .leading, spacing: 1) {
                Text(hmString(s.start))
                    .font(.system(size: 16, weight: .heavy, design: .rounded))
                    .foregroundStyle(ink)
                Text(hmString(s.end))
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(muted)
            }
            .frame(width: 48, alignment: .leading)

            VStack(alignment: .leading, spacing: 5) {
                Text(s.lesson.subject)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(ink)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 6) {
                    KindBadge(kind: s.lesson.kind, size: 10, filled: false)
                    if !room.isEmpty {
                        Text(room)
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(ink)
                    }
                }
                if !address.isEmpty {
                    detail("mappin.and.ellipse", address)
                }
                if !teacher.isEmpty {
                    detail("person", teacher)
                }
                if !note.isEmpty && note.count <= 80 {
                    Text(note)
                        .font(.system(size: 12).italic())
                        .foregroundStyle(muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .padding(.leading, 12)
            .overlay(alignment: .leading) {
                Capsule().fill(st.color).frame(width: 4)
            }
            Spacer(minLength: 0)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(st.color.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
    }

    private func detail(_ icon: String, _ text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 5) {
            Image(systemName: icon)
                .font(.system(size: 11, weight: .semibold))
            Text(text)
                .font(.system(size: 12, weight: .medium))
                .fixedSize(horizontal: false, vertical: true)
        }
        .foregroundStyle(Color(white: 0.4))
    }

    private func gapRow(_ text: String) -> some View {
        HStack(spacing: 8) {
            Rectangle().fill(Color(white: 0.88)).frame(height: 1)
            Label(text, systemImage: "cup.and.saucer")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Color(white: 0.55))
                .fixedSize()
            Rectangle().fill(Color(white: 0.88)).frame(height: 1)
        }
        .padding(.horizontal, 6)
    }

    private func restNote(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 16, weight: .semibold))
            .foregroundStyle(muted)
            .frame(maxWidth: .infinity, alignment: .center)
            .padding(.vertical, 18)
    }

    // MARK: неделя — компактно, по дням

    @ViewBuilder
    private var weekContent: some View {
        if days.allSatisfy({ $0.slots.isEmpty }) {
            restNote(L("На этой неделе пар нет 🎉"))
        } else {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(Array(days.enumerated()), id: \.element.id) { i, d in
                    if i > 0 { Rectangle().fill(Color(white: 0.92)).frame(height: 1) }
                    weekDay(d)
                }
            }
        }
    }

    private func weekDay(_ d: ShareDay) -> some View {
        let today = Calendar.current.isDateInToday(d.date)
        return VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text(Fmt.formatter("EEEE").string(from: d.date).capitalizedFirst)
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .foregroundStyle(today ? Color.brand : ink)
                Text(Fmt.formatter("d MMMM").string(from: d.date))
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(muted)
                Spacer()
                Text(d.slots.isEmpty ? L("пар нет") : ScheduleShare.pairs(d.slots.count))
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(d.slots.isEmpty ? Color(white: 0.6) : Color.brand)
            }
            ForEach(d.slots, id: \.key) { s in weekRow(s) }
        }
    }

    private func weekRow(_ s: LessonSlot) -> some View {
        let st = KindStyle.of(s.lesson.kind)
        let room = ScheduleShare.room(s)
        return HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(hmString(s.start))
                .font(.system(size: 13, weight: .heavy, design: .rounded))
                .foregroundStyle(ink)
                .frame(width: 40, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(ink)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 4) {
                    Text(st.label)
                        .foregroundStyle(st.color)
                    if !room.isEmpty {
                        Text("· \(room)")
                            .foregroundStyle(muted)
                    }
                }
                .font(.system(size: 11, weight: .bold))
            }
            .padding(.leading, 10)
            .overlay(alignment: .leading) {
                Capsule().fill(st.color).frame(width: 3)
            }
            Spacer(minLength: 0)
        }
    }
}

// MARK: - «Картинкой» в инструментах: выбрать день или неделю и посмотреть, что уйдёт

struct ScheduleShareView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var mode = 0          // 0 сегодня, 1 завтра, 2 эта неделя, 3 следующая
    @State private var image: UIImage?
    @State private var share: ShareItem?

    private var span: ScheduleSpan {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        // в воскресенье «эта неделя» — уже следующая
        let base = ScheduleEngine.weekday(of: today) == 7 ? (cal.date(byAdding: .day, value: 1, to: today) ?? today) : today
        switch mode {
        case 0: return .day(today)
        case 1: return .day(cal.date(byAdding: .day, value: 1, to: today) ?? today)
        case 2: return .week(base)
        default: return .week(cal.date(byAdding: .day, value: 7, to: base) ?? base)
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Picker(L("Что"), selection: $mode) {
                    Text(L("Сегодня")).tag(0)
                    Text(L("Завтра")).tag(1)
                    Text(L("Неделя")).tag(2)
                    Text(L("След.")).tag(3)
                }
                .pickerStyle(.segmented)

                if let image {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        .shadow(color: .black.opacity(0.12), radius: 12, y: 5)
                        .transition(.opacity)
                }

                Menu {
                    Button { send() } label: { Label(L("Картинкой"), systemImage: "photo") }
                    Button {
                        share = ShareItem(items: [ScheduleShare.text(span, data: schedule.data)])
                    } label: { Label(L("Текстом"), systemImage: "text.alignleft") }
                    Button {
                        UIPasteboard.general.string = ScheduleShare.text(span, data: schedule.data)
                        Haptics.success()
                    } label: { Label(L("Скопировать текст"), systemImage: "doc.on.doc") }
                } label: {
                    Label(L("Отправить ребятам"), systemImage: "paperplane.fill")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .foregroundStyle(.white)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                } primaryAction: {
                    send()
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .pausesAmbientWhileScrolling()
        .navigationTitle(L("Расписание картинкой"))
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .onAppear(perform: render)
        .onChange(of: mode) { render() }
        .onChange(of: schedule.data.ruzEvents.count) { render() }
    }

    private func send() {
        Haptics.tap()
        if let image { share = ShareItem(items: [image]) }
        else { share = ShareItem(items: ScheduleShare.imageItems(span, data: schedule.data)) }
    }

    @MainActor private func render() {
        image = ScheduleShare.image(span, data: schedule.data)
    }
}
