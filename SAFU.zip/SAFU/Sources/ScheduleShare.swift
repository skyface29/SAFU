import SwiftUI
import UIKit

// MARK: - Расписание картинкой
// Красивая карточка на день или неделю — сразу в чат группы.

struct ScheduleShareView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @AppStorage("group") private var group = ""
    @State private var mode = 0          // 0 сегодня, 1 завтра, 2 неделя
    @State private var image: UIImage?

    private var days: [(Date, [LessonSlot])] {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        switch mode {
        case 0: return [(today, ScheduleEngine.slots(on: today, data: schedule.data))]
        case 1:
            let t = cal.date(byAdding: .day, value: 1, to: today) ?? today
            return [(t, ScheduleEngine.slots(on: t, data: schedule.data))]
        default:
            // эта неделя, а в выходные — следующая
            var monday = WeekKey.monday(of: today)
            if ScheduleEngine.weekday(of: today) >= 6 { monday = cal.date(byAdding: .day, value: 7, to: monday) ?? monday }
            return (0..<6).compactMap { i in
                guard let d = cal.date(byAdding: .day, value: i, to: monday) else { return nil }
                return (d, ScheduleEngine.slots(on: d, data: schedule.data))
            }
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Picker("Что", selection: $mode) {
                    Text("Сегодня").tag(0)
                    Text("Завтра").tag(1)
                    Text("Неделя").tag(2)
                }
                .pickerStyle(.segmented)

                card
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .shadow(color: .black.opacity(0.15), radius: 14, y: 6)

                if let image {
                    ShareLink(item: Image(uiImage: image),
                              preview: SharePreview("Расписание", image: Image(uiImage: image))) {
                        Label("Отправить картинкой", systemImage: "square.and.arrow.up")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .foregroundStyle(.white)
                            .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                    .buttonStyle(PressableStyle())
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .navigationTitle("Расписание картинкой")
        .onAppear(perform: render)
        .onChange(of: mode) { _ in render() }
    }

    @MainActor private func render() {
        let r = ImageRenderer(content: card.frame(width: 390))
        r.scale = 3
        image = r.uiImage
    }

    private var title: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        switch mode {
        case 0: f.dateFormat = "EEEE, d MMMM"; return "Сегодня · " + f.string(from: Date())
        case 1:
            f.dateFormat = "EEEE, d MMMM"
            return "Завтра · " + f.string(from: Date().addingTimeInterval(86_400))
        default:
            guard let first = days.first?.0, let last = days.last?.0 else { return "Неделя" }
            f.dateFormat = "d MMM"
            return "Неделя · \(f.string(from: first)) – \(f.string(from: last))"
        }
    }

    private var card: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("РАСПИСАНИЕ" + (group.isEmpty ? "" : " · \(group)"))
                        .font(.system(size: 11, weight: .heavy))
                        .foregroundStyle(.white.opacity(0.75))
                    Text(title.capitalizedFirst)
                        .font(.system(size: 20, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Image(systemName: "snowflake")
                    .font(.system(size: 26, weight: .bold))
                    .foregroundStyle(.white.opacity(0.9))
            }

            ForEach(days, id: \.0) { item in
                let day = item.0
                let slots = item.1
                VStack(alignment: .leading, spacing: 8) {
                    if mode == 2 {
                        Text(dayTitle(day))
                            .font(.system(size: 13, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white.opacity(0.85))
                    }
                    if slots.isEmpty {
                        Text(mode == 2 ? "пар нет" : "Пар нет — отдыхаем 🎉")
                            .font(.system(size: mode == 2 ? 12 : 15, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.8))
                            .padding(.vertical, mode == 2 ? 0 : 10)
                    }
                    ForEach(slots, id: \.key) { s in pairRow(s) }
                }
            }

            Text("САФУ · by @\(Developer.telegram)")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.white.opacity(0.55))
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(20)
        .background(
            LinearGradient(colors: [Color.brand, Color.brand2.opacity(0.9), Color.brand.opacity(0.85)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
        )
    }

    private func pairRow(_ s: LessonSlot) -> some View {
        let st = KindStyle.of(s.lesson.kind)
        return HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 0) {
                Text(hmString(s.start)).font(.system(size: 14, weight: .heavy, design: .rounded))
                Text(hmString(s.end)).font(.system(size: 11, weight: .semibold)).opacity(0.7)
            }
            .foregroundStyle(.white)
            .frame(width: 44, alignment: .leading)
            RoundedRectangle(cornerRadius: 2).fill(st.color).frame(width: 3)
            VStack(alignment: .leading, spacing: 2) {
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                Text([st.label, s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)"].filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.75))
            }
            Spacer(minLength: 0)
        }
        .padding(10)
        .background(Color.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func dayTitle(_ d: Date) -> String {
        let f = Fmt.formatter("EEEE, d MMMM")
        return f.string(from: d).capitalizedFirst
    }
}
