import SwiftUI

// MARK: - Заметки
// Много заметок вместо одного поля: заголовок, текст, чек-лист, цвет, предмет, закрепление, поиск.
// Старая единственная заметка (ключ "notes") переносится сюда при первом запуске.

struct NoteItem: Codable, Identifiable, Hashable {
    var id = UUID()
    var text: String
    var done = false
}

struct Note: Codable, Identifiable, Hashable {
    var id = UUID()
    var title: String = ""
    var text: String = ""
    var items: [NoteItem] = []
    var subject: String = ""
    var color: Int = 0
    var pinned = false
    var created = Date()
    var updated = Date()

    var displayTitle: String {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !t.isEmpty { return t }
        let first = text.split(separator: "\n").first.map(String.init)?.trimmingCharacters(in: .whitespaces) ?? ""
        if !first.isEmpty { return first }
        return items.first?.text ?? "Без названия"
    }

    var preview: String {
        let body = title.isEmpty ? text.split(separator: "\n").dropFirst().joined(separator: " ") : text
        let clean = body.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespaces)
        if !clean.isEmpty { return clean }
        if !items.isEmpty { return "\(items.filter(\.done).count) из \(items.count) готово" }
        return ""
    }

    var isEmpty: Bool {
        title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && items.allSatisfy { $0.text.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    static let palette: [Color] = [
        .clear,
        Color(red: 0.98, green: 0.80, blue: 0.25),
        Color(red: 0.40, green: 0.78, blue: 0.45),
        Color(red: 0.35, green: 0.62, blue: 0.98),
        Color(red: 0.93, green: 0.42, blue: 0.55),
        Color(red: 0.65, green: 0.45, blue: 0.95),
    ]
}

final class NotesStore: ObservableObject {
    static let shared = NotesStore()
    @Published var notes: [Note] = [] { didSet { save() } }
    private let key = "notes.v2"

    init() {
        let d = UserDefaults.standard
        if let raw = d.data(forKey: key), let list = try? JSONDecoder().decode([Note].self, from: raw) {
            notes = list
        } else if let old = d.string(forKey: "notes"), !old.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            notes = [Note(text: old)]
        }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(notes) { UserDefaults.standard.set(raw, forKey: key) }
    }

    /// Закреплённые сверху, дальше — свежие
    var sorted: [Note] {
        notes.sorted { a, b in
            if a.pinned != b.pinned { return a.pinned }
            return a.updated > b.updated
        }
    }

    func upsert(_ n: Note) {
        var n = n
        n.updated = Date()
        if let i = notes.firstIndex(where: { $0.id == n.id }) { notes[i] = n } else { notes.insert(n, at: 0) }
    }

    func delete(_ id: UUID) { notes.removeAll { $0.id == id } }

    func togglePin(_ id: UUID) {
        if let i = notes.firstIndex(where: { $0.id == id }) { notes[i].pinned.toggle() }
    }
}

// MARK: - Список

struct NotesView: View {
    @ObservedObject private var store = NotesStore.shared
    @State private var query = ""
    @State private var editing: Note?

    private var filtered: [Note] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return store.sorted }
        return store.sorted.filter {
            $0.title.lowercased().contains(q) || $0.text.lowercased().contains(q)
                || $0.subject.lowercased().contains(q) || $0.items.contains { $0.text.lowercased().contains(q) }
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                if store.notes.isEmpty {
                    EmptyState(icon: "note.text", title: "Пока пусто",
                               text: "Нажми «+», чтобы записать мысль, список покупок к общаге или что спросить у преподавателя.")
                        .padding(.top, 40)
                }
                ForEach(filtered) { n in
                    Button {
                        Haptics.tap()
                        editing = n
                    } label: {
                        NoteCard(note: n)
                    }
                    .buttonStyle(PressableStyle())
                    .contextMenu {
                        Button { store.togglePin(n.id) } label: {
                            Label(n.pinned ? "Открепить" : "Закрепить", systemImage: n.pinned ? "pin.slash" : "pin")
                        }
                        ShareLink(item: shareText(n)) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                        Button(role: .destructive) {
                            withAnimation { store.delete(n.id) }
                        } label: { Label("Удалить", systemImage: "trash") }
                    }
                }
            }
            .padding(20)
        }
        .background(AmbientBackground())
        .searchable(text: $query, prompt: "Поиск по заметкам")
        .navigationTitle("Заметки")
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    Haptics.tap()
                    editing = Note()
                } label: { Image(systemName: "square.and.pencil") }
            }
        }
        .sheet(item: $editing) { n in
            NoteSheet(note: n)
        }
    }

    private func shareText(_ n: Note) -> String {
        var parts: [String] = []
        if !n.title.isEmpty { parts.append(n.title) }
        if !n.text.isEmpty { parts.append(n.text) }
        if !n.items.isEmpty { parts.append(n.items.map { ($0.done ? "☑ " : "☐ ") + $0.text }.joined(separator: "\n")) }
        return parts.joined(separator: "\n\n")
    }
}

struct NoteCard: View {
    let note: Note

    var body: some View {
        HStack(spacing: 0) {
            if note.color > 0 {
                Rectangle()
                    .fill(Note.palette[note.color % Note.palette.count])
                    .frame(width: 5)
            }
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    if note.pinned {
                        Image(systemName: "pin.fill").font(.caption2).foregroundStyle(Color.brand)
                    }
                    Text(note.displayTitle)
                        .font(.system(.subheadline, design: .rounded).weight(.bold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Spacer(minLength: 4)
                    Text(Fmt.relative(note.updated))
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
                if !note.preview.isEmpty {
                    Text(note.preview)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                }
                if !note.items.isEmpty || !note.subject.isEmpty {
                    HStack(spacing: 8) {
                        if !note.items.isEmpty {
                            let done = note.items.filter(\.done).count
                            Label("\(done)/\(note.items.count)", systemImage: done == note.items.count ? "checkmark.circle.fill" : "checklist")
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(done == note.items.count ? Color.green : Color.secondary)
                        }
                        if !note.subject.isEmpty {
                            Text(note.subject)
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(Color.brand)
                                .lineLimit(1)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 3)
                                .background(Color.brand.opacity(0.12), in: Capsule())
                        }
                    }
                }
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        .glass(18)
    }
}

// MARK: - Редактор

struct NoteSheet: View {
    @State var note: Note
    @ObservedObject private var store = NotesStore.shared
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @State private var newItem = ""
    @FocusState private var focus: Field?

    enum Field { case title, text, item }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Заголовок", text: $note.title)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                        .focused($focus, equals: .title)
                    TextField("Текст заметки", text: $note.text, axis: .vertical)
                        .lineLimit(4...40)
                        .focused($focus, equals: .text)
                }

                Section {
                    ForEach($note.items) { $it in
                        HStack(spacing: 10) {
                            Button {
                                Haptics.tap()
                                it.done.toggle()
                            } label: {
                                Image(systemName: it.done ? "checkmark.circle.fill" : "circle")
                                    .font(.title3)
                                    .foregroundStyle(it.done ? Color.green : Color.secondary)
                            }
                            .buttonStyle(.plain)
                            TextField("Пункт", text: $it.text)
                                .strikethrough(it.done)
                                .foregroundStyle(it.done ? Color.secondary : Color.primary)
                        }
                    }
                    .onDelete { note.items.remove(atOffsets: $0) }
                    .onMove { note.items.move(fromOffsets: $0, toOffset: $1) }
                    HStack(spacing: 10) {
                        Image(systemName: "plus.circle.fill").font(.title3).foregroundStyle(Color.brand)
                        TextField("Добавить пункт", text: $newItem)
                            .focused($focus, equals: .item)
                            .submitLabel(.next)
                            .onSubmit(addItem)
                    }
                } header: {
                    Text("Чек-лист")
                } footer: {
                    if !note.items.isEmpty { Text("Смахни пункт влево, чтобы удалить.") }
                }

                Section("Оформление") {
                    HStack(spacing: 14) {
                        ForEach(0..<Note.palette.count, id: \.self) { i in
                            Circle()
                                .fill(i == 0 ? Color.primary.opacity(0.08) : Note.palette[i])
                                .frame(width: 28, height: 28)
                                .overlay(Circle().strokeBorder(Color.primary.opacity(note.color == i ? 0.8 : 0), lineWidth: 2).padding(-4))
                                .overlay { if i == 0 { Image(systemName: "nosign").font(.caption).foregroundStyle(.secondary) } }
                                .onTapGesture { Haptics.tap(); note.color = i }
                        }
                    }
                    .padding(.vertical, 4)
                    Picker("Предмет", selection: $note.subject) {
                        Text("Без предмета").tag("")
                        ForEach(ScheduleQuery.subjects(schedule.data), id: \.self) { Text($0).tag($0) }
                        if !note.subject.isEmpty && !ScheduleQuery.subjects(schedule.data).contains(note.subject) {
                            Text(note.subject).tag(note.subject)
                        }
                    }
                    Toggle("Закрепить сверху", isOn: $note.pinned)
                }

                if store.notes.contains(where: { $0.id == note.id }) {
                    Section {
                        Button("Удалить заметку", role: .destructive) {
                            store.delete(note.id)
                            dismiss()
                        }
                    }
                }
            }
            .navigationTitle(note.isEmpty ? "Новая заметка" : "Заметка")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { saveAndClose() }.fontWeight(.semibold)
                }
            }
            .onAppear { if note.isEmpty { focus = .title } }
        }
    }

    private func addItem() {
        let t = newItem.trimmingCharacters(in: .whitespaces)
        guard !t.isEmpty else { return }
        note.items.append(NoteItem(text: t))
        newItem = ""
        focus = .item
    }

    private func saveAndClose() {
        addItem()
        note.items.removeAll { $0.text.trimmingCharacters(in: .whitespaces).isEmpty }
        if note.isEmpty {
            store.delete(note.id)
        } else {
            store.upsert(note)
            Haptics.success()
        }
        dismiss()
    }
}

/// Блок «Заметки» в профиле: пара последних и переход ко всем
struct NotesPreviewSection: View {
    @ObservedObject private var store = NotesStore.shared

    var body: some View {
        Section {
            NavigationLink {
                NotesView()
            } label: {
                HStack {
                    Label("Все заметки", systemImage: "note.text")
                    Spacer()
                    Text("\(store.notes.count)").foregroundStyle(.secondary)
                }
            }
            ForEach(store.sorted.prefix(3)) { n in
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 5) {
                        if n.pinned { Image(systemName: "pin.fill").font(.caption2).foregroundStyle(Color.brand) }
                        Text(n.displayTitle).font(.subheadline.weight(.semibold)).lineLimit(1)
                    }
                    if !n.preview.isEmpty {
                        Text(n.preview).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                }
            }
        } header: {
            Text("Заметки")
        }
    }
}
