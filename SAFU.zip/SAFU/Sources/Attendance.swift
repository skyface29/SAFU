import SwiftUI
import UIKit

// MARK: - Модель посещаемости

enum Mark: String, Codable, CaseIterable {
    case present, late, absent, excused

    var symbol: String {
        switch self {
        case .present: return "+"
        case .late: return "О"
        case .absent: return "−"
        case .excused: return "У"
        }
    }

    var title: String {
        switch self {
        case .present: return "Был"
        case .late: return "Опозд."
        case .absent: return "Н/б"
        case .excused: return "Уваж."
        }
    }

    var color: Color {
        switch self {
        case .present: return Color(red: 0.16, green: 0.75, blue: 0.42)
        case .late: return Color(red: 0.36, green: 0.52, blue: 1.0)
        case .absent: return Color(red: 0.95, green: 0.28, blue: 0.30)
        case .excused: return Color(red: 1.0, green: 0.62, blue: 0.10)
        }
    }

    /// Опоздавший на паре был — в процент посещаемости идёт как присутствие
    var attended: Bool { self == .present || self == .late }
}

/// Справка или больничный: на все пары этого периода студент сам получает «У»
struct Excuse: Identifiable, Codable, Hashable {
    var id = UUID()
    var studentID: UUID
    var from: Date
    var to: Date
    var reason: String

    func covers(_ d: Date) -> Bool {
        let cal = Calendar.current
        let a = cal.startOfDay(for: from)
        let b = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: to)) ?? to
        return d >= a && d < b
    }
}

struct Student: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
}

struct AttendanceLesson: Codable, Hashable, Identifiable {
    var key: String
    var subject: String
    var kind: String
    var start: Date
    var id: String { key }
}

private struct AttendanceData: Codable {
    var students: [Student] = []
    var marks: [String: [String: Mark]] = [:]        // занятие → студент → отметка
    var lessons: [String: AttendanceLesson] = [:]
    var excuses: [Excuse] = []
    var edited: [String: Date] = [:]                // занятие → когда отметки меняли (для обмена с замом)

    init(students: [Student], marks: [String: [String: Mark]], lessons: [String: AttendanceLesson],
         excuses: [Excuse], edited: [String: Date]) {
        self.students = students
        self.marks = marks
        self.lessons = lessons
        self.excuses = excuses
        self.edited = edited
    }

    // старые версии не знали справок и времени правки — читаем их данные без потерь
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        students = try c.decodeIfPresent([Student].self, forKey: .students) ?? []
        marks = try c.decodeIfPresent([String: [String: Mark]].self, forKey: .marks) ?? [:]
        lessons = try c.decodeIfPresent([String: AttendanceLesson].self, forKey: .lessons) ?? [:]
        excuses = try c.decodeIfPresent([Excuse].self, forKey: .excuses) ?? []
        edited = try c.decodeIfPresent([String: Date].self, forKey: .edited) ?? [:]
    }
}

final class AttendanceStore: ObservableObject {
    private let key = "attendance.v1"

    @Published var students: [Student] = [] { didSet { save() } }
    @Published var marks: [String: [String: Mark]] = [:] { didSet { save() } }
    @Published var lessons: [String: AttendanceLesson] = [:] { didSet { save() } }
    @Published var excuses: [Excuse] = [] { didSet { save() } }
    @Published var edited: [String: Date] = [:] { didSet { save() } }
    private var loading = true
    private var saveQueued = false
    private static let saveQueue = DispatchQueue(label: "safu.attendance.save", qos: .utility)

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let d = try? JSONDecoder().decode(AttendanceData.self, from: raw) {
            students = d.students
            marks = d.marks
            lessons = d.lessons
            excuses = d.excuses
            edited = d.edited
        }
        loading = false
    }

    /// Одна отметка меняет сразу три поля, и раньше каждое кодировало весь журнал прямо на главном потоке,
    /// посреди свайпа в перекличке. Теперь — одна запись на проход главного потока, кодирование в фоне.
    private func save() {
        guard !loading, !saveQueued else { return }
        saveQueued = true
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.saveQueued = false
            let d = AttendanceData(students: self.students, marks: self.marks, lessons: self.lessons,
                                   excuses: self.excuses, edited: self.edited)
            let key = self.key
            // очередь последовательная: более старый снимок никогда не перезапишет новый
            AttendanceStore.saveQueue.async {
                if let raw = try? JSONEncoder().encode(d) { UserDefaults.standard.set(raw, forKey: key) }
            }
        }
    }

    /// Есть ли список группы — без создания хранилища (для фоновых напоминаний)
    static var hasRoster: Bool {
        guard let raw = UserDefaults.standard.data(forKey: "attendance.v1"),
              let d = try? JSONDecoder().decode(AttendanceData.self, from: raw) else { return false }
        return !d.students.isEmpty
    }

    static func key(for slot: LessonSlot) -> String {
        "\(Int(slot.start.timeIntervalSince1970))|\(slot.lesson.subject)"
    }

    /// Время начала занятия прямо из ключа — справка работает и для пар, где ещё никого не отмечали
    static func start(of lessonKey: String) -> Date? {
        lessonKey.split(separator: "|").first.flatMap { Double($0) }.map { Date(timeIntervalSince1970: $0) }
    }

    var sortedStudents: [Student] {
        students.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    /// Отметка с учётом справок: если старосты не ставили ничего, а у студента справка — «У»
    func mark(of student: Student, in lessonKey: String) -> Mark? {
        if let m = marks[lessonKey]?[student.id.uuidString] { return m }
        if let d = lessons[lessonKey]?.start ?? AttendanceStore.start(of: lessonKey), excuse(for: student, at: d) != nil {
            return .excused
        }
        return nil
    }

    /// Отметка, поставленная руками (без справок)
    func explicitMark(of student: Student, in lessonKey: String) -> Mark? {
        marks[lessonKey]?[student.id.uuidString]
    }

    func excuse(for student: Student, at date: Date) -> Excuse? {
        excuses.first { $0.studentID == student.id && $0.covers(date) }
    }

    private func touch(_ slot: LessonSlot) -> String {
        let k = AttendanceStore.key(for: slot)
        lessons[k] = AttendanceLesson(key: k, subject: slot.lesson.subject, kind: slot.lesson.kind, start: slot.start)
        edited[k] = Date()
        return k
    }

    func set(_ mark: Mark?, for student: Student, slot: LessonSlot) {
        let k = touch(slot)
        var m = marks[k] ?? [:]
        m[student.id.uuidString] = mark
        marks[k] = m
    }

    /// «Все были»: у кого справка — остаются с «У»
    func markAll(_ mark: Mark?, slot: LessonSlot) {
        let k = touch(slot)
        var m: [String: Mark] = [:]
        if let mark = mark {
            for s in students where excuse(for: s, at: slot.start) == nil { m[s.id.uuidString] = mark }
        }
        marks[k] = m
    }

    /// Последнее занятие до этого, где уже ставили отметки: сначала сегодняшние, потом любые
    func previousLesson(before slot: LessonSlot) -> AttendanceLesson? {
        recordedLessons.first { $0.start < slot.start && $0.key != AttendanceStore.key(for: slot) }
    }

    /// «Как на прошлой паре»: те же люди, что и на прошлом занятии (опоздание переносится как «был»)
    @discardableResult
    func copyPrevious(to slot: LessonSlot) -> AttendanceLesson? {
        guard let prev = previousLesson(before: slot), let src = marks[prev.key] else { return nil }
        let k = touch(slot)
        var m: [String: Mark] = [:]
        for s in students {
            if excuse(for: s, at: slot.start) != nil { continue }
            guard let old = src[s.id.uuidString] else { continue }
            m[s.id.uuidString] = old == .late ? .present : old
        }
        marks[k] = m
        return prev
    }

    func addExcuse(_ e: Excuse) { excuses.append(e) }
    func removeExcuse(_ e: Excuse) { excuses.removeAll { $0.id == e.id } }

    func add(names: [String]) {
        let existing = Set(students.map { $0.name.lowercased() })
        let fresh = names
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && !existing.contains($0.lowercased()) }
        students.append(contentsOf: fresh.map { Student(name: $0) })
    }

    func remove(_ s: Student) {
        students.removeAll { $0.id == s.id }
        excuses.removeAll { $0.studentID == s.id }
    }

    struct Stats {
        var present = 0, late = 0, absent = 0, excused = 0
        var total: Int { present + late + absent + excused }
        /// Процент посещаемости: был, опоздал и уважительная не считаются прогулом
        var percent: Int? {
            total == 0 ? nil : Int((Double(present + late + excused) / Double(total) * 100).rounded())
        }
    }

    func stats(for s: Student, subject: String? = nil, in range: Range<Date>? = nil) -> Stats {
        var st = Stats()
        for (k, m) in marks where !m.isEmpty {
            let l = lessons[k]
            if let subject = subject, l?.subject != subject { continue }
            if let range = range, let d = l?.start ?? AttendanceStore.start(of: k), !range.contains(d) { continue }
            switch mark(of: s, in: k) {
            case .present?: st.present += 1
            case .late?: st.late += 1
            case .absent?: st.absent += 1
            case .excused?: st.excused += 1
            case nil: break
            }
        }
        return st
    }

    var recordedLessons: [AttendanceLesson] {
        lessons.values.filter { !(marks[$0.key] ?? [:]).isEmpty }.sorted { $0.start > $1.start }
    }

    /// Текст отчёта по занятию — чтобы отправить старосте/преподавателю: ФИО столбиком по каждой отметке
    func report(for slot: LessonSlot) -> String {
        let k = AttendanceStore.key(for: slot)
        let f = Fmt.formatter("d MMMM, H:mm")
        let list = sortedStudents
        func names(_ m: Mark) -> [String] { list.filter { mark(of: $0, in: k) == m }.map(\.name) }
        func block(_ title: String, _ n: [String]) -> String {
            (["\(title) (\(n.count)):"] + n.enumerated().map { "\($0.offset + 1). \($0.element)" }).joined(separator: "\n")
        }
        let present = names(.present), late = names(.late), absent = names(.absent), excused = names(.excused)
        let unmarked = list.count - present.count - late.count - absent.count - excused.count
        var parts = ["\(slot.lesson.subject) (\(KindStyle.of(slot.lesson.kind).label.lowercased())), \(f.string(from: slot.start))\n"
                     + "На паре: \(present.count + late.count) из \(list.count)"]
        if !present.isEmpty { parts.append(block("Присутствуют", present)) }
        if !late.isEmpty { parts.append(block("Опоздали", late)) }
        parts.append(absent.isEmpty ? "Отсутствующих нет" : block("Отсутствуют", absent))
        if !excused.isEmpty { parts.append(block("По уважительной", excused)) }
        if unmarked > 0 { parts.append("Не отмечены: \(unmarked)") }
        return parts.joined(separator: "\n\n")
    }

    /// Таблица для Excel/Numbers: строки — студенты, столбцы — занятия
    func csv() -> String {
        let f = Fmt.formatter("dd.MM HH:mm")
        let ls = lessons.values.sorted { $0.start < $1.start }
        func q(_ s: String) -> String { "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        var header: [String] = ["Студент"]
        for l in ls { header.append("\(f.string(from: l.start)) \(l.subject)") }
        header.append("Пропуски")
        header.append("Опозд.")
        header.append("Уваж.")
        var rows: [String] = [header.map { q($0) }.joined(separator: ";")]
        for s in sortedStudents {
            var cells = [q(s.name)]
            for l in ls { cells.append(q(mark(of: s, in: l.key)?.symbol ?? "")) }
            let st = stats(for: s)
            cells.append(q("\(st.absent)"))
            cells.append(q("\(st.late)"))
            cells.append(q("\(st.excused)"))
            rows.append(cells.joined(separator: ";"))
        }
        return rows.joined(separator: "\n")
    }
}

// MARK: - Экран отметок

struct AttendanceView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var selected: LessonSlot?
    @State private var showRoster = false
    @State private var showStats = false
    @State private var showMonth = false
    @State private var showExcuses = false
    @State private var showExchange = false
    @State private var showSite = false
    @State private var rollCall: LessonSlot?
    @State private var share: ShareItem?
    @State private var copiedFrom: String?
    @AppStorage("att.remind") private var remind = true
    @AppStorage("user.role") private var role = 0
    let initial: LessonSlot?

    init(slot: LessonSlot? = nil) {
        initial = slot
    }

    /// Занятия за последние 7 дней и сегодняшние
    private var recent: [LessonSlot] {
        ScheduleQuery.slots(schedule.data, from: -7, days: 8)
            .filter { $0.start <= Date().addingTimeInterval(3 * 3600) }
            .sorted { $0.start > $1.start }
    }

    private var current: LessonSlot? { selected ?? initial ?? recent.first }

    var body: some View {
        List {
            if attendance.students.isEmpty {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Сначала добавь группу", systemImage: "person.3.fill")
                            .font(.headline)
                        Text("Один раз внеси список ребят — можно вставить сразу всех, по одному в строке. Или загрузи файл с отметками от старосты или зама.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        HStack(spacing: 18) {
                            Button { showRoster = true } label: {
                                Label("Добавить студентов", systemImage: "plus")
                            }
                            Button { showExchange = true } label: {
                                Label("Из файла", systemImage: "tray.and.arrow.down")
                            }
                        }
                        .buttonStyle(.borderless)
                        .font(.subheadline.weight(.bold))
                    }
                    .padding(.vertical, 6)
                }
            }

            Section("Занятие") {
                if recent.isEmpty && initial == nil {
                    Text("Нет занятий за последнюю неделю").foregroundStyle(.secondary)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(lessonChoices, id: \.key) { s in
                            let isOn = current?.key == s.key
                            Button { selected = s; copiedFrom = nil } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack(spacing: 4) {
                                        Circle().fill(KindStyle.of(s.lesson.kind).color).frame(width: 7, height: 7)
                                        Text(shortDate(s.start)).font(.caption2.weight(.bold))
                                        Spacer(minLength: 0)
                                        if !(attendance.marks[AttendanceStore.key(for: s)] ?? [:]).isEmpty {
                                            Image(systemName: "checkmark.circle.fill").font(.caption2)
                                        }
                                    }
                                    Text(s.lesson.subject).font(.caption.weight(.semibold)).lineLimit(1)
                                }
                                .foregroundStyle(isOn ? Color.white : Color.primary)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 8)
                                .frame(width: 150, alignment: .leading)
                                .background(isOn ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.07)),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
            }

            if let slot = current, !attendance.students.isEmpty {
                let k = AttendanceStore.key(for: slot)
                Section {
                    summary(k)
                    Button { rollCall = slot } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "hand.draw.fill")
                                .font(.title3)
                            VStack(alignment: .leading, spacing: 1) {
                                Text("Перекличка свайпами").font(.headline)
                                Text("вправо — был, влево — нет, вверх — уважит., вниз — опоздал")
                                    .font(.caption)
                                    .opacity(0.85)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.subheadline.weight(.bold))
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 12)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .listRowInsets(EdgeInsets(top: 6, leading: 12, bottom: 6, trailing: 12))
                    HStack(spacing: 10) {
                        Button { Haptics.success(); attendance.markAll(.present, slot: slot) } label: {
                            Label("Все были", systemImage: "checkmark.circle.fill")
                        }
                        .buttonStyle(.borderless)
                        Spacer()
                        if attendance.previousLesson(before: slot) != nil {
                            Button {
                                Haptics.success()
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                                    if let p = attendance.copyPrevious(to: slot) { copiedFrom = p.subject + ", " + shortDate(p.start) }
                                }
                            } label: {
                                Label("Как на прошлой", systemImage: "arrow.uturn.backward.circle.fill")
                            }
                            .buttonStyle(.borderless)
                            Spacer()
                        }
                        Button(role: .destructive) { attendance.markAll(nil, slot: slot); copiedFrom = nil } label: {
                            Image(systemName: "arrow.counterclockwise")
                        }
                        .buttonStyle(.borderless)
                    }
                    .font(.subheadline.weight(.semibold))
                    if let c = copiedFrom {
                        Text("Скопировано с занятия: \(c). Поправь тех, кто ушёл или пришёл.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("\(slot.lesson.subject) · \(KindStyle.of(slot.lesson.kind).label)")
                }

                Section {
                    ForEach(attendance.sortedStudents) { st in
                        row(st, slot: slot, key: k)
                    }
                } footer: {
                    Text("+ был, О опоздал, − не было, У уважительная. Повторное нажатие снимает отметку. У кого справка на эти дни — «У» стоит сама.")
                }

                Section {
                    Button { shareImage(slot) } label: {
                        Label("Отправить отчёт картинкой", systemImage: "photo.on.rectangle.angled")
                    }
                    ShareLink(item: attendance.report(for: slot)) {
                        Label("Отправить текстом", systemImage: "text.alignleft")
                    }
                }
            }

            Section {
                Button { showSite = true } label: {
                    menuRow("Сайт старост: общие отметки", "globe", .teal, UserDefaults.standard.string(forKey: "otmetki.code")?.isEmpty == false ? "подключён" : nil)
                }
            } footer: {
                Text("Подключи группу с arktika-app.ru/otmetki по коду: отметки станут общими с сайтом, замом, куратором и студентами. Там же отметки «опоздал» и «перезачёт».")
            }

            if !attendance.students.isEmpty {
                Section {
                    Button { showExcuses = true } label: {
                        menuRow("Справки и больничные", "cross.case.fill", .orange,
                                attendance.excuses.isEmpty ? nil : "\(attendance.excuses.count)")
                    }
                    Button { showMonth = true } label: {
                        menuRow("Рапортичка за месяц", "doc.richtext.fill", .red, nil)
                    }
                    Button { showExchange = true } label: {
                        menuRow("Обмен отметками со старостой", "arrow.left.arrow.right.circle.fill", .blue, nil)
                    }
                    if role == 1 || role == 2 {
                        Toggle(isOn: $remind) {
                            menuRow("Напоминать отметить", "bell.badge.fill", .purple, nil)
                        }
                        .onChange(of: remind) { _ in AttendanceReminder.schedule(data: schedule.data) }
                    }
                } header: {
                    Text("Старосте и заму")
                } footer: {
                    if role == 1 || role == 2 {
                        Text("Через 10 минут после начала пары придёт уведомление — нажми, и откроется перекличка.")
                    }
                }
            }
        }
        .navigationTitle("Посещаемость")
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Menu {
                    Button { showRoster = true } label: { Label("Список группы", systemImage: "person.3") }
                    Button { showStats = true } label: { Label("Статистика и таблица", systemImage: "chart.bar") }
                    Button { showMonth = true } label: { Label("Рапортичка за месяц", systemImage: "doc.richtext") }
                    Button { showExcuses = true } label: { Label("Справки", systemImage: "cross.case") }
                    Button { showExchange = true } label: { Label("Обмен отметками", systemImage: "arrow.left.arrow.right") }
                    Button { showSite = true } label: { Label("Сайт старост", systemImage: "globe") }
                } label: {
                    Image(systemName: "person.3.fill")
                }
            }
        }
        .sheet(isPresented: $showRoster) {
            NavigationStack { RosterView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showStats) {
            NavigationStack { AttendanceStatsView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showMonth) {
            NavigationStack { AttendanceMonthView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showExcuses) {
            NavigationStack { ExcusesView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showExchange) {
            NavigationStack { AttendanceExchangeView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showSite) {
            NavigationStack { SiteAttendanceView() }
        }
        .sheet(item: $share) { ShareSheet(items: $0.items) }
        .fullScreenCover(item: Binding(get: { rollCall.map { RollCallTarget(slot: $0) } }, set: { rollCall = $0?.slot })) { t in
            RollCallView(slot: t.slot).environmentObject(attendance)
        }
    }

    private func menuRow(_ title: String, _ icon: String, _ color: Color, _ badge: String?) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 28, height: 28)
                .background(color.gradient, in: RoundedRectangle(cornerRadius: 7, style: .continuous))
            Text(title).foregroundStyle(.primary)
            Spacer()
            if let badge { Text(badge).foregroundStyle(.secondary) }
        }
    }

    @MainActor
    private func shareImage(_ slot: LessonSlot) {
        Haptics.tap()
        if let img = AttendanceShareCard.render(slot: slot, store: attendance) {
            share = ShareItem(items: [img])
        } else {
            share = ShareItem(items: [attendance.report(for: slot)])
        }
    }

    private var lessonChoices: [LessonSlot] {
        var list = recent
        if let i = initial, !list.contains(where: { $0.key == i.key }) { list.insert(i, at: 0) }
        return list
    }

    private func shortDate(_ d: Date) -> String {
        Fmt.formatter(Calendar.current.isDateInToday(d) ? "'сегодня' H:mm" : "EE d MMM, H:mm").string(from: d)
    }

    private func summary(_ k: String) -> some View {
        let list = attendance.students
        let p = list.filter { attendance.mark(of: $0, in: k) == .present }.count
        let l = list.filter { attendance.mark(of: $0, in: k) == .late }.count
        let a = list.filter { attendance.mark(of: $0, in: k) == .absent }.count
        let e = list.filter { attendance.mark(of: $0, in: k) == .excused }.count
        let none = list.count - p - l - a - e
        return HStack(spacing: 6) {
            pill("\(p)", "был", Mark.present.color)
            pill("\(l)", "опозд.", Mark.late.color)
            pill("\(a)", "н/б", Mark.absent.color)
            pill("\(e)", "уваж.", Mark.excused.color)
            pill("\(none)", "не отм.", .gray)
        }
    }

    private func pill(_ n: String, _ t: String, _ c: Color) -> some View {
        VStack(spacing: 1) {
            Text(n).font(.system(.headline, design: .rounded).weight(.bold)).foregroundStyle(c)
                .contentTransition(.numericText())
            Text(t).font(.caption2).foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.8)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(c.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func row(_ st: Student, slot: LessonSlot, key: String) -> some View {
        let current = attendance.mark(of: st, in: key)
        let explicit = attendance.explicitMark(of: st, in: key)
        let note = explicit == nil ? attendance.excuse(for: st, at: slot.start) : nil
        return HStack(spacing: 6) {
            VStack(alignment: .leading, spacing: 1) {
                Text(st.name)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                if let note {
                    Text("справка" + (note.reason.isEmpty ? "" : ": \(note.reason)"))
                        .font(.caption2)
                        .foregroundStyle(Mark.excused.color)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            ForEach(Mark.allCases, id: \.self) { m in
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.7)) {
                        attendance.set(explicit == m ? nil : m, for: st, slot: slot)
                    }
                } label: {
                    Text(m.symbol)
                        .font(.system(.subheadline, design: .rounded).weight(.heavy))
                        .foregroundStyle(current == m ? Color.white : m.color)
                        .frame(width: 33, height: 32)
                        .background(current == m ? m.color : m.color.opacity(0.12),
                                    in: RoundedRectangle(cornerRadius: 9, style: .continuous))
                        .scaleEffect(current == m ? 1.05 : 1)
                }
                .buttonStyle(.borderless)
            }
        }
        .listRowBackground(current.map { $0.color.opacity(0.08) })
    }
}

/// Пара для полноэкранной переклички
struct RollCallTarget: Identifiable {
    let slot: LessonSlot
    var id: String { slot.key }
}

// MARK: - Список группы

struct RosterView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var newName = ""
    @State private var bulk = ""
    @State private var showBulk = false

    var body: some View {
        List {
            Section {
                HStack {
                    TextField("Фамилия Имя", text: $newName)
                        .textInputAutocapitalization(.words)
                        .onSubmit(addOne)
                    Button("Добавить", action: addOne)
                        .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                Button { showBulk.toggle() } label: {
                    Label("Вставить список целиком", systemImage: "list.bullet.clipboard")
                }
                if showBulk {
                    TextEditor(text: $bulk)
                        .frame(minHeight: 140)
                    Button {
                        attendance.add(names: bulk.components(separatedBy: .newlines))
                        bulk = ""
                        showBulk = false
                        Haptics.success()
                    } label: {
                        Label("Добавить всех", systemImage: "person.3.sequence.fill")
                    }
                    .disabled(bulk.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            } footer: {
                Text("В режиме списка — по одному человеку в строке. Можно скопировать список из беседы группы.")
            }

            Section("Группа (\(attendance.students.count))") {
                ForEach(attendance.sortedStudents) { s in
                    Text(s.name)
                }
                .onDelete { idx in
                    let list = attendance.sortedStudents
                    for i in idx { attendance.remove(list[i]) }
                }
            }
        }
        .navigationTitle("Список группы")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
        }
    }

    private func addOne() {
        attendance.add(names: [newName])
        newName = ""
        Haptics.tap()
    }
}

// MARK: - Статистика

struct AttendanceStatsView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: String = ""
    @State private var csvURL: URL?

    private var subjects: [String] {
        Array(Set(attendance.lessons.values.map(\.subject))).sorted()
    }

    var body: some View {
        List {
            Section {
                Picker("Предмет", selection: $subject) {
                    Text("Все предметы").tag("")
                    ForEach(subjects, id: \.self) { Text($0).tag($0) }
                }
                Text("Отмечено занятий: \(attendance.recordedLessons.filter { subject.isEmpty || $0.subject == subject }.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Студенты") {
                ForEach(attendance.sortedStudents) { s in
                    let st = attendance.stats(for: s, subject: subject.isEmpty ? nil : subject)
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(s.name).font(.subheadline.weight(.semibold))
                            Text("был \(st.present) · опозд. \(st.late) · н/б \(st.absent) · уваж. \(st.excused)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if let pct = st.percent {
                            Text("\(pct)%")
                                .font(.system(.headline, design: .rounded).weight(.bold))
                                .foregroundStyle(pct >= 80 ? Mark.present.color : (pct >= 60 ? Mark.excused.color : Mark.absent.color))
                        }
                    }
                }
            }

            Section {
                Button { exportCSV() } label: { Label("Сделать таблицу (CSV для Excel)", systemImage: "tablecells") }
                if let u = csvURL {
                    ShareLink(item: u) { Label("Отправить таблицу", systemImage: "square.and.arrow.up") }
                }
            } footer: {
                Text("Таблица сохраняется в «Файлы › Отчёты» и открывается в Excel, Numbers или Р7.")
            }
        }
        .navigationTitle("Статистика")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
        }
    }

    private func exportCSV() {
        let dir = FileService.root.appendingPathComponent("Отчёты", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("Посещаемость.csv")
        // BOM, чтобы Excel правильно открыл кириллицу
        let data = Data([0xEF, 0xBB, 0xBF]) + Data(attendance.csv().utf8)
        try? data.write(to: url)
        csvURL = url
        Haptics.success()
    }
}
