import SwiftUI
import UIKit

// MARK: - Модель посещаемости

enum Mark: String, Codable, CaseIterable {
    case present, absent, excused

    var symbol: String {
        switch self {
        case .present: return "+"
        case .absent: return "−"
        case .excused: return "У"
        }
    }

    var title: String {
        switch self {
        case .present: return "Был"
        case .absent: return "Н/б"
        case .excused: return "Уваж."
        }
    }

    var color: Color {
        switch self {
        case .present: return Color(red: 0.16, green: 0.75, blue: 0.42)
        case .absent: return Color(red: 0.95, green: 0.28, blue: 0.30)
        case .excused: return Color(red: 1.0, green: 0.62, blue: 0.10)
        }
    }
}

struct Student: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
}

struct AttendanceLesson: Codable, Hashable, Identifiable {
    var key: String
    var subject: String
    var kind: String
    var start: Date
    var id: String { key }
}

private struct AttendanceData: Codable {
    var students: [Student] = []
    var marks: [String: [String: Mark]] = [:]        // занятие → студент → отметка
    var lessons: [String: AttendanceLesson] = [:]
}

final class AttendanceStore: ObservableObject {
    private let key = "attendance.v1"

    @Published var students: [Student] = [] { didSet { save() } }
    @Published var marks: [String: [String: Mark]] = [:] { didSet { save() } }
    @Published var lessons: [String: AttendanceLesson] = [:] { didSet { save() } }
    private var loading = true

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let d = try? JSONDecoder().decode(AttendanceData.self, from: raw) {
            students = d.students
            marks = d.marks
            lessons = d.lessons
        }
        loading = false
    }

    private func save() {
        guard !loading else { return }
        let d = AttendanceData(students: students, marks: marks, lessons: lessons)
        if let raw = try? JSONEncoder().encode(d) { UserDefaults.standard.set(raw, forKey: key) }
    }

    static func key(for slot: LessonSlot) -> String {
        "\(Int(slot.start.timeIntervalSince1970))|\(slot.lesson.subject)"
    }

    var sortedStudents: [Student] {
        students.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    func mark(of student: Student, in lessonKey: String) -> Mark? {
        marks[lessonKey]?[student.id.uuidString]
    }

    func set(_ mark: Mark?, for student: Student, slot: LessonSlot) {
        let k = AttendanceStore.key(for: slot)
        lessons[k] = AttendanceLesson(key: k, subject: slot.lesson.subject, kind: slot.lesson.kind, start: slot.start)
        var m = marks[k] ?? [:]
        m[student.id.uuidString] = mark
        marks[k] = m
    }

    func markAll(_ mark: Mark?, slot: LessonSlot) {
        let k = AttendanceStore.key(for: slot)
        lessons[k] = AttendanceLesson(key: k, subject: slot.lesson.subject, kind: slot.lesson.kind, start: slot.start)
        var m: [String: Mark] = [:]
        if let mark = mark {
            for s in students { m[s.id.uuidString] = mark }
        }
        marks[k] = m
    }

    func add(names: [String]) {
        let existing = Set(students.map { $0.name.lowercased() })
        let fresh = names
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && !existing.contains($0.lowercased()) }
        students.append(contentsOf: fresh.map { Student(name: $0) })
    }

    func remove(_ s: Student) {
        students.removeAll { $0.id == s.id }
    }

    func stats(for s: Student, subject: String? = nil) -> (present: Int, absent: Int, excused: Int) {
        var p = 0, a = 0, e = 0
        for (k, m) in marks {
            if let subject = subject, lessons[k]?.subject != subject { continue }
            switch m[s.id.uuidString] {
            case .present?: p += 1
            case .absent?: a += 1
            case .excused?: e += 1
            case nil: break
            }
        }
        return (p, a, e)
    }

    var recordedLessons: [AttendanceLesson] {
        lessons.values.filter { !(marks[$0.key] ?? [:]).isEmpty }.sorted { $0.start > $1.start }
    }

    /// Текст отчёта по занятию — чтобы отправить старосте/преподавателю
    func report(for slot: LessonSlot) -> String {
        let k = AttendanceStore.key(for: slot)
        let f = Fmt.formatter("d MMMM, H:mm")
        let list = sortedStudents
        let absent = list.filter { mark(of: $0, in: k) == .absent }.map(\.name)
        let excused = list.filter { mark(of: $0, in: k) == .excused }.map(\.name)
        let present = list.filter { mark(of: $0, in: k) == .present }.count
        var lines = ["\(slot.lesson.subject) (\(KindStyle.of(slot.lesson.kind).label.lowercased())), \(f.string(from: slot.start))",
                     "Присутствуют: \(present) из \(list.count)"]
        lines.append(absent.isEmpty ? "Отсутствующих нет" : "Отсутствуют (\(absent.count)): " + absent.joined(separator: ", "))
        if !excused.isEmpty { lines.append("По уважительной (\(excused.count)): " + excused.joined(separator: ", ")) }
        return lines.joined(separator: "\n")
    }

    /// Таблица для Excel/Numbers: строки — студенты, столбцы — занятия
    func csv() -> String {
        let f = Fmt.formatter("dd.MM HH:mm")
        let ls = lessons.values.sorted { $0.start < $1.start }
        func q(_ s: String) -> String { "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        var header: [String] = ["Студент"]
        for l in ls { header.append("\(f.string(from: l.start)) \(l.subject)") }
        header.append("Пропуски")
        header.append("Уваж.")
        var rows: [String] = [header.map { q($0) }.joined(separator: ";")]
        for s in sortedStudents {
            var cells = [q(s.name)]
            for l in ls { cells.append(q(mark(of: s, in: l.key)?.symbol ?? "")) }
            let st = stats(for: s)
            cells.append(q("\(st.absent)"))
            cells.append(q("\(st.excused)"))
            rows.append(cells.joined(separator: ";"))
        }
        return rows.joined(separator: "\n")
    }
}

// MARK: - Экран отметок

struct AttendanceView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @State private var selected: LessonSlot?
    @State private var showRoster = false
    @State private var showStats = false
    let initial: LessonSlot?

    init(slot: LessonSlot? = nil) {
        initial = slot
    }

    /// Занятия за последние 7 дней и сегодняшние
    private var recent: [LessonSlot] {
        ScheduleQuery.slots(schedule.data, from: -7, days: 8)
            .filter { $0.start <= Date().addingTimeInterval(3 * 3600) }
            .sorted { $0.start > $1.start }
    }

    private var current: LessonSlot? { selected ?? initial ?? recent.first }

    var body: some View {
        List {
            if attendance.students.isEmpty {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("Сначала добавь группу", systemImage: "person.3.fill")
                            .font(.headline)
                        Text("Один раз внеси список ребят — можно вставить сразу всех, по одному в строке.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                        Button { showRoster = true } label: {
                            Label("Добавить студентов", systemImage: "plus")
                                .font(.subheadline.weight(.bold))
                        }
                    }
                    .padding(.vertical, 6)
                }
            }

            Section("Занятие") {
                if recent.isEmpty && initial == nil {
                    Text("Нет занятий за последнюю неделю").foregroundStyle(.secondary)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(lessonChoices, id: \.key) { s in
                            let isOn = current?.key == s.key
                            Button { selected = s } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    HStack(spacing: 4) {
                                        Circle().fill(KindStyle.of(s.lesson.kind).color).frame(width: 7, height: 7)
                                        Text(shortDate(s.start)).font(.caption2.weight(.bold))
                                    }
                                    Text(s.lesson.subject).font(.caption.weight(.semibold)).lineLimit(1)
                                }
                                .foregroundStyle(isOn ? Color.white : Color.primary)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 8)
                                .frame(width: 150, alignment: .leading)
                                .background(isOn ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary.opacity(0.07)),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12))
            }

            if let slot = current, !attendance.students.isEmpty {
                let k = AttendanceStore.key(for: slot)
                Section {
                    summary(k)
                    HStack(spacing: 10) {
                        Button { Haptics.success(); attendance.markAll(.present, slot: slot) } label: {
                            Label("Все были", systemImage: "checkmark.circle.fill")
                        }
                        .buttonStyle(.borderless)
                        Spacer()
                        Button(role: .destructive) { attendance.markAll(nil, slot: slot) } label: {
                            Label("Сбросить", systemImage: "arrow.counterclockwise")
                        }
                        .buttonStyle(.borderless)
                    }
                    .font(.subheadline.weight(.semibold))
                } header: {
                    Text("\(slot.lesson.subject) · \(KindStyle.of(slot.lesson.kind).label)")
                }

                Section {
                    ForEach(attendance.sortedStudents) { st in
                        row(st, slot: slot, key: k)
                    }
                } footer: {
                    Text("Нажимай + (был), − (не было) или У (уважительная). Повторное нажатие снимает отметку.")
                }

                Section {
                    ShareLink(item: attendance.report(for: slot)) {
                        Label("Отправить отчёт по занятию", systemImage: "square.and.arrow.up")
                    }
                }
            }
        }
        .navigationTitle("Посещаемость")
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Menu {
                    Button { showRoster = true } label: { Label("Список группы", systemImage: "person.3") }
                    Button { showStats = true } label: { Label("Статистика и таблица", systemImage: "chart.bar") }
                } label: {
                    Image(systemName: "person.3.fill")
                }
            }
        }
        .sheet(isPresented: $showRoster) {
            NavigationStack { RosterView() }.environmentObject(attendance)
        }
        .sheet(isPresented: $showStats) {
            NavigationStack { AttendanceStatsView() }.environmentObject(attendance)
        }
    }

    private var lessonChoices: [LessonSlot] {
        var list = recent
        if let i = initial, !list.contains(where: { $0.key == i.key }) { list.insert(i, at: 0) }
        return list
    }

    private func shortDate(_ d: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = Calendar.current.isDateInToday(d) ? "'сегодня' H:mm" : "EE d MMM, H:mm"
        return f.string(from: d)
    }

    private func summary(_ k: String) -> some View {
        let list = attendance.students
        let p = list.filter { attendance.mark(of: $0, in: k) == .present }.count
        let a = list.filter { attendance.mark(of: $0, in: k) == .absent }.count
        let e = list.filter { attendance.mark(of: $0, in: k) == .excused }.count
        let none = list.count - p - a - e
        return HStack(spacing: 8) {
            pill("\(p)", "был", Mark.present.color)
            pill("\(a)", "н/б", Mark.absent.color)
            pill("\(e)", "уваж.", Mark.excused.color)
            pill("\(none)", "не отм.", .gray)
        }
    }

    private func pill(_ n: String, _ t: String, _ c: Color) -> some View {
        VStack(spacing: 1) {
            Text(n).font(.system(.headline, design: .rounded).weight(.bold)).foregroundStyle(c)
            Text(t).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(c.opacity(0.12), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func row(_ st: Student, slot: LessonSlot, key: String) -> some View {
        let current = attendance.mark(of: st, in: key)
        return HStack(spacing: 8) {
            Text(st.name)
                .font(.subheadline.weight(.semibold))
                .lineLimit(1)
                .frame(maxWidth: .infinity, alignment: .leading)
            ForEach(Mark.allCases, id: \.self) { m in
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.7)) {
                        attendance.set(current == m ? nil : m, for: st, slot: slot)
                    }
                } label: {
                    Text(m.symbol)
                        .font(.system(.headline, design: .rounded).weight(.heavy))
                        .foregroundStyle(current == m ? Color.white : m.color)
                        .frame(width: 38, height: 34)
                        .background(current == m ? m.color : m.color.opacity(0.12),
                                    in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .scaleEffect(current == m ? 1.05 : 1)
                }
                .buttonStyle(.borderless)
            }
        }
        .listRowBackground(current.map { $0.color.opacity(0.08) })
    }
}

// MARK: - Список группы

struct RosterView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var newName = ""
    @State private var bulk = ""
    @State private var showBulk = false

    var body: some View {
        List {
            Section {
                HStack {
                    TextField("Фамилия Имя", text: $newName)
                        .textInputAutocapitalization(.words)
                        .onSubmit(addOne)
                    Button("Добавить", action: addOne)
                        .disabled(newName.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                Button { showBulk.toggle() } label: {
                    Label("Вставить список целиком", systemImage: "list.bullet.clipboard")
                }
                if showBulk {
                    TextEditor(text: $bulk)
                        .frame(minHeight: 140)
                    Button {
                        attendance.add(names: bulk.components(separatedBy: .newlines))
                        bulk = ""
                        showBulk = false
                        Haptics.success()
                    } label: {
                        Label("Добавить всех", systemImage: "person.3.sequence.fill")
                    }
                    .disabled(bulk.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            } footer: {
                Text("В режиме списка — по одному человеку в строке. Можно скопировать список из беседы группы.")
            }

            Section("Группа (\(attendance.students.count))") {
                ForEach(attendance.sortedStudents) { s in
                    Text(s.name)
                }
                .onDelete { idx in
                    let list = attendance.sortedStudents
                    for i in idx { attendance.remove(list[i]) }
                }
            }
        }
        .navigationTitle("Список группы")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
        }
    }

    private func addOne() {
        attendance.add(names: [newName])
        newName = ""
        Haptics.tap()
    }
}

// MARK: - Статистика

struct AttendanceStatsView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: String = ""
    @State private var csvURL: URL?

    private var subjects: [String] {
        Array(Set(attendance.lessons.values.map(\.subject))).sorted()
    }

    var body: some View {
        List {
            Section {
                Picker("Предмет", selection: $subject) {
                    Text("Все предметы").tag("")
                    ForEach(subjects, id: \.self) { Text($0).tag($0) }
                }
                Text("Отмечено занятий: \(attendance.recordedLessons.filter { subject.isEmpty || $0.subject == subject }.count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Студенты") {
                ForEach(attendance.sortedStudents) { s in
                    let st = attendance.stats(for: s, subject: subject.isEmpty ? nil : subject)
                    let total = st.present + st.absent + st.excused
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(s.name).font(.subheadline.weight(.semibold))
                            Text("был \(st.present) · н/б \(st.absent) · уваж. \(st.excused)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        if total > 0 {
                            let pct = Int((Double(st.present + st.excused) / Double(total) * 100).rounded())
                            Text("\(pct)%")
                                .font(.system(.headline, design: .rounded).weight(.bold))
                                .foregroundStyle(pct >= 80 ? Mark.present.color : (pct >= 60 ? Mark.excused.color : Mark.absent.color))
                        }
                    }
                }
            }

            Section {
                Button { exportCSV() } label: { Label("Сделать таблицу (CSV для Excel)", systemImage: "tablecells") }
                if let u = csvURL {
                    ShareLink(item: u) { Label("Отправить таблицу", systemImage: "square.and.arrow.up") }
                }
            } footer: {
                Text("Таблица сохраняется в «Файлы › Отчёты» и открывается в Excel, Numbers или Р7.")
            }
        }
        .navigationTitle("Статистика")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
        }
    }

    private func exportCSV() {
        let dir = FileService.root.appendingPathComponent("Отчёты", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("Посещаемость.csv")
        // BOM, чтобы Excel правильно открыл кириллицу
        let data = Data([0xEF, 0xBB, 0xBF]) + Data(attendance.csv().utf8)
        try? data.write(to: url)
        csvURL = url
        Haptics.success()
    }
}
