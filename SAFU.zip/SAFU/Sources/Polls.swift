import SwiftUI
import UIKit

// MARK: - Опросы группы
// Создаёшь опрос → отправляешь в чат группы → отмечаешь, кто что ответил → итоги и список «не ответили».
// Сервера нет: всё хранится на телефоне, а ребята отвечают в привычном чате.

struct GroupPoll: Codable, Identifiable, Hashable {
    var id = UUID()
    var question: String
    var options: [String]
    var created = Date()
    /// id студента → номер варианта
    var answers: [String: Int] = [:]
    var closed = false
}

final class PollStore: ObservableObject {
    static let shared = PollStore()
    @Published var polls: [GroupPoll] = [] { didSet { save() } }
    private let key = "polls.v1"

    private init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let v = try? JSONDecoder().decode([GroupPoll].self, from: raw) { polls = v }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(polls) { UserDefaults.standard.set(raw, forKey: key) }
    }
}

enum PollText {
    static let marks = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣"]

    static func invite(_ p: GroupPoll) -> String {
        var t = "📊 Опрос: \(p.question)\n\n"
        for (i, o) in p.options.enumerated() { t += "\(marks[min(i, marks.count - 1)]) \(o)\n" }
        t += "\nОтветьте цифрой 🙏"
        return t
    }

    static func results(_ p: GroupPoll, students: [Student]) -> String {
        var t = "📊 Итоги: \(p.question)\n\n"
        for (i, o) in p.options.enumerated() {
            let names = students.filter { p.answers[$0.id.uuidString] == i }.map(\.name)
            t += "\(marks[min(i, marks.count - 1)]) \(o) — \(names.count)"
            if !names.isEmpty { t += ": " + names.joined(separator: ", ") }
            t += "\n"
        }
        let silent = students.filter { p.answers[$0.id.uuidString] == nil }
        if !silent.isEmpty { t += "\nНе ответили: " + silent.map(\.name).joined(separator: ", ") }
        return t
    }

    static func nudge(_ p: GroupPoll, students: [Student]) -> String {
        let silent = students.filter { p.answers[$0.id.uuidString] == nil }.map(\.name)
        return "⏰ Напоминаю про опрос «\(p.question)».\nЕщё не ответили: \(silent.joined(separator: ", "))"
    }
}

// MARK: - Список опросов

struct PollsView: View {
    @ObservedObject private var store = PollStore.shared
    @EnvironmentObject private var attendance: AttendanceStore
    @State private var creating = false

    var body: some View {
        List {
            if attendance.students.isEmpty {
                Section {
                    Label("Сначала добавь список группы в «Посещаемости» — тогда можно отмечать, кто что ответил.",
                          systemImage: "person.3.fill")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }
            Section {
                Button { creating = true } label: {
                    Label("Новый опрос", systemImage: "plus.circle.fill").fontWeight(.semibold)
                }
            }
            ForEach(store.polls.sorted { $0.created > $1.created }) { p in
                NavigationLink {
                    PollDetailView(id: p.id)
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(p.question).font(.headline).lineLimit(2)
                            if p.closed {
                                Text("закрыт").font(.caption2.weight(.bold)).foregroundStyle(.secondary)
                            }
                        }
                        let n = attendance.students.count
                        Text("Ответили \(p.answers.count)\(n > 0 ? " из \(n)" : "") · \(p.created.formatted(.dateTime.day().month()))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        if n > 0 {
                            ProgressView(value: Double(p.answers.count), total: Double(max(n, 1))).tint(Color.brand)
                        }
                    }
                    .padding(.vertical, 2)
                }
                .swipeActions {
                    Button(role: .destructive) { store.polls.removeAll { $0.id == p.id } } label: {
                        Label("Удалить", systemImage: "trash")
                    }
                }
            }
        }
        .navigationTitle("Опросы группы")
        .sheet(isPresented: $creating) {
            NavigationStack { PollEditor() }
        }
    }
}

// MARK: - Новый опрос

struct PollEditor: View {
    @ObservedObject private var store = PollStore.shared
    @Environment(\.dismiss) private var dismiss
    @State private var question = ""
    @State private var options = ["", ""]

    private let templates: [(String, [String])] = [
        ("Кто будет на паре?", ["Буду", "Не буду", "Опоздаю"]),
        ("Удобно перенести пару?", ["Да", "Нет", "Всё равно"]),
        ("Кто сдаёт лабу на этой неделе?", ["Сдаю", "Не готов", "Уже сдал"]),
        ("Скидываемся?", ["Да", "Нет"]),
        ("Во сколько встречаемся?", ["Утром", "Днём", "Вечером"]),
    ]

    private var valid: Bool {
        !question.trimmingCharacters(in: .whitespaces).isEmpty
            && options.filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.count >= 2
    }

    var body: some View {
        Form {
            Section("Вопрос") {
                TextField("О чём спрашиваем", text: $question, axis: .vertical)
            }
            Section {
                ForEach(options.indices, id: \.self) { i in
                    HStack {
                        Text(PollText.marks[min(i, PollText.marks.count - 1)])
                        TextField("Вариант \(i + 1)", text: Binding(get: { i < options.count ? options[i] : "" },
                                                                  set: { if i < options.count { options[i] = $0 } }))
                    }
                }
                .onDelete { idx in if options.count > 2 { options.remove(atOffsets: idx) } }
                if options.count < 8 {
                    Button { options.append("") } label: { Label("Ещё вариант", systemImage: "plus") }
                }
            } header: {
                Text("Варианты")
            }
            Section("Шаблоны") {
                ForEach(templates, id: \.0) { t in
                    Button(t.0) {
                        question = t.0
                        options = t.1
                        Haptics.tap()
                    }
                }
            }
        }
        .navigationTitle("Новый опрос")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Создать") {
                    let opts = options.map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
                    store.polls.append(GroupPoll(question: question.trimmingCharacters(in: .whitespaces), options: opts))
                    Haptics.success()
                    dismiss()
                }
                .fontWeight(.semibold)
                .disabled(!valid)
            }
        }
    }
}

// MARK: - Опрос: отметки и итоги

struct PollDetailView: View {
    let id: UUID
    @ObservedObject private var store = PollStore.shared
    @EnvironmentObject private var attendance: AttendanceStore

    private var index: Int? { store.polls.firstIndex { $0.id == id } }

    var body: some View {
        if let i = index {
            content(i)
        } else {
            Text("Опрос удалён").foregroundStyle(.secondary)
        }
    }

    private func content(_ i: Int) -> some View {
        let p = store.polls[i]
        let students = attendance.sortedStudents
        let total = max(p.answers.count, 1)
        return List {
            Section {
                Text(p.question).font(.system(.title3, design: .rounded).weight(.bold))
                ShareLink(item: PollText.invite(p)) {
                    Label("Отправить в чат группы", systemImage: "paperplane.fill")
                }
            }

            Section("Итоги") {
                ForEach(p.options.indices, id: \.self) { o in
                    let n = p.answers.values.filter { $0 == o }.count
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text("\(PollText.marks[min(o, PollText.marks.count - 1)]) \(p.options[o])")
                            Spacer()
                            Text("\(n) · \(Int(Double(n) / Double(total) * 100))%")
                                .font(.subheadline.weight(.bold)).monospacedDigit()
                        }
                        GeometryReader { g in
                            Capsule().fill(Color.primary.opacity(0.08))
                                .overlay(alignment: .leading) {
                                    Capsule().fill(brandGradient)
                                        .frame(width: max(4, g.size.width * CGFloat(n) / CGFloat(total)))
                                }
                        }
                        .frame(height: 7)
                    }
                    .padding(.vertical, 2)
                }
                ShareLink(item: PollText.results(p, students: students)) {
                    Label("Отправить итоги", systemImage: "chart.bar.doc.horizontal")
                }
                if students.contains(where: { p.answers[$0.id.uuidString] == nil }) {
                    ShareLink(item: PollText.nudge(p, students: students)) {
                        Label("Напомнить тем, кто молчит", systemImage: "bell.badge.fill")
                    }
                }
            }

            Section {
                if students.isEmpty {
                    Text("Список группы пуст — добавь его в «Посещаемости».").foregroundStyle(.secondary)
                }
                ForEach(students) { st in
                    let a = p.answers[st.id.uuidString]
                    Menu {
                        ForEach(p.options.indices, id: \.self) { o in
                            Button {
                                store.polls[i].answers[st.id.uuidString] = o
                                Haptics.tap()
                            } label: {
                                if a == o { Label(p.options[o], systemImage: "checkmark") } else { Text(p.options[o]) }
                            }
                        }
                        if a != nil {
                            Divider()
                            Button("Сбросить", role: .destructive) { store.polls[i].answers[st.id.uuidString] = nil }
                        }
                    } label: {
                        HStack {
                            Text(st.name).foregroundStyle(.primary)
                            Spacer()
                            if let a {
                                Text(p.options[a]).font(.subheadline.weight(.semibold)).foregroundStyle(Color.brand)
                            } else {
                                Text("—").foregroundStyle(.secondary)
                            }
                        }
                    }
                }
            } header: {
                Text("Кто что ответил")
            } footer: {
                Text("Нажми на имя и выбери ответ из чата.")
            }

            Section {
                Toggle("Опрос закрыт", isOn: $store.polls[i].closed)
            }
        }
        .navigationTitle("Опрос")
        .navigationBarTitleDisplayMode(.inline)
    }
}
