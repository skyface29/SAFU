import SwiftUI
import Combine
import CryptoKit
import AVFoundation
import UIKit

// MARK: - Синхронизация с компьютером по домашнему Wi‑Fi
//
// Один раз связываем телефон с Арктикой для Windows: телефон сам находит компьютер в сети, оба показывают
// код, на компьютере нажимают «Разрешить» (PCDiscovery.swift) — или QR-кодом с экрана компьютера.
// В связке — адреса компьютера в домашней сети, номер связки и постоянный ключ. Дальше, пока приложение
// открыто, телефон сам заходит на компьютер каждые несколько секунд и сразу после правок: присылает свои
// ДЗ, задачи и заметки и забирает общую версию. Компьютер сводит их по полям (побеждает поздняя правка),
// поэтому «сделано» на телефоне и новый срок на компьютере сохраняются оба. Ушли из приложения — последний
// обмен в фоне; компьютер сменил адрес в сети — телефон находит его заново по отпечатку связки. Всё зашифровано AES-256-GCM
// ключом из QR, к шифру привязан адрес запроса. Ни облаков, ни своих серверов — только твоя сеть.
// Сведение — на компьютере (windows/src/lib/syncmerge.ts); здесь — те же отметки «что и когда менялось».

/// Ссылка из QR-кода связки: arktika://sync?h=…&p=…&i=…&k=…&n=…
struct SyncLink: Equatable {
    let hosts: [String]
    let port: Int
    let id: String
    let key: Data
    let name: String

    init(hosts: [String], port: Int, id: String, key: Data, name: String) {
        self.hosts = hosts
        self.port = port
        self.id = id
        self.key = key
        self.name = name
    }

    init?(string: String) {
        guard let u = URL(string: string.trimmingCharacters(in: .whitespacesAndNewlines)) else { return nil }
        self.init(url: u)
    }

    init?(url: URL) {
        guard url.scheme?.lowercased() == "arktika", url.host?.lowercased() == "sync",
              let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems else { return nil }
        func value(_ n: String) -> String? { items.first { $0.name == n }?.value }
        guard let h = value("h"), let p = value("p").flatMap({ Int($0) }), (1...65535).contains(p),
              let i = value("i"), !i.isEmpty, i.count < 64,
              let k = value("k"), let key = Data(base64URL: k), key.count == 32 else { return nil }
        // только адреса домашней сети: код с адресом в интернете не уведёт данные наружу
        let list = h.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }.filter(PCLink.isLocal)
        guard !list.isEmpty else { return nil }
        hosts = Array(list.prefix(5))
        port = p
        id = i
        self.key = key
        let n = (value("n") ?? "").replacingOccurrences(of: "+", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        name = n.isEmpty ? "Компьютер" : String(n.prefix(40))
    }
}

extension SyncLink {
    /// Связка, которую компьютер прислал после «Разрешить» (без QR-кода)
    init?(grant j: [String: Any], found: SyncFound) {
        guard let i = j["id"] as? String, !i.isEmpty, i.count < 64,
              let k = j["key"] as? String, let key = Data(base64URL: k), key.count == 32 else { return nil }
        var seen = Set<String>()
        let list = ([found.host] + ((j["hosts"] as? [String]) ?? []).filter(PCLink.isLocal)).filter { seen.insert($0).inserted }
        let p = (j["port"] as? NSNumber)?.intValue ?? found.port
        let n = ((j["name"] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        self.init(hosts: Array(list.prefix(5)), port: (1...65535).contains(p) ? p : found.port, id: i, key: key,
                  name: n.isEmpty ? found.pc : String(n.prefix(40)))
    }
}

/// Связка с компьютером — в связке ключей телефона
struct SyncPairing: Codable, Equatable {
    var hosts: [String]
    var port: Int
    var id: String
    var key: Data
    var name: String
    var paired: Date
}

/// Отметки одной коллекции: у каждого поля — отпечаток значения и когда его меняли (мс); удалённые записи
struct SyncCollState: Codable {
    struct Stamp: Codable { var h: String; var m: Double }
    var stamps: [String: [String: Stamp]] = [:]
    var tomb: [String: Double] = [:]
    var initialized = false
}

// MARK: - Записи ↔ JSON (даты — миллисекунды, как на компьютере)

enum SyncCodec {
    static let encoder: JSONEncoder = {
        let e = JSONEncoder()
        e.dateEncodingStrategy = .custom { date, enc in
            var c = enc.singleValueContainer()
            try c.encode(Int64((date.timeIntervalSince1970 * 1000).rounded()))
        }
        e.outputFormatting = [.sortedKeys]
        return e
    }()

    static let decoder: JSONDecoder = {
        let d = JSONDecoder()
        d.dateDecodingStrategy = .millisecondsSince1970
        return d
    }()

    static func dicts<T: Encodable>(_ items: [T]) -> [[String: Any]] {
        guard let data = try? encoder.encode(items),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr
    }

    /// Короткий отпечаток значения: одинаковое значение — одинаковый отпечаток
    static func fingerprint(_ v: Any) -> String {
        let data = (try? JSONSerialization.data(withJSONObject: [v], options: [.sortedKeys])) ?? Data()
        return SHA256.hash(data: data).prefix(10).map { String(format: "%02x", $0) }.joined()
    }

    /// Запись из JSON компьютера. Недостающие поля — по умолчанию, пустые (null) — тоже
    static func decode<T: Decodable>(_ dict: [String: Any], as type: T.Type, defaults: [String: Any] = [:]) -> T? {
        var d = defaults
        for (k, v) in dict where !(v is NSNull) { d[k] = v }
        guard let data = try? JSONSerialization.data(withJSONObject: d) else { return nil }
        return try? decoder.decode(T.self, from: data)
    }
}

// MARK: - Отметки «что и когда менялось» (так же, как на компьютере)

enum SyncStamps {
    /// Фото ДЗ — файлы на своём устройстве, их не синхронизируем
    static let localOnly: [String: Set<String>] = ["homework": ["photos"]]

    static func synced(_ coll: String, _ f: String) -> Bool {
        f != "id" && !(localOnly[coll]?.contains(f) ?? false)
    }

    static func idOf(_ d: [String: Any]) -> String { (d["id"] as? String ?? "").lowercased() }

    private static func number(_ v: Any?) -> Double { (v as? NSNumber)?.doubleValue ?? 0 }

    /// Когда менялось поле, которое видим впервые при первой синхронизации, — берём из самих данных
    static func hint(_ coll: String, _ d: [String: Any], _ f: String) -> Double {
        if coll == "homework" && (f == "done" || f == "doneAt" || f == "steps") { return number(d["doneAt"]) }
        if coll == "notes" { return number(d["updated"]) }
        return 0
    }

    /// Свои правки с прошлого раза: поле поменялось — «сейчас», запись пропала — удалена сейчас
    static func refresh(_ coll: String, _ items: [[String: Any]], _ st: SyncCollState, now: Double) -> SyncCollState {
        let first = !st.initialized
        var out = SyncCollState(stamps: [:], tomb: st.tomb, initialized: true)
        for it in items {
            let id = idOf(it)
            guard !id.isEmpty else { continue }
            let old = st.stamps[id]
            var s: [String: SyncCollState.Stamp] = [:]
            for (f, v) in it where synced(coll, f) {
                let h = SyncCodec.fingerprint(v)
                if let prev = old?[f] {
                    s[f] = prev.h == h ? prev : .init(h: h, m: now)
                } else {
                    // новое поле у старой записи (обновление приложения) — не правка; новая запись — правка сейчас
                    s[f] = .init(h: h, m: first ? hint(coll, it, f) : (old != nil ? 0 : now))
                }
            }
            out.stamps[id] = s
            out.tomb[id] = nil
        }
        for id in st.stamps.keys where out.stamps[id] == nil { out.tomb[id] = now }
        out.tomb = out.tomb.filter { now - $0.value < 120 * 86_400_000 }
        return out
    }

    /// Отметки для того, что получилось после сведения: отпечатки — свои, «когда менялось» — общее
    static func restamp(_ coll: String, _ items: [[String: Any]], m: [String: [String: Double]], tomb: [String: Double]) -> SyncCollState {
        var out = SyncCollState(stamps: [:], tomb: tomb, initialized: true)
        for it in items {
            let id = idOf(it)
            guard !id.isEmpty else { continue }
            var s: [String: SyncCollState.Stamp] = [:]
            for (f, v) in it where synced(coll, f) {
                s[f] = .init(h: SyncCodec.fingerprint(v), m: m[id]?[f] ?? 0)
            }
            out.stamps[id] = s
        }
        return out
    }

    static func wire(_ st: SyncCollState) -> [String: [String: Double]] {
        st.stamps.mapValues { $0.mapValues(\.m) }
    }

    /// Числа из JSON → [id: [поле: мс]]
    static func readM(_ any: Any?) -> [String: [String: Double]] {
        guard let d = any as? [String: Any] else { return [:] }
        var out: [String: [String: Double]] = [:]
        for (id, v) in d {
            guard let f = v as? [String: Any] else { continue }
            out[id] = f.compactMapValues { ($0 as? NSNumber)?.doubleValue }
        }
        return out
    }

    static func readTomb(_ any: Any?) -> [String: Double] {
        (any as? [String: Any])?.compactMapValues { ($0 as? NSNumber)?.doubleValue } ?? [:]
    }
}

// MARK: - Синхронизация

final class PCSync: ObservableObject {
    static let shared = PCSync()

    @Published private(set) var pairing: SyncPairing?
    @Published private(set) var lastSync: Date?
    @Published private(set) var syncing = false
    /// Что мешает: компьютер не в сети, связку сбросили…
    @Published private(set) var problem: String?

    /// Компьютеры с Арктикой в этой сети — для связки без QR-кода
    @Published private(set) var nearby: [SyncFound] = []
    @Published private(set) var searching = false
    /// Хоть раз искали (пока не искали — не пишем «не нашёл»)
    @Published private(set) var searched = false

    /// Связка без QR-кода: что сейчас показать
    enum PairStep: Equatable {
        case connecting(String)
        /// код и имя компьютера
        case code(String, String)
        case failed(String)
    }
    @Published private(set) var pairStep: PairStep?
    /// Телефон не связан, а рядом нашёлся компьютер — предложить
    @Published var offer: SyncFound?
    private var pairTask: Task<Void, Never>?
    /// Когда можно снова обойти сеть в поисках сменившего адрес компьютера
    private var rescanAfter = Date.distantPast

    private weak var tasks: TaskStore?
    private var bag = Set<AnyCancellable>()
    private var observers: [NSObjectProtocol] = []
    private var loop: Task<Void, Never>?
    private var inFlight = false
    private var again = false
    /// Сейчас кладём общую версию в хранилища — это не правка, снова синхронизировать не нужно
    private var applying = false
    private var started = false
    private let session: URLSession

    private let pairKey = "pcsync.pair.v1"
    private let stateKey = "pcsync.state.v1"
    private let lastKey = "pcsync.last"
    private static let route = "/v2/sync"

    var isPaired: Bool { pairing != nil }

    private init() {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 6
        c.timeoutIntervalForResource = 20
        c.waitsForConnectivity = false
        c.urlCache = nil
        session = URLSession(configuration: c)
        if let raw = Keychain.get(pairKey), let p = try? JSONDecoder().decode(SyncPairing.self, from: raw) { pairing = p }
        let t = UserDefaults.standard.double(forKey: lastKey)
        lastSync = t > 0 ? Date(timeIntervalSince1970: t) : nil
    }

    /// Запуск вместе с хранилищами: следим за правками и за тем, открыто ли приложение
    func start(tasks: TaskStore) {
        self.tasks = tasks
        guard !started else { return }
        started = true
        let changed: () -> Void = { [weak self] in
            guard let self, !self.applying else { return }
            self.kick(after: 1.2)
        }
        HomeworkStore.shared.$items.dropFirst().sink { _ in changed() }.store(in: &bag)
        NotesStore.shared.$notes.dropFirst().sink { _ in changed() }.store(in: &bag)
        tasks.$tasks.dropFirst().sink { _ in changed() }.store(in: &bag)
        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName: UIApplication.didBecomeActiveNotification, object: nil, queue: .main) { [weak self] _ in
            self?.startLoop(delay: 0.9)
            self?.lookAroundSoon(after: 6)
        })
        observers.append(nc.addObserver(forName: UIApplication.didEnterBackgroundNotification, object: nil, queue: .main) { [weak self] _ in
            self?.loop?.cancel()
            self?.loop = nil
            self?.flushInBackground()
        })
        if UIApplication.shared.applicationState == .active {
            startLoop(delay: 2.5)
            lookAroundSoon(after: 10)
        }
    }

    /// Ушли из приложения — последняя правка не ждёт следующего открытия: ещё один обмен, пока iOS даёт время
    private func flushInBackground() {
        guard isPaired else { return }
        var bg = UIBackgroundTaskIdentifier.invalid
        bg = UIApplication.shared.beginBackgroundTask(withName: "pcsync") {
            UIApplication.shared.endBackgroundTask(bg)
            bg = .invalid
        }
        Task { @MainActor in
            await self.syncNow(background: true)
            if bg != .invalid {
                UIApplication.shared.endBackgroundTask(bg)
                bg = .invalid
            }
        }
    }

    /// Фоновое обновление iOS: заодно обменяться с компьютером, если он рядом
    @MainActor
    func backgroundSync() async {
        guard isPaired, tasks != nil else { return }
        await syncNow(background: true)
    }

    // MARK: поиск компьютера в сети

    private static let offerLastKey = "pcsync.offer.last"
    private static let offerNeverKey = "pcsync.offer.never"

    static func neverOffer() {
        UserDefaults.standard.set(true, forKey: offerNeverKey)
    }

    private func lookAroundSoon(after delay: Double) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            Task { @MainActor in await self.lookAround() }
        }
    }

    /// Телефон не связан — раз в полдня тихо смотрим, нет ли в этом Wi‑Fi компьютера с Арктикой, и предлагаем связаться
    @MainActor
    private func lookAround() async {
        let d = UserDefaults.standard
        let now = Date().timeIntervalSince1970
        guard !isPaired, pairStep == nil, offer == nil, !searching,
              d.bool(forKey: "onboarded"), !d.bool(forKey: Self.offerNeverKey),
              now - d.double(forKey: Self.offerLastKey) > 12 * 3600,
              UIApplication.shared.applicationState == .active,
              !LocalNet.interfaces().isEmpty else { return }
        d.set(now, forKey: Self.offerLastKey)
        let list = await PCDiscovery.scan(stop: { _ in true })
        guard !isPaired, pairStep == nil, let f = list.first else { return }
        nearby = list
        offer = f
    }

    /// Найти компьютеры с Арктикой в этой сети (экран синхронизации)
    @MainActor
    func searchNearby() async {
        guard !searching else { return }
        searching = true
        defer {
            searching = false
            searched = true
        }
        let list = await PCDiscovery.scan(first: pairing?.hosts ?? [])
        // сначала свой (тот, с кем телефон связан), потом по имени
        let mine = pairing.map { PCDiscovery.tag($0.id) }
        nearby = list.sorted { a, b in
            let x = a.pair != nil && a.pair == mine, y = b.pair != nil && b.pair == mine
            return x != y ? x : a.pc.localizedStandardCompare(b.pc) == .orderedAscending
        }
    }

    /// Связаться с найденным компьютером: код на обоих экранах, «Разрешить» на компьютере
    func pairWith(_ f: SyncFound) {
        pairTask?.cancel()
        pairStep = .connecting(f.pc)
        let device = UIDevice.current.name
        pairTask = Task { @MainActor [weak self] in
            do {
                let link = try await PCPairing.run(f, device: device) { code in
                    guard let self, !Task.isCancelled else { return }
                    self.pairStep = .code(code, f.pc)
                    Haptics.tap()
                }
                guard let self, !Task.isCancelled else { return }
                self.pairStep = nil
                self.pairTask = nil
                self.nearby = []
                self.pair(link)
            } catch is CancellationError {
            } catch {
                guard let self, !Task.isCancelled else { return }
                self.pairStep = .failed((error as? LocalizedError)?.errorDescription ?? "Не получилось связаться. Попробуй ещё раз.")
                self.pairTask = nil
            }
        }
    }

    func cancelPairing() {
        pairTask?.cancel()
        pairTask = nil
        pairStep = nil
    }

    /// Компьютер не ответил по старым адресам: наверное, ему выдали в сети новый — ищем его по отпечатку связки
    @MainActor
    private func rediscover(_ p: SyncPairing) async -> Bool {
        guard Date() >= rescanAfter, UIApplication.shared.applicationState == .active, !LocalNet.interfaces().isEmpty else { return false }
        rescanAfter = Date().addingTimeInterval(5 * 60)
        let tag = PCDiscovery.tag(p.id)
        let ports = p.port == PCDiscovery.port ? [p.port] : [p.port, PCDiscovery.port]
        let list = await PCDiscovery.scan(ports: ports, stop: { $0.pair == tag })
        guard let f = list.first(where: { $0.pair == tag }), pairing?.id == p.id else { return false }
        rescanAfter = Date().addingTimeInterval(60)
        var n = pairing ?? p
        n.hosts = Array(([f.host] + n.hosts.filter { $0 != f.host }).prefix(5))
        n.port = f.port
        if let raw = try? JSONEncoder().encode(n) { Keychain.set(raw, for: pairKey) }
        pairing = n
        return true
    }

    /// Пока приложение открыто — заглядываем на компьютер каждые несколько секунд
    private func startLoop(delay: Double) {
        loop?.cancel()
        guard isPaired else { return }
        loop = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            while !Task.isCancelled {
                guard let self else { return }
                await self.syncNow()
                // компьютер не отвечает — реже, чтобы не тратить батарею
                let wait: Double = self.problem == nil ? 10 : 45
                try? await Task.sleep(nanoseconds: UInt64(wait * 1_000_000_000))
            }
        }
    }

    /// Синхронизировать вскоре (после правки)
    func kick(after delay: Double = 0) {
        guard isPaired else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            Task { @MainActor in await self.syncNow() }
        }
    }

    // MARK: связка

    func pair(_ link: SyncLink) {
        let p = SyncPairing(hosts: link.hosts, port: link.port, id: link.id, key: link.key, name: link.name, paired: Date())
        if let raw = try? JSONEncoder().encode(p) { Keychain.set(raw, for: pairKey) }
        // новая связка — отметки с чистого листа: первая встреча сводится по самим данным
        UserDefaults.standard.removeObject(forKey: stateKey)
        UserDefaults.standard.removeObject(forKey: lastKey)
        pairing = p
        lastSync = nil
        problem = nil
        offer = nil
        rescanAfter = .distantPast
        Haptics.success()
        startLoop(delay: 0.2)
    }

    func unpair() {
        loop?.cancel()
        loop = nil
        Keychain.delete(pairKey)
        UserDefaults.standard.removeObject(forKey: stateKey)
        UserDefaults.standard.removeObject(forKey: lastKey)
        pairing = nil
        lastSync = nil
        problem = nil
    }

    // MARK: состояние

    private func loadState() -> [String: SyncCollState] {
        guard let raw = UserDefaults.standard.data(forKey: stateKey),
              let s = try? JSONDecoder().decode([String: SyncCollState].self, from: raw) else { return [:] }
        return s
    }

    private func saveState(_ s: [String: SyncCollState]) {
        if let raw = try? JSONEncoder().encode(s) { UserDefaults.standard.set(raw, forKey: stateKey) }
    }

    /// Что сейчас лежит в хранилищах — в виде для сети
    private func snapshot() -> [String: [[String: Any]]] {
        var out: [String: [[String: Any]]] = [
            "homework": SyncCodec.dicts(HomeworkStore.shared.items),
            "notes": SyncCodec.dicts(NotesStore.shared.notes)
        ]
        if let tasks { out["tasks"] = SyncCodec.dicts(tasks.tasks) }
        return out
    }

    // MARK: один обмен

    /// background — последний обмен после ухода из приложения или фоновое обновление iOS
    @MainActor
    func syncNow(background: Bool = false) async {
        guard let p = pairing, background || UIApplication.shared.applicationState != .background else { return }
        if inFlight { again = true; return }
        inFlight = true
        syncing = true
        defer {
            inFlight = false
            syncing = false
            if again { again = false; kick(after: 0.4) }
        }

        let now = Date().timeIntervalSince1970 * 1000
        var state = loadState()
        let local = snapshot()
        var data: [String: Any] = [:]
        var sent: [String: String] = [:]
        for (coll, items) in local {
            let st = SyncStamps.refresh(coll, items, state[coll] ?? SyncCollState(), now: now)
            state[coll] = st
            data[coll] = ["items": items, "m": SyncStamps.wire(st), "tomb": st.tomb]
            sent[coll] = SyncCodec.fingerprint(items)
        }
        // свои правки и удаления помним, даже если компьютер сейчас не ответит
        saveState(state)

        do {
            let body = try JSONSerialization.data(withJSONObject: ["device": UIDevice.current.name, "data": data])
            let answer = try await post(body, pairing: p)
            guard let rdata = answer["data"] as? [String: Any] else { throw PCTransferError.broken }
            // пока ждали ответа, что-то поправили — сводим ещё раз, с этой правкой
            let current = snapshot()
            if current.contains(where: { sent[$0.key] != SyncCodec.fingerprint($0.value) }) {
                again = true
                return
            }
            applying = true
            defer { applying = false }
            for coll in local.keys {
                guard let r = rdata[coll] as? [String: Any], let items = r["items"] as? [[String: Any]] else { continue }
                apply(coll, items)
                let final = snapshot()[coll] ?? []
                state[coll] = SyncStamps.restamp(coll, final, m: SyncStamps.readM(r["m"]), tomb: SyncStamps.readTomb(r["tomb"]))
            }
            saveState(state)
            remember(answer, for: p)
            lastSync = Date()
            UserDefaults.standard.set(lastSync!.timeIntervalSince1970, forKey: lastKey)
            problem = nil
        } catch PCTransferError.rejected(let code) where code == 403 || code == 400 {
            problem = "Компьютер не узнаёт этот телефон: связку обновили или отключили. Свяжи их заново по QR-коду"
        } catch {
            // компьютеру выдали в сети новый адрес — находим его и сразу пробуем снова
            if !background, await rediscover(p) {
                again = true
                return
            }
            problem = "Компьютер не отвечает. Нужно, чтобы он был в той же сети Wi‑Fi и Арктика на нём была запущена. Если всё так — на компьютере: «Синхронизация с iPhone» → «Разрешить синхронизацию» (брандмауэр Windows)"
        }
    }

    /// Компьютер сменил адрес или порт — запоминаем новые
    private func remember(_ answer: [String: Any], for p: SyncPairing) {
        var n = p
        if let hosts = answer["hosts"] as? [String] {
            let list = hosts.filter(PCLink.isLocal)
            if !list.isEmpty { n.hosts = Array(list.prefix(5)) }
        }
        if let port = (answer["port"] as? NSNumber)?.intValue, (1...65535).contains(port) { n.port = port }
        if let name = answer["pc"] as? String, !name.isEmpty { n.name = String(name.prefix(40)) }
        guard n != p, pairing?.id == p.id else { return }
        if let raw = try? JSONEncoder().encode(n) { Keychain.set(raw, for: pairKey) }
        pairing = n
    }

    // MARK: общая версия — в хранилища

    private func apply(_ coll: String, _ items: [[String: Any]]) {
        let nowMs = Date().timeIntervalSince1970 * 1000
        switch coll {
        case "homework":
            let local = Dictionary(HomeworkStore.shared.items.map { ($0.id.uuidString.lowercased(), $0) }, uniquingKeysWith: { a, _ in a })
            let list: [Homework] = items.compactMap { d in
                var d = d
                // фото — свои: у пришедшей с компьютера записи их здесь нет
                d["photos"] = local[SyncStamps.idOf(d)]?.photos ?? []
                return SyncCodec.decode(d, as: Homework.self)
            }
            HomeworkStore.shared.applySync(list)
        case "tasks":
            let defaults: [String: Any] = ["title": "", "subject": "", "note": "", "done": false, "remind": true, "due": nowMs]
            tasks?.applySync(items.compactMap { SyncCodec.decode($0, as: StudyTask.self, defaults: defaults) })
        case "notes":
            let defaults: [String: Any] = ["title": "", "text": "", "items": [Any](), "subject": "", "color": 0, "pinned": false,
                                           "created": nowMs, "updated": nowMs]
            NotesStore.shared.applySync(items.compactMap { SyncCodec.decode($0, as: Note.self, defaults: defaults) })
        default:
            break
        }
    }

    // MARK: сеть

    /// Запрос на компьютер: пробуем все его адреса сразу, отвечает первый
    private func post(_ body: Data, pairing p: SyncPairing) async throws -> [String: Any] {
        let key = SymmetricKey(data: p.key)
        let sealed = try PCCrypto.seal(body, key: key, aad: "POST \(Self.route)")
        let session = self.session
        let route = Self.route
        // в группе — сырые байты ответа: их можно передавать между задачами, словари — нет
        let results: [Result<Data, Error>] = await withTaskGroup(of: Result<Data, Error>.self) { group in
            for h in p.hosts {
                guard let url = URL(string: "http://\(h):\(p.port)\(route)") else { continue }
                group.addTask {
                    do {
                        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 6)
                        req.httpMethod = "POST"
                        req.setValue(p.id, forHTTPHeaderField: "X-Arktika-Pair")
                        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
                        req.httpBody = sealed
                        let (data, resp) = try await session.data(for: req)
                        guard let http = resp as? HTTPURLResponse else { throw PCTransferError.broken }
                        guard http.statusCode == 200,
                              (http.value(forHTTPHeaderField: "Content-Type") ?? "").hasPrefix("application/octet-stream") else {
                            throw PCTransferError.rejected(http.statusCode)
                        }
                        return .success(try PCCrypto.open(data, key: key, aad: "R POST \(route)"))
                    } catch {
                        return .failure(error)
                    }
                }
            }
            var all: [Result<Data, Error>] = []
            for await r in group {
                if case .success = r {
                    group.cancelAll()
                    return [r]
                }
                all.append(r)
            }
            return all
        }
        for r in results {
            if case .success(let plain) = r {
                guard let j = try JSONSerialization.jsonObject(with: plain) as? [String: Any] else { throw PCTransferError.broken }
                return j
            }
        }
        for r in results {
            if case .failure(let e) = r, let pe = e as? PCTransferError, case .rejected(let c) = pe { throw PCTransferError.rejected(c) }
        }
        throw PCTransferError.unreachable
    }

    // MARK: подписи

    /// «только что», «5 минут назад»
    static func ago(_ d: Date, now: Date = Date()) -> String {
        if now.timeIntervalSince(d) < 50 { return "только что" }
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.unitsStyle = .full
        return f.localizedString(for: d, relativeTo: now)
    }
}

// MARK: - Экран: Профиль → «Синхронизация с компьютером»

struct PCSyncView: View {
    @ObservedObject private var sync = PCSync.shared
    @State private var scanning = false
    @State private var confirmUnpair = false
    /// Связанный телефон ищет другой компьютер
    @State private var findOther = false

    var body: some View {
        List {
            Section {
                TimelineView(.periodic(from: .now, by: 30)) { ctx in
                    HStack(spacing: 14) {
                        Image(systemName: sync.isPaired ? "arrow.triangle.2.circlepath" : "laptopcomputer.and.iphone")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 52, height: 52)
                            .background(sync.isPaired ? AnyShapeStyle(LinearGradient(colors: [.green, .teal], startPoint: .topLeading, endPoint: .bottomTrailing))
                                                      : AnyShapeStyle(brandGradient),
                                        in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                            .rotationEffect(.degrees(sync.syncing ? 180 : 0))
                            .animation(.easeInOut(duration: 0.6), value: sync.syncing)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(title).font(.headline)
                            Text(subtitle(ctx.date)).font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.vertical, 6)
                }
                if let problem = sync.problem, sync.isPaired {
                    Label(problem, systemImage: "wifi.exclamationmark")
                        .font(.footnote)
                        .foregroundStyle(.orange)
                }
                if sync.isPaired {
                    Button {
                        Haptics.tap()
                        Task { @MainActor in await sync.syncNow() }
                    } label: {
                        Label("Синхронизировать сейчас", systemImage: "arrow.clockwise")
                    }
                    .disabled(sync.syncing)
                }
            }

            if sync.pairStep != nil {
                Section { PCPairPanel() }
            } else if !sync.isPaired || findOther {
                nearbySection
            }

            Section("Как это работает") {
                point("magnifyingglass", "Телефон сам находит компьютер",
                      "Арктика для Windows запущена, вы в одном Wi‑Fi — компьютер появится в списке. Нажми на него, сверь код на обоих экранах и нажми на компьютере «Разрешить». Один раз — и всё. QR-код тоже работает.")
                point("arrow.left.arrow.right", "Дальше всё само",
                      "Пока Арктика открыта на телефоне, она заглядывает на компьютер каждые несколько секунд и сразу после правок. Отметил ДЗ сделанным на компьютере — через пару секунд оно сделано и здесь, и наоборот.")
                point("checklist", "Что синхронизируется",
                      "ДЗ (сроки, подпункты, «сделано»), задачи и заметки. Фото к ДЗ остаются на своём устройстве. Файлы предметов и фото доски — через «Перенос на компьютер».")
                point("wifi", "Нужна одна сеть Wi‑Fi",
                      "Телефон и компьютер в одной сети, Арктика на компьютере запущена (можно свёрнутой в трей). Были в разных местах — всё догонит, как только окажетесь в одной сети. Компьютеру выдали новый адрес — телефон найдёт его сам. Закрыл приложение сразу после правки — она всё равно уйдёт на компьютер.")
                point("checkmark.seal", "Ничего не теряется",
                      "Если одно и то же поменяли в двух местах, побеждает то, что сделали позже, — по каждому полю отдельно: «сделано» не сотрёт новый срок, и наоборот.")
                point("lock.shield", "Без облаков и чужих серверов",
                      "Напрямую по домашней сети, шифрование AES‑256. Ключ передаётся зашифрованным и только после «Разрешить» на компьютере; «Новый код» на компьютере — и старая связка больше не работает.")
            }

            Section {
                if sync.isPaired && !findOther {
                    Button {
                        findOther = true
                        Task { @MainActor in await sync.searchNearby() }
                    } label: {
                        Label("Найти компьютер в сети", systemImage: "magnifyingglass")
                    }
                }
                Button {
                    scanning = true
                } label: {
                    Label(sync.isPaired ? "Связать заново по QR-коду" : "Связать по QR-коду", systemImage: "qrcode.viewfinder")
                }
                if sync.isPaired {
                    Button(role: .destructive) {
                        confirmUnpair = true
                    } label: {
                        Label("Отключить синхронизацию", systemImage: "link.badge.plus")
                    }
                }
            } footer: {
                Text("Перенос на компьютер по QR-коду никуда не делся: он отправляет файлы предметов, фото доски и записи лекций.")
            }
        }
        .navigationTitle("Синхронизация")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if !sync.isPaired && sync.pairStep == nil { await sync.searchNearby() }
        }
        .onChange(of: sync.pairing) { _, _ in findOther = false }
        .refreshable {
            if !sync.isPaired || findOther { await sync.searchNearby() }
        }
        .sheet(isPresented: $scanning) {
            SyncScanSheet { link in
                sync.pair(link)
                scanning = false
            }
        }
        .confirmationDialog("Отключить синхронизацию?", isPresented: $confirmUnpair, titleVisibility: .visible) {
            Button("Отключить", role: .destructive) { sync.unpair() }
        } message: {
            Text("ДЗ, задачи и заметки останутся и здесь, и на компьютере, но меняться вместе перестанут.")
        }
    }

    /// Компьютеры с Арктикой в этой сети: нажал — связываемся без QR-кода
    @ViewBuilder
    private var nearbySection: some View {
        Section {
            if sync.searching && sync.nearby.isEmpty {
                HStack(spacing: 12) {
                    ProgressView()
                    Text("Ищу компьютер с Арктикой в этой сети…")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 6)
            }
            ForEach(sync.nearby) { f in
                Button {
                    Haptics.tap()
                    sync.pairWith(f)
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: "laptopcomputer")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 38, height: 38)
                            .background(Color.brand, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(f.pc).font(.body.weight(.semibold)).foregroundStyle(.primary)
                            Text(isMine(f) ? "Уже связан · \(f.host)" : "Нажми, чтобы связать · \(f.host)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.tertiary)
                    }
                }
            }
            if !sync.searching && sync.searched && sync.nearby.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Компьютер не нашёлся").font(.subheadline.weight(.semibold))
                    Text("Проверь: компьютер и телефон в одной сети Wi‑Fi, Арктика на компьютере запущена и обновлена (19.1 или новее). Если iPhone спрашивал про локальную сеть — разреши: Настройки → Арктика → Локальная сеть. На компьютере в «Синхронизация с iPhone» нажми «Разрешить синхронизацию», если там есть такая кнопка. В сетях общежитий и кампуса устройства часто не видят друг друга — тогда подключи компьютер к «Режиму модема» iPhone.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
            if !sync.searching {
                Button {
                    Task { @MainActor in await sync.searchNearby() }
                } label: {
                    Label(sync.searched ? "Искать ещё раз" : "Найти компьютер", systemImage: "arrow.clockwise")
                }
            }
        } header: {
            Text("Компьютеры рядом")
        }
    }

    private func isMine(_ f: SyncFound) -> Bool {
        guard let p = sync.pairing, let tag = f.pair else { return false }
        return PCDiscovery.tag(p.id) == tag
    }

    private var title: String {
        guard let p = sync.pairing else { return "Компьютер не связан" }
        return sync.lastSync == nil ? "Связано с «\(p.name)»" : "Синхронизировано с «\(p.name)»"
    }

    private func subtitle(_ now: Date) -> String {
        guard sync.isPaired else { return "Выбери компьютер ниже — и ДЗ, задачи и заметки станут общими" }
        if sync.syncing && sync.lastSync == nil { return "Ищу компьютер в сети…" }
        guard let last = sync.lastSync else { return "Жду компьютер: открой на нём Арктику" }
        return "Последний раз — \(PCSync.ago(last, now: now))"
    }

    private func point(_ icon: String, _ title: String, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Color.brand)
                .frame(width: 26)
                .padding(.top, 2)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.subheadline.weight(.semibold))
                Text(text).font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
    }
}

/// Камера для QR-кода связки
private struct SyncScanSheet: View {
    let onLink: (SyncLink) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var access = AVCaptureDevice.authorizationStatus(for: .video)
    @State private var wrong = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                ZStack {
                    if access == .authorized {
                        QRScannerView { text in
                            if let l = SyncLink(string: text) {
                                onLink(l)
                            } else if !wrong {
                                wrong = true
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { wrong = false }
                            }
                        }
                    } else {
                        Color.black.onAppear {
                            AVCaptureDevice.requestAccess(for: .video) { _ in
                                DispatchQueue.main.async { access = AVCaptureDevice.authorizationStatus(for: .video) }
                            }
                        }
                    }
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .strokeBorder(wrong ? Color.orange : Color.white.opacity(0.9), style: StrokeStyle(lineWidth: 3, dash: [26, 14]))
                        .frame(width: 230, height: 230)
                        .allowsHitTesting(false)
                    if wrong {
                        Text("Это не код синхронизации")
                            .font(.footnote.weight(.bold))
                            .padding(.horizontal, 12).padding(.vertical, 7)
                            .background(.ultraThinMaterial, in: Capsule())
                            .offset(y: 140)
                    }
                }
                .frame(maxWidth: .infinity)
                .frame(height: 380)
                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                .padding(.horizontal, 16)
                .animation(.easeOut(duration: 0.2), value: wrong)

                Text("Наведи на QR-код на компьютере")
                    .font(.title3.weight(.bold))
                Text("Арктика для Windows → Профиль → «Синхронизация с iPhone»")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                Spacer(minLength: 0)
            }
            .padding(.top, 12)
            .navigationTitle("Связать с компьютером")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Отмена") { dismiss() } }
            }
        }
    }
}

/// Пометка во вкладке «ДЗ»: синхронизировано с компьютером N минут назад
struct SyncBadge: View {
    @ObservedObject private var sync = PCSync.shared

    var body: some View {
        if let p = sync.pairing {
            TimelineView(.periodic(from: .now, by: 30)) { ctx in
                Button {
                    Haptics.tap()
                    Task { @MainActor in await sync.syncNow() }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: sync.problem == nil ? "arrow.triangle.2.circlepath" : "wifi.slash")
                            .font(.caption.weight(.bold))
                            .rotationEffect(.degrees(sync.syncing ? 180 : 0))
                            .animation(.easeInOut(duration: 0.6), value: sync.syncing)
                        Text(label(p, ctx.date))
                            .font(.caption.weight(.semibold))
                            .lineLimit(1)
                    }
                    .foregroundStyle(sync.problem == nil ? Color.brand : Color.orange)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background((sync.problem == nil ? Color.brand : Color.orange).opacity(0.12), in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .accessibilityLabel(label(p, ctx.date))
                .accessibilityHint("Синхронизировать сейчас")
            }
        }
    }

    private func label(_ p: SyncPairing, _ now: Date) -> String {
        if sync.problem != nil { return "\(p.name) не в сети" + (sync.lastSync.map { " · было \(PCSync.ago($0, now: now))" } ?? "") }
        guard let last = sync.lastSync else { return "Жду «\(p.name)»" }
        return "С «\(p.name)» · \(PCSync.ago(last, now: now))"
    }
}
