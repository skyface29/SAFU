import SwiftUI
import WebKit
import UIKit

final class WebModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, WKScriptMessageHandler {
    let webView: WKWebView
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var url: URL?
    @Published var title = ""
    @Published var errorText: String?
    @Published var toast: String?
    /// Предложение сохранить пароль (показываем после успешного входа)
    @Published var pendingCredential: SiteCredential?
    private var candidate: SiteCredential?
    private var autoAttempts: [String: [Date]] = [:]

    /// Главная страница ресурса — на неё откатываемся, если сохранённая страница не открылась
    var homeURL: URL?
    private var triedFallback = false
    private var progressObs: NSKeyValueObservation?
    private var downloadNames: [ObjectIdentifier: String] = [:]

    override init() {
        let config = WKWebViewConfiguration()
        // Общее постоянное хранилище: входы в Sakai, почту и т.д. сохраняются между запусками
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        config.userContentController.addUserScript(
            WKUserScript(source: LoginScript.source, injectionTime: .atDocumentEnd, forMainFrameOnly: false))
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.configuration.userContentController.add(WeakScriptHandler(self), name: "safuLogin")
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = true
        // Некоторые сайты (например, Samoware) проверяют браузер — представляемся мобильным Safari
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1"

        // Потянуть вниз — обновить страницу
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(pullToRefresh(_:)), for: .valueChanged)
        webView.scrollView.refreshControl = refresh

        progressObs = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] wv, _ in
            let value = wv.estimatedProgress
            Task { @MainActor in self?.progress = value }
        }
    }

    @objc private func pullToRefresh(_ sender: UIRefreshControl) {
        webView.reload()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { sender.endRefreshing() }
    }

    func load(_ url: URL) {
        guard webView.url == nil else { return }
        errorText = nil
        webView.load(URLRequest(url: url))
    }

    func goHome() {
        guard let u = homeURL else { return }
        errorText = nil
        webView.load(URLRequest(url: u))
    }

    func retry() {
        errorText = nil
        if webView.url != nil { webView.reload() } else if let u = homeURL { webView.load(URLRequest(url: u)) }
    }

    private func update() {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
        url = webView.url
        title = webView.title ?? ""
    }

    private func showToast(_ text: String) {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
            withAnimation(.easeOut(duration: 0.3)) { self?.toast = nil }
        }
    }

    // MARK: навигация

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        errorText = nil
        update()
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        triedFallback = true
        update()
        // сохраняем вход, чтобы он пережил перезапуск приложения
        SessionKeeper.save(from: webView.configuration.websiteDataStore.httpCookieStore)
        offerToSaveIfLoggedIn()
    }

    // MARK: логины и пароли

    private func jsString(_ s: String) -> String {
        (try? JSONEncoder().encode(s)).flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
    }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any],
              let kind = body["kind"] as? String,
              let host = (body["host"] as? String)?.lowercased(), !host.isEmpty else { return }
        if kind == "form" {
            autofill(host: host, frame: message.frameInfo)
        } else if kind == "creds", CredentialStore.enabled {
            let pass = body["pass"] as? String ?? ""
            guard !pass.isEmpty else { return }
            candidate = SiteCredential(host: host, user: body["user"] as? String ?? "", pass: pass)
        }
    }

    private func autofill(host: String, frame: WKFrameInfo) {
        guard CredentialStore.enabled, let c = CredentialStore.get(host) else { return }
        // автонажатие «Войти» — не чаще 2 раз за 5 минут, чтобы не зациклиться при неверном пароле
        let recent = (autoAttempts[host] ?? []).filter { Date().timeIntervalSince($0) < 300 }
        let submit = CredentialStore.autoLogin && recent.count < 2
        if submit { autoAttempts[host] = recent + [Date()] }
        let js = "window.__safuFill && window.__safuFill(\(jsString(c.user)), \(jsString(c.pass)), \(submit ? "true" : "false"))"
        webView.evaluateJavaScript(js, in: frame, in: .page) { _ in }
        if submit { showToast("Вход выполняется автоматически…") }
    }

    /// Если после ввода пароля страница больше не просит пароль — вход удался, предлагаем сохранить
    private func offerToSaveIfLoggedIn() {
        guard let c = candidate else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            guard let self = self else { return }
            self.webView.evaluateJavaScript("!!document.querySelector('input[type=\"password\"]')") { result, _ in
                let stillLogin = (result as? Bool) ?? false
                guard !stillLogin else { return }
                self.candidate = nil
                if CredentialStore.get(c.host) != c { self.pendingCredential = c }
            }
        }
    }

    func saveCredential(_ c: SiteCredential) {
        CredentialStore.save(c)
        pendingCredential = nil
        showToast("Пароль сохранён")
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }

    private func handle(_ error: Error) {
        update()
        let ns = error as NSError
        // отменённые переходы и «загрузка прервана» (скачивание файла) — не ошибки
        if ns.code == NSURLErrorCancelled || (ns.domain == "WebKitErrorDomain" && (ns.code == 102 || ns.code == 204)) { return }
        // сохранённая страница не открылась — тихо идём на главную сайта
        if !triedFallback, let home = homeURL {
            triedFallback = true
            webView.load(URLRequest(url: home))
            return
        }
        switch ns.code {
        case NSURLErrorNotConnectedToInternet, NSURLErrorNetworkConnectionLost:
            errorText = "Нет интернета"
        case NSURLErrorTimedOut:
            errorText = "Сайт долго не отвечает"
        case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost, NSURLErrorDNSLookupFailed:
            errorText = "Сайт сейчас недоступен"
        case NSURLErrorServerCertificateUntrusted, NSURLErrorSecureConnectionFailed,
             NSURLErrorServerCertificateHasBadDate, NSURLErrorServerCertificateNotYetValid:
            errorText = "Проблема с защищённым соединением сайта"
        default:
            errorText = ns.localizedDescription
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let u = navigationAction.request.url, let scheme = u.scheme?.lowercased() else {
            decisionHandler(.allow); return
        }
        // почта, телефон, другие приложения — отдаём системе
        if !["http", "https", "about", "blob", "data", "javascript", "file"].contains(scheme) {
            UIApplication.shared.open(u)
            decisionHandler(.cancel)
            return
        }
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = navigationResponse.response as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition"),
           cd.lowercased().contains("attachment") {
            decisionHandler(.download)
            return
        }
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    // Ссылки с target="_blank" и всплывающие окна входа открываем в этом же окне
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil || navigationAction.targetFrame?.isMainFrame == false {
            webView.load(navigationAction.request)
        }
        return nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    // MARK: окна JavaScript (alert / confirm / prompt) — без них часть кнопок на сайтах «не работает»

    private func present(_ alert: UIAlertController) {
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first,
              var top = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController ?? scene.windows.first?.rootViewController
        else { return }
        while let p = top.presentedViewController { top = p }
        top.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(a)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(a)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { $0.text = defaultText }
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(a.textFields?.first?.text) })
        present(a)
    }

    // MARK: скачивание файлов → вкладка «Файлы», папка «Загрузки»

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileService.root.appendingPathComponent("Загрузки", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = FileService.uniqueURL(in: dir, name: suggestedFilename.isEmpty ? "Файл" : suggestedFilename)
        downloadNames[ObjectIdentifier(download)] = dest.lastPathComponent
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        let name = downloadNames[ObjectIdentifier(download)] ?? "Файл"
        Haptics.success()
        showToast("Скачано: \(name) → Файлы › Загрузки")
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        showToast("Не удалось скачать файл")
    }
}

struct WebView: UIViewRepresentable {
    @ObservedObject var model: WebModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WebScreen: View {
    let resource: Resource
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @StateObject private var model = WebModel()
    @State private var ruzConnected = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @AppStorage("web.light") private var forceLight = true

    private var homeURL: URL? { URL(string: resource.url) }
    private var currentURL: URL? { model.webView.url ?? homeURL }

    var body: some View {
        NavigationStack {
            WebView(model: model)
                .overlay(alignment: .top) {
                    if model.isLoading {
                        GeometryReader { geo in
                            Capsule()
                                .fill(brandGradient)
                                .frame(width: max(24, geo.size.width * model.progress), height: 3)
                                .animation(.easeOut(duration: 0.25), value: model.progress)
                        }
                        .frame(height: 3)
                        .transition(.opacity)
                    }
                }
                .overlay { if let err = model.errorText { errorView(err) } }
                .overlay(alignment: .bottom) {
                    VStack(spacing: 10) {
                        if let t = model.toast {
                            Label(t, systemImage: "arrow.down.circle.fill")
                                .font(.subheadline.weight(.semibold))
                                .padding(.horizontal, 16)
                                .padding(.vertical, 11)
                                .glass(20)
                                .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                        ruzButton
                    }
                    .padding(.bottom, 14)
                }
                .animation(.easeInOut(duration: 0.2), value: model.isLoading)
                .animation(.spring(response: 0.4, dampingFraction: 0.8), value: ruzCandidate)
                .animation(.spring(response: 0.4, dampingFraction: 0.8), value: model.errorText)
                .navigationTitle(model.title.isEmpty ? resource.title : model.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbarBackground(.ultraThinMaterial, for: .navigationBar, .bottomBar)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button { close() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .semibold))
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Menu {
                            Button { if let u = currentURL { openURL(u) } } label: {
                                Label("Открыть в Safari", systemImage: "safari")
                            }
                            Button {
                                if let u = currentURL { UIPasteboard.general.url = u }
                                Haptics.success()
                            } label: { Label("Скопировать ссылку", systemImage: "link") }
                            Button {
                                forceLight.toggle()
                                model.webView.overrideUserInterfaceStyle = forceLight ? .light : .unspecified
                            } label: {
                                Label(forceLight ? "Разрешить тёмную тему сайта" : "Всегда светлый сайт",
                                      systemImage: forceLight ? "moon" : "sun.max")
                            }
                            Button(role: .destructive) {
                                store.clearLastURL(for: resource)
                                model.goHome()
                            } label: { Label("Начать с главной", systemImage: "house") }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                        }
                    }
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button { model.webView.goBack() } label: { Image(systemName: "chevron.backward") }
                            .disabled(!model.canGoBack)
                        Spacer()
                        Button { model.webView.goForward() } label: { Image(systemName: "chevron.forward") }
                            .disabled(!model.canGoForward)
                        Spacer()
                        Button {
                            Haptics.tap()
                            model.goHome()
                        } label: { Image(systemName: "house") }
                        Spacer()
                        Button {
                            if model.isLoading { model.webView.stopLoading() } else { model.webView.reload() }
                        } label: { Image(systemName: model.isLoading ? "xmark" : "arrow.clockwise") }
                        Spacer()
                        if let u = currentURL {
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                        }
                    }
                }
        }
        .onAppear {
            model.homeURL = homeURL
            // Многие сайты вуза плохо поддерживают тёмную тему: текст сливается с фоном
            model.webView.overrideUserInterfaceStyle = forceLight ? .light : .unspecified
            // Сначала возвращаем сохранённый вход, потом открываем страницу
            let start = store.lastURL(for: resource) ?? homeURL
            SessionKeeper.restore(into: model.webView.configuration.websiteDataStore.httpCookieStore) {
                if let u = start { model.load(u) }
            }
        }
        .onDisappear(perform: remember)
        .alert("Сохранить пароль?", isPresented: Binding(get: { model.pendingCredential != nil },
                                                         set: { if !$0 { model.pendingCredential = nil } })) {
            Button("Сохранить") {
                if let c = model.pendingCredential { model.saveCredential(c) }
            }
            Button("Не сейчас", role: .cancel) { model.pendingCredential = nil }
        } message: {
            if let c = model.pendingCredential {
                Text("Для \(c.host)\(c.user.isEmpty ? "" : " (\(c.user))"). В следующий раз вход будет автоматическим. Пароль хранится зашифрованно только на этом iPhone.")
            }
        }
    }

    private func errorView(_ text: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(text)
                .font(.headline)
                .multilineTextAlignment(.center)
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    model.retry()
                } label: {
                    Label("Повторить", systemImage: "arrow.clockwise")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 11)
                        .background(brandGradient, in: Capsule())
                }
                Button {
                    store.clearLastURL(for: resource)
                    model.goHome()
                } label: {
                    Label("Главная", systemImage: "house")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 11)
                        .glass(22, interactive: true)
                }
            }
            .buttonStyle(PressableStyle())
            Button { if let u = currentURL { openURL(u) } } label: {
                Text("Открыть в Safari").font(.footnote.weight(.semibold))
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }

    /// ID группы, если сейчас открыто расписание группы в РУЗ
    private var ruzCandidate: String? {
        guard let u = model.url, u.host?.contains("ruz.narfu.ru") == true,
              let id = RuzClient.groupID(in: u) else { return nil }
        return id
    }

    @ViewBuilder private var ruzButton: some View {
        if let id = ruzCandidate {
            if ruzConnected || (schedule.data.usesRuz && schedule.data.ruzGroupID == id) {
                Label("Это твоё расписание", systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .glass(22)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            } else {
                Button {
                    let number = RuzClient.groupNumber(fromTitle: model.title) ?? schedule.data.ruzGroupNumber
                    schedule.connectRuz(number: number, institution: schedule.data.ruzInstitution, id: id)
                    Task { await schedule.sync(force: true) }
                    Haptics.success()
                    withAnimation { ruzConnected = true }
                } label: {
                    Label("Сделать моим расписанием", systemImage: "calendar.badge.checkmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 13)
                        .background(brandGradient, in: Capsule())
                        .shadow(color: .black.opacity(0.25), radius: 12, y: 6)
                }
                .buttonStyle(PressableStyle())
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private func remember() {
        if let u = model.webView.url { store.saveLastURL(u, for: resource) }
        SessionKeeper.save(from: model.webView.configuration.websiteDataStore.httpCookieStore)
    }

    private func close() {
        remember()
        dismiss()
    }
}
