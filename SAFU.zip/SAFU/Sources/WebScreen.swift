import SwiftUI
import WebKit

final class WebModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    let webView: WKWebView
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var url: URL?
    @Published var title = ""

    override init() {
        let config = WKWebViewConfiguration()
        // Общее постоянное хранилище: входы в Sakai, почту и т.д. сохраняются между запусками
        config.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // Некоторые сайты (например, Samoware) проверяют браузер — представляемся мобильным Safari
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
    }

    func load(_ url: URL) {
        guard webView.url == nil else { return }
        webView.load(URLRequest(url: url))
    }

    private func update() {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
        url = webView.url
        title = webView.title ?? ""
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { update() }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { update() }

    // Ссылки с target="_blank" открываем в этом же окне
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}

struct WebView: UIViewRepresentable {
    @ObservedObject var model: WebModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WebScreen: View {
    let resource: Resource
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @StateObject private var model = WebModel()
    @State private var ruzConnected = false
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @AppStorage("web.light") private var forceLight = true

    private var homeURL: URL? { URL(string: resource.url) }
    private var currentURL: URL? { model.webView.url ?? homeURL }

    var body: some View {
        NavigationStack {
            WebView(model: model)
                .overlay(alignment: .top) {
                    if model.isLoading {
                        ProgressView()
                            .padding(10)
                            .glass(18)
                            .padding(.top, 8)
                            .transition(.opacity.combined(with: .scale))
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: model.isLoading)
                .overlay(alignment: .bottom) { ruzButton }
                .animation(.spring(response: 0.4, dampingFraction: 0.8), value: ruzCandidate)
                .navigationTitle(resource.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbarBackground(.ultraThinMaterial, for: .navigationBar, .bottomBar)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button { close() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .semibold))
                        }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            if let u = currentURL { openURL(u) }
                        } label: { Image(systemName: "safari") }
                    }
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button { model.webView.goBack() } label: { Image(systemName: "chevron.backward") }
                            .disabled(!model.canGoBack)
                        Spacer()
                        Button { model.webView.goForward() } label: { Image(systemName: "chevron.forward") }
                            .disabled(!model.canGoForward)
                        Spacer()
                        Button {
                            Haptics.tap()
                            if let u = homeURL { model.webView.load(URLRequest(url: u)) }
                        } label: { Image(systemName: "house") }
                        Spacer()
                        Button { model.webView.reload() } label: { Image(systemName: "arrow.clockwise") }
                        Spacer()
                        if let u = currentURL {
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                        }
                    }
                }
        }
        .onAppear {
            // Многие сайты вуза плохо поддерживают тёмную тему: текст сливается с фоном
            model.webView.overrideUserInterfaceStyle = forceLight ? .light : .unspecified
            // Память: открываем страницу, на которой остановился в прошлый раз
            if let u = store.lastURL(for: resource) ?? homeURL { model.load(u) }
        }
        .onDisappear(perform: remember)
    }

    /// ID группы, если сейчас открыто расписание группы в РУЗ
    private var ruzCandidate: String? {
        guard let u = model.url, u.host?.contains("ruz.narfu.ru") == true,
              let id = RuzClient.groupID(in: u) else { return nil }
        return id
    }

    @ViewBuilder private var ruzButton: some View {
        if let id = ruzCandidate {
            if ruzConnected || (schedule.data.usesRuz && schedule.data.ruzGroupID == id) {
                Label("Это твоё расписание", systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .glass(22)
                    .padding(.bottom, 14)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            } else {
                Button {
                    let number = RuzClient.groupNumber(fromTitle: model.title) ?? schedule.data.ruzGroupNumber
                    schedule.connectRuz(number: number, institution: schedule.data.ruzInstitution, id: id)
                    Task { await schedule.sync(force: true) }
                    Haptics.success()
                    withAnimation { ruzConnected = true }
                } label: {
                    Label("Сделать моим расписанием", systemImage: "calendar.badge.checkmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 13)
                        .background(brandGradient, in: Capsule())
                        .shadow(color: .black.opacity(0.25), radius: 12, y: 6)
                }
                .buttonStyle(PressableStyle())
                .padding(.bottom, 14)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private func remember() {
        if let u = model.webView.url { store.saveLastURL(u, for: resource) }
    }

    private func close() {
        remember()
        dismiss()
    }
}
