import SwiftUI
import WebKit

final class WebModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate {
    let webView: WKWebView
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false

    override init() {
        let config = WKWebViewConfiguration()
        // Общее постоянное хранилище: входы в Sakai, почту и т.д. сохраняются между запусками
        config.websiteDataStore = .default()
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // Некоторые сайты (например, Samoware) проверяют браузер — представляемся мобильным Safari
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"
    }

    func load(_ url: URL) {
        guard webView.url == nil else { return }
        webView.load(URLRequest(url: url))
    }

    private func update() {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { update() }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { update() }

    // Ссылки с target="_blank" открываем в этом же окне
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}

struct WebView: UIViewRepresentable {
    @ObservedObject var model: WebModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct WebScreen: View {
    let resource: Resource
    @StateObject private var model = WebModel()
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL

    private var currentURL: URL? { model.webView.url ?? URL(string: resource.url) }

    var body: some View {
        NavigationStack {
            WebView(model: model)
                .ignoresSafeArea(edges: .bottom)
                .navigationTitle(resource.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        Button("Готово") { dismiss() }
                    }
                    ToolbarItem(placement: .navigationBarTrailing) {
                        if model.isLoading { ProgressView() }
                    }
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button { model.webView.goBack() } label: { Image(systemName: "chevron.backward") }
                            .disabled(!model.canGoBack)
                        Spacer()
                        Button { model.webView.goForward() } label: { Image(systemName: "chevron.forward") }
                            .disabled(!model.canGoForward)
                        Spacer()
                        Button { model.webView.reload() } label: { Image(systemName: "arrow.clockwise") }
                        Spacer()
                        if let u = currentURL {
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                        }
                        Spacer()
                        Button {
                            if let u = currentURL { openURL(u) }
                        } label: { Image(systemName: "safari") }
                    }
                }
        }
        .onAppear {
            if let u = URL(string: resource.url) { model.load(u) }
        }
    }
}
