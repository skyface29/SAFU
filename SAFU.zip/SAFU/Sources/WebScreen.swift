import SwiftUI
import WebKit
import UIKit

final class WebModel: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, WKScriptMessageHandler {
    let webView: WKWebView
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var isLoading = false
    @Published var progress: Double = 0
    @Published var url: URL?
    @Published var title = ""
    @Published var errorText: String?
    @Published var toast: String?
    /// Предложение сохранить пароль (показываем после успешного входа)
    @Published var pendingCredential: SiteCredential?
    private var candidate: SiteCredential?
    private var autoAttempts: [String: [Date]] = [:]

    /// Главная страница ресурса — на неё откатываемся, если сохранённая страница не открылась
    var homeURL: URL?
    private var triedFallback = false
    private var progressObs: NSKeyValueObservation?
    /// Следим за историей напрямую: сайты-приложения (Samoware, Sakai) меняют страницу без полной загрузки,
    /// и события навигации не приходят — из-за этого «назад» и «вперёд» оставались серыми
    private var navObs: [NSKeyValueObservation] = []
    /// В истории страницы есть куда вернуться (history.length > 1), даже если сам браузер этого не видит
    @Published var jsHistory = false
    /// На странице форма входа, и для сайта есть сохранённый пароль — показываем кнопку «Вставить пароль»
    @Published var loginUser: String?
    private var loginFrame: WKFrameInfo?
    /// Сайты, которые уже один раз обновили после первой загрузки
    private var reloadedOnce = Set<String>()
    private var downloadNames: [ObjectIdentifier: URL] = [:]
    /// Последний скачанный файл — по нажатию на подсказку он открывается карточкой
    @Published var lastDownload: URL?
    private var saveTimer: Timer?

    override init() {
        let config = WKWebViewConfiguration()
        // Общее постоянное хранилище: входы в Sakai, почту и т.д. сохраняются между запусками
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.preferences.javaScriptCanOpenWindowsAutomatically = true
        // Скрипт логинов живёт в отдельном мире WebKit: скрипты самой страницы его не видят,
        // не могут вызвать подстановку пароля и не могут слать сообщения от его имени
        config.userContentController.addUserScript(
            WKUserScript(source: LoginScript.source, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: .defaultClient))
        // «Всегда светлый сайт» (включено по умолчанию): сайт получает светлую схему и в CSS тоже,
        // иначе часть сайтов (почта) рисует светлый текст для тёмной темы на своём белом фоне
        if UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true {
            config.userContentController.addUserScript(
                WKUserScript(source: "(function(){var s=document.createElement('style');s.textContent=':root{color-scheme:light only !important}';(document.head||document.documentElement).appendChild(s);})();",
                             injectionTime: .atDocumentStart, forMainFrameOnly: false, in: .defaultClient))
        }
        // Невидимый текст в полях ввода (белое на белом, как в Samoware) — делаем читаемым
        config.userContentController.addUserScript(
            WKUserScript(source: ContrastFix.source, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: .defaultClient))
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.configuration.userContentController.add(WeakScriptHandler(self), contentWorld: .defaultClient, name: "safuLogin")
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        // страница не подстраивает отступы под «опасные» зоны экрана: шапка и нижняя панель у неё свои,
        // а карточку двигают и сворачивают — иначе на каждом кадре анимации страница пересчитывала отступы
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsLinkPreview = true
        // Некоторые сайты (например, Samoware) проверяют браузер — представляемся мобильным Safari
        webView.customUserAgent = Self.mobileUA

        // Потянуть вниз — обновить страницу
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(pullToRefresh(_:)), for: .valueChanged)
        webView.scrollView.refreshControl = refresh

        // сохраняем вход каждые 20 секунд, даже если приложение потом закроют смахиванием
        saveTimer = Timer.scheduledTimer(withTimeInterval: 20, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            SessionKeeper.save(from: self.webView.configuration.websiteDataStore.httpCookieStore)
        }

        progressObs = webView.observe(\.estimatedProgress, options: [.new]) { [weak self] wv, _ in
            let value = wv.estimatedProgress
            Task { @MainActor in self?.progress = value }
        }
        navObs = [
            webView.observe(\.canGoBack, options: [.new]) { [weak self] wv, _ in
                let v = wv.canGoBack
                Task { @MainActor in self?.canGoBack = v }
            },
            webView.observe(\.canGoForward, options: [.new]) { [weak self] wv, _ in
                let v = wv.canGoForward
                Task { @MainActor in self?.canGoForward = v }
            },
            webView.observe(\.url, options: [.new]) { [weak self] wv, _ in
                let u = wv.url
                Task { @MainActor in
                    self?.url = u
                    self?.checkJSHistory()
                }
            },
        ]
    }

    deinit {
        saveTimer?.invalidate()
    }

    @objc private func pullToRefresh(_ sender: UIRefreshControl) {
        webView.reload()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { sender.endRefreshing() }
    }

    // MARK: «Как в Safari» — сайт без наших помощников
    // Для сайтов, которым мешают вставки приложения (например, подсказки адресов в почте):
    // без скриптов автозаполнения и контраста, с настоящим названием браузера и темой как в системе.

    static let plainKey = "web.plain.hosts"

    static func isPlain(_ host: String?) -> Bool {
        guard let host else { return false }
        // почта Samoware: в Safari подсказки адресов работают, в приложении — нет. Один раз включаем ей режим Safari
        let d = UserDefaults.standard
        if !d.bool(forKey: "web.plain.samoware") {
            d.set(true, forKey: "web.plain.samoware")
            setPlain("edu.narfu.ru", true)
        }
        return (UserDefaults.standard.stringArray(forKey: plainKey) ?? []).contains(host)
    }

    static func setPlain(_ host: String, _ on: Bool) {
        var list = Set(UserDefaults.standard.stringArray(forKey: plainKey) ?? [])
        if on { list.insert(host) } else { list.remove(host) }
        UserDefaults.standard.set(Array(list), forKey: plainKey)
    }

    /// Переключить сайт в режим «как в Safari» (или вернуть помощников) и перезагрузить
    func applyPlain(_ on: Bool) {
        let ucc = webView.configuration.userContentController
        ucc.removeAllUserScripts()
        // пароли работают в обоих режимах: скрипт входа ничего не меняет на странице, только подставляет пароль
        ucc.addUserScript(WKUserScript(source: LoginScript.source, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: .defaultClient))
        webView.customUserAgent = Self.mobileUA
        if on {
            // набранный текст в почте не должен сливаться с фоном: только поля ввода + светлая тема сайта
            ucc.addUserScript(WKUserScript(source: ContrastFix.inputsOnly, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: .defaultClient))
            webView.overrideUserInterfaceStyle = (UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true) ? .light : .unspecified
        } else {
            ucc.addUserScript(WKUserScript(source: ContrastFix.source, injectionTime: .atDocumentEnd, forMainFrameOnly: false, in: .defaultClient))
            if UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true {
                ucc.addUserScript(WKUserScript(source: "(function(){var s=document.createElement('style');s.textContent=':root{color-scheme:light only !important}';(document.head||document.documentElement).appendChild(s);})();",
                                               injectionTime: .atDocumentStart, forMainFrameOnly: false, in: .defaultClient))
            }
            webView.overrideUserInterfaceStyle = (UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true) ? .light : .unspecified
        }
    }

    /// Представляемся настоящим Safari с версией iOS этого телефона (устаревшая версия отключала на сайтах части интерфейса)
    static let mobileUA: String = {
        let v = UIDevice.current.systemVersion.split(separator: ".")
        let major = v.first.map(String.init) ?? "18"
        let minor = v.count > 1 ? String(v[1]) : "0"
        return "Mozilla/5.0 (iPhone; CPU iPhone OS \(major)_\(minor) like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/\(major).\(minor) Mobile/15E148 Safari/604.1"
    }()

    func load(_ url: URL) {
        guard webView.url == nil else { return }
        errorText = nil
        webView.load(URLRequest(url: url))
    }

    func goHome() {
        guard let u = homeURL else { return }
        errorText = nil
        webView.load(URLRequest(url: u))
    }

    func retry() {
        errorText = nil
        if webView.url != nil { webView.reload() } else if let u = homeURL { webView.load(URLRequest(url: u)) }
    }

    /// Назад: по истории браузера, а если её нет — по истории самой страницы
    func back() {
        Haptics.tap()
        if webView.canGoBack { webView.goBack() } else { webView.evaluateJavaScript("history.back()") { _, _ in } }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in self?.checkJSHistory() }
    }

    func forward() {
        Haptics.tap()
        if webView.canGoForward { webView.goForward() } else { webView.evaluateJavaScript("history.forward()") { _, _ in } }
    }

    func checkJSHistory() {
        webView.evaluateJavaScript("history.length") { [weak self] v, _ in
            let n = (v as? Int) ?? 0
            DispatchQueue.main.async { self?.jsHistory = n > 1 }
        }
    }

    private func update() {
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        isLoading = webView.isLoading
        url = webView.url
        title = webView.title ?? ""
        checkJSHistory()
    }

    private func showToast(_ text: String) {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { toast = text }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) { [weak self] in
            withAnimation(.easeOut(duration: 0.3)) { self?.toast = nil }
        }
    }

    // MARK: навигация

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        errorText = nil
        loginUser = nil
        loginFrame = nil
        update()
    }
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) { update() }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Почта (режим «Как в Safari») при самой первой загрузке рисует белый текст и не показывает подсказки,
        // а после обновления всё нормально. Делаем это обновление сами — один раз за открытие.
        if let host = webView.url?.host, Self.isPlain(host), !reloadedOnce.contains(host) {
            reloadedOnce.insert(host)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak webView] in webView?.reload() }
        }
        triedFallback = true
        update()
        // сохраняем вход, чтобы он пережил перезапуск приложения
        SessionKeeper.save(from: webView.configuration.websiteDataStore.httpCookieStore)
        offerToSaveIfLoggedIn()
    }

    // MARK: логины и пароли

    private func jsString(_ s: String) -> String {
        (try? JSONEncoder().encode(s)).flatMap { String(data: $0, encoding: .utf8) } ?? "\"\""
    }

    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        // Адрес берём у WebKit, а не из сообщения страницы — подделать его нельзя.
        // Пароли подставляем и запоминаем только на защищённых (https) страницах.
        let origin = message.frameInfo.securityOrigin
        let host = origin.host.lowercased()
        guard let body = message.body as? [String: Any],
              let kind = body["kind"] as? String,
              !host.isEmpty, origin.protocol == "https" else { return }
        if kind == "form" {
            if CredentialStore.enabled, let c = CredentialStore.get(host) {
                loginFrame = message.frameInfo
                loginUser = c.user.isEmpty ? "" : c.user
            }
            autofill(host: host, frame: message.frameInfo)
        } else if kind == "gone" {
            loginUser = nil
            loginFrame = nil
            // форма входа исчезла без перезагрузки страницы — вход удался (почта и другие «одностраничные» сайты)
            SessionKeeper.save(from: webView.configuration.websiteDataStore.httpCookieStore)
            if let c = candidate, CredentialStore.get(c.host) != c {
                candidate = nil
                pendingCredential = c
            }
        } else if kind == "creds", CredentialStore.enabled {
            let pass = body["pass"] as? String ?? ""
            guard !pass.isEmpty else { return }
            candidate = SiteCredential(host: host, user: body["user"] as? String ?? "", pass: pass)
        }
    }

    /// Кнопка «Вставить пароль»: подставить сохранённые логин и пароль на текущей странице
    func fillPasswordNow() {
        guard let host = webView.url?.host else { return }
        guard let c = CredentialStore.get(host) else {
            showToast("Для этого сайта пароль ещё не сохранён — войди один раз вручную")
            return
        }
        let js = "window.__safuFill ? window.__safuFill(\(jsString(c.user)), \(jsString(c.pass)), false) : false"
        webView.evaluateJavaScript(js, in: loginFrame, in: .defaultClient) { [weak self] result in
            if case .success(let v) = result, (v as? Bool) == true {
                Haptics.success()
            } else {
                DispatchQueue.main.async { self?.showToast("На этой странице нет поля для пароля") }
            }
        }
    }

    private func autofill(host: String, frame: WKFrameInfo) {
        guard CredentialStore.enabled, let c = CredentialStore.get(host) else { return }
        // автонажатие «Войти» — не чаще 2 раз за 5 минут, чтобы не зациклиться при неверном пароле
        let recent = (autoAttempts[host] ?? []).filter { Date().timeIntervalSince($0) < 300 }
        let submit = CredentialStore.autoLogin && recent.count < 2
        if submit { autoAttempts[host] = recent + [Date()] }
        let js = "window.__safuFill && window.__safuFill(\(jsString(c.user)), \(jsString(c.pass)), \(submit ? "true" : "false"))"
        webView.evaluateJavaScript(js, in: frame, in: .defaultClient) { _ in }
        if submit { showToast("Вход выполняется автоматически…") }
    }

    /// Если после ввода пароля страница больше не просит пароль — вход удался, предлагаем сохранить
    private func offerToSaveIfLoggedIn() {
        guard let c = candidate else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            guard let self = self else { return }
            self.webView.evaluateJavaScript("!!document.querySelector('input[type=\"password\"]')") { result, _ in
                let stillLogin = (result as? Bool) ?? false
                guard !stillLogin else { return }
                self.candidate = nil
                if CredentialStore.get(c.host) != c { self.pendingCredential = c }
            }
        }
    }

    func saveCredential(_ c: SiteCredential) {
        CredentialStore.save(c)
        pendingCredential = nil
        showToast("Пароль сохранён")
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handle(error)
    }

    private func handle(_ error: Error) {
        update()
        let ns = error as NSError
        // отменённые переходы и «загрузка прервана» (скачивание файла) — не ошибки
        if ns.code == NSURLErrorCancelled || (ns.domain == "WebKitErrorDomain" && (ns.code == 102 || ns.code == 204)) { return }
        // сохранённая страница не открылась — тихо идём на главную сайта
        if !triedFallback, let home = homeURL {
            triedFallback = true
            webView.load(URLRequest(url: home))
            return
        }
        switch ns.code {
        case NSURLErrorNotConnectedToInternet, NSURLErrorNetworkConnectionLost:
            errorText = "Нет интернета"
        case NSURLErrorTimedOut:
            errorText = "Сайт долго не отвечает"
        case NSURLErrorCannotFindHost, NSURLErrorCannotConnectToHost, NSURLErrorDNSLookupFailed:
            errorText = "Сайт сейчас недоступен"
        case NSURLErrorServerCertificateUntrusted, NSURLErrorSecureConnectionFailed,
             NSURLErrorServerCertificateHasBadDate, NSURLErrorServerCertificateNotYetValid:
            errorText = "Проблема с защищённым соединением сайта"
        default:
            errorText = ns.localizedDescription
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let u = navigationAction.request.url, let scheme = u.scheme?.lowercased() else {
            decisionHandler(.allow); return
        }
        // почта, телефон, другие приложения — отдаём системе, но только по нажатию пользователя:
        // сайт не может сам запустить звонок или другое приложение, а нашу схему safu:// сайтам не отдаём
        if !["http", "https", "about", "blob", "data", "javascript", "file"].contains(scheme) {
            if scheme != "safu" && navigationAction.navigationType == .linkActivated {
                UIApplication.shared.open(u)
            }
            decisionHandler(.cancel)
            return
        }
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = navigationResponse.response as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition"),
           cd.lowercased().contains("attachment") {
            decisionHandler(.download)
            return
        }
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    // Ссылки с target="_blank" и всплывающие окна входа открываем в этом же окне
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil || navigationAction.targetFrame?.isMainFrame == false {
            webView.load(navigationAction.request)
        }
        return nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    // MARK: окна JavaScript (alert / confirm / prompt) — без них часть кнопок на сайтах «не работает»

    private func present(_ alert: UIAlertController) {
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first,
              var top = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController ?? scene.windows.first?.rootViewController
        else { return }
        while let p = top.presentedViewController { top = p }
        top.present(alert, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(a)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(a)
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { $0.text = defaultText }
        a.addAction(UIAlertAction(title: "Отмена", style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(a.textFields?.first?.text) })
        present(a)
    }

    // MARK: скачивание файлов → вкладка «Файлы», папка «Загрузки»

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dir = FileService.root.appendingPathComponent("Загрузки", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let dest = FileService.uniqueURL(in: dir, name: suggestedFilename.isEmpty ? "Файл" : suggestedFilename)
        downloadNames[ObjectIdentifier(download)] = dest
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) {
        let dest = downloadNames[ObjectIdentifier(download)]
        lastDownload = dest
        Haptics.success()
        showToast("Скачано: \(dest?.lastPathComponent ?? "Файл") · нажми, чтобы открыть")
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        lastDownload = nil
        showToast("Не удалось скачать файл")
    }
}

struct WebView: UIViewRepresentable {
    @ObservedObject var model: WebModel
    func makeUIView(context: Context) -> WKWebView { model.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Сайт внутри приложения. Шапка и нижняя панель — как у мини-приложений и браузера в Telegram.
/// В карточке-мини-приложении шапку рисует сама карточка (её можно тянуть вниз), здесь — только
/// страница и нижняя панель; в отдельном окне — всё вместе
struct WebScreen: View {
    let resource: Resource
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore
    @StateObject private var model: WebModel
    /// Есть — сайт живёт в карточке: шапку рисует карточка, снизу отступ под полоску «домой»
    private let embeddedInset: CGFloat?

    init(resource: Resource, model: WebModel? = nil, embeddedInset: CGFloat? = nil) {
        self.resource = resource
        _model = StateObject(wrappedValue: model ?? WebModel())
        self.embeddedInset = embeddedInset
    }
    @State private var ruzConnected = false
    @Environment(\.dismiss) private var dismiss
    @AppStorage("web.light") private var forceLight = true

    private var homeURL: URL? { URL(string: resource.url) }
    private var currentURL: URL? { model.webView.url ?? homeURL }

    var body: some View {
        VStack(spacing: 0) {
            if embeddedInset == nil {
                MiniHeader(resource: resource, onClose: close) {
                    MiniPill {
                        WebMenuItems(model: model, resource: resource)
                    }
                }
                .background(MiniChrome.headerColor.ignoresSafeArea(edges: .top))
            }
            page
            WebBottomBar(model: model, homeURL: homeURL, bottomInset: embeddedInset)
        }
        .onAppear {
            model.homeURL = homeURL
            // Многие сайты вуза плохо поддерживают тёмную тему: текст сливается с фоном
            model.webView.overrideUserInterfaceStyle = forceLight ? .light : .unspecified
            // развернули свёрнутый сайт — страница уже открыта, ничего не перезагружаем
            guard model.webView.url == nil else { return }
            // Сначала возвращаем сохранённый вход, потом открываем страницу
            let start = store.lastURL(for: resource) ?? homeURL
            if WebModel.isPlain(start?.host) { model.applyPlain(true) }
            SessionKeeper.restore(into: model.webView.configuration.websiteDataStore.httpCookieStore) {
                if let u = start { model.load(u) }
            }
        }
        .onDisappear(perform: remember)
        .alert("Сохранить пароль?", isPresented: Binding(get: { model.pendingCredential != nil },
                                                         set: { if !$0 { model.pendingCredential = nil } })) {
            Button("Сохранить") {
                if let c = model.pendingCredential { model.saveCredential(c) }
            }
            Button("Не сейчас", role: .cancel) { model.pendingCredential = nil }
        } message: {
            if let c = model.pendingCredential {
                Text("Для \(c.host)\(c.user.isEmpty ? "" : " (\(c.user))"). В следующий раз вход будет автоматическим. Пароль хранится зашифрованно только на этом iPhone.")
            }
        }
    }

    private var page: some View {
        WebView(model: model)
            .overlay(alignment: .top) {
                ZStack(alignment: .top) {
                    MiniChrome.hairline
                    WebProgressLine(model: model)
                }
            }
            .overlay { if let err = model.errorText { errorView(err) } }
            .overlay(alignment: .bottom) {
                VStack(spacing: 10) {
                    // есть форма входа и сохранённый пароль — кнопка сразу под рукой
                    if let user = model.loginUser {
                        Button {
                            model.fillPasswordNow()
                        } label: {
                            Label(user.isEmpty ? "Вставить пароль" : "Вставить пароль · \(user)", systemImage: "key.fill")
                                .font(.subheadline.weight(.semibold))
                                .lineLimit(1)
                                .foregroundStyle(.white)
                                .padding(.horizontal, 18)
                                .padding(.vertical, 12)
                                .background(Color.brand, in: Capsule())
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                    if let t = model.toast {
                        Button {
                            // скачанный файл — сразу карточкой поверх сайта, сайт уходит в свёрнутые
                            if let u = model.lastDownload, embeddedInset != nil {
                                remember()
                                model.toast = nil
                                SiteTabs.shared.openFile(u)
                            }
                        } label: {
                            Label(t, systemImage: "arrow.down.circle.fill")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 11)
                                .background(Color.black.opacity(0.78), in: Capsule())
                        }
                        .buttonStyle(PressableStyle())
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                    ruzButton
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 14)
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.86), value: model.loginUser)
            .animation(.spring(response: 0.4, dampingFraction: 0.86), value: ruzCandidate)
            .animation(.spring(response: 0.4, dampingFraction: 0.86), value: model.errorText)
            .animation(.spring(response: 0.4, dampingFraction: 0.86), value: model.toast)
    }

    private func errorView(_ text: String) -> some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 38, weight: .semibold))
                .foregroundStyle(.secondary)
            Text(text)
                .font(.headline)
                .multilineTextAlignment(.center)
            HStack(spacing: 10) {
                Button {
                    Haptics.tap()
                    model.retry()
                } label: {
                    Label("Повторить", systemImage: "arrow.clockwise")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 11)
                        .background(Color.brand, in: Capsule())
                }
                Button {
                    store.clearLastURL(for: resource)
                    model.goHome()
                } label: {
                    Label("Главная", systemImage: "house")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 11)
                        .background(Color.primary.opacity(0.08), in: Capsule())
                }
            }
            .buttonStyle(PressableStyle())
            Button { if let u = currentURL { UIApplication.shared.open(u) } } label: {
                Text("Открыть в Safari").font(.footnote.weight(.semibold))
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemBackground))
    }

    /// ID группы, если сейчас открыто расписание группы в РУЗ
    private var ruzCandidate: String? {
        guard let u = model.url, u.host?.contains("ruz.narfu.ru") == true,
              let id = RuzClient.groupID(in: u) else { return nil }
        return id
    }

    @ViewBuilder private var ruzButton: some View {
        if let id = ruzCandidate {
            if ruzConnected || (schedule.data.usesRuz && schedule.data.ruzGroupID == id) {
                Label("Это твоё расписание", systemImage: "checkmark.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 12)
                    .background(Color.black.opacity(0.78), in: Capsule())
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            } else {
                Button {
                    let number = RuzClient.groupNumber(fromTitle: model.title) ?? schedule.data.ruzGroupNumber
                    schedule.connectRuz(number: number, institution: schedule.data.ruzInstitution, id: id)
                    Task { await schedule.sync(force: true) }
                    Haptics.success()
                    withAnimation { ruzConnected = true }
                } label: {
                    Label("Сделать моим расписанием", systemImage: "calendar.badge.checkmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 13)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(PressableStyle())
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    private func remember() {
        if let u = model.webView.url { store.saveLastURL(u, for: resource) }
        SessionKeeper.save(from: model.webView.configuration.websiteDataStore.httpCookieStore)
    }

    private func close() {
        remember()
        dismiss()
    }
}

/// Тонкая полоска загрузки под шапкой — отдельным видом, чтобы прогресс не перерисовывал всю страницу
private struct WebProgressLine: View {
    @ObservedObject var model: WebModel

    var body: some View {
        GeometryReader { geo in
            Rectangle()
                .fill(Color.brand)
                .frame(width: max(12, geo.size.width * model.progress), height: 2)
                .animation(.easeOut(duration: 0.25), value: model.progress)
        }
        .frame(height: 2)
        .opacity(model.isLoading ? 1 : 0)
        .animation(.easeInOut(duration: 0.2), value: model.isLoading)
        .allowsHitTesting(false)
    }
}

/// Нижняя панель браузера: назад, вперёд, главная, обновить, поделиться
private struct WebBottomBar: View {
    @ObservedObject var model: WebModel
    let homeURL: URL?
    /// В карточке — отступ под полоску «домой» задаётся явно, в отдельном окне — системный
    let bottomInset: CGFloat?

    var body: some View {
        HStack(spacing: 0) {
            item("chevron.backward", label: "Назад", enabled: model.canGoBack || model.jsHistory) { model.back() }
            item("chevron.forward", label: "Вперёд", enabled: model.canGoForward) { model.forward() }
            item("house", label: "Главная") {
                Haptics.tap()
                model.goHome()
            }
            item(model.isLoading ? "xmark" : "arrow.clockwise", label: model.isLoading ? "Остановить" : "Обновить") {
                if model.isLoading { model.webView.stopLoading() } else { model.webView.reload() }
            }
            if let u = model.url ?? homeURL {
                ShareLink(item: u) {
                    icon("square.and.arrow.up")
                }
                .frame(maxWidth: .infinity)
                .accessibilityLabel("Поделиться")
            }
        }
        .frame(height: 46)
        .padding(.horizontal, 6)
        .padding(.bottom, bottomInset ?? 0)
        .background(MiniChrome.headerColor.ignoresSafeArea(edges: .bottom))
        .overlay(alignment: .top) { MiniChrome.hairline }
    }

    private func icon(_ name: String) -> some View {
        Image(systemName: name)
            .font(.system(size: 19, weight: .medium))
            .frame(width: 44, height: 44)
            .contentShape(Rectangle())
    }

    private func item(_ name: String, label: String, enabled: Bool = true, action: @escaping () -> Void) -> some View {
        Button(action: action) { icon(name) }
            .buttonStyle(.plain)
            .foregroundStyle(enabled ? Color.brand : Color.secondary.opacity(0.5))
            .disabled(!enabled)
            .frame(maxWidth: .infinity)
            .accessibilityLabel(label)
    }
}

/// Пункты меню «⋯» у сайта — общие для карточки и отдельного окна
struct WebMenuItems: View {
    @ObservedObject var model: WebModel
    let resource: Resource
    @EnvironmentObject private var store: ResourceStore
    @AppStorage("web.light") private var forceLight = true

    private var currentURL: URL? { model.webView.url ?? URL(string: resource.url) }

    var body: some View {
        Section(currentURL?.host ?? resource.title) {
            Button { if let u = currentURL { UIApplication.shared.open(u) } } label: {
                Label("Открыть в Safari", systemImage: "safari")
            }
            Button {
                if let u = currentURL { UIPasteboard.general.url = u }
                Haptics.success()
            } label: { Label("Скопировать ссылку", systemImage: "link") }
            Button {
                Haptics.tap()
                model.webView.reload()
            } label: { Label("Обновить", systemImage: "arrow.clockwise") }
        }
        Section {
            Button {
                model.fillPasswordNow()
            } label: {
                Label("Вставить пароль", systemImage: "key.fill")
            }
            if let host = currentURL?.host {
                let plain = WebModel.isPlain(host)
                Button {
                    WebModel.setPlain(host, !plain)
                    model.applyPlain(!plain)
                    model.webView.reload()
                    Haptics.tap()
                } label: {
                    Label(plain ? "Вернуть помощников приложения" : "Простой режим (если что-то не работает)",
                          systemImage: plain ? "wand.and.stars" : "leaf")
                }
            }
            Button {
                forceLight.toggle()
                model.webView.overrideUserInterfaceStyle = forceLight ? .light : .unspecified
            } label: {
                Label(forceLight ? "Разрешить тёмную тему сайта" : "Всегда светлый сайт",
                      systemImage: forceLight ? "moon" : "sun.max")
            }
        }
        Section {
            Button(role: .destructive) {
                store.clearLastURL(for: resource)
                model.goHome()
            } label: { Label("Начать с главной", systemImage: "house") }
        }
    }
}

// MARK: - Читаемый текст в полях ввода
// Некоторые сайты (почта Samoware) задают полям светлый текст на светлом фоне — набранное не видно.
// При фокусе и вводе сравниваем яркость текста и фона поля; если почти одинаковые — красим текст в тёмный
// (или в светлый, если фон тёмный). Остальные поля не трогаем.

enum ContrastFix {
    /// Только поля ввода: без слежки за всплывающими списками (она могла мешать подсказкам адресов в почте)
    static var inputsOnly: String { "window.__safuInputsOnly = true;\n" + source }

    static let source = """
    (function(){
      if (window.__safuContrast) return; window.__safuContrast = true;
      function rgb(s){ var m = s && s.match(/rgba?\\(([^)]+)\\)/); if(!m) return null;
        var p = m[1].split(',').map(function(x){ return parseFloat(x); });
        return { r:p[0], g:p[1], b:p[2], a: p.length > 3 ? p[3] : 1 }; }
      function lum(c){ function f(v){ v/=255; return v <= 0.03928 ? v/12.92 : Math.pow((v+0.055)/1.055, 2.4); }
        return 0.2126*f(c.r) + 0.7152*f(c.g) + 0.0722*f(c.b); }
      function bgOf(el){
        while (el && el.nodeType === 1) {
          var c = rgb(getComputedStyle(el).backgroundColor);
          if (c && c.a > 0.5) return c;
          el = el.parentElement;
        }
        return { r:255, g:255, b:255, a:1 };
      }
      function fix(el){
        if (!el || el.nodeType !== 1) return;
        var editable = el.isContentEditable || el.tagName === 'INPUT' || el.tagName === 'TEXTAREA';
        if (!editable) return;
        var cs = getComputedStyle(el);
        var fg = rgb(cs.webkitTextFillColor && cs.webkitTextFillColor !== 'currentcolor' ? cs.webkitTextFillColor : cs.color) || rgb(cs.color);
        if (!fg) return;
        var bg = bgOf(el);
        var l1 = lum(fg), l2 = lum(bg);
        var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
        if (ratio >= 2.2 && fg.a > 0.4) return;
        var c = l2 > 0.5 ? '#111111' : '#f2f2f2';
        el.style.setProperty('color', c, 'important');
        el.style.setProperty('-webkit-text-fill-color', c, 'important');
      }
      document.addEventListener('focusin', function(e){ fix(e.target); }, true);
      document.addEventListener('input', function(e){ fix(e.target); }, true);
      document.addEventListener('keyup', function(e){ fix(e.target); }, true);
      if (window.__safuInputsOnly) return;

      // Всплывающие подсказки (адреса преподавателей в почте) тоже могут прийти белым по белому.
      // Проверяем только новые элементы с текстом, не чаще раза в 150 мс и не больше 300 за раз.
      function fixText(el){
        if (!el || el.nodeType !== 1 || !el.textContent || !el.textContent.trim()) return;
        var own = false;
        for (var i = 0; i < el.childNodes.length; i++) {
          var n = el.childNodes[i];
          if (n.nodeType === 3 && n.textContent.trim()) { own = true; break; }
        }
        if (!own) return;
        var cs = getComputedStyle(el);
        if (cs.visibility === 'hidden' || cs.display === 'none') return;
        var fg = rgb(cs.color); if (!fg) return;
        var bg = bgOf(el);
        var l1 = lum(fg), l2 = lum(bg);
        var ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
        if (ratio >= 1.6) return;
        el.style.setProperty('color', l2 > 0.5 ? '#111111' : '#f2f2f2', 'important');
      }
      var queue = [];
      var timer = null;
      function flush(){
        timer = null;
        var list = queue.splice(0, queue.length);
        var n = 0;
        for (var i = 0; i < list.length && n < 300; i++) {
          var root = list[i];
          if (!root.querySelectorAll) continue;
          fixText(root); n++;
          var inner = root.querySelectorAll('*');
          for (var j = 0; j < inner.length && n < 300; j++) { fixText(inner[j]); n++; }
        }
      }
      new MutationObserver(function(ms){
        for (var i = 0; i < ms.length; i++) {
          for (var k = 0; k < ms[i].addedNodes.length; k++) {
            var a = ms[i].addedNodes[k];
            queue.push(a.nodeType === 1 ? a : a.parentElement);
          }
        }
        if (!timer && queue.length) timer = setTimeout(flush, 150);
      }).observe(document.documentElement, { childList: true, subtree: true });
    })();
    """
}
