import Foundation
import WidgetKit

final class ScheduleStore: ObservableObject {
    @Published var data: ScheduleData {
        didSet {
            snapshotCurrentWeek()
            SharedSchedule.save(data)
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
    @Published var syncing = false
    @Published var syncMessage: String?

    init() {
        data = SharedSchedule.load()
        snapshotCurrentWeek()
        SharedSchedule.save(data)
    }

    // MARK: ручное расписание

    /// Запоминаем расписание этой недели, чтобы потом можно было посмотреть его в архиве
    private func snapshotCurrentWeek() {
        guard !data.lessons.isEmpty else { return }
        let key = WeekKey.key(for: Date())
        if data.history[key] != data.lessons {
            data.history[key] = data.lessons
        }
        if data.history.count > 60 {
            let keep = Set(data.history.keys.sorted().suffix(60))
            data.history = data.history.filter { keep.contains($0.key) }
        }
    }

    var archivedWeeks: Int { data.history.count }

    func clearHistory() {
        data.history = [:]
    }

    var hasLessons: Bool { data.usesRuz ? !data.ruzEvents.isEmpty : !data.lessons.isEmpty }

    var isConfigured: Bool { data.usesRuz || !data.lessons.isEmpty }

    func contains(_ l: Lesson) -> Bool {
        data.lessons.contains { $0.id == l.id }
    }

    func upsert(_ l: Lesson) {
        if let i = data.lessons.firstIndex(where: { $0.id == l.id }) {
            data.lessons[i] = l
        } else {
            data.lessons.append(l)
        }
    }

    func delete(_ l: Lesson) {
        data.lessons.removeAll { $0.id == l.id }
    }

    func clearAll() {
        data.lessons = []
    }

    // MARK: РУЗ

    func connectRuz(number: String, institution: Int, id: String = "") {
        var d = data
        d.source = 1
        d.ruzGroupNumber = number.trimmingCharacters(in: .whitespaces)
        d.ruzInstitution = institution
        if d.ruzGroupID != id { d.ruzGroupID = id }
        d.lastSync = nil
        data = d
    }

    func useManual() {
        data.source = 0
    }

    func clearRuzCache() {
        var d = data
        d.ruzEvents = []
        d.lastSync = nil
        d.syncInfo = ""
        data = d
    }

    var lastSyncText: String {
        guard let last = data.lastSync else { return "ещё не обновлялось" }
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.unitsStyle = .full
        return "обновлено " + f.localizedString(for: last, relativeTo: Date())
    }

    @MainActor
    func sync(force: Bool = false) async {
        guard data.usesRuz, !syncing else { return }
        if !force, let last = data.lastSync, Date().timeIntervalSince(last) < 20 * 60 { return }
        syncing = true
        defer { syncing = false }
        do {
            var id = data.ruzGroupID
            if id.isEmpty {
                guard !data.ruzGroupNumber.isEmpty,
                      let found = try await RuzClient.findGroupID(number: data.ruzGroupNumber,
                                                                  institution: data.ruzInstitution) else {
                    syncMessage = "Группа \(data.ruzGroupNumber) не найдена в РУЗ. Открой РУЗ, найди свою группу и нажми «Сделать моим расписанием»."
                    data.syncInfo = syncMessage ?? ""
                    return
                }
                id = found
            }
            let r = try await RuzClient.load(groupID: id)
            var d = data
            d.ruzGroupID = id
            if !r.events.isEmpty { d.mergeRuz(r.events) }
            d.lastSync = Date()
            d.syncInfo = r.events.isEmpty
                ? (r.notice ?? "РУЗ не вернул пар на ближайшие недели")
                : "Загружено пар: \(r.events.count) · \(r.method)"
            data = d
            syncMessage = d.syncInfo
        } catch {
            syncMessage = "Нет связи с РУЗ, показываю сохранённое расписание"
        }
    }
}
