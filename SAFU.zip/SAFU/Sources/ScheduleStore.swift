import Foundation
import WidgetKit

final class ScheduleStore: ObservableObject {
    @Published var data: ScheduleData {
        didSet {
            snapshotCurrentWeek()
            schedulePersist()
            scheduleSideEffects()
        }
    }
    private var persistWork: DispatchWorkItem?
    private static let persistQueue = DispatchQueue(label: "safu.schedule.persist", qos: .utility)

    /// Сохранение на диск и обновление виджета — пачкой и в фоне, а не на каждое изменение
    private func schedulePersist() {
        persistWork?.cancel()
        let snapshot = data
        let work = DispatchWorkItem {
            SharedSchedule.save(snapshot)
            DispatchQueue.main.async { WidgetCenter.shared.reloadAllTimelines() }
        }
        persistWork = work
        ScheduleStore.persistQueue.asyncAfter(deadline: .now() + 0.4, execute: work)
    }
    @Published var syncing = false
    @Published var syncMessage: String?
    /// Журнал изменений расписания из РУЗ
    @Published var changes: [ScheduleChange] = [] {
        didSet {
            if let d = try? JSONEncoder().encode(changes) { UserDefaults.standard.set(d, forKey: "schedule.changes") }
        }
    }
    @Published var unseenChanges = UserDefaults.standard.integer(forKey: "schedule.unseen") {
        didSet { UserDefaults.standard.set(unseenChanges, forKey: "schedule.unseen") }
    }
    private var sideEffectsWork: DispatchWorkItem?
    @Published var loadingWeek = false
    private var triedWeeks = Set<String>()

    init() {
        data = SharedSchedule.load()
        if let raw = UserDefaults.standard.data(forKey: "schedule.changes"),
           let list = try? JSONDecoder().decode([ScheduleChange].self, from: raw) {
            changes = list
        }
        // один раз очищаем журнал: там были ложные «изменения» из-за смены источника (iCal → страница)
        if !UserDefaults.standard.bool(forKey: "changes.reset.v57") {
            changes = []
            unseenChanges = 0
            UserDefaults.standard.set(true, forKey: "changes.reset.v57")
            UserDefaults.standard.removeObject(forKey: "schedule.changes")
            UserDefaults.standard.set(0, forKey: "schedule.unseen")
        }
        snapshotCurrentWeek()
        SharedSchedule.save(data)
    }

    /// Напоминания о парах и Live Activity — пересчитываем после изменений (с задержкой, чтобы не дёргать часто)
    func scheduleSideEffects() {
        sideEffectsWork?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.refreshSideEffects() }
        sideEffectsWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: work)
    }

    func refreshSideEffects() {
        PairNotifier.reschedule(data: data)
        LiveActivityManager.update(data: data)
        SubjectFolders.ensureAll(ScheduleQuery.subjects(data))
        CommutePlanner.scheduleNotifications(data: data)
        WeeklyDigest.schedule(data: data)
        MorningBrief.schedule(data: data)
        BusLiveManager.auto(data: data)
    }

    // MARK: память прошлых недель (РУЗ)

    func hasEvents(inWeekOf date: Date) -> Bool {
        let monday = WeekKey.monday(of: date)
        let end = monday.addingTimeInterval(7 * 86_400)
        return data.ruzEvents.contains { $0.start >= monday && $0.start < end }
    }

    /// С какой даты приложение помнит расписание
    var memorySince: Date? { data.ruzEvents.first?.start }

    var rememberedWeeks: Int {
        Set(data.ruzEvents.map { WeekKey.key(for: $0.start) }).count
    }

    /// Пробуем дозагрузить прошлую неделю из РУЗ (один раз за запуск для каждой недели)
    @MainActor
    func loadArchiveWeek(_ date: Date) async {
        guard data.usesRuz, !data.ruzGroupID.isEmpty, !hasEvents(inWeekOf: date) else { return }
        let key = WeekKey.key(for: date)
        guard !triedWeeks.contains(key) else { return }
        triedWeeks.insert(key)
        loadingWeek = true
        defer { loadingWeek = false }
        let events = await RuzClient.loadWeek(groupID: data.ruzGroupID, monday: WeekKey.monday(of: date))
        guard !events.isEmpty else { return }
        var d = data
        d.mergeRuz(events)
        data = d
    }

    func markChangesSeen() {
        unseenChanges = 0
    }

    func clearChanges() {
        changes = []
        unseenChanges = 0
    }

    // MARK: ручное расписание

    /// Запоминаем расписание этой недели, чтобы потом можно было посмотреть его в архиве
    private func snapshotCurrentWeek() {
        guard !data.lessons.isEmpty else { return }
        let key = WeekKey.key(for: Date())
        if data.history[key] != data.lessons {
            data.history[key] = data.lessons
        }
        if data.history.count > 60 {
            let keep = Set(data.history.keys.sorted().suffix(60))
            data.history = data.history.filter { keep.contains($0.key) }
        }
    }

    var archivedWeeks: Int { data.history.count }

    func clearHistory() {
        data.history = [:]
    }

    var hasLessons: Bool { data.usesRuz ? !data.ruzEvents.isEmpty : !data.lessons.isEmpty }

    var isConfigured: Bool { data.usesRuz || !data.lessons.isEmpty }

    func contains(_ l: Lesson) -> Bool {
        data.lessons.contains { $0.id == l.id }
    }

    func upsert(_ l: Lesson) {
        if let i = data.lessons.firstIndex(where: { $0.id == l.id }) {
            data.lessons[i] = l
        } else {
            data.lessons.append(l)
        }
    }

    func delete(_ l: Lesson) {
        data.lessons.removeAll { $0.id == l.id }
    }

    func clearAll() {
        data.lessons = []
    }

    // MARK: РУЗ

    func connectRuz(number: String, institution: Int, id: String = "") {
        var d = data
        let newNumber = number.trimmingCharacters(in: .whitespaces)
        // другая группа — её пары не смешиваем со старой памятью
        if !d.ruzGroupNumber.isEmpty && d.ruzGroupNumber != newNumber { d.ruzEvents = [] }
        d.source = 1
        d.ruzGroupNumber = newNumber
        d.ruzInstitution = institution
        if d.ruzGroupID != id { d.ruzGroupID = id }
        d.lastSync = nil
        data = d
    }

    func useManual() {
        data.source = 0
    }

    func clearRuzCache() {
        var d = data
        d.ruzEvents = []
        d.lastSync = nil
        d.syncInfo = ""
        data = d
    }

    var lastSyncText: String {
        guard let last = data.lastSync else { return "ещё не обновлялось" }
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.unitsStyle = .full
        return "обновлено " + f.localizedString(for: last, relativeTo: Date())
    }

    @MainActor
    func sync(force: Bool = false) async {
        guard data.usesRuz, !syncing else { return }
        if !force, let last = data.lastSync, Date().timeIntervalSince(last) < 20 * 60 { return }
        syncing = true
        defer { syncing = false }
        do {
            var id = data.ruzGroupID
            if id.isEmpty {
                guard !data.ruzGroupNumber.isEmpty,
                      let found = try await RuzClient.findGroupID(number: data.ruzGroupNumber,
                                                                  institution: data.ruzInstitution) else {
                    syncMessage = "Группа \(data.ruzGroupNumber) не найдена в РУЗ. Открой РУЗ, найди свою группу и нажми «Сделать моим расписанием»."
                    data.syncInfo = syncMessage ?? ""
                    return
                }
                id = found
            }
            let r = try await RuzClient.load(groupID: id)
            var d = data
            let before = ChangeDetector.upcoming(data)
            d.ruzGroupID = id
            if !r.events.isEmpty { d.mergeRuz(r.events) }
            // сравниваем с тем, что было, и сообщаем об изменениях
            // сравниваем, только если источник тот же (страница РУЗ и iCal по-разному пишут аудитории)
            let lastMethod = UserDefaults.standard.string(forKey: "ruz.lastMethod")
            UserDefaults.standard.set(r.method, forKey: "ruz.lastMethod")
            if !before.isEmpty && !r.events.isEmpty && lastMethod == r.method {
                let found = ChangeDetector.diff(before: before, after: ChangeDetector.upcoming(d))
                if !found.isEmpty {
                    changes = Array((found + changes).prefix(50))
                    unseenChanges += found.count
                    ChangeDetector.notify(found)
                }
            }
            d.lastSync = Date()
            d.syncInfo = r.events.isEmpty
                ? (r.notice ?? "РУЗ не вернул пар на ближайшие недели")
                : "Загружено пар: \(r.events.count) · \(r.method)"
            data = d
            syncMessage = d.syncInfo
        } catch {
            syncMessage = "Нет связи с РУЗ, показываю сохранённое расписание"
        }
    }
}
