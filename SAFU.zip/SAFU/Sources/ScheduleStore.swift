import Foundation
import WidgetKit

final class ScheduleStore: ObservableObject {
    @Published var data: ScheduleData {
        didSet {
            snapshotCurrentWeek()
            SharedSchedule.save(data)
            WidgetCenter.shared.reloadAllTimelines()
        }
    }

    init() {
        data = SharedSchedule.load()
        snapshotCurrentWeek()
        SharedSchedule.save(data)
    }

    /// Запоминаем расписание этой недели, чтобы потом можно было посмотреть его в архиве
    private func snapshotCurrentWeek() {
        guard !data.lessons.isEmpty else { return }
        let key = WeekKey.key(for: Date())
        if data.history[key] != data.lessons {
            data.history[key] = data.lessons
        }
        // храним не больше года
        if data.history.count > 60 {
            let keep = Set(data.history.keys.sorted().suffix(60))
            data.history = data.history.filter { keep.contains($0.key) }
        }
    }

    var archivedWeeks: Int { data.history.count }

    func clearHistory() {
        data.history = [:]
    }

    var hasLessons: Bool { !data.lessons.isEmpty }

    func contains(_ l: Lesson) -> Bool {
        data.lessons.contains { $0.id == l.id }
    }

    func upsert(_ l: Lesson) {
        if let i = data.lessons.firstIndex(where: { $0.id == l.id }) {
            data.lessons[i] = l
        } else {
            data.lessons.append(l)
        }
    }

    func delete(_ l: Lesson) {
        data.lessons.removeAll { $0.id == l.id }
    }

    func lessonsCount(on weekday: Int) -> Int {
        data.lessons.filter { $0.weekday == weekday }.count
    }

    func clearAll() {
        data.lessons = []
    }
}
