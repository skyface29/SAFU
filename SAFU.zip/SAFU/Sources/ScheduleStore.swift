import Foundation
import WidgetKit

final class ScheduleStore: ObservableObject {
    @Published var data: ScheduleData {
        didSet {
            snapshotCurrentWeek()
            schedulePersist()
            scheduleSideEffects()
        }
    }
    private var persistWork: DispatchWorkItem?
    private static let persistQueue = DispatchQueue(label: "safu.schedule.persist", qos: .utility)

    /// Сохранение на диск и обновление виджета — пачкой и в фоне, а не на каждое изменение
    private func schedulePersist() {
        persistWork?.cancel()
        let snapshot = data
        let work = DispatchWorkItem {
            SharedSchedule.save(snapshot)
            RuzArchive.save(snapshot)            // прошлые пары — ещё и в отдельный файл-архив
            DispatchQueue.main.async {
                WidgetBridge.publish(snapshot)          // виджету — группа и пары (App Groups после переподписи не работают)
                WidgetCenter.shared.reloadAllTimelines()
            }
        }
        persistWork = work
        ScheduleStore.persistQueue.asyncAfter(deadline: .now() + 0.4, execute: work)
    }
    @Published var syncing = false
    @Published var syncMessage: String?
    /// Сбор расписания преподавателя по группам школы: 0…1, nil — не идёт
    @Published var teacherProgress: Double?
    /// Журнал изменений расписания из РУЗ
    @Published var changes: [ScheduleChange] = [] {
        didSet {
            if let d = try? JSONEncoder().encode(changes) { UserDefaults.standard.set(d, forKey: "schedule.changes") }
        }
    }
    @Published var unseenChanges = UserDefaults.standard.integer(forKey: "schedule.unseen") {
        didSet { UserDefaults.standard.set(unseenChanges, forKey: "schedule.unseen") }
    }
    private var sideEffectsWork: DispatchWorkItem?
    @Published var loadingWeek = false
    private var triedWeeks = Set<String>()

    init() {
        data = SharedSchedule.load()
        if let raw = UserDefaults.standard.data(forKey: "schedule.changes"),
           let list = try? JSONDecoder().decode([ScheduleChange].self, from: raw) {
            changes = list
        }
        // один раз очищаем журнал: там были ложные «изменения» из-за смены источника (iCal → страница)
        if !UserDefaults.standard.bool(forKey: "changes.reset.v57") {
            changes = []
            unseenChanges = 0
            UserDefaults.standard.set(true, forKey: "changes.reset.v57")
            UserDefaults.standard.removeObject(forKey: "schedule.changes")
            UserDefaults.standard.set(0, forKey: "schedule.unseen")
        }
        // 7.6.1: поиск свободных аудиторий мог подмешать чужую группу — чистим память РУЗ
        // и заново находим группу по номеру
        if !UserDefaults.standard.bool(forKey: "repair.ruz.v761") {
            UserDefaults.standard.set(true, forKey: "repair.ruz.v761")
            var d = data
            if d.usesRuz {
                d.ruzEvents = []
                d.lastSync = nil
                d.syncInfo = ""
                if !d.ruzGroupNumber.trimmingCharacters(in: .whitespaces).isEmpty { d.ruzGroupID = "" }
                data = d
            }
            changes = []
            unseenChanges = 0
            UserDefaults.standard.removeObject(forKey: "schedule.changes")
            UserDefaults.standard.set(0, forKey: "schedule.unseen")
            UserDefaults.standard.removeObject(forKey: "ruz.lastMethod")
        }
        snapshotCurrentWeek()
        // память прошлых недель: если в основном хранилище чего-то не хватает — достаём из архива
        var restored = data
        if restored.usesRuz, restored.restorePast(RuzArchive.load(for: restored)) > 0 {
            data = restored
        }
        // запись на диск — в фоне: раньше всё расписание кодировалось и писалось дважды
        // прямо при запуске, ещё до первого кадра
        let snapshot = data
        ScheduleStore.persistQueue.async {
            SharedSchedule.save(snapshot)
            RuzArchive.save(snapshot)
        }
    }

    /// Напоминания о парах и Live Activity — пересчитываем после изменений (с задержкой, чтобы не дёргать часто)
    func scheduleSideEffects() {
        sideEffectsWork?.cancel()
        let work = DispatchWorkItem { [weak self] in self?.refreshSideEffects() }
        sideEffectsWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: work)
    }

    func refreshSideEffects() {
        let snapshot = data
        PairNotifier.reschedule(data: snapshot)
        LiveActivityManager.update(data: snapshot)
        CommutePlanner.scheduleNotifications(data: snapshot)
        MorningBrief.schedule(data: snapshot)
        BusLiveManager.auto(data: snapshot)
        WakePlanner.schedule(data: snapshot)
        // папки предметов и недельная сводка — диск и разбор данных, главному потоку это не нужно
        DispatchQueue.global(qos: .utility).async {
            SubjectFolders.ensureAll(ScheduleQuery.subjects(snapshot))
            WeeklyDigest.schedule(data: snapshot)
        }
    }

    // MARK: память прошлых недель (РУЗ)

    func hasEvents(inWeekOf date: Date) -> Bool {
        let monday = WeekKey.monday(of: date)
        let end = monday.addingTimeInterval(7 * 86_400)
        return data.ruzEvents.contains { $0.start >= monday && $0.start < end }
    }

    /// С какой даты приложение помнит расписание
    var memorySince: Date? { data.ruzEvents.first?.start }

    var rememberedWeeks: Int {
        Set(data.ruzEvents.map { WeekKey.key(for: $0.start) }).count
    }

    /// Пробуем дозагрузить прошлую неделю из РУЗ (один раз за запуск для каждой недели)
    @MainActor
    func loadArchiveWeek(_ date: Date) async {
        guard data.usesRuz, !data.ruzGroupID.isEmpty, !hasEvents(inWeekOf: date) else { return }
        let key = WeekKey.key(for: date)
        guard !triedWeeks.contains(key) else { return }
        triedWeeks.insert(key)
        loadingWeek = true
        defer { loadingWeek = false }
        let events = await RuzClient.loadWeek(groupID: data.ruzGroupID, monday: WeekKey.monday(of: date))
        guard !events.isEmpty else { return }
        var d = data
        d.mergeRuz(events)
        data = d
    }

    /// Фоновая проверка могла обновить расписание и журнал замен, пока приложение спало
    /// Расписание с диска (его могла обновить фоновая проверка). Читается и разбирается в фоне:
    /// раньше это шло в главном потоке ровно в момент возвращения в приложение — и давало рывок
    func reloadFromDisk() {
        let known = data.lastSync ?? .distantPast
        DispatchQueue.global(qos: .userInitiated).async {
            var stored = SharedSchedule.load()
            guard let s = stored.lastSync, s > known else { return }
            if stored.usesRuz { stored.restorePast(RuzArchive.load(for: stored)) }
            var list: [ScheduleChange]?
            if let raw = UserDefaults.standard.data(forKey: "schedule.changes") {
                list = try? JSONDecoder().decode([ScheduleChange].self, from: raw)
            }
            DispatchQueue.main.async { [weak self] in
                // пока читали, расписание могло обновиться из РУЗ — тогда оно свежее
                guard let self, s > (self.data.lastSync ?? .distantPast) else { return }
                self.data = stored
                if let list { self.changes = list }
                self.unseenChanges = UserDefaults.standard.integer(forKey: "schedule.unseen")
            }
        }
    }

    /// Проверка РУЗ в фоне: приложение закрыто, а о заменах и отменах приходит уведомление
    static func backgroundSync() async {
        var d = SharedSchedule.load()
        guard d.usesRuz, !d.ruzGroupID.isEmpty else { return }
        if let last = d.lastSync, Date().timeIntervalSince(last) < 30 * 60 { return }
        let oldTimeout = RuzClient.requestTimeout
        let oldICS = RuzClient.useICS
        RuzClient.requestTimeout = 15      // у фоновой задачи мало времени
        RuzClient.useICS = false
        defer {
            RuzClient.requestTimeout = oldTimeout
            RuzClient.useICS = oldICS
        }
        guard let r = try? await RuzClient.load(groupID: d.ruzGroupID), !r.events.isEmpty else { return }
        let before = ChangeDetector.upcoming(d)
        d.mergeRuz(r.events)
        let defaults = UserDefaults.standard
        if !before.isEmpty && defaults.string(forKey: "ruz.lastMethod") == r.method {
            let found = ChangeDetector.diff(before: before, after: ChangeDetector.upcoming(d))
            if !found.isEmpty {
                var list: [ScheduleChange] = []
                if let raw = defaults.data(forKey: "schedule.changes"),
                   let old = try? JSONDecoder().decode([ScheduleChange].self, from: raw) { list = old }
                list = Array((found + list).prefix(50))
                if let enc = try? JSONEncoder().encode(list) { defaults.set(enc, forKey: "schedule.changes") }
                defaults.set(defaults.integer(forKey: "schedule.unseen") + found.count, forKey: "schedule.unseen")
                ChangeDetector.notify(found)
            }
        }
        defaults.set(r.method, forKey: "ruz.lastMethod")
        d.lastSync = Date()
        d.syncInfo = L("Загружено пар: \(r.events.count) · \(r.method)")
        d.restorePast(RuzArchive.load(for: d))
        SharedSchedule.save(d)
        RuzArchive.save(d)
    }

    func markChangesSeen() {
        unseenChanges = 0
    }

    func clearChanges() {
        changes = []
        unseenChanges = 0
    }

    // MARK: ручное расписание

    /// Запоминаем расписание этой недели, чтобы потом можно было посмотреть его в архиве
    private func snapshotCurrentWeek() {
        guard !data.lessons.isEmpty else { return }
        let key = WeekKey.key(for: Date())
        if data.history[key] != data.lessons {
            data.history[key] = data.lessons
        }
        if data.history.count > 60 {
            let keep = Set(data.history.keys.sorted().suffix(60))
            data.history = data.history.filter { keep.contains($0.key) }
        }
    }

    var archivedWeeks: Int { data.history.count }

    func clearHistory() {
        data.history = [:]
    }

    var hasLessons: Bool { data.usesRuz ? !data.ruzEvents.isEmpty : !data.lessons.isEmpty }

    var isConfigured: Bool { data.usesRuz || !data.lessons.isEmpty }

    func contains(_ l: Lesson) -> Bool {
        data.lessons.contains { $0.id == l.id }
    }

    func upsert(_ l: Lesson) {
        if let i = data.lessons.firstIndex(where: { $0.id == l.id }) {
            data.lessons[i] = l
        } else {
            data.lessons.append(l)
        }
    }

    func delete(_ l: Lesson) {
        data.lessons.removeAll { $0.id == l.id }
    }

    func clearAll() {
        data.lessons = []
    }

    // MARK: РУЗ

    func connectRuz(number: String, institution: Int, id: String = "") {
        var d = data
        let newNumber = number.trimmingCharacters(in: .whitespaces)
        // другая группа — её пары не смешиваем со старой памятью
        if !d.ruzGroupNumber.isEmpty && d.ruzGroupNumber != newNumber { d.ruzEvents = [] }
        d.source = 1
        d.ruzGroupNumber = newNumber
        d.ruzInstitution = institution
        if d.ruzGroupID != id { d.ruzGroupID = id }
        d.lastSync = nil
        data = d
    }

    /// Преподаватель: своя школа, без группы — пары соберёт sync()
    func connectTeacher(institution: Int) {
        var d = data
        if d.ruzInstitution != institution || !d.ruzGroupNumber.isEmpty { d.ruzEvents = [] }
        d.source = 1
        d.ruzGroupNumber = ""
        d.ruzGroupID = ""
        d.ruzInstitution = institution
        d.lastSync = nil
        data = d
    }

    func useManual() {
        data.source = 0
    }

    func clearRuzCache() {
        RuzArchive.remove(for: data)      // «Очистить память» — по просьбе, значит и архив тоже
        var d = data
        d.ruzEvents = []
        d.lastSync = nil
        d.syncInfo = ""
        data = d
    }

    /// Один на всё приложение: подпись читается при каждой отрисовке «Пар», а форматтер создавать дорого
    private static let relative: RelativeDateTimeFormatter = {
        let f = RelativeDateTimeFormatter()
        f.locale = Lang.locale
        f.unitsStyle = .full
        return f
    }()

    var lastSyncText: String {
        guard let last = data.lastSync else { return L("ещё не обновлялось") }
        return L("обновлено ") + Self.relative.localizedString(for: last, relativeTo: Date())
    }

    @MainActor
    func sync(force: Bool = false) async {
        guard data.usesRuz, !syncing else { return }
        if !force, let last = data.lastSync, Date().timeIntervalSince(last) < 20 * 60 { return }
        // преподаватель: пары собираются из расписаний всех групп школы — это дольше, поэтому не чаще раза в 3 часа
        if TeacherMode.isOn {
            if !force, let last = data.lastSync, Date().timeIntervalSince(last) < 3 * 3600 { return }
            syncing = true
            defer { syncing = false }
            do {
                let r = try await TeacherMode.scan(institution: data.ruzInstitution, query: TeacherMode.query, force: force) { done, total in
                    self.teacherProgress = total > 0 ? Double(done) / Double(total) : 0
                }
                teacherProgress = nil
                var d = data
                if !r.events.isEmpty { d.mergeRuz(r.events) }
                d.lastSync = Date()
                d.syncInfo = r.events.isEmpty
                    ? L("В РУЗ не нашлось пар преподавателя «\(TeacherMode.query)»")
                    : L("Пар: \(r.events.count) · групп: \(r.groups.count)")
                data = d
                syncMessage = d.syncInfo
            } catch {
                teacherProgress = nil
                syncMessage = (error.localizedDescription.isEmpty ? L("Нет связи с РУЗ") : error.localizedDescription)
                    + L(", показываю сохранённое расписание")
            }
            return
        }
        syncing = true
        defer { syncing = false }
        do {
            var id = data.ruzGroupID
            if id.isEmpty {
                guard !data.ruzGroupNumber.isEmpty,
                      let found = try await RuzClient.findGroupID(number: data.ruzGroupNumber,
                                                                  institution: data.ruzInstitution) else {
                    syncMessage = L("Группа \(data.ruzGroupNumber) не найдена в РУЗ. Открой РУЗ, найди свою группу и нажми «Сделать моим расписанием».")
                    data.syncInfo = syncMessage ?? ""
                    return
                }
                id = found
            }
            let r = try await RuzClient.load(groupID: id)
            var d = data
            let before = ChangeDetector.upcoming(data)
            d.ruzGroupID = id
            if !r.events.isEmpty { d.mergeRuz(r.events) }
            // сравниваем с тем, что было, и сообщаем об изменениях
            // сравниваем, только если источник тот же (страница РУЗ и iCal по-разному пишут аудитории)
            let lastMethod = UserDefaults.standard.string(forKey: "ruz.lastMethod")
            UserDefaults.standard.set(r.method, forKey: "ruz.lastMethod")
            if !before.isEmpty && !r.events.isEmpty && lastMethod == r.method {
                let found = ChangeDetector.diff(before: before, after: ChangeDetector.upcoming(d))
                if !found.isEmpty {
                    changes = Array((found + changes).prefix(50))
                    unseenChanges += found.count
                    ChangeDetector.notify(found)
                }
            }
            d.lastSync = Date()
            d.syncInfo = r.events.isEmpty
                ? (r.notice ?? L("РУЗ не вернул пар на ближайшие недели"))
                : L("Загружено пар: \(r.events.count) · \(r.method)")
            data = d
            syncMessage = d.syncInfo
        } catch {
            syncMessage = L("Нет связи с РУЗ, показываю сохранённое расписание")
        }
    }
}


// MARK: - Архив прошлых пар (отдельный файл на устройстве)
//
// Прошлые недели важны (что было, где, у кого), а основное хранилище — одна большая запись в настройках,
// которую могут перезаписать синхронизация, сбой или восстановление. Поэтому прошлые пары дополнительно
// копятся в файле: только добавляются, никогда не удаляются сами. Для каждой группы — свой файл.

enum RuzArchive {
    private static let queue = DispatchQueue(label: "safu.ruz.archive", qos: .utility)

    private static func url(for data: ScheduleData) -> URL? {
        let group = data.ruzGroupNumber.trimmingCharacters(in: .whitespaces)
        guard !group.isEmpty else { return nil }
        let safe = group.filter { $0.isLetter || $0.isNumber }
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
        guard let dir = base?.appendingPathComponent("RuzArchive", isDirectory: true) else { return nil }
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("group-\(safe).json")
    }

    static func load(for data: ScheduleData) -> [RuzEvent] {
        guard let u = url(for: data), let raw = try? Data(contentsOf: u),
              let list = try? JSONDecoder().decode([RuzEvent].self, from: raw) else { return [] }
        return list
    }

    /// Дописать в архив прошедшие пары, которых там ещё нет (сегодняшние и будущие не храним — они меняются)
    static func save(_ data: ScheduleData) {
        guard data.usesRuz, !TeacherMode.isOn, !data.ruzEvents.isEmpty, let u = url(for: data) else { return }
        let snapshot = data
        queue.async {
            let cal = Calendar.current
            let today = cal.startOfDay(for: Date())
            var archive = RuzArchive.load(for: snapshot)
            let archivedDays = Set(archive.map { cal.startOfDay(for: $0.start) })
            // день попадает в архив целиком и один раз — так не бывает дублей и «половинок»
            let add = snapshot.ruzEvents.filter {
                let d = cal.startOfDay(for: $0.start)
                return d < today && !archivedDays.contains(d)
            }
            guard !add.isEmpty else { return }
            archive = (archive + add).sorted { $0.start < $1.start }
            if let raw = try? JSONEncoder().encode(archive) {
                try? raw.write(to: u, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            }
        }
    }

    static func remove(for data: ScheduleData) {
        guard let u = url(for: data) else { return }
        queue.async { try? FileManager.default.removeItem(at: u) }
    }
}
