import SwiftUI
import Combine
import WebKit
import QuickLook
import QuickLookThumbnailing
import LocalAuthentication

// MARK: - Сайты и файлы как мини-приложения
//
// Сайт или файл открывается карточкой на весь экран, приложение под ней темнеет.
// Шапка как у мини-приложений Telegram: крестик слева, название по центру, справа капсула «⌄ ⋯».
// Потянул шапку вниз или нажал «⌄» — карточка уменьшается и улетает в своё мини-окошко над вкладками.
// Вход, прокрутка, открытая страница PDF — всё остаётся на месте. Окошки стоят в ряд, в каждом —
// шапка и страница, какой её оставили, в углу значок сайта. Нажал окошко — окно вырастает из него,
// потянул вверх — растёт прямо под пальцем, смахнул вниз — закрыл. Больше четырёх — слева пачка «+N»,
// она открывает стопку всех окон с наклоном назад, как в Telegram.
//
// Плавность. Все переходы — пружины Core Animation: их считает системный рендер-сервер, а не приложение,
// поэтому кадры не теряются, даже если приложение в этот миг занято. На время движения живая страница
// подменяется своей неподвижной копией и прячется — двигается одна лёгкая картинка, а не весь WebKit.

enum MiniAnim {
    static let open = Animation.spring(response: 0.42, dampingFraction: 0.92)
    static let close = Animation.spring(response: 0.34, dampingFraction: 1)
    static let stack = Animation.spring(response: 0.44, dampingFraction: 0.88)
    static let quick = Animation.spring(response: 0.28, dampingFraction: 0.88)
    /// Окошки в ряду расступаются и съезжаются
    static let dock = Animation.spring(response: 0.4, dampingFraction: 0.84)
}

/// Размеры и цвета «хрома» мини-приложений — одни и те же у карточки, окошек и стопки,
/// поэтому переходы между ними совпадают до точки
enum MiniChrome {
    static let header: CGFloat = 54
    /// Зазор между статус-баром и развёрнутой карточкой
    static let topGap: CGFloat = 8
    static let radius: CGFloat = 22

    private static let headerUI = UIColor { t in
        t.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor(white: 0.975, alpha: 1)
    }
    static var headerColor: Color { Color(uiColor: headerUI) }
    static var headerUIColor: UIColor { headerUI }

    static var hairline: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.1))
            .frame(height: 0.5)
            .allowsHitTesting(false)
    }
}

/// Мини-окошки свёрнутых над вкладками. Одна и та же раскладка у ряда, у карточки, которая в него летит,
/// и у стопки, которая из него вылетает, — поэтому все переходы встают точно в окошко
enum MiniDock {
    static let w: CGFloat = 56
    static let h: CGFloat = 78
    static let gap: CGFloat = 12
    static let radius: CGFloat = 12
    /// Сколько окошек видно в ряду; остальные — в пачке «+N» слева
    static let maxShown = 4
    /// Низ окошек над нижним краем слоя (над вкладками)
    static let lift: CGFloat = 62

    struct Layout {
        var rects: [UUID: CGRect] = [:]
        /// Пачка «+N», если окон больше, чем помещается
        var overflow: CGRect?
        var hidden = 0
        /// Весь ряд
        var frame: CGRect = .zero
    }

    /// ids — по порядку, последний самый свежий: он справа
    static func layout(_ ids: [UUID], width: CGFloat, top: CGFloat) -> Layout {
        var out = Layout()
        guard !ids.isEmpty else { return out }
        let shown = ids.suffix(maxShown)
        out.hidden = ids.count - shown.count
        let m = shown.count + (out.hidden > 0 ? 1 : 0)
        let total = CGFloat(m) * w + CGFloat(m - 1) * gap
        var x = (width - total) / 2
        out.frame = CGRect(x: x, y: top, width: total, height: h)
        if out.hidden > 0 {
            out.overflow = CGRect(x: x, y: top, width: w, height: h)
            x += w + gap
        }
        for id in shown {
            out.rects[id] = CGRect(x: x, y: top, width: w, height: h)
            x += w + gap
        }
        return out
    }

    /// Во сколько раз окно уменьшается в окошке
    static func scale(_ screenW: CGFloat) -> CGFloat { w / max(screenW, 1) }
    /// Сколько окна (в его собственных точках) видно в окошке: шапка и верх страницы
    static func crop(_ screenW: CGFloat) -> CGFloat { h / scale(screenW) }
}

/// Отдельная от Haptics «твёрдая» отдача — щелчок, когда карточку дотянули до сворачивания
enum SiteHaptics {
    private static let rigidGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .rigid)
        g.prepare()
        return g
    }()
    private static let softGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .soft)
        g.prepare()
        return g
    }()
    private static var enabled: Bool { UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }

    static func rigid() {
        guard enabled else { return }
        rigidGen.impactOccurred(intensity: 0.75)
        rigidGen.prepare()
    }

    /// Мягкий толчок: окно приземлилось в своё окошко
    static func soft() {
        guard enabled else { return }
        softGen.impactOccurred(intensity: 0.55)
        softGen.prepare()
    }
}

// MARK: - Вид файла: значок, цвет, подпись

enum FileLook {
    static func ext(_ url: URL) -> String { url.pathExtension.lowercased() }

    static func icon(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt", "pages", "md": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods", "numbers": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled.fill"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "photo.fill"
        case "mp4", "mov", "m4v": return "play.rectangle.fill"
        case "mp3", "m4a", "wav", "aac": return "waveform"
        case "zip", "rar", "7z": return "archivebox.fill"
        default: return "doc.fill"
        }
    }

    static func color(_ url: URL) -> Color {
        switch ext(url) {
        case "pdf": return Color(red: 0.93, green: 0.27, blue: 0.27)
        case "doc", "docx", "rtf", "odt", "pages": return Color(red: 0.20, green: 0.45, blue: 0.95)
        case "txt", "md": return Color(red: 0.45, green: 0.50, blue: 0.60)
        case "xls", "xlsx", "csv", "ods", "numbers": return Color(red: 0.13, green: 0.65, blue: 0.38)
        case "ppt", "pptx", "key", "odp": return Color(red: 0.97, green: 0.52, blue: 0.16)
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return Color(red: 0.62, green: 0.38, blue: 0.95)
        case "mp4", "mov", "m4v", "mp3", "m4a", "wav", "aac": return Color(red: 0.92, green: 0.30, blue: 0.62)
        default: return Color(red: 0.40, green: 0.48, blue: 0.62)
        }
    }

    static func kind(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "PDF"
        case "doc", "docx", "rtf", "odt", "pages": return "Документ"
        case "txt", "md": return "Текст"
        case "xls", "xlsx", "csv", "ods", "numbers": return "Таблица"
        case "ppt", "pptx", "key", "odp": return "Презентация"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "Фото"
        case "mp4", "mov", "m4v": return "Видео"
        case "mp3", "m4a", "wav", "aac": return "Аудио"
        case "": return "Файл"
        default: return ext(url).uppercased()
        }
    }

    /// «PDF · 2,4 МБ»
    static func meta(_ url: URL) -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        guard size > 0 else { return kind(url) }
        return kind(url) + " · " + ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    /// Файл в виде «ресурса»: так у него та же шапка, значок и цвет, что у сайтов
    static func resource(_ url: URL) -> Resource {
        Resource(title: url.deletingPathExtension().lastPathComponent,
                 subtitle: meta(url),
                 url: url.absoluteString,
                 icon: icon(url),
                 category: "Файлы")
    }

    static func canPrint(_ url: URL) -> Bool { UIPrintInteractionController.canPrint(url) }

    static func printFile(_ url: URL) {
        let c = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = ["jpg", "jpeg", "png", "heic", "webp", "tiff"].contains(ext(url)) ? .photo : .general
        info.jobName = url.lastPathComponent
        c.printInfo = info
        c.printingItem = url
        _ = c.present(animated: true, completionHandler: nil)
    }

    /// Положить сам файл в буфер обмена — вставляется в Telegram, почту, Заметки
    static func copy(_ url: URL) {
        guard let p = NSItemProvider(contentsOf: url) else { return }
        UIPasteboard.general.itemProviders = [p]
        Haptics.success()
    }

    /// Снимок без содержимого (QuickLook иногда рисуется в другом процессе и снимается пустым)
    static func isBlank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage else { return true }
        let w = 24, h = 24
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return false }
        var lo = [255, 255, 255], hi = [0, 0, 0]
        for i in 0..<(w * h) {
            for c in 0..<3 {
                let v = Int(px[i * 4 + c])
                lo[c] = min(lo[c], v)
                hi[c] = max(hi[c], v)
            }
        }
        return (0..<3).allSatisfy { hi[$0] - lo[$0] < 10 }
    }

    /// Снимок вида средствами UIKit — в уменьшенном масштабе, чтобы стопка не съедала память
    static func render(_ v: UIView) -> UIImage? {
        guard v.window != nil, v.bounds.width > 1, v.bounds.height > 1 else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = min(2, v.window?.screen.scale ?? 2)
        let img = UIGraphicsImageRenderer(bounds: v.bounds, format: format).image { _ in
            _ = v.drawHierarchy(in: v.bounds, afterScreenUpdates: false)
        }
        return isBlank(img) ? nil : img
    }
}

// MARK: - Просмотр файла, который переживает сворачивание

/// QuickLook живёт в карточке, а не на экране: свернул — и вернулся на ту же страницу
final class FilePreviewHolder: NSObject, QLPreviewControllerDataSource {
    let url: URL

    lazy var controller: QLPreviewController = {
        let c = QLPreviewController()
        c.dataSource = self
        return c
    }()

    init(url: URL) {
        self.url = url
        super.init()
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        url as NSURL
    }

    /// Переносим просмотр в новую карточку (старая может ещё доигрывать исчезновение)
    func attach(to box: UIViewController) {
        let c = controller
        if c.parent === box { return }
        if c.parent != nil {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        box.addChild(c)
        c.view.frame = box.view.bounds
        c.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.view.addSubview(c.view)
        c.didMove(toParent: box)
    }

    /// Снимок той страницы, на которой остановился
    func snapshot() -> UIImage? {
        guard controller.isViewLoaded, let v = controller.view else { return nil }
        return FileLook.render(v)
    }

    /// Первая страница — для карточки в стопке, пока своего снимка нет
    func makeThumbnail(_ done: @escaping (UIImage) -> Void) {
        let req = QLThumbnailGenerator.Request(fileAt: url, size: CGSize(width: 360, height: 520),
                                               scale: 2, representationTypes: .thumbnail)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
            guard let img = rep?.uiImage else { return }
            DispatchQueue.main.async { done(img) }
        }
    }
}

private struct FilePreviewBox: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .secondarySystemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ box: UIViewController, coordinator: ()) {
        // просмотр уже мог переехать в новую карточку — тогда здесь его нет и трогать нечего
        for c in box.children {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
    }
}

// MARK: - Вкладка: сайт или файл

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    /// Есть — это файл, нет — сайт
    let file: FilePreviewHolder?
    private var web: WebModel?
    /// Как выглядела вкладка, когда её свернули
    @Published var snapshot: UIImage?
    /// Первая страница файла
    @Published var thumb: UIImage?

    var isFile: Bool { file != nil }

    /// Живая страница сайта (у файлов не создаётся — им браузер не нужен)
    var model: WebModel {
        if let web { return web }
        let m = WebModel()
        web = m
        return m
    }

    init(resource: Resource) {
        self.resource = resource
        self.file = nil
    }

    init(file url: URL) {
        self.file = FilePreviewHolder(url: url)
        self.resource = FileLook.resource(url)
    }

    func matches(file url: URL) -> Bool {
        guard let f = file?.url else { return false }
        return f.standardizedFileURL.path == url.standardizedFileURL.path
    }
}

/// Где сейчас развёрнутая карточка и куда она едет. Переходы считает не приложение, а системный
/// рендер-сервер (пружины Core Animation): приложение один раз задаёт, куда ехать, и дальше кадры
/// идут сами, 120 в секунду, даже если в этот миг SwiftUI что-то пересчитывает.
/// Пока карточку ведёт палец, положение задаётся напрямую на каждом кадре жеста
final class MiniMotion {
    static let shared = MiniMotion()

    struct State: Equatable {
        /// 0 — карточка развёрнута, 1 — сжалась в своё мини-окошко
        var collapse: CGFloat = 0
        /// Палец тянет шапку вверх (резинка), точки
        var drag: CGFloat = 0
        /// 0 — на месте, 1 — уехала за нижний край экрана
        var slide: CGFloat = 0
    }

    /// Куда карточка едет (или где стоит)
    private(set) var state = State()
    /// Насколько карточка ушла с экрана
    var hidden: CGFloat { min(1, max(state.collapse, state.slide)) }

    /// Развёрнутая сейчас карточка
    weak var live: CardMotorView? {
        didSet {
            live?.apply(current)
            if let live { attached(live) }
        }
    }

    private var token = 0
    /// Переход задали, когда карточки ещё нет на экране: он начнётся, как только она появится
    private var pending: (() -> Void)?
    private var pendingFrom: State?

    /// Что показывать карточке, которая только что появилась
    var current: State { pendingFrom ?? state }

    /// Сразу, без анимации (жест пальцем)
    func set(_ s: State) {
        token += 1
        pending = nil
        pendingFrom = nil
        state = s
        live?.halt()
        live?.apply(s)
    }

    func reset() { set(State()) }

    /// Карточка ушла из иерархии — её больше не двигаем
    func detach() {
        token += 1
        pending = nil
        pendingFrom = nil
        live = nil
        state = State()
    }

    /// Пружина. velocity — скорость пальца в долях пути в секунду.
    /// started — когда движение уже началось (например, чтобы соседние окошки съехались).
    /// started стоит раньше остальных, чтобы замыкание в конце вызова всегда было completion
    func animate(to t: State, started: (() -> Void)? = nil, response: Double = 0.42, damping: Double = 1,
                 velocity: State = State(), completion: (() -> Void)? = nil) {
        token += 1
        let tk = token
        let from = state
        state = t
        pending = nil
        pendingFrom = nil

        let finish: () -> Void = { [weak self] in
            guard let self, self.token == tk else { return }
            if t == State() { self.live?.settle() }
            completion?()
        }
        let start: () -> Void = { [weak self] in
            guard let self, self.token == tk, let v = self.live, v.window != nil else { return }
            self.pending = nil
            self.pendingFrom = nil
            // скорость пальца — в долях оставшегося пути, как её понимает пружина UIKit
            func norm(_ a: CGFloat, _ b: CGFloat, _ speed: CGFloat) -> CGFloat {
                abs(b - a) > 0.001 ? min(max(speed / (b - a), -10), 10) : 0
            }
            var nv: CGFloat = 0
            if abs(t.collapse - from.collapse) > 0.001 {
                nv = norm(from.collapse, t.collapse, velocity.collapse)
            } else if abs(t.slide - from.slide) > 0.001 {
                nv = norm(from.slide, t.slide, velocity.slide)
            }
            v.apply(from)
            v.animate(to: t, response: response, bounce: min(max(1 - damping, 0), 0.4), velocity: nv)
            if let started { DispatchQueue.main.async(execute: started) }
            // пружина почти пришла (меньше точки до цели) — переход закончен
            DispatchQueue.main.asyncAfter(deadline: .now() + response * 1.45, execute: finish)
        }

        if let v = live, v.window != nil {
            start()
        } else {
            // карточку только что добавили — SwiftUI ещё не поставил её на экран
            pending = start
            pendingFrom = from
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                guard let self, self.token == tk, self.pending != nil else { return }
                self.pending = nil
                self.pendingFrom = nil
                self.live?.apply(t)
                started?()
                finish()
            }
        }
    }

    /// Карточка встала на экран — начинаем переход, который её ждал
    func attached(_ v: CardMotorView) {
        guard v === live, v.window != nil, let p = pending else { return }
        p()
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()

    /// Откуда разворачивается карточка
    enum Entry { case bottom, bar, stack }

    /// Открытые сайты и файлы, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутая сейчас вкладка (nil — все свёрнуты)
    @Published private(set) var activeID: UUID?
    /// Прошлая развёрнутая карточка: лежит под новой, пока та выезжает снизу
    @Published private(set) var underID: UUID?
    @Published var showSwitcher = false
    /// Стопка складывается обратно в окошки
    @Published var switcherLeaving = false
    /// Окну держат место в ряду: оно летит в своё окошко или вырастает из него
    @Published private(set) var dockHold: UUID?
    /// Окно только что приземлилось в окошко — окошко коротко «принимает» его
    @Published var landed: UUID?
    /// Где сейчас ряд окошек (в координатах экрана) — окно-слой забирает нажатия только там
    var barRect: CGRect = .zero
    /// Стопка сложилась в окошки — ряд встаёт на место без своей анимации появления
    var capsuleArrived = false
    /// В приложении открыт лист или окно — окошки над ним не показываем
    @Published var sheetCovering = false
    /// Старый режим «настоящим Safari» (сейчас все сайты, и почта тоже, открываются карточкой)
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26) — окошки прячутся следом
    @Published var barInline = false
    /// Файлы закрыты Face ID (включено «Файлы по Face ID», и приложение уходило в фон)
    @Published var filesLocked = false
    /// Окошко тянут пальцем вверх: окно уже растёт под пальцем
    @Published private(set) var barDragging = false
    /// Идёт анимация открытия или сворачивания — повторные нажатия её не ломают
    private(set) var busy = false
    /// Номер перехода: завершение старой анимации не трогает то, что открыли поверх
    private var gen = 0

    /// Сайтов больше не держим: каждый — живая страница в памяти. Файлы лёгкие, их можно больше
    private let siteLimit = 4
    private let totalLimit = 8
    private let motion = MiniMotion.shared

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var under: SiteTab? { tabs.first { $0.id == underID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }
    /// Что стоит в ряду окошек: свёрнутые и окно, которому держат место
    var dockTabs: [SiteTab] {
        tabs.filter { $0.id != underID && ($0.id != activeID || $0.id == dockHold) }
    }

    /// Ряд, каким он станет, если свернуть ещё и это окно (куда полетит развёрнутая карточка)
    func dockIDs(including id: UUID?) -> [UUID] {
        tabs.filter { $0.id == id || ($0.id != underID && ($0.id != activeID || $0.id == dockHold)) }.map(\.id)
    }

    private init() {
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            if UserDefaults.standard.bool(forKey: "lockFiles"), self.tabs.contains(where: { $0.isFile }) {
                self.filesLocked = true
            }
        }
    }

    // MARK: открыть

    func open(_ r: Resource) {
        if let t = tabs.first(where: { !$0.isFile && $0.resource.url == r.url }) {
            present(t, isNew: false)
        } else {
            present(SiteTab(resource: r), isNew: true)
        }
    }

    /// Файл карточкой поверх приложения — как сайт
    func openFile(_ url: URL) {
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            present(t, isNew: false)
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        present(t, isNew: true)
    }

    /// Файл сразу в свёрнутые (из окна просмотра, открытого поверх другого окна)
    func addMinimized(file url: URL) {
        Haptics.tap()
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            guard t.id != activeID else { return }
            withAnimation(MiniAnim.dock) { tabs = reordered(tabs, putting: t) }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        var list = tabs
        list.append(t)
        list = trimmed(reordered(list, putting: t), keep: [t.id])
        withAnimation(MiniAnim.dock) { tabs = list }
    }

    /// Карточка выезжает снизу. Если уже развёрнута другая — новая накрывает её, а та уходит в свёрнутые
    private func present(_ t: SiteTab, isNew: Bool) {
        Haptics.tap()
        if t.id == activeID {
            if motion.hidden > 0 && !busy { motion.animate(to: .init(), response: 0.36) }
            return
        }
        let g = bump()
        busy = true
        let previous = active
        if let previous { takeSnapshot(previous) }

        var list = tabs
        list.removeAll { $0.id == t.id }
        list.append(t)
        var keep: Set<UUID> = [t.id]
        if let p = previous?.id { keep.insert(p) }
        list = trimmed(list, keep: keep)

        // прошлая карточка остаётся на месте, новая стартует за нижним краем
        motion.detach()
        motion.set(.init(slide: 1))
        withAnimation(MiniAnim.dock) {
            tabs = list
            underID = previous?.id
            activeID = t.id
            dockHold = nil
            showSwitcher = false
            switcherLeaving = false
        }
        motion.animate(to: .init(), response: 0.42) {
            guard g == self.gen else { return }
            self.busy = false
            if self.underID != nil { self.noAnimation { self.underID = nil } }
        }
    }

    // MARK: свернуть / развернуть

    /// Развернуть свёрнутую: из окошка окно вырастает прямо с его места, из стопки — уже стоит на месте
    func restore(_ t: SiteTab, from entry: Entry) {
        if entry == .bottom {
            present(t, isNew: false)
            return
        }
        guard tabs.contains(where: { $0.id == t.id }) else { return }
        if entry == .bar {
            guard !busy else { return }
            guard activeID == nil else {
                present(t, isNew: false)
                return
            }
            Haptics.tap()
            let g = bump()
            busy = true
            motion.detach()
            motion.set(.init(collapse: 1))
            // окно встаёт ровно на место своего окошка, само окошко под ним уже пустое
            noAnimation {
                dockHold = t.id
                underID = nil
                activeID = t.id
            }
            motion.animate(to: .init(), started: { [weak self] in
                // соседи съезжаются на освободившееся место, пока окно растёт
                guard let self, g == self.gen else { return }
                withAnimation(MiniAnim.dock) {
                    self.dockHold = nil
                    self.tabs = self.reordered(self.tabs, putting: t, onTop: true)
                }
            }, response: 0.44) {
                if g == self.gen { self.busy = false }
            }
            return
        }
        // из стопки: карточка уже стоит на месте — живая страница встаёт под стопку
        let g = bump()
        busy = true
        motion.detach()
        motion.set(.init())
        noAnimation {
            tabs = reordered(tabs, putting: t, onTop: true)
            underID = nil
            dockHold = nil
            activeID = t.id
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.noAnimation {
                self.showSwitcher = false
                self.switcherLeaving = false
            }
            if g == self.gen { self.busy = false }
        }
    }

    /// Карточка уменьшается и улетает в своё мини-окошко — с того места, где её отпустил палец,
    /// и с его скоростью. Соседние окошки сразу расступаются, освобождая ей место справа
    @discardableResult
    func minimize(velocity: CGFloat = 0) -> Bool {
        guard let t = active, !busy else { return false }
        Haptics.tap()
        let g = bump()
        busy = true
        motion.live?.freezeLive()
        withAnimation(MiniAnim.dock) { dockHold = t.id }
        motion.animate(to: .init(collapse: 1), response: 0.46, velocity: .init(collapse: velocity)) {
            guard g == self.gen else { return }
            self.land(t)
        }
        return true
    }

    /// Окно долетело до окошка: окошко встаёт ровно на его место — подмены не видно
    private func land(_ t: SiteTab) {
        noAnimation {
            activeID = nil
            underID = nil
            dockHold = nil
            barDragging = false
            landed = t.id
        }
        motion.detach()
        busy = false
        SiteHaptics.soft()
        // ряд мог быть спрятан (открыт лист) — значок в углу окошка всё равно должен вернуться
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            if self.landed == t.id { self.landed = nil }
        }
    }

    // MARK: окошко тянут вверх — окно растёт под пальцем

    /// Палец пошёл вверх по окошку: окно встаёт на его место, сжатое ровно в окошко
    func beginBarDrag(_ t: SiteTab) -> Bool {
        guard !busy, activeID == nil, tabs.contains(where: { $0.id == t.id }) else { return false }
        Haptics.tap()
        bump()
        busy = true
        motion.detach()
        motion.set(.init(collapse: 1))
        noAnimation {
            dockHold = t.id
            underID = nil
            activeID = t.id
            barDragging = true
        }
        return true
    }

    /// Отпустили: развернуть до конца или вернуть обратно в окошко
    func endBarDrag(open: Bool, velocity: CGFloat) {
        guard barDragging, let t = active else { return }
        let g = bump()
        if open {
            motion.animate(to: .init(), started: { [weak self] in
                guard let self, g == self.gen else { return }
                withAnimation(MiniAnim.dock) {
                    self.dockHold = nil
                    self.tabs = self.reordered(self.tabs, putting: t, onTop: true)
                }
            }, response: 0.42, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.noAnimation { self.barDragging = false }
                self.busy = false
            }
        } else {
            motion.animate(to: .init(collapse: 1), response: 0.36, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.land(t)
            }
        }
    }

    /// Стопка всех окон с наклоном назад, как в Telegram (пачка «+N» и «Все окна» в меню)
    func openStack() {
        guard !busy, activeID == nil, !tabs.isEmpty else { return }
        Haptics.tap()
        switcherLeaving = false
        withAnimation(MiniAnim.stack) { showSwitcher = true }
    }

    /// Стопка сложилась в окошки — ряд встаёт на её место
    func hideSwitcher() {
        noAnimation {
            showSwitcher = false
            switcherLeaving = false
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(MiniAnim.quick) { barInline = inline }
    }

    // MARK: закрыть

    func close(_ t: SiteTab) {
        SiteHaptics.rigid()
        guard t.id == activeID else {
            withAnimation(MiniAnim.dock) { remove(t) }
            return
        }
        guard !busy else { return }
        let g = bump()
        busy = true
        // развёрнутая уезжает вниз за край экрана, как лист
        motion.live?.freezeLive()
        var end = motion.state
        end.slide = 1
        motion.animate(to: end, response: 0.36) {
            guard g == self.gen else { return }
            self.motion.detach()
            withAnimation(.easeOut(duration: 0.2)) {
                self.remove(t)
                self.activeID = nil
                self.underID = nil
                self.dockHold = nil
            }
            self.busy = false
        }
    }

    func closeAll() {
        SiteHaptics.rigid()
        bump()
        busy = false
        motion.detach()
        withAnimation(MiniAnim.stack) {
            tabs = []
            activeID = nil
            underID = nil
            dockHold = nil
            barDragging = false
            showSwitcher = false
            switcherLeaving = false
        }
        filesLocked = false
    }

    private func remove(_ t: SiteTab) {
        tabs.removeAll { $0.id == t.id }
        if tabs.isEmpty {
            showSwitcher = false
            switcherLeaving = false
        }
        if !tabs.contains(where: { $0.isFile }) { filesLocked = false }
    }

    // MARK: Face ID для файлов

    func unlockFiles() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            filesLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return }
                Haptics.success()
                withAnimation(.easeInOut(duration: 0.25)) { self.filesLocked = false }
            }
        }
    }

    /// Слой с карточками — в своём окне над всем приложением, поэтому показать можно всегда
    static var canShowOnTop: Bool { true }

    // MARK: служебное

    @discardableResult
    private func bump() -> Int {
        gen += 1
        return gen
    }

    private func noAnimation(_ body: () -> Void) {
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t, body)
    }

    /// Вкладку — в самый верх свёрнутых. Развёрнутая (если есть) остаётся последней:
    /// иначе при сворачивании она улетела бы не в крайнее окошко
    private func reordered(_ input: [SiteTab], putting t: SiteTab, onTop: Bool = false) -> [SiteTab] {
        var list = input
        list.removeAll { $0.id == t.id }
        if !onTop, let a = activeID, a != t.id, let i = list.firstIndex(where: { $0.id == a }) {
            list.insert(t, at: i)
        } else {
            list.append(t)
        }
        return list
    }

    /// Самые давние вкладки закрываем, чтобы не тратить память
    private func trimmed(_ input: [SiteTab], keep: Set<UUID>) -> [SiteTab] {
        var list = input
        var keep = keep
        if let a = activeID { keep.insert(a) }
        if let u = underID { keep.insert(u) }
        while list.filter({ !$0.isFile }).count > siteLimit,
              let old = list.first(where: { !$0.isFile && !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        while list.count > totalLimit, let old = list.first(where: { !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        return list
    }

    /// Снять страницу для окошка и стопки прямо сейчас (движок зовёт, когда окно начинает сворачиваться)
    func captureSnapshot(_ t: SiteTab) { takeSnapshot(t) }

    private func takeSnapshot(_ t: SiteTab) {
        if let holder = t.file {
            if let img = holder.snapshot() { t.snapshot = img }
            return
        }
        let wv = t.model.webView
        guard wv.window != nil, wv.bounds.width > 1, wv.bounds.height > 1 else { return }
        let config = WKSnapshotConfiguration()
        config.afterScreenUpdates = false
        config.snapshotWidth = NSNumber(value: Double(min(wv.bounds.width, 340)))
        wv.takeSnapshot(with: config) { [weak t, weak wv] image, _ in
            if let image {
                t?.snapshot = image
            } else if let wv, let img = FileLook.render(wv) {
                // запасной путь: WebKit иногда отдаёт пустой снимок, пока страница грузится
                t?.snapshot = img
            }
        }
    }
}

// MARK: - Приложение под карточкой отъезжает назад, как в Telegram

struct SiteBackdrop: ViewModifier {
    // приложение под карточкой не перерисовывается во время жестов:
    // затемнение — слой внутри UIKit-движка карточки
    func body(content: Content) -> some View { content }
}

// MARK: - Шапка мини-приложения

/// Крестик слева, значок и название по центру, справа — что передали (обычно капсула «⌄ ⋯»)
struct MiniHeader<Trailing: View>: View {
    let resource: Resource
    var onClose: (() -> Void)? = nil
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        ZStack {
            HStack(spacing: 8) {
                SiteIcon(resource: resource, size: 22)
                Text(resource.title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            .padding(.horizontal, 96)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)

            HStack(spacing: 0) {
                Button {
                    onClose?()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 46, height: 46)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")

                Spacer(minLength: 0)
                trailing()
            }
            .padding(.leading, 6)
            .padding(.trailing, 10)
        }
        .frame(height: MiniChrome.header)
        .frame(maxWidth: .infinity)
        .background(MiniChrome.headerColor)
    }
}

/// Капсула справа в шапке, как у мини-приложений Telegram: «свернуть» и «ещё».
/// У плашки свёрнутых та же капсула, только стрелка смотрит вверх, а «ещё» спрятано
struct MiniPill<Items: View>: View {
    /// 0 — карточка развёрнута (⌄ и ⋯), 1 — сжалась в плашку (только ⌃)
    var collapse: CGFloat = 0
    var chevronLabel = "Свернуть"
    var onChevron: (() -> Void)? = nil
    @ViewBuilder var menu: () -> Items

    var body: some View {
        HStack(spacing: 0) {
            if let onChevron {
                Button(action: onChevron) {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 15, weight: .bold))
                        .rotationEffect(.degrees(Double(180 * collapse)))
                        .foregroundStyle(.primary)
                        .frame(width: 38, height: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(chevronLabel)
            }
            Menu {
                menu()
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 38, height: 32)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("Ещё")
            .frame(width: 38 * max(0, 1 - collapse), alignment: .leading)
            .opacity(Double(max(0, 1 - collapse * 1.6)))
            .clipped()
            .allowsHitTesting(collapse < 0.5)
        }
        .frame(height: 32)
        .background(Color.primary.opacity(0.08), in: Capsule(style: .continuous))
    }
}

/// Меню «⋯» карточки: у сайта — свои пункты, у файла — свои
private struct CardMenu: View {
    let tab: SiteTab

    var body: some View {
        if let f = tab.file?.url {
            FileMenuItems(url: f)
        } else {
            WebMenuItems(model: tab.model, resource: tab.resource)
        }
    }
}

struct FileMenuItems: View {
    let url: URL
    /// В отдельном окне просмотра файл не прячется за Face ID — там это меню всегда полное
    var respectsLock = true
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        Section(FileLook.meta(url)) {
            if respectsLock && tabs.filesLocked {
                Button { tabs.unlockFiles() } label: { Label("Разблокировать", systemImage: "faceid") }
            } else {
                ShareLink(item: url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                Button { FileLook.copy(url) } label: { Label("Скопировать файл", systemImage: "doc.on.doc") }
                if FileLook.canPrint(url) {
                    Button { FileLook.printFile(url) } label: { Label("Напечатать", systemImage: "printer") }
                }
            }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутая карточка, мини-окошки, стопка

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы окошки не легли на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под окошками системная полоса с Sakai и почтой: когда панель сжимается, окошки прячутся следом
    var followsBar = false

    var body: some View {
        GeometryReader { geo in
            let dockTop = geo.size.height - MiniDock.lift - bottomExtra - MiniDock.h
            let cards = [tabs.under, tabs.active].compactMap { $0 }
            let showDock = (tabs.barDragging || !tabs.dockTabs.isEmpty) && !tabs.showSwitcher
                && (!tabs.sheetCovering || tabs.barDragging || tabs.active != nil)

            ZStack(alignment: .top) {
                // окошки лежат под развёрнутой карточкой: карточка улетает ровно в своё окошко,
                // а когда окно вырастает из окошка, остальные съезжаются на его место
                if showDock {
                    MiniDockView(width: geo.size.width, travel: max(dockTop - MiniChrome.topGap, 1),
                                 tucked: followsBar && tabs.barInline && !tabs.barDragging && tabs.active == nil)
                        .offset(y: dockTop)
                        .transition(.opacity)
                        .zIndex(1)
                }

                // одна и та же карточка остаётся тем же видом, когда уходит «под» новую:
                // живая страница не пересоздаётся и не моргает
                ForEach(cards) { t in
                    CardMotor(tab: t, live: t.id == tabs.activeID, dockTop: dockTop)
                        .ignoresSafeArea()
                        .zIndex(t.id == tabs.activeID ? 3 : 2)
                        .transition(.identity)
                }

                if tabs.showSwitcher {
                    StackSwitcherHost(dockTop: dockTop)
                        .ignoresSafeArea()
                        .zIndex(4)
                        .transition(.identity)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
        }
        // клавиатура не двигает карточку и окошки: страница сама прокручивает поле ввода над клавиатурой,
        // а пересчёт всей карточки при каждом показе клавиатуры давал рывок
        .ignoresSafeArea(.keyboard)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }
}

// MARK: - Развёрнутая карточка (UIKit-движок — в конце файла)

/// Содержимое карточки. Входные данные не меняются, пока карточку тянут или сворачивают,
/// поэтому SwiftUI не пересчитывает страницу на каждом кадре
private struct CardBody: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        if tab.isFile {
            FileBody(tab: tab)
        } else {
            WebScreen(resource: tab.resource, model: tab.model, embeddedInset: bottomInset)
        }
    }
}

// MARK: - Карточка файла

private struct FileBody: View {
    let tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        ZStack {
            if let holder = tab.file {
                FilePreviewBox(holder: holder)
            } else {
                Color(.secondarySystemBackground)
            }
            if tabs.filesLocked {
                FileLockedView()
                    .transition(.opacity)
            }
        }
        .overlay(alignment: .top) { MiniChrome.hairline }
        .animation(.easeInOut(duration: 0.25), value: tabs.filesLocked)
    }
}

private struct FileLockedView: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.regularMaterial)
            VStack(spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.secondary)
                Text("Файл защищён")
                    .font(.headline)
                Button { SiteTabs.shared.unlockFiles() } label: {
                    Label("Открыть по Face ID", systemImage: "faceid")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear { SiteTabs.shared.unlockFiles() }
    }
}

// MARK: - Свёрнутые: мини-окошки над вкладками

/// Ряд мини-окошек. В каждом — то же окно, что было развёрнуто (шапка и страница), только маленькое,
/// в углу — значок сайта. Новое окошко встаёт справа, соседи расступаются.
/// Нажал — окно вырастает из окошка; потянул вверх — растёт прямо под пальцем;
/// смахнул вниз — закрыл; долгое нажатие — меню. Окон больше четырёх — слева пачка «+N».
private struct MiniDockView: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let width: CGFloat
    /// Путь от окошка до развёрнутой карточки, точки
    let travel: CGFloat
    /// Панель вкладок сжата прокруткой — окошки спрятаны
    var tucked = false
    @State private var shown = false
    @State private var lifting = false
    /// Окошко смахивают вниз
    @State private var closing: UUID?
    @State private var closeDY: CGFloat = 0
    @State private var armed = false
    /// Окно только что приземлилось — окошко коротко подпрыгивает
    @State private var bounce: UUID?

    var body: some View {
        let list = tabs.dockTabs
        let lay = MiniDock.layout(list.map(\.id), width: width, top: 0)

        ZStack(alignment: .topLeading) {
            // основа на всю ширину: пока окно тянут вверх, жест не обрывается, даже если ряд опустел
            Color.clear
                .frame(width: width, height: MiniDock.h)
                .contentShape(Rectangle())

            if let r = lay.overflow {
                overflowTile(lay.hidden)
                    .transition(.scale(scale: 0.5).combined(with: .opacity))
                    .offset(x: r.minX)
            }

            ForEach(list) { t in
                if let r = lay.rects[t.id] {
                    slot(t)
                        .transition(.scale(scale: 0.5).combined(with: .opacity))
                        .offset(x: r.minX)
                }
            }
        }
        .frame(width: width, height: MiniDock.h, alignment: .topLeading)
        .background(
            GeometryReader { g in
                let f = g.frame(in: .global)
                let r = tucked || lay.frame.isEmpty ? CGRect.zero : lay.frame.offsetBy(dx: f.minX, dy: f.minY)
                Color.clear
                    .onAppear { tabs.barRect = r }
                    .onChange(of: r) { _, n in tabs.barRect = n }
            }
        )
        .onDisappear { tabs.barRect = .zero }
        .gesture(
            DragGesture(minimumDistance: 8)
                .onChanged { v in dragChanged(v, lay: lay, list: list) }
                .onEnded { v in dragEnded(v) }
        )
        .scaleEffect(shown && !tucked ? 1 : 0.9, anchor: .bottom)
        .offset(y: tucked ? 28 : 0)
        .opacity(shown && !tucked ? 1 : 0)
        .animation(.spring(response: 0.34, dampingFraction: 0.9), value: tucked)
        .allowsHitTesting(!tucked)
        .onAppear {
            if tabs.capsuleArrived {
                // стопка уже сложилась ровно в окошки — ряд встаёт без своей анимации, подмены не видно
                tabs.capsuleArrived = false
                var tr = Transaction()
                tr.disablesAnimations = true
                withTransaction(tr) { shown = true }
            } else {
                DispatchQueue.main.async {
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { shown = true }
                }
            }
        }
        .onChange(of: tabs.landed) { _, id in
            guard let id else { return }
            withAnimation(.spring(response: 0.16, dampingFraction: 0.55)) { bounce = id }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                // окошко оседает, а в угол выскакивает значок сайта
                withAnimation(.spring(response: 0.42, dampingFraction: 0.58)) {
                    bounce = nil
                    if tabs.landed == id { tabs.landed = nil }
                }
            }
        }
    }

    // MARK: окошко

    @ViewBuilder
    private func slot(_ t: SiteTab) -> some View {
        // окну держат место: оно летит сюда или вырастает отсюда — само окошко пока пустое
        let held = t.id == tabs.activeID || t.id == tabs.dockHold
        let isClosing = closing == t.id
        ZStack {
            if !held {
                MiniWindow(tab: t, screenWidth: width, badge: tabs.landed != t.id)
                    .scaleEffect(bounce == t.id ? 1.08 : 1, anchor: .bottom)
                    .offset(y: isClosing ? closeDY : 0)
                    .opacity(isClosing ? Double(max(0, 1 - closeDY / 140)) : 1)
                    .contentShape(.contextMenuPreview, RoundedRectangle(cornerRadius: MiniDock.radius, style: .continuous))
                    .contentShape(Rectangle())
                    .onTapGesture { tabs.restore(t, from: .bar) }
                    .contextMenu { menu(t) }
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("Свёрнуто: \(t.resource.title)")
                    .accessibilityHint("Развернуть")
                    .accessibilityAddTraits(.isButton)
                    .accessibilityAction { tabs.restore(t, from: .bar) }
                    .accessibilityAction(named: "Закрыть") { tabs.close(t) }
            }
        }
        .frame(width: MiniDock.w, height: MiniDock.h)
    }

    /// Пачка «+N»: окна, которые не поместились в ряд. Нажал — стопка всех окон
    private func overflowTile(_ n: Int) -> some View {
        let shape = RoundedRectangle(cornerRadius: MiniDock.radius, style: .continuous)
        return ZStack {
            shape.fill(MiniChrome.headerColor)
                .overlay(shape.fill(Color.black.opacity(0.2)))
                .frame(width: MiniDock.w - 12)
                .offset(y: -8)
            shape.fill(MiniChrome.headerColor)
                .overlay(shape.fill(Color.black.opacity(0.1)))
                .frame(width: MiniDock.w - 6)
                .offset(y: -4)
            shape.fill(MiniChrome.headerColor)
                .shadow(color: .black.opacity(0.28), radius: 9, y: 4)
            shape.strokeBorder(Color.primary.opacity(0.14), lineWidth: 0.5)
            VStack(spacing: 4) {
                Text("+\(n)")
                    .font(.system(size: 19, weight: .bold, design: .rounded).monospacedDigit())
                    .foregroundStyle(.primary)
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
        }
        .frame(width: MiniDock.w, height: MiniDock.h)
        .contentShape(shape)
        .onTapGesture { tabs.openStack() }
        .contextMenu {
            Button { tabs.openStack() } label: { Label("Все окна", systemImage: "square.stack.3d.up") }
            Button(role: .destructive) { tabs.closeAll() } label: { Label("Закрыть все", systemImage: "xmark.circle") }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Ещё \(n) свёрнутых окон")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { tabs.openStack() }
    }

    @ViewBuilder
    private func menu(_ t: SiteTab) -> some View {
        let many = tabs.dockTabs.count > 1
        Button { tabs.restore(t, from: .bar) } label: {
            Label("Развернуть", systemImage: "arrow.up.left.and.arrow.down.right")
        }
        if many {
            Button { tabs.openStack() } label: { Label("Все окна", systemImage: "square.stack.3d.up") }
        }
        Button(role: .destructive) { tabs.close(t) } label: {
            Label("Закрыть «\(t.resource.title)»", systemImage: "xmark")
        }
        if many {
            Button(role: .destructive) { tabs.closeAll() } label: {
                Label("Закрыть все", systemImage: "xmark.circle")
            }
        }
    }

    // MARK: жесты

    private func hit(_ p: CGPoint, lay: MiniDock.Layout, list: [SiteTab]) -> SiteTab? {
        list.first { t in
            lay.rects[t.id].map { $0.insetBy(dx: -MiniDock.gap / 2, dy: -14).contains(p) } ?? false
        }
    }

    private func collapse(_ dy: CGFloat) -> CGFloat { 1 - min(1, max(0, -dy / travel)) }

    private func dragChanged(_ v: DragGesture.Value, lay: MiniDock.Layout, list: [SiteTab]) {
        let dy = v.translation.height
        if lifting {
            MiniMotion.shared.set(.init(collapse: collapse(dy)))
            return
        }
        if closing != nil {
            closeDY = dy > 0 ? dy : -pow(-dy, 0.5)
            let now = dy > 44
            if now != armed {
                armed = now
                if now { SiteHaptics.rigid() }
            }
            return
        }
        guard abs(dy) > abs(v.translation.width), let t = hit(v.startLocation, lay: lay, list: list),
              t.id != tabs.activeID, t.id != tabs.dockHold else { return }
        if dy < -6 {
            // потянул вверх — окно вырастает прямо под пальцем
            if tabs.beginBarDrag(t) {
                lifting = true
                MiniMotion.shared.set(.init(collapse: collapse(dy)))
            }
        } else if dy > 6 {
            // вниз — окошко уезжает и тает: так закрывают
            closing = t.id
            closeDY = dy
        }
    }

    private func dragEnded(_ v: DragGesture.Value) {
        if lifting {
            lifting = false
            let vel = -v.velocity.height
            let open = -v.predictedEndTranslation.height > travel * 0.3 || vel > 450
            tabs.endBarDrag(open: open && vel > -300, velocity: v.velocity.height / travel)
            return
        }
        guard let id = closing else { return }
        armed = false
        let far = v.translation.height > 44 || v.predictedEndTranslation.height > 130
        if far, let t = tabs.tabs.first(where: { $0.id == id }) {
            withAnimation(.easeIn(duration: 0.14)) { closeDY = 150 }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.14) {
                tabs.close(t)
                // окошко уже растворилось; сбрасываем, когда соседи доедут на его место
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    if closing == id {
                        closing = nil
                        closeDY = 0
                    }
                }
            }
        } else {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                closing = nil
                closeDY = 0
            }
        }
    }
}

/// Мини-окошко: то же окно, что развёрнутое (шапка и страница), уменьшенное в несколько раз.
/// Карточка при сворачивании уменьшается ровно до него, поэтому подмены не видно
private struct MiniWindow: View {
    let tab: SiteTab
    let screenWidth: CGFloat
    /// Значок сайта в углу (выскакивает, когда окно приземлилось)
    var badge = true

    var body: some View {
        let k = MiniDock.scale(screenWidth)
        let shape = RoundedRectangle(cornerRadius: MiniDock.radius, style: .continuous)
        StackCardView(tab: tab, pill: 1)
            .frame(width: screenWidth, height: MiniDock.crop(screenWidth), alignment: .top)
            .scaleEffect(k, anchor: .topLeading)
            .frame(width: MiniDock.w, height: MiniDock.h, alignment: .topLeading)
            .allowsHitTesting(false)
            .clipShape(shape)
            .overlay(shape.strokeBorder(Color.primary.opacity(0.14), lineWidth: 0.5))
            .background(shape.fill(MiniChrome.headerColor).shadow(color: .black.opacity(0.28), radius: 9, y: 4))
            .overlay(alignment: .bottomTrailing) {
                SiteIcon(resource: tab.resource, size: 22)
                    .padding(2)
                    .background(MiniChrome.headerColor, in: RoundedRectangle(cornerRadius: 8.5, style: .continuous))
                    .shadow(color: .black.opacity(0.2), radius: 3, y: 1)
                    .offset(x: 7, y: 7)
                    .scaleEffect(badge ? 1 : 0.2)
                    .opacity(badge ? 1 : 0)
                    .allowsHitTesting(false)
            }
    }
}

// MARK: - Стопка открытых вкладок как в Telegram

/// Раскладка стопки: старые сверху, свежая — внизу и поверх всех; верх последней — чуть ниже середины экрана.
/// Если карточек много, лишние у верхнего края складываются в тонкую пачку, остальное — прокруткой
private struct StackLayout {
    let count: Int
    let height: CGFloat
    let first: CGFloat
    let last: CGFloat
    let step: CGFloat
    let maxScroll: CGFloat
    let cardHeight: CGFloat
    let scale: CGFloat

    init(count: Int, size: CGSize, safeTop: CGFloat) {
        self.count = count
        height = size.height
        first = safeTop + 12
        last = max(first, size.height * 0.53)
        if count > 1 {
            step = min(max((last - first) / CGFloat(count - 1), size.height * 0.13), size.height * 0.45)
        } else {
            step = 0
        }
        maxScroll = max(0, first - (last - step * CGFloat(max(count - 1, 0))))
        cardHeight = max(size.height - safeTop - MiniChrome.topGap, 200)
        scale = size.width > 28 ? (size.width - 28) / size.width : 1
    }

    /// Верх карточки и насколько глубоко она ушла в пачку у верхнего края
    func top(_ i: Int, scroll: CGFloat) -> (y: CGFloat, depth: CGFloat) {
        let raw: CGFloat
        if count <= 1 {
            raw = first + (last - first) * 0.4 + scroll
        } else {
            raw = last - step * CGFloat(count - 1 - i) + scroll
        }
        guard raw < first else { return (raw, 0) }
        let over = min(first - raw, step * 4)
        return (first - over * 0.06, min(over / max(step, 1), 4))
    }

    /// Чем ниже карточка, тем сильнее она наклонена — как в Telegram
    func angle(at y: CGFloat) -> CGFloat {
        min(max(15 + 34 * y / max(height, 1), 12), 40)
    }
}

/// Окно в стопке и в мини-окошке: шапка и снимок страницы — так же, как окно выглядит развёрнутым
private struct StackCardView: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    var dim: Double = 0
    /// 0…1: капсула «⌄ ⋯» в шапке
    var pill: CGFloat = 1
    @AppStorage("web.light") private var forceLight = true

    var body: some View {
        // скругление — у слоя вокруг (оно разное у карточки и у окошка), здесь только содержимое
        VStack(spacing: 0) {
            MiniHeader(resource: tab.resource) {
                MiniPill(onChevron: {}) { EmptyView() }
                    .opacity(Double(pill))
            }
            preview
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .overlay(alignment: .top) { MiniChrome.hairline }
        }
        .background(MiniChrome.headerColor)
        .overlay(Color.black.opacity(dim))
    }

    private var locked: Bool { tab.isFile && tabs.filesLocked }

    private var pageColor: Color {
        if tab.isFile { return Color(.secondarySystemBackground) }
        return forceLight ? Color.white : Color(.systemBackground)
    }

    /// Снимок — во всю ширину и прижат к верху, как страница в развёрнутом окне:
    /// в высокой карточке стопки и в маленьком окошке видна одна и та же верхняя часть
    private var preview: some View {
        pageColor
            .overlay(alignment: .top) {
                if locked {
                    VStack(spacing: 10) {
                        Image(systemName: "lock.fill")
                            .font(.system(size: 30, weight: .semibold))
                        Text("Защищено")
                            .font(.subheadline.weight(.semibold))
                    }
                    .foregroundStyle(.secondary)
                    .padding(.top, 110)
                } else if let img = tab.snapshot {
                    Image(uiImage: img)
                        .resizable()
                        .interpolation(.medium)
                        .aspectRatio(contentMode: .fit)
                        .fixedSize(horizontal: false, vertical: true)
                } else if let thumb = tab.thumb {
                    // первая страница файла, как в просмотрщике: лист с полями
                    Image(uiImage: thumb)
                        .resizable()
                        .interpolation(.medium)
                        .aspectRatio(contentMode: .fit)
                        .fixedSize(horizontal: false, vertical: true)
                        .overlay(Rectangle().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                } else {
                    SiteIcon(resource: tab.resource, size: 40)
                        .opacity(0.3)
                        .padding(.top, 140)
                }
            }
            .clipped()
    }
}

/// Значок вкладки: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28, style: .continuous)
                .fill(c)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.5, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// Свой цвет у каждого сайта и типа файла — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        if let u = URL(string: r.url), u.isFileURL { return FileLook.color(u) }
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || host == "edu.narfu.ru" || r.icon.contains("envelope") {
            return Color(red: 0.20, green: 0.33, blue: 0.55)
        }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками) — карточкой, все сайты одинаково
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        SiteTabs.shared.open(r)
    }

    /// Ссылка из любого места: поверх приложения — карточкой, поверх окна — в этом окне Safari
    static func link(_ u: URL) {
        let r = Resource(title: u.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт",
                         subtitle: "", url: u.absoluteString, icon: "globe", category: "Ссылки")
        SiteTabs.shared.open(r)
    }
}

// MARK: - Развёрнутая карточка: UIKit-движок

/// Содержимое карточки в своём UIHostingController: шапка и страница.
/// Во время переходов SwiftUI его не трогает — двигается только слой вокруг
private struct CardContent: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        let t = tab
        VStack(spacing: 0) {
            MiniHeader(resource: t.resource, onClose: { SiteTabs.shared.close(t) }) {
                MiniPill(onChevron: { _ = SiteTabs.shared.minimize() }) {
                    CardMenu(tab: t)
                }
            }
            CardBody(tab: t, bottomInset: bottomInset)
        }
        .background(MiniChrome.headerColor)
        .modifier(AppearanceRoot())
        .tint(Color.brand)
        .pausesAmbient()
    }
}

struct CardMotor: UIViewRepresentable {
    let tab: SiteTab
    let live: Bool
    /// Верх ряда мини-окошек в координатах SiteLayer (от верхней безопасной зоны)
    let dockTop: CGFloat
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore

    private func root(bottomInset: CGFloat) -> AnyView {
        AnyView(CardContent(tab: tab, bottomInset: bottomInset)
            .environmentObject(store)
            .environmentObject(schedule))
    }

    func makeUIView(context: Context) -> CardMotorView {
        let inset = CardMotorView.windowInsets.bottom
        let v = CardMotorView(root: root(bottomInset: inset))
        v.rootInset = inset
        v.tab = tab
        v.dockTopLocal = dockTop
        v.isLive = live
        return v
    }

    func updateUIView(_ v: CardMotorView, context: Context) {
        // содержимое пересобираем, только если что-то в нём правда поменялось:
        // слой обновляется при каждом сворачивании, а страница от этого не должна пересчитываться
        let inset = CardMotorView.windowInsets.bottom
        if inset != v.rootInset {
            v.rootInset = inset
            v.host.rootView = root(bottomInset: inset)
        }
        v.dockTopLocal = dockTop
        v.isLive = live
    }

    static func dismantleUIView(_ v: CardMotorView, coordinator: ()) {
        v.teardown()
    }
}

/// Развёрнутая карточка. Сворачивается в своё мини-окошко: верх идёт ровно за пальцем, карточка
/// плавно уменьшается и съезжает к окошку, скругление становится как у окошка — и в конце от неё
/// остаётся само окошко. Все переходы — пружины Core Animation на рендер-сервере.
/// Страница на время движения подменяется неподвижной копией, а живая прячется.
final class CardMotorView: UIView, UIGestureRecognizerDelegate {
    let host: UIHostingController<AnyView>
    /// Нижний отступ, с которым собрано содержимое
    var rootInset: CGFloat = 0
    private let dim = UIView()
    private let clip = UIView()
    /// Вся карточка (шапка и страница): уменьшается целиком, как картинка
    private let content = UIView()
    private var pan: UIPanGestureRecognizer!
    private var armed = false
    private var last = MiniMotion.State()
    weak var tab: SiteTab?
    /// Неподвижная копия поверх живой страницы, пока карточка в движении
    private var frozen: UIView?
    private var freezeToken = 0
    /// Карточку уже видели развёрнутой — её можно скопировать как есть
    private var wasExpanded = false
    /// Окошко, в которое карточка сворачивается (в координатах окна)
    private var lastSlot: CGRect?

    var dockTopLocal: CGFloat = 0 { didSet { if dockTopLocal != oldValue { apply(last) } } }
    var isLive = false {
        didSet {
            guard isLive != oldValue else { return }
            dim.isHidden = !isLive
            pan.isEnabled = isLive
            if isLive {
                MiniMotion.shared.live = self
            } else {
                if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
                halt()
                unfreeze(animated: false)
                apply(.init())
            }
        }
    }

    static var windowInsets: UIEdgeInsets {
        let w = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        return w?.safeAreaInsets ?? .zero
    }

    init(root: AnyView) {
        host = UIHostingController(rootView: root)
        super.init(frame: .zero)
        clipsToBounds = false
        backgroundColor = .clear

        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        dim.isHidden = true
        addSubview(dim)

        clip.clipsToBounds = true
        clip.layer.cornerRadius = MiniChrome.radius
        clip.layer.cornerCurve = .continuous
        clip.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        clip.backgroundColor = MiniChrome.headerUIColor
        addSubview(clip)

        content.backgroundColor = MiniChrome.headerUIColor
        content.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        content.clipsToBounds = true
        clip.addSubview(content)

        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        content.addSubview(host.view)

        pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        pan.isEnabled = false
        clip.addGestureRecognizer(pan)
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: встраивание контроллера — чтобы алерты, меню и «Поделиться» внутри страницы работали

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil else { return }
        if host.parent == nil, let parent = parentController() {
            parent.addChild(host)
            host.didMove(toParent: parent)
        }
        apply(isLive ? MiniMotion.shared.current : .init())
        if isLive { MiniMotion.shared.attached(self) }
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    func teardown() {
        if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
        freezeToken += 1
        host.willMove(toParent: nil)
        host.view.removeFromSuperview()
        host.removeFromParent()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        apply(last)
    }

    // MARK: геометрия — в координатах окна, как бы SwiftUI ни разместил этот вид

    private struct Geo {
        var origin: CGPoint
        var width: CGFloat
        var screenH: CGFloat
        var top: CGFloat
        var fullH: CGFloat
        /// Мини-окошко этой карточки
        var slot: CGRect
        /// Сколько проходит верх карточки до окошка — на столько же ведёт палец
        var travel: CGFloat { max(slot.minY - top, 1) }
    }

    private func geometry() -> Geo? {
        guard let w = window else { return nil }
        let ins = w.safeAreaInsets
        let top = ins.top + MiniChrome.topGap
        let width = w.bounds.width
        let dockTop = ins.top + dockTopLocal
        // окошко — там, где карточка встанет в ряд, если её свернуть
        if let id = tab?.id,
           let r = MiniDock.layout(SiteTabs.shared.dockIDs(including: id), width: width, top: dockTop).rects[id] {
            lastSlot = r
        }
        let slot = lastSlot ?? CGRect(x: (width - MiniDock.w) / 2, y: dockTop, width: MiniDock.w, height: MiniDock.h)
        return Geo(origin: convert(CGPoint.zero, to: nil), width: width, screenH: w.bounds.height, top: top,
                   fullH: max(w.bounds.height - top, MiniChrome.header + 1), slot: slot)
    }

    /// Поставить карточку в положение s. animated — внутри блока анимации UIKit:
    /// тогда новые значения становятся целью пружины, которую ведёт рендер-сервер
    func apply(_ s: MiniMotion.State, animated: Bool = false) {
        last = s
        guard let g = geometry() else { return }
        if !animated {
            CATransaction.begin()
            CATransaction.setDisableActions(true)
        }

        let c = min(max(s.collapse, 0), 1)
        // карточка уменьшается целиком, как картинка; видна её верхняя часть высотой с окошко
        let k = 1 + (MiniDock.scale(g.width) - 1) * c
        let crop = g.fullH + (MiniDock.crop(g.width) - g.fullH) * c
        let slideY = s.slide * (g.fullH + 80)
        // верх — ровно за пальцем, к верху окошка; по горизонтали — к его середине
        let top = g.top + (g.slot.minY - g.top) * c + s.drag + slideY
        let cx = g.width / 2 + (g.slot.midX - g.width / 2) * c
        let full = CGRect(x: 0, y: 0, width: g.width, height: g.fullH)

        UIView.performWithoutAnimation {
            let df = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.width, height: g.screenH)
            if dim.frame != df { dim.frame = df }
            if content.bounds != full { content.bounds = full }
            if host.view.frame != full { host.view.frame = full }
        }
        dim.alpha = isLive ? 0.4 * (1 - min(1, max(c, s.slide))) : 0
        clip.layer.cornerRadius = MiniChrome.radius + (MiniDock.radius - MiniChrome.radius) * c
        clip.bounds = CGRect(x: 0, y: 0, width: g.width * k, height: max(crop * k, 1))
        clip.center = CGPoint(x: cx - g.origin.x, y: top - g.origin.y)
        content.center = CGPoint(x: g.width * k / 2, y: 0)
        content.transform = CGAffineTransform(scaleX: k, y: k)

        let atRest = c < 0.001 && s.slide < 0.001 && abs(s.drag) < 0.5
        // пока карточка не развёрнута, страница не принимает нажатия
        host.view.isUserInteractionEnabled = atRest && frozen == nil

        if !animated {
            // карточка появилась сжатой в окошко — под живой шапкой снимок страницы, пока она оживает
            if isLive && c > 0.002 && frozen == nil && !wasExpanded { freezeFromImage(g) }
            if isLive && atRest && frozen == nil { wasExpanded = true }
            CATransaction.commit()
        }
    }

    /// Пружина до положения s — дальше кадры считает рендер-сервер
    func animate(to s: MiniMotion.State, response: Double, bounce: Double, velocity: CGFloat) {
        guard window != nil else {
            apply(s)
            return
        }
        UIView.animate(springDuration: response, bounce: bounce, initialSpringVelocity: velocity, delay: 0,
                       options: [.allowUserInteraction, .beginFromCurrentState]) {
            self.apply(s, animated: true)
        }
    }

    /// Палец перехватил карточку — анимация останавливается, дальше её ведёт палец
    func halt() {
        clip.layer.removeAllAnimations()
        content.layer.removeAllAnimations()
        dim.layer.removeAllAnimations()
    }

    /// Карточка доехала и развернулась — живая страница возвращается
    func settle() {
        guard isLive else { return }
        unfreeze(animated: true)
        wasExpanded = true
        host.view.isUserInteractionEnabled = true
    }

    // MARK: неподвижная копия на время движения

    /// Копия всей карточки поверх живой; живая через миг прячется (не скрывается, а становится прозрачной —
    /// WebKit продолжает считать страницу видимой и не выкидывает её из памяти)
    func freezeLive() {
        guard frozen == nil, wasExpanded, window != nil,
              let snap = host.view.snapshotView(afterScreenUpdates: false) else { return }
        UIView.performWithoutAnimation {
            snap.frame = host.view.frame
            snap.isUserInteractionEnabled = false
            content.addSubview(snap)
        }
        frozen = snap
        host.view.isUserInteractionEnabled = false
        if let t = tab { SiteTabs.shared.captureSnapshot(t) }
        freezeToken += 1
        let tk = freezeToken
        // копия должна успеть нарисоваться, поэтому живая страница прячется не сразу
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self, weak snap] in
            guard let self, let snap, self.freezeToken == tk, self.frozen === snap else { return }
            self.host.view.alpha = 0
        }
    }

    /// Окно вырастает из окошка: страница — снимком (как в окошке: во всю ширину, прижата к верху),
    /// шапка живая
    private func freezeFromImage(_ g: Geo) {
        guard frozen == nil, let t = tab else { return }
        let page = CGRect(x: 0, y: MiniChrome.header, width: g.width, height: max(g.fullH - MiniChrome.header, 1))
        let box = UIView(frame: page)
        box.clipsToBounds = true
        box.isUserInteractionEnabled = false
        let light = UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true
        box.backgroundColor = t.isFile ? .secondarySystemBackground : (light ? .white : .systemBackground)
        if let img = t.snapshot, img.size.width > 0 {
            let iv = UIImageView(image: img)
            iv.frame = CGRect(x: 0, y: 0, width: page.width, height: page.width * img.size.height / img.size.width)
            box.addSubview(iv)
        } else if let thumb = t.thumb, thumb.size.width > 0 {
            let w = page.width - 40
            let iv = UIImageView(image: thumb)
            iv.frame = CGRect(x: 20, y: 20, width: w, height: w * thumb.size.height / thumb.size.width)
            box.addSubview(iv)
        }
        UIView.performWithoutAnimation { content.addSubview(box) }
        frozen = box
    }

    private func unfreeze(animated: Bool) {
        freezeToken += 1
        host.view.alpha = 1
        guard let f = frozen else { return }
        frozen = nil
        guard animated else {
            f.removeFromSuperview()
            return
        }
        // живая страница проступает из-под копии
        UIView.animate(withDuration: 0.18, delay: 0, options: [.curveEaseOut, .allowUserInteraction]) {
            f.alpha = 0
        } completion: { _ in
            f.removeFromSuperview()
        }
    }

    // нажатия мимо карточки проходят в приложение
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let p = convert(point, to: clip)
        guard clip.point(inside: p, with: event) else { return nil }
        return super.hitTest(point, with: event) ?? clip
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        clip.point(inside: convert(point, to: clip), with: event)
    }

    // MARK: шапку тянут вниз — карточка едет ровно под пальцем

    override func gestureRecognizerShouldBegin(_ g: UIGestureRecognizer) -> Bool {
        guard g === pan else { return super.gestureRecognizerShouldBegin(g) }
        guard isLive, !SiteTabs.shared.busy else { return false }
        let p = pan.location(in: clip)
        let v = pan.velocity(in: clip)
        // за всю шапку, кроме кнопок по краям
        return p.y < MiniChrome.header && p.x > 56 && p.x < clip.bounds.width - 100 && abs(v.y) >= abs(v.x)
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geometry() else { return }
        let motion = MiniMotion.shared
        let y = r.translation(in: self).y
        switch r.state {
        case .began, .changed:
            if r.state == .began { freezeLive() }
            if y >= 0 {
                motion.set(.init(collapse: min(1, y / g.travel)))
            } else {
                motion.set(.init(drag: -pow(-y, 0.6)))
            }
            let nowArmed = y > 120
            if nowArmed != armed {
                armed = nowArmed
                if nowArmed { SiteHaptics.rigid() }
            }
        default:
            armed = false
            let vel = r.velocity(in: self).y
            let far = r.state == .ended && (y > 120 || y + vel * 0.15 > g.travel * 0.5 || vel > 700) && vel > -200
            if !(far && SiteTabs.shared.minimize(velocity: vel / g.travel)) {
                motion.animate(to: .init(), response: 0.36,
                               velocity: .init(collapse: y >= 0 ? vel / g.travel : 0))
            }
        }
    }
}



// MARK: - Стопка на UIKit: каждый кадр рисует Core Animation, SwiftUI не пересчитывается

private final class StackCardState: ObservableObject {
    @Published var pill: CGFloat = 1
}

private struct StackCardContent: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject var st: StackCardState

    var body: some View {
        StackCardView(tab: tab, pill: st.pill)
            .animation(.easeOut(duration: 0.2), value: st.pill)
            .modifier(AppearanceRoot())
    }
}

private final class StackNode {
    let tab: SiteTab
    let st = StackCardState()
    /// Плоская обёртка: наклонённая карточка рисуется внутри неё и не уходит в глубину за фон и соседей
    let wrap = UIView()
    let card = UIView()
    let dim = UIView()
    let host: UIHostingController<AnyView>

    init(tab: SiteTab) {
        self.tab = tab
        host = UIHostingController(rootView: AnyView(StackCardContent(tab: tab, st: st)))
        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        card.clipsToBounds = true
        card.backgroundColor = .clear
        card.layer.cornerRadius = MiniChrome.radius
        card.layer.cornerCurve = .continuous
        card.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        card.layer.allowsEdgeAntialiasing = true
        card.isUserInteractionEnabled = false
        card.addSubview(host.view)
        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        card.addSubview(dim)
        wrap.isUserInteractionEnabled = false
        wrap.backgroundColor = .clear
        wrap.addSubview(card)
    }
}

struct StackSwitcherHost: UIViewRepresentable {
    /// Верх ряда мини-окошек в координатах SiteLayer
    let dockTop: CGFloat

    func makeUIView(context: Context) -> StackSwitcherView {
        let v = StackSwitcherView()
        v.dockTopLocal = dockTop
        return v
    }

    func updateUIView(_ v: StackSwitcherView, context: Context) {
        v.dockTopLocal = dockTop
    }

    static func dismantleUIView(_ v: StackSwitcherView, coordinator: ()) {
        v.teardown()
    }
}

final class StackSwitcherView: UIView, UIGestureRecognizerDelegate {
    var dockTopLocal: CGFloat = 0

    private enum Phase: Equatable { case entering, shown, opening(UUID), leaving }

    private let bg = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let shade = UIView()
    private var nodes: [StackNode] = []
    private var phase: Phase = .entering
    private var scroll: CGFloat = 0
    private var scrollStart: CGFloat = 0
    private var axis = 0              // 0 — ещё не ясно, 1 — вбок, 2 — вертикально
    private var swipe: StackNode?
    private var swipeX: CGFloat = 0
    private var bag: AnyCancellable?
    private var built = false

    init() {
        super.init(frame: .zero)
        backgroundColor = .clear
        bg.alpha = 0
        bg.isUserInteractionEnabled = false
        addSubview(bg)
        shade.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        shade.isUserInteractionEnabled = false
        bg.contentView.addSubview(shade)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        addGestureRecognizer(pan)
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onTap(_:))))
        AmbientCoordinator.shared.push(token)
    }

    private let token = UUID()

    required init?(coder: NSCoder) { fatalError() }

    func teardown() {
        bag = nil
        AmbientCoordinator.shared.popLater(token)
        for n in nodes {
            n.host.willMove(toParent: nil)
            n.host.view.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes = []
    }

    // MARK: геометрия в координатах окна

    private struct Geo {
        var origin: CGPoint
        var size: CGSize
        var safeTop: CGFloat
        var dockTop: CGFloat
        /// Ряд мини-окошек: из них стопка вылетает и в них же складывается
        var dock: MiniDock.Layout
    }

    private var geo: Geo? {
        guard let w = window else { return nil }
        let top = w.safeAreaInsets.top + dockTopLocal
        return Geo(origin: convert(CGPoint.zero, to: nil), size: w.bounds.size,
                   safeTop: w.safeAreaInsets.top, dockTop: top,
                   dock: MiniDock.layout(SiteTabs.shared.dockTabs.map(\.id), width: w.bounds.width, top: top))
    }

    private func layout(_ g: Geo) -> StackLayout {
        StackLayout(count: nodes.count, size: g.size, safeTop: g.safeTop)
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil, !built, let g = geo else { return }
        built = true
        bg.frame = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.size.width, height: g.size.height)
        shade.frame = bg.bounds
        let parent = parentController()
        for t in SiteTabs.shared.tabs { add(t, parent: parent, geo: g) }
        // стопка вылетает из окошек: сначала каждая карточка стоит ровно в своём окошке и выглядит как оно
        phase = .entering
        var tr = Transaction()
        tr.disablesAnimations = true
        withTransaction(tr) { pills(1) }
        applyAll(animated: false)
        bag = SiteTabs.shared.$tabs
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] list in self?.sync(list) }
        DispatchQueue.main.async { self.enter() }
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    private func add(_ t: SiteTab, parent: UIViewController?, geo g: Geo) {
        let n = StackNode(tab: t)
        let h = layout(g).cardHeight
        n.host.view.frame = CGRect(x: 0, y: 0, width: g.size.width, height: h)
        n.dim.frame = n.host.view.frame
        if let parent {
            parent.addChild(n.host)
            n.host.didMove(toParent: parent)
        }
        n.wrap.frame = bounds
        n.wrap.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(n.wrap)
        nodes.append(n)
    }

    /// Вкладки закрыли — карточки съезжаются на освободившееся место
    private func sync(_ list: [SiteTab]) {
        let ids = Set(list.map(\.id))
        let gone = nodes.filter { !ids.contains($0.tab.id) }
        guard !gone.isEmpty else { return }
        for n in gone {
            n.host.willMove(toParent: nil)
            n.wrap.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes.removeAll { !ids.contains($0.tab.id) }
        if swipe.map({ !ids.contains($0.tab.id) }) ?? false { swipe = nil; swipeX = 0 }
        guard !nodes.isEmpty, phase == .shown, let g = geo else { return }
        scroll = min(max(scroll, 0), layout(g).maxScroll)
        animate(0.42) { self.applyAll(animated: false) }
    }

    // MARK: позы

    private struct Pose {
        var y: CGFloat
        var angle: CGFloat
        var scale: CGFloat
        var dim: CGFloat
        var alpha: CGFloat
        var height: CGFloat
        /// Карточка сжата в мини-окошко
        var mini = false
        /// Центр по горизонтали (nil — по центру экрана)
        var x: CGFloat? = nil
    }

    private func pose(_ i: Int, _ n: StackNode, _ g: Geo, _ lay: StackLayout) -> Pose {
        switch phase {
        case .entering, .leaving:
            // каждая карточка — в своём мини-окошке; те, что в пачке «+N», прячутся в пачку
            let k = MiniDock.scale(g.size.width)
            let crop = MiniDock.crop(g.size.width)
            if let r = g.dock.rects[n.tab.id] {
                return Pose(y: r.minY, angle: 0, scale: k, dim: 0, alpha: 1, height: crop, mini: true, x: r.midX)
            }
            let r = g.dock.overflow
                ?? CGRect(x: (g.size.width - MiniDock.w) / 2, y: g.dockTop, width: MiniDock.w, height: MiniDock.h)
            return Pose(y: r.minY, angle: 0, scale: k, dim: 0, alpha: 0, height: crop, mini: true, x: r.midX)
        case .opening(let id):
            if n.tab.id == id {
                return Pose(y: g.safeTop + MiniChrome.topGap, angle: 0, scale: 1, dim: 0, alpha: 1, height: lay.cardHeight)
            }
            let p = lay.top(i, scroll: clampedScroll(lay))
            return Pose(y: p.y + g.size.height * 0.5, angle: lay.angle(at: p.y), scale: lay.scale,
                        dim: 0.3, alpha: 0, height: lay.cardHeight)
        case .shown:
            let p = lay.top(i, scroll: axis == 2 ? scroll : clampedScroll(lay))
            return Pose(y: p.y, angle: lay.angle(at: p.y), scale: lay.scale * (1 - 0.035 * p.depth),
                        dim: min(0.12 * p.depth, 0.4), alpha: 1, height: lay.cardHeight)
        }
    }

    private func clampedScroll(_ lay: StackLayout) -> CGFloat { min(max(scroll, 0), lay.maxScroll) }

    private func applyAll(animated: Bool) {
        guard let g = geo else { return }
        let lay = layout(g)
        for (i, n) in nodes.enumerated() {
            var p = pose(i, n, g, lay)
            let dx: CGFloat = n === swipe ? swipeX : 0
            p.alpha *= 1 - min(abs(dx) / max(g.size.width, 1), 0.8)
            set(n, p, dx: dx, g: g)
        }
    }

    private func set(_ n: StackNode, _ p: Pose, dx: CGFloat, g: Geo) {
        n.card.bounds = CGRect(x: 0, y: 0, width: g.size.width, height: p.height)
        n.card.center = CGPoint(x: (p.x ?? g.size.width / 2) + dx - g.origin.x, y: p.y - g.origin.y)
        var t = CATransform3DMakeScale(p.scale, p.scale, 1)
        t = CATransform3DConcat(t, CATransform3DMakeRotation(-p.angle * .pi / 180, 1, 0, 0))
        var persp = CATransform3DIdentity
        persp.m34 = -1 / max(g.size.height * 0.8, 1)
        n.card.transform3D = CATransform3DConcat(t, persp)
        n.card.alpha = p.alpha
        n.dim.alpha = p.dim
        // скругление на экране: как у развёрнутой карточки или как у окошка
        n.card.layer.cornerRadius = (p.mini ? MiniDock.radius : MiniChrome.radius) / max(p.scale, 0.05)
    }

    /// Капсула «⌄ ⋯» в шапках: в окошках она есть (как у развёрнутого окна), в стопке — нет
    private func pills(_ v: CGFloat) {
        for n in nodes { n.st.pill = v }
    }

    private func animate(_ duration: Double, velocity: CGFloat = 0, delay: Double = 0,
                         _ body: @escaping () -> Void, completion: (() -> Void)? = nil) {
        UIView.animate(springDuration: duration, bounce: 0, initialSpringVelocity: velocity, delay: delay,
                       options: [.allowUserInteraction, .beginFromCurrentState], animations: body) { _ in
            completion?()
        }
    }

    /// Палец поймал карточки посреди анимации — продолжаем с того места, где они сейчас на экране
    private func freeze() {
        for n in nodes {
            guard let pl = n.card.layer.presentation() else { continue }
            n.card.layer.removeAllAnimations()
            n.card.layer.bounds = pl.bounds
            n.card.layer.position = pl.position
            n.card.layer.transform = pl.transform
            n.card.layer.opacity = pl.opacity
        }
    }

    // MARK: появление, раскрытие, уход в окошки

    private func enter() {
        guard phase == .entering else { return }
        phase = .shown
        pills(0)
        guard let g = geo else { return }
        let lay = layout(g)
        animate(0.32) { self.bg.alpha = 1 }
        for (i, n) in nodes.enumerated() {
            let p = pose(i, n, g, lay)
            // свежая поднимается первой, остальные — чуть следом, веером
            animate(0.5, delay: Double(nodes.count - 1 - i) * 0.025) { self.set(n, p, dx: 0, g: g) }
        }
    }

    private func open(_ n: StackNode) {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .opening(n.tab.id)
        n.st.pill = 1
        bringSubviewToFront(n.wrap)
        animate(0.4) {
            self.applyAll(animated: false)
            self.bg.alpha = 0
        } completion: {
            SiteTabs.shared.restore(n.tab, from: .stack)
        }
    }

    private func dismiss() {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .leaving
        swipe = nil
        swipeX = 0
        SiteTabs.shared.switcherLeaving = true
        // карточки на лету уменьшаются, выпрямляются и встают каждая в своё окошко
        pills(1)
        UIView.animate(springDuration: 0.42, bounce: 0, initialSpringVelocity: 0, delay: 0,
                       options: [.allowUserInteraction, .beginFromCurrentState]) {
            self.applyAll(animated: false)
            self.bg.alpha = 0
        } completion: { _ in
            // карточки стоят ровно в окошках — ряд встаёт на их место без своей анимации появления
            SiteTabs.shared.capsuleArrived = true
            SiteTabs.shared.hideSwitcher()
        }
    }

    private func fly(_ n: StackNode, direction: CGFloat, velocity: CGFloat) {
        guard let g = geo else { return }
        let target = direction * g.size.width * 1.15
        let rel = abs(velocity) / max(abs(target - swipeX), 1)
        SiteHaptics.rigid()
        animate(0.32, velocity: min(rel, 8)) {
            n.card.center.x = g.size.width / 2 + target - g.origin.x
            n.card.alpha = 0
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
        swipe = nil
        swipeX = 0
    }

    private func closeByButton(_ n: StackNode) {
        SiteHaptics.rigid()
        animate(0.3) {
            n.card.alpha = 0
            n.card.transform3D = CATransform3DScale(n.card.transform3D, 0.9, 0.9, 1)
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
    }

    // MARK: жесты

    private func windowPoint(_ r: UIGestureRecognizer) -> CGPoint {
        r.location(in: nil)
    }

    private func cardIndex(at p: CGPoint, lay: StackLayout) -> Int? {
        let sc = clampedScroll(lay)
        var hit: Int?
        for i in 0..<nodes.count where lay.top(i, scroll: sc).y <= p.y { hit = i }
        return hit
    }

    override func gestureRecognizerShouldBegin(_ r: UIGestureRecognizer) -> Bool {
        phase == .shown
    }

    @objc private func onTap(_ r: UITapGestureRecognizer) {
        guard phase == .shown, let g = geo else { return }
        let lay = layout(g)
        let p = windowPoint(r)
        guard let i = cardIndex(at: p, lay: lay) else { dismiss(); return }
        let n = nodes[i]
        let top = lay.top(i, scroll: clampedScroll(lay)).y
        let inset = g.size.width * (1 - lay.scale) / 2
        if p.y - top < MiniChrome.header * lay.scale && p.x < inset + 54 {
            closeByButton(n)
        } else {
            open(n)
        }
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geo else { return }
        let lay = layout(g)
        let t = r.translation(in: nil)
        let v = r.velocity(in: nil)
        switch r.state {
        case .began:
            guard phase == .shown else { return }
            freeze()
            axis = abs(v.x) > abs(v.y) ? 1 : 2
            scrollStart = clampedScroll(lay)
            if axis == 1, let i = cardIndex(at: windowPoint(r), lay: lay) { swipe = nodes[i] }
        case .changed:
            guard phase == .shown else { return }
            if axis == 1 {
                guard swipe != nil else { return }
                swipeX = t.x
            } else {
                scroll = rubber(scrollStart + t.y, max: lay.maxScroll)
            }
            applyAll(animated: false)
        default:
            guard phase == .shown else { axis = 0; return }
            let wasAxis = axis
            axis = 0
            if wasAxis == 1 {
                if let n = swipe, abs(t.x) > 110 || abs(v.x) > 800 {
                    fly(n, direction: (abs(v.x) > 300 ? v.x : t.x) < 0 ? -1 : 1, velocity: v.x)
                } else {
                    swipe = nil
                    let rel = abs(v.x) / max(abs(swipeX), 1)
                    swipeX = 0
                    animate(0.34, velocity: min(rel, 8)) { self.applyAll(animated: false) }
                }
            } else {
                // потянул вниз, когда прокручивать некуда, — стопка складывается обратно в окошки
                if t.y > 130 && scrollStart + t.y > lay.maxScroll + 110 {
                    dismiss()
                    return
                }
                let from = scroll
                let target = min(max(scrollStart + t.y + v.y * 0.22, 0), lay.maxScroll)
                scroll = target
                let rel = abs(v.y) / max(abs(target - from), 1)
                animate(0.5, velocity: min(rel, 6)) { self.applyAll(animated: false) }
            }
        }
    }

    private func rubber(_ v: CGFloat, max m: CGFloat) -> CGFloat {
        if v < 0 { return -pow(-v, 0.7) }
        if v > m { return m + pow(v - m, 0.7) }
        return v
    }
}
