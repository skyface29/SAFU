import SwiftUI
import WebKit

// MARK: - Сайты как мини-приложения в Telegram
//
// Сайт открывается карточкой на весь экран. Потянул за ручку вниз — он сворачивается в плашку
// над вкладками и продолжает жить: вход, прокрутка, набранный текст — всё на месте.
// Можно держать несколько сайтов свёрнутыми и переключаться между ними стопкой карточек.

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    let model = WebModel()
    /// Картинка страницы для стопки карточек
    @Published var snapshot: UIImage?

    init(resource: Resource) {
        self.resource = resource
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()
    /// Открытые сайты, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутый сейчас сайт (nil — все свёрнуты)
    @Published var activeID: UUID?
    @Published var showSwitcher = false
    /// Сайт в режиме «как в Safari» — открывается системным Safari поверх всего
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26): полоса с Sakai и почтой встала в один ряд
    /// с кружком вкладок — плашка свёрнутых сайтов опускается следом, без пустого места
    @Published var barInline = false
    /// Сайт открыли из стопки карточек — он не выезжает снизу, а «вырастает» из карточки
    var openedFromStack = false

    /// Больше не держим: каждый сайт — это живая страница в памяти
    private let limit = 4

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }

    func open(_ r: Resource) {
        Haptics.tap()
        openedFromStack = false
        // развёрнутый сайт уходит в стопку — запоминаем, как он выглядел
        if let cur = active, cur.resource.url != r.url { takeSnapshot(cur) }
        if let t = tabs.first(where: { $0.resource.url == r.url }) {
            bringToFront(t)
            withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = t.id }
            return
        }
        let t = SiteTab(resource: r)
        var list = tabs
        list.append(t)
        // самый давний свёрнутый сайт закрываем, чтобы не тратить память
        while list.count > limit, let old = list.first(where: { $0.id != t.id }) {
            list.removeAll { $0.id == old.id }
        }
        tabs = list
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = t.id }
    }

    func restore(_ t: SiteTab, fromStack: Bool = false) {
        Haptics.tap()
        if let cur = active, cur.id != t.id { takeSnapshot(cur) }
        openedFromStack = fromStack
        bringToFront(t)
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
            showSwitcher = false
            activeID = t.id
        }
    }

    func minimize() {
        guard let t = active else { return }
        Haptics.tap()
        takeSnapshot(t)
        openedFromStack = false
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = nil }
    }

    /// Нажали на плашку: один сайт — сразу разворачиваем, несколько — стопка карточек как в Telegram
    func tapBar() {
        let list = minimized
        if list.count > 1 {
            Haptics.tap()
            withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) { showSwitcher = true }
        } else if let t = list.last {
            restore(t)
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { barInline = inline }
    }

    func close(_ t: SiteTab) {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs.removeAll { $0.id == t.id }
            if activeID == t.id { activeID = nil }
            if tabs.isEmpty { showSwitcher = false }
        }
    }

    func closeAll() {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs = []
            activeID = nil
            showSwitcher = false
        }
    }

    private func bringToFront(_ t: SiteTab) {
        guard let i = tabs.firstIndex(where: { $0.id == t.id }), i != tabs.count - 1 else { return }
        var list = tabs
        list.remove(at: i)
        list.append(t)
        tabs = list
    }

    private func takeSnapshot(_ t: SiteTab) {
        let config = WKSnapshotConfiguration()
        config.snapshotWidth = 420
        t.model.webView.takeSnapshot(with: config) { image, _ in
            if let image { t.snapshot = image }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутый сайт, плашка свёрнутых, стопка карточек

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под плашкой системная полоса с Sakai и почтой: когда панель сжимается, плашка опускается следом
    var followsBar = false
    @State private var drag: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                // затемнение под карточкой, пока её тянут
                if tabs.active != nil {
                    Color.black
                        .opacity(0.5 * (1 - progress(geo)))
                        .ignoresSafeArea()
                        .transition(.opacity)
                        .allowsHitTesting(false)
                }

                if tabs.active == nil && !tabs.minimized.isEmpty && !tabs.showSwitcher {
                    MinimizedBar(bottomExtra: bottomExtra, followsBar: followsBar)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                if let t = tabs.active {
                    expanded(t, geo: geo)
                        .id(t.id)
                        .transition(tabs.openedFromStack
                                    ? .asymmetric(insertion: .scale(scale: 0.92, anchor: .top).combined(with: .opacity),
                                                  removal: .move(edge: .bottom))
                                    : .move(edge: .bottom))
                }

                if tabs.showSwitcher {
                    SiteSwitcher()
                        .transition(.opacity)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        }
        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: tabs.activeID)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.showSwitcher)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.tabs.count)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }

    private func progress(_ geo: GeometryProxy) -> CGFloat {
        min(1, max(0, drag / max(geo.size.height * 0.5, 1)))
    }

    /// Карточка сайта как мини-приложение в Telegram: скруглённый верх, зазор под статус-баром,
    /// тянуть вниз можно за заголовок
    private func expanded(_ t: SiteTab, geo: GeometryProxy) -> some View {
        let p = progress(geo)
        let top = 14 + 16 * p
        let bottom = 34 * p
        return WebScreen(resource: t.resource, model: t.model,
                         onClose: { SiteTabs.shared.close(t) },
                         onMinimize: { SiteTabs.shared.minimize() })
            // снизу карточка доходит до края экрана, а панель сайта остаётся над полоской «домой»
            .safeAreaPadding(.bottom, geo.safeAreaInsets.bottom)
            .background(Color(.systemBackground))
            .clipShape(UnevenRoundedRectangle(topLeadingRadius: top, bottomLeadingRadius: bottom,
                                              bottomTrailingRadius: bottom, topTrailingRadius: top, style: .continuous))
            .overlay(alignment: .top) { dragZone }
            .padding(.top, 6)
            .ignoresSafeArea(.container, edges: .bottom)
            .scaleEffect(1 - 0.08 * p, anchor: .bottom)
            .offset(y: drag)
            .shadow(color: .black.opacity(0.3), radius: 18, y: -2)
            .pausesAmbient()
    }

    /// Ручка и заголовок — за них тянут вниз (кнопки по краям остаются нажимаемыми)
    private var dragZone: some View {
        ZStack(alignment: .top) {
            Capsule()
                .fill(Color.secondary.opacity(0.55))
                .frame(width: 38, height: 5)
                .padding(.top, 5)
            HStack(spacing: 0) {
                Color.clear.frame(width: 110)
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(dragGesture)
                Color.clear.frame(width: 110)
            }
            .frame(height: 52)
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Свернуть сайт")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { SiteTabs.shared.minimize() }
    }

    private var dragGesture: some Gesture {
        DragGesture(minimumDistance: 4, coordinateSpace: .global)
            .onChanged { v in
                drag = max(0, v.translation.height)
            }
            .onEnded { v in
                let fling = v.predictedEndTranslation.height
                if v.translation.height > 110 || fling > 320 {
                    SiteTabs.shared.minimize()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { drag = 0 }
                } else {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { drag = 0 }
                }
            }
    }
}

// MARK: - Стекло для плашки и кнопок слоя сайтов

/// Настоящее «жидкое стекло» iOS 26 независимо от стиля карточек — плашка живёт рядом
/// со стеклянной панелью вкладок и должна выглядеть с ней одним целым
private struct SiteGlass<S: InsettableShape>: ViewModifier {
    let shape: S
    var tint: Color = .clear

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(tint).interactive(), in: shape)
        } else {
            fallback(content)
        }
        #else
        fallback(content)
        #endif
    }

    private func fallback(_ content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: shape)
            .background(tint, in: shape)
            .overlay(shape.strokeBorder(LinearGradient(colors: [Color.white.opacity(0.32), Color.white.opacity(0.06)],
                                                       startPoint: .top, endPoint: .bottom), lineWidth: 0.7))
    }
}

private extension View {
    func siteGlass<S: InsettableShape>(_ shape: S, tint: Color = .clear) -> some View {
        modifier(SiteGlass(shape: shape, tint: tint))
    }
}

// MARK: - Плашка свёрнутых сайтов

/// Стеклянная капсула над вкладками (как свёрнутое мини-приложение в Telegram).
/// Нажал: один сайт — развернулся, несколько — стопка карточек. Вверх — развернуть, вбок — закрыть
private struct MinimizedBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let bottomExtra: CGFloat
    let followsBar: Bool
    @State private var dx: CGFloat = 0

    /// Над полной панелью (вкладки + полоса с кнопками) или над сжатой (всё в один ряд)
    private var lift: CGFloat {
        58 + ((followsBar && tabs.barInline) ? -4 : bottomExtra)
    }

    var body: some View {
        let list = tabs.minimized
        if let top = list.last {
            HStack(spacing: 10) {
                icons(list)

                VStack(alignment: .leading, spacing: 1) {
                    Text(top.resource.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    Text(subtitle(list, top))
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                Spacer(minLength: 6)

                if list.count > 1 {
                    Image(systemName: "square.stack")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .accessibilityHidden(true)
                }

                Button {
                    flyAway(top)
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 34, height: 34)
                        .contentShape(Circle())
                }
                .buttonStyle(PressableStyle())
                .accessibilityLabel("Закрыть \(top.resource.title)")
            }
            .padding(.leading, 7)
            .padding(.trailing, 5)
            .frame(height: 50)
            .siteGlass(Capsule(style: .continuous), tint: SiteColor.color(top.resource).opacity(0.10))
            .shadow(color: .black.opacity(0.16), radius: 12, y: 5)
            .contentShape(Capsule(style: .continuous))
            .offset(x: dx)
            .opacity(1 - Double(min(abs(dx) / 260, 0.85)))
            .onTapGesture { tabs.tapBar() }
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { v in
                        if abs(v.translation.width) > abs(v.translation.height) { dx = v.translation.width }
                    }
                    .onEnded { v in
                        if v.translation.height < -28 && abs(v.translation.height) > abs(v.translation.width) {
                            dx = 0
                            tabs.tapBar()                                            // смахнул вверх — развернуть
                        } else if abs(v.translation.width) > 90 || abs(v.predictedEndTranslation.width) > 260 {
                            flyAway(top, to: v.translation.width < 0 ? -1 : 1)        // смахнул вбок — закрыть
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.8)) { dx = 0 }
                        }
                    }
            )
            .accessibilityAction(named: Text(list.count > 1 ? "Показать все свёрнутые сайты" : "Развернуть сайт")) { tabs.tapBar() }
            .padding(.horizontal, 16)
            .padding(.bottom, lift)
        }
    }

    private func icons(_ list: [SiteTab]) -> some View {
        let shown = Array(list.suffix(3))
        return ZStack(alignment: .leading) {
            ForEach(Array(shown.enumerated()), id: \.element.id) { i, t in
                SiteIcon(resource: t.resource, size: 36)
                    .clipShape(Circle())
                    .overlay(Circle().strokeBorder(Color.black.opacity(0.25), lineWidth: 1))
                    .offset(x: CGFloat(i) * 12)
            }
        }
        .frame(width: 36 + CGFloat(max(shown.count - 1, 0)) * 12, alignment: .leading)
    }

    private func subtitle(_ list: [SiteTab], _ top: SiteTab) -> String {
        if list.count > 1 {
            let n = list.count - 1
            return "и ещё \(n) \(HWText.plural(n, "сайт", "сайта", "сайтов"))"
        }
        let page = top.model.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !page.isEmpty && page.lowercased() != top.resource.title.lowercased() { return page }
        return "свёрнуто"
    }

    private func flyAway(_ t: SiteTab, to side: CGFloat = 1) {
        withAnimation(.easeOut(duration: 0.2)) { dx = side * 420 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.17) {
            tabs.close(t)
            dx = 0
        }
    }
}

// MARK: - Стопка открытых сайтов как в Telegram

/// Карточки лежат друг на друге с наклоном назад, у каждой виден заголовок.
/// Прокрутка — верхние карточки уходят в стопку у края экрана. Нажал — карточка выпрямляется
/// и разворачивается в сайт; смахнул вбок или крестик — закрыл; нажал мимо — свернул стопку
private struct SiteSwitcher: View {
    @ObservedObject private var tabs = SiteTabs.shared
    @State private var shown = false
    @State private var opening: UUID?
    @State private var leaving = false

    var body: some View {
        GeometryReader { geo in
            let cardH = min(max(geo.size.height * 0.6, 320), 600)
            let step = cardH * 0.46
            let list = tabs.tabs

            ZStack(alignment: .bottom) {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .overlay(Color.black.opacity(0.45))
                    .ignoresSafeArea()
                    .opacity(shown ? 1 : 0)

                ScrollView(showsIndicators: false) {
                    // старые сверху, свежий — внизу и поверх всех
                    VStack(spacing: step - cardH) {
                        ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                            StackCard(tab: t,
                                      height: cardH,
                                      enterOffset: geo.size.height * 0.75 + CGFloat(list.count - i) * 40,
                                      shown: shown,
                                      opening: opening,
                                      delay: Double(list.count - 1 - i) * 0.035,
                                      onOpen: { open(t) })
                                .zIndex(Double(i))
                                .transition(.asymmetric(insertion: .identity,
                                                        removal: .opacity.combined(with: .scale(scale: 0.9))))
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.top, 10)
                    .padding(.bottom, 104)
                    .frame(maxWidth: .infinity, minHeight: geo.size.height, alignment: .top)
                    // нажал на пустое место — стопка сворачивается обратно в плашку
                    .background(
                        Color.clear
                            .contentShape(Rectangle())
                            .onTapGesture { dismiss() }
                    )
                }
                .defaultScrollAnchor(.bottom)
                .scrollDisabled(opening != nil)

                closeAll
                    .opacity(shown && opening == nil ? 1 : 0)
                    .offset(y: shown ? 0 : 40)
            }
        }
        .onAppear {
            // первый кадр — карточки ещё внизу, со второго они въезжают по одной
            DispatchQueue.main.async { withAnimation(.easeOut(duration: 0.25)) { shown = true } }
        }
        .accessibilityAction(.escape) { dismiss() }
    }

    private var closeAll: some View {
        Button { tabs.closeAll() } label: {
            Label("Закрыть все", systemImage: "xmark")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .siteGlass(Capsule(style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .padding(.bottom, 14)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: shown)
    }

    private func open(_ t: SiteTab) {
        guard opening == nil, !leaving else { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) { opening = t.id }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            SiteTabs.shared.restore(t, fromStack: true)
        }
    }

    private func dismiss() {
        guard opening == nil, !leaving else { return }
        leaving = true
        Haptics.tap()
        withAnimation(.spring(response: 0.34, dampingFraction: 0.9)) { shown = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.24) {
            withAnimation(.easeOut(duration: 0.15)) { SiteTabs.shared.showSwitcher = false }
        }
    }
}

private struct StackCard: View {
    @ObservedObject var tab: SiteTab
    let height: CGFloat
    let enterOffset: CGFloat
    let shown: Bool
    let opening: UUID?
    let delay: Double
    let onOpen: () -> Void
    @State private var dx: CGFloat = 0

    private static let radius: CGFloat = 26

    var body: some View {
        let isOpening = opening == tab.id
        let othersHide = opening != nil && !isOpening
        let shape = RoundedRectangle(cornerRadius: Self.radius, style: .continuous)

        card
            .frame(maxWidth: .infinity)
            .frame(height: height)
            .clipShape(shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.10), lineWidth: 0.8))
            .background(shape.fill(Color.black).shadow(color: .black.opacity(0.45), radius: 22, y: -10))
            // наклон назад и стопка у верхнего края считаются на видеокарте, без пересчёта раскладки
            .visualEffect { content, proxy in
                let y = proxy.frame(in: .scrollView).minY
                let up: CGFloat = min(max(-y / 280, 0), 1)
                let tilt: Double = isOpening ? 0 : -(14 + 10 * Double(up))
                let scale: CGFloat = isOpening ? 1 : 1 - 0.08 * up
                let lift: CGFloat = y < 0 ? -y * 0.8 : 0
                return content
                    .scaleEffect(scale, anchor: .top)
                    .rotation3DEffect(.degrees(tilt),
                                      axis: (x: 1, y: 0, z: 0),
                                      anchor: .top,
                                      perspective: 0.55)
                    .offset(y: lift)
            }
            .offset(x: dx, y: shown ? (othersHide ? 220 : 0) : enterOffset)
            .opacity(othersHide ? 0 : 1 - Double(min(abs(dx) / 340, 0.8)))
            .animation(.spring(response: 0.5, dampingFraction: 0.82).delay(shown ? delay : 0), value: shown)
            .contentShape(shape)
            .onTapGesture(perform: onOpen)
            .simultaneousGesture(
                DragGesture(minimumDistance: 18)
                    .onChanged { v in
                        if abs(v.translation.width) > abs(v.translation.height) * 1.2 { dx = v.translation.width }
                    }
                    .onEnded { v in
                        let w = v.translation.width
                        if abs(w) > abs(v.translation.height) && (abs(w) > 110 || abs(v.predictedEndTranslation.width) > 320) {
                            withAnimation(.easeOut(duration: 0.2)) { dx = w < 0 ? -520 : 520 }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) { SiteTabs.shared.close(tab) }
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.8)) { dx = 0 }
                        }
                    }
            )
            .accessibilityElement(children: .contain)
            .accessibilityLabel(tab.resource.title)
            .accessibilityAction(named: "Открыть", onOpen)
    }

    private var card: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { SiteTabs.shared.close(tab) } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.primary)
                        .frame(width: 36, height: 36)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")
                Spacer(minLength: 0)
                SiteIcon(resource: tab.resource, size: 24)
                Text(tab.resource.title)
                    .font(.headline)
                    .lineLimit(1)
                Spacer(minLength: 0)
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 10)
            .frame(height: 54)
            .background(Color(.secondarySystemBackground))

            // превью строго по размеру карточки: картинка обрезается, а не растягивает карточку
            Color(.systemBackground)
                .overlay(alignment: .top) {
                    if let img = tab.snapshot {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                    } else {
                        SiteIcon(resource: tab.resource, size: 60)
                            .padding(.top, 80)
                    }
                }
                .clipped()
        }
    }
}

/// Значок сайта: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .fill(LinearGradient(colors: [c, c.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .strokeBorder(Color.white.opacity(0.25), lineWidth: 0.6)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.48, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
    }
}

/// Свой цвет у каждого сайта — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || r.icon.contains("envelope") { return Color(red: 0.98, green: 0.45, blue: 0.22) }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками): встроенный браузер или Safari
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        guard let u = URL(string: r.url) else { return }
        if WebModel.isPlain(u.host) {
            Haptics.tap()
            // в Safari приложение не может само вставить пароль — кладём его в буфер на минуту
            if let host = u.host, CredentialStore.enabled, let c = CredentialStore.get(host) {
                UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: c.pass]],
                                              options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
            }
            SiteTabs.shared.safari = SafariLink(url: u)
        } else {
            SiteTabs.shared.open(r)
        }
    }
}
