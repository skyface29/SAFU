import SwiftUI
import WebKit

// MARK: - Сайты как мини-приложения в Telegram
//
// Сайт открывается карточкой на весь экран. Потянул за ручку вниз — он сворачивается в плашку
// над вкладками и продолжает жить: вход, прокрутка, набранный текст — всё на месте.
// Можно держать несколько сайтов свёрнутыми и переключаться между ними стопкой карточек.

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    let model = WebModel()
    /// Картинка страницы для стопки карточек
    @Published var snapshot: UIImage?

    init(resource: Resource) {
        self.resource = resource
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()
    /// Открытые сайты, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутый сейчас сайт (nil — все свёрнуты)
    @Published var activeID: UUID?
    @Published var showSwitcher = false
    /// Сайт в режиме «как в Safari» — открывается системным Safari поверх всего
    @Published var safari: SafariLink?

    /// Больше не держим: каждый сайт — это живая страница в памяти
    private let limit = 4

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }

    func open(_ r: Resource) {
        Haptics.tap()
        // развёрнутый сайт уходит в стопку — запоминаем, как он выглядел
        if let cur = active, cur.resource.url != r.url { takeSnapshot(cur) }
        if let t = tabs.first(where: { $0.resource.url == r.url }) {
            bringToFront(t)
            withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = t.id }
            return
        }
        let t = SiteTab(resource: r)
        var list = tabs
        list.append(t)
        // самый давний свёрнутый сайт закрываем, чтобы не тратить память
        while list.count > limit, let old = list.first(where: { $0.id != t.id }) {
            list.removeAll { $0.id == old.id }
        }
        tabs = list
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = t.id }
    }

    func restore(_ t: SiteTab) {
        Haptics.tap()
        if let cur = active, cur.id != t.id { takeSnapshot(cur) }
        showSwitcher = false
        bringToFront(t)
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = t.id }
    }

    func minimize() {
        guard let t = active else { return }
        Haptics.tap()
        takeSnapshot(t)
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) { activeID = nil }
    }

    func close(_ t: SiteTab) {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs.removeAll { $0.id == t.id }
            if activeID == t.id { activeID = nil }
            if tabs.isEmpty { showSwitcher = false }
        }
    }

    func closeAll() {
        Haptics.tap()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs = []
            activeID = nil
            showSwitcher = false
        }
    }

    private func bringToFront(_ t: SiteTab) {
        guard let i = tabs.firstIndex(where: { $0.id == t.id }), i != tabs.count - 1 else { return }
        var list = tabs
        list.remove(at: i)
        list.append(t)
        tabs = list
    }

    private func takeSnapshot(_ t: SiteTab) {
        let config = WKSnapshotConfiguration()
        config.snapshotWidth = 420
        t.model.webView.takeSnapshot(with: config) { image, _ in
            if let image { t.snapshot = image }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутый сайт, плашка свёрнутых, стопка карточек

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    @State private var drag: CGFloat = 0

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                // затемнение под карточкой, пока её тянут
                if tabs.active != nil {
                    Color.black
                        .opacity(0.5 * (1 - progress(geo)))
                        .ignoresSafeArea()
                        .transition(.opacity)
                        .allowsHitTesting(false)
                }

                if tabs.active == nil && !tabs.minimized.isEmpty && !tabs.showSwitcher {
                    MinimizedBar(bottomExtra: bottomExtra)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }

                if let t = tabs.active {
                    expanded(t, geo: geo)
                        .id(t.id)
                        .transition(.move(edge: .bottom))
                }

                if tabs.showSwitcher {
                    SiteSwitcher()
                        .transition(.opacity.combined(with: .scale(scale: 1.04)))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        }
        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: tabs.activeID)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.showSwitcher)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.tabs.count)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }

    private func progress(_ geo: GeometryProxy) -> CGFloat {
        min(1, max(0, drag / max(geo.size.height * 0.5, 1)))
    }

    /// Карточка сайта как мини-приложение в Telegram: скруглённый верх, зазор под статус-баром,
    /// тянуть вниз можно за заголовок
    private func expanded(_ t: SiteTab, geo: GeometryProxy) -> some View {
        let p = progress(geo)
        let top = 14 + 16 * p
        let bottom = 34 * p
        return WebScreen(resource: t.resource, model: t.model,
                         onClose: { SiteTabs.shared.close(t) },
                         onMinimize: { SiteTabs.shared.minimize() })
            // снизу карточка доходит до края экрана, а панель сайта остаётся над полоской «домой»
            .safeAreaPadding(.bottom, geo.safeAreaInsets.bottom)
            .background(Color(.systemBackground))
            .clipShape(UnevenRoundedRectangle(topLeadingRadius: top, bottomLeadingRadius: bottom,
                                              bottomTrailingRadius: bottom, topTrailingRadius: top, style: .continuous))
            .overlay(alignment: .top) { dragZone }
            .padding(.top, 6)
            .ignoresSafeArea(.container, edges: .bottom)
            .scaleEffect(1 - 0.08 * p, anchor: .bottom)
            .offset(y: drag)
            .shadow(color: .black.opacity(0.3), radius: 18, y: -2)
            .pausesAmbient()
    }

    /// Ручка и заголовок — за них тянут вниз (кнопки по краям остаются нажимаемыми)
    private var dragZone: some View {
        ZStack(alignment: .top) {
            Capsule()
                .fill(Color.secondary.opacity(0.55))
                .frame(width: 38, height: 5)
                .padding(.top, 5)
            HStack(spacing: 0) {
                Color.clear.frame(width: 110)
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(dragGesture)
                Color.clear.frame(width: 110)
            }
            .frame(height: 52)
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Свернуть сайт")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { SiteTabs.shared.minimize() }
    }

    private var dragGesture: some Gesture {
        DragGesture(minimumDistance: 4, coordinateSpace: .global)
            .onChanged { v in
                drag = max(0, v.translation.height)
            }
            .onEnded { v in
                let fling = v.predictedEndTranslation.height
                if v.translation.height > 110 || fling > 320 {
                    SiteTabs.shared.minimize()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { drag = 0 }
                } else {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { drag = 0 }
                }
            }
    }
}

/// Плашка свёрнутого сайта над вкладками (как свёрнутое мини-приложение в Telegram)
private struct MinimizedBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let bottomExtra: CGFloat

    var body: some View {
        let list = tabs.minimized
        if let top = list.last {
            HStack(spacing: 12) {
                // стопка значков — сколько сайтов свёрнуто
                ZStack {
                    ForEach(Array(list.suffix(3).enumerated()), id: \.element.id) { i, t in
                        SiteIcon(resource: t.resource, size: 30)
                            .offset(x: CGFloat(i) * 7)
                    }
                }
                .frame(width: 30 + CGFloat(min(list.count, 3) - 1) * 7, alignment: .leading)

                VStack(alignment: .leading, spacing: 1) {
                    Text(top.resource.title)
                        .font(.subheadline.weight(.bold))
                        .lineLimit(1)
                    Text(list.count > 1 ? "и ещё \(list.count - 1) · нажми, чтобы открыть" : "свёрнуто · нажми, чтобы открыть")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 6)
                if list.count > 1 {
                    Button {
                        Haptics.tap()
                        tabs.showSwitcher = true
                    } label: {
                        Image(systemName: "square.stack.fill")
                            .font(.subheadline.weight(.semibold))
                            .frame(width: 34, height: 34)
                            .background(Color.primary.opacity(0.08), in: Circle())
                    }
                    .buttonStyle(PressableStyle())
                }
                Button {
                    tabs.close(top)
                } label: {
                    Image(systemName: "xmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 34, height: 34)
                        .background(Color.primary.opacity(0.08), in: Circle())
                }
                .buttonStyle(PressableStyle())
            }
            .padding(.leading, 12)
            .padding(.trailing, 8)
            .padding(.vertical, 8)
            .glass(24, interactive: true)
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .strokeBorder(LinearGradient(colors: [Color.white.opacity(0.28), Color.white.opacity(0.04)],
                                                 startPoint: .top, endPoint: .bottom), lineWidth: 0.8)
            )
            .shadow(color: .black.opacity(0.25), radius: 14, y: 6)
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .onTapGesture { tabs.restore(top) }
            .gesture(
                DragGesture(minimumDistance: 12).onEnded { v in
                    if v.translation.height < -30 { tabs.restore(top) }            // смахнул вверх — развернуть
                    else if abs(v.translation.width) > 90 { tabs.close(top) }        // смахнул вбок — закрыть
                }
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 58 + bottomExtra)
        }
    }
}

/// Стопка открытых сайтов как в Telegram: каждая следующая карточка ниже и поверх предыдущей,
/// у всех виден заголовок. Нажал — открыл, крестик или смахнул вбок — закрыл
private struct SiteSwitcher: View {
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        ZStack {
            Rectangle()
                .fill(.ultraThinMaterial)
                .ignoresSafeArea()
                .onTapGesture { tabs.showSwitcher = false }

            VStack(spacing: 14) {
                HStack {
                    Text("Открытые сайты")
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Spacer()
                    Button("Готово") { tabs.showSwitcher = false }
                        .font(.body.weight(.semibold))
                }
                .padding(.horizontal, 20)

                ScrollView(showsIndicators: false) {
                    // старые сверху, свежий — внизу и поверх всех
                    VStack(spacing: -SiteCard.overlap) {
                        ForEach(Array(tabs.tabs.enumerated()), id: \.element.id) { i, t in
                            SiteCard(tab: t)
                                .zIndex(Double(i))
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .padding(.bottom, 120)
                }

                Button(role: .destructive) { tabs.closeAll() } label: {
                    Label("Закрыть все", systemImage: "xmark.circle.fill")
                        .font(.subheadline.weight(.semibold))
                        .padding(.horizontal, 18)
                        .padding(.vertical, 11)
                        .glass(22, interactive: true)
                }
                .buttonStyle(PressableStyle())
                .padding(.bottom, 12)
            }
            .padding(.top, 8)
        }
    }
}

private struct SiteCard: View {
    @ObservedObject var tab: SiteTab
    @State private var dx: CGFloat = 0

    static let height: CGFloat = 360
    /// Насколько следующая карточка наезжает на эту (заголовок и кусок страницы остаются видны)
    static let overlap: CGFloat = 250

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { SiteTabs.shared.close(tab) } label: {
                    Image(systemName: "xmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.primary)
                        .frame(width: 32, height: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                Spacer(minLength: 0)
                SiteIcon(resource: tab.resource, size: 24)
                Text(tab.resource.title)
                    .font(.headline)
                    .lineLimit(1)
                Spacer(minLength: 0)
                Color.clear.frame(width: 32, height: 32)
            }
            .padding(.horizontal, 12)
            .frame(height: 52)
            .background(Color(.secondarySystemBackground))

            // превью строго по размеру карточки: картинка обрезается, а не растягивает карточку
            Color(.systemBackground)
                .overlay(alignment: .top) {
                    if let img = tab.snapshot {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                    } else {
                        SiteIcon(resource: tab.resource, size: 56)
                            .padding(.top, 60)
                    }
                }
                .clipped()
        }
        .frame(maxWidth: .infinity)
        .frame(height: Self.height)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).strokeBorder(Color.white.opacity(0.12), lineWidth: 0.8))
        .shadow(color: .black.opacity(0.35), radius: 14, y: -6)
        .offset(x: dx)
        .opacity(1 - Double(min(abs(dx) / 300, 0.7)))
        .contentShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        .onTapGesture { SiteTabs.shared.restore(tab) }
        .simultaneousGesture(
            DragGesture(minimumDistance: 20)
                .onChanged { v in
                    if abs(v.translation.width) > abs(v.translation.height) * 1.3 { dx = v.translation.width }
                }
                .onEnded { v in
                    if abs(v.translation.width) > 120 && abs(v.translation.width) > abs(v.translation.height) {
                        SiteTabs.shared.close(tab)
                    } else {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { dx = 0 }
                    }
                }
        )
    }
}

/// Значок сайта: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .fill(LinearGradient(colors: [c, c.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .strokeBorder(Color.white.opacity(0.25), lineWidth: 0.6)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.48, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
    }
}

/// Свой цвет у каждого сайта — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || r.icon.contains("envelope") { return Color(red: 0.98, green: 0.45, blue: 0.22) }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками): встроенный браузер или Safari
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        guard let u = URL(string: r.url) else { return }
        if WebModel.isPlain(u.host) {
            Haptics.tap()
            // в Safari приложение не может само вставить пароль — кладём его в буфер на минуту
            if let host = u.host, CredentialStore.enabled, let c = CredentialStore.get(host) {
                UIPasteboard.general.setItems([[UIPasteboard.typeAutomatic: c.pass]],
                                              options: [.localOnly: true, .expirationDate: Date().addingTimeInterval(60)])
            }
            SiteTabs.shared.safari = SafariLink(url: u)
        } else {
            SiteTabs.shared.open(r)
        }
    }
}
