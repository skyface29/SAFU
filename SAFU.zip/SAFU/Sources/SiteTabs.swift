import SwiftUI
import WebKit
import QuickLook
import QuickLookThumbnailing
import LocalAuthentication

// MARK: - Сайты и файлы как мини-приложения в Telegram
//
// Сайт или файл открывается карточкой на весь экран, приложение под ней отъезжает назад и темнеет.
// Шапка как у мини-приложений Telegram: крестик слева, название по центру, справа капсула «⌄ ⋯».
// Потянул шапку вниз или нажал «⌄» — карточка съезжает вниз и превращается в свою же шапку —
// плашку над вкладками. Вход, прокрутка, открытая страница PDF — всё остаётся на месте.
// Свёрнутых несколько — за плашкой видны края стопки, а нажатие открывает стопку карточек
// с наклоном назад, как в Telegram.
//
// Плавность. Карточка с сайтом рисуется без тени и без маски (раньше обе пересчитывали всю
// страницу на каждом кадре прокрутки). Пока тянешь шапку, пересчитывается только шапка —
// сама страница не перерисовывается. Под стопкой живой фон приложения стоит на паузе.

enum MiniAnim {
    static let open = Animation.spring(response: 0.42, dampingFraction: 0.92)
    static let collapse = Animation.spring(response: 0.38, dampingFraction: 1)
    static let close = Animation.spring(response: 0.34, dampingFraction: 1)
    static let back = Animation.spring(response: 0.34, dampingFraction: 0.82)
    static let stack = Animation.spring(response: 0.44, dampingFraction: 0.88)
    static let unfold = Animation.spring(response: 0.36, dampingFraction: 1)
    static let quick = Animation.spring(response: 0.28, dampingFraction: 0.88)
}

/// Размеры и цвета «хрома» мини-приложений — одни и те же у карточки, плашки и стопки,
/// поэтому переходы между ними совпадают до точки
enum MiniChrome {
    static let header: CGFloat = 54
    /// Зазор между статус-баром и развёрнутой карточкой
    static let topGap: CGFloat = 8
    static let radius: CGFloat = 22
    /// Отступ плашки свёрнутых от краёв экрана
    static let barInset: CGFloat = 10

    private static let headerUI = UIColor { t in
        t.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor(white: 0.975, alpha: 1)
    }
    static var headerColor: Color { Color(uiColor: headerUI) }

    /// Плашка — это шапка карточки, уменьшенная до ширины экрана без отступов
    static func panelScale(_ width: CGFloat) -> CGFloat {
        width > 2 * barInset ? (width - 2 * barInset) / width : 1
    }

    static var hairline: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.1))
            .frame(height: 0.5)
            .allowsHitTesting(false)
    }
}

/// Отдельная от Haptics «твёрдая» отдача — щелчок, когда карточку дотянули до сворачивания
enum SiteHaptics {
    private static let rigidGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .rigid)
        g.prepare()
        return g
    }()
    private static var enabled: Bool { UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }

    static func rigid() {
        guard enabled else { return }
        rigidGen.impactOccurred(intensity: 0.75)
        rigidGen.prepare()
    }
}

// MARK: - Вид файла: значок, цвет, подпись

enum FileLook {
    static func ext(_ url: URL) -> String { url.pathExtension.lowercased() }

    static func icon(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt", "pages", "md": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods", "numbers": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled.fill"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "photo.fill"
        case "mp4", "mov", "m4v": return "play.rectangle.fill"
        case "mp3", "m4a", "wav", "aac": return "waveform"
        case "zip", "rar", "7z": return "archivebox.fill"
        default: return "doc.fill"
        }
    }

    static func color(_ url: URL) -> Color {
        switch ext(url) {
        case "pdf": return Color(red: 0.93, green: 0.27, blue: 0.27)
        case "doc", "docx", "rtf", "odt", "pages": return Color(red: 0.20, green: 0.45, blue: 0.95)
        case "txt", "md": return Color(red: 0.45, green: 0.50, blue: 0.60)
        case "xls", "xlsx", "csv", "ods", "numbers": return Color(red: 0.13, green: 0.65, blue: 0.38)
        case "ppt", "pptx", "key", "odp": return Color(red: 0.97, green: 0.52, blue: 0.16)
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return Color(red: 0.62, green: 0.38, blue: 0.95)
        case "mp4", "mov", "m4v", "mp3", "m4a", "wav", "aac": return Color(red: 0.92, green: 0.30, blue: 0.62)
        default: return Color(red: 0.40, green: 0.48, blue: 0.62)
        }
    }

    static func kind(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "PDF"
        case "doc", "docx", "rtf", "odt", "pages": return "Документ"
        case "txt", "md": return "Текст"
        case "xls", "xlsx", "csv", "ods", "numbers": return "Таблица"
        case "ppt", "pptx", "key", "odp": return "Презентация"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "Фото"
        case "mp4", "mov", "m4v": return "Видео"
        case "mp3", "m4a", "wav", "aac": return "Аудио"
        case "": return "Файл"
        default: return ext(url).uppercased()
        }
    }

    /// «PDF · 2,4 МБ»
    static func meta(_ url: URL) -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        guard size > 0 else { return kind(url) }
        return kind(url) + " · " + ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    /// Файл в виде «ресурса»: так у него та же шапка, значок и цвет, что у сайтов
    static func resource(_ url: URL) -> Resource {
        Resource(title: url.deletingPathExtension().lastPathComponent,
                 subtitle: meta(url),
                 url: url.absoluteString,
                 icon: icon(url),
                 category: "Файлы")
    }

    static func canPrint(_ url: URL) -> Bool { UIPrintInteractionController.canPrint(url) }

    static func printFile(_ url: URL) {
        let c = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = ["jpg", "jpeg", "png", "heic", "webp", "tiff"].contains(ext(url)) ? .photo : .general
        info.jobName = url.lastPathComponent
        c.printInfo = info
        c.printingItem = url
        _ = c.present(animated: true, completionHandler: nil)
    }

    /// Положить сам файл в буфер обмена — вставляется в Telegram, почту, Заметки
    static func copy(_ url: URL) {
        guard let p = NSItemProvider(contentsOf: url) else { return }
        UIPasteboard.general.itemProviders = [p]
        Haptics.success()
    }

    /// Снимок без содержимого (QuickLook иногда рисуется в другом процессе и снимается пустым)
    static func isBlank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage else { return true }
        let w = 24, h = 24
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return false }
        var lo = [255, 255, 255], hi = [0, 0, 0]
        for i in 0..<(w * h) {
            for c in 0..<3 {
                let v = Int(px[i * 4 + c])
                lo[c] = min(lo[c], v)
                hi[c] = max(hi[c], v)
            }
        }
        return (0..<3).allSatisfy { hi[$0] - lo[$0] < 10 }
    }

    /// Снимок вида средствами UIKit — в уменьшенном масштабе, чтобы стопка не съедала память
    static func render(_ v: UIView) -> UIImage? {
        guard v.window != nil, v.bounds.width > 1, v.bounds.height > 1 else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = min(2, v.window?.screen.scale ?? 2)
        let img = UIGraphicsImageRenderer(bounds: v.bounds, format: format).image { _ in
            _ = v.drawHierarchy(in: v.bounds, afterScreenUpdates: false)
        }
        return isBlank(img) ? nil : img
    }
}

// MARK: - Просмотр файла, который переживает сворачивание

/// QuickLook живёт в карточке, а не на экране: свернул — и вернулся на ту же страницу
final class FilePreviewHolder: NSObject, QLPreviewControllerDataSource {
    let url: URL

    lazy var controller: QLPreviewController = {
        let c = QLPreviewController()
        c.dataSource = self
        return c
    }()

    init(url: URL) {
        self.url = url
        super.init()
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        url as NSURL
    }

    /// Переносим просмотр в новую карточку (старая может ещё доигрывать исчезновение)
    func attach(to box: UIViewController) {
        let c = controller
        if c.parent === box { return }
        if c.parent != nil {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        box.addChild(c)
        c.view.frame = box.view.bounds
        c.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.view.addSubview(c.view)
        c.didMove(toParent: box)
    }

    /// Снимок той страницы, на которой остановился
    func snapshot() -> UIImage? {
        guard controller.isViewLoaded, let v = controller.view else { return nil }
        return FileLook.render(v)
    }

    /// Первая страница — для карточки в стопке, пока своего снимка нет
    func makeThumbnail(_ done: @escaping (UIImage) -> Void) {
        let req = QLThumbnailGenerator.Request(fileAt: url, size: CGSize(width: 360, height: 520),
                                               scale: 2, representationTypes: .thumbnail)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
            guard let img = rep?.uiImage else { return }
            DispatchQueue.main.async { done(img) }
        }
    }
}

private struct FilePreviewBox: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .secondarySystemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ box: UIViewController, coordinator: ()) {
        // просмотр уже мог переехать в новую карточку — тогда здесь его нет и трогать нечего
        for c in box.children {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
    }
}

// MARK: - Вкладка: сайт или файл

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    /// Есть — это файл, нет — сайт
    let file: FilePreviewHolder?
    private var web: WebModel?
    /// Как выглядела вкладка, когда её свернули
    @Published var snapshot: UIImage?
    /// Первая страница файла
    @Published var thumb: UIImage?

    var isFile: Bool { file != nil }

    /// Живая страница сайта (у файлов не создаётся — им браузер не нужен)
    var model: WebModel {
        if let web { return web }
        let m = WebModel()
        web = m
        return m
    }

    init(resource: Resource) {
        self.resource = resource
        self.file = nil
    }

    init(file url: URL) {
        self.file = FilePreviewHolder(url: url)
        self.resource = FileLook.resource(url)
    }

    func matches(file url: URL) -> Bool {
        guard let f = file?.url else { return false }
        return f.standardizedFileURL.path == url.standardizedFileURL.path
    }
}

/// Где сейчас развёрнутая карточка. Все переходы — это изменения этих чисел внутри одной
/// пружинной анимации, поэтому карточка, приложение под ней и плашка двигаются согласованно
final class MiniMotion: ObservableObject {
    static let shared = MiniMotion()
    /// Палец тянет шапку вниз, точки
    @Published var drag: CGFloat = 0
    /// То же, 0…1 — по нему приложение под карточкой возвращается на место
    @Published var dragProgress: CGFloat = 0
    /// 0 — карточка развёрнута, 1 — сжалась в плашку над вкладками
    @Published var collapse: CGFloat = 0
    /// 0 — на месте, 1 — уехала за нижний край экрана
    @Published var slide: CGFloat = 0

    /// Насколько карточка ушла с экрана (для приложения под ней)
    var hidden: CGFloat { max(dragProgress, collapse, slide) }

    func reset() {
        if drag != 0 { drag = 0 }
        if dragProgress != 0 { dragProgress = 0 }
        if collapse != 0 { collapse = 0 }
        if slide != 0 { slide = 0 }
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()

    /// Откуда разворачивается карточка
    enum Entry { case bottom, bar, stack }

    /// Открытые сайты и файлы, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутая сейчас вкладка (nil — все свёрнуты)
    @Published private(set) var activeID: UUID?
    /// Прошлая развёрнутая карточка: лежит под новой, пока та выезжает снизу
    @Published private(set) var underID: UUID?
    @Published var showSwitcher = false
    /// Стопка уезжает обратно в плашку — приложение под ней уже возвращается на место
    @Published var switcherLeaving = false
    /// Старый режим «настоящим Safari» (сейчас все сайты, и почта тоже, открываются карточкой)
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26): полоса с Sakai и почтой встала в один ряд
    /// с кружком вкладок — плашка свёрнутых опускается следом, без пустого места
    @Published var barInline = false
    /// Файлы закрыты Face ID (включено «Файлы по Face ID», и приложение уходило в фон)
    @Published var filesLocked = false
    /// Идёт анимация открытия или сворачивания — повторные нажатия её не ломают
    private(set) var busy = false
    /// Номер перехода: завершение старой анимации не трогает то, что открыли поверх
    private var gen = 0

    /// Сайтов больше не держим: каждый — живая страница в памяти. Файлы лёгкие, их можно больше
    private let siteLimit = 4
    private let totalLimit = 8
    private let motion = MiniMotion.shared

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var under: SiteTab? { tabs.first { $0.id == underID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }

    private init() {
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            if UserDefaults.standard.bool(forKey: "lockFiles"), self.tabs.contains(where: { $0.isFile }) {
                self.filesLocked = true
            }
        }
    }

    // MARK: открыть

    func open(_ r: Resource) {
        if let t = tabs.first(where: { !$0.isFile && $0.resource.url == r.url }) {
            present(t, isNew: false)
        } else {
            present(SiteTab(resource: r), isNew: true)
        }
    }

    /// Файл карточкой поверх приложения — как сайт
    func openFile(_ url: URL) {
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            present(t, isNew: false)
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        present(t, isNew: true)
    }

    /// Файл сразу в свёрнутые (из окна просмотра, открытого поверх другого окна)
    func addMinimized(file url: URL) {
        Haptics.tap()
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            guard t.id != activeID else { return }
            withAnimation(MiniAnim.quick) { tabs = reordered(tabs, putting: t) }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        var list = tabs
        list.append(t)
        list = trimmed(reordered(list, putting: t), keep: [t.id])
        withAnimation(MiniAnim.quick) { tabs = list }
    }

    /// Карточка выезжает снизу. Если уже развёрнута другая — новая накрывает её, а та уходит в свёрнутые
    private func present(_ t: SiteTab, isNew: Bool) {
        Haptics.tap()
        if t.id == activeID {
            if motion.hidden > 0 && !busy { withAnimation(MiniAnim.back) { motion.reset() } }
            return
        }
        let g = bump()
        busy = true
        let previous = active
        if let previous { takeSnapshot(previous) }

        var list = tabs
        list.removeAll { $0.id == t.id }
        list.append(t)
        var keep: Set<UUID> = [t.id]
        if let p = previous?.id { keep.insert(p) }
        list = trimmed(list, keep: keep)

        noAnimation {
            motion.reset()
            motion.slide = 1
        }
        // плашка свёрнутых тает, пока карточка выезжает
        withAnimation(.easeOut(duration: 0.18)) {
            tabs = list
            underID = previous?.id
            activeID = t.id
            showSwitcher = false
            switcherLeaving = false
        }
        DispatchQueue.main.async {
            withAnimation(MiniAnim.open, completionCriteria: .logicallyComplete) {
                self.motion.slide = 0
            } completion: {
                guard g == self.gen else { return }
                self.busy = false
                if self.underID != nil { self.noAnimation { self.underID = nil } }
            }
        }
    }

    // MARK: свернуть / развернуть

    /// Развернуть свёрнутую: из плашки карточка «вырастает» из своей шапки, из стопки — уже стоит на месте
    func restore(_ t: SiteTab, from entry: Entry) {
        if entry == .bottom {
            present(t, isNew: false)
            return
        }
        guard tabs.contains(where: { $0.id == t.id }) else { return }
        if entry == .bar { Haptics.tap() }
        let g = bump()
        busy = true
        noAnimation {
            motion.reset()
            if entry == .bar { motion.collapse = 1 }
            tabs = reordered(tabs, putting: t, onTop: true)
            underID = nil
            activeID = t.id
        }
        if entry == .bar {
            DispatchQueue.main.async {
                withAnimation(MiniAnim.unfold, completionCriteria: .logicallyComplete) {
                    self.motion.collapse = 0
                } completion: {
                    if g == self.gen { self.busy = false }
                }
            }
        } else {
            // живая страница уже под стопкой — стопку убираем, когда карточка под ней нарисовалась
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.noAnimation {
                    self.showSwitcher = false
                    self.switcherLeaving = false
                }
                if g == self.gen { self.busy = false }
            }
        }
    }

    /// Карточка съезжает вниз и становится плашкой над вкладками
    @discardableResult
    func minimize() -> Bool {
        guard let t = active, !busy else { return false }
        Haptics.tap()
        takeSnapshot(t)
        let g = bump()
        busy = true
        withAnimation(MiniAnim.collapse, completionCriteria: .removed) {
            motion.collapse = 1
        } completion: {
            guard g == self.gen else { return }
            // плашка встаёт ровно туда, где закончилась шапка карточки — подмены не видно
            self.noAnimation {
                self.activeID = nil
                self.underID = nil
                self.motion.reset()
            }
            self.busy = false
        }
        return true
    }

    /// Нажали на плашку: одна вкладка — сразу разворачиваем, несколько — стопка карточек как в Telegram
    func tapBar() {
        guard !busy else { return }
        let list = minimized
        if list.count > 1 {
            Haptics.tap()
            switcherLeaving = false
            withAnimation(MiniAnim.stack) { showSwitcher = true }
        } else if let t = list.last {
            restore(t, from: .bar)
        }
    }

    /// Стопка доиграла уход в плашку
    func hideSwitcher() {
        noAnimation {
            showSwitcher = false
            switcherLeaving = false
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(MiniAnim.quick) { barInline = inline }
    }

    // MARK: закрыть

    func close(_ t: SiteTab) {
        SiteHaptics.rigid()
        guard t.id == activeID else {
            withAnimation(MiniAnim.stack) { remove(t) }
            return
        }
        guard !busy else { return }
        let g = bump()
        busy = true
        // развёрнутая уезжает вниз за край экрана, как лист
        withAnimation(MiniAnim.close, completionCriteria: .logicallyComplete) {
            motion.slide = 1
        } completion: {
            guard g == self.gen else { return }
            withAnimation(.easeOut(duration: 0.2)) {
                self.remove(t)
                self.activeID = nil
                self.underID = nil
            }
            self.noAnimation { self.motion.reset() }
            self.busy = false
        }
    }

    func closeAll() {
        SiteHaptics.rigid()
        bump()
        busy = false
        withAnimation(MiniAnim.stack) {
            tabs = []
            activeID = nil
            underID = nil
            showSwitcher = false
            switcherLeaving = false
        }
        noAnimation { motion.reset() }
        filesLocked = false
    }

    private func remove(_ t: SiteTab) {
        tabs.removeAll { $0.id == t.id }
        if tabs.isEmpty {
            showSwitcher = false
            switcherLeaving = false
        }
        if !tabs.contains(where: { $0.isFile }) { filesLocked = false }
    }

    // MARK: Face ID для файлов

    func unlockFiles() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            filesLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return }
                Haptics.success()
                withAnimation(.easeInOut(duration: 0.25)) { self.filesLocked = false }
            }
        }
    }

    /// Окно поверх приложения (лист, полноэкранное окно) — тогда карточку не будет видно под ним
    static var canShowOnTop: Bool {
        let windows = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
        guard let main = windows.first(where: { $0.windowLevel == .normal && $0.rootViewController != nil }) else { return true }
        return main.rootViewController?.presentedViewController == nil
    }

    // MARK: служебное

    @discardableResult
    private func bump() -> Int {
        gen += 1
        return gen
    }

    private func noAnimation(_ body: () -> Void) {
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t, body)
    }

    /// Вкладку — в самый верх свёрнутых. Развёрнутая (если есть) остаётся последней:
    /// иначе при сворачивании плашка показала бы не ту вкладку
    private func reordered(_ input: [SiteTab], putting t: SiteTab, onTop: Bool = false) -> [SiteTab] {
        var list = input
        list.removeAll { $0.id == t.id }
        if !onTop, let a = activeID, a != t.id, let i = list.firstIndex(where: { $0.id == a }) {
            list.insert(t, at: i)
        } else {
            list.append(t)
        }
        return list
    }

    /// Самые давние вкладки закрываем, чтобы не тратить память
    private func trimmed(_ input: [SiteTab], keep: Set<UUID>) -> [SiteTab] {
        var list = input
        var keep = keep
        if let a = activeID { keep.insert(a) }
        if let u = underID { keep.insert(u) }
        while list.filter({ !$0.isFile }).count > siteLimit,
              let old = list.first(where: { !$0.isFile && !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        while list.count > totalLimit, let old = list.first(where: { !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        return list
    }

    /// Снимок для стопки — сразу, пока карточка ещё на экране
    private func takeSnapshot(_ t: SiteTab) {
        if let holder = t.file {
            if let img = holder.snapshot() { t.snapshot = img }
            return
        }
        let wv = t.model.webView
        guard wv.window != nil, wv.bounds.width > 1, wv.bounds.height > 1 else { return }
        let config = WKSnapshotConfiguration()
        config.afterScreenUpdates = false
        config.snapshotWidth = NSNumber(value: Double(min(wv.bounds.width, 340)))
        wv.takeSnapshot(with: config) { [weak t, weak wv] image, _ in
            if let image {
                t?.snapshot = image
            } else if let wv, let img = FileLook.render(wv) {
                // запасной путь: WebKit иногда отдаёт пустой снимок, пока страница грузится
                t?.snapshot = img
            }
        }
    }
}

// MARK: - Приложение под карточкой отъезжает назад, как в Telegram

/// Чёрные уголки поверх приложения: при уменьшении у него появляются скруглённые углы,
/// без маски и лишней отрисовки всего экрана
private struct CornerCaps: Shape {
    var radius: CGFloat

    func path(in rect: CGRect) -> Path {
        var p = Path(rect)
        p.addRoundedRect(in: rect, cornerSize: CGSize(width: radius, height: radius), style: .continuous)
        return p
    }
}

struct SiteBackdrop: ViewModifier {
    @ObservedObject private var tabs = SiteTabs.shared
    @ObservedObject private var motion = MiniMotion.shared

    private var amount: CGFloat {
        if tabs.showSwitcher { return tabs.switcherLeaving ? 0 : 1 }
        if tabs.underID != nil { return 1 }
        if tabs.activeID != nil { return 1 - motion.hidden }
        return 0
    }

    func body(content: Content) -> some View {
        let a = amount
        let on = a > 0.001
        return content
            .overlay {
                ZStack {
                    Color.black.opacity(0.34 * a)
                    CornerCaps(radius: 44)
                        .fill(Color.black, style: FillStyle(eoFill: true))
                }
                .ignoresSafeArea()
                .opacity(on ? 1 : 0)
                .allowsHitTesting(false)
            }
            .scaleEffect(1 - 0.06 * a)
            .background {
                Color.black
                    .ignoresSafeArea()
                    .opacity(on ? 1 : 0)
            }
    }
}

// MARK: - Шапка мини-приложения

/// Крестик слева, значок и название по центру, справа — что передали (обычно капсула «⌄ ⋯»)
struct MiniHeader<Trailing: View>: View {
    let resource: Resource
    var onClose: (() -> Void)? = nil
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        ZStack {
            HStack(spacing: 8) {
                SiteIcon(resource: resource, size: 22)
                Text(resource.title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            .padding(.horizontal, 96)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)

            HStack(spacing: 0) {
                Button {
                    onClose?()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 46, height: 46)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")

                Spacer(minLength: 0)
                trailing()
            }
            .padding(.leading, 6)
            .padding(.trailing, 10)
        }
        .frame(height: MiniChrome.header)
        .frame(maxWidth: .infinity)
        .background(MiniChrome.headerColor)
    }
}

/// Капсула справа в шапке, как у мини-приложений Telegram: «свернуть» и «ещё».
/// У плашки свёрнутых та же капсула, только стрелка смотрит вверх, а «ещё» спрятано
struct MiniPill<Items: View>: View {
    /// 0 — карточка развёрнута (⌄ и ⋯), 1 — сжалась в плашку (только ⌃)
    var collapse: CGFloat = 0
    var chevronLabel = "Свернуть"
    var onChevron: (() -> Void)? = nil
    @ViewBuilder var menu: () -> Items

    var body: some View {
        HStack(spacing: 0) {
            if let onChevron {
                Button(action: onChevron) {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 15, weight: .bold))
                        .rotationEffect(.degrees(Double(180 * collapse)))
                        .foregroundStyle(.primary)
                        .frame(width: 38, height: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(chevronLabel)
            }
            Menu {
                menu()
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 38, height: 32)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("Ещё")
            .frame(width: 38 * max(0, 1 - collapse), alignment: .leading)
            .opacity(Double(max(0, 1 - collapse * 1.6)))
            .clipped()
            .allowsHitTesting(collapse < 0.5)
        }
        .frame(height: 32)
        .background(Color.primary.opacity(0.08), in: Capsule(style: .continuous))
    }
}

/// Меню «⋯» карточки: у сайта — свои пункты, у файла — свои
private struct CardMenu: View {
    let tab: SiteTab

    var body: some View {
        if let f = tab.file?.url {
            FileMenuItems(url: f)
        } else {
            WebMenuItems(model: tab.model, resource: tab.resource)
        }
    }
}

struct FileMenuItems: View {
    let url: URL
    /// В отдельном окне просмотра файл не прячется за Face ID — там это меню всегда полное
    var respectsLock = true
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        Section(FileLook.meta(url)) {
            if respectsLock && tabs.filesLocked {
                Button { tabs.unlockFiles() } label: { Label("Разблокировать", systemImage: "faceid") }
            } else {
                ShareLink(item: url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                Button { FileLook.copy(url) } label: { Label("Скопировать файл", systemImage: "doc.on.doc") }
                if FileLook.canPrint(url) {
                    Button { FileLook.printFile(url) } label: { Label("Напечатать", systemImage: "printer") }
                }
            }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутая карточка, плашка свёрнутых, стопка

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под плашкой системная полоса с Sakai и почтой: когда панель сжимается, плашка опускается следом
    var followsBar = false

    var body: some View {
        GeometryReader { geo in
            let lift = 58 + ((followsBar && tabs.barInline) ? -4 : bottomExtra)
            let panel = MiniChrome.panelScale(geo.size.width)
            let barTop = geo.size.height - lift - MiniChrome.header * panel
            let cards = [tabs.under, tabs.active].compactMap { $0 }

            ZStack(alignment: .top) {
                if tabs.active == nil && !tabs.minimized.isEmpty && !tabs.showSwitcher {
                    MinimizedBar(width: geo.size.width)
                        .offset(y: barTop)
                        .transition(.opacity)
                        .zIndex(1)
                }

                // одна и та же карточка остаётся тем же видом, когда уходит «под» новую:
                // живая страница не пересоздаётся и не моргает
                ForEach(cards) { t in
                    ExpandedCard(tab: t,
                                 live: t.id == tabs.activeID,
                                 size: geo.size,
                                 bottomInset: geo.safeAreaInsets.bottom,
                                 barTop: barTop)
                        .zIndex(t.id == tabs.activeID ? 3 : 2)
                        .transition(.identity)
                }

                if tabs.showSwitcher {
                    StackSwitcher(safeTop: geo.safeAreaInsets.top,
                                  barTop: geo.safeAreaInsets.top + barTop)
                        .zIndex(4)
                        .transition(.identity)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
        }
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }
}

// MARK: - Развёрнутая карточка

/// Карточка на весь экран. Её положение целиком задаётся MiniMotion: тянешь шапку —
/// карточка идёт за пальцем, сворачиваешь — съезжает и сжимается ровно в плашку,
/// закрываешь — уезжает за нижний край
private struct ExpandedCard: View {
    @ObservedObject var tab: SiteTab
    /// false — карточка лежит под новой и ни на что не реагирует
    let live: Bool
    let size: CGSize
    let bottomInset: CGFloat
    let barTop: CGFloat
    @ObservedObject private var motion = MiniMotion.shared
    @State private var armed = false

    var body: some View {
        let top = MiniChrome.topGap
        let fullH = max(size.height - top + bottomInset, MiniChrome.header + 1)
        let c = live ? motion.collapse : 0
        let slide = live ? motion.slide : 0
        let dragY = live ? motion.drag : 0
        let dragP = live ? motion.dragProgress : 0
        let panel = MiniChrome.panelScale(size.width)
        let dragScale = 1 - 0.06 * dragP
        let scale = dragScale + (panel - dragScale) * c
        let y = top + dragY + (barTop - top - dragY) * c + slide * (fullH + 80)
        let visible = fullH - (fullH - MiniChrome.header) * c

        VStack(spacing: 0) {
            header(collapse: c)
            CardBody(tab: tab, bottomInset: bottomInset)
                .frame(height: fullH - MiniChrome.header)
                .opacity(Double(1 - c))
                .allowsHitTesting(c < 0.01)
        }
        .frame(width: size.width, height: visible, alignment: .top)
        .background(MiniChrome.headerColor)
        .clipShape(RoundedRectangle(cornerRadius: MiniChrome.radius, style: .continuous))
        .scaleEffect(scale, anchor: .top)
        .offset(y: y)
        .frame(width: size.width, height: size.height, alignment: .top)
        .allowsHitTesting(live)
        .pausesAmbient()
    }

    private func header(collapse c: CGFloat) -> some View {
        let t = tab
        return MiniHeader(resource: t.resource, onClose: { SiteTabs.shared.close(t) }) {
            MiniPill(collapse: c, onChevron: { _ = SiteTabs.shared.minimize() }) {
                CardMenu(tab: t)
            }
        }
        // тянуть вниз можно за всю шапку, кроме кнопок по краям
        .overlay {
            HStack(spacing: 0) {
                Color.clear.frame(width: 56)
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(dragGesture)
                Color.clear.frame(width: 100)
            }
            .accessibilityHidden(true)
        }
    }

    private var dragGesture: some Gesture {
        DragGesture(minimumDistance: 3, coordinateSpace: .global)
            .onChanged { v in
                guard live, !SiteTabs.shared.busy else { return }
                let y = v.translation.height
                // вверх карточка почти не идёт — лёгкое сопротивление, как у резинки
                let d = y >= 0 ? y : -pow(-y, 0.6)
                motion.drag = d
                motion.dragProgress = min(1, max(0, d / max(size.height * 0.6, 1)))
                let nowArmed = y > 120
                if nowArmed != armed {
                    armed = nowArmed
                    if nowArmed { SiteHaptics.rigid() }
                }
            }
            .onEnded { v in
                guard live else { return }
                armed = false
                let far = v.translation.height > 120 || v.predictedEndTranslation.height > 380
                if !(far && SiteTabs.shared.minimize()) {
                    withAnimation(MiniAnim.back) {
                        motion.drag = 0
                        motion.dragProgress = 0
                    }
                }
            }
    }
}

/// Содержимое карточки. Входные данные не меняются, пока карточку тянут или сворачивают,
/// поэтому SwiftUI не пересчитывает страницу на каждом кадре
private struct CardBody: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        if tab.isFile {
            FileBody(tab: tab)
        } else {
            WebScreen(resource: tab.resource, model: tab.model, embeddedInset: bottomInset)
        }
    }
}

// MARK: - Карточка файла

private struct FileBody: View {
    let tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        ZStack {
            if let holder = tab.file {
                FilePreviewBox(holder: holder)
            } else {
                Color(.secondarySystemBackground)
            }
            if tabs.filesLocked {
                FileLockedView()
                    .transition(.opacity)
            }
        }
        .overlay(alignment: .top) { MiniChrome.hairline }
        .animation(.easeInOut(duration: 0.25), value: tabs.filesLocked)
    }
}

private struct FileLockedView: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.regularMaterial)
            VStack(spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.secondary)
                Text("Файл защищён")
                    .font(.headline)
                Button { SiteTabs.shared.unlockFiles() } label: {
                    Label("Открыть по Face ID", systemImage: "faceid")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear { SiteTabs.shared.unlockFiles() }
    }
}

// MARK: - Плашка свёрнутых

/// Шапка свёрнутой карточки над вкладками — как в Telegram. Если свёрнуто несколько,
/// за ней видны края остальных. Нажал или смахнул вверх — развернуть (несколько — стопка),
/// смахнул вбок или крестик — закрыть, долгое нажатие — меню с «Закрыть все»
private struct MinimizedBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let width: CGFloat
    @State private var dx: CGFloat = 0
    @State private var dy: CGFloat = 0
    @State private var peek = false

    var body: some View {
        let list = tabs.minimized
        if let top = list.last {
            let s = MiniChrome.panelScale(width)
            let layers = min(list.count - 1, 2)
            let shape = RoundedRectangle(cornerRadius: MiniChrome.radius, style: .continuous)

            ZStack(alignment: .top) {
                // края остальных свёрнутых — выглядывают сверху, как карты в колоде
                ForEach(0..<2, id: \.self) { k in
                    shape
                        .fill(MiniChrome.headerColor)
                        .overlay(shape.strokeBorder(Color.primary.opacity(0.1), lineWidth: 0.5))
                        .frame(width: width, height: MiniChrome.header)
                        .scaleEffect(1 - 0.07 * CGFloat(k + 1), anchor: .top)
                        .offset(y: (peek && k < layers) ? -CGFloat(k + 1) * 6.5 : 0)
                        .opacity(k < layers ? (k == 0 ? 0.8 : 0.55) : 0)
                        .zIndex(Double(-k - 1))
                }

                MiniHeader(resource: top.resource, onClose: { flyAway(top) }) {
                    MiniPill(collapse: 1,
                             chevronLabel: list.count > 1 ? "Показать все" : "Развернуть",
                             onChevron: { tabs.tapBar() }) { EmptyView() }
                }
                .frame(width: width)
                .clipShape(shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.1), lineWidth: 0.5))
                .contentShape(shape)
                .onTapGesture { tabs.tapBar() }
                .contextMenu {
                    Button { tabs.tapBar() } label: {
                        Label(list.count > 1 ? "Показать все" : "Развернуть", systemImage: "rectangle.stack")
                    }
                    Button(role: .destructive) { tabs.close(top) } label: {
                        Label("Закрыть «\(top.resource.title)»", systemImage: "xmark")
                    }
                    if list.count > 1 {
                        Button(role: .destructive) { tabs.closeAll() } label: {
                            Label("Закрыть все", systemImage: "xmark.circle")
                        }
                    }
                }
                .zIndex(1)
            }
            .frame(width: width)
            .scaleEffect(s, anchor: .top)
            .frame(width: width * s, height: MiniChrome.header * s, alignment: .top)
            .offset(x: dx, y: dy)
            .opacity(1 - Double(min(abs(dx) / max(width, 1), 0.8)))
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { v in
                        if abs(v.translation.width) > abs(v.translation.height) {
                            dx = v.translation.width
                        } else if v.translation.height < 0 {
                            dy = -pow(-v.translation.height, 0.7)          // тянется вверх за пальцем
                        }
                    }
                    .onEnded { v in
                        if v.translation.height < -24 && abs(v.translation.height) > abs(v.translation.width) {
                            withAnimation(MiniAnim.quick) { dx = 0; dy = 0 }
                            tabs.tapBar()                                            // смахнул вверх — развернуть
                        } else if abs(v.translation.width) > 90 || abs(v.predictedEndTranslation.width) > 260 {
                            flyAway(top, to: v.translation.width < 0 ? -1 : 1)        // смахнул вбок — закрыть
                        } else {
                            withAnimation(MiniAnim.back) { dx = 0; dy = 0 }
                        }
                    }
            )
            .onAppear {
                DispatchQueue.main.async { withAnimation(MiniAnim.stack) { peek = true } }
            }
            .accessibilityElement(children: .contain)
            .accessibilityLabel(list.count > 1 ? "Свёрнуто: \(top.resource.title) и ещё \(list.count - 1)" : "Свёрнуто: \(top.resource.title)")
            .accessibilityAction(named: Text(list.count > 1 ? "Показать все" : "Развернуть")) { tabs.tapBar() }
        }
    }

    private func flyAway(_ t: SiteTab, to side: CGFloat = 1) {
        withAnimation(.easeOut(duration: 0.2)) { dx = side * width }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            tabs.close(t)
            var tr = Transaction()
            tr.disablesAnimations = true
            withTransaction(tr) {
                dx = 0
                dy = 0
            }
        }
    }
}

// MARK: - Стопка открытых вкладок как в Telegram

/// Наклон карточки назад вокруг верхнего края с перспективой.
/// Свой эффект вместо rotation3DEffect: глубина задаётся точно, и всё плавно анимируется
private struct TiltEffect: GeometryEffect {
    /// Градусы; больше нуля — низ карточки уходит вглубь
    var angle: CGFloat
    var scale: CGFloat
    /// Расстояние до «глаза», точки — чем меньше, тем сильнее перспектива
    var depth: CGFloat

    var animatableData: AnimatablePair<CGFloat, AnimatablePair<CGFloat, CGFloat>> {
        get { AnimatablePair(angle, AnimatablePair(scale, depth)) }
        set {
            angle = newValue.first
            scale = newValue.second.first
            depth = newValue.second.second
        }
    }

    func effectValue(size: CGSize) -> ProjectionTransform {
        let cx = size.width / 2
        var t = CATransform3DMakeTranslation(-cx, 0, 0)
        t = CATransform3DConcat(t, CATransform3DMakeScale(scale, scale, 1))
        t = CATransform3DConcat(t, CATransform3DMakeRotation(-angle * .pi / 180, 1, 0, 0))
        var p = CATransform3DIdentity
        p.m34 = -1 / max(depth, 1)
        t = CATransform3DConcat(t, p)
        t = CATransform3DConcat(t, CATransform3DMakeTranslation(cx, 0, 0))
        return ProjectionTransform(t)
    }
}

/// Раскладка стопки: старые сверху, свежая — внизу и поверх всех; верх последней — чуть ниже середины экрана.
/// Если карточек много, лишние у верхнего края складываются в тонкую пачку, остальное — прокруткой
private struct StackLayout {
    let count: Int
    let height: CGFloat
    let first: CGFloat
    let last: CGFloat
    let step: CGFloat
    let maxScroll: CGFloat
    let cardHeight: CGFloat
    let scale: CGFloat

    init(count: Int, size: CGSize, safeTop: CGFloat) {
        self.count = count
        height = size.height
        first = safeTop + 12
        last = max(first, size.height * 0.53)
        if count > 1 {
            step = min(max((last - first) / CGFloat(count - 1), size.height * 0.13), size.height * 0.45)
        } else {
            step = 0
        }
        maxScroll = max(0, first - (last - step * CGFloat(max(count - 1, 0))))
        cardHeight = max(size.height - safeTop - MiniChrome.topGap, 200)
        scale = size.width > 28 ? (size.width - 28) / size.width : 1
    }

    /// Верх карточки и насколько глубоко она ушла в пачку у верхнего края
    func top(_ i: Int, scroll: CGFloat) -> (y: CGFloat, depth: CGFloat) {
        let raw: CGFloat
        if count <= 1 {
            raw = first + (last - first) * 0.4 + scroll
        } else {
            raw = last - step * CGFloat(count - 1 - i) + scroll
        }
        guard raw < first else { return (raw, 0) }
        let over = min(first - raw, step * 4)
        return (first - over * 0.06, min(over / max(step, 1), 4))
    }

    /// Чем ниже карточка, тем сильнее она наклонена — как в Telegram
    func angle(at y: CGFloat) -> CGFloat {
        min(max(15 + 34 * y / max(height, 1), 12), 40)
    }
}

/// Карточки лежат друг на друге с наклоном назад, у каждой видна шапка.
/// Нажал — карточка выпрямляется и разворачивается на весь экран; крестик или смахнул вбок — закрыл;
/// потянул вниз или нажал выше карточек — стопка уходит обратно в плашку
private struct StackSwitcher: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let safeTop: CGFloat
    /// Верх плашки свёрнутых в координатах всего экрана — туда стопка и уезжает
    let barTop: CGFloat

    @State private var shown = false
    @State private var leaving = false
    @State private var opening: UUID?
    @State private var scroll: CGFloat = 0
    @State private var scrollStart: CGFloat?
    @State private var axis: Axis?
    @State private var swipeID: UUID?
    @State private var swipeX: CGFloat = 0

    private struct Pose {
        var y: CGFloat
        var angle: CGFloat
        var scale: CGFloat
        var dim: Double
        var pill: CGFloat
        var opacity: Double
    }

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            let list = tabs.tabs
            let lay = StackLayout(count: list.count, size: size, safeTop: safeTop)
            let sc = axis == .vertical ? scroll : min(max(scroll, 0), lay.maxScroll)

            ZStack(alignment: .top) {
                ZStack {
                    Rectangle().fill(.ultraThinMaterial)
                    Color.black.opacity(0.5)
                }
                .environment(\.colorScheme, .dark)
                .opacity(shown && opening == nil && !leaving ? 1 : 0)
                .animation(.easeOut(duration: 0.28), value: shown)
                .allowsHitTesting(false)

                ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                    let p = pose(t, index: i, lay: lay, scroll: sc, size: size)
                    let dx: CGFloat = t.id == swipeID ? swipeX : 0
                    let fade: Double = p.opacity * swipeFade(dx, width: size.width)
                    let delay: Double = Double(list.count - 1 - i) * 0.03
                    StackCardView(tab: t, dim: p.dim, pill: p.pill)
                        .frame(width: size.width, height: lay.cardHeight, alignment: .top)
                        .modifier(TiltEffect(angle: p.angle, scale: p.scale, depth: size.height * 0.8))
                        .offset(x: dx, y: p.y)
                        .opacity(fade)
                        .animation(MiniAnim.stack.delay(delay), value: shown)
                        .zIndex(Double(i))
                        .allowsHitTesting(false)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(t.resource.title)
                        .accessibilityAddTraits(.isButton)
                        .accessibilityAction { open(t) }
                        .accessibilityAction(named: Text("Закрыть")) { tabs.close(t) }
                }
            }
            .frame(width: size.width, height: size.height, alignment: .top)
            .contentShape(Rectangle())
            .gesture(dragGesture(lay: lay, list: list, size: size))
            .onTapGesture(coordinateSpace: .local) { point in
                tap(at: point, lay: lay, list: list, size: size)
            }
        }
        .ignoresSafeArea()
        .pausesAmbient()
        .onAppear {
            DispatchQueue.main.async { shown = true }
        }
        .accessibilityAction(.escape) { dismiss() }
    }

    private func swipeFade(_ dx: CGFloat, width: CGFloat) -> Double {
        1 - Double(min(abs(dx) / max(width, 1), 0.8))
    }

    private func pose(_ t: SiteTab, index i: Int, lay: StackLayout, scroll: CGFloat, size: CGSize) -> Pose {
        let pos = lay.top(i, scroll: scroll)
        var p = Pose(y: pos.y, angle: lay.angle(at: pos.y),
                     scale: lay.scale * (1 - 0.035 * pos.depth),
                     dim: min(0.12 * Double(pos.depth), 0.4), pill: 0, opacity: 1)
        if let o = opening {
            if o == t.id {
                // выпрямляется точно в развёрнутую карточку — потом её подменяет живая страница
                p = Pose(y: safeTop + MiniChrome.topGap, angle: 0, scale: 1, dim: 0, pill: 1, opacity: 1)
            } else {
                p.y += size.height * 0.5
                p.opacity = 0
            }
        } else if leaving {
            p.y = barTop
            p.angle = 0
            p.scale = lay.scale * 0.94
            p.opacity = 0
        } else if !shown {
            p.y = size.height + 40 + CGFloat(i) * 24
            p.angle = lay.angle(at: size.height)
        }
        return p
    }

    // MARK: жесты

    private func cardIndex(at point: CGPoint, lay: StackLayout, count: Int) -> Int? {
        let sc = min(max(scroll, 0), lay.maxScroll)
        var hit: Int?
        for i in 0..<count where lay.top(i, scroll: sc).y <= point.y { hit = i }
        return hit
    }

    private func tap(at point: CGPoint, lay: StackLayout, list: [SiteTab], size: CGSize) {
        guard shown, opening == nil, !leaving else { return }
        guard let i = cardIndex(at: point, lay: lay, count: list.count) else {
            dismiss()
            return
        }
        let t = list[i]
        let top = lay.top(i, scroll: min(max(scroll, 0), lay.maxScroll)).y
        let inset = size.width * (1 - lay.scale) / 2
        // крестик в шапке карточки
        if point.y - top < MiniChrome.header * lay.scale && point.x < inset + 54 {
            close(t)
        } else {
            open(t)
        }
    }

    private func dragGesture(lay: StackLayout, list: [SiteTab], size: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 8)
            .onChanged { v in
                guard opening == nil, !leaving else { return }
                if axis == nil {
                    let horizontal = abs(v.translation.width) > abs(v.translation.height)
                    axis = horizontal ? .horizontal : .vertical
                    scrollStart = min(max(scroll, 0), lay.maxScroll)
                    if horizontal, let i = cardIndex(at: v.startLocation, lay: lay, count: list.count) {
                        swipeID = list[i].id
                    }
                }
                if axis == .horizontal {
                    if swipeID != nil { swipeX = v.translation.width }
                } else {
                    scroll = rubber((scrollStart ?? 0) + v.translation.height, max: lay.maxScroll)
                }
            }
            .onEnded { v in
                let wasAxis = axis
                let start = scrollStart ?? 0
                axis = nil
                scrollStart = nil
                guard opening == nil, !leaving else { return }
                if wasAxis == .horizontal {
                    let w = v.translation.width
                    if let id = swipeID, let t = list.first(where: { $0.id == id }),
                       abs(w) > 110 || abs(v.predictedEndTranslation.width) > 320 {
                        withAnimation(.easeOut(duration: 0.2)) { swipeX = (w < 0 ? -1 : 1) * size.width * 1.2 }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) { close(t) }
                    } else {
                        withAnimation(MiniAnim.back) {
                            swipeX = 0
                            swipeID = nil
                        }
                    }
                } else {
                    // потянул вниз, когда прокручивать некуда, — стопка уходит в плашку
                    if v.translation.height > 130 && start + v.translation.height > lay.maxScroll + 110 {
                        dismiss()
                        return
                    }
                    let target = start + v.predictedEndTranslation.height
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.92)) {
                        scroll = min(max(target, 0), lay.maxScroll)
                    }
                }
            }
    }

    private func rubber(_ v: CGFloat, max m: CGFloat) -> CGFloat {
        if v < 0 { return -pow(-v, 0.7) }
        if v > m { return m + pow(v - m, 0.7) }
        return v
    }

    // MARK: действия

    private func open(_ t: SiteTab) {
        guard opening == nil, !leaving else { return }
        Haptics.tap()
        withAnimation(MiniAnim.unfold, completionCriteria: .logicallyComplete) {
            opening = t.id
        } completion: {
            SiteTabs.shared.restore(t, from: .stack)
        }
    }

    private func close(_ t: SiteTab) {
        // улетевшая карточка исчезает там, куда её смахнули; сбрасываем смахивание уже без анимации
        tabs.close(t)
        var tr = Transaction()
        tr.disablesAnimations = true
        withTransaction(tr) {
            swipeID = nil
            swipeX = 0
        }
    }

    private func dismiss() {
        guard opening == nil, !leaving else { return }
        Haptics.tap()
        withAnimation(.spring(response: 0.32, dampingFraction: 1), completionCriteria: .logicallyComplete) {
            leaving = true
            tabs.switcherLeaving = true
        } completion: {
            SiteTabs.shared.hideSwitcher()
        }
    }
}

/// Карточка в стопке: живая шапку и снимок страницы — так же, как карточка выглядит развёрнутой
private struct StackCardView: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    let dim: Double
    /// 0…1: появляется капсула «⌄ ⋯», пока карточка разворачивается
    let pill: CGFloat
    @AppStorage("web.light") private var forceLight = true

    var body: some View {
        VStack(spacing: 0) {
            MiniHeader(resource: tab.resource) {
                MiniPill(onChevron: {}) { EmptyView() }
                    .opacity(Double(pill))
            }
            preview
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .overlay(alignment: .top) { MiniChrome.hairline }
        }
        .background(MiniChrome.headerColor)
        .overlay(Color.black.opacity(dim))
        .clipShape(RoundedRectangle(cornerRadius: MiniChrome.radius, style: .continuous))
    }

    private var locked: Bool { tab.isFile && tabs.filesLocked }

    private var pageColor: Color {
        if tab.isFile { return Color(.secondarySystemBackground) }
        return forceLight ? Color.white : Color(.systemBackground)
    }

    private var preview: some View {
        ZStack(alignment: .top) {
            pageColor
            if locked {
                VStack(spacing: 10) {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 30, weight: .semibold))
                    Text("Защищено")
                        .font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(.secondary)
                .padding(.top, 110)
            } else if let img = tab.snapshot {
                Image(uiImage: img)
                    .resizable()
                    .interpolation(.medium)
                    .aspectRatio(contentMode: .fit)
            } else if let thumb = tab.thumb {
                // первая страница файла, как в просмотрщике: лист с полями
                Image(uiImage: thumb)
                    .resizable()
                    .interpolation(.medium)
                    .aspectRatio(contentMode: .fit)
                    .overlay(Rectangle().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
            } else {
                SiteIcon(resource: tab.resource, size: 40)
                    .opacity(0.3)
                    .padding(.top, 140)
            }
        }
        .clipped()
    }
}

/// Значок вкладки: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28, style: .continuous)
                .fill(c)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.5, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// Свой цвет у каждого сайта и типа файла — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        if let u = URL(string: r.url), u.isFileURL { return FileLook.color(u) }
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || host == "edu.narfu.ru" || r.icon.contains("envelope") {
            return Color(red: 0.98, green: 0.45, blue: 0.22)
        }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками) — карточкой, все сайты одинаково
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        SiteTabs.shared.open(r)
    }

    /// Ссылка из любого места: поверх приложения — карточкой, поверх окна — в этом окне Safari
    static func link(_ u: URL) {
        let r = Resource(title: u.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт",
                         subtitle: "", url: u.absoluteString, icon: "globe", category: "Ссылки")
        SiteTabs.shared.open(r)
    }
}
