import SwiftUI
import Combine
import WebKit
import QuickLook
import QuickLookThumbnailing
import LocalAuthentication

// MARK: - Сайты и файлы как мини-приложения в Telegram
//
// Сайт или файл открывается карточкой на весь экран, приложение под ней отъезжает назад и темнеет.
// Шапка как у мини-приложений Telegram: крестик слева, название по центру, справа капсула «⌄ ⋯».
// Потянул шапку вниз или нажал «⌄» — карточка съезжает вниз и превращается в свою же шапку —
// плашку над вкладками. Вход, прокрутка, открытая страница PDF — всё остаётся на месте.
// Свёрнутых несколько — за плашкой видны края стопки, а нажатие открывает стопку карточек
// с наклоном назад, как в Telegram.
//
// Плавность. Карточка с сайтом рисуется без тени и без маски (раньше обе пересчитывали всю
// страницу на каждом кадре прокрутки). Пока тянешь шапку, пересчитывается только шапка —
// сама страница не перерисовывается. Под стопкой живой фон приложения стоит на паузе.

enum MiniAnim {
    static let open = Animation.spring(response: 0.42, dampingFraction: 0.92)
    static let collapse = Animation.spring(response: 0.38, dampingFraction: 1)
    static let close = Animation.spring(response: 0.34, dampingFraction: 1)
    static let back = Animation.spring(response: 0.34, dampingFraction: 0.82)
    static let stack = Animation.spring(response: 0.44, dampingFraction: 0.88)
    static let unfold = Animation.spring(response: 0.36, dampingFraction: 1)
    static let quick = Animation.spring(response: 0.28, dampingFraction: 0.88)

    /// Доводка после жеста: продолжает движение пальца с его скоростью, без отскока
    static func fling(_ velocity: CGFloat) -> Animation {
        .interpolatingSpring(mass: 1, stiffness: 300, damping: 34,
                             initialVelocity: Double(min(max(velocity, -5), 5)))
    }
}

/// Размеры и цвета «хрома» мини-приложений — одни и те же у карточки, плашки и стопки,
/// поэтому переходы между ними совпадают до точки
enum MiniChrome {
    static let header: CGFloat = 54
    /// Зазор между статус-баром и развёрнутой карточкой
    static let topGap: CGFloat = 8
    static let radius: CGFloat = 22
    /// Отступ плашки свёрнутых от краёв экрана
    static let barInset: CGFloat = 10
    /// Свёрнутое окно — маленькая капсула по центру над вкладками
    static let capsuleHeight: CGFloat = 44
    /// Ширина капсулы постоянная — окно перетекает ровно в неё
    static func capsuleWidth(_ screen: CGFloat) -> CGFloat { min(224, max(160, screen - 110)) }

    // Островок свёрнутых окон — как панель задач Windows: только значки и чёрточка под ними
    static let islandHeight: CGFloat = 50
    static let islandSlot: CGFloat = 44
    static let islandIcon: CGFloat = 30
    static let islandPad: CGFloat = 5
    static let islandRadius: CGFloat = 17
    static let islandMax = 7

    static func islandWidth(_ n: Int) -> CGFloat { CGFloat(min(max(n, 1), islandMax)) * islandSlot + islandPad * 2 }

    /// Где на экране значок окна номер i из n (по центру над вкладками)
    static func islandSlotRect(_ i: Int, of n: Int, screen: CGFloat, centerY: CGFloat) -> CGRect {
        let shown = min(max(n, 1), islandMax)
        let idx = min(max(i, 0), shown - 1)
        let x0 = (screen - islandWidth(shown)) / 2 + islandPad
        return CGRect(x: x0 + CGFloat(idx) * islandSlot, y: centerY - islandSlot / 2, width: islandSlot, height: islandSlot)
    }
    /// До какого размера уменьшается окно, когда влетает в капсулу (как сворачивание в Windows)
    static let minScale: CGFloat = 0.16

    /// Центр капсулы по вертикали, если верх полосы плашки — barTop
    static func capsuleCenter(barTop: CGFloat, width: CGFloat) -> CGFloat {
        barTop + header * panelScale(width) / 2
    }

    private static let headerUI = UIColor { t in
        t.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor(white: 0.975, alpha: 1)
    }
    static var headerColor: Color { Color(uiColor: headerUI) }

    /// Плашка — это шапка карточки, уменьшенная до ширины экрана без отступов
    static func panelScale(_ width: CGFloat) -> CGFloat {
        width > 2 * barInset ? (width - 2 * barInset) / width : 1
    }

    static var hairline: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.1))
            .frame(height: 0.5)
            .allowsHitTesting(false)
    }
}

/// Отдельная от Haptics «твёрдая» отдача — щелчок, когда карточку дотянули до сворачивания
enum SiteHaptics {
    private static let rigidGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .rigid)
        g.prepare()
        return g
    }()
    private static var enabled: Bool { UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }

    static func rigid() {
        guard enabled else { return }
        rigidGen.impactOccurred(intensity: 0.75)
        rigidGen.prepare()
    }
}

// MARK: - Вид файла: значок, цвет, подпись

enum FileLook {
    static func ext(_ url: URL) -> String { url.pathExtension.lowercased() }

    static func icon(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt", "pages", "md": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods", "numbers": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled.fill"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "photo.fill"
        case "mp4", "mov", "m4v": return "play.rectangle.fill"
        case "mp3", "m4a", "wav", "aac": return "waveform"
        case "zip", "rar", "7z": return "archivebox.fill"
        default: return "doc.fill"
        }
    }

    static func color(_ url: URL) -> Color {
        switch ext(url) {
        case "pdf": return Color(red: 0.93, green: 0.27, blue: 0.27)
        case "doc", "docx", "rtf", "odt", "pages": return Color(red: 0.20, green: 0.45, blue: 0.95)
        case "txt", "md": return Color(red: 0.45, green: 0.50, blue: 0.60)
        case "xls", "xlsx", "csv", "ods", "numbers": return Color(red: 0.13, green: 0.65, blue: 0.38)
        case "ppt", "pptx", "key", "odp": return Color(red: 0.97, green: 0.52, blue: 0.16)
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return Color(red: 0.62, green: 0.38, blue: 0.95)
        case "mp4", "mov", "m4v", "mp3", "m4a", "wav", "aac": return Color(red: 0.92, green: 0.30, blue: 0.62)
        default: return Color(red: 0.40, green: 0.48, blue: 0.62)
        }
    }

    static func kind(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "PDF"
        case "doc", "docx", "rtf", "odt", "pages": return "Документ"
        case "txt", "md": return "Текст"
        case "xls", "xlsx", "csv", "ods", "numbers": return "Таблица"
        case "ppt", "pptx", "key", "odp": return "Презентация"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "Фото"
        case "mp4", "mov", "m4v": return "Видео"
        case "mp3", "m4a", "wav", "aac": return "Аудио"
        case "": return "Файл"
        default: return ext(url).uppercased()
        }
    }

    /// «PDF · 2,4 МБ»
    static func meta(_ url: URL) -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        guard size > 0 else { return kind(url) }
        return kind(url) + " · " + ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    /// Файл в виде «ресурса»: так у него та же шапка, значок и цвет, что у сайтов
    static func resource(_ url: URL) -> Resource {
        Resource(title: url.deletingPathExtension().lastPathComponent,
                 subtitle: meta(url),
                 url: url.absoluteString,
                 icon: icon(url),
                 category: "Файлы")
    }

    static func canPrint(_ url: URL) -> Bool { UIPrintInteractionController.canPrint(url) }

    static func printFile(_ url: URL) {
        let c = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = ["jpg", "jpeg", "png", "heic", "webp", "tiff"].contains(ext(url)) ? .photo : .general
        info.jobName = url.lastPathComponent
        c.printInfo = info
        c.printingItem = url
        _ = c.present(animated: true, completionHandler: nil)
    }

    /// Положить сам файл в буфер обмена — вставляется в Telegram, почту, Заметки
    static func copy(_ url: URL) {
        guard let p = NSItemProvider(contentsOf: url) else { return }
        UIPasteboard.general.itemProviders = [p]
        Haptics.success()
    }

    /// Снимок без содержимого (QuickLook иногда рисуется в другом процессе и снимается пустым)
    static func isBlank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage else { return true }
        let w = 24, h = 24
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return false }
        var lo = [255, 255, 255], hi = [0, 0, 0]
        for i in 0..<(w * h) {
            for c in 0..<3 {
                let v = Int(px[i * 4 + c])
                lo[c] = min(lo[c], v)
                hi[c] = max(hi[c], v)
            }
        }
        return (0..<3).allSatisfy { hi[$0] - lo[$0] < 10 }
    }

    /// Снимок вида средствами UIKit — в уменьшенном масштабе, чтобы стопка не съедала память
    static func render(_ v: UIView) -> UIImage? {
        guard v.window != nil, v.bounds.width > 1, v.bounds.height > 1 else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = min(2, v.window?.screen.scale ?? 2)
        let img = UIGraphicsImageRenderer(bounds: v.bounds, format: format).image { _ in
            _ = v.drawHierarchy(in: v.bounds, afterScreenUpdates: false)
        }
        return isBlank(img) ? nil : img
    }
}

// MARK: - Просмотр файла, который переживает сворачивание

/// QuickLook живёт в карточке, а не на экране: свернул — и вернулся на ту же страницу
final class FilePreviewHolder: NSObject, QLPreviewControllerDataSource {
    let url: URL

    lazy var controller: QLPreviewController = {
        let c = QLPreviewController()
        c.dataSource = self
        return c
    }()

    init(url: URL) {
        self.url = url
        super.init()
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        url as NSURL
    }

    /// Переносим просмотр в новую карточку (старая может ещё доигрывать исчезновение)
    func attach(to box: UIViewController) {
        let c = controller
        if c.parent === box { return }
        if c.parent != nil {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        box.addChild(c)
        c.view.frame = box.view.bounds
        c.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.view.addSubview(c.view)
        c.didMove(toParent: box)
    }

    /// Снимок той страницы, на которой остановился
    func snapshot() -> UIImage? {
        guard controller.isViewLoaded, let v = controller.view else { return nil }
        return FileLook.render(v)
    }

    /// Первая страница — для карточки в стопке, пока своего снимка нет
    func makeThumbnail(_ done: @escaping (UIImage) -> Void) {
        let req = QLThumbnailGenerator.Request(fileAt: url, size: CGSize(width: 360, height: 520),
                                               scale: 2, representationTypes: .thumbnail)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
            guard let img = rep?.uiImage else { return }
            DispatchQueue.main.async { done(img) }
        }
    }
}

private struct FilePreviewBox: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .secondarySystemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ box: UIViewController, coordinator: ()) {
        // просмотр уже мог переехать в новую карточку — тогда здесь его нет и трогать нечего
        for c in box.children {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
    }
}

// MARK: - Вкладка: сайт или файл

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    /// Есть — это файл, нет — сайт
    let file: FilePreviewHolder?
    private var web: WebModel?
    /// Как выглядела вкладка, когда её свернули
    @Published var snapshot: UIImage?
    /// Первая страница файла
    @Published var thumb: UIImage?

    var isFile: Bool { file != nil }

    /// Живая страница сайта (у файлов не создаётся — им браузер не нужен)
    var model: WebModel {
        if let web { return web }
        let m = WebModel()
        web = m
        return m
    }

    init(resource: Resource) {
        self.resource = resource
        self.file = nil
    }

    init(file url: URL) {
        self.file = FilePreviewHolder(url: url)
        self.resource = FileLook.resource(url)
    }

    func matches(file url: URL) -> Bool {
        guard let f = file?.url else { return false }
        return f.standardizedFileURL.path == url.standardizedFileURL.path
    }
}

/// Где сейчас развёрнутая карточка. Числа живут вне SwiftUI: каждый кадр жеста и анимации
/// двигает слои Core Animation напрямую (до 120 кадров в секунду), SwiftUI при этом не пересчитывается вовсе
final class MiniMotion: ObservableObject {
    static let shared = MiniMotion()

    struct State: Equatable {
        /// 0 — карточка развёрнута, 1 — сжалась в плашку над вкладками
        var collapse: CGFloat = 0
        /// Палец тянет шапку вверх (резинка), точки
        var drag: CGFloat = 0
        /// 0 — на месте, 1 — уехала за нижний край экрана
        var slide: CGFloat = 0
    }

    private(set) var state = State()
    /// Капсула в шапке как у плашки (только «⌃») — меняется редко, это единственное, что видит SwiftUI
    @Published var pillCollapsed = false

    /// Насколько карточка ушла с экрана (для затемнения под ней)
    var hidden: CGFloat { min(1, max(state.collapse, state.slide)) }

    /// Развёрнутая сейчас карточка
    weak var live: CardMotorView? {
        didSet { live?.apply(state) }
    }

    private var link: CADisplayLink?
    private var from = State()
    private var target = State()
    private var v0 = State()
    private var omega: Double = 16
    /// Затухание: 1 — без отскока, меньше — лёгкое покачивание, как у капли
    private var zeta: Double = 1
    private var t0: CFTimeInterval = 0
    private var done: (() -> Void)?

    /// Сразу, без анимации (жест пальцем)
    func set(_ s: State) {
        stop()
        state = s
        live?.apply(s)
    }

    func reset() { set(State()) }

    /// Карточка ушла из иерархии — её больше не двигаем
    func detach() {
        stop()
        live = nil
        state = State()
    }

    /// Пружина без отскока. velocity — скорость пальца в долях пути в секунду
    func animate(to t: State, response: Double = 0.38, damping: Double = 1, velocity: State = State(),
                 completion: (() -> Void)? = nil) {
        stop()
        zeta = min(max(damping, 0.3), 1)
        from = state
        target = t
        func clamp(_ x: CGFloat) -> CGFloat { min(max(x, -8), 8) }
        v0 = State(collapse: clamp(velocity.collapse), drag: velocity.drag, slide: clamp(velocity.slide))
        omega = 2 * .pi / max(response, 0.05)
        t0 = CACurrentMediaTime()
        done = completion
        let l = CADisplayLink(target: LinkProxy(self), selector: #selector(LinkProxy.tick(_:)))
        l.preferredFrameRateRange = CAFrameRateRange(minimum: 80, maximum: 120, preferred: 120)
        l.add(to: .main, forMode: .common)
        link = l
    }

    private func stop() {
        link?.invalidate()
        link = nil
        done = nil
    }

    /// Критически затухающая пружина: x(t) = T + (A + B·t)·e^(−ωt)
    private func value(_ x0: CGFloat, _ x1: CGFloat, _ v: CGFloat, _ t: Double) -> CGFloat {
        let a = Double(x0 - x1)
        if zeta >= 0.999 {
            let b = Double(v) + omega * a
            return x1 + CGFloat((a + b * t) * exp(-omega * t))
        }
        // недозатухающая: x = T + e^(−ζωt)·(A·cos ωd t + B·sin ωd t)
        let wd = omega * sqrt(1 - zeta * zeta)
        let b = (Double(v) + zeta * omega * a) / wd
        return x1 + CGFloat(exp(-zeta * omega * t) * (a * cos(wd * t) + b * sin(wd * t)))
    }

    fileprivate func tick(_ l: CADisplayLink) {
        let t = max(0, l.targetTimestamp - t0)
        var s = State(collapse: value(from.collapse, target.collapse, v0.collapse, t),
                      drag: value(from.drag, target.drag, v0.drag, t),
                      slide: value(from.slide, target.slide, v0.slide, t))
        let settled = t * omega * zeta > 9 ||
            (abs(s.collapse - target.collapse) < 0.0008 && abs(s.slide - target.slide) < 0.0008 && abs(s.drag - target.drag) < 0.3 && t > 0.05)
        if settled { s = target }
        state = s
        live?.apply(s)
        if settled {
            let d = done
            stop()
            d?()
        }
    }

    private final class LinkProxy: NSObject {
        weak var owner: MiniMotion?
        init(_ o: MiniMotion) { owner = o }
        @objc func tick(_ l: CADisplayLink) {
            guard let owner else { l.invalidate(); return }
            owner.tick(l)
        }
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()

    /// Откуда разворачивается карточка
    enum Entry { case bottom, bar, stack }

    /// Открытые сайты и файлы, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутая сейчас вкладка (nil — все свёрнуты)
    @Published private(set) var activeID: UUID?
    /// Прошлая развёрнутая карточка: лежит под новой, пока та выезжает снизу
    @Published private(set) var underID: UUID?
    @Published var showSwitcher = false
    /// Стопка уезжает обратно в плашку — приложение под ней уже возвращается на место
    @Published var switcherLeaving = false
    /// Стопка доехала до плашки и растворяется, а плашка под ней проявляется
    @Published var switcherFading = false
    /// Где сейчас плашка свёрнутых (в координатах экрана) — окно-слой забирает нажатия только там
    var barRect: CGRect = .zero
    /// Окно только что перетекло в капсулу — капсула встаёт на его место без своей анимации появления
    var capsuleArrived = false
    /// Значок островка, в который сворачивается (или из которого вырастает) окно: номер и сколько всего
    var morphSlot: (index: Int, count: Int) = (0, 1)
    /// В приложении открыт лист или окно — капсулу над ним не показываем
    @Published var sheetCovering = false
    /// Старый режим «настоящим Safari» (сейчас все сайты, и почта тоже, открываются карточкой)
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26): полоса с Sakai и почтой встала в один ряд
    /// с кружком вкладок — плашка свёрнутых опускается следом, без пустого места
    @Published var barInline = false
    /// Файлы закрыты Face ID (включено «Файлы по Face ID», и приложение уходило в фон)
    @Published var filesLocked = false
    /// Плашку тянут пальцем вверх: карточка уже развёрнута под пальцем, а сама плашка
    /// остаётся в иерархии (невидимой), чтобы жест не оборвался
    @Published private(set) var barDragging = false
    /// Идёт анимация открытия или сворачивания — повторные нажатия её не ломают
    private(set) var busy = false
    /// Номер перехода: завершение старой анимации не трогает то, что открыли поверх
    private var gen = 0

    /// Сайтов больше не держим: каждый — живая страница в памяти. Файлы лёгкие, их можно больше
    private let siteLimit = 4
    private let totalLimit = 8
    private let motion = MiniMotion.shared

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var under: SiteTab? { tabs.first { $0.id == underID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }

    private init() {
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            if UserDefaults.standard.bool(forKey: "lockFiles"), self.tabs.contains(where: { $0.isFile }) {
                self.filesLocked = true
            }
        }
    }

    // MARK: открыть

    func open(_ r: Resource) {
        if let t = tabs.first(where: { !$0.isFile && $0.resource.url == r.url }) {
            present(t, isNew: false)
        } else {
            present(SiteTab(resource: r), isNew: true)
        }
    }

    /// Файл карточкой поверх приложения — как сайт
    func openFile(_ url: URL) {
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            present(t, isNew: false)
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        present(t, isNew: true)
    }

    /// Файл сразу в свёрнутые (из окна просмотра, открытого поверх другого окна)
    func addMinimized(file url: URL) {
        Haptics.tap()
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            guard t.id != activeID else { return }
            withAnimation(MiniAnim.quick) { tabs = reordered(tabs, putting: t) }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        var list = tabs
        list.append(t)
        list = trimmed(reordered(list, putting: t), keep: [t.id])
        withAnimation(MiniAnim.quick) { tabs = list }
    }

    /// Карточка выезжает снизу. Если уже развёрнута другая — новая накрывает её, а та уходит в свёрнутые
    private func present(_ t: SiteTab, isNew: Bool) {
        Haptics.tap()
        if t.id == activeID {
            if motion.hidden > 0 && !busy { motion.animate(to: .init(), response: 0.34) }
            return
        }
        let g = bump()
        busy = true
        let previous = active
        if let previous { takeSnapshot(previous) }

        var list = tabs
        list.removeAll { $0.id == t.id }
        list.append(t)
        var keep: Set<UUID> = [t.id]
        if let p = previous?.id { keep.insert(p) }
        list = trimmed(list, keep: keep)

        // прошлая карточка остаётся на месте, новая стартует за нижним краем
        motion.detach()
        motion.set(.init(slide: 1))
        noAnimation { motion.pillCollapsed = false }
        // плашка свёрнутых тает, пока карточка выезжает
        withAnimation(.easeOut(duration: 0.18)) {
            tabs = list
            underID = previous?.id
            activeID = t.id
            showSwitcher = false
            switcherLeaving = false
        }
        DispatchQueue.main.async {
            self.motion.animate(to: .init(), response: 0.42) {
                guard g == self.gen else { return }
                self.busy = false
                if self.underID != nil { self.noAnimation { self.underID = nil } }
            }
        }
    }

    // MARK: свернуть / развернуть

    /// Развернуть свёрнутую: из плашки карточка «вырастает» из своей шапки, из стопки — уже стоит на месте
    func restore(_ t: SiteTab, from entry: Entry) {
        if entry == .bottom {
            present(t, isNew: false)
            return
        }
        guard tabs.contains(where: { $0.id == t.id }) else { return }
        if entry == .bar {
            Haptics.tap()
            let list = minimized
            morphSlot = (list.firstIndex { $0.id == t.id } ?? max(list.count - 1, 0), list.count)
        }
        let g = bump()
        busy = true
        motion.set(.init(collapse: entry == .bar ? 1 : 0))
        noAnimation {
            motion.pillCollapsed = entry == .bar
            tabs = reordered(tabs, putting: t, onTop: true)
            underID = nil
            if entry != .bar { activeID = t.id }
        }
        // капсула мягко тает, пока из неё вырастает окно
        if entry == .bar { withAnimation(.easeOut(duration: 0.16)) { activeID = t.id } }
        if entry == .bar {
            DispatchQueue.main.async {
                self.motion.pillCollapsed = false
                self.motion.animate(to: .init(), response: 0.4) {
                    if g == self.gen { self.busy = false }
                }
            }
        } else {
            // живая страница уже под стопкой — стопку убираем, когда карточка под ней нарисовалась
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.noAnimation {
                    self.showSwitcher = false
                    self.switcherLeaving = false
                }
                if g == self.gen { self.busy = false }
            }
        }
    }

    /// Карточка съезжает вниз и становится плашкой над вкладками — с того места,
    /// где её отпустил палец, и с его скоростью
    @discardableResult
    func minimize(velocity: CGFloat = 0) -> Bool {
        guard let t = active, !busy else { return false }
        Haptics.tap()
        takeSnapshot(t)
        let g = bump()
        busy = true
        motion.pillCollapsed = true
        morphSlot = (tabs.firstIndex { $0.id == t.id } ?? max(tabs.count - 1, 0), tabs.count)
        // как в Windows: окно быстро и ровно влетает в свой значок, без покачиваний
        motion.animate(to: .init(collapse: 1), response: 0.36, velocity: .init(collapse: velocity)) {
            guard g == self.gen else { return }
            self.capsuleArrived = true
            // плашка встаёт ровно туда, где закончилась шапка карточки — подмены не видно
            self.noAnimation {
                self.activeID = nil
                self.underID = nil
                self.motion.pillCollapsed = false
            }
            self.motion.detach()
            self.busy = false
        }
        return true
    }

    // MARK: плашку тянут вверх — карточка растёт под пальцем

    /// Палец пошёл вверх по плашке: верхняя свёрнутая становится карточкой, сжатой ровно в плашку
    func beginBarDrag(_ tab: SiteTab? = nil) -> Bool {
        guard !busy, activeID == nil, let t = tab ?? minimized.last else { return false }
        Haptics.tap()
        let list = minimized
        morphSlot = (list.firstIndex { $0.id == t.id } ?? max(list.count - 1, 0), list.count)
        bump()
        busy = true
        motion.set(.init(collapse: 1))
        noAnimation {
            motion.pillCollapsed = true
            tabs = reordered(tabs, putting: t, onTop: true)
            underID = nil
            activeID = t.id
            barDragging = true
        }
        return true
    }

    /// Отпустили плашку: развернуть до конца или вернуть обратно в плашку
    func endBarDrag(open: Bool, velocity: CGFloat) {
        guard barDragging else { return }
        let g = bump()
        if open {
            motion.pillCollapsed = false
            motion.animate(to: .init(), response: 0.4, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.noAnimation { self.barDragging = false }
                self.busy = false
            }
        } else {
            motion.animate(to: .init(collapse: 1), response: 0.34, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.capsuleArrived = true
                self.noAnimation {
                    self.activeID = nil
                    self.barDragging = false
                    self.motion.pillCollapsed = false
                }
                self.motion.detach()
                self.busy = false
            }
        }
    }

    /// Нажали на плашку: одна вкладка — сразу разворачиваем, несколько — стопка карточек как в Telegram
    func tapBar() {
        guard !busy else { return }
        let list = minimized
        if list.count > 1 {
            Haptics.tap()
            switcherLeaving = false
            withAnimation(MiniAnim.stack) { showSwitcher = true }
        } else if let t = list.last {
            restore(t, from: .bar)
        }
    }

    /// Стопка доиграла уход в плашку — плашка мягко проявляется на своём месте
    func hideSwitcher() {
        noAnimation {
            showSwitcher = false
            switcherLeaving = false
            switcherFading = false
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(MiniAnim.quick) { barInline = inline }
    }

    // MARK: закрыть

    func close(_ t: SiteTab) {
        SiteHaptics.rigid()
        guard t.id == activeID else {
            withAnimation(MiniAnim.stack) { remove(t) }
            return
        }
        guard !busy else { return }
        let g = bump()
        busy = true
        // развёрнутая уезжает вниз за край экрана, как лист
        var end = motion.state
        end.slide = 1
        motion.animate(to: end, response: 0.34) {
            guard g == self.gen else { return }
            self.motion.detach()
            withAnimation(.easeOut(duration: 0.2)) {
                self.remove(t)
                self.activeID = nil
                self.underID = nil
            }
            self.busy = false
        }
    }

    func closeAll() {
        SiteHaptics.rigid()
        bump()
        busy = false
        withAnimation(MiniAnim.stack) {
            tabs = []
            activeID = nil
            underID = nil
            showSwitcher = false
            switcherLeaving = false
        }
        motion.detach()
        noAnimation { motion.pillCollapsed = false }
        filesLocked = false
    }

    private func remove(_ t: SiteTab) {
        tabs.removeAll { $0.id == t.id }
        if tabs.isEmpty {
            showSwitcher = false
            switcherLeaving = false
        }
        if !tabs.contains(where: { $0.isFile }) { filesLocked = false }
    }

    // MARK: Face ID для файлов

    func unlockFiles() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            filesLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return }
                Haptics.success()
                withAnimation(.easeInOut(duration: 0.25)) { self.filesLocked = false }
            }
        }
    }

    /// Окно поверх приложения (лист, полноэкранное окно) — тогда карточку не будет видно под ним
    /// Слой с карточками — в своём окне над всем приложением, поэтому показать можно всегда
    static var canShowOnTop: Bool { true }

    static var canShowOnTopLegacy: Bool {
        let windows = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
        guard let main = windows.first(where: { $0.windowLevel == .normal && $0.rootViewController != nil }) else { return true }
        return main.rootViewController?.presentedViewController == nil
    }

    // MARK: служебное

    @discardableResult
    private func bump() -> Int {
        gen += 1
        return gen
    }

    private func noAnimation(_ body: () -> Void) {
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t, body)
    }

    /// Вкладку — в самый верх свёрнутых. Развёрнутая (если есть) остаётся последней:
    /// иначе при сворачивании плашка показала бы не ту вкладку
    private func reordered(_ input: [SiteTab], putting t: SiteTab, onTop: Bool = false) -> [SiteTab] {
        var list = input
        list.removeAll { $0.id == t.id }
        if !onTop, let a = activeID, a != t.id, let i = list.firstIndex(where: { $0.id == a }) {
            list.insert(t, at: i)
        } else {
            list.append(t)
        }
        return list
    }

    /// Самые давние вкладки закрываем, чтобы не тратить память
    private func trimmed(_ input: [SiteTab], keep: Set<UUID>) -> [SiteTab] {
        var list = input
        var keep = keep
        if let a = activeID { keep.insert(a) }
        if let u = underID { keep.insert(u) }
        while list.filter({ !$0.isFile }).count > siteLimit,
              let old = list.first(where: { !$0.isFile && !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        while list.count > totalLimit, let old = list.first(where: { !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        return list
    }

    /// Снимок для стопки — сразу, пока карточка ещё на экране
    private func takeSnapshot(_ t: SiteTab) {
        if let holder = t.file {
            if let img = holder.snapshot() { t.snapshot = img }
            return
        }
        let wv = t.model.webView
        guard wv.window != nil, wv.bounds.width > 1, wv.bounds.height > 1 else { return }
        let config = WKSnapshotConfiguration()
        config.afterScreenUpdates = false
        config.snapshotWidth = NSNumber(value: Double(min(wv.bounds.width, 340)))
        wv.takeSnapshot(with: config) { [weak t, weak wv] image, _ in
            if let image {
                t?.snapshot = image
            } else if let wv, let img = FileLook.render(wv) {
                // запасной путь: WebKit иногда отдаёт пустой снимок, пока страница грузится
                t?.snapshot = img
            }
        }
    }
}

// MARK: - Приложение под карточкой отъезжает назад, как в Telegram

struct SiteBackdrop: ViewModifier {
    // приложение под карточкой не перерисовывается во время жестов:
    // затемнение — слой внутри UIKit-движка карточки
    func body(content: Content) -> some View { content }
}

// MARK: - Шапка мини-приложения

/// Крестик слева, значок и название по центру, справа — что передали (обычно капсула «⌄ ⋯»)
struct MiniHeader<Trailing: View>: View {
    let resource: Resource
    var onClose: (() -> Void)? = nil
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        ZStack {
            HStack(spacing: 8) {
                SiteIcon(resource: resource, size: 22)
                Text(resource.title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            .padding(.horizontal, 96)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)

            HStack(spacing: 0) {
                Button {
                    onClose?()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 46, height: 46)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")

                Spacer(minLength: 0)
                trailing()
            }
            .padding(.leading, 6)
            .padding(.trailing, 10)
        }
        .frame(height: MiniChrome.header)
        .frame(maxWidth: .infinity)
        .background(MiniChrome.headerColor)
    }
}

/// Капсула справа в шапке, как у мини-приложений Telegram: «свернуть» и «ещё».
/// У плашки свёрнутых та же капсула, только стрелка смотрит вверх, а «ещё» спрятано
struct MiniPill<Items: View>: View {
    /// 0 — карточка развёрнута (⌄ и ⋯), 1 — сжалась в плашку (только ⌃)
    var collapse: CGFloat = 0
    var chevronLabel = "Свернуть"
    var onChevron: (() -> Void)? = nil
    @ViewBuilder var menu: () -> Items

    var body: some View {
        HStack(spacing: 0) {
            if let onChevron {
                Button(action: onChevron) {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 15, weight: .bold))
                        .rotationEffect(.degrees(Double(180 * collapse)))
                        .foregroundStyle(.primary)
                        .frame(width: 38, height: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(chevronLabel)
            }
            Menu {
                menu()
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 38, height: 32)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("Ещё")
            .frame(width: 38 * max(0, 1 - collapse), alignment: .leading)
            .opacity(Double(max(0, 1 - collapse * 1.6)))
            .clipped()
            .allowsHitTesting(collapse < 0.5)
        }
        .frame(height: 32)
        .background(Color.primary.opacity(0.08), in: Capsule(style: .continuous))
    }
}

/// Меню «⋯» карточки: у сайта — свои пункты, у файла — свои
private struct CardMenu: View {
    let tab: SiteTab

    var body: some View {
        if let f = tab.file?.url {
            FileMenuItems(url: f)
        } else {
            WebMenuItems(model: tab.model, resource: tab.resource)
        }
    }
}

struct FileMenuItems: View {
    let url: URL
    /// В отдельном окне просмотра файл не прячется за Face ID — там это меню всегда полное
    var respectsLock = true
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        Section(FileLook.meta(url)) {
            if respectsLock && tabs.filesLocked {
                Button { tabs.unlockFiles() } label: { Label("Разблокировать", systemImage: "faceid") }
            } else {
                ShareLink(item: url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                Button { FileLook.copy(url) } label: { Label("Скопировать файл", systemImage: "doc.on.doc") }
                if FileLook.canPrint(url) {
                    Button { FileLook.printFile(url) } label: { Label("Напечатать", systemImage: "printer") }
                }
            }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутая карточка, плашка свёрнутых, стопка

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под плашкой системная полоса с Sakai и почтой: когда панель сжимается, плашка опускается следом
    var followsBar = false

    var body: some View {
        GeometryReader { geo in
            // островок стоит над полной полосой; когда панель сжимается при прокрутке, он прячется, а не прыгает
            let lift = 58 + bottomExtra
            let panel = MiniChrome.panelScale(geo.size.width)
            let barTop = geo.size.height - lift - MiniChrome.header * panel
            let cards = [tabs.under, tabs.active].compactMap { $0 }

            ZStack(alignment: .top) {
                if (tabs.barDragging || (tabs.active == nil && !tabs.minimized.isEmpty)) && !tabs.showSwitcher
                    && (!tabs.sheetCovering || tabs.barDragging) {
                    MinimizedBar(width: geo.size.width, travel: max(barTop - MiniChrome.topGap, 1),
                                 tucked: followsBar && tabs.barInline && !tabs.barDragging)
                        // не 0: полностью прозрачный вид SwiftUI может выкинуть из жестов;
                        // пока стопка складывается в плашку, плашка ждёт под ней невидимой
                        .opacity(tabs.barDragging ? 0.001 : 1)
                        .animation(.easeOut(duration: 0.16), value: tabs.barDragging)
                        .offset(y: barTop)
                        .transition(.opacity)
                        .zIndex(1)
                }

                // одна и та же карточка остаётся тем же видом, когда уходит «под» новую:
                // живая страница не пересоздаётся и не моргает
                ForEach(cards) { t in
                    CardMotor(tab: t, live: t.id == tabs.activeID, barTop: barTop)
                        .ignoresSafeArea()
                        .zIndex(t.id == tabs.activeID ? 3 : 2)
                        .transition(.identity)
                }

                if tabs.showSwitcher {
                    StackSwitcherHost(barTop: barTop)
                        .ignoresSafeArea()
                        .zIndex(4)
                        .transition(.identity)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
        }
        // клавиатура не двигает карточку и плашку: страница сама прокручивает поле ввода над клавиатурой,
        // а пересчёт всей карточки при каждом показе клавиатуры давал рывок
        .ignoresSafeArea(.keyboard)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }
}

// MARK: - Развёрнутая карточка (UIKit-движок — в конце файла)

/// Содержимое карточки. Входные данные не меняются, пока карточку тянут или сворачивают,
/// поэтому SwiftUI не пересчитывает страницу на каждом кадре
private struct CardBody: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        if tab.isFile {
            FileBody(tab: tab)
        } else {
            WebScreen(resource: tab.resource, model: tab.model, embeddedInset: bottomInset)
        }
    }
}

// MARK: - Карточка файла

private struct FileBody: View {
    let tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        ZStack {
            if let holder = tab.file {
                FilePreviewBox(holder: holder)
            } else {
                Color(.secondarySystemBackground)
            }
            if tabs.filesLocked {
                FileLockedView()
                    .transition(.opacity)
            }
        }
        .overlay(alignment: .top) { MiniChrome.hairline }
        .animation(.easeInOut(duration: 0.25), value: tabs.filesLocked)
    }
}

private struct FileLockedView: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.regularMaterial)
            VStack(spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.secondary)
                Text("Файл защищён")
                    .font(.headline)
                Button { SiteTabs.shared.unlockFiles() } label: {
                    Label("Открыть по Face ID", systemImage: "faceid")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear { SiteTabs.shared.unlockFiles() }
    }
}

/// Содержимое капсулы: значок, название, «+N», стрелка. Одно и то же у капсулы и у окна,
/// которое в неё перетекает, — поэтому подмены не видно
struct CapsuleFace: View {
    let resource: Resource
    let extra: Int
    let width: CGFloat

    var body: some View {
        HStack(spacing: 10) {
            SiteIcon(resource: resource, size: 28)
            Text(resource.title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.primary)
                .lineLimit(1)
                .truncationMode(.tail)
            Spacer(minLength: 2)
            if extra > 0 {
                Text("+\(extra)")
                    .font(.system(size: 13, weight: .semibold).monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Image(systemName: "chevron.up")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(.secondary)
        }
        .padding(.leading, 8)
        .padding(.trailing, 14)
        .frame(width: MiniChrome.capsuleWidth(width), height: MiniChrome.capsuleHeight)
    }
}

/// Настоящее «жидкое стекло» iOS 26 (на старых iOS — матовое размытие)
enum LiquidGlass {
    static var available: Bool {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) { return true }
        #endif
        return false
    }

    static func effect() -> UIVisualEffect {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) { return UIGlassEffect() }
        #endif
        return UIBlurEffect(style: MiniChrome.capsuleBlur)
    }

    /// Контейнер, в котором соседние капли стекла сливаются, как вода
    static func container(spacing: CGFloat) -> UIVisualEffect? {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            let c = UIGlassContainerEffect()
            c.spacing = spacing
            return c
        }
        #endif
        return nil
    }

    /// Скругление стекла (у UIGlassEffect обычный cornerRadius не работает)
    static func round(_ v: UIVisualEffectView, _ r: CGFloat) {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            v.cornerConfiguration = .uniformCorners(radius: .fixed(r))
            return
        }
        #endif
        v.clipsToBounds = true
        v.layer.cornerRadius = r
        v.layer.cornerCurve = .continuous
    }
}

/// Стекло капсулы — тот же материал, в который превращается перетекающее окно
struct CapsuleGlass: UIViewRepresentable {
    func makeUIView(context: Context) -> UIVisualEffectView {
        let v = UIVisualEffectView(effect: LiquidGlass.effect())
        LiquidGlass.round(v, MiniChrome.capsuleHeight / 2)
        if !LiquidGlass.available {
            v.layer.borderWidth = 0.6
            v.layer.borderColor = UIColor.white.withAlphaComponent(0.14).cgColor
        }
        v.isUserInteractionEnabled = false
        return v
    }
    func updateUIView(_ v: UIVisualEffectView, context: Context) {}
}

extension MiniChrome {
    static let capsuleBlur: UIBlurEffect.Style = .systemMaterial
}

// MARK: - Свёрнутые: островок как панель задач Windows

/// Значок окна в островке: плитка и чёрточка под ней (у последнего — длинная и цветная).
/// Тот же вид рисуется внутри окна, которое влетает в значок, — поэтому подмены не видно
struct IslandIcon: View {
    let resource: Resource
    let latest: Bool

    var body: some View {
        VStack(spacing: 3) {
            SiteIcon(resource: resource, size: MiniChrome.islandIcon)
            Capsule(style: .continuous)
                .fill(latest ? Color.brand : Color.primary.opacity(0.35))
                .frame(width: latest ? 14 : 5, height: 3)
        }
        .padding(.top, 4)
        .frame(width: MiniChrome.islandSlot, height: MiniChrome.islandSlot)
    }
}

/// Стекло островка
struct IslandGlass: UIViewRepresentable {
    func makeUIView(context: Context) -> UIVisualEffectView {
        let v = UIVisualEffectView(effect: LiquidGlass.effect())
        LiquidGlass.round(v, MiniChrome.islandRadius)
        if !LiquidGlass.available {
            v.layer.borderWidth = 0.6
            v.layer.borderColor = UIColor.white.withAlphaComponent(0.12).cgColor
        }
        v.isUserInteractionEnabled = false
        return v
    }
    func updateUIView(_ v: UIVisualEffectView, context: Context) {}
}

/// Островок свёрнутых окон. Нажал на значок — окно вырастает из него, долгое нажатие — меню,
/// потянул островок вверх — стопка окон как в Telegram (одно окно растёт прямо под пальцем)
private struct MinimizedBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let width: CGFloat
    /// Путь от островка до развёрнутой карточки, точки
    let travel: CGFloat
    /// Панель вкладок сжата прокруткой — островок спрятан
    var tucked = false
    @State private var dy: CGFloat = 0
    @State private var lifting = false
    @State private var shown = false
    /// Окно только что влетело в значок — значок коротко «принимает» его
    @State private var landed: UUID?

    var body: some View {
        let list = Array((tabs.barDragging ? tabs.tabs : tabs.minimized).prefix(MiniChrome.islandMax))
        if !list.isEmpty {
            HStack(spacing: 0) {
                ForEach(list) { t in
                    IslandIcon(resource: t.resource, latest: t.id == list.last?.id)
                        .scaleEffect(landed == t.id ? 1.16 : 1)
                        .contentShape(Rectangle())
                        .onTapGesture { tabs.restore(t, from: .bar) }
                        .contextMenu {
                            Button { tabs.restore(t, from: .bar) } label: {
                                Label("Развернуть", systemImage: "arrow.up.left.and.arrow.down.right")
                            }
                            Button(role: .destructive) { tabs.close(t) } label: {
                                Label("Закрыть «\(t.resource.title)»", systemImage: "xmark")
                            }
                            if list.count > 1 {
                                Button(role: .destructive) { tabs.closeAll() } label: {
                                    Label("Закрыть все", systemImage: "xmark.circle")
                                }
                            }
                        }
                        .accessibilityLabel("Свёрнуто: \(t.resource.title)")
                        .accessibilityAddTraits(.isButton)
                        .transition(.scale(scale: 0.6).combined(with: .opacity))
                }
            }
            .padding(.horizontal, MiniChrome.islandPad)
            .frame(height: MiniChrome.islandHeight)
            .background(IslandGlass())
            .animation(.spring(response: 0.3, dampingFraction: 0.9), value: list.map(\.id))
            .background(
                GeometryReader { g in
                    Color.clear
                        .onAppear { tabs.barRect = tucked ? .zero : g.frame(in: .global) }
                        .onChange(of: g.frame(in: .global)) { _, r in tabs.barRect = tucked ? .zero : r }
                        .onChange(of: tucked) { _, t in tabs.barRect = t ? .zero : g.frame(in: .global) }
                }
            )
            .onDisappear { tabs.barRect = .zero }
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { v in
                        let up = -v.translation.height
                        if lifting {
                            MiniMotion.shared.set(.init(collapse: 1 - min(1, max(0, up / travel))))
                        } else if up > 0 {
                            if list.count == 1 && tabs.beginBarDrag(list[0]) {
                                lifting = true
                            } else {
                                dy = -pow(up, 0.7)
                            }
                        }
                    }
                    .onEnded { v in
                        if lifting {
                            lifting = false
                            let vel = -v.velocity.height
                            let open = -v.predictedEndTranslation.height > travel * 0.35 || vel > 500
                            tabs.endBarDrag(open: open && vel > -300, velocity: v.velocity.height / travel)
                            return
                        }
                        withAnimation(.spring(response: 0.3, dampingFraction: 1)) { dy = 0 }
                        if v.translation.height < -24 { tabs.tapBar() }
                    }
            )
            .scaleEffect(shown && !tucked ? 1 : 0.82, anchor: .bottom)
            .opacity(shown && !tucked ? 1 : 0)
            .blur(radius: tucked ? 6 : 0)
            .animation(.spring(response: 0.34, dampingFraction: 0.9), value: tucked)
            .allowsHitTesting(!tucked)
            .offset(y: dy)
            .frame(width: width, height: MiniChrome.header * MiniChrome.panelScale(width))
            .onAppear {
                if tabs.capsuleArrived {
                    // окно уже влетело в свой значок — островок встаёт без своей анимации
                    tabs.capsuleArrived = false
                    var tr = Transaction()
                    tr.disablesAnimations = true
                    withTransaction(tr) { shown = true }
                    // значок «ловит» окно: короткий упругий отклик и лёгкая отдача
                    if let id = list.last?.id {
                        Haptics.tap()
                        withAnimation(.spring(response: 0.18, dampingFraction: 0.55)) { landed = id }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                            withAnimation(.spring(response: 0.38, dampingFraction: 0.5)) { landed = nil }
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { shown = true }
                    }
                }
            }
        }
    }
}

// MARK: - Стопка открытых вкладок как в Telegram

/// Наклон карточки назад вокруг верхнего края с перспективой.
/// Свой эффект вместо rotation3DEffect: глубина задаётся точно, и всё плавно анимируется
private struct TiltEffect: GeometryEffect {
    /// Градусы; больше нуля — низ карточки уходит вглубь
    var angle: CGFloat
    var scale: CGFloat
    /// Расстояние до «глаза», точки — чем меньше, тем сильнее перспектива
    var depth: CGFloat

    var animatableData: AnimatablePair<CGFloat, AnimatablePair<CGFloat, CGFloat>> {
        get { AnimatablePair(angle, AnimatablePair(scale, depth)) }
        set {
            angle = newValue.first
            scale = newValue.second.first
            depth = newValue.second.second
        }
    }

    func effectValue(size: CGSize) -> ProjectionTransform {
        let cx = size.width / 2
        var t = CATransform3DMakeTranslation(-cx, 0, 0)
        t = CATransform3DConcat(t, CATransform3DMakeScale(scale, scale, 1))
        t = CATransform3DConcat(t, CATransform3DMakeRotation(-angle * .pi / 180, 1, 0, 0))
        var p = CATransform3DIdentity
        p.m34 = -1 / max(depth, 1)
        t = CATransform3DConcat(t, p)
        t = CATransform3DConcat(t, CATransform3DMakeTranslation(cx, 0, 0))
        return ProjectionTransform(t)
    }
}

/// Раскладка стопки: старые сверху, свежая — внизу и поверх всех; верх последней — чуть ниже середины экрана.
/// Если карточек много, лишние у верхнего края складываются в тонкую пачку, остальное — прокруткой
private struct StackLayout {
    let count: Int
    let height: CGFloat
    let first: CGFloat
    let last: CGFloat
    let step: CGFloat
    let maxScroll: CGFloat
    let cardHeight: CGFloat
    let scale: CGFloat

    init(count: Int, size: CGSize, safeTop: CGFloat) {
        self.count = count
        height = size.height
        first = safeTop + 12
        last = max(first, size.height * 0.53)
        if count > 1 {
            step = min(max((last - first) / CGFloat(count - 1), size.height * 0.13), size.height * 0.45)
        } else {
            step = 0
        }
        maxScroll = max(0, first - (last - step * CGFloat(max(count - 1, 0))))
        cardHeight = max(size.height - safeTop - MiniChrome.topGap, 200)
        scale = size.width > 28 ? (size.width - 28) / size.width : 1
    }

    /// Верх карточки и насколько глубоко она ушла в пачку у верхнего края
    func top(_ i: Int, scroll: CGFloat) -> (y: CGFloat, depth: CGFloat) {
        let raw: CGFloat
        if count <= 1 {
            raw = first + (last - first) * 0.4 + scroll
        } else {
            raw = last - step * CGFloat(count - 1 - i) + scroll
        }
        guard raw < first else { return (raw, 0) }
        let over = min(first - raw, step * 4)
        return (first - over * 0.06, min(over / max(step, 1), 4))
    }

    /// Чем ниже карточка, тем сильнее она наклонена — как в Telegram
    func angle(at y: CGFloat) -> CGFloat {
        min(max(15 + 34 * y / max(height, 1), 12), 40)
    }
}

/// Карточки лежат друг на друге с наклоном назад, у каждой видна шапка.
/// Нажал — карточка выпрямляется и разворачивается на весь экран; крестик или смахнул вбок — закрыл;
/// потянул вниз или нажал выше карточек — стопка уходит обратно в плашку
private struct StackSwitcher: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let safeTop: CGFloat
    /// Верх плашки свёрнутых в координатах всего экрана — туда стопка и уезжает
    let barTop: CGFloat

    @State private var shown = false
    @State private var leaving = false
    @State private var opening: UUID?
    @State private var scroll: CGFloat = 0
    @State private var scrollStart: CGFloat?
    @State private var axis: Axis?
    @State private var swipeID: UUID?
    @State private var swipeX: CGFloat = 0

    private struct Pose {
        var y: CGFloat
        var angle: CGFloat
        var scale: CGFloat
        var dim: Double
        var pill: CGFloat
        var opacity: Double
        /// Карточка уходит в плашку: страница гаснет, остаётся только шапка
        var folding = false
    }

    var body: some View {
        GeometryReader { geo in
            let size = geo.size
            let list = tabs.tabs
            let lay = StackLayout(count: list.count, size: size, safeTop: safeTop)
            let sc = axis == .vertical ? scroll : min(max(scroll, 0), lay.maxScroll)

            ZStack(alignment: .top) {
                ZStack {
                    Rectangle().fill(.ultraThinMaterial)
                    Color.black.opacity(0.5)
                }
                .environment(\.colorScheme, .dark)
                .opacity(shown && opening == nil && !leaving ? 1 : 0)
                .animation(.easeOut(duration: 0.28), value: shown)
                .allowsHitTesting(false)

                ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                    let p = pose(t, index: i, lay: lay, scroll: sc, size: size)
                    let dx: CGFloat = t.id == swipeID ? swipeX : 0
                    let fade: Double = p.opacity * swipeFade(dx, width: size.width)
                    let delay: Double = Double(list.count - 1 - i) * 0.03
                    StackCardView(tab: t, dim: p.dim, pill: p.pill, folding: p.folding,
                                  extra: i == list.count - 1 ? list.count - 1 : 0)
                        // уходит в плашку — высота плавно схлопывается до шапки,
                        // тёмная плита больше не ползёт вниз поверх вкладок
                        .frame(width: size.width, height: p.folding ? MiniChrome.header : lay.cardHeight, alignment: .top)
                        .modifier(TiltEffect(angle: p.angle, scale: p.scale, depth: size.height * 0.8))
                        .offset(x: dx, y: p.y)
                        .opacity(fade)
                        .animation(MiniAnim.stack.delay(delay), value: shown)
                        .zIndex(Double(i))
                        .allowsHitTesting(false)
                        .accessibilityElement(children: .ignore)
                        .accessibilityLabel(t.resource.title)
                        .accessibilityAddTraits(.isButton)
                        .accessibilityAction { open(t) }
                        .accessibilityAction(named: Text("Закрыть")) { tabs.close(t) }
                }
            }
            .frame(width: size.width, height: size.height, alignment: .top)
            .contentShape(Rectangle())
            .gesture(dragGesture(lay: lay, list: list, size: size))
            .onTapGesture(coordinateSpace: .local) { point in
                tap(at: point, lay: lay, list: list, size: size)
            }
        }
        .ignoresSafeArea()
        .pausesAmbient()
        .onAppear {
            DispatchQueue.main.async { shown = true }
        }
        .accessibilityAction(.escape) { dismiss() }
    }

    private func swipeFade(_ dx: CGFloat, width: CGFloat) -> Double {
        1 - Double(min(abs(dx) / max(width, 1), 0.8))
    }

    private func pose(_ t: SiteTab, index i: Int, lay: StackLayout, scroll: CGFloat, size: CGSize) -> Pose {
        let pos = lay.top(i, scroll: scroll)
        var p = Pose(y: pos.y, angle: lay.angle(at: pos.y),
                     scale: lay.scale * (1 - 0.035 * pos.depth),
                     dim: min(0.12 * Double(pos.depth), 0.4), pill: 0, opacity: 1)
        if let o = opening {
            if o == t.id {
                // выпрямляется точно в развёрнутую карточку — потом её подменяет живая страница
                p = Pose(y: safeTop + MiniChrome.topGap, angle: 0, scale: 1, dim: 0, pill: 1, opacity: 1)
            } else {
                p.y += size.height * 0.5
                p.opacity = 0
            }
        } else if leaving {
            // верхняя карточка сжимается ровно в плашку, остальные прячутся под неё краями колоды
            let depth = CGFloat(lay.count - 1 - i)
            p.y = barTop - min(depth, 2) * 10
            p.angle = 0
            p.scale = MiniChrome.panelScale(size.width) * (1 - 0.06 * min(depth, 2))
            p.dim = 0
            p.pill = 1
            // задние не просвечивают сквозь плашку — прячутся целиком,
            // края колоды потом аккуратно выезжают уже у самой плашки
            p.opacity = depth == 0 ? 1 : 0
            p.folding = true
        } else if !shown {
            p.y = size.height + 40 + CGFloat(i) * 24
            p.angle = lay.angle(at: size.height)
        }
        return p
    }

    // MARK: жесты

    private func cardIndex(at point: CGPoint, lay: StackLayout, count: Int) -> Int? {
        let sc = min(max(scroll, 0), lay.maxScroll)
        var hit: Int?
        for i in 0..<count where lay.top(i, scroll: sc).y <= point.y { hit = i }
        return hit
    }

    private func tap(at point: CGPoint, lay: StackLayout, list: [SiteTab], size: CGSize) {
        guard shown, opening == nil, !leaving else { return }
        guard let i = cardIndex(at: point, lay: lay, count: list.count) else {
            dismiss()
            return
        }
        let t = list[i]
        let top = lay.top(i, scroll: min(max(scroll, 0), lay.maxScroll)).y
        let inset = size.width * (1 - lay.scale) / 2
        // крестик в шапке карточки
        if point.y - top < MiniChrome.header * lay.scale && point.x < inset + 54 {
            close(t)
        } else {
            open(t)
        }
    }

    private func dragGesture(lay: StackLayout, list: [SiteTab], size: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 8)
            .onChanged { v in
                guard opening == nil, !leaving else { return }
                if axis == nil {
                    let horizontal = abs(v.translation.width) > abs(v.translation.height)
                    axis = horizontal ? .horizontal : .vertical
                    scrollStart = min(max(scroll, 0), lay.maxScroll)
                    if horizontal, let i = cardIndex(at: v.startLocation, lay: lay, count: list.count) {
                        swipeID = list[i].id
                    }
                }
                if axis == .horizontal {
                    if swipeID != nil { swipeX = v.translation.width }
                } else {
                    scroll = rubber((scrollStart ?? 0) + v.translation.height, max: lay.maxScroll)
                }
            }
            .onEnded { v in
                let wasAxis = axis
                let start = scrollStart ?? 0
                axis = nil
                scrollStart = nil
                guard opening == nil, !leaving else { return }
                if wasAxis == .horizontal {
                    let w = v.translation.width
                    if let id = swipeID, let t = list.first(where: { $0.id == id }),
                       abs(w) > 110 || abs(v.predictedEndTranslation.width) > 320 {
                        withAnimation(.easeOut(duration: 0.2)) { swipeX = (w < 0 ? -1 : 1) * size.width * 1.2 }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) { close(t) }
                    } else {
                        withAnimation(MiniAnim.back) {
                            swipeX = 0
                            swipeID = nil
                        }
                    }
                } else {
                    // потянул вниз, когда прокручивать некуда, — стопка уходит в плашку
                    if v.translation.height > 130 && start + v.translation.height > lay.maxScroll + 110 {
                        dismiss()
                        return
                    }
                    let target = start + v.predictedEndTranslation.height
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.92)) {
                        scroll = min(max(target, 0), lay.maxScroll)
                    }
                }
            }
    }

    private func rubber(_ v: CGFloat, max m: CGFloat) -> CGFloat {
        if v < 0 { return -pow(-v, 0.7) }
        if v > m { return m + pow(v - m, 0.7) }
        return v
    }

    // MARK: действия

    private func open(_ t: SiteTab) {
        guard opening == nil, !leaving else { return }
        Haptics.tap()
        withAnimation(MiniAnim.unfold, completionCriteria: .logicallyComplete) {
            opening = t.id
        } completion: {
            SiteTabs.shared.restore(t, from: .stack)
        }
    }

    private func close(_ t: SiteTab) {
        // улетевшая карточка исчезает там, куда её смахнули; сбрасываем смахивание уже без анимации
        tabs.close(t)
        var tr = Transaction()
        tr.disablesAnimations = true
        withTransaction(tr) {
            swipeID = nil
            swipeX = 0
        }
    }

    private func dismiss() {
        guard opening == nil, !leaving else { return }
        Haptics.tap()
        withAnimation(.spring(response: 0.34, dampingFraction: 1), completionCriteria: .logicallyComplete) {
            leaving = true
            tabs.switcherLeaving = true
        } completion: {
            SiteTabs.shared.hideSwitcher()
        }
    }
}

/// Карточка в стопке: живая шапку и снимок страницы — так же, как карточка выглядит развёрнутой
private struct StackCardView: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    let dim: Double
    /// 0…1: появляется капсула «⌄ ⋯», пока карточка разворачивается
    let pill: CGFloat
    /// Уходит в плашку: страница быстро гаснет, капсула становится как у плашки (только ⌃)
    var folding = false
    /// Сколько ещё свёрнуто — у верхней карточки, как счётчик на плашке
    var extra = 0
    @AppStorage("web.light") private var forceLight = true

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: MiniChrome.radius, style: .continuous)
        VStack(spacing: 0) {
            MiniHeader(resource: tab.resource) {
                HStack(spacing: 8) {
                    if folding && extra > 0 {
                        Text("+\(extra)")
                            .font(.system(size: 13, weight: .bold).monospacedDigit())
                            .foregroundStyle(.primary)
                            .padding(.horizontal, 8)
                            .frame(height: 24)
                            .background(Color.primary.opacity(0.1), in: Capsule(style: .continuous))
                            .transition(.opacity)
                    }
                    MiniPill(collapse: folding ? 1 : 0, onChevron: {}) { EmptyView() }
                        .opacity(Double(pill))
                }
            }
            preview
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .overlay(alignment: .top) { MiniChrome.hairline }
                .opacity(folding ? 0 : 1)
        }
        .background(MiniChrome.headerColor)
        .overlay(Color.black.opacity(dim))
        .clipShape(shape)
        // та же обводка и тень, что у плашки, — подмена в конце не видна
        .overlay(shape.strokeBorder(LinearGradient(colors: [Color.white.opacity(0.3), Color.primary.opacity(0.08)],
                                                   startPoint: .top, endPoint: .bottom), lineWidth: 0.7)
                    .opacity(folding ? 1 : 0))
        .shadow(color: .black.opacity(folding ? 0.3 : 0), radius: folding ? 14 : 0, y: folding ? 4 : 0)
    }

    private var locked: Bool { tab.isFile && tabs.filesLocked }

    private var pageColor: Color {
        if tab.isFile { return Color(.secondarySystemBackground) }
        return forceLight ? Color.white : Color(.systemBackground)
    }

    private var preview: some View {
        ZStack(alignment: .top) {
            pageColor
            if locked {
                VStack(spacing: 10) {
                    Image(systemName: "lock.fill")
                        .font(.system(size: 30, weight: .semibold))
                    Text("Защищено")
                        .font(.subheadline.weight(.semibold))
                }
                .foregroundStyle(.secondary)
                .padding(.top, 110)
            } else if let img = tab.snapshot {
                Image(uiImage: img)
                    .resizable()
                    .interpolation(.medium)
                    .aspectRatio(contentMode: .fit)
            } else if let thumb = tab.thumb {
                // первая страница файла, как в просмотрщике: лист с полями
                Image(uiImage: thumb)
                    .resizable()
                    .interpolation(.medium)
                    .aspectRatio(contentMode: .fit)
                    .overlay(Rectangle().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
            } else {
                SiteIcon(resource: tab.resource, size: 40)
                    .opacity(0.3)
                    .padding(.top, 140)
            }
        }
        .clipped()
    }
}

/// Значок вкладки: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28, style: .continuous)
                .fill(c)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.5, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

/// Свой цвет у каждого сайта и типа файла — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        if let u = URL(string: r.url), u.isFileURL { return FileLook.color(u) }
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || host == "edu.narfu.ru" || r.icon.contains("envelope") {
            return Color(red: 0.20, green: 0.33, blue: 0.55)
        }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками) — карточкой, все сайты одинаково
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        SiteTabs.shared.open(r)
    }

    /// Ссылка из любого места: поверх приложения — карточкой, поверх окна — в этом окне Safari
    static func link(_ u: URL) {
        let r = Resource(title: u.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт",
                         subtitle: "", url: u.absoluteString, icon: "globe", category: "Ссылки")
        SiteTabs.shared.open(r)
    }
}


// MARK: - Развёрнутая карточка: UIKit-движок

/// Содержимое карточки в своём UIHostingController: шапка и страница.
/// Во время жестов SwiftUI его не трогает — двигается только слой вокруг
private struct CardContent: View {
    @ObservedObject var tab: SiteTab
    let live: Bool
    let bottomInset: CGFloat
    @ObservedObject private var motion = MiniMotion.shared

    var body: some View {
        let t = tab
        VStack(spacing: 0) {
            MiniHeader(resource: t.resource, onClose: { SiteTabs.shared.close(t) }) {
                MiniPill(collapse: live && motion.pillCollapsed ? 1 : 0,
                         onChevron: { _ = SiteTabs.shared.minimize() }) {
                    CardMenu(tab: t)
                }
                .animation(.easeOut(duration: 0.22), value: motion.pillCollapsed)
            }
            CardBody(tab: t, bottomInset: bottomInset)
        }
        .background(MiniChrome.headerColor)
        .modifier(AppearanceRoot())
        .tint(Color.brand)
        .pausesAmbient()
    }
}

struct CardMotor: UIViewRepresentable {
    let tab: SiteTab
    let live: Bool
    /// Верх плашки свёрнутых в координатах SiteLayer (от верхней безопасной зоны)
    let barTop: CGFloat
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore

    private func root(bottomInset: CGFloat) -> AnyView {
        AnyView(CardContent(tab: tab, live: live, bottomInset: bottomInset)
            .environmentObject(store)
            .environmentObject(schedule))
    }

    func makeUIView(context: Context) -> CardMotorView {
        let v = CardMotorView(root: root(bottomInset: CardMotorView.windowInsets.bottom))
        v.snapshotImage = tab.snapshot
        v.setFace(tab.resource, extra: max(SiteTabs.shared.tabs.count - 1, 0))
        v.barTopLocal = barTop
        v.isLive = live
        return v
    }

    func updateUIView(_ v: CardMotorView, context: Context) {
        v.snapshotImage = tab.snapshot
        v.setFace(tab.resource, extra: max(SiteTabs.shared.tabs.count - 1, 0))
        v.host.rootView = root(bottomInset: CardMotorView.windowInsets.bottom)
        v.barTopLocal = barTop
        v.isLive = live
    }

    static func dismantleUIView(_ v: CardMotorView, coordinator: ()) {
        v.teardown()
    }
}

final class CardMotorView: UIView, UIGestureRecognizerDelegate {
    let host: UIHostingController<AnyView>
    private let dim = UIView()
    private let clip = UIView()
    private let cover = UIView()
    /// Вся страница с шапкой: при перетекании сжимается по ширине и тает
    private let content = UIView()
    /// Лицо капсулы внутри окна — проявляется в конце перетекания
    private let face: UIHostingController<AnyView>
    /// Жидкое стекло: окно становится каплей стекла и сливается с капсулой, как вода
    private let glassBox = UIVisualEffectView(effect: LiquidGlass.container(spacing: 28))
    private let dropGlass = UIVisualEffectView(effect: nil)
    private let poolGlass = UIVisualEffectView(effect: nil)
    private var dropOn = false
    private var poolOn = false
    private var pan: UIPanGestureRecognizer!
    private var armed = false
    private var last = MiniMotion.State()
    /// Снимок страницы, сделанный при сворачивании (им карточка вырастает из капсулы)
    var snapshotImage: UIImage?
    /// Пока окно уменьшается, вместо живой страницы двигается её неподвижная копия:
    /// WebKit не дорисовывает уменьшенную страницу и показывал серый прямоугольник
    private var frozen: UIView?
    private var frozenHidesHost = false
    /// Карточку уже видели развёрнутой — её можно скопировать как есть
    private var wasExpanded = false
    /// Матовое стекло: у самой капсулы окно мутнеет и растворяется в ней
    private let frost = UIVisualEffectView(effect: nil)
    private var frostAnimator: UIViewPropertyAnimator?

    var barTopLocal: CGFloat = 0 { didSet { if barTopLocal != oldValue { apply(last) } } }
    var isLive = false {
        didSet {
            guard isLive != oldValue else { return }
            dim.isHidden = !isLive
            pan.isEnabled = isLive
            if isLive {
                MiniMotion.shared.live = self
            } else {
                if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
                apply(.init())
            }
        }
    }

    static var windowInsets: UIEdgeInsets {
        let w = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        return w?.safeAreaInsets ?? .zero
    }

    init(root: AnyView) {
        host = UIHostingController(rootView: root)
        face = UIHostingController(rootView: AnyView(EmptyView()))
        super.init(frame: .zero)
        clipsToBounds = false
        backgroundColor = .clear

        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        dim.isHidden = true
        addSubview(dim)

        clip.clipsToBounds = true
        clip.layer.cornerRadius = MiniChrome.radius
        clip.layer.cornerCurve = .continuous
        clip.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        let headerUI = UIColor { t in
            t.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor(white: 0.975, alpha: 1)
        }
        glassBox.isUserInteractionEnabled = false
        glassBox.backgroundColor = .clear
        addSubview(glassBox)
        for v in [poolGlass, dropGlass] {
            v.isUserInteractionEnabled = false
            LiquidGlass.round(v, MiniChrome.radius)
            glassBox.contentView.addSubview(v)
        }

        clip.backgroundColor = .clear
        addSubview(clip)

        content.backgroundColor = headerUI
        content.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        content.clipsToBounds = true
        clip.addSubview(content)

        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        content.addSubview(host.view)

        cover.backgroundColor = headerUI
        cover.alpha = 0
        cover.isUserInteractionEnabled = false
        content.addSubview(cover)

        frost.isUserInteractionEnabled = false
        frost.isHidden = true
        clip.addSubview(frost)

        face.safeAreaRegions = []
        face.view.backgroundColor = .clear
        face.view.isUserInteractionEnabled = false
        face.view.alpha = 0
        clip.addSubview(face.view)

        pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        pan.isEnabled = false
        clip.addGestureRecognizer(pan)
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: встраивание контроллера — чтобы алерты, меню и «Поделиться» внутри страницы работали

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil, host.parent == nil, let parent = parentController() else { return }
        parent.addChild(host)
        host.didMove(toParent: parent)
        apply(isLive ? MiniMotion.shared.state : .init())
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    func setFace(_ resource: Resource, extra: Int) {
        face.rootView = AnyView(IslandIcon(resource: resource, latest: true).modifier(AppearanceRoot()))
    }

    func teardown() {
        frostAnimator?.stopAnimation(true)
        frostAnimator = nil
        if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
        host.willMove(toParent: nil)
        host.view.removeFromSuperview()
        host.removeFromParent()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        apply(last)
    }

    // MARK: геометрия — в координатах окна, как бы SwiftUI ни разместил этот вид

    private struct Geo {
        var origin: CGPoint
        var width: CGFloat
        var screenH: CGFloat
        var top: CGFloat
        var fullH: CGFloat
        var barTop: CGFloat
        /// Верх уменьшенного окна, когда оно стоит центром на капсуле
        var endTop: CGFloat {
            MiniChrome.capsuleCenter(barTop: barTop, width: width) - fullH * MiniChrome.minScale / 2
        }
        /// Капсула на экране
        var capsule: CGRect {
            let w = MiniChrome.capsuleWidth(width)
            let h = MiniChrome.capsuleHeight
            return CGRect(x: (width - w) / 2, y: MiniChrome.capsuleCenter(barTop: barTop, width: width) - h / 2,
                          width: w, height: h)
        }
        /// Значок островка, в который летит окно
        var slot: CGRect {
            let m = SiteTabs.shared.morphSlot
            return MiniChrome.islandSlotRect(m.index, of: m.count, screen: width,
                                             centerY: MiniChrome.capsuleCenter(barTop: barTop, width: width))
        }
        /// Сколько проходит верх окна до значка — на столько же ведёт палец
        var travel: CGFloat { max(slot.minY - top, 1) }
    }

    private var geo: Geo? {
        guard let w = window else { return nil }
        let ins = w.safeAreaInsets
        let top = ins.top + MiniChrome.topGap
        return Geo(origin: convert(CGPoint.zero, to: nil),
                   width: w.bounds.width,
                   screenH: w.bounds.height,
                   top: top,
                   fullH: max(w.bounds.height - top, MiniChrome.header + 1),
                   barTop: ins.top + barTopLocal)
    }

    func apply(_ s: MiniMotion.State) {
        last = s
        guard let g = geo else { return }
        CATransaction.begin()
        CATransaction.setDisableActions(true)

        // Как сворачивание в Windows: окно сжимается и влетает в свой значок в островке.
        // Верх идёт ровно за пальцем, высота уходит быстрее ширины, страница тает,
        // в конце на месте окна — значок. Только рамка и прозрачность — никаких размытий на кадрах.
        let c = min(max(s.collapse, 0), 1.03)
        let slot = g.slot
        let cc = min(c, 1)
        let eh = 1 - pow(1 - cc, 1.7)
        let ew = cc * cc * (3 - 2 * cc)
        let w = max(slot.width * 0.9, g.width + (slot.width - g.width) * ew)
        let h = max(slot.height * 0.9, g.fullH + (slot.height - g.fullH) * eh)
        let cx = g.width / 2 + (slot.midX - g.width / 2) * ew
        let yWin = g.top + s.drag + (slot.minY - g.top) * c + s.slide * (g.fullH + 80)

        dim.frame = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.width, height: g.screenH)
        dim.alpha = isLive ? 0.4 * (1 - min(1, max(c, s.slide))) : 0

        clip.transform = .identity
        clip.alpha = 1
        clip.layer.cornerRadius = MiniChrome.radius + (12 - MiniChrome.radius) * cc
        clip.bounds = CGRect(x: 0, y: 0, width: w, height: h)
        clip.center = CGPoint(x: cx - g.origin.x, y: yWin - g.origin.y)
        clip.layer.borderWidth = 0

        let k = w / g.width
        content.bounds = CGRect(x: 0, y: 0, width: g.width, height: g.fullH)
        content.layer.position = CGPoint(x: w / 2, y: 0)
        content.transform = CGAffineTransform(scaleX: k, y: k)
        let cf = min(1, max(0, (c - 0.3) / 0.4))
        content.alpha = 1 - cf * cf * (3 - 2 * cf)

        let hostFrame = CGRect(x: 0, y: 0, width: g.width, height: g.fullH)
        if host.view.frame != hostFrame { host.view.frame = hostFrame }
        cover.alpha = 0
        freeze(c > 0.002 && s.slide < 0.01, g: g)
        if c < 0.001 && s.slide < 0.001 && s.drag == 0 && isLive { wasExpanded = true }
        frost.isHidden = true
        glassBox.isHidden = true

        let ff = min(1, max(0, (c - 0.55) / 0.35))
        face.view.alpha = ff * ff * (3 - 2 * ff)
        face.view.isHidden = face.view.alpha < 0.01
        face.view.bounds = CGRect(x: 0, y: 0, width: MiniChrome.islandSlot, height: MiniChrome.islandSlot)
        face.view.center = CGPoint(x: w / 2, y: h / 2)
        let fs = min(1, min(w, h) / MiniChrome.islandSlot)
        face.view.transform = CGAffineTransform(scaleX: max(fs, 0.5), y: max(fs, 0.5))

        // пока карточка не развёрнута, страница не принимает нажатия
        host.view.isUserInteractionEnabled = c < 0.01 && s.slide < 0.01

        CATransaction.commit()
    }

    private func freeze(_ on: Bool, g: Geo) {
        if on {
            guard frozen == nil else { return }
            if wasExpanded, let snap = host.view.snapshotView(afterScreenUpdates: false) {
                // окно было развёрнуто — копируем его целиком, живая страница прячется
                // живая страница остаётся под копией: так WebKit успевает снять её для стопки
                snap.frame = host.view.frame
                content.insertSubview(snap, aboveSubview: host.view)
                frozen = snap
                frozenHidesHost = false
            } else if let img = snapshotImage {
                // окно вырастает из капсулы — под живой шапкой снимок страницы
                let iv = UIImageView(image: img)
                iv.contentMode = .scaleAspectFill
                iv.clipsToBounds = true
                iv.backgroundColor = .white
                iv.frame = CGRect(x: 0, y: MiniChrome.header, width: g.width, height: g.fullH - MiniChrome.header)
                content.insertSubview(iv, aboveSubview: host.view)
                frozen = iv
                frozenHidesHost = false
            }
        } else if let f = frozen {
            f.removeFromSuperview()
            frozen = nil
            if frozenHidesHost { host.view.isHidden = false }
            frozenHidesHost = false
        }
    }

    // нажатия мимо карточки проходят в приложение
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let p = convert(point, to: clip)
        guard clip.point(inside: p, with: event) else { return nil }
        return super.hitTest(point, with: event) ?? clip
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        clip.point(inside: convert(point, to: clip), with: event)
    }

    // MARK: шапку тянут вниз — карточка едет ровно под пальцем

    override func gestureRecognizerShouldBegin(_ g: UIGestureRecognizer) -> Bool {
        guard g === pan else { return super.gestureRecognizerShouldBegin(g) }
        guard isLive, !SiteTabs.shared.busy else { return false }
        let p = pan.location(in: clip)
        let v = pan.velocity(in: clip)
        // за всю шапку, кроме кнопок по краям
        return p.y < MiniChrome.header && p.x > 56 && p.x < clip.bounds.width - 100 && abs(v.y) >= abs(v.x)
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geo else { return }
        let motion = MiniMotion.shared
        let y = r.translation(in: self).y
        switch r.state {
        case .began, .changed:
            if y >= 0 {
                motion.set(.init(collapse: min(1, y / g.travel)))
            } else {
                motion.set(.init(drag: -pow(-y, 0.6)))
            }
            let nowArmed = y > 120
            if nowArmed != armed {
                armed = nowArmed
                if nowArmed { SiteHaptics.rigid() }
            }
        default:
            armed = false
            let vel = r.velocity(in: self).y
            let far = r.state == .ended && (y > 120 || y + vel * 0.15 > g.travel * 0.5 || vel > 700) && vel > -200
            if !(far && SiteTabs.shared.minimize(velocity: vel / g.travel)) {
                motion.animate(to: .init(), response: 0.34,
                               velocity: .init(collapse: y >= 0 ? vel / g.travel : 0))
            }
        }
    }
}


// MARK: - Стопка на UIKit: каждый кадр рисует Core Animation, SwiftUI не пересчитывается

private final class StackCardState: ObservableObject {
    @Published var folding = false
    @Published var pill: CGFloat = 0
    @Published var extra = 0
}

private struct StackCardContent: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject var st: StackCardState

    var body: some View {
        StackCardView(tab: tab, dim: 0, pill: st.pill, folding: st.folding, extra: st.extra)
            .animation(.easeOut(duration: 0.2), value: st.pill)
            .modifier(AppearanceRoot())
    }
}

private final class StackNode {
    let tab: SiteTab
    let st = StackCardState()
    /// Плоская обёртка: наклонённая карточка рисуется внутри неё и не уходит в глубину за фон и соседей
    let wrap = UIView()
    let card = UIView()
    let dim = UIView()
    let host: UIHostingController<AnyView>
    /// Стекло и лицо капсулы: верхняя карточка стопки становится капсулой
    let glass = UIVisualEffectView(effect: nil)
    let face: UIHostingController<AnyView>

    init(tab: SiteTab, extra: Int, screen: CGFloat) {
        self.tab = tab
        host = UIHostingController(rootView: AnyView(StackCardContent(tab: tab, st: st)))
        face = UIHostingController(rootView: AnyView(IslandIcon(resource: tab.resource, latest: false)
            .modifier(AppearanceRoot())))
        face.safeAreaRegions = []
        face.view.backgroundColor = .clear
        face.view.alpha = 0
        face.view.isUserInteractionEnabled = false
        glass.isUserInteractionEnabled = false
        glass.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        card.clipsToBounds = true
        card.backgroundColor = .clear
        card.layer.cornerRadius = MiniChrome.radius
        card.layer.cornerCurve = .continuous
        card.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        card.layer.allowsEdgeAntialiasing = true
        card.isUserInteractionEnabled = false
        card.addSubview(host.view)
        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        card.addSubview(dim)
        // стекло — под страницей: страница тает, и карточка оказывается стеклянной капсулой
        card.insertSubview(glass, at: 0)
        card.addSubview(face.view)
        wrap.isUserInteractionEnabled = false
        wrap.backgroundColor = .clear
        wrap.addSubview(card)
    }
}

struct StackSwitcherHost: UIViewRepresentable {
    /// Верх плашки свёрнутых в координатах SiteLayer
    let barTop: CGFloat

    func makeUIView(context: Context) -> StackSwitcherView {
        let v = StackSwitcherView()
        v.barTopLocal = barTop
        return v
    }

    func updateUIView(_ v: StackSwitcherView, context: Context) {
        v.barTopLocal = barTop
    }

    static func dismantleUIView(_ v: StackSwitcherView, coordinator: ()) {
        v.teardown()
    }
}

final class StackSwitcherView: UIView, UIGestureRecognizerDelegate {
    var barTopLocal: CGFloat = 0

    private enum Phase: Equatable { case entering, shown, opening(UUID), leaving }

    private let bg = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let shade = UIView()
    private var nodes: [StackNode] = []
    private var phase: Phase = .entering
    private var scroll: CGFloat = 0
    private var scrollStart: CGFloat = 0
    private var axis = 0              // 0 — ещё не ясно, 1 — вбок, 2 — вертикально
    private var swipe: StackNode?
    private var swipeX: CGFloat = 0
    private var bag: AnyCancellable?
    private var built = false

    init() {
        super.init(frame: .zero)
        backgroundColor = .clear
        bg.alpha = 0
        bg.isUserInteractionEnabled = false
        addSubview(bg)
        shade.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        shade.isUserInteractionEnabled = false
        bg.contentView.addSubview(shade)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        addGestureRecognizer(pan)
        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onTap(_:))))
        AmbientCoordinator.shared.push(token)
    }

    private let token = UUID()

    required init?(coder: NSCoder) { fatalError() }

    func teardown() {
        bag = nil
        AmbientCoordinator.shared.popLater(token)
        for n in nodes {
            n.host.willMove(toParent: nil)
            n.host.view.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes = []
    }

    // MARK: геометрия в координатах окна

    private struct Geo {
        var origin: CGPoint
        var size: CGSize
        var safeTop: CGFloat
        var barTop: CGFloat
    }

    private var geo: Geo? {
        guard let w = window else { return nil }
        return Geo(origin: convert(CGPoint.zero, to: nil), size: w.bounds.size,
                   safeTop: w.safeAreaInsets.top, barTop: w.safeAreaInsets.top + barTopLocal)
    }

    private func layout(_ g: Geo) -> StackLayout {
        StackLayout(count: nodes.count, size: g.size, safeTop: g.safeTop)
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil, !built, let g = geo else { return }
        built = true
        bg.frame = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.size.width, height: g.size.height)
        shade.frame = bg.bounds
        let parent = parentController()
        for t in SiteTabs.shared.tabs { add(t, parent: parent, geo: g) }
        // стопка вырастает из плашки: сначала карточки стоят ровно там, где плашка
        phase = .entering
        applyAll(animated: false)
        bag = SiteTabs.shared.$tabs
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] list in self?.sync(list) }
        DispatchQueue.main.async { self.enter() }
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    private func add(_ t: SiteTab, parent: UIViewController?, geo g: Geo) {
        let n = StackNode(tab: t, extra: max(SiteTabs.shared.tabs.count - 1, 0), screen: g.size.width)
        let h = layout(g).cardHeight
        n.host.view.frame = CGRect(x: 0, y: 0, width: g.size.width, height: h)
        n.dim.frame = n.host.view.frame
        if let parent {
            parent.addChild(n.host)
            n.host.didMove(toParent: parent)
        }
        n.wrap.frame = bounds
        n.wrap.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(n.wrap)
        nodes.append(n)
    }

    /// Вкладки закрыли — карточки съезжаются на освободившееся место
    private func sync(_ list: [SiteTab]) {
        let ids = Set(list.map(\.id))
        let gone = nodes.filter { !ids.contains($0.tab.id) }
        guard !gone.isEmpty else { return }
        for n in gone {
            n.host.willMove(toParent: nil)
            n.wrap.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes.removeAll { !ids.contains($0.tab.id) }
        if swipe.map({ !ids.contains($0.tab.id) }) ?? false { swipe = nil; swipeX = 0 }
        guard !nodes.isEmpty, phase == .shown, let g = geo else { return }
        scroll = min(max(scroll, 0), layout(g).maxScroll)
        animate(0.42) { self.applyAll(animated: false) }
    }

    // MARK: позы

    private struct Pose {
        var y: CGFloat
        var angle: CGFloat
        var scale: CGFloat
        var dim: CGFloat
        var alpha: CGFloat
        var height: CGFloat
        /// Карточка свёрнута в значок: страница скрыта, видно значок
        var capsule = false
        /// Центр по горизонтали (nil — по центру экрана)
        var x: CGFloat? = nil
    }

    private func pose(_ i: Int, _ n: StackNode, _ g: Geo, _ lay: StackLayout) -> Pose {
        let count = nodes.count
        switch phase {
        case .entering, .leaving:
            // свёрнуто в плашку: верхняя — точно на месте плашки, остальные выглядывают краями колоды
            // все карточки уменьшаются в капсулу и тают — как окна при сворачивании в Windows
            // как в Windows: каждая карточка влетает в свой значок в островке
            let slot = MiniChrome.islandSlotRect(i, of: count, screen: g.size.width,
                                                 centerY: MiniChrome.capsuleCenter(barTop: g.barTop, width: g.size.width))
            let sc = slot.width / g.size.width
            return Pose(y: slot.minY, angle: 0, scale: sc, dim: 0,
                        alpha: i < MiniChrome.islandMax ? 1 : 0, height: slot.height / sc, capsule: true,
                        x: slot.midX)
        case .opening(let id):
            if n.tab.id == id {
                return Pose(y: g.safeTop + MiniChrome.topGap, angle: 0, scale: 1, dim: 0, alpha: 1, height: lay.cardHeight)
            }
            let p = lay.top(i, scroll: clampedScroll(lay))
            return Pose(y: p.y + g.size.height * 0.5, angle: lay.angle(at: p.y), scale: lay.scale,
                        dim: 0.3, alpha: 0, height: lay.cardHeight)
        case .shown:
            let p = lay.top(i, scroll: axis == 2 ? scroll : clampedScroll(lay))
            return Pose(y: p.y, angle: lay.angle(at: p.y), scale: lay.scale * (1 - 0.035 * p.depth),
                        dim: min(0.12 * p.depth, 0.4), alpha: 1, height: lay.cardHeight)
        }
    }

    private func clampedScroll(_ lay: StackLayout) -> CGFloat { min(max(scroll, 0), lay.maxScroll) }

    private func applyAll(animated: Bool) {
        guard let g = geo else { return }
        let lay = layout(g)
        for (i, n) in nodes.enumerated() {
            var p = pose(i, n, g, lay)
            let dx: CGFloat = n === swipe ? swipeX : 0
            p.alpha *= 1 - min(abs(dx) / max(g.size.width, 1), 0.8)
            set(n, p, dx: dx, g: g)
        }
    }

    private func set(_ n: StackNode, _ p: Pose, dx: CGFloat, g: Geo) {
        n.card.bounds = CGRect(x: 0, y: 0, width: g.size.width, height: p.height)
        n.card.center = CGPoint(x: (p.x ?? g.size.width / 2) + dx - g.origin.x, y: p.y - g.origin.y)
        var t = CATransform3DMakeScale(p.scale, p.scale, 1)
        t = CATransform3DConcat(t, CATransform3DMakeRotation(-p.angle * .pi / 180, 1, 0, 0))
        var persp = CATransform3DIdentity
        persp.m34 = -1 / max(g.size.height * 0.8, 1)
        n.card.transform3D = CATransform3DConcat(t, persp)
        n.card.alpha = p.alpha
        n.dim.alpha = p.dim
        // скругление на экране: 22 точки у карточки, 12 — у значка
        n.card.layer.cornerRadius = (p.capsule ? 12 : MiniChrome.radius) / max(p.scale, 0.05)
        n.glass.frame = n.card.bounds
        n.host.view.alpha = p.capsule ? 0 : 1
        n.face.view.alpha = p.capsule ? 1 : 0
        n.face.view.bounds = CGRect(x: 0, y: 0, width: MiniChrome.islandSlot, height: MiniChrome.islandSlot)
        n.face.view.center = CGPoint(x: g.size.width / 2, y: p.height / 2)
        n.face.view.transform = CGAffineTransform(scaleX: 1 / max(p.scale, 0.05), y: 1 / max(p.scale, 0.05))
        n.glass.isHidden = true
    }

    private func animate(_ duration: Double, velocity: CGFloat = 0, delay: Double = 0,
                         _ body: @escaping () -> Void, completion: (() -> Void)? = nil) {
        UIView.animate(springDuration: duration, bounce: 0, initialSpringVelocity: velocity, delay: delay,
                       options: [.allowUserInteraction, .beginFromCurrentState], animations: body) { _ in
            completion?()
        }
    }

    /// Палец поймал карточки посреди анимации — продолжаем с того места, где они сейчас на экране
    private func freeze() {
        for n in nodes {
            guard let pl = n.card.layer.presentation() else { continue }
            n.card.layer.removeAllAnimations()
            n.card.layer.bounds = pl.bounds
            n.card.layer.position = pl.position
            n.card.layer.transform = pl.transform
            n.card.layer.opacity = pl.opacity
        }
    }

    // MARK: появление, раскрытие, уход в плашку

    private func enter() {
        guard phase == .entering else { return }
        phase = .shown
        for n in nodes {
            n.st.folding = false
            n.st.extra = 0
            n.st.pill = 0
        }
        guard let g = geo else { return }
        let lay = layout(g)
        animate(0.32) { self.bg.alpha = 1 }
        for (i, n) in nodes.enumerated() {
            let p = pose(i, n, g, lay)
            // верхняя поднимается первой, остальные — чуть следом, веером
            animate(0.5, delay: Double(nodes.count - 1 - i) * 0.025) { self.set(n, p, dx: 0, g: g) }
        }
    }

    private func open(_ n: StackNode) {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .opening(n.tab.id)
        n.st.pill = 1
        bringSubviewToFront(n.wrap)
        animate(0.4) {
            self.applyAll(animated: false)
            self.bg.alpha = 0
        } completion: {
            SiteTabs.shared.restore(n.tab, from: .stack)
        }
    }

    private func dismiss() {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .leaving
        swipe = nil
        swipeX = 0
        SiteTabs.shared.switcherLeaving = true
        if let top = nodes.last { bringSubviewToFront(top.wrap) }
        UIView.animate(springDuration: 0.42, bounce: 0, initialSpringVelocity: 0, delay: 0,
                       options: [.allowUserInteraction, .beginFromCurrentState]) {
            self.applyAll(animated: false)
            self.bg.alpha = 0
        } completion: { _ in
            // верхняя карточка стала капсулой ровно на её месте — подменяем без анимации появления
            SiteTabs.shared.capsuleArrived = true
            SiteTabs.shared.hideSwitcher()
        }
    }

    private func fly(_ n: StackNode, direction: CGFloat, velocity: CGFloat) {
        guard let g = geo else { return }
        let target = direction * g.size.width * 1.15
        let rel = abs(velocity) / max(abs(target - swipeX), 1)
        SiteHaptics.rigid()
        animate(0.32, velocity: min(rel, 8)) {
            n.card.center.x = g.size.width / 2 + target - g.origin.x
            n.card.alpha = 0
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
        swipe = nil
        swipeX = 0
    }

    private func closeByButton(_ n: StackNode) {
        SiteHaptics.rigid()
        animate(0.3) {
            n.card.alpha = 0
            n.card.transform3D = CATransform3DScale(n.card.transform3D, 0.9, 0.9, 1)
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
    }

    // MARK: жесты

    private func windowPoint(_ r: UIGestureRecognizer) -> CGPoint {
        r.location(in: nil)
    }

    private func cardIndex(at p: CGPoint, lay: StackLayout) -> Int? {
        let sc = clampedScroll(lay)
        var hit: Int?
        for i in 0..<nodes.count where lay.top(i, scroll: sc).y <= p.y { hit = i }
        return hit
    }

    override func gestureRecognizerShouldBegin(_ r: UIGestureRecognizer) -> Bool {
        phase == .shown
    }

    @objc private func onTap(_ r: UITapGestureRecognizer) {
        guard phase == .shown, let g = geo else { return }
        let lay = layout(g)
        let p = windowPoint(r)
        guard let i = cardIndex(at: p, lay: lay) else { dismiss(); return }
        let n = nodes[i]
        let top = lay.top(i, scroll: clampedScroll(lay)).y
        let inset = g.size.width * (1 - lay.scale) / 2
        if p.y - top < MiniChrome.header * lay.scale && p.x < inset + 54 {
            closeByButton(n)
        } else {
            open(n)
        }
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geo else { return }
        let lay = layout(g)
        let t = r.translation(in: nil)
        let v = r.velocity(in: nil)
        switch r.state {
        case .began:
            guard phase == .shown else { return }
            freeze()
            axis = abs(v.x) > abs(v.y) ? 1 : 2
            scrollStart = clampedScroll(lay)
            if axis == 1, let i = cardIndex(at: windowPoint(r), lay: lay) { swipe = nodes[i] }
        case .changed:
            guard phase == .shown else { return }
            if axis == 1 {
                guard swipe != nil else { return }
                swipeX = t.x
            } else {
                scroll = rubber(scrollStart + t.y, max: lay.maxScroll)
            }
            applyAll(animated: false)
        default:
            guard phase == .shown else { axis = 0; return }
            let wasAxis = axis
            axis = 0
            if wasAxis == 1 {
                if let n = swipe, abs(t.x) > 110 || abs(v.x) > 800 {
                    fly(n, direction: (abs(v.x) > 300 ? v.x : t.x) < 0 ? -1 : 1, velocity: v.x)
                } else {
                    swipe = nil
                    let rel = abs(v.x) / max(abs(swipeX), 1)
                    swipeX = 0
                    animate(0.34, velocity: min(rel, 8)) { self.applyAll(animated: false) }
                }
            } else {
                // потянул вниз, когда прокручивать некуда, — стопка складывается обратно в плашку
                if t.y > 130 && scrollStart + t.y > lay.maxScroll + 110 {
                    dismiss()
                    return
                }
                let from = scroll
                let target = min(max(scrollStart + t.y + v.y * 0.22, 0), lay.maxScroll)
                scroll = target
                let rel = abs(v.y) / max(abs(target - from), 1)
                animate(0.5, velocity: min(rel, 6)) { self.applyAll(animated: false) }
            }
        }
    }

    private func rubber(_ v: CGFloat, max m: CGFloat) -> CGFloat {
        if v < 0 { return -pow(-v, 0.7) }
        if v > m { return m + pow(v - m, 0.7) }
        return v
    }
}
