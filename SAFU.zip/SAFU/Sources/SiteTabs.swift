import SwiftUI
import Combine
import WebKit
import QuickLook
import QuickLookThumbnailing
import PDFKit
import LocalAuthentication

// MARK: - Сайты и файлы как мини-приложения
//
// Сайт или файл открывается карточкой на весь экран, приложение под ней темнеет.
// Шапка как у мини-приложений Telegram: крестик слева, название по центру, справа капсула «⌄ ⋯».
// Потянул шапку вниз или нажал «⌄» — карточка сжимается и садится в плашку внизу, как в Арктике
// для Windows: кружки значков внахлёст, название верхнего окна, «ещё N» и капсула «⌃ ▤ ✕».
// Вход, прокрутка, открытая страница PDF — всё остаётся на месте. Нажал плашку — окно вырастает из неё,
// потянул вверх — растёт прямо под пальцем, смахнул вбок — наверх выходит следующее окно,
// «▤» — стопка всех окон с наклоном назад: «Открыто: N», нажми — откроется, смахни вбок — закроется.
//
// Плавность. Все переходы — пружины Core Animation: их считает системный рендер-сервер, а не приложение,
// поэтому кадры не теряются, даже если приложение в этот миг занято. На время движения живая страница
// подменяется своей неподвижной копией и прячется — двигается одна лёгкая картинка, а не весь WebKit.

enum MiniAnim {
    static let open = Animation.spring(response: 0.36, dampingFraction: 0.92)
    static let close = Animation.spring(response: 0.31, dampingFraction: 1)
    static let stack = Animation.spring(response: 0.38, dampingFraction: 0.88)
    static let quick = Animation.spring(response: 0.28, dampingFraction: 0.88)
    /// Содержимое плашки меняется: значки въезжают и уезжают, название сменяется
    static let dock = Animation.spring(response: 0.35, dampingFraction: 0.8)
    /// Плашка выскакивает с лёгким перелётом, как на Windows
    static let pill = Animation.spring(response: 0.36, dampingFraction: 0.64)
}

/// Размеры и цвета «хрома» мини-приложений — одни и те же у карточки, окошек и стопки,
/// поэтому переходы между ними совпадают до точки
enum MiniChrome {
    static let header: CGFloat = 54
    /// Зазор между статус-баром и развёрнутой карточкой
    static let topGap: CGFloat = 8
    static let radius: CGFloat = 22

    private static let headerUI = UIColor { t in
        t.userInterfaceStyle == .dark ? UIColor(white: 0.11, alpha: 1) : UIColor(white: 0.975, alpha: 1)
    }
    static var headerColor: Color { Color(uiColor: headerUI) }
    static var headerUIColor: UIColor { headerUI }

    static var hairline: some View {
        Rectangle()
            .fill(Color.primary.opacity(0.1))
            .frame(height: 0.5)
            .allowsHitTesting(false)
    }
}

/// Плашка свёрнутых внизу, как в Арктике для Windows. Одна и та же геометрия у плашки, у карточки,
/// которая в неё садится, и у стопки, которая из неё вылетает, — поэтому все переходы встают точно в плашку
enum MiniDock {
    static let h: CGFloat = 56
    static let maxW: CGFloat = 340
    /// Поля по бокам на узком экране
    static let side: CGFloat = 20
    static var radius: CGFloat { h / 2 }
    /// Низ плашки над нижним краем слоя (над вкладками)
    static let lift: CGFloat = 70
    /// Сколько кружков значков видно в плашке
    static let maxIcons = 3

    static func width(_ screenW: CGFloat) -> CGFloat { max(min(maxW, screenW - side * 2), 1) }

    /// Плашка: по центру, верх — top
    static func rect(width screenW: CGFloat, top: CGFloat) -> CGRect {
        let w = width(screenW)
        return CGRect(x: (screenW - w) / 2, y: top, width: w, height: h)
    }

    /// Во сколько раз окно уменьшается, садясь в плашку
    static func scale(_ screenW: CGFloat) -> CGFloat { width(screenW) / max(screenW, 1) }
    /// Сколько окна (в его собственных точках) остаётся видно в плашке: шапка и самый верх страницы
    static func crop(_ screenW: CGFloat) -> CGFloat { h / scale(screenW) }
}

/// Отдельная от Haptics «твёрдая» отдача — щелчок, когда карточку дотянули до сворачивания
enum SiteHaptics {
    private static let rigidGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .rigid)
        g.prepare()
        return g
    }()
    private static let softGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .soft)
        g.prepare()
        return g
    }()
    private static var enabled: Bool { UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }

    static func rigid() {
        guard enabled else { return }
        rigidGen.impactOccurred(intensity: 0.75)
        rigidGen.prepare()
    }

    /// Мягкий толчок: окно село в плашку
    static func soft() {
        guard enabled else { return }
        softGen.impactOccurred(intensity: 0.55)
        softGen.prepare()
    }
}

// MARK: - Вид файла: значок, цвет, подпись

enum FileLook {
    static func ext(_ url: URL) -> String { url.pathExtension.lowercased() }

    static func icon(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt", "pages", "md": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods", "numbers": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled.fill"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "photo.fill"
        case "mp4", "mov", "m4v": return "play.rectangle.fill"
        case "mp3", "m4a", "wav", "aac": return "waveform"
        case "zip", "rar", "7z": return "archivebox.fill"
        default: return "doc.fill"
        }
    }

    static func kind(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "PDF"
        case "doc", "docx", "rtf", "odt", "pages": return "Документ"
        case "txt", "md": return "Текст"
        case "xls", "xlsx", "csv", "ods", "numbers": return "Таблица"
        case "ppt", "pptx", "key", "odp": return "Презентация"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "Фото"
        case "mp4", "mov", "m4v": return "Видео"
        case "mp3", "m4a", "wav", "aac": return "Аудио"
        case "": return "Файл"
        default: return ext(url).uppercased()
        }
    }

    /// «PDF · 2,4 МБ»
    static func meta(_ url: URL) -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        guard size > 0 else { return kind(url) }
        return kind(url) + " · " + ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    /// Файл в виде «ресурса»: так у него та же шапка, значок и цвет, что у сайтов
    static func resource(_ url: URL) -> Resource {
        Resource(title: url.deletingPathExtension().lastPathComponent,
                 subtitle: meta(url),
                 url: url.absoluteString,
                 icon: icon(url),
                 category: "Файлы")
    }

    static func canPrint(_ url: URL) -> Bool { UIPrintInteractionController.canPrint(url) }

    static func printFile(_ url: URL) {
        let c = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = ["jpg", "jpeg", "png", "heic", "webp", "tiff"].contains(ext(url)) ? .photo : .general
        info.jobName = url.lastPathComponent
        c.printInfo = info
        c.printingItem = url
        _ = c.present(animated: true, completionHandler: nil)
    }

    /// Положить сам файл в буфер обмена — вставляется в Telegram, почту, Заметки
    static func copy(_ url: URL) {
        guard let p = NSItemProvider(contentsOf: url) else { return }
        UIPasteboard.general.itemProviders = [p]
        Haptics.success()
    }

    /// Снимок без содержимого (QuickLook иногда рисуется в другом процессе и снимается пустым)
    static func isBlank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage else { return true }
        let w = 24, h = 24
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return false }
        var lo = [255, 255, 255], hi = [0, 0, 0]
        for i in 0..<(w * h) {
            for c in 0..<3 {
                let v = Int(px[i * 4 + c])
                lo[c] = min(lo[c], v)
                hi[c] = max(hi[c], v)
            }
        }
        return (0..<3).allSatisfy { hi[$0] - lo[$0] < 10 }
    }

    /// Снимок вида средствами UIKit — в уменьшенном масштабе, чтобы стопка не съедала память
    static func render(_ v: UIView) -> UIImage? {
        guard v.window != nil, v.bounds.width > 1, v.bounds.height > 1 else { return nil }
        let format = UIGraphicsImageRendererFormat.preferred()
        format.scale = min(2, v.window?.screen.scale ?? 2)
        let img = UIGraphicsImageRenderer(bounds: v.bounds, format: format).image { _ in
            _ = v.drawHierarchy(in: v.bounds, afterScreenUpdates: false)
        }
        return isBlank(img) ? nil : img
    }
}

// MARK: - Просмотр файла, который переживает сворачивание

/// Просмотр живёт в карточке, а не на экране: свернул — и вернулся на ту же страницу.
/// PDF (учебники, методички) — встроенным PDFKit: он рисует страницы в самом приложении, поэтому
/// не пропадает, пока приложение в фоне, и помнит страницу. Остальное — QuickLook
final class FilePreviewHolder: NSObject, QLPreviewControllerDataSource {
    let url: URL

    lazy var controller: UIViewController = {
        // защищённый только «пустым» паролем (так бывает у решебников) — тоже открываем сами
        if FileLook.ext(url) == "pdf", let doc = PDFDocument(url: url), !doc.isLocked || doc.unlock(withPassword: "") {
            return PDFPageController(url: url, document: doc)
        }
        let c = QLPreviewController()
        c.dataSource = self
        return c
    }()

    /// Приложение уходило в фон: QuickLook рисует в отдельном системном процессе, и iOS его выгружает —
    /// без перезагрузки после возвращения на месте файла была пустая страница
    private var wasInBackground = false
    private var observers: [NSObjectProtocol] = []

    init(url: URL) {
        self.url = url
        super.init()
        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                        object: nil, queue: .main) { [weak self] _ in
            self?.wasInBackground = true
        })
        observers.append(nc.addObserver(forName: UIApplication.didBecomeActiveNotification,
                                        object: nil, queue: .main) { [weak self] _ in
            guard let self, self.wasInBackground else { return }
            self.wasInBackground = false
            self.revive()
        })
    }

    deinit {
        observers.forEach { NotificationCenter.default.removeObserver($0) }
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        url as NSURL
    }

    private func revive() {
        guard let ql = controller as? QLPreviewController, ql.isViewLoaded else { return }
        ql.reloadData()
    }

    /// Переносим просмотр в новую карточку (старая может ещё доигрывать исчезновение)
    func attach(to box: UIViewController) {
        let c = controller
        if c.parent === box { return }
        if c.parent != nil {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        box.addChild(c)
        c.view.frame = box.view.bounds
        c.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.view.addSubview(c.view)
        c.didMove(toParent: box)
    }

    /// Снимок той страницы, на которой остановился
    func snapshot() -> UIImage? {
        guard controller.isViewLoaded, let v = controller.view else { return nil }
        return FileLook.render(v)
    }

    /// Первая страница — для карточки в стопке, пока своего снимка нет
    func makeThumbnail(_ done: @escaping (UIImage) -> Void) {
        let req = QLThumbnailGenerator.Request(fileAt: url, size: CGSize(width: 360, height: 520),
                                               scale: 2, representationTypes: .thumbnail)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
            guard let img = rep?.uiImage else { return }
            DispatchQueue.main.async { done(img) }
        }
    }
}

/// Где остановился в каждом PDF: страница и место на ней. Ключ — папка и имя файла
/// (полный путь к папке приложения меняется после обновлений)
enum FileMemory {
    private static let key = "files.pdfPlace.v1"

    private static func id(_ url: URL) -> String {
        url.deletingLastPathComponent().lastPathComponent + "/" + url.lastPathComponent
    }

    static func place(for url: URL) -> (page: Int, point: CGPoint)? {
        guard let raw = (UserDefaults.standard.dictionary(forKey: key) as? [String: String])?[id(url)] else { return nil }
        let p = raw.split(separator: "|").compactMap { Double($0) }
        guard p.count >= 3 else { return nil }
        return (Int(p[0]), CGPoint(x: p[1], y: p[2]))
    }

    static func remember(page: Int, point: CGPoint, for url: URL) {
        var all = UserDefaults.standard.dictionary(forKey: key) as? [String: String] ?? [:]
        all[id(url)] = "\(page)|\(Double(point.x))|\(Double(point.y))|\(Date().timeIntervalSince1970)"
        // помним последние 200 файлов
        if all.count > 200 {
            let stamp: (String) -> Double = { Double($0.split(separator: "|").last ?? "") ?? 0 }
            for (k, _) in all.sorted(by: { stamp($0.value) < stamp($1.value) }).prefix(all.count - 200) {
                all.removeValue(forKey: k)
            }
        }
        UserDefaults.standard.set(all, forKey: key)
    }
}

/// PDF в карточке: листается сплошной лентой, открывается там, где его оставили
final class PDFPageController: UIViewController {
    let url: URL
    private let document: PDFDocument
    private let pdf = PDFView()
    private var restored = false
    /// Место, на котором человек остановился (при настоящем размере ленты)
    private var anchor: PDFDestination?
    /// Лента меняет размер и возвращается на место — её прыжки в это время не запоминаем
    private var settling = false
    private var observers: [NSObjectProtocol] = []

    init(url: URL, document: PDFDocument) {
        self.url = url
        self.document = document
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError() }

    deinit {
        observers.forEach { NotificationCenter.default.removeObserver($0) }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .secondarySystemBackground
        // размер ленте задаём сами в viewDidLayoutSubviews: так видно, когда он меняется
        pdf.displayMode = .singlePageContinuous
        pdf.displayDirection = .vertical
        pdf.autoScales = true
        pdf.pageShadowsEnabled = true
        pdf.backgroundColor = .secondarySystemBackground
        pdf.document = document
        view.addSubview(pdf)

        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName: .PDFViewPageChanged, object: pdf, queue: .main) { [weak self] _ in
            self?.remember()
        })
        // уходит в фон или блокировку — точное место на странице тоже запоминаем
        observers.append(nc.addObserver(forName: UIApplication.willResignActiveNotification,
                                        object: nil, queue: .main) { [weak self] _ in
            self?.remember()
        })
    }

    private static func usable(_ size: CGSize) -> Bool { size.width > 120 && size.height > 120 }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let size = view.bounds.size
        guard pdf.frame.size != size else { return }
        // Карточку открыли, свернули или перенесли: PDFView с autoScales пересчитывает масштаб
        // и съезжает на другую страницу (часто на середину) — а это место потом запоминалось.
        // Берём место до смены размера и возвращаемся на него, когда размер снова настоящий
        if restored, !settling, Self.usable(pdf.frame.size), let here = destination() { anchor = here }
        settling = true
        pdf.frame = CGRect(origin: .zero, size: size)
        guard Self.usable(size) else { return }
        if !restored {
            restored = true
            if let place = FileMemory.place(for: url), place.page >= 0, place.page < document.pageCount,
               let page = document.page(at: place.page) {
                anchor = PDFDestination(page: page, at: place.point)
            }
        }
        DispatchQueue.main.async { [weak self] in
            guard let self, self.pdf.frame.size == size else { return }
            self.pdf.layoutIfNeeded()
            if let anchor = self.anchor { self.pdf.go(to: anchor) }
            // уведомления о смене страницы от этого прыжка приходят чуть позже — пропускаем их
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak self] in
                guard let self, self.pdf.frame.size == size else { return }
                self.settling = false
            }
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        remember()
    }

    /// Где сейчас верх ленты; у PDFView бывает «неопределённая» точка — такую не берём
    private func destination() -> PDFDestination? {
        guard let dest = pdf.currentDestination, dest.page != nil,
              dest.point.x.isFinite, dest.point.y.isFinite,
              abs(dest.point.x) < 100_000, abs(dest.point.y) < 100_000 else { return nil }
        return dest
    }

    private func remember() {
        guard restored, !settling, Self.usable(pdf.frame.size),
              let dest = destination(), let page = dest.page else { return }
        anchor = dest
        FileMemory.remember(page: document.index(for: page), point: dest.point, for: url)
    }
}

private struct FilePreviewBox: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .secondarySystemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ box: UIViewController, coordinator: ()) {
        // просмотр уже мог переехать в новую карточку — тогда здесь его нет и трогать нечего
        for c in box.children {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
    }
}

// MARK: - Вкладка: сайт или файл

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    /// Есть — это файл, нет — сайт
    let file: FilePreviewHolder?
    private var web: WebModel?
    /// Как выглядела вкладка, когда её свернули
    @Published var snapshot: UIImage?
    /// Первая страница файла
    @Published var thumb: UIImage?

    var isFile: Bool { file != nil }
    /// Плитка, из которой вкладку открыли (метка OriginProbe), и её скругление: закрытая — садится обратно в неё
    var originKey: String?
    var originRadius: CGFloat = 15
    /// Вкладка вернулась после перезапуска приложения: с какой страницы и прокрутки начать
    var restore: (url: URL, offset: CGPoint)?

    /// Живая страница сайта (у файлов не создаётся — им браузер не нужен)
    var model: WebModel {
        if let web { return web }
        let m = WebModel()
        if let r = restore {
            m.startOverride = r.url
            m.restorePlace = (url: Optional(r.url), offset: r.offset)
            restore = nil
        }
        web = m
        return m
    }

    /// Страница, если её уже открывали (не создаёт новую)
    var loadedModel: WebModel? { web }

    init(resource: Resource) {
        self.resource = resource
        self.file = nil
    }

    init(file url: URL) {
        self.file = FilePreviewHolder(url: url)
        self.resource = FileLook.resource(url)
    }

    func matches(file url: URL) -> Bool {
        guard let f = file?.url else { return false }
        return f.standardizedFileURL.path == url.standardizedFileURL.path
    }
}

/// Где сейчас развёрнутая карточка и куда она едет. Переходы считает не приложение, а системный
/// рендер-сервер (пружины Core Animation): приложение один раз задаёт, куда ехать, и дальше кадры
/// идут сами, 120 в секунду, даже если в этот миг SwiftUI что-то пересчитывает.
/// Пока карточку ведёт палец, положение задаётся напрямую на каждом кадре жеста
final class MiniMotion {
    static let shared = MiniMotion()

    struct State: Equatable {
        /// 0 — карточка развёрнута, 1 — сжалась в плашку свёрнутых
        var collapse: CGFloat = 0
        /// Палец тянет шапку вверх (резинка), точки
        var drag: CGFloat = 0
        /// 0 — на месте, 1 — уехала за нижний край экрана
        var slide: CGFloat = 0
    }

    /// Куда карточка едет (или где стоит)
    private(set) var state = State()
    /// Насколько карточка ушла с экрана
    var hidden: CGFloat { min(1, max(state.collapse, state.slide)) }

    /// Развёрнутая сейчас карточка
    weak var live: CardMotorView? {
        didSet {
            live?.apply(current)
            if let live { attached(live) }
        }
    }

    private var token = 0
    /// Переход задали, когда карточки ещё нет на экране: он начнётся, как только она появится
    private var pending: (() -> Void)?
    private var pendingFrom: State?

    /// Что показывать карточке, которая только что появилась
    var current: State { pendingFrom ?? state }

    /// Сразу, без анимации (жест пальцем)
    func set(_ s: State) {
        token += 1
        pending = nil
        pendingFrom = nil
        state = s
        live?.halt()
        live?.apply(s)
    }

    func reset() { set(State()) }

    /// Карточка ушла из иерархии — её больше не двигаем
    func detach() {
        token += 1
        pending = nil
        pendingFrom = nil
        live = nil
        state = State()
    }

    /// Пружина. velocity — скорость пальца в долях пути в секунду.
    /// started — когда движение уже началось.
    /// started стоит раньше остальных, чтобы замыкание в конце вызова всегда было completion
    func animate(to t: State, started: (() -> Void)? = nil, response: Double = 0.42, damping: Double = 1,
                 velocity: State = State(), completion: (() -> Void)? = nil) {
        token += 1
        let tk = token
        let from = state
        state = t
        pending = nil
        pendingFrom = nil

        let finish: () -> Void = { [weak self] in
            guard let self, self.token == tk else { return }
            if t == State() { self.live?.settle() }
            completion?()
        }
        let start: () -> Void = { [weak self] in
            guard let self, self.token == tk, let v = self.live, v.window != nil else { return }
            self.pending = nil
            self.pendingFrom = nil
            // скорость пальца — в долях оставшегося пути, как её понимает пружина UIKit
            func norm(_ a: CGFloat, _ b: CGFloat, _ speed: CGFloat) -> CGFloat {
                abs(b - a) > 0.001 ? min(max(speed / (b - a), -10), 10) : 0
            }
            var nv: CGFloat = 0
            if abs(t.collapse - from.collapse) > 0.001 {
                nv = norm(from.collapse, t.collapse, velocity.collapse)
            } else if abs(t.slide - from.slide) > 0.001 {
                nv = norm(from.slide, t.slide, velocity.slide)
            }
            v.apply(from)
            v.animate(to: t, response: response, bounce: min(max(1 - damping, 0), 0.4), velocity: nv)
            if let started { DispatchQueue.main.async(execute: started) }
            // пружина почти пришла (меньше точки до цели) — переход закончен
            DispatchQueue.main.asyncAfter(deadline: .now() + response * 1.45, execute: finish)
        }

        if let v = live, v.window != nil {
            start()
        } else {
            // карточку только что добавили — SwiftUI ещё не поставил её на экран
            pending = start
            pendingFrom = from
            // запасной выход, если карточка так и не встала на экран
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                guard let self, self.token == tk, self.pending != nil else { return }
                self.pending = nil
                self.pendingFrom = nil
                self.live?.apply(t)
                started?()
                finish()
            }
        }
    }

    /// Карточка встала на экран — начинаем переход, который её ждал.
    /// Не сразу, а следующим шагом: сейчас идёт обновление SwiftUI, а в нём анимации UIKit выключены —
    /// карточка встала бы на место рывком и только растворилась бы
    func attached(_ v: CardMotorView) {
        guard v === live, v.window != nil, pending != nil else { return }
        DispatchQueue.main.async { [weak self, weak v] in
            guard let self, let v, v === self.live, v.window != nil, let p = self.pending else { return }
            p()
        }
    }
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()

    /// Откуда разворачивается карточка
    enum Entry { case bottom, bar, stack }

    /// Открытые сайты и файлы, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутая сейчас вкладка (nil — все свёрнуты)
    @Published private(set) var activeID: UUID?
    /// Прошлая развёрнутая карточка: лежит под новой, пока та выезжает снизу
    @Published private(set) var underID: UUID?
    @Published var showSwitcher = false
    /// Стопка складывается обратно в плашку
    @Published var switcherLeaving = false
    /// Окно садится в плашку: оно ещё тает на экране, а плашка уже показывает его
    @Published private(set) var landingID: UUID?
    /// В плашку только что село окно — плашка коротко подпрыгивает
    @Published var landed: UUID?
    /// Где сейчас плашка (в координатах экрана) — окно-слой забирает нажатия только там
    var barRect: CGRect = .zero
    /// В приложении открыт лист или окно — плашку над ним не показываем
    @Published var sheetCovering = false
    /// Старый режим «настоящим Safari» (сейчас все сайты, и почта тоже, открываются карточкой)
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26) — плашка прячется следом
    @Published var barInline = false
    /// Файлы закрыты Face ID (включено «Файлы по Face ID», и приложение уходило в фон)
    @Published var filesLocked = false
    /// Плашку тянут пальцем вверх: окно уже растёт под пальцем
    @Published private(set) var barDragging = false
    /// Карточка вырастает из значка, на который нажали (в координатах экрана), и его скругление.
    /// Пока задано — «свёрнутое» положение карточки не плашка, а этот значок
    /// tile — это серая плитка панели: карточка в начале и в конце пути выглядит ею, а не тает
    private(set) var origin: (rect: CGRect, radius: CGFloat, tile: Bool)?
    /// Идёт анимация открытия или сворачивания — повторные нажатия её не ломают
    private(set) var busy = false
    /// Номер перехода: завершение старой анимации не трогает то, что открыли поверх
    private var gen = 0

    /// Сайтов больше не держим: каждый — живая страница в памяти. Файлы лёгкие, их можно больше
    private let siteLimit = 4
    private let totalLimit = 8
    private let motion = MiniMotion.shared

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var under: SiteTab? { tabs.first { $0.id == underID } }
    /// Что в плашке: свёрнутые и окно, которое в неё уже садится. Последнее — сверху, его название на плашке
    var dockTabs: [SiteTab] {
        tabs.filter { $0.id != underID && ($0.id != activeID || $0.id == landingID) }
    }

    private init() {
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            if UserDefaults.standard.bool(forKey: "lockFiles"), self.tabs.contains(where: { $0.isFile }) {
                self.filesLocked = true
            }
            // iOS может выгрузить приложение в фоне — открытые вкладки переживут это
            self.persist()
        }
        restoreSaved()
    }

    // MARK: вкладки переживают перезапуск приложения

    private struct SavedTab: Codable {
        var resource: Resource
        /// Файл — путь внутри папки приложения (сама папка после обновлений меняется)
        var file: String?
        /// Сайт — открытая страница и прокрутка
        var page: String?
        var x: Double?
        var y: Double?
    }

    private static let savedKey = "sitetabs.saved.v1"
    private static let savedAtKey = "sitetabs.saved.at"

    private static var homePath: String { URL(fileURLWithPath: NSHomeDirectory()).resolvingSymlinksInPath().path }

    private func persist() {
        let home = Self.homePath
        let list: [SavedTab] = tabs.compactMap { t in
            if let f = t.file {
                let p = f.url.resolvingSymlinksInPath().path
                guard p.hasPrefix(home + "/") else { return nil }
                return SavedTab(resource: t.resource, file: String(p.dropFirst(home.count + 1)))
            }
            var s = SavedTab(resource: t.resource)
            if let m = t.loadedModel, let u = m.placeToKeep.url {
                let place = m.placeToKeep.offset
                s.page = u.absoluteString
                s.x = Double(place.x)
                s.y = Double(place.y)
            } else if let r = t.restore {
                s.page = r.url.absoluteString
                s.x = Double(r.offset.x)
                s.y = Double(r.offset.y)
            }
            return s
        }
        let d = UserDefaults.standard
        d.set(try? JSONEncoder().encode(list), forKey: Self.savedKey)
        d.set(Date().timeIntervalSince1970, forKey: Self.savedAtKey)
    }

    /// При запуске — свёрнутыми в плашку, как их оставили (если с тех пор прошло меньше суток)
    private func restoreSaved() {
        let d = UserDefaults.standard
        guard let raw = d.data(forKey: Self.savedKey),
              let list = try? JSONDecoder().decode([SavedTab].self, from: raw),
              Date().timeIntervalSince1970 - d.double(forKey: Self.savedAtKey) < 24 * 3600 else { return }
        let home = URL(fileURLWithPath: Self.homePath)
        var out: [SiteTab] = []
        for s in list {
            if let f = s.file {
                let url = home.appendingPathComponent(f)
                guard FileManager.default.fileExists(atPath: url.path) else { continue }
                let t = SiteTab(file: url)
                t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
                out.append(t)
            } else {
                let t = SiteTab(resource: s.resource)
                if let p = s.page.flatMap(URL.init(string:)) {
                    t.restore = (p, CGPoint(x: s.x ?? 0, y: s.y ?? 0))
                }
                out.append(t)
            }
        }
        tabs = out
        if d.bool(forKey: "lockFiles"), out.contains(where: { $0.isFile }) { filesLocked = true }
    }

    // MARK: открыть

    /// origin — метка плитки, на которую нажали (OriginProbe): карточка вырастает прямо из неё
    /// (radius — её скругление), а закрытая садится обратно
    func open(_ r: Resource, origin key: String? = nil, radius: CGFloat = 15) {
        let start = SiteOrigins.rect(key).map { ($0, radius) }
        let tiled = key.map(Self.isTile) ?? false
        let t = tabs.first(where: { !$0.isFile && $0.resource.url == r.url }) ?? SiteTab(resource: r)
        if let key {
            t.originKey = key
            t.originRadius = radius
        }
        present(t, isNew: !tabs.contains(where: { $0.id == t.id }), from: start, tile: tiled)
    }

    /// Плитки панели на главной (у кнопок панели над вкладками плиток нет — там карточка просто тает)
    private static func isTile(_ key: String) -> Bool {
        key.hasPrefix("top:") || key.hasPrefix("dock:") || key.hasPrefix("lib:")
    }

    /// Файл карточкой поверх приложения — как сайт
    func openFile(_ url: URL) {
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            present(t, isNew: false)
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        present(t, isNew: true)
    }

    /// Файл сразу в свёрнутые (из окна просмотра, открытого поверх другого окна)
    func addMinimized(file url: URL) {
        Haptics.tap()
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            guard t.id != activeID else { return }
            withAnimation(MiniAnim.dock) { tabs = reordered(tabs, putting: t) }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        var list = tabs
        list.append(t)
        list = trimmed(reordered(list, putting: t), keep: [t.id])
        withAnimation(MiniAnim.dock) { tabs = list }
        pulse(t.id)
    }

    /// Карточка выезжает снизу. Если уже развёрнута другая — новая накрывает её, а та уходит в свёрнутые
    private func present(_ t: SiteTab, isNew: Bool, from start: (CGRect, CGFloat)? = nil, tile: Bool = false) {
        Haptics.tap()
        if t.id == activeID {
            if motion.hidden > 0 && !busy { motion.animate(to: .init(), response: 0.36) }
            return
        }
        let g = bump()
        busy = true
        let previous = active
        if let previous { takeSnapshot(previous) }

        var list = tabs
        list.removeAll { $0.id == t.id }
        list.append(t)
        var keep: Set<UUID> = [t.id]
        if let p = previous?.id { keep.insert(p) }
        list = trimmed(list, keep: keep)

        // из значка — карточка вырастает прямо из него; иначе прошлая остаётся на месте, новая выезжает снизу
        let grow = start != nil && previous == nil
        origin = grow ? start.map { (rect: $0.0, radius: $0.1, tile: tile) } : nil
        motion.detach()
        motion.set(grow ? .init(collapse: 1) : .init(slide: 1))
        withAnimation(MiniAnim.dock) {
            tabs = list
            underID = previous?.id
            activeID = t.id
            landingID = nil
            showSwitcher = false
            switcherLeaving = false
        }
        // с едва заметным перелётом — живее, чем ровная остановка
        motion.animate(to: .init(), response: grow ? 0.36 : 0.42, damping: grow ? 0.9 : 0.88) {
            guard g == self.gen else { return }
            self.origin = nil
            self.busy = false
            if self.underID != nil { self.noAnimation { self.underID = nil } }
        }
    }

    // MARK: свернуть / развернуть

    /// Развернуть свёрнутую: из плашки окно вырастает прямо с её места, из стопки — уже стоит на месте
    func restore(_ t: SiteTab, from entry: Entry) {
        if entry == .bottom {
            present(t, isNew: false)
            return
        }
        guard tabs.contains(where: { $0.id == t.id }) else { return }
        if entry == .bar {
            guard !busy else { return }
            guard activeID == nil else {
                present(t, isNew: false)
                return
            }
            Haptics.tap()
            let g = bump()
            busy = true
            origin = nil
            motion.detach()
            motion.set(.init(collapse: 1))
            // окно встаёт ровно на место плашки и вырастает из неё, а плашка сразу отпускает его:
            // значок уезжает, наверх выходит следующее окно (или плашка прячется, если окно было одно)
            noAnimation {
                underID = nil
                landingID = nil
            }
            withAnimation(MiniAnim.dock) {
                activeID = t.id
                tabs = reordered(tabs, putting: t, onTop: true)
            }
            motion.animate(to: .init(), response: 0.44, damping: 0.86) {
                if g == self.gen { self.busy = false }
            }
            return
        }
        // из стопки: карточка уже стоит на месте — живая страница встаёт под стопку
        let g = bump()
        busy = true
        motion.detach()
        motion.set(.init())
        noAnimation {
            tabs = reordered(tabs, putting: t, onTop: true)
            underID = nil
            landingID = nil
            activeID = t.id
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.noAnimation {
                self.showSwitcher = false
                self.switcherLeaving = false
            }
            if g == self.gen { self.busy = false }
        }
    }

    /// Карточка сжимается и садится в плашку — с того места, где её отпустил палец, и с его скоростью.
    /// Когда она почти села, плашка уже показывает её и подпрыгивает, а карточка тает поверх
    @discardableResult
    func minimize(velocity: CGFloat = 0) -> Bool {
        guard let t = active, !busy else { return false }
        origin = nil
        Haptics.tap()
        let g = bump()
        busy = true
        motion.live?.freezeLive()
        motion.animate(to: .init(collapse: 1), response: 0.46, damping: 0.92, velocity: .init(collapse: velocity)) {
            guard g == self.gen else { return }
            self.land(t)
        }
        arrive(t, gen: g, after: 0.2)
        return true
    }

    /// Окно почти село: плашка принимает его (выскакивает, если была пустой, или подпрыгивает)
    private func arrive(_ t: SiteTab, gen g: Int, after delay: Double) {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            guard g == self.gen, self.activeID == t.id else { return }
            let had = !self.dockTabs.isEmpty
            withAnimation(MiniAnim.dock) { self.landingID = t.id }
            if had { self.pulse(t.id) }
            SiteHaptics.soft()
        }
    }

    /// Окно село и растаяло — карточка уходит, плашка уже показывает его
    private func land(_ t: SiteTab) {
        noAnimation {
            activeID = nil
            underID = nil
            landingID = nil
            barDragging = false
        }
        motion.detach()
        busy = false
    }

    /// Плашка коротко подпрыгивает
    private func pulse(_ id: UUID) {
        landed = id
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            if self.landed == id { self.landed = nil }
        }
    }

    // MARK: плашку тянут вверх — окно растёт под пальцем

    /// Палец пошёл вверх по плашке: окно встаёт на её место, сжатое ровно в плашку
    func beginBarDrag(_ t: SiteTab) -> Bool {
        guard !busy, activeID == nil, tabs.contains(where: { $0.id == t.id }) else { return false }
        Haptics.tap()
        bump()
        busy = true
        origin = nil
        motion.detach()
        motion.set(.init(collapse: 1))
        noAnimation {
            underID = nil
            landingID = nil
            barDragging = true
        }
        withAnimation(MiniAnim.dock) { activeID = t.id }
        return true
    }

    /// Отпустили: развернуть до конца или вернуть обратно в плашку
    func endBarDrag(open: Bool, velocity: CGFloat) {
        guard barDragging, let t = active else { return }
        let g = bump()
        if open {
            withAnimation(MiniAnim.dock) { tabs = reordered(tabs, putting: t, onTop: true) }
            motion.animate(to: .init(), response: 0.42, damping: 0.88, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.noAnimation { self.barDragging = false }
                self.busy = false
            }
        } else {
            motion.animate(to: .init(collapse: 1), response: 0.36, velocity: .init(collapse: velocity)) {
                guard g == self.gen else { return }
                self.land(t)
            }
            arrive(t, gen: g, after: 0.14)
        }
    }

    /// Смахнул плашку вбок — наверх выходит следующее свёрнутое окно (forward — то, что под верхним)
    func cycle(forward: Bool) {
        guard !busy, activeID == nil, tabs.count > 1 else { return }
        Haptics.tap()
        var list = tabs
        if forward {
            let top = list.removeLast()
            list.insert(top, at: 0)
        } else {
            let bottom = list.removeFirst()
            list.append(bottom)
        }
        withAnimation(MiniAnim.dock) { tabs = list }
    }

    /// Стопка всех окон с наклоном назад: вылетает из плашки («▤» на плашке и «Все окна» в меню)
    func openStack() {
        guard !busy, activeID == nil, !tabs.isEmpty else { return }
        Haptics.tap()
        switcherLeaving = false
        withAnimation(MiniAnim.stack) { showSwitcher = true }
    }

    /// Стопка сложилась в плашку
    func hideSwitcher() {
        noAnimation {
            showSwitcher = false
            switcherLeaving = false
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(MiniAnim.quick) { barInline = inline }
    }

    // MARK: закрыть

    func close(_ t: SiteTab) {
        SiteHaptics.rigid()
        guard t.id == activeID else {
            withAnimation(MiniAnim.dock) { remove(t) }
            return
        }
        guard !busy else { return }
        let g = bump()
        busy = true
        motion.live?.freezeLive()
        // открыли из плитки, и она на виду — карточка сжимается и садится обратно в неё
        if let key = t.originKey, let rect = SiteOrigins.rect(key), motion.hidden < 0.01 {
            origin = (rect: rect, radius: t.originRadius, tile: Self.isTile(key))
            motion.animate(to: .init(collapse: 1), response: 0.34, damping: 0.94) {
                guard g == self.gen else { return }
                self.motion.detach()
                self.noAnimation {
                    self.remove(t)
                    self.activeID = nil
                    self.underID = nil
                    self.landingID = nil
                }
                self.origin = nil
                self.busy = false
            }
            return
        }
        // иначе развёрнутая уезжает вниз за край экрана, как лист
        var end = motion.state
        end.slide = 1
        motion.animate(to: end, response: 0.36) {
            guard g == self.gen else { return }
            self.motion.detach()
            withAnimation(.easeOut(duration: 0.2)) {
                self.remove(t)
                self.activeID = nil
                self.underID = nil
                self.landingID = nil
            }
            self.busy = false
        }
    }

    /// haptic: false — стопка уже щёлкнула, когда нажали «Закрыть все»
    func closeAll(haptic: Bool = true) {
        if haptic { SiteHaptics.rigid() }
        bump()
        busy = false
        origin = nil
        motion.detach()
        withAnimation(MiniAnim.stack) {
            tabs = []
            activeID = nil
            underID = nil
            landingID = nil
            barDragging = false
            showSwitcher = false
            switcherLeaving = false
        }
        filesLocked = false
    }

    private func remove(_ t: SiteTab) {
        tabs.removeAll { $0.id == t.id }
        if tabs.isEmpty {
            showSwitcher = false
            switcherLeaving = false
        }
        if !tabs.contains(where: { $0.isFile }) { filesLocked = false }
    }

    // MARK: Face ID для файлов

    func unlockFiles() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            filesLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return }
                Haptics.success()
                withAnimation(.easeInOut(duration: 0.25)) { self.filesLocked = false }
            }
        }
    }

    /// Слой с карточками — в своём окне над всем приложением, поэтому показать можно всегда
    static var canShowOnTop: Bool { true }

    // MARK: служебное

    @discardableResult
    private func bump() -> Int {
        gen += 1
        return gen
    }

    private func noAnimation(_ body: () -> Void) {
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t, body)
    }

    /// Вкладку — в самый верх свёрнутых. Развёрнутая (если есть) остаётся последней:
    /// иначе после сворачивания на плашке оказалось бы не её название
    private func reordered(_ input: [SiteTab], putting t: SiteTab, onTop: Bool = false) -> [SiteTab] {
        var list = input
        list.removeAll { $0.id == t.id }
        if !onTop, let a = activeID, a != t.id, let i = list.firstIndex(where: { $0.id == a }) {
            list.insert(t, at: i)
        } else {
            list.append(t)
        }
        return list
    }

    /// Самые давние вкладки закрываем, чтобы не тратить память
    private func trimmed(_ input: [SiteTab], keep: Set<UUID>) -> [SiteTab] {
        var list = input
        var keep = keep
        if let a = activeID { keep.insert(a) }
        if let u = underID { keep.insert(u) }
        while list.filter({ !$0.isFile }).count > siteLimit,
              let old = list.first(where: { !$0.isFile && !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        while list.count > totalLimit, let old = list.first(where: { !keep.contains($0.id) }) {
            list.removeAll { $0.id == old.id }
        }
        return list
    }

    /// Снять страницу для стопки прямо сейчас (движок зовёт, когда окно начинает сворачиваться)
    func captureSnapshot(_ t: SiteTab) { takeSnapshot(t) }

    private func takeSnapshot(_ t: SiteTab) {
        if let holder = t.file {
            if let img = holder.snapshot() { t.snapshot = img }
            return
        }
        let wv = t.model.webView
        guard wv.window != nil, wv.bounds.width > 1, wv.bounds.height > 1 else { return }
        let config = WKSnapshotConfiguration()
        config.afterScreenUpdates = false
        config.snapshotWidth = NSNumber(value: Double(min(wv.bounds.width, 340)))
        wv.takeSnapshot(with: config) { [weak t, weak wv] image, _ in
            if let image {
                t?.snapshot = image
            } else if let wv, let img = FileLook.render(wv) {
                // запасной путь: WebKit иногда отдаёт пустой снимок, пока страница грузится
                t?.snapshot = img
            }
        }
    }
}

// MARK: - Приложение под карточкой отъезжает назад, как в Telegram

struct SiteBackdrop: ViewModifier {
    // приложение под карточкой не перерисовывается во время жестов:
    // затемнение — слой внутри UIKit-движка карточки
    func body(content: Content) -> some View { content }
}

// MARK: - Шапка мини-приложения

/// Крестик слева, значок и название по центру, справа — что передали (обычно капсула «⌄ ⋯»)
struct MiniHeader<Trailing: View>: View {
    let resource: Resource
    var onClose: (() -> Void)? = nil
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        ZStack {
            HStack(spacing: 8) {
                SiteIcon(resource: resource, size: 22)
                Text(resource.title)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            .padding(.horizontal, 96)
            .accessibilityElement(children: .combine)
            .accessibilityAddTraits(.isHeader)

            HStack(spacing: 0) {
                Button {
                    onClose?()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.primary)
                        .frame(width: 46, height: 46)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")

                Spacer(minLength: 0)
                trailing()
            }
            .padding(.leading, 6)
            .padding(.trailing, 10)
        }
        .frame(height: MiniChrome.header)
        .frame(maxWidth: .infinity)
        .background(MiniChrome.headerColor)
    }
}

/// Капсула справа в шапке, как у мини-приложений Telegram: «свернуть» и «ещё».
/// У плашки свёрнутых та же капсула, только стрелка смотрит вверх, а «ещё» спрятано
struct MiniPill<Items: View>: View {
    /// 0 — карточка развёрнута (⌄ и ⋯), 1 — сжалась в плашку (только ⌃)
    var collapse: CGFloat = 0
    var chevronLabel = "Свернуть"
    var onChevron: (() -> Void)? = nil
    @ViewBuilder var menu: () -> Items

    var body: some View {
        HStack(spacing: 0) {
            if let onChevron {
                Button(action: onChevron) {
                    Image(systemName: "chevron.down")
                        .font(.system(size: 15, weight: .bold))
                        .rotationEffect(.degrees(Double(180 * collapse)))
                        .foregroundStyle(.primary)
                        .frame(width: 38, height: 32)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(chevronLabel)
            }
            Menu {
                menu()
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 38, height: 32)
                    .contentShape(Rectangle())
            }
            .accessibilityLabel("Ещё")
            .frame(width: 38 * max(0, 1 - collapse), alignment: .leading)
            .opacity(Double(max(0, 1 - collapse * 1.6)))
            .clipped()
            .allowsHitTesting(collapse < 0.5)
        }
        .frame(height: 32)
        .background(Color.primary.opacity(0.08), in: Capsule(style: .continuous))
    }
}

/// Меню «⋯» карточки: у сайта — свои пункты, у файла — свои
private struct CardMenu: View {
    let tab: SiteTab

    var body: some View {
        if let f = tab.file?.url {
            FileMenuItems(url: f)
        } else {
            WebMenuItems(model: tab.model, resource: tab.resource)
        }
    }
}

struct FileMenuItems: View {
    let url: URL
    /// В отдельном окне просмотра файл не прячется за Face ID — там это меню всегда полное
    var respectsLock = true
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        Section(FileLook.meta(url)) {
            if respectsLock && tabs.filesLocked {
                Button { tabs.unlockFiles() } label: { Label("Разблокировать", systemImage: "faceid") }
            } else {
                ShareLink(item: url) { Label("Поделиться", systemImage: "square.and.arrow.up") }
                Button { FileLook.copy(url) } label: { Label("Скопировать файл", systemImage: "doc.on.doc") }
                if FileLook.canPrint(url) {
                    Button { FileLook.printFile(url) } label: { Label("Напечатать", systemImage: "printer") }
                }
            }
        }
    }
}

// MARK: - Слой поверх приложения: развёрнутая карточка, плашка свёрнутых, стопка

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под плашкой системная полоса с Sakai и почтой: когда панель сжимается, плашка прячется следом
    var followsBar = false

    var body: some View {
        GeometryReader { geo in
            let dockTop = geo.size.height - MiniDock.lift - bottomExtra - MiniDock.h
            let cards = [tabs.under, tabs.active].compactMap { $0 }
            // стопка складывается — плашка уже встаёт под неё, карточки садятся прямо в неё
            let showDock = (tabs.barDragging || !tabs.dockTabs.isEmpty)
                && (!tabs.showSwitcher || tabs.switcherLeaving)
                && (!tabs.sheetCovering || tabs.barDragging || tabs.active != nil)

            ZStack(alignment: .top) {
                // плашка лежит под развёрнутой карточкой: карточка садится ровно в неё и вырастает из неё
                if showDock {
                    MiniPillBar(width: geo.size.width, travel: max(dockTop - MiniChrome.topGap, 1),
                                tucked: followsBar && tabs.barInline && !tabs.barDragging && tabs.active == nil)
                        // отступом, а не сдвигом: так плашка и сжимается к своему низу, а не к верху экрана
                        .padding(.top, dockTop)
                        .transition(.asymmetric(insertion: .identity,
                                                removal: .scale(scale: 0.82, anchor: .bottom).combined(with: .opacity)))
                        .zIndex(1)
                }

                // одна и та же карточка остаётся тем же видом, когда уходит «под» новую:
                // живая страница не пересоздаётся и не моргает
                ForEach(cards) { t in
                    CardMotor(tab: t, live: t.id == tabs.activeID, dockTop: dockTop)
                        .ignoresSafeArea()
                        .zIndex(t.id == tabs.activeID ? 3 : 2)
                        .transition(.identity)
                }

                if tabs.showSwitcher {
                    StackSwitcherHost(dockTop: dockTop)
                        .ignoresSafeArea()
                        .zIndex(4)
                        .transition(.identity)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
        }
        // клавиатура не двигает карточку и плашку: страница сама прокручивает поле ввода над клавиатурой,
        // а пересчёт всей карточки при каждом показе клавиатуры давал рывок
        .ignoresSafeArea(.keyboard)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }
}

// MARK: - Развёрнутая карточка (UIKit-движок — в конце файла)

/// Содержимое карточки. Входные данные не меняются, пока карточку тянут или сворачивают,
/// поэтому SwiftUI не пересчитывает страницу на каждом кадре
private struct CardBody: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        if tab.isFile {
            FileBody(tab: tab)
        } else {
            WebScreen(resource: tab.resource, model: tab.model, embeddedInset: bottomInset)
        }
    }
}

// MARK: - Карточка файла

private struct FileBody: View {
    let tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared

    var body: some View {
        ZStack {
            if let holder = tab.file {
                FilePreviewBox(holder: holder)
            } else {
                Color(.secondarySystemBackground)
            }
            if tabs.filesLocked {
                FileLockedView()
                    .transition(.opacity)
            }
        }
        .overlay(alignment: .top) { MiniChrome.hairline }
        .animation(.easeInOut(duration: 0.25), value: tabs.filesLocked)
    }
}

private struct FileLockedView: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.regularMaterial)
            VStack(spacing: 14) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.secondary)
                Text("Файл защищён")
                    .font(.headline)
                Button { SiteTabs.shared.unlockFiles() } label: {
                    Label("Открыть по Face ID", systemImage: "faceid")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .padding(.vertical, 12)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear { SiteTabs.shared.unlockFiles() }
    }
}

// MARK: - Свёрнутые: плашка внизу, как в Арктике для Windows

/// Плашка свёрнутых окон: кружки значков внахлёст (свежий — справа и поверх), название верхнего окна,
/// «ещё N» и капсула «⌃ ▤ ✕». Нажал — верхнее окно вырастает из плашки; потянул вверх — растёт прямо
/// под пальцем; смахнул вбок — наверх выходит следующее окно; «▤» — стопка всех окон; долгое нажатие — меню
private struct MiniPillBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let width: CGFloat
    /// Путь от плашки до развёрнутой карточки, точки
    let travel: CGFloat
    /// Панель вкладок сжата прокруткой — плашка спрятана
    var tucked = false
    @State private var shown = false
    @State private var lifting = false
    /// В плашку село окно — она коротко подпрыгивает
    @State private var bounce = false
    /// Плашку тянут вбок или вниз — она едет за пальцем с резинкой
    @State private var shift: CGSize = .zero
    /// Откуда въезжает название нового верхнего окна
    @State private var edge: Edge = .bottom

    var body: some View {
        let list = tabs.dockTabs
        let rect = MiniDock.rect(width: width, top: 0)

        ZStack(alignment: .topLeading) {
            // основа на всю ширину: пока окно тянут вверх, жест не обрывается, даже если плашка опустела
            Color.clear
                .frame(width: width, height: MiniDock.h)
                .contentShape(Rectangle())

            if let top = list.last {
                face(list, top: top)
                    .frame(width: rect.width, height: rect.height)
                    .offset(x: rect.minX)
                    .transition(.opacity)
            }
        }
        .frame(width: width, height: MiniDock.h, alignment: .topLeading)
        .background(
            GeometryReader { g in
                let f = g.frame(in: .global)
                let r = tucked || list.isEmpty ? CGRect.zero : rect.offsetBy(dx: f.minX, dy: f.minY)
                Color.clear
                    .onAppear { tabs.barRect = r }
                    .onChange(of: r) { _, n in tabs.barRect = n }
            }
        )
        .onDisappear { tabs.barRect = .zero }
        .gesture(
            DragGesture(minimumDistance: 8)
                .onChanged { v in dragChanged(v, top: list.last) }
                .onEnded { v in dragEnded(v, count: list.count) }
        )
        .offset(x: shift.width, y: shift.height)
        .scaleEffect(bounce ? 1.06 : 1, anchor: .bottom)
        .scaleEffect(shown && !tucked ? 1 : 0.8, anchor: .bottom)
        .offset(y: tucked ? 28 : 0)
        .opacity(shown && !tucked ? 1 : 0)
        .animation(.spring(response: 0.31, dampingFraction: 0.9), value: tucked)
        .allowsHitTesting(!tucked)
        .onAppear(perform: appear)
        .onChange(of: tabs.landed) { _, id in
            if id != nil { pop() }
        }
    }

    /// Плашка выскакивает снизу с перелётом. Из стопки — чуть позже, когда карточки уже подлетают
    private func appear() {
        let delay = tabs.switcherLeaving ? 0.14 : 0
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            withAnimation(MiniAnim.pill) { shown = true }
        }
    }

    private func pop() {
        withAnimation(.spring(response: 0.16, dampingFraction: 0.5)) { bounce = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.5)) { bounce = false }
        }
    }

    // MARK: вид

    private func face(_ list: [SiteTab], top: SiteTab) -> some View {
        let icons = Array(list.suffix(MiniDock.maxIcons))
        let more = list.count - 1
        return HStack(spacing: 10) {
            // кружки значков внахлёст, как на Windows: свежий — справа и поверх
            HStack(spacing: -11) {
                ForEach(Array(icons.enumerated()), id: \.element.id) { i, t in
                    PillIcon(resource: t.resource)
                        .zIndex(Double(i))
                        .transition(.scale(scale: 0.2).combined(with: .opacity))
                }
            }

            // название верхнего окна: сменилось окно — новое въезжает, старое уезжает
            ZStack(alignment: .leading) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(top.resource.title)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.primary)
                    Text(more > 0 ? "ещё \(more)" : subtitle(top))
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                        .contentTransition(.numericText())
                }
                .lineLimit(1)
                .id(top.id)
                .transition(.push(from: edge))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .clipped()

            HStack(spacing: 0) {
                pillButton("chevron.up", label: "Развернуть") { tabs.restore(top, from: .bar) }
                if more > 0 {
                    pillButton("square.stack.3d.up.fill", label: "Все окна", size: 14) { tabs.openStack() }
                        .transition(.scale(scale: 0.4).combined(with: .opacity))
                }
                pillButton("xmark", label: "Закрыть «\(top.resource.title)»") { tabs.close(top) }
            }
            .background(Color.primary.opacity(0.08), in: Capsule())
        }
        .padding(.leading, 10)
        .padding(.trailing, 8)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .modifier(PillGlass())
        .contentShape(.contextMenuPreview, Capsule())
        .contentShape(Capsule())
        .onTapGesture { tabs.restore(top, from: .bar) }
        .contextMenu { menu(list, top: top) }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Свёрнуто: \(top.resource.title)\(more > 0 ? " и ещё \(more)" : "")")
    }

    private func pillButton(_ icon: String, label: String, size: CGFloat = 15,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: size, weight: .bold))
                .foregroundStyle(.primary)
                .frame(width: 36, height: 34)
                .contentShape(Rectangle())
        }
        .buttonStyle(PressableStyle())
        .accessibilityLabel(label)
    }

    /// Под названием одного окна — что это: «Курсы и задания», адрес сайта или «PDF · 2 МБ»
    private func subtitle(_ t: SiteTab) -> String {
        if !t.resource.subtitle.isEmpty { return t.resource.subtitle }
        return URL(string: t.resource.url)?.host ?? ""
    }

    @ViewBuilder
    private func menu(_ list: [SiteTab], top: SiteTab) -> some View {
        Section("Свёрнуто") {
            ForEach(list.reversed()) { t in
                Button { tabs.restore(t, from: .bar) } label: {
                    Label(t.resource.title, systemImage: t.resource.icon)
                }
            }
        }
        if list.count > 1 {
            Button { tabs.openStack() } label: { Label("Все окна", systemImage: "square.stack.3d.up") }
        }
        Button(role: .destructive) { tabs.close(top) } label: {
            Label("Закрыть «\(top.resource.title)»", systemImage: "xmark")
        }
        if list.count > 1 {
            Button(role: .destructive) { tabs.closeAll() } label: {
                Label("Закрыть все", systemImage: "xmark.circle")
            }
        }
    }

    // MARK: жесты

    private func collapse(_ dy: CGFloat) -> CGFloat { 1 - min(1, max(0, -dy / travel)) }

    private func rubber(_ v: CGFloat, _ power: CGFloat) -> CGFloat {
        v < 0 ? -pow(-v, power) : pow(v, power)
    }

    private func dragChanged(_ v: DragGesture.Value, top: SiteTab?) {
        let dx = v.translation.width
        let dy = v.translation.height
        if lifting {
            MiniMotion.shared.set(.init(collapse: collapse(dy)))
            return
        }
        // потянул вверх — верхнее окно вырастает прямо под пальцем
        if dy < -6, abs(dy) > abs(dx), let top, tabs.beginBarDrag(top) {
            lifting = true
            shift = .zero
            MiniMotion.shared.set(.init(collapse: collapse(dy)))
            return
        }
        // вбок и вниз плашка едет за пальцем, с резинкой
        shift = CGSize(width: rubber(dx, 0.72), height: dy > 0 ? rubber(dy, 0.5) : 0)
    }

    private func dragEnded(_ v: DragGesture.Value, count: Int) {
        if lifting {
            lifting = false
            let vel = -v.velocity.height
            let open = -v.predictedEndTranslation.height > travel * 0.3 || vel > 450
            tabs.endBarDrag(open: open && vel > -300, velocity: v.velocity.height / travel)
            return
        }
        let dx = v.translation.width
        let flung = abs(dx) > 44 || abs(v.predictedEndTranslation.width) > 150
        if count > 1, flung, abs(dx) > abs(v.translation.height) {
            // смахнул влево — наверх выходит следующее окно, вправо — предыдущее
            edge = dx < 0 ? .trailing : .leading
            tabs.cycle(forward: dx < 0)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { edge = .bottom }
        }
        withAnimation(.spring(response: 0.32, dampingFraction: 0.6)) { shift = .zero }
    }
}

/// Кружок значка в плашке: символ сайта или файла в цвет темы
private struct PillIcon: View {
    let resource: Resource

    var body: some View {
        Image(systemName: resource.icon)
            .font(.system(size: 13, weight: .bold))
            .foregroundStyle(Color.brand)
            .frame(width: 32, height: 32)
            .background(Circle().fill(SiteTile.fill))
            .background(Circle().fill(MiniChrome.headerColor))
            .overlay(Circle().strokeBorder(MiniChrome.headerColor, lineWidth: 2))
            .accessibilityHidden(true)
    }
}

/// Стекло плашки: на iOS 26 — настоящее жидкое стекло (откликается на касание), раньше — матовое.
/// Плашка на экране одна, поэтому живое стекло здесь не тормозит
private struct PillGlass: ViewModifier {
    @Environment(\.colorScheme) private var scheme

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(), in: Capsule())
        } else {
            frosted(content)
        }
        #else
        frosted(content)
        #endif
    }

    private func frosted(_ content: Content) -> some View {
        content
            .background(Capsule().fill(.regularMaterial)
                            .shadow(color: .black.opacity(0.26), radius: 14, y: 6))
            .overlay(Capsule().strokeBorder(Color.white.opacity(scheme == .dark ? 0.14 : 0.55), lineWidth: 0.6))
    }
}

// MARK: - Стопка открытых вкладок, как в Арктике для Windows

/// Раскладка стопки: старые сверху, свежая — внизу и поверх всех; верх последней — чуть ниже середины экрана.
/// Если карточек много, лишние у верхнего края складываются в тонкую пачку, остальное — прокруткой
private struct StackLayout {
    /// Над карточками — «Открыто: N», «Закрыть все» и подсказка
    static let header: CGFloat = 70

    let count: Int
    let height: CGFloat
    let first: CGFloat
    let last: CGFloat
    let step: CGFloat
    let maxScroll: CGFloat
    let cardHeight: CGFloat
    let scale: CGFloat

    init(count: Int, size: CGSize, safeTop: CGFloat) {
        self.count = count
        height = size.height
        first = safeTop + Self.header
        last = max(first, size.height * 0.53)
        if count > 1 {
            step = min(max((last - first) / CGFloat(count - 1), size.height * 0.13), size.height * 0.45)
        } else {
            step = 0
        }
        maxScroll = max(0, first - (last - step * CGFloat(max(count - 1, 0))))
        cardHeight = max(size.height - safeTop - MiniChrome.topGap, 200)
        scale = size.width > 28 ? (size.width - 28) / size.width : 1
    }

    /// Верх карточки и насколько глубоко она ушла в пачку у верхнего края
    func top(_ i: Int, scroll: CGFloat) -> (y: CGFloat, depth: CGFloat) {
        let raw: CGFloat
        if count <= 1 {
            raw = first + (last - first) * 0.4 + scroll
        } else {
            raw = last - step * CGFloat(count - 1 - i) + scroll
        }
        guard raw < first else { return (raw, 0) }
        let over = min(first - raw, step * 4)
        return (first - over * 0.06, min(over / max(step, 1), 4))
    }

    /// Чем ниже карточка, тем сильнее она наклонена — как в Telegram
    func angle(at y: CGFloat) -> CGFloat {
        min(max(15 + 34 * y / max(height, 1), 12), 40)
    }
}

/// Окно в стопке: шапка и снимок страницы — так же, как окно выглядит развёрнутым
private struct StackCardView: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    var dim: Double = 0
    /// 0…1: капсула «⌄ ⋯» в шапке
    var pill: CGFloat = 1
    @AppStorage("web.light") private var forceLight = true

    var body: some View {
        // скругление — у слоя вокруг (оно разное у карточки и у плашки), здесь только содержимое
        VStack(spacing: 0) {
            MiniHeader(resource: tab.resource) {
                MiniPill(onChevron: {}) { EmptyView() }
                    .opacity(Double(pill))
            }
            preview
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                .overlay(alignment: .top) { MiniChrome.hairline }
        }
        .background(MiniChrome.headerColor)
        .overlay(Color.black.opacity(dim))
    }

    private var locked: Bool { tab.isFile && tabs.filesLocked }

    private var pageColor: Color {
        if tab.isFile { return Color(.secondarySystemBackground) }
        return forceLight ? Color.white : Color(.systemBackground)
    }

    /// Снимок — во всю ширину и прижат к верху, как страница в развёрнутом окне:
    /// в высокой карточке стопки и в сжатой до плашки видна одна и та же верхняя часть
    private var preview: some View {
        pageColor
            .overlay(alignment: .top) {
                if locked {
                    VStack(spacing: 10) {
                        Image(systemName: "lock.fill")
                            .font(.system(size: 30, weight: .semibold))
                        Text("Защищено")
                            .font(.subheadline.weight(.semibold))
                    }
                    .foregroundStyle(.secondary)
                    .padding(.top, 110)
                } else if let img = tab.snapshot {
                    Image(uiImage: img)
                        .resizable()
                        .interpolation(.medium)
                        .aspectRatio(contentMode: .fit)
                        .fixedSize(horizontal: false, vertical: true)
                } else if let thumb = tab.thumb {
                    // первая страница файла, как в просмотрщике: лист с полями
                    Image(uiImage: thumb)
                        .resizable()
                        .interpolation(.medium)
                        .aspectRatio(contentMode: .fit)
                        .fixedSize(horizontal: false, vertical: true)
                        .overlay(Rectangle().strokeBorder(Color.primary.opacity(0.08), lineWidth: 0.5))
                        .padding(.horizontal, 20)
                        .padding(.top, 20)
                } else {
                    SiteIcon(resource: tab.resource, size: 40)
                        .opacity(0.3)
                        .padding(.top, 140)
                }
            }
            .clipped()
    }
}

/// Значок вкладки: плитка в цвет темы, как все остальные значки приложения
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: size * 0.28, style: .continuous)
        Image(systemName: resource.icon)
            .font(.system(size: size * 0.48, weight: .semibold))
            .foregroundStyle(Color.brand)
            .frame(width: size, height: size)
            .background(shape.fill(SiteTile.fill))
            .overlay(shape.strokeBorder(SiteTile.stroke, lineWidth: 0.5))
            .accessibilityHidden(true)
    }
}

/// Плитки сайтов — все в цвет темы (как значки «Инструментов»), без своего цвета у каждого сайта.
/// Так же выглядит карточка в первый миг, когда вырастает из плитки
enum SiteTile {
    static var fill: Color { Color.brand.opacity(0.14) }
    static var stroke: Color { Color.brand.opacity(0.18) }
    static var tintUI: UIColor { UIColor(Color.brand) }
    /// Скругление плитки размера size
    static func radius(_ size: CGFloat) -> CGFloat { size * 0.3 }
}

struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Откуда вырастает карточка: значки кнопок сайтов отмечают себя невидимой меткой,
/// а при нажатии берётся её место на экране. Во время прокрутки ничего не считается
enum SiteOrigins {
    private final class Ref { weak var view: UIView?; init(_ v: UIView) { view = v } }
    private static var refs: [String: Ref] = [:]

    static func register(_ key: String, _ v: UIView) {
        if refs[key]?.view !== v { refs[key] = Ref(v) }
    }

    /// Место значка на экране, если он сейчас виден
    static func rect(_ key: String?) -> CGRect? {
        guard let key, let v = refs[key]?.view, let w = v.window, !v.isHidden, v.alpha > 0.01 else { return nil }
        let r = v.convert(v.bounds, to: nil)
        guard r.width > 4, r.height > 4, w.bounds.intersects(r) else { return nil }
        return r
    }
}

/// Невидимая метка значка — откуда вырастет карточка сайта
struct OriginProbe: UIViewRepresentable {
    let key: String

    func makeUIView(context: Context) -> UIView {
        let v = UIView()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        SiteOrigins.register(key, v)
        return v
    }

    func updateUIView(_ v: UIView, context: Context) {
        SiteOrigins.register(key, v)
    }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками) — карточкой, все сайты одинаково
enum QuickOpen {
    /// origin — метка значка, из которого вырастет карточка (OriginProbe)
    static func open(_ r: Resource, store: ResourceStore, origin: String? = nil, radius: CGFloat = 15) {
        SiteTabs.shared.open(r, origin: origin, radius: radius)
        store.markOpenedSoon(r)
    }

    /// Ссылка из любого места: поверх приложения — карточкой, поверх окна — в этом окне Safari
    static func link(_ u: URL) {
        let r = Resource(title: u.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт",
                         subtitle: "", url: u.absoluteString, icon: "globe", category: "Ссылки")
        SiteTabs.shared.open(r)
    }
}

// MARK: - Развёрнутая карточка: UIKit-движок

/// Содержимое карточки в своём UIHostingController: шапка и страница.
/// Во время переходов SwiftUI его не трогает — двигается только слой вокруг
private struct CardContent: View {
    let tab: SiteTab
    let bottomInset: CGFloat

    var body: some View {
        let t = tab
        VStack(spacing: 0) {
            MiniHeader(resource: t.resource, onClose: { SiteTabs.shared.close(t) }) {
                MiniPill(onChevron: { _ = SiteTabs.shared.minimize() }) {
                    CardMenu(tab: t)
                }
            }
            CardBody(tab: t, bottomInset: bottomInset)
        }
        .background(MiniChrome.headerColor)
        .modifier(AppearanceRoot())
        .tint(Color.brand)
        .pausesAmbient()
    }
}

struct CardMotor: UIViewRepresentable {
    let tab: SiteTab
    let live: Bool
    /// Верх ряда мини-окошек в координатах SiteLayer (от верхней безопасной зоны)
    let dockTop: CGFloat
    @EnvironmentObject private var store: ResourceStore
    @EnvironmentObject private var schedule: ScheduleStore

    private func root(bottomInset: CGFloat) -> AnyView {
        AnyView(CardContent(tab: tab, bottomInset: bottomInset)
            .environmentObject(store)
            .environmentObject(schedule))
    }

    func makeUIView(context: Context) -> CardMotorView {
        let inset = CardMotorView.windowInsets.bottom
        let v = CardMotorView(root: root(bottomInset: inset))
        v.rootInset = inset
        v.tab = tab
        v.dockTopLocal = dockTop
        v.isLive = live
        return v
    }

    func updateUIView(_ v: CardMotorView, context: Context) {
        // содержимое пересобираем, только если что-то в нём правда поменялось:
        // слой обновляется при каждом сворачивании, а страница от этого не должна пересчитываться
        let inset = CardMotorView.windowInsets.bottom
        if inset != v.rootInset {
            v.rootInset = inset
            v.host.rootView = root(bottomInset: inset)
        }
        v.dockTopLocal = dockTop
        v.isLive = live
    }

    static func dismantleUIView(_ v: CardMotorView, coordinator: ()) {
        v.teardown()
    }
}

/// Развёрнутая карточка. Сворачивается в плашку: верх идёт ровно за пальцем, карточка плавно сжимается
/// до ширины плашки и съезжает к ней, от страницы остаётся одна шапка, скругление становится как у плашки —
/// и в самом конце карточка тает, а плашка принимает её. Все переходы — пружины Core Animation
/// на рендер-сервере. Страница на время движения подменяется неподвижной копией, а живая прячется.
final class CardMotorView: UIView, UIGestureRecognizerDelegate {
    let host: UIHostingController<AnyView>
    /// Нижний отступ, с которым собрано содержимое
    var rootInset: CGFloat = 0
    private let dim = UIView()
    private let clip = UIView()
    /// Вся карточка (шапка и страница): уменьшается целиком, как картинка
    private let content = UIView()
    /// Плитка сайта поверх карточки: карточка вырастает из плитки и садится обратно в неё,
    /// в начале и в конце пути она и выглядит этой плиткой
    private let cover = UIView()
    private let coverTint = UIView()
    private let coverGlyph = UIImageView()
    private var pan: UIPanGestureRecognizer!
    private var armed = false
    private var last = MiniMotion.State()
    weak var tab: SiteTab? {
        didSet { coverGlyph.image = tab.flatMap { UIImage(systemName: $0.resource.icon) } }
    }
    /// Неподвижная копия поверх живой страницы, пока карточка в движении
    private var frozen: UIView?
    private var freezeToken = 0
    /// Карточку уже видели развёрнутой — её можно скопировать как есть
    private var wasExpanded = false

    var dockTopLocal: CGFloat = 0 { didSet { if dockTopLocal != oldValue { apply(last) } } }
    var isLive = false {
        didSet {
            guard isLive != oldValue else { return }
            dim.isHidden = !isLive
            pan.isEnabled = isLive
            if isLive {
                MiniMotion.shared.live = self
            } else {
                if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
                halt()
                unfreeze(animated: false)
                apply(.init())
            }
        }
    }

    static var windowInsets: UIEdgeInsets {
        let w = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        return w?.safeAreaInsets ?? .zero
    }

    init(root: AnyView) {
        host = UIHostingController(rootView: root)
        super.init(frame: .zero)
        clipsToBounds = false
        backgroundColor = .clear

        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        dim.isHidden = true
        addSubview(dim)

        clip.clipsToBounds = true
        clip.layer.cornerRadius = MiniChrome.radius
        clip.layer.cornerCurve = .continuous
        clip.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        clip.backgroundColor = MiniChrome.headerUIColor
        addSubview(clip)

        content.backgroundColor = MiniChrome.headerUIColor
        content.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        content.clipsToBounds = true
        clip.addSubview(content)

        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        content.addSubview(host.view)

        cover.backgroundColor = MiniChrome.headerUIColor
        cover.isUserInteractionEnabled = false
        cover.alpha = 0
        coverTint.isUserInteractionEnabled = false
        cover.addSubview(coverTint)
        coverGlyph.contentMode = .center
        cover.addSubview(coverGlyph)
        clip.addSubview(cover)

        pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        pan.isEnabled = false
        clip.addGestureRecognizer(pan)
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: встраивание контроллера — чтобы алерты, меню и «Поделиться» внутри страницы работали

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil else { return }
        if host.parent == nil, let parent = parentController() {
            parent.addChild(host)
            host.didMove(toParent: parent)
        }
        apply(isLive ? MiniMotion.shared.current : .init())
        if isLive { MiniMotion.shared.attached(self) }
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    func teardown() {
        if MiniMotion.shared.live === self { MiniMotion.shared.live = nil }
        freezeToken += 1
        host.willMove(toParent: nil)
        host.view.removeFromSuperview()
        host.removeFromParent()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        apply(last)
    }

    // MARK: геометрия — в координатах окна, как бы SwiftUI ни разместил этот вид

    private struct Geo {
        var origin: CGPoint
        var width: CGFloat
        var screenH: CGFloat
        var top: CGFloat
        var fullH: CGFloat
        /// Плашка, в которую карточка садится
        var slot: CGRect
        /// Сколько проходит верх карточки до плашки — на столько же ведёт палец
        var travel: CGFloat { max(slot.minY - top, 1) }
    }

    private func geometry() -> Geo? {
        guard let w = window else { return nil }
        let ins = w.safeAreaInsets
        let top = ins.top + MiniChrome.topGap
        let width = w.bounds.width
        // карточка вырастает из значка — или сворачивается в плашку
        let slot = SiteTabs.shared.origin?.rect ?? MiniDock.rect(width: width, top: ins.top + dockTopLocal)
        return Geo(origin: convert(CGPoint.zero, to: nil), width: width, screenH: w.bounds.height, top: top,
                   fullH: max(w.bounds.height - top, MiniChrome.header + 1), slot: slot)
    }

    /// Поставить карточку в положение s. animated — внутри блока анимации UIKit:
    /// тогда новые значения становятся целью пружины, которую ведёт рендер-сервер
    func apply(_ s: MiniMotion.State, animated: Bool = false) {
        last = s
        guard let g = geometry() else { return }
        if !animated {
            CATransaction.begin()
            CATransaction.setDisableActions(true)
        }

        let c = min(max(s.collapse, 0), 1)
        // карточка уменьшается целиком, как картинка, до ширины плашки (или значка);
        // видна её верхняя часть высотой с плашку
        let k1 = max(g.slot.width, 1) / max(g.width, 1)
        let k = 1 + (k1 - 1) * c
        let crop = g.fullH + (g.slot.height / k1 - g.fullH) * c
        let slideY = s.slide * (g.fullH + 80)
        // верх — ровно за пальцем, к верху плашки; по горизонтали — к её середине
        let top = g.top + (g.slot.minY - g.top) * c + s.drag + slideY
        let cx = g.width / 2 + (g.slot.midX - g.width / 2) * c
        let full = CGRect(x: 0, y: 0, width: g.width, height: g.fullH)

        UIView.performWithoutAnimation {
            let df = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.width, height: g.screenH)
            if dim.frame != df { dim.frame = df }
            if content.bounds != full { content.bounds = full }
            if host.view.frame != full { host.view.frame = full }
        }
        dim.alpha = isLive ? 0.4 * (1 - min(1, max(c, s.slide))) : 0
        let from = isLive ? SiteTabs.shared.origin : nil
        let tile = from?.tile == true ? from : nil
        // в плашку карточка садится и тает, из плашки — проступает, едва начав расти.
        // Из плитки — сразу видна: сначала это сама плитка, по дороге она проявляется страницей
        clip.alpha = isLive && tile == nil ? Self.pillAlpha(c) : 1
        let r1 = from?.radius ?? MiniDock.radius
        clip.layer.cornerRadius = MiniChrome.radius + (r1 - MiniChrome.radius) * c
        let cb = CGRect(x: 0, y: 0, width: g.width * k, height: max(crop * k, 1))
        clip.bounds = cb
        clip.center = CGPoint(x: cx - g.origin.x, y: top - g.origin.y)
        cover.frame = cb
        // плиткой карточка остаётся только самое начало пути — дальше уже видна сама страница
        cover.alpha = tile == nil ? 0 : min(1, max(0, (c - 0.72) / 0.28))
        coverGlyph.frame = cb
        coverTint.frame = cb
        if let tile {
            let brand = SiteTile.tintUI
            if coverGlyph.tintColor != brand {
                coverGlyph.tintColor = brand
                coverTint.backgroundColor = brand.withAlphaComponent(0.14)
            }
            let pt = max(tile.rect.height * 0.42, 12)
            let cfg = UIImage.SymbolConfiguration(pointSize: pt, weight: .semibold)
            if coverGlyph.preferredSymbolConfiguration != cfg { coverGlyph.preferredSymbolConfiguration = cfg }
        }
        content.center = CGPoint(x: g.width * k / 2, y: 0)
        content.transform = CGAffineTransform(scaleX: k, y: k)

        let atRest = c < 0.001 && s.slide < 0.001 && abs(s.drag) < 0.5
        // пока карточка не развёрнута, страница не принимает нажатия
        host.view.isUserInteractionEnabled = atRest && frozen == nil

        if !animated {
            // карточка появилась сжатой в плашку — под живой шапкой снимок страницы, пока она оживает
            if isLive && c > 0.002 && frozen == nil && !wasExpanded { freezeFromImage(g) }
            if isLive && atRest && frozen == nil { wasExpanded = true }
            CATransaction.commit()
        }
    }

    /// Насколько видна карточка: почти вся дорога — целиком, последние шаги до плашки — тает
    static func pillAlpha(_ c: CGFloat) -> CGFloat { min(1, max(0, (1 - c) / 0.14)) }

    /// Пружина до положения s — дальше кадры считает рендер-сервер
    func animate(to s: MiniMotion.State, response: Double, bounce: Double, velocity: CGFloat) {
        guard window != nil else {
            apply(s)
            return
        }
        let fromAlpha = clip.layer.presentation()?.opacity ?? clip.layer.opacity
        // переход могли позвать изнутри обновления SwiftUI, где анимации UIKit выключены, — включаем на время
        let enabled = UIView.areAnimationsEnabled
        UIView.setAnimationsEnabled(true)
        CATransaction.begin()
        CATransaction.setDisableActions(false)
        UIView.animate(springDuration: response, bounce: bounce, initialSpringVelocity: velocity, delay: 0,
                       options: [.allowUserInteraction, .beginFromCurrentState]) {
            self.apply(s, animated: true)
        }
        CATransaction.commit()
        UIView.setAnimationsEnabled(enabled)
        // прозрачность — не по пружине: та растворила бы карточку с первых кадров. В плашку карточка
        // летит целиком и тает, только когда почти села; из плашки — проступает сразу
        let toAlpha = clip.layer.opacity
        guard abs(toAlpha - fromAlpha) > 0.01 else { return }
        let out = toAlpha < fromAlpha
        let l = clip.layer
        l.removeAnimation(forKey: "opacity")
        let a = CABasicAnimation(keyPath: "opacity")
        a.fromValue = fromAlpha
        a.toValue = toAlpha
        a.duration = out ? 0.16 : 0.12
        if out {
            // палец уже довёл карточку почти до плашки (она начала таять) — тает раньше
            a.beginTime = l.convertTime(CACurrentMediaTime(), from: nil) + response * 0.42 * Double(fromAlpha)
        }
        a.fillMode = .backwards
        a.timingFunction = CAMediaTimingFunction(name: out ? .easeIn : .easeOut)
        l.add(a, forKey: "opacity")
    }

    /// Палец перехватил карточку — анимация останавливается, дальше её ведёт палец
    func halt() {
        clip.layer.removeAllAnimations()
        content.layer.removeAllAnimations()
        dim.layer.removeAllAnimations()
    }

    /// Карточка доехала и развернулась — живая страница возвращается
    func settle() {
        guard isLive else { return }
        unfreeze(animated: true)
        wasExpanded = true
        host.view.isUserInteractionEnabled = true
    }

    // MARK: неподвижная копия на время движения

    /// Копия всей карточки поверх живой; живая через миг прячется (не скрывается, а становится прозрачной —
    /// WebKit продолжает считать страницу видимой и не выкидывает её из памяти)
    func freezeLive() {
        guard frozen == nil, wasExpanded, window != nil,
              let snap = host.view.snapshotView(afterScreenUpdates: false) else { return }
        UIView.performWithoutAnimation {
            snap.frame = host.view.frame
            snap.isUserInteractionEnabled = false
            content.addSubview(snap)
        }
        frozen = snap
        host.view.isUserInteractionEnabled = false
        if let t = tab { SiteTabs.shared.captureSnapshot(t) }
        freezeToken += 1
        let tk = freezeToken
        // копия должна успеть нарисоваться, поэтому живая страница прячется не сразу
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self, weak snap] in
            guard let self, let snap, self.freezeToken == tk, self.frozen === snap else { return }
            self.host.view.alpha = 0
        }
    }

    /// Окно вырастает из плашки: страница — снимком (во всю ширину, прижата к верху),
    /// шапка живая
    private func freezeFromImage(_ g: Geo) {
        guard frozen == nil, let t = tab else { return }
        let page = CGRect(x: 0, y: MiniChrome.header, width: g.width, height: max(g.fullH - MiniChrome.header, 1))
        let box = UIView(frame: page)
        box.clipsToBounds = true
        box.isUserInteractionEnabled = false
        let light = UserDefaults.standard.object(forKey: "web.light") as? Bool ?? true
        box.backgroundColor = t.isFile ? .secondarySystemBackground : (light ? .white : .systemBackground)
        if let img = t.snapshot, img.size.width > 0 {
            let iv = UIImageView(image: img)
            iv.frame = CGRect(x: 0, y: 0, width: page.width, height: page.width * img.size.height / img.size.width)
            box.addSubview(iv)
        } else if let thumb = t.thumb, thumb.size.width > 0 {
            let w = page.width - 40
            let iv = UIImageView(image: thumb)
            iv.frame = CGRect(x: 20, y: 20, width: w, height: w * thumb.size.height / thumb.size.width)
            box.addSubview(iv)
        }
        UIView.performWithoutAnimation { content.addSubview(box) }
        frozen = box
    }

    private func unfreeze(animated: Bool) {
        freezeToken += 1
        host.view.alpha = 1
        guard let f = frozen else { return }
        frozen = nil
        guard animated else {
            f.removeFromSuperview()
            return
        }
        // живая страница проступает из-под копии
        UIView.animate(withDuration: 0.18, delay: 0, options: [.curveEaseOut, .allowUserInteraction]) {
            f.alpha = 0
        } completion: { _ in
            f.removeFromSuperview()
        }
    }

    // нажатия мимо карточки проходят в приложение
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let p = convert(point, to: clip)
        guard clip.point(inside: p, with: event) else { return nil }
        return super.hitTest(point, with: event) ?? clip
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        clip.point(inside: convert(point, to: clip), with: event)
    }

    // MARK: шапку тянут вниз — карточка едет ровно под пальцем

    override func gestureRecognizerShouldBegin(_ g: UIGestureRecognizer) -> Bool {
        guard g === pan else { return super.gestureRecognizerShouldBegin(g) }
        guard isLive, !SiteTabs.shared.busy else { return false }
        let p = pan.location(in: clip)
        let v = pan.velocity(in: clip)
        // за всю шапку, кроме кнопок по краям
        return p.y < MiniChrome.header && p.x > 56 && p.x < clip.bounds.width - 100 && abs(v.y) >= abs(v.x)
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geometry() else { return }
        let motion = MiniMotion.shared
        let y = r.translation(in: self).y
        switch r.state {
        case .began, .changed:
            if r.state == .began { freezeLive() }
            if y >= 0 {
                motion.set(.init(collapse: min(1, y / g.travel)))
            } else {
                motion.set(.init(drag: -pow(-y, 0.6)))
            }
            let nowArmed = y > 120
            if nowArmed != armed {
                armed = nowArmed
                if nowArmed { SiteHaptics.rigid() }
            }
        default:
            armed = false
            let vel = r.velocity(in: self).y
            let far = r.state == .ended && (y > 120 || y + vel * 0.15 > g.travel * 0.5 || vel > 700) && vel > -200
            if !(far && SiteTabs.shared.minimize(velocity: vel / g.travel)) {
                motion.animate(to: .init(), response: 0.36,
                               velocity: .init(collapse: y >= 0 ? vel / g.travel : 0))
            }
        }
    }
}



// MARK: - Стопка на UIKit: каждый кадр рисует Core Animation, SwiftUI не пересчитывается

private final class StackCardState: ObservableObject {
    @Published var pill: CGFloat = 1
}

private struct StackCardContent: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject var st: StackCardState

    var body: some View {
        StackCardView(tab: tab, pill: st.pill)
            .animation(.easeOut(duration: 0.2), value: st.pill)
            .modifier(AppearanceRoot())
    }
}

private final class StackNode {
    let tab: SiteTab
    let st = StackCardState()
    /// Плоская обёртка: наклонённая карточка рисуется внутри неё и не уходит в глубину за фон и соседей
    let wrap = UIView()
    let card = UIView()
    let dim = UIView()
    let host: UIHostingController<AnyView>

    init(tab: SiteTab) {
        self.tab = tab
        host = UIHostingController(rootView: AnyView(StackCardContent(tab: tab, st: st)))
        host.safeAreaRegions = []
        host.view.backgroundColor = .clear
        host.view.autoresizingMask = []
        card.clipsToBounds = true
        card.backgroundColor = .clear
        card.layer.cornerRadius = MiniChrome.radius
        card.layer.cornerCurve = .continuous
        card.layer.anchorPoint = CGPoint(x: 0.5, y: 0)
        card.layer.allowsEdgeAntialiasing = true
        card.isUserInteractionEnabled = false
        card.addSubview(host.view)
        dim.backgroundColor = .black
        dim.alpha = 0
        dim.isUserInteractionEnabled = false
        card.addSubview(dim)
        wrap.isUserInteractionEnabled = false
        wrap.backgroundColor = .clear
        wrap.addSubview(card)
    }
}

struct StackSwitcherHost: UIViewRepresentable {
    /// Верх плашки свёрнутых в координатах SiteLayer
    let dockTop: CGFloat

    func makeUIView(context: Context) -> StackSwitcherView {
        let v = StackSwitcherView()
        v.dockTopLocal = dockTop
        return v
    }

    func updateUIView(_ v: StackSwitcherView, context: Context) {
        v.dockTopLocal = dockTop
    }

    static func dismantleUIView(_ v: StackSwitcherView, coordinator: ()) {
        v.teardown()
    }
}

/// Стопка всех окон, как в Арктике для Windows: сверху «Открыто: N» и «Закрыть все», карточки наклонены назад.
/// Вылетает из плашки веером и складывается обратно в неё. Нажал карточку — она разворачивается,
/// смахнул вбок — закрылась, потянул всё вниз или нажал мимо — стопка садится в плашку
final class StackSwitcherView: UIView, UIGestureRecognizerDelegate {
    var dockTopLocal: CGFloat = 0

    private enum Phase: Equatable { case entering, shown, opening(UUID), leaving, closing }

    private let bg = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterialDark))
    private let shade = UIView()
    /// «Открыто: N», «Закрыть все» и подсказка над карточками
    private let chrome = UIView()
    private let titleLabel = UILabel()
    private let hintLabel = UILabel()
    private let closeAllButton = UIButton(type: .system)
    private var nodes: [StackNode] = []
    private var phase: Phase = .entering
    private var scroll: CGFloat = 0
    private var scrollStart: CGFloat = 0
    private var axis = 0              // 0 — ещё не ясно, 1 — вбок, 2 — вертикально
    private var swipe: StackNode?
    private var swipeX: CGFloat = 0
    private var bag: AnyCancellable?
    private var built = false

    init() {
        super.init(frame: .zero)
        backgroundColor = .clear
        bg.alpha = 0
        bg.isUserInteractionEnabled = false
        addSubview(bg)
        shade.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        shade.isUserInteractionEnabled = false
        bg.contentView.addSubview(shade)
        buildChrome()

        let pan = UIPanGestureRecognizer(target: self, action: #selector(onPan(_:)))
        pan.delegate = self
        addGestureRecognizer(pan)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onTap(_:)))
        tap.delegate = self
        addGestureRecognizer(tap)
        AmbientCoordinator.shared.push(token)
    }

    private let token = UUID()

    required init?(coder: NSCoder) { fatalError() }

    func teardown() {
        bag = nil
        AmbientCoordinator.shared.popLater(token)
        for n in nodes {
            n.host.willMove(toParent: nil)
            n.host.view.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes = []
    }

    // MARK: шапка стопки

    private func buildChrome() {
        chrome.alpha = 0
        chrome.backgroundColor = .clear

        let base = UIFont.systemFont(ofSize: 26, weight: .bold)
        if let rounded = base.fontDescriptor.withDesign(.rounded) {
            titleLabel.font = UIFont(descriptor: rounded, size: 26)
        } else {
            titleLabel.font = base
        }
        titleLabel.textColor = .white
        titleLabel.adjustsFontSizeToFitWidth = true
        titleLabel.minimumScaleFactor = 0.7
        titleLabel.accessibilityTraits = .header
        chrome.addSubview(titleLabel)

        hintLabel.font = .systemFont(ofSize: 13, weight: .medium)
        hintLabel.textColor = UIColor.white.withAlphaComponent(0.6)
        hintLabel.text = "Нажми на карточку, чтобы открыть · смахни в сторону, чтобы закрыть"
        hintLabel.adjustsFontSizeToFitWidth = true
        hintLabel.minimumScaleFactor = 0.75
        chrome.addSubview(hintLabel)

        var cfg = UIButton.Configuration.filled()
        cfg.title = "Закрыть все"
        cfg.baseBackgroundColor = UIColor.white.withAlphaComponent(0.16)
        cfg.baseForegroundColor = .white
        cfg.cornerStyle = .capsule
        cfg.contentInsets = NSDirectionalEdgeInsets(top: 7, leading: 14, bottom: 7, trailing: 14)
        cfg.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { incoming in
            var out = incoming
            out.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            return out
        }
        closeAllButton.configuration = cfg
        closeAllButton.accessibilityLabel = "Закрыть все окна"
        closeAllButton.addAction(UIAction { [weak self] _ in self?.closeAll() }, for: .touchUpInside)
        chrome.addSubview(closeAllButton)
        addSubview(chrome)
    }

    private func layoutChrome(_ g: Geo) {
        let w = g.size.width
        chrome.frame = CGRect(x: -g.origin.x, y: -g.origin.y + g.safeTop + 6, width: w, height: StackLayout.header - 10)
        let bs = closeAllButton.sizeThatFits(CGSize(width: 220, height: 44))
        let bh = max(bs.height, 32)
        closeAllButton.frame = CGRect(x: w - 20 - bs.width, y: 0, width: bs.width, height: bh)
        titleLabel.frame = CGRect(x: 20, y: 0, width: max(closeAllButton.frame.minX - 32, 60), height: bh)
        hintLabel.frame = CGRect(x: 20, y: bh + 4, width: w - 40, height: 18)
        updateTitle()
    }

    private func updateTitle() {
        titleLabel.text = "Открыто: \(nodes.count)"
    }

    // MARK: геометрия в координатах окна

    private struct Geo {
        var origin: CGPoint
        var size: CGSize
        var safeTop: CGFloat
        /// Плашка свёрнутых: из неё стопка вылетает и в неё же складывается
        var pill: CGRect
    }

    private var geo: Geo? {
        guard let w = window else { return nil }
        return Geo(origin: convert(CGPoint.zero, to: nil), size: w.bounds.size, safeTop: w.safeAreaInsets.top,
                   pill: MiniDock.rect(width: w.bounds.width, top: w.safeAreaInsets.top + dockTopLocal))
    }

    private func layout(_ g: Geo) -> StackLayout {
        StackLayout(count: nodes.count, size: g.size, safeTop: g.safeTop)
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        guard window != nil, !built, let g = geo else { return }
        built = true
        bg.frame = CGRect(x: -g.origin.x, y: -g.origin.y, width: g.size.width, height: g.size.height)
        shade.frame = bg.bounds
        let parent = parentController()
        for t in SiteTabs.shared.tabs { add(t, parent: parent, geo: g) }
        // шапка — над карточками: «Закрыть все» всегда под пальцем
        bringSubviewToFront(chrome)
        layoutChrome(g)
        chrome.transform = CGAffineTransform(translationX: 0, y: -14)
        // стопка вылетает из плашки: сначала каждая карточка сжата ровно в плашку
        phase = .entering
        var tr = Transaction()
        tr.disablesAnimations = true
        withTransaction(tr) { pills(1) }
        applyAll(animated: false)
        bag = SiteTabs.shared.$tabs
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] list in self?.sync(list) }
        DispatchQueue.main.async { self.enter() }
    }

    private func parentController() -> UIViewController? {
        var r: UIResponder? = superview
        while let x = r {
            if let vc = x as? UIViewController { return vc }
            r = x.next
        }
        return nil
    }

    private func add(_ t: SiteTab, parent: UIViewController?, geo g: Geo) {
        let n = StackNode(tab: t)
        let h = layout(g).cardHeight
        n.host.view.frame = CGRect(x: 0, y: 0, width: g.size.width, height: h)
        n.dim.frame = n.host.view.frame
        if let parent {
            parent.addChild(n.host)
            n.host.didMove(toParent: parent)
        }
        n.wrap.frame = bounds
        n.wrap.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(n.wrap)
        nodes.append(n)
    }

    /// Вкладки закрыли — карточки съезжаются на освободившееся место
    private func sync(_ list: [SiteTab]) {
        let ids = Set(list.map(\.id))
        let gone = nodes.filter { !ids.contains($0.tab.id) }
        guard !gone.isEmpty else { return }
        for n in gone {
            n.host.willMove(toParent: nil)
            n.wrap.removeFromSuperview()
            n.host.removeFromParent()
        }
        nodes.removeAll { !ids.contains($0.tab.id) }
        updateTitle()
        if swipe.map({ !ids.contains($0.tab.id) }) ?? false { swipe = nil; swipeX = 0 }
        guard !nodes.isEmpty, phase == .shown, let g = geo else { return }
        scroll = min(max(scroll, 0), layout(g).maxScroll)
        animate(0.42, bounce: 0.1) { self.applyAll(animated: false) }
    }

    // MARK: позы

    private struct Pose {
        var y: CGFloat
        var angle: CGFloat
        var scale: CGFloat
        var dim: CGFloat
        var alpha: CGFloat
        var height: CGFloat
        /// Карточка сжата в плашку
        var mini = false
        /// Центр по горизонтали (nil — по центру экрана)
        var x: CGFloat? = nil
    }

    private func pose(_ i: Int, _ n: StackNode, _ g: Geo, _ lay: StackLayout) -> Pose {
        switch phase {
        case .entering, .leaving:
            // каждая карточка сжата ровно в плашку, как свернувшееся окно: от неё видна одна шапка
            return Pose(y: g.pill.minY, angle: 0, scale: MiniDock.scale(g.size.width), dim: 0, alpha: 0,
                        height: MiniDock.crop(g.size.width), mini: true, x: g.pill.midX)
        case .opening(let id):
            if n.tab.id == id {
                return Pose(y: g.safeTop + MiniChrome.topGap, angle: 0, scale: 1, dim: 0, alpha: 1, height: lay.cardHeight)
            }
            let p = lay.top(i, scroll: clampedScroll(lay))
            return Pose(y: p.y + g.size.height * 0.5, angle: lay.angle(at: p.y), scale: lay.scale,
                        dim: 0.3, alpha: 0, height: lay.cardHeight)
        case .closing:
            // «Закрыть все»: карточки уезжают вниз за край и тают
            let p = lay.top(i, scroll: clampedScroll(lay))
            return Pose(y: p.y + g.size.height * 0.7, angle: lay.angle(at: p.y), scale: lay.scale * 0.94,
                        dim: 0.2, alpha: 0, height: lay.cardHeight)
        case .shown:
            let p = lay.top(i, scroll: axis == 2 ? scroll : clampedScroll(lay))
            return Pose(y: p.y, angle: lay.angle(at: p.y), scale: lay.scale * (1 - 0.035 * p.depth),
                        dim: min(0.12 * p.depth, 0.4), alpha: 1, height: lay.cardHeight)
        }
    }

    private func clampedScroll(_ lay: StackLayout) -> CGFloat { min(max(scroll, 0), lay.maxScroll) }

    private func applyAll(animated: Bool) {
        guard let g = geo else { return }
        let lay = layout(g)
        for (i, n) in nodes.enumerated() {
            var p = pose(i, n, g, lay)
            let dx: CGFloat = n === swipe ? swipeX : 0
            p.alpha *= 1 - min(abs(dx) / max(g.size.width, 1), 0.8)
            set(n, p, dx: dx, g: g)
        }
    }

    private func set(_ n: StackNode, _ p: Pose, dx: CGFloat, g: Geo) {
        n.card.bounds = CGRect(x: 0, y: 0, width: g.size.width, height: p.height)
        n.card.center = CGPoint(x: (p.x ?? g.size.width / 2) + dx - g.origin.x, y: p.y - g.origin.y)
        var t = CATransform3DMakeScale(p.scale, p.scale, 1)
        t = CATransform3DConcat(t, CATransform3DMakeRotation(-p.angle * .pi / 180, 1, 0, 0))
        var persp = CATransform3DIdentity
        persp.m34 = -1 / max(g.size.height * 0.8, 1)
        n.card.transform3D = CATransform3DConcat(t, persp)
        n.card.alpha = p.alpha
        n.dim.alpha = p.dim
        // скругление на экране: как у развёрнутой карточки или как у плашки
        n.card.layer.cornerRadius = (p.mini ? MiniDock.radius : MiniChrome.radius) / max(p.scale, 0.05)
    }

    /// Капсула «⌄ ⋯» в шапках: у сжатых в плашку она есть (как у развёрнутого окна), в стопке — нет
    private func pills(_ v: CGFloat) {
        for n in nodes { n.st.pill = v }
    }

    private func animate(_ duration: Double, velocity: CGFloat = 0, bounce: Double = 0, delay: Double = 0,
                         _ body: @escaping () -> Void, completion: (() -> Void)? = nil) {
        UIView.animate(springDuration: duration, bounce: bounce, initialSpringVelocity: velocity, delay: delay,
                       options: [.allowUserInteraction, .beginFromCurrentState], animations: body) { _ in
            completion?()
        }
    }

    /// Прозрачность отдельно от пружины: в плашку карточка летит целиком и тает, только когда почти села
    private func fade(_ n: StackNode, delay: Double, duration: Double) {
        let l = n.card.layer
        let from = l.presentation()?.opacity ?? 1
        l.removeAnimation(forKey: "opacity")
        let a = CABasicAnimation(keyPath: "opacity")
        a.fromValue = from
        a.toValue = l.opacity
        a.duration = duration
        a.beginTime = l.convertTime(CACurrentMediaTime(), from: nil) + delay
        a.fillMode = .backwards
        a.timingFunction = CAMediaTimingFunction(name: .easeIn)
        l.add(a, forKey: "opacity")
    }

    /// Палец поймал карточки посреди анимации — продолжаем с того места, где они сейчас на экране
    private func freeze() {
        for n in nodes {
            guard let pl = n.card.layer.presentation() else { continue }
            n.card.layer.removeAllAnimations()
            n.card.layer.bounds = pl.bounds
            n.card.layer.position = pl.position
            n.card.layer.transform = pl.transform
            n.card.layer.opacity = pl.opacity
        }
    }

    // MARK: появление, раскрытие, уход в плашку

    private func enter() {
        guard phase == .entering else { return }
        phase = .shown
        pills(0)
        guard let g = geo else { return }
        let lay = layout(g)
        animate(0.36) {
            self.bg.alpha = 1
            self.chrome.alpha = 1
            self.chrome.transform = .identity
        }
        for (i, n) in nodes.enumerated() {
            let p = pose(i, n, g, lay)
            // свежая вылетает из плашки первой, остальные — следом, веером, с лёгким перелётом
            animate(0.54, bounce: 0.16, delay: Double(nodes.count - 1 - i) * 0.045) { self.set(n, p, dx: 0, g: g) }
        }
    }

    private func open(_ n: StackNode) {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .opening(n.tab.id)
        n.st.pill = 1
        bringSubviewToFront(n.wrap)
        animate(0.4) {
            self.applyAll(animated: false)
            self.bg.alpha = 0
            self.chrome.alpha = 0
        } completion: {
            SiteTabs.shared.restore(n.tab, from: .stack)
        }
    }

    private func dismiss() {
        guard phase == .shown else { return }
        Haptics.tap()
        phase = .leaving
        swipe = nil
        swipeX = 0
        // плашка уже встаёт под стопку — карточки садятся прямо в неё
        SiteTabs.shared.switcherLeaving = true
        pills(1)
        guard let g = geo else {
            SiteTabs.shared.hideSwitcher()
            return
        }
        let lay = layout(g)
        animate(0.3) {
            self.bg.alpha = 0
            self.chrome.alpha = 0
        }
        let step = 0.03
        for (i, n) in nodes.enumerated() {
            let p = pose(i, n, g, lay)
            // верхние садятся первыми, свежая — последней и поверх
            let delay = Double(i) * step
            animate(0.44, delay: delay) { self.set(n, p, dx: 0, g: g) }
            fade(n, delay: delay + 0.2, duration: 0.14)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.42 + Double(nodes.count) * step) {
            SiteTabs.shared.hideSwitcher()
        }
    }

    /// «Закрыть все»: карточки веером уезжают вниз и тают, потом все окна закрываются
    private func closeAll() {
        guard phase == .shown, let g = geo else { return }
        SiteHaptics.rigid()
        phase = .closing
        swipe = nil
        swipeX = 0
        let lay = layout(g)
        animate(0.32) {
            self.bg.alpha = 0
            self.chrome.alpha = 0
        }
        let step = 0.035
        for (i, n) in nodes.enumerated() {
            let p = pose(i, n, g, lay)
            animate(0.42, delay: Double(nodes.count - 1 - i) * step) { self.set(n, p, dx: 0, g: g) }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.36 + Double(nodes.count) * step) {
            SiteTabs.shared.closeAll(haptic: false)
        }
    }

    private func fly(_ n: StackNode, direction: CGFloat, velocity: CGFloat) {
        guard let g = geo else { return }
        let target = direction * g.size.width * 1.15
        let rel = abs(velocity) / max(abs(target - swipeX), 1)
        SiteHaptics.rigid()
        animate(0.32, velocity: min(rel, 8)) {
            n.card.center.x = g.size.width / 2 + target - g.origin.x
            n.card.alpha = 0
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
        swipe = nil
        swipeX = 0
    }

    private func closeByButton(_ n: StackNode) {
        SiteHaptics.rigid()
        animate(0.3) {
            n.card.alpha = 0
            n.card.transform3D = CATransform3DScale(n.card.transform3D, 0.9, 0.9, 1)
        } completion: {
            SiteTabs.shared.close(n.tab)
        }
    }

    // MARK: жесты

    private func windowPoint(_ r: UIGestureRecognizer) -> CGPoint {
        r.location(in: nil)
    }

    private func cardIndex(at p: CGPoint, lay: StackLayout) -> Int? {
        let sc = clampedScroll(lay)
        var hit: Int?
        for i in 0..<nodes.count where lay.top(i, scroll: sc).y <= p.y { hit = i }
        return hit
    }

    override func gestureRecognizerShouldBegin(_ r: UIGestureRecognizer) -> Bool {
        phase == .shown
    }

    /// «Закрыть все» — обычная кнопка: её нажатие не должно складывать стопку
    func gestureRecognizer(_ g: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        !(touch.view?.isDescendant(of: closeAllButton) ?? false)
    }

    @objc private func onTap(_ r: UITapGestureRecognizer) {
        guard phase == .shown, let g = geo else { return }
        let lay = layout(g)
        let p = windowPoint(r)
        guard let i = cardIndex(at: p, lay: lay) else { dismiss(); return }
        let n = nodes[i]
        let top = lay.top(i, scroll: clampedScroll(lay)).y
        let inset = g.size.width * (1 - lay.scale) / 2
        if p.y - top < MiniChrome.header * lay.scale && p.x < inset + 54 {
            closeByButton(n)
        } else {
            open(n)
        }
    }

    @objc private func onPan(_ r: UIPanGestureRecognizer) {
        guard let g = geo else { return }
        let lay = layout(g)
        let t = r.translation(in: nil)
        let v = r.velocity(in: nil)
        switch r.state {
        case .began:
            guard phase == .shown else { return }
            freeze()
            axis = abs(v.x) > abs(v.y) ? 1 : 2
            scrollStart = clampedScroll(lay)
            if axis == 1, let i = cardIndex(at: windowPoint(r), lay: lay) { swipe = nodes[i] }
        case .changed:
            guard phase == .shown else { return }
            if axis == 1 {
                guard swipe != nil else { return }
                swipeX = t.x
            } else {
                scroll = rubber(scrollStart + t.y, max: lay.maxScroll)
            }
            applyAll(animated: false)
        default:
            guard phase == .shown else { axis = 0; return }
            let wasAxis = axis
            axis = 0
            if wasAxis == 1 {
                if let n = swipe, abs(t.x) > 110 || abs(v.x) > 800 {
                    fly(n, direction: (abs(v.x) > 300 ? v.x : t.x) < 0 ? -1 : 1, velocity: v.x)
                } else {
                    swipe = nil
                    let rel = abs(v.x) / max(abs(swipeX), 1)
                    swipeX = 0
                    animate(0.34, velocity: min(rel, 8), bounce: 0.12) { self.applyAll(animated: false) }
                }
            } else {
                // потянул вниз, когда прокручивать некуда, — стопка складывается обратно в плашку
                if t.y > 130 && scrollStart + t.y > lay.maxScroll + 110 {
                    dismiss()
                    return
                }
                let from = scroll
                let target = min(max(scrollStart + t.y + v.y * 0.22, 0), lay.maxScroll)
                scroll = target
                let rel = abs(v.y) / max(abs(target - from), 1)
                animate(0.5, velocity: min(rel, 6)) { self.applyAll(animated: false) }
            }
        }
    }

    private func rubber(_ v: CGFloat, max m: CGFloat) -> CGFloat {
        if v < 0 { return -pow(-v, 0.7) }
        if v > m { return m + pow(v - m, 0.7) }
        return v
    }
}
