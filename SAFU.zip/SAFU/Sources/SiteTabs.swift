import SwiftUI
import WebKit
import QuickLook
import QuickLookThumbnailing
import LocalAuthentication

// MARK: - Сайты и файлы как мини-приложения в Telegram
//
// Сайт или файл открывается карточкой на весь экран, а приложение под ней чуть отъезжает назад.
// Потянул за ручку вниз — карточка сворачивается в плашку над вкладками и продолжает жить:
// вход, прокрутка, открытая страница PDF — всё на месте. Свёрнутых может быть несколько —
// тогда плашка открывает стопку карточек, как в Telegram.

private enum SiteAnim {
    static let spring = Animation.spring(response: 0.42, dampingFraction: 0.86)
    static let snappy = Animation.spring(response: 0.34, dampingFraction: 0.82)
}

/// Отдельная от Haptics «твёрдая» отдача — щелчок, когда карточку дотянули до сворачивания
private enum SiteHaptics {
    private static let rigidGen: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .rigid)
        g.prepare()
        return g
    }()
    private static var enabled: Bool { UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true }

    static func rigid() {
        guard enabled else { return }
        rigidGen.impactOccurred(intensity: 0.75)
        rigidGen.prepare()
    }
}

// MARK: - Вид файла: значок, цвет, подпись

enum FileLook {
    static func ext(_ url: URL) -> String { url.pathExtension.lowercased() }

    static func icon(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "doc.richtext.fill"
        case "doc", "docx", "rtf", "txt", "odt", "pages", "md": return "doc.text.fill"
        case "xls", "xlsx", "csv", "ods", "numbers": return "tablecells.fill"
        case "ppt", "pptx", "key", "odp": return "rectangle.on.rectangle.angled.fill"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "photo.fill"
        case "mp4", "mov", "m4v": return "play.rectangle.fill"
        case "mp3", "m4a", "wav", "aac": return "waveform"
        case "zip", "rar", "7z": return "archivebox.fill"
        default: return "doc.fill"
        }
    }

    static func color(_ url: URL) -> Color {
        switch ext(url) {
        case "pdf": return Color(red: 0.93, green: 0.27, blue: 0.27)
        case "doc", "docx", "rtf", "odt", "pages": return Color(red: 0.20, green: 0.45, blue: 0.95)
        case "txt", "md": return Color(red: 0.45, green: 0.50, blue: 0.60)
        case "xls", "xlsx", "csv", "ods", "numbers": return Color(red: 0.13, green: 0.65, blue: 0.38)
        case "ppt", "pptx", "key", "odp": return Color(red: 0.97, green: 0.52, blue: 0.16)
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return Color(red: 0.62, green: 0.38, blue: 0.95)
        case "mp4", "mov", "m4v", "mp3", "m4a", "wav", "aac": return Color(red: 0.92, green: 0.30, blue: 0.62)
        default: return Color(red: 0.40, green: 0.48, blue: 0.62)
        }
    }

    static func kind(_ url: URL) -> String {
        switch ext(url) {
        case "pdf": return "PDF"
        case "doc", "docx", "rtf", "odt", "pages": return "Документ"
        case "txt", "md": return "Текст"
        case "xls", "xlsx", "csv", "ods", "numbers": return "Таблица"
        case "ppt", "pptx", "key", "odp": return "Презентация"
        case "jpg", "jpeg", "png", "heic", "gif", "webp", "tiff": return "Фото"
        case "mp4", "mov", "m4v": return "Видео"
        case "mp3", "m4a", "wav", "aac": return "Аудио"
        case "": return "Файл"
        default: return ext(url).uppercased()
        }
    }

    /// «PDF · 2,4 МБ»
    static func meta(_ url: URL) -> String {
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]))?.fileSize ?? 0
        guard size > 0 else { return kind(url) }
        return kind(url) + " · " + ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    /// Снимок без содержимого (QuickLook иногда рисуется в другом процессе и снимается пустым)
    static func isBlank(_ img: UIImage) -> Bool {
        guard let cg = img.cgImage else { return true }
        let w = 24, h = 24
        var px = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return false }
        var lo = [255, 255, 255], hi = [0, 0, 0]
        for i in 0..<(w * h) {
            for c in 0..<3 {
                let v = Int(px[i * 4 + c])
                lo[c] = min(lo[c], v)
                hi[c] = max(hi[c], v)
            }
        }
        return (0..<3).allSatisfy { hi[$0] - lo[$0] < 10 }
    }
}

// MARK: - Просмотр файла, который переживает сворачивание

/// QuickLook живёт в карточке, а не на экране: свернул — и вернулся на ту же страницу
final class FilePreviewHolder: NSObject, QLPreviewControllerDataSource {
    let url: URL

    lazy var controller: QLPreviewController = {
        let c = QLPreviewController()
        c.dataSource = self
        return c
    }()

    init(url: URL) {
        self.url = url
        super.init()
    }

    func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }

    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        url as NSURL
    }

    /// Переносим просмотр в новую карточку (старая может ещё доигрывать исчезновение)
    func attach(to box: UIViewController) {
        let c = controller
        if c.parent === box { return }
        if c.parent != nil {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
        box.addChild(c)
        c.view.frame = box.view.bounds
        c.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        box.view.addSubview(c.view)
        c.didMove(toParent: box)
    }

    /// Снимок той страницы, на которой остановился
    func snapshot() -> UIImage? {
        guard controller.isViewLoaded, let v = controller.view, v.window != nil,
              v.bounds.width > 1, v.bounds.height > 1 else { return nil }
        let renderer = UIGraphicsImageRenderer(bounds: v.bounds)
        let img = renderer.image { _ in _ = v.drawHierarchy(in: v.bounds, afterScreenUpdates: false) }
        return FileLook.isBlank(img) ? nil : img
    }

    /// Первая страница — для карточки в стопке, пока своего снимка нет
    func makeThumbnail(_ done: @escaping (UIImage) -> Void) {
        let req = QLThumbnailGenerator.Request(fileAt: url, size: CGSize(width: 420, height: 620),
                                               scale: 2, representationTypes: .thumbnail)
        QLThumbnailGenerator.shared.generateBestRepresentation(for: req) { rep, _ in
            guard let img = rep?.uiImage else { return }
            DispatchQueue.main.async { done(img) }
        }
    }
}

private struct FilePreviewBox: UIViewControllerRepresentable {
    let holder: FilePreviewHolder

    func makeUIViewController(context: Context) -> UIViewController {
        let box = UIViewController()
        box.view.backgroundColor = .systemBackground
        holder.attach(to: box)
        return box
    }

    func updateUIViewController(_ box: UIViewController, context: Context) {}

    static func dismantleUIViewController(_ box: UIViewController, coordinator: ()) {
        // просмотр уже мог переехать в новую карточку — тогда здесь его нет и трогать нечего
        for c in box.children {
            c.willMove(toParent: nil)
            c.view.removeFromSuperview()
            c.removeFromParent()
        }
    }
}

// MARK: - Вкладка: сайт или файл

final class SiteTab: Identifiable, ObservableObject {
    let id = UUID()
    let resource: Resource
    /// Есть — это файл, нет — сайт
    let file: FilePreviewHolder?
    private var web: WebModel?
    /// Как выглядела вкладка, когда её свернули
    @Published var snapshot: UIImage?
    /// Первая страница файла
    @Published var thumb: UIImage?

    var isFile: Bool { file != nil }
    var preview: UIImage? { snapshot ?? thumb }

    /// Живая страница сайта (у файлов не создаётся — им браузер не нужен)
    var model: WebModel {
        if let web { return web }
        let m = WebModel()
        web = m
        return m
    }

    init(resource: Resource) {
        self.resource = resource
        self.file = nil
    }

    init(file url: URL) {
        self.file = FilePreviewHolder(url: url)
        self.resource = Resource(title: url.deletingPathExtension().lastPathComponent,
                                 subtitle: FileLook.meta(url),
                                 url: url.absoluteString,
                                 icon: FileLook.icon(url),
                                 category: "Файлы")
    }

    func matches(file url: URL) -> Bool {
        guard let f = file?.url else { return false }
        return f.standardizedFileURL.path == url.standardizedFileURL.path
    }
}

/// Насколько карточку уже стянули вниз (0…1) — по нему приложение под ней возвращается на место
final class SiteMotion: ObservableObject {
    static let shared = SiteMotion()
    @Published var drag: CGFloat = 0
}

final class SiteTabs: ObservableObject {
    static let shared = SiteTabs()
    /// Открытые сайты и файлы, последний — самый свежий
    @Published private(set) var tabs: [SiteTab] = []
    /// Развёрнутая сейчас вкладка (nil — все свёрнуты)
    @Published var activeID: UUID?
    @Published var showSwitcher = false
    /// Старый режим «настоящим Safari» (сейчас все сайты, и почта тоже, открываются карточкой)
    @Published var safari: SafariLink?
    /// Панель вкладок сжалась при прокрутке (iOS 26): полоса с Sakai и почтой встала в один ряд
    /// с кружком вкладок — плашка свёрнутых опускается следом, без пустого места
    @Published var barInline = false
    /// Файлы закрыты Face ID (включено «Файлы по Face ID», и приложение уходило в фон)
    @Published var filesLocked = false
    /// Вкладку открыли из стопки — она не выезжает снизу, а «вырастает» из карточки
    var openedFromStack = false

    /// Сайтов больше не держим: каждый — живая страница в памяти. Файлы лёгкие, их можно больше
    private let siteLimit = 4
    private let totalLimit = 8

    var active: SiteTab? { tabs.first { $0.id == activeID } }
    var minimized: [SiteTab] { tabs.filter { $0.id != activeID } }

    private init() {
        NotificationCenter.default.addObserver(forName: UIApplication.didEnterBackgroundNotification,
                                               object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            if UserDefaults.standard.bool(forKey: "lockFiles"), self.tabs.contains(where: { $0.isFile }) {
                self.filesLocked = true
            }
        }
    }

    // MARK: открыть

    func open(_ r: Resource) {
        Haptics.tap()
        openedFromStack = false
        if let cur = active, cur.resource.url != r.url { takeSnapshot(cur) }
        if let t = tabs.first(where: { !$0.isFile && $0.resource.url == r.url }) {
            bringToFront(t)
            withAnimation(SiteAnim.spring) { showSwitcher = false; activeID = t.id }
            return
        }
        insert(SiteTab(resource: r), activate: true)
    }

    /// Файл карточкой поверх приложения — как сайт
    func openFile(_ url: URL) {
        Haptics.tap()
        openedFromStack = false
        if let cur = active, !cur.matches(file: url) { takeSnapshot(cur) }
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            bringToFront(t)
            withAnimation(SiteAnim.spring) { showSwitcher = false; activeID = t.id }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        insert(t, activate: true)
    }

    /// Файл сразу в свёрнутые (из окна просмотра, открытого поверх другого окна)
    func addMinimized(file url: URL) {
        Haptics.tap()
        if let t = tabs.first(where: { $0.matches(file: url) }) {
            withAnimation(SiteAnim.spring) { bringToFront(t) }
            return
        }
        let t = SiteTab(file: url)
        t.file?.makeThumbnail { [weak t] img in t?.thumb = img }
        insert(t, activate: false)
    }

    private func insert(_ t: SiteTab, activate: Bool) {
        var list = tabs
        list.append(t)
        // самые давние вкладки закрываем, чтобы не тратить память
        while list.filter({ !$0.isFile }).count > siteLimit,
              let old = list.first(where: { !$0.isFile && $0.id != t.id && $0.id != activeID }) {
            list.removeAll { $0.id == old.id }
        }
        while list.count > totalLimit, let old = list.first(where: { $0.id != t.id && $0.id != activeID }) {
            list.removeAll { $0.id == old.id }
        }
        withAnimation(SiteAnim.spring) {
            tabs = list
            if activate {
                showSwitcher = false
                activeID = t.id
            }
        }
    }

    // MARK: свернуть / развернуть

    func restore(_ t: SiteTab, fromStack: Bool = false) {
        Haptics.tap()
        if let cur = active, cur.id != t.id { takeSnapshot(cur) }
        openedFromStack = fromStack
        bringToFront(t)
        withAnimation(SiteAnim.spring) {
            showSwitcher = false
            activeID = t.id
        }
    }

    func minimize() {
        guard let t = active else { return }
        Haptics.tap()
        takeSnapshot(t)
        openedFromStack = false
        withAnimation(SiteAnim.spring) {
            activeID = nil
            SiteMotion.shared.drag = 0
        }
    }

    /// Нажали на плашку: одна вкладка — сразу разворачиваем, несколько — стопка карточек как в Telegram
    func tapBar() {
        let list = minimized
        if list.count > 1 {
            Haptics.tap()
            withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) { showSwitcher = true }
        } else if let t = list.last {
            restore(t)
        }
    }

    func setBarInline(_ inline: Bool) {
        guard barInline != inline else { return }
        withAnimation(SiteAnim.spring) { barInline = inline }
    }

    // MARK: закрыть

    func close(_ t: SiteTab) {
        SiteHaptics.rigid()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs.removeAll { $0.id == t.id }
            if activeID == t.id { activeID = nil }
            if tabs.isEmpty { showSwitcher = false }
            SiteMotion.shared.drag = 0
        }
        if !tabs.contains(where: { $0.isFile }) { filesLocked = false }
    }

    func closeAll() {
        SiteHaptics.rigid()
        withAnimation(.spring(response: 0.4, dampingFraction: 0.86)) {
            tabs = []
            activeID = nil
            showSwitcher = false
        }
        filesLocked = false
    }

    // MARK: Face ID для файлов

    func unlockFiles() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            filesLocked = false
            return
        }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Доступ к твоим файлам") { ok, _ in
            DispatchQueue.main.async {
                guard ok else { return }
                Haptics.success()
                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) { self.filesLocked = false }
            }
        }
    }

    /// Окно поверх приложения (лист, полноэкранное окно) — тогда карточку не будет видно под ним
    static var canShowOnTop: Bool {
        let windows = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
        guard let main = windows.first(where: { $0.windowLevel == .normal && $0.rootViewController != nil }) else { return true }
        return main.rootViewController?.presentedViewController == nil
    }

    // MARK: служебное

    private func bringToFront(_ t: SiteTab) {
        guard let i = tabs.firstIndex(where: { $0.id == t.id }), i != tabs.count - 1 else { return }
        var list = tabs
        list.remove(at: i)
        list.append(t)
        tabs = list
    }

    private func takeSnapshot(_ t: SiteTab) {
        if let holder = t.file {
            if let img = holder.snapshot() { t.snapshot = img }
            return
        }
        let config = WKSnapshotConfiguration()
        config.snapshotWidth = 420
        t.model.webView.takeSnapshot(with: config) { image, _ in
            if let image { t.snapshot = image }
        }
    }
}

// MARK: - Приложение под карточкой отъезжает назад, как в Telegram

/// Чёрные уголки поверх приложения: при уменьшении у него появляются скруглённые углы,
/// без маски и лишней отрисовки всего экрана
private struct CornerCaps: Shape {
    var radius: CGFloat

    func path(in rect: CGRect) -> Path {
        var p = Path(rect)
        p.addRoundedRect(in: rect, cornerSize: CGSize(width: radius, height: radius), style: .continuous)
        return p
    }
}

struct SiteBackdrop: ViewModifier {
    @ObservedObject private var tabs = SiteTabs.shared
    @ObservedObject private var motion = SiteMotion.shared

    func body(content: Content) -> some View {
        let amount: CGFloat = tabs.showSwitcher ? 1 : (tabs.activeID != nil ? 1 - motion.drag : 0)
        let on = amount > 0.001
        content
            .overlay {
                CornerCaps(radius: 40)
                    .fill(Color.black, style: FillStyle(eoFill: true))
                    .ignoresSafeArea()
                    .opacity(on ? 1 : 0)
                    .allowsHitTesting(false)
            }
            .scaleEffect(1 - 0.065 * amount)
            .background {
                Color.black
                    .ignoresSafeArea()
                    .opacity(on ? 1 : 0)
            }
    }
}

// MARK: - Слой поверх приложения: развёрнутая карточка, плашка свёрнутых, стопка

struct SiteLayer: View {
    @ObservedObject private var tabs = SiteTabs.shared
    /// Сколько отступить снизу, чтобы плашка не легла на док с кнопками
    var bottomExtra: CGFloat = 0
    /// Под плашкой системная полоса с Sakai и почтой: когда панель сжимается, плашка опускается следом
    var followsBar = false
    @State private var drag: CGFloat = 0
    @State private var armed = false

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                // затемнение под карточкой, пока её тянут
                if tabs.active != nil {
                    Color.black
                        .opacity(0.42 * (1 - progress(geo)))
                        .ignoresSafeArea()
                        .transition(.opacity)
                        .allowsHitTesting(false)
                }

                if tabs.active == nil && !tabs.minimized.isEmpty && !tabs.showSwitcher {
                    MinimizedBar(bottomExtra: bottomExtra, followsBar: followsBar)
                        .transition(.asymmetric(
                            insertion: .move(edge: .bottom).combined(with: .scale(scale: 0.8, anchor: .bottom)).combined(with: .opacity),
                            removal: .scale(scale: 1.04, anchor: .bottom).combined(with: .opacity)))
                }

                if let t = tabs.active {
                    expanded(t, geo: geo)
                        .id(t.id)
                        .transition(tabs.openedFromStack
                                    ? .asymmetric(insertion: .scale(scale: 0.92, anchor: .top).combined(with: .opacity),
                                                  removal: .move(edge: .bottom).combined(with: .scale(scale: 0.9, anchor: .bottom)))
                                    : .asymmetric(insertion: .move(edge: .bottom),
                                                  removal: .move(edge: .bottom).combined(with: .scale(scale: 0.9, anchor: .bottom))))
                }

                if tabs.showSwitcher {
                    SiteSwitcher()
                        .transition(.opacity)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
        }
        .animation(SiteAnim.spring, value: tabs.activeID)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.showSwitcher)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: tabs.tabs.count)
        .fullScreenCover(item: $tabs.safari) { link in
            SafariView(url: link.url).ignoresSafeArea().pausesAmbient()
        }
    }

    private func progress(_ geo: GeometryProxy) -> CGFloat {
        min(1, max(0, drag / max(geo.size.height * 0.5, 1)))
    }

    /// Карточка как мини-приложение в Telegram: скруглённый верх, зазор под статус-баром,
    /// тянуть вниз можно за заголовок
    private func expanded(_ t: SiteTab, geo: GeometryProxy) -> some View {
        let p = progress(geo)
        let top = 14 + 18 * p
        let bottom = 38 * p
        return card(t)
            // снизу карточка доходит до края экрана, а панель остаётся над полоской «домой»
            .safeAreaPadding(.bottom, geo.safeAreaInsets.bottom)
            .background(Color(.systemBackground))
            .clipShape(UnevenRoundedRectangle(topLeadingRadius: top, bottomLeadingRadius: bottom,
                                              bottomTrailingRadius: bottom, topTrailingRadius: top, style: .continuous))
            .overlay(alignment: .top) { dragZone(geo) }
            .padding(.top, 6)
            .ignoresSafeArea(.container, edges: .bottom)
            .scaleEffect(1 - 0.1 * p, anchor: .bottom)
            .offset(y: drag)
            .shadow(color: .black.opacity(0.3), radius: 18, y: -2)
            .pausesAmbient()
    }

    @ViewBuilder
    private func card(_ t: SiteTab) -> some View {
        if t.isFile {
            FileScreen(tab: t,
                       onClose: { SiteTabs.shared.close(t) },
                       onMinimize: { SiteTabs.shared.minimize() })
        } else {
            WebScreen(resource: t.resource, model: t.model,
                      onClose: { SiteTabs.shared.close(t) },
                      onMinimize: { SiteTabs.shared.minimize() })
        }
    }

    /// Ручка и заголовок — за них тянут вниз (кнопки по краям остаются нажимаемыми)
    private func dragZone(_ geo: GeometryProxy) -> some View {
        ZStack(alignment: .top) {
            Capsule()
                .fill(Color.secondary.opacity(armed ? 0.9 : 0.55))
                .frame(width: armed ? 48 : 38, height: 5)
                .padding(.top, 5)
                .animation(SiteAnim.snappy, value: armed)
            HStack(spacing: 0) {
                Color.clear.frame(width: 110)
                Color.clear
                    .contentShape(Rectangle())
                    .gesture(dragGesture(geo))
                Color.clear.frame(width: 110)
            }
            .frame(height: 52)
        }
        .frame(maxWidth: .infinity, alignment: .top)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Свернуть")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { SiteTabs.shared.minimize() }
    }

    private func dragGesture(_ geo: GeometryProxy) -> some Gesture {
        DragGesture(minimumDistance: 4, coordinateSpace: .global)
            .onChanged { v in
                let y = v.translation.height
                // вверх карточка почти не идёт — лёгкое сопротивление, как у резинки
                drag = y >= 0 ? y : -pow(-y, 0.6)
                SiteMotion.shared.drag = progress(geo)
                let nowArmed = y > 110
                if nowArmed != armed {
                    armed = nowArmed
                    SiteHaptics.rigid()
                }
            }
            .onEnded { v in
                let fling = v.predictedEndTranslation.height
                armed = false
                if v.translation.height > 110 || fling > 320 {
                    SiteTabs.shared.minimize()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { drag = 0 }
                } else {
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.78)) {
                        drag = 0
                        SiteMotion.shared.drag = 0
                    }
                }
            }
    }
}

// MARK: - Карточка файла

struct FileScreen: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    let onClose: () -> Void
    let onMinimize: () -> Void

    var body: some View {
        NavigationStack {
            Group {
                if let holder = tab.file {
                    FilePreviewBox(holder: holder)
                        .ignoresSafeArea(edges: .bottom)
                } else {
                    Color(.systemBackground)
                }
            }
            .overlay {
                if tabs.filesLocked {
                    FileLockedView()
                        .transition(.opacity)
                }
            }
            .animation(.easeInOut(duration: 0.25), value: tabs.filesLocked)
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(.ultraThinMaterial, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    HStack(spacing: 14) {
                        Button(action: onClose) {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .semibold))
                        }
                        .accessibilityLabel("Закрыть")
                        Button(action: onMinimize) {
                            Image(systemName: "chevron.down").font(.system(size: 15, weight: .semibold))
                        }
                        .accessibilityLabel("Свернуть")
                    }
                }
                ToolbarItem(placement: .principal) {
                    VStack(spacing: 1) {
                        Text(tab.resource.title)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Text(tab.resource.subtitle)
                            .font(.caption2.weight(.medium))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: 200)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    if let u = tab.file?.url, !tabs.filesLocked {
                        ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                    }
                }
            }
        }
    }
}

private struct FileLockedView: View {
    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial)
            VStack(spacing: 18) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 44, weight: .semibold))
                    .foregroundStyle(brandGradient)
                Text("Файл защищён")
                    .font(.system(.title3, design: .rounded).weight(.bold))
                Button { SiteTabs.shared.unlockFiles() } label: {
                    Label("Разблокировать", systemImage: "faceid")
                        .font(.headline)
                        .foregroundStyle(.primary)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 14)
                        .liveGlass(24)
                }
                .buttonStyle(PressableStyle())
            }
        }
        .onAppear { SiteTabs.shared.unlockFiles() }
    }
}

// MARK: - Стекло для плашки и кнопок слоя

/// Настоящее «жидкое стекло» iOS 26 независимо от стиля карточек — плашка живёт рядом
/// со стеклянной панелью вкладок и должна выглядеть с ней одним целым
private struct SiteGlass<S: InsettableShape>: ViewModifier {
    let shape: S
    var tint: Color = .clear

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(tint).interactive(), in: shape)
        } else {
            fallback(content)
        }
        #else
        fallback(content)
        #endif
    }

    private func fallback(_ content: Content) -> some View {
        content
            .background(.ultraThinMaterial, in: shape)
            .background(tint, in: shape)
            .overlay(shape.strokeBorder(LinearGradient(colors: [Color.white.opacity(0.32), Color.white.opacity(0.06)],
                                                       startPoint: .top, endPoint: .bottom), lineWidth: 0.7))
    }
}

private extension View {
    func siteGlass<S: InsettableShape>(_ shape: S, tint: Color = .clear) -> some View {
        modifier(SiteGlass(shape: shape, tint: tint))
    }
}

// MARK: - Плашка свёрнутых

/// Стеклянная капсула над вкладками (как свёрнутое мини-приложение в Telegram).
/// Нажал: одна вкладка — развернулась, несколько — стопка карточек. Вверх — развернуть, вбок — закрыть
private struct MinimizedBar: View {
    @ObservedObject private var tabs = SiteTabs.shared
    let bottomExtra: CGFloat
    let followsBar: Bool
    @State private var dx: CGFloat = 0
    @State private var dy: CGFloat = 0
    @State private var pop = false

    /// Над полной панелью (вкладки + полоса с кнопками) или над сжатой (всё в один ряд)
    private var lift: CGFloat {
        58 + ((followsBar && tabs.barInline) ? -4 : bottomExtra)
    }

    var body: some View {
        let list = tabs.minimized
        if let top = list.last {
            HStack(spacing: 10) {
                icons(list)

                VStack(alignment: .leading, spacing: 1) {
                    Text(top.resource.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .contentTransition(.opacity)
                    Text(subtitle(list, top))
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .contentTransition(.numericText())
                }
                .id(top.id)
                .transition(.asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity),
                                        removal: .move(edge: .top).combined(with: .opacity)))

                Spacer(minLength: 6)

                if list.count > 1 {
                    Text("\(list.count)")
                        .font(.caption.weight(.bold).monospacedDigit())
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.primary.opacity(0.08), in: Capsule())
                        .contentTransition(.numericText())
                        .accessibilityHidden(true)
                }

                Button {
                    flyAway(top)
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 34, height: 34)
                        .contentShape(Circle())
                }
                .buttonStyle(PressableStyle())
                .accessibilityLabel("Закрыть \(top.resource.title)")
            }
            .padding(.leading, 7)
            .padding(.trailing, 5)
            .frame(height: 50)
            .clipped()
            .siteGlass(Capsule(style: .continuous), tint: SiteColor.color(top.resource).opacity(0.12))
            .shadow(color: .black.opacity(0.16), radius: 12, y: 5)
            .contentShape(Capsule(style: .continuous))
            .scaleEffect(pop ? 1.05 : (dy < 0 ? 1 + min(-dy, 60) / 600 : 1))
            .offset(x: dx, y: dy)
            .opacity(1 - Double(min(abs(dx) / 260, 0.85)))
            .animation(SiteAnim.snappy, value: top.id)
            .animation(SiteAnim.snappy, value: list.count)
            .onTapGesture { tabs.tapBar() }
            .gesture(
                DragGesture(minimumDistance: 10)
                    .onChanged { v in
                        if abs(v.translation.width) > abs(v.translation.height) {
                            dx = v.translation.width
                        } else if v.translation.height < 0 {
                            dy = -pow(-v.translation.height, 0.75)          // тянется вверх за пальцем
                        }
                    }
                    .onEnded { v in
                        if v.translation.height < -28 && abs(v.translation.height) > abs(v.translation.width) {
                            withAnimation(SiteAnim.snappy) { dx = 0; dy = 0 }
                            tabs.tapBar()                                            // смахнул вверх — развернуть
                        } else if abs(v.translation.width) > 90 || abs(v.predictedEndTranslation.width) > 260 {
                            flyAway(top, to: v.translation.width < 0 ? -1 : 1)        // смахнул вбок — закрыть
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.7)) { dx = 0; dy = 0 }
                        }
                    }
            )
            .onChange(of: list.count) { _ in bounce() }
            .onAppear { bounce() }
            .accessibilityAction(named: Text(list.count > 1 ? "Показать все свёрнутые" : "Развернуть")) { tabs.tapBar() }
            .padding(.horizontal, 16)
            .padding(.bottom, lift)
        }
    }

    private func bounce() {
        withAnimation(.spring(response: 0.22, dampingFraction: 0.5)) { pop = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) {
            withAnimation(.spring(response: 0.38, dampingFraction: 0.62)) { pop = false }
        }
    }

    private func icons(_ list: [SiteTab]) -> some View {
        let shown = Array(list.suffix(3))
        return ZStack(alignment: .leading) {
            ForEach(Array(shown.enumerated()), id: \.element.id) { i, t in
                SiteIcon(resource: t.resource, size: 36)
                    .clipShape(Circle())
                    .overlay(Circle().strokeBorder(Color.black.opacity(0.25), lineWidth: 1))
                    .offset(x: CGFloat(i) * 12)
                    .transition(.scale(scale: 0.4).combined(with: .opacity))
            }
        }
        .frame(width: 36 + CGFloat(max(shown.count - 1, 0)) * 12, alignment: .leading)
    }

    private func subtitle(_ list: [SiteTab], _ top: SiteTab) -> String {
        if list.count > 1 {
            let n = list.count - 1
            let files = list.filter { $0.isFile }.count
            let sites = list.count - files
            if files == 0 { return "и ещё \(n) \(HWText.plural(n, "сайт", "сайта", "сайтов"))" }
            if sites == 0 { return "и ещё \(n) \(HWText.plural(n, "файл", "файла", "файлов"))" }
            return "\(sites) \(HWText.plural(sites, "сайт", "сайта", "сайтов")) · \(files) \(HWText.plural(files, "файл", "файла", "файлов"))"
        }
        if top.isFile {
            return tabs.filesLocked ? "Защищено · нажми, чтобы открыть" : top.resource.subtitle
        }
        let page = top.model.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !page.isEmpty && page.lowercased() != top.resource.title.lowercased() { return page }
        return "свёрнуто"
    }

    private func flyAway(_ t: SiteTab, to side: CGFloat = 1) {
        withAnimation(.easeOut(duration: 0.2)) { dx = side * 420 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.17) {
            tabs.close(t)
            dx = 0
            dy = 0
        }
    }
}

// MARK: - Стопка открытых вкладок как в Telegram

/// Карточки лежат друг на друге с наклоном назад, у каждой виден заголовок.
/// Прокрутка — верхние карточки уходят в стопку у края экрана. Нажал — карточка выпрямляется
/// и разворачивается; смахнул вбок или крестик — закрыл; нажал мимо — свернул стопку
private struct SiteSwitcher: View {
    @ObservedObject private var tabs = SiteTabs.shared
    @State private var shown = false
    @State private var opening: UUID?
    @State private var leaving = false

    var body: some View {
        GeometryReader { geo in
            let cardH = min(max(geo.size.height * 0.6, 320), 600)
            let step = cardH * 0.46
            let list = tabs.tabs

            ZStack(alignment: .bottom) {
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .overlay(Color.black.opacity(0.45))
                    .ignoresSafeArea()
                    .opacity(shown ? 1 : 0)

                ScrollView(showsIndicators: false) {
                    // старые сверху, свежая — внизу и поверх всех
                    VStack(spacing: step - cardH) {
                        ForEach(Array(list.enumerated()), id: \.element.id) { i, t in
                            StackCard(tab: t,
                                      height: cardH,
                                      enterOffset: geo.size.height * 0.75 + CGFloat(list.count - i) * 40,
                                      shown: shown,
                                      opening: opening,
                                      delay: Double(list.count - 1 - i) * 0.035,
                                      onOpen: { open(t) })
                                .zIndex(Double(i))
                                .transition(.asymmetric(insertion: .identity,
                                                        removal: .opacity.combined(with: .scale(scale: 0.85))))
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.top, 10)
                    .padding(.bottom, 104)
                    .frame(maxWidth: .infinity, minHeight: geo.size.height, alignment: .top)
                    // нажал на пустое место — стопка сворачивается обратно в плашку
                    .background(
                        Color.clear
                            .contentShape(Rectangle())
                            .onTapGesture { dismiss() }
                    )
                }
                .defaultScrollAnchor(.bottom)
                .scrollDisabled(opening != nil)

                bottomBar(count: list.count)
                    .opacity(shown && opening == nil ? 1 : 0)
                    .offset(y: shown ? 0 : 40)
            }
        }
        .onAppear {
            // первый кадр — карточки ещё внизу, со второго они въезжают по одной
            DispatchQueue.main.async { withAnimation(.easeOut(duration: 0.25)) { shown = true } }
        }
        .accessibilityAction(.escape) { dismiss() }
    }

    private func bottomBar(count: Int) -> some View {
        HStack(spacing: 10) {
            Button { tabs.closeAll() } label: {
                Label("Закрыть все", systemImage: "xmark")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.primary)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .siteGlass(Capsule(style: .continuous))
            }
            .buttonStyle(PressableStyle())

            Button { dismiss() } label: {
                Image(systemName: "chevron.down")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.primary)
                    .frame(width: 44, height: 44)
                    .siteGlass(Circle())
            }
            .buttonStyle(PressableStyle())
            .accessibilityLabel("Скрыть")
        }
        .padding(.bottom, 14)
        .animation(.spring(response: 0.4, dampingFraction: 0.86), value: shown)
    }

    private func open(_ t: SiteTab) {
        guard opening == nil, !leaving else { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) { opening = t.id }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            SiteTabs.shared.restore(t, fromStack: true)
        }
    }

    private func dismiss() {
        guard opening == nil, !leaving else { return }
        leaving = true
        Haptics.tap()
        withAnimation(.spring(response: 0.34, dampingFraction: 0.9)) { shown = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.24) {
            withAnimation(.easeOut(duration: 0.15)) { SiteTabs.shared.showSwitcher = false }
        }
    }
}

private struct StackCard: View {
    @ObservedObject var tab: SiteTab
    @ObservedObject private var tabs = SiteTabs.shared
    let height: CGFloat
    let enterOffset: CGFloat
    let shown: Bool
    let opening: UUID?
    let delay: Double
    let onOpen: () -> Void
    @State private var dx: CGFloat = 0

    private static let radius: CGFloat = 26

    var body: some View {
        let isOpening = opening == tab.id
        let othersHide = opening != nil && !isOpening
        let shape = RoundedRectangle(cornerRadius: Self.radius, style: .continuous)

        card
            .frame(maxWidth: .infinity)
            .frame(height: height)
            .clipShape(shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.10), lineWidth: 0.8))
            .background(shape.fill(Color.black).shadow(color: .black.opacity(0.45), radius: 22, y: -10))
            // наклон назад и стопка у верхнего края считаются на видеокарте, без пересчёта раскладки
            .visualEffect { content, proxy in
                let y = proxy.frame(in: .scrollView).minY
                let up: CGFloat = min(max(-y / 280, 0), 1)
                let tilt: Double = isOpening ? 0 : -(14 + 10 * Double(up))
                let scale: CGFloat = isOpening ? 1 : 1 - 0.08 * up
                let lift: CGFloat = y < 0 ? -y * 0.8 : 0
                return content
                    .scaleEffect(scale, anchor: .top)
                    .rotation3DEffect(.degrees(tilt),
                                      axis: (x: 1, y: 0, z: 0),
                                      anchor: .top,
                                      perspective: 0.55)
                    .offset(y: lift)
            }
            .rotationEffect(.degrees(Double(dx) / 40), anchor: .bottom)
            .offset(x: dx, y: shown ? (othersHide ? 220 : 0) : enterOffset)
            .opacity(othersHide ? 0 : 1 - Double(min(abs(dx) / 340, 0.8)))
            .animation(.spring(response: 0.5, dampingFraction: 0.82).delay(shown ? delay : 0), value: shown)
            .contentShape(shape)
            .onTapGesture(perform: onOpen)
            .simultaneousGesture(
                DragGesture(minimumDistance: 18)
                    .onChanged { v in
                        if abs(v.translation.width) > abs(v.translation.height) * 1.2 { dx = v.translation.width }
                    }
                    .onEnded { v in
                        let w = v.translation.width
                        if abs(w) > abs(v.translation.height) && (abs(w) > 110 || abs(v.predictedEndTranslation.width) > 320) {
                            withAnimation(.easeOut(duration: 0.2)) { dx = w < 0 ? -520 : 520 }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) { SiteTabs.shared.close(tab) }
                        } else {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.7)) { dx = 0 }
                        }
                    }
            )
            .accessibilityElement(children: .contain)
            .accessibilityLabel(tab.resource.title)
            .accessibilityAction(named: "Открыть", onOpen)
    }

    private var hidden: Bool { tab.isFile && tabs.filesLocked }

    private var card: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { SiteTabs.shared.close(tab) } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.primary)
                        .frame(width: 36, height: 36)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Закрыть")
                Spacer(minLength: 0)
                SiteIcon(resource: tab.resource, size: 24)
                VStack(alignment: .leading, spacing: 0) {
                    Text(tab.resource.title)
                        .font(.headline)
                        .lineLimit(1)
                    if tab.isFile {
                        Text(tab.resource.subtitle)
                            .font(.caption2.weight(.medium))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
                Color.clear.frame(width: 36, height: 36)
            }
            .padding(.horizontal, 10)
            .frame(height: 54)
            .background(Color(.secondarySystemBackground))

            // превью строго по размеру карточки: картинка обрезается, а не растягивает карточку
            Color(uiColor: tab.isFile ? UIColor.secondarySystemBackground : UIColor.systemBackground)
                .overlay(alignment: .top) {
                    if hidden {
                        VStack(spacing: 10) {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 34, weight: .semibold))
                                .foregroundStyle(.secondary)
                            Text("Защищено")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                        .padding(.top, 90)
                    } else if let img = tab.preview {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFill()
                            .transition(.opacity)
                    } else {
                        SiteIcon(resource: tab.resource, size: 60)
                            .padding(.top, 80)
                    }
                }
                .clipped()
        }
    }
}

/// Значок вкладки: цветная плитка с символом
struct SiteIcon: View {
    let resource: Resource
    var size: CGFloat = 30

    var body: some View {
        let c = SiteColor.color(resource)
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .fill(LinearGradient(colors: [c, c.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous)
                .strokeBorder(Color.white.opacity(0.25), lineWidth: 0.6)
            Image(systemName: resource.icon)
                .font(.system(size: size * 0.48, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
    }
}

/// Свой цвет у каждого сайта и типа файла — узнаётся с полувзгляда
enum SiteColor {
    static func color(_ r: Resource) -> Color {
        if let u = URL(string: r.url), u.isFileURL { return FileLook.color(u) }
        let host = (URL(string: r.url)?.host ?? r.title).lowercased()
        if host.contains("sakai") { return Color(red: 0.20, green: 0.52, blue: 0.98) }
        if host.contains("mail") || host.contains("samoware") || host == "edu.narfu.ru" || r.icon.contains("envelope") {
            return Color(red: 0.98, green: 0.45, blue: 0.22)
        }
        if host.contains("ruz") { return Color(red: 0.16, green: 0.72, blue: 0.48) }
        if host.contains("r7") || r.title.lowercased().contains("р7") { return Color(red: 0.62, green: 0.38, blue: 0.95) }
        if host.contains("modeus") { return Color(red: 0.12, green: 0.70, blue: 0.80) }
        var h: UInt64 = 5381
        for u in host.unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.6, brightness: 0.9)
    }
}


struct SafariLink: Identifiable {
    let url: URL
    var id: String { url.absoluteString }
}

/// Открыть сайт откуда угодно (главная, панель над вкладками) — карточкой, все сайты одинаково
enum QuickOpen {
    static func open(_ r: Resource, store: ResourceStore) {
        store.markOpened(r)
        SiteTabs.shared.open(r)
    }

    /// Ссылка из любого места: поверх приложения — карточкой, поверх окна — в этом окне Safari
    static func link(_ u: URL) {
        let r = Resource(title: u.host?.replacingOccurrences(of: "www.", with: "") ?? "Сайт",
                         subtitle: "", url: u.absoluteString, icon: "globe", category: "Ссылки")
        SiteTabs.shared.open(r)
    }
}
