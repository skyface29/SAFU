import SwiftUI

// MARK: - Режим преподавателя
// В РУЗ САФУ нет отдельной выдачи «расписание преподавателя», поэтому оно собирается из расписаний
// всех групп высшей школы: берём пары, где указан этот преподаватель, и склеиваем одинаковые пары
// разных групп (поток). Дальше всё приложение работает как обычно: главная, «Пары», Live Activity,
// уведомления, дорога — только вместо фамилии преподавателя в паре показаны номера групп.

/// Пометка «Бета»: режим преподавателя ещё в разработке
struct BetaBadge: View {
    var body: some View {
        Text("БЕТА")
            .font(.system(size: 9, weight: .heavy, design: .rounded))
            .tracking(0.6)
            .foregroundStyle(.white)
            .padding(.horizontal, 6)
            .padding(.vertical, 2)
            .background(Color.orange.gradient, in: Capsule())
            .accessibilityLabel("Бета-версия")
    }
}

enum TeacherMode {
    static let betaNote = "Режим преподавателя в разработке: пары собираются из РУЗ по расписаниям групп и могут быть неполными. Сверяйтесь с официальным расписанием."

    static let kindKey = "user.kind"
    static let queryKey = "teacher.query"

    static var isOn: Bool { UserDefaults.standard.string(forKey: kindKey) == "teacher" }
    static var query: String { UserDefaults.standard.string(forKey: queryKey) ?? "" }

    /// «Иванов И.И.», «Иванов Иван», «иванов» → фамилия и первые буквы имени и отчества
    static func parse(_ q: String) -> (surname: String, initials: [Character]) {
        let parts = q.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        guard let surname = parts.first else { return ("", []) }
        let initials = parts.dropFirst().compactMap(\.first)
        return (surname, Array(initials.prefix(2)))
    }

    /// Ведёт ли пару этот человек. В паре может быть несколько преподавателей через запятую
    static func matches(_ teacher: String, _ who: (surname: String, initials: [Character])) -> Bool {
        guard !who.surname.isEmpty else { return false }
        let words = teacher.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        for (i, w) in words.enumerated() where w == who.surname {
            let rest = words.dropFirst(i + 1).prefix(who.initials.count).compactMap(\.first)
            if Array(rest) == who.initials { return true }
        }
        return false
    }

    /// Пары преподавателя по всем группам школы (из общего расписания школы). progress(готово, всего)
    @MainActor
    static func scan(institution: Int, query: String, force: Bool = false,
                     progress: @escaping @MainActor (Int, Int) -> Void) async throws -> (events: [RuzEvent], groups: [String]) {
        let school = SchoolTimetable.shared
        await school.ensure(institution: institution, force: force, progress: progress)
        if school.events.isEmpty, let e = school.error { throw TeacherScanError.failed(e) }
        let merged = merge(school.events(for: query))
        return (merged, Array(Set(merged.flatMap { groups(in: $0.teacher) })).sorted())
    }

    /// Одна и та же пара у нескольких групп (поток) — одна запись, вместо фамилии список групп
    static func merge(_ list: [SchoolEvent]) -> [RuzEvent] {
        var merged: [String: (RuzEvent, Set<String>)] = [:]
        for x in list {
            let key = "\(Int(x.e.start.timeIntervalSince1970))|\(x.e.subject.lowercased())|\(x.e.room)"
            if var m = merged[key] { m.1.insert(x.group); merged[key] = m } else { merged[key] = (x.e, [x.group]) }
        }
        return merged.values.map { (e, gs) -> RuzEvent in
            var r = e
            let list = gs.sorted()
            r.teacher = (list.count == 1 ? "Группа " : "Группы ") + list.joined(separator: ", ")
            return r
        }.sorted { $0.start < $1.start }
    }

    static func groups(in teacherField: String) -> [String] {
        teacherField.replacingOccurrences(of: "Группы ", with: "").replacingOccurrences(of: "Группа ", with: "")
            .components(separatedBy: ", ").filter { !$0.isEmpty && $0.allSatisfy(\.isNumber) }
    }

    /// Группы, у которых преподаватель ведёт пары (из уже загруженного расписания)
    static func myGroups(_ data: ScheduleData) -> [String] {
        Array(Set(data.ruzEvents.flatMap { groups(in: $0.teacher) })).sorted()
    }
}

enum TeacherScanError: LocalizedError {
    case failed(String)
    var errorDescription: String? { if case .failed(let s) = self { return s }; return nil }
}

// MARK: - Расписание всей школы
// Один проход по всем группам всех школ и филиалов САФУ (несколько минут, своя школа — первой),
// дальше — мгновенный поиск любого преподавателя.
// Хранится на телефоне и обновляется не чаще раза в 12 часов.

struct SchoolEvent: Codable, Hashable {
    let e: RuzEvent
    let group: String
}

@MainActor
final class SchoolTimetable: ObservableObject {
    static let shared = SchoolTimetable()

    @Published private(set) var events: [SchoolEvent] = [] { didSet { teacherCache = nil } }
    /// Список преподавателей строится один раз на каждый набор данных, а не на каждую отрисовку
    private var teacherCache: [(name: String, subjects: [String])]?
    @Published private(set) var institution = 0
    @Published private(set) var scannedAt: Date?
    @Published private(set) var progress: Double?
    @Published private(set) var failedGroups = 0
    @Published private(set) var error: String?

    private struct Blob: Codable {
        let institution: Int
        let at: Date
        let events: [SchoolEvent]
        let failed: Int
    }

    private static func fileURL(_ inst: Int) -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("school-\(inst).json")
    }

    var isScanning: Bool { progress != nil }

    func isFresh(_ inst: Int) -> Bool {
        institution == inst && !events.isEmpty && (scannedAt.map { Date().timeIntervalSince($0) < 12 * 3600 } ?? false)
    }

    /// Поднять сохранённое с диска
    func load(_ inst: Int) {
        guard institution != inst || events.isEmpty,
              let raw = try? Data(contentsOf: Self.fileURL(inst)),
              let b = try? JSONDecoder().decode(Blob.self, from: raw) else { return }
        events = b.events
        institution = b.institution
        scannedAt = b.at
        failedGroups = b.failed
    }

    /// Собрать расписание всех групп САФУ: сначала своя школа (её пары показываются сразу),
    /// потом все остальные школы и филиалы — преподаватели часто ведут пары не только в своей школе
    func ensure(institution inst: Int, force: Bool = false, progress report: (@MainActor (Int, Int) -> Void)? = nil) async {
        load(inst)
        if !force && isFresh(inst) { return }
        if isScanning {
            // уже идёт — просто дождёмся
            while isScanning { try? await Task.sleep(nanoseconds: 300_000_000) }
            return
        }
        error = nil
        progress = 0
        defer { progress = nil }

        var schools = await RuzDirectory.allInstitutions()
        schools.removeAll { $0 == inst }
        schools.insert(inst, at: 0)
        var plan: [RuzGroup] = []
        var seenIDs = Set<String>()
        var homeCount = 0
        for (i, school) in schools.enumerated() {
            guard let list = try? await RuzDirectory.groups(institution: school) else { continue }
            for g in list where seenIDs.insert(g.id).inserted { plan.append(g) }
            if i == 0 { homeCount = plan.count }
        }
        guard !plan.isEmpty else {
            error = "Нет связи с РУЗ — не удалось получить список групп"
            return
        }
        report?(0, plan.count)
        var found: [SchoolEvent] = []
        var failed = 0
        var start = 0
        var shownHome = false
        // по 6 групп за раз и повтор при сбое — РУЗ не любит лавину запросов
        while start < plan.count {
            let chunk = Array(plan[start..<min(start + 6, plan.count)])
            let part = await withTaskGroup(of: [SchoolEvent]?.self) { tg -> ([SchoolEvent], Int) in
                for g in chunk { tg.addTask { await Self.fetch(g) } }
                var acc: [SchoolEvent] = []
                var bad = 0
                for await p in tg { if let p { acc += p } else { bad += 1 } }
                return (acc, bad)
            }
            found += part.0
            failed += part.1
            start += chunk.count
            progress = Double(start) / Double(plan.count)
            report?(start, plan.count)
            // своя школа готова — показываем её сразу, остальное догружается
            if !shownHome && start >= homeCount && !found.isEmpty {
                shownHome = true
                events = found
                institution = inst
            }
        }
        guard !found.isEmpty else {
            error = "РУЗ не ответил — попробуй позже"
            return
        }
        events = found
        institution = inst
        scannedAt = Date()
        failedGroups = failed
        let blob = Blob(institution: inst, at: Date(), events: found, failed: failed)
        let url = Self.fileURL(inst)
        Task.detached(priority: .utility) {
            if let raw = try? JSONEncoder().encode(blob) { try? raw.write(to: url, options: .atomic) }
        }
    }

    /// Расписание одной группы; nil — РУЗ не ответил дважды
    nonisolated private static func fetch(_ g: RuzGroup) async -> [SchoolEvent]? {
        guard let url = RuzClient.timetableURL(groupID: g.id) else { return [] }
        for attempt in 0..<2 {
            if let html = try? await RuzClient.fetch(url, session: schoolSession), !html.isEmpty {
                return RuzClient.parseHTML(html).map { SchoolEvent(e: $0, group: g.number) }
            }
            if attempt == 0 { try? await Task.sleep(nanoseconds: 700_000_000) }
        }
        return nil
    }

    func events(for query: String) -> [SchoolEvent] {
        let who = TeacherMode.parse(query)
        return events.filter { TeacherMode.matches($0.e.teacher, who) }
    }

    /// Все преподаватели школы: ФИО → предметы
    func teachers() -> [(name: String, subjects: [String])] {
        if let teacherCache { return teacherCache }
        var map: [String: Set<String>] = [:]
        for x in events {
            for name in x.e.teacher.components(separatedBy: ",") {
                let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
                guard n.count > 3 else { continue }
                map[n, default: []].insert(x.e.subject)
            }
        }
        let list = map.map { ($0.key, $0.value.sorted()) }.sorted { $0.name < $1.name }
        teacherCache = list
        return list
    }
}

private let schoolSession: URLSession = {
    let c = URLSessionConfiguration.ephemeral
    c.timeoutIntervalForRequest = 20
    c.httpMaximumConnectionsPerHost = 4
    return URLSession(configuration: c)
}()

// MARK: - Карточка преподавателя на главной

struct TeacherHomeCard: View {
    let data: ScheduleData
    let onTool: (Tool) -> Void
    let onRefresh: () -> Void
    var syncing = false

    private var today: [LessonSlot] {
        let cal = Calendar.current
        return ScheduleQuery.slots(data, days: 1).filter { cal.isDateInToday($0.start) }
    }
    private var week: Int { ScheduleQuery.slots(data, days: 7).count }
    private var groups: [String] { TeacherMode.myGroups(data) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Преподаватель", systemImage: "person.crop.rectangle.stack.fill")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Color.brand)
                    .textCase(.uppercase)
                BetaBadge()
                Spacer()
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.caption.weight(.bold))
                        .rotationEffect(.degrees(syncing ? 360 : 0))
                        .animation(syncing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: syncing)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                stat("\(today.count)", "сегодня")
                stat("\(week)", "за 7 дней")
                stat("\(groups.count)", "групп")
            }
            if !groups.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(groups, id: \.self) { g in
                            Text(g)
                                .font(.caption.weight(.semibold).monospacedDigit())
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.brand.opacity(0.12), in: Capsule())
                        }
                    }
                }
            }
            Text("В разработке: пары из РУЗ могут быть неполными")
                .font(.caption2)
                .foregroundStyle(.secondary)
            HStack(spacing: 8) {
                action("Посещаемость", "person.crop.circle.badge.checkmark") { onTool(.attendance) }
                action("Рассылка", "megaphone.fill") { onTool(.broadcast) }
            }
        }
        .padding(16)
        .glass(24)
    }

    private func stat(_ value: String, _ title: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value).font(.system(.title2, design: .rounded).weight(.heavy)).contentTransition(.numericText())
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func action(_ title: String, _ icon: String, _ run: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            run()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PressableStyle())
    }
}

// MARK: - Все школы и филиалы из РУЗ

extension RuzDirectory {
    /// Номера всех школ и филиалов с главной страницы РУЗ (кешируется на неделю)
    static func allInstitutions() async -> [Int] {
        let d = UserDefaults.standard
        if let at = d.object(forKey: "ruz.institutions.at") as? Date, Date().timeIntervalSince(at) < 7 * 86_400,
           let list = d.array(forKey: "ruz.institutions") as? [Int], !list.isEmpty {
            return list
        }
        var ids = RuzClient.institutions.map(\.0)
        if let url = URL(string: RuzClient.base), let html = try? await RuzClient.fetch(url) {
            for m in html.rx("institution=(\\d+)") {
                if let n = Int(html.sub(m.range(at: 1))), !ids.contains(n) { ids.append(n) }
            }
            d.set(ids, forKey: "ruz.institutions")
            d.set(Date(), forKey: "ruz.institutions.at")
        }
        return ids
    }
}
