import SwiftUI

// MARK: - Режим преподавателя
// В РУЗ САФУ нет отдельной выдачи «расписание преподавателя», поэтому оно собирается из расписаний
// всех групп высшей школы: берём пары, где указан этот преподаватель, и склеиваем одинаковые пары
// разных групп (поток). Дальше всё приложение работает как обычно: главная, «Пары», Live Activity,
// уведомления, дорога — только вместо фамилии преподавателя в паре показаны номера групп.

enum TeacherMode {
    static let kindKey = "user.kind"
    static let queryKey = "teacher.query"

    static var isOn: Bool { UserDefaults.standard.string(forKey: kindKey) == "teacher" }
    static var query: String { UserDefaults.standard.string(forKey: queryKey) ?? "" }

    /// «Иванов И.И.», «Иванов Иван», «иванов» → фамилия и первые буквы имени и отчества
    static func parse(_ q: String) -> (surname: String, initials: [Character]) {
        let parts = q.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        guard let surname = parts.first else { return ("", []) }
        let initials = parts.dropFirst().compactMap(\.first)
        return (surname, Array(initials.prefix(2)))
    }

    /// Ведёт ли пару этот человек. В паре может быть несколько преподавателей через запятую
    static func matches(_ teacher: String, _ who: (surname: String, initials: [Character])) -> Bool {
        guard !who.surname.isEmpty else { return false }
        let words = teacher.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        for (i, w) in words.enumerated() where w == who.surname {
            let rest = words.dropFirst(i + 1).prefix(who.initials.count).compactMap(\.first)
            if Array(rest) == who.initials { return true }
        }
        return false
    }

    /// Пары преподавателя по всем группам школы (из общего расписания школы). progress(готово, всего)
    @MainActor
    static func scan(institution: Int, query: String, force: Bool = false,
                     progress: @escaping @MainActor (Int, Int) -> Void) async throws -> (events: [RuzEvent], groups: [String]) {
        let school = SchoolTimetable.shared
        await school.ensure(institution: institution, force: force, progress: progress)
        if school.events.isEmpty, let e = school.error { throw TeacherScanError.failed(e) }
        let merged = merge(school.events(for: query))
        return (merged, Array(Set(merged.flatMap { groups(in: $0.teacher) })).sorted())
    }

    /// Одна и та же пара у нескольких групп (поток) — одна запись, вместо фамилии список групп
    static func merge(_ list: [SchoolEvent]) -> [RuzEvent] {
        var merged: [String: (RuzEvent, Set<String>)] = [:]
        for x in list {
            let key = "\(Int(x.e.start.timeIntervalSince1970))|\(x.e.subject.lowercased())|\(x.e.room)"
            if var m = merged[key] { m.1.insert(x.group); merged[key] = m } else { merged[key] = (x.e, [x.group]) }
        }
        return merged.values.map { (e, gs) -> RuzEvent in
            var r = e
            let list = gs.sorted()
            r.teacher = (list.count == 1 ? "Группа " : "Группы ") + list.joined(separator: ", ")
            return r
        }.sorted { $0.start < $1.start }
    }

    static func groups(in teacherField: String) -> [String] {
        teacherField.replacingOccurrences(of: "Группы ", with: "").replacingOccurrences(of: "Группа ", with: "")
            .components(separatedBy: ", ").filter { !$0.isEmpty && $0.allSatisfy(\.isNumber) }
    }

    /// Группы, у которых преподаватель ведёт пары (из уже загруженного расписания)
    static func myGroups(_ data: ScheduleData) -> [String] {
        Array(Set(data.ruzEvents.flatMap { groups(in: $0.teacher) })).sorted()
    }
}

enum TeacherScanError: LocalizedError {
    case failed(String)
    var errorDescription: String? { if case .failed(let s) = self { return s }; return nil }
}

// MARK: - Расписание всей школы
// Один проход по всем группам школы (~1 минута), дальше — мгновенный поиск любого преподавателя.
// Хранится на телефоне и обновляется не чаще раза в 12 часов.

struct SchoolEvent: Codable, Hashable {
    let e: RuzEvent
    let group: String
}

@MainActor
final class SchoolTimetable: ObservableObject {
    static let shared = SchoolTimetable()

    @Published private(set) var events: [SchoolEvent] = []
    @Published private(set) var institution = 0
    @Published private(set) var scannedAt: Date?
    @Published private(set) var progress: Double?
    @Published private(set) var failedGroups = 0
    @Published private(set) var error: String?

    private struct Blob: Codable {
        let institution: Int
        let at: Date
        let events: [SchoolEvent]
        let failed: Int
    }

    private static func fileURL(_ inst: Int) -> URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent("school-\(inst).json")
    }

    var isScanning: Bool { progress != nil }

    func isFresh(_ inst: Int) -> Bool {
        institution == inst && !events.isEmpty && (scannedAt.map { Date().timeIntervalSince($0) < 12 * 3600 } ?? false)
    }

    /// Поднять сохранённое с диска
    func load(_ inst: Int) {
        guard institution != inst || events.isEmpty,
              let raw = try? Data(contentsOf: Self.fileURL(inst)),
              let b = try? JSONDecoder().decode(Blob.self, from: raw) else { return }
        events = b.events
        institution = b.institution
        scannedAt = b.at
        failedGroups = b.failed
    }

    func ensure(institution inst: Int, force: Bool = false, progress report: (@MainActor (Int, Int) -> Void)? = nil) async {
        load(inst)
        if !force && isFresh(inst) { return }
        if isScanning {
            // уже идёт — просто дождёмся
            while isScanning { try? await Task.sleep(nanoseconds: 300_000_000) }
            return
        }
        error = nil
        progress = 0
        defer { progress = nil }

        guard let groups = try? await RuzDirectory.groups(institution: inst), !groups.isEmpty else {
            error = "Нет связи с РУЗ — не удалось получить список групп"
            return
        }
        report?(0, groups.count)
        var found: [SchoolEvent] = []
        var failed = 0
        var start = 0
        // по 4 группы за раз и повтор при сбое — РУЗ не любит лавину запросов
        while start < groups.count {
            let chunk = Array(groups[start..<min(start + 4, groups.count)])
            let part = await withTaskGroup(of: [SchoolEvent]?.self) { tg -> ([SchoolEvent], Int) in
                for g in chunk { tg.addTask { await Self.fetch(g) } }
                var acc: [SchoolEvent] = []
                var bad = 0
                for await p in tg { if let p { acc += p } else { bad += 1 } }
                return (acc, bad)
            }
            found += part.0
            failed += part.1
            start += chunk.count
            progress = Double(start) / Double(groups.count)
            report?(start, groups.count)
        }
        guard !found.isEmpty else {
            error = "РУЗ не ответил — попробуй позже"
            return
        }
        events = found
        institution = inst
        scannedAt = Date()
        failedGroups = failed
        let blob = Blob(institution: inst, at: Date(), events: found, failed: failed)
        let url = Self.fileURL(inst)
        Task.detached(priority: .utility) {
            if let raw = try? JSONEncoder().encode(blob) { try? raw.write(to: url, options: .atomic) }
        }
    }

    /// Расписание одной группы; nil — РУЗ не ответил дважды
    nonisolated private static func fetch(_ g: RuzGroup) async -> [SchoolEvent]? {
        guard let url = RuzClient.timetableURL(groupID: g.id) else { return [] }
        for attempt in 0..<2 {
            if let html = try? await RuzClient.fetch(url, session: schoolSession), !html.isEmpty {
                return RuzClient.parseHTML(html).map { SchoolEvent(e: $0, group: g.number) }
            }
            if attempt == 0 { try? await Task.sleep(nanoseconds: 700_000_000) }
        }
        return nil
    }

    func events(for query: String) -> [SchoolEvent] {
        let who = TeacherMode.parse(query)
        return events.filter { TeacherMode.matches($0.e.teacher, who) }
    }

    /// Все преподаватели школы: ФИО → предметы
    func teachers() -> [(name: String, subjects: [String])] {
        var map: [String: Set<String>] = [:]
        for x in events {
            for name in x.e.teacher.components(separatedBy: ",") {
                let n = name.trimmingCharacters(in: .whitespacesAndNewlines)
                guard n.count > 3 else { continue }
                map[n, default: []].insert(x.e.subject)
            }
        }
        return map.map { ($0.key, $0.value.sorted()) }.sorted { $0.name < $1.name }
    }
}

private let schoolSession: URLSession = {
    let c = URLSessionConfiguration.ephemeral
    c.timeoutIntervalForRequest = 20
    c.httpMaximumConnectionsPerHost = 4
    return URLSession(configuration: c)
}()

// MARK: - Карточка преподавателя на главной

struct TeacherHomeCard: View {
    let data: ScheduleData
    let onTool: (Tool) -> Void
    let onRefresh: () -> Void
    var syncing = false
    @AppStorage("modeus.on") private var modeusOn = false

    private var today: [LessonSlot] {
        let cal = Calendar.current
        return ScheduleQuery.slots(data, days: 1).filter { cal.isDateInToday($0.start) }
    }
    private var week: Int { ScheduleQuery.slots(data, days: 7).count }
    private var groups: [String] { TeacherMode.myGroups(data) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Преподаватель", systemImage: "person.crop.rectangle.stack.fill")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Color.brand)
                    .textCase(.uppercase)
                Spacer()
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.caption.weight(.bold))
                        .rotationEffect(.degrees(syncing ? 360 : 0))
                        .animation(syncing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: syncing)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                stat("\(today.count)", "сегодня")
                stat("\(week)", "за 7 дней")
                stat("\(groups.count)", "групп")
            }
            if !groups.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(groups, id: \.self) { g in
                            Text(g)
                                .font(.caption.weight(.semibold).monospacedDigit())
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.brand.opacity(0.12), in: Capsule())
                        }
                    }
                }
            }
            if !modeusOn {
                ModeusConnectCard(compact: true)
            }
            HStack(spacing: 8) {
                action("Посещаемость", "person.crop.circle.badge.checkmark") { onTool(.attendance) }
                action("Рассылка", "megaphone.fill") { onTool(.broadcast) }
            }
        }
        .padding(16)
        .glass(24)
    }

    private func stat(_ value: String, _ title: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value).font(.system(.title2, design: .rounded).weight(.heavy)).contentTransition(.numericText())
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func action(_ title: String, _ icon: String, _ run: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            run()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PressableStyle())
    }
}
