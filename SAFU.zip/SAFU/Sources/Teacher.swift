import SwiftUI

// MARK: - Режим преподавателя
// В РУЗ САФУ нет отдельной выдачи «расписание преподавателя», поэтому оно собирается из расписаний
// всех групп высшей школы: берём пары, где указан этот преподаватель, и склеиваем одинаковые пары
// разных групп (поток). Дальше всё приложение работает как обычно: главная, «Пары», Live Activity,
// уведомления, дорога — только вместо фамилии преподавателя в паре показаны номера групп.

enum TeacherMode {
    static let kindKey = "user.kind"
    static let queryKey = "teacher.query"

    static var isOn: Bool { UserDefaults.standard.string(forKey: kindKey) == "teacher" }
    static var query: String { UserDefaults.standard.string(forKey: queryKey) ?? "" }

    /// «Иванов И.И.», «Иванов Иван», «иванов» → фамилия и первые буквы имени и отчества
    static func parse(_ q: String) -> (surname: String, initials: [Character]) {
        let parts = q.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        guard let surname = parts.first else { return ("", []) }
        let initials = parts.dropFirst().compactMap(\.first)
        return (surname, Array(initials.prefix(2)))
    }

    /// Ведёт ли пару этот человек. В паре может быть несколько преподавателей через запятую
    static func matches(_ teacher: String, _ who: (surname: String, initials: [Character])) -> Bool {
        guard !who.surname.isEmpty else { return false }
        let words = teacher.lowercased()
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        for (i, w) in words.enumerated() where w == who.surname {
            let rest = words.dropFirst(i + 1).prefix(who.initials.count).compactMap(\.first)
            if Array(rest) == who.initials { return true }
        }
        return false
    }

    /// Пары преподавателя по всем группам школы. progress(готово, всего)
    static func scan(institution: Int, query: String,
                     progress: @escaping @MainActor (Int, Int) -> Void) async throws -> (events: [RuzEvent], groups: [String]) {
        let who = parse(query)
        guard !who.surname.isEmpty else { return ([], []) }
        let groups = try await RuzDirectory.groups(institution: institution)
        guard !groups.isEmpty else { return ([], []) }
        await progress(0, groups.count)

        var found: [(RuzEvent, String)] = []
        var start = 0
        while start < groups.count {
            try Task.checkCancellation()
            let chunk = Array(groups[start..<min(start + 8, groups.count)])
            let part = await withTaskGroup(of: [(RuzEvent, String)].self) { tg -> [(RuzEvent, String)] in
                for g in chunk {
                    tg.addTask {
                        guard let url = RuzClient.timetableURL(groupID: g.id),
                              let html = try? await RuzClient.fetch(url, session: teacherSession) else { return [] }
                        return RuzClient.parseHTML(html).filter { matches($0.teacher, who) }.map { ($0, g.number) }
                    }
                }
                var acc: [(RuzEvent, String)] = []
                for await p in tg { acc += p }
                return acc
            }
            found += part
            start += chunk.count
            await progress(start, groups.count)
        }

        // одна и та же пара у нескольких групп (поток) — одна запись со списком групп
        var merged: [String: (RuzEvent, Set<String>)] = [:]
        for (e, g) in found {
            let key = "\(Int(e.start.timeIntervalSince1970))|\(e.subject.lowercased())|\(e.room)"
            if var m = merged[key] { m.1.insert(g); merged[key] = m } else { merged[key] = (e, [g]) }
        }
        var all = Set<String>()
        let events = merged.values.map { (e, gs) -> RuzEvent in
            all.formUnion(gs)
            var x = e
            let list = gs.sorted()
            x.teacher = (list.count == 1 ? "Группа " : "Группы ") + list.joined(separator: ", ")
            return x
        }.sorted { $0.start < $1.start }
        return (events, all.sorted())
    }

    /// Группы, у которых преподаватель ведёт пары (из уже загруженного расписания)
    static func myGroups(_ data: ScheduleData) -> [String] {
        var set = Set<String>()
        for e in data.ruzEvents {
            let t = e.teacher.replacingOccurrences(of: "Группы ", with: "").replacingOccurrences(of: "Группа ", with: "")
            for g in t.components(separatedBy: ", ") where !g.isEmpty && g.allSatisfy(\.isNumber) { set.insert(g) }
        }
        return set.sorted()
    }
}

private let teacherSession = URLSession(configuration: .ephemeral)

// MARK: - Карточка преподавателя на главной

struct TeacherHomeCard: View {
    let data: ScheduleData
    let onTool: (Tool) -> Void
    let onRefresh: () -> Void
    var syncing = false

    private var today: [LessonSlot] {
        let cal = Calendar.current
        return ScheduleQuery.slots(data, days: 1).filter { cal.isDateInToday($0.start) }
    }
    private var week: Int { ScheduleQuery.slots(data, days: 7).count }
    private var groups: [String] { TeacherMode.myGroups(data) }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Преподаватель", systemImage: "person.crop.rectangle.stack.fill")
                    .font(.caption.weight(.heavy))
                    .foregroundStyle(Color.brand)
                    .textCase(.uppercase)
                Spacer()
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.caption.weight(.bold))
                        .rotationEffect(.degrees(syncing ? 360 : 0))
                        .animation(syncing ? .linear(duration: 1).repeatForever(autoreverses: false) : .default, value: syncing)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }
            HStack(spacing: 10) {
                stat("\(today.count)", "сегодня")
                stat("\(week)", "за 7 дней")
                stat("\(groups.count)", "групп")
            }
            if !groups.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(groups, id: \.self) { g in
                            Text(g)
                                .font(.caption.weight(.semibold).monospacedDigit())
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.brand.opacity(0.12), in: Capsule())
                        }
                    }
                }
            }
            HStack(spacing: 8) {
                action("Посещаемость", "person.crop.circle.badge.checkmark") { onTool(.attendance) }
                action("Рассылка", "megaphone.fill") { onTool(.broadcast) }
            }
        }
        .padding(16)
        .glass(24)
    }

    private func stat(_ value: String, _ title: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value).font(.system(.title2, design: .rounded).weight(.heavy)).contentTransition(.numericText())
            Text(title).font(.caption).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func action(_ title: String, _ icon: String, _ run: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            run()
        } label: {
            Label(title, systemImage: icon)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PressableStyle())
    }
}
