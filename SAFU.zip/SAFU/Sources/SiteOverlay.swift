import SwiftUI
import UIKit
import Combine

// MARK: - Сайты и файлы поверх всего приложения
//
// Слой с карточками живёт в отдельном прозрачном окне над приложением. Поэтому файл или сайт
// открывается карточкой откуда угодно — из главной, из папки предмета, из любого листа или окна —
// и его так же можно свернуть в плашку внизу и собрать в стопку. Мимо карточек нажатия проходят в приложение.

/// Параметры слоя, которые знает только главный экран (где плашка над вкладками)
final class SiteOverlayConfig: ObservableObject {
    static let shared = SiteOverlayConfig()
    @Published var bottomExtra: CGFloat = 0
    @Published var followsBar = false
    @Published var hidden = true
    weak var store: ResourceStore?
    weak var schedule: ScheduleStore?
}

/// Окно-слой: забирает только нажатия по карточке, стопке и окошкам, остальное — приложению под ним
final class SiteOverlayWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard let hit = super.hitTest(point, with: event) else { return nil }
        // открыто окно поверх слоя (Safari, «Поделиться») — оно целиком наше
        if rootViewController?.presentedViewController != nil { return hit }
        var v: UIView? = hit
        while let x = v {
            if x is CardMotorView {
                claimKey(for: event)
                return hit
            }
            if x is StackSwitcherView { return hit }
            v = x.superview
        }
        // плашка свёрнутых (с небольшим запасом, чтобы по ней было легко попасть)
        if SiteTabs.shared.barRect.insetBy(dx: -8, dy: -12).contains(point) { return hit }
        return nil
    }

    /// Mac: нажали по карточке — слой становится главным окном. Иначе ввод с клавиатуры и фокус полей
    /// остаются у приложения под карточкой, и сайт будто зависает
    private func claimKey(for event: UIEvent?) {
        #if targetEnvironment(macCatalyst)
        guard event?.type == .touches, !isKeyWindow else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self, !self.isHidden, !self.isKeyWindow, SiteTabs.shared.activeID != nil else { return }
            self.makeKey()
        }
        #endif
    }
}

enum SiteOverlay {
    private static var window: SiteOverlayWindow?
    private static var bag: AnyCancellable?
    private static var sheetTimer: Timer?
    private static var activation: NSObjectProtocol?

    static func install(in scene: UIWindowScene) {
        guard window == nil else { return }
        let host = UIHostingController(rootView: SiteOverlayRoot())
        host.view.backgroundColor = .clear
        let w = SiteOverlayWindow(windowScene: scene)
        w.windowLevel = .normal + 1
        w.backgroundColor = .clear
        w.rootViewController = host
        w.isHidden = SiteOverlayConfig.shared.hidden
        window = w
        // открыт лист или окно в приложении — плашка над ним не висит
        sheetTimer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { _ in
            let covered = mainWindow(of: scene)?.rootViewController?.presentedViewController != nil
            if SiteTabs.shared.sheetCovering != covered {
                withAnimation(.easeOut(duration: 0.2)) { SiteTabs.shared.sheetCovering = covered }
            }
        }
        // развёрнута карточка — окно становится главным, чтобы клавиатура в полях сайта работала;
        // все свёрнуты — главным снова становится приложение
        bag = SiteTabs.shared.$activeID
            .removeDuplicates()
            .receive(on: DispatchQueue.main)
            .sink { id in
                guard let w = window, !w.isHidden else { return }
                if id != nil {
                    if !w.isKeyWindow { w.makeKey() }
                } else if w.isKeyWindow {
                    mainWindow(of: scene)?.makeKey()
                }
            }
        // приложение снова на экране (на Mac — и после того, как окно чем-то закрывали), а карточка
        // развёрнута — клавиатура снова у неё, а не у приложения под ней
        activation = NotificationCenter.default.addObserver(forName: UIScene.didActivateNotification,
                                                            object: scene, queue: .main) { _ in
            keyIfCardOpen()
        }
    }

    static func setHidden(_ hidden: Bool) {
        guard let w = window, w.isHidden != hidden else { return }
        w.isHidden = hidden
        if hidden, w.isKeyWindow, let scene = w.windowScene { mainWindow(of: scene)?.makeKey() }
        // слой прятали (приложение уходило в фон) — карточка, развёрнутая до этого, снова получает ввод
        if !hidden { keyIfCardOpen() }
    }

    /// Только Mac: там главное окно получает и клавиатуру, и фокус полей сайта, а приложение уходит «в фон»,
    /// даже когда его окно просто закрыли другим. На iPhone касание поля само делает окно главным
    private static func keyIfCardOpen() {
        #if targetEnvironment(macCatalyst)
        guard let w = window, !w.isHidden, !w.isKeyWindow, SiteTabs.shared.activeID != nil else { return }
        w.makeKey()
        #endif
    }

    private static func mainWindow(of scene: UIWindowScene) -> UIWindow? {
        scene.windows.first { !($0 is SiteOverlayWindow) && $0.windowLevel == .normal }
    }
}

private struct SiteOverlayRoot: View {
    @ObservedObject private var cfg = SiteOverlayConfig.shared

    var body: some View {
        Group {
            if let store = cfg.store, let schedule = cfg.schedule {
                SiteLayer(bottomExtra: cfg.bottomExtra, followsBar: cfg.followsBar)
                    .environmentObject(store)
                    .environmentObject(schedule)
            } else {
                Color.clear
            }
        }
        .modifier(AppearanceRoot())
        .tint(Color.brand)
    }
}

/// Невидимый вид в главном экране: ставит окно-слой и передаёт ему параметры
struct SiteOverlayInstaller: UIViewRepresentable {
    let bottomExtra: CGFloat
    let followsBar: Bool
    let hidden: Bool
    let store: ResourceStore
    let schedule: ScheduleStore

    final class Probe: UIView {
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if let scene = window?.windowScene { SiteOverlay.install(in: scene) }
            if let w = window { ScrollTuckWatcher.shared.attach(to: w) }
        }
    }

    func makeUIView(context: Context) -> Probe {
        let v = Probe()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        push()
        return v
    }

    func updateUIView(_ v: Probe, context: Context) { push() }

    private func push() {
        let cfg = SiteOverlayConfig.shared
        let b = bottomExtra, f = followsBar, h = hidden
        let st = store, sc = schedule
        DispatchQueue.main.async {
            if cfg.store !== st { cfg.store = st; cfg.objectWillChange.send() }
            if cfg.schedule !== sc { cfg.schedule = sc; cfg.objectWillChange.send() }
            if cfg.bottomExtra != b { cfg.bottomExtra = b }
            if cfg.followsBar != f { cfg.followsBar = f }
            if cfg.hidden != h { cfg.hidden = h }
            SiteOverlay.setHidden(h)
        }
    }
}

// MARK: - Плашка уезжает вниз вместе с панелью вкладок

/// Панель вкладок iOS 26 сжимается, когда листают вниз, и разворачивается, когда листают вверх.
/// Без системной полосы главных кнопок приложение об этом не узнаёт — поэтому следим за прокруткой сами:
/// жест на всём окне, который ничему не мешает (распознаётся вместе с остальными и не отменяет нажатия)
final class ScrollTuckWatcher: NSObject, UIGestureRecognizerDelegate {
    static let shared = ScrollTuckWatcher()
    private weak var window: UIWindow?
    private var pan: UIPanGestureRecognizer?

    func attach(to w: UIWindow) {
        guard window !== w else { return }
        if let pan, let old = window { old.removeGestureRecognizer(pan) }
        let p = UIPanGestureRecognizer(target: self, action: #selector(moved(_:)))
        p.cancelsTouchesInView = false
        p.delaysTouchesBegan = false
        p.delaysTouchesEnded = false
        p.delegate = self
        w.addGestureRecognizer(p)
        pan = p
        window = w
    }

    func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }

    @objc private func moved(_ g: UIPanGestureRecognizer) {
        guard g.state == .changed, let w = window else { return }
        let t = g.translation(in: w)
        // явное вертикальное движение, а не случайный сдвиг пальца
        guard abs(t.y) > 24, abs(t.y) > abs(t.x) * 1.5 else { return }
        defer { g.setTranslation(.zero, in: w) }
        // только когда под пальцем то, что действительно листается по вертикали
        guard scrollsVertically(at: g.location(in: w), in: w) else { return }
        // палец вверх — содержимое листается вниз, панель сжимается
        SiteTabs.shared.setScrolledDown(t.y < 0)
    }

    private func scrollsVertically(at p: CGPoint, in w: UIWindow) -> Bool {
        var v = w.hitTest(p, with: nil)
        while let x = v {
            if let s = x as? UIScrollView, s.isScrollEnabled, s.contentSize.height > s.bounds.height + 1 { return true }
            v = x.superview
        }
        return false
    }
}
