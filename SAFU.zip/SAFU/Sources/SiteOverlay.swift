import SwiftUI
import UIKit
import Combine

// MARK: - Сайты и файлы поверх всего приложения
//
// Слой с карточками живёт в отдельном прозрачном окне над приложением. Поэтому файл или сайт
// открывается карточкой откуда угодно — из главной, из папки предмета, из любого листа или окна —
// и его так же можно свернуть в плашку и собрать в стопку. Мимо карточек нажатия проходят в приложение.

/// Параметры слоя, которые знает только главный экран (где плашка над вкладками)
final class SiteOverlayConfig: ObservableObject {
    static let shared = SiteOverlayConfig()
    @Published var bottomExtra: CGFloat = 0
    @Published var followsBar = false
    @Published var hidden = true
    weak var store: ResourceStore?
    weak var schedule: ScheduleStore?
}

/// Окно-слой: забирает только нажатия по карточке, стопке и плашке, остальное — приложению под ним
final class SiteOverlayWindow: UIWindow {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard let hit = super.hitTest(point, with: event) else { return nil }
        // открыто окно поверх слоя (Safari, «Поделиться») — оно целиком наше
        if rootViewController?.presentedViewController != nil { return hit }
        var v: UIView? = hit
        while let x = v {
            if x is CardMotorView || x is StackSwitcherView { return hit }
            v = x.superview
        }
        if SiteTabs.shared.barRect.insetBy(dx: 0, dy: -6).contains(point) { return hit }
        return nil
    }
}

enum SiteOverlay {
    private static var window: SiteOverlayWindow?
    private static var bag: AnyCancellable?

    static func install(in scene: UIWindowScene) {
        guard window == nil else { return }
        let host = UIHostingController(rootView: SiteOverlayRoot())
        host.view.backgroundColor = .clear
        let w = SiteOverlayWindow(windowScene: scene)
        w.windowLevel = .normal + 1
        w.backgroundColor = .clear
        w.rootViewController = host
        w.isHidden = SiteOverlayConfig.shared.hidden
        window = w
        // развёрнута карточка — окно становится главным, чтобы клавиатура в полях сайта работала;
        // все свёрнуты — главным снова становится приложение
        bag = SiteTabs.shared.$activeID
            .removeDuplicates()
            .receive(on: DispatchQueue.main)
            .sink { id in
                guard let w = window, !w.isHidden else { return }
                if id != nil {
                    if !w.isKeyWindow { w.makeKey() }
                } else if w.isKeyWindow {
                    mainWindow(of: scene)?.makeKey()
                }
            }
    }

    static func setHidden(_ hidden: Bool) {
        guard let w = window, w.isHidden != hidden else { return }
        w.isHidden = hidden
        if hidden, w.isKeyWindow, let scene = w.windowScene { mainWindow(of: scene)?.makeKey() }
    }

    private static func mainWindow(of scene: UIWindowScene) -> UIWindow? {
        scene.windows.first { !($0 is SiteOverlayWindow) && $0.windowLevel == .normal }
    }
}

private struct SiteOverlayRoot: View {
    @ObservedObject private var cfg = SiteOverlayConfig.shared

    var body: some View {
        Group {
            if let store = cfg.store, let schedule = cfg.schedule {
                SiteLayer(bottomExtra: cfg.bottomExtra, followsBar: cfg.followsBar)
                    .environmentObject(store)
                    .environmentObject(schedule)
            } else {
                Color.clear
            }
        }
        .modifier(AppearanceRoot())
        .tint(Color.brand)
    }
}

/// Невидимый вид в главном экране: ставит окно-слой и передаёт ему параметры
struct SiteOverlayInstaller: UIViewRepresentable {
    let bottomExtra: CGFloat
    let followsBar: Bool
    let hidden: Bool
    let store: ResourceStore
    let schedule: ScheduleStore

    final class Probe: UIView {
        override func didMoveToWindow() {
            super.didMoveToWindow()
            if let scene = window?.windowScene { SiteOverlay.install(in: scene) }
        }
    }

    func makeUIView(context: Context) -> Probe {
        let v = Probe()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        push()
        return v
    }

    func updateUIView(_ v: Probe, context: Context) { push() }

    private func push() {
        let cfg = SiteOverlayConfig.shared
        let b = bottomExtra, f = followsBar, h = hidden
        let st = store, sc = schedule
        DispatchQueue.main.async {
            if cfg.store !== st { cfg.store = st; cfg.objectWillChange.send() }
            if cfg.schedule !== sc { cfg.schedule = sc; cfg.objectWillChange.send() }
            if cfg.bottomExtra != b { cfg.bottomExtra = b }
            if cfg.followsBar != f { cfg.followsBar = f }
            if cfg.hidden != h { cfg.hidden = h }
            SiteOverlay.setHidden(h)
        }
    }
}
