import Foundation
import Security
import WebKit
#if targetEnvironment(macCatalyst)
import CryptoKit
import LocalAuthentication
#endif

// MARK: - Связка ключей (пароли и вход хранятся зашифрованно, только на этом iPhone)

enum Keychain {
    private static let service = "ru.student.safuhub"
    /// Уже прочитанные значения: запрос в связку ключей медленный, а экраны спрашивают часто
    private static var cache: [String: Data?] = [:]
    private static let lock = NSLock()

    #if targetEnvironment(macCatalyst)
    // Mac: сборка из .dmg подписана без сертификата (ad-hoc), и подпись у каждой сборки своя.
    // Элементы обычной связки ключей macOS привязаны к подписи той сборки, что их создала:
    // после обновления приложение их не может ни прочитать (спрашивает пароль Mac или молча отказывает),
    // ни удалить — а новая запись падала с «уже есть такой элемент». Пароль «сохранялся» только
    // до перезапуска. Поэтому на Mac всё лежит в своём зашифрованном хранилище (см. MacVault)
    static func set(_ data: Data, for key: String) {
        lock.lock(); cache[key] = data; lock.unlock()
        MacVault.shared.set(data, for: key)
    }

    static func get(_ key: String) -> Data? {
        lock.lock()
        if let hit = cache[key] { lock.unlock(); return hit }
        lock.unlock()
        let value = MacVault.shared.get(key)
        lock.lock(); cache[key] = .some(value); lock.unlock()
        return value
    }

    static func delete(_ key: String) {
        lock.lock(); cache[key] = .some(nil); lock.unlock()
        MacVault.shared.delete(key)
    }

    static func accounts() -> [String] { MacVault.shared.accounts() }
    #else
    private static func q(_ base: [String: Any]) -> [String: Any] { base }

    static func set(_ data: Data, for key: String) {
        delete(key)
        lock.lock(); cache[key] = data; lock.unlock()
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(Self.q(q) as CFDictionary, nil)
    }

    static func get(_ key: String) -> Data? {
        lock.lock()
        if let hit = cache[key] { lock.unlock(); return hit }
        lock.unlock()
        let value = read(key)
        lock.lock(); cache[key] = .some(value); lock.unlock()
        return value
    }

    private static func read(_ key: String) -> Data? {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(Self.q(q) as CFDictionary, &out) == errSecSuccess else { return nil }
        return out as? Data
    }

    static func delete(_ key: String) {
        lock.lock(); cache[key] = .some(nil); lock.unlock()
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(Self.q(q) as CFDictionary)
    }

    static func accounts() -> [String] {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecReturnAttributes as String: true,
            kSecMatchLimit as String: kSecMatchLimitAll
        ]
        var out: AnyObject?
        guard SecItemCopyMatching(Self.q(q) as CFDictionary, &out) == errSecSuccess,
              let items = out as? [[String: Any]] else { return [] }
        return items.compactMap { $0[kSecAttrAccount as String] as? String }
    }
    #endif
}

#if targetEnvironment(macCatalyst)
/// Хранилище паролей, входа на сайты и ключей связки на Mac.
/// Один файл, зашифрованный AES-256-GCM (подделку или порчу файла видно — он просто не откроется);
/// ключ — случайный, в соседнем файле, оба доступны только пользователю Mac (права 600, папка 700).
/// Защищает от чужих глаз в резервных копиях, синхронизации папок и при случайной отправке файла.
/// От программы, запущенной под тем же пользователем, без подписи разработчика (Developer ID)
/// не защищает ни это хранилище, ни связка ключей — у неё такой же доступ к файлам пользователя
final class MacVault {
    static let shared = MacVault()

    private let lock = NSLock()
    private var items: [String: Data] = [:]
    private var loaded = false
    private let dir: URL
    private var dataURL: URL { dir.appendingPathComponent("vault.bin") }
    private var keyURL: URL { dir.appendingPathComponent("vault.key") }

    private init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        dir = base.appendingPathComponent("ru.student.safuhub/Vault", isDirectory: true)
    }

    func get(_ key: String) -> Data? {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        return items[key]
    }

    func set(_ data: Data, for key: String) {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        guard items[key] != data else { return }
        items[key] = data
        persist()
    }

    func delete(_ key: String) {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        guard items.removeValue(forKey: key) != nil else { return }
        persist()
    }

    func accounts() -> [String] {
        lock.lock(); defer { lock.unlock() }
        loadIfNeeded()
        return Array(items.keys)
    }

    // MARK: файлы

    private func loadIfNeeded() {
        guard !loaded else { return }
        loaded = true
        let fm = FileManager.default
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        if fm.fileExists(atPath: dataURL.path) {
            if let key = readKey(), let raw = try? Data(contentsOf: dataURL),
               let box = try? AES.GCM.SealedBox(combined: raw),
               let plain = try? AES.GCM.open(box, using: key),
               let dict = try? JSONDecoder().decode([String: Data].self, from: plain) {
                items = dict
            } else {
                // файл испорчен или ключ потерян — не затираем: отложим в сторону, чтобы можно было разобраться
                let aside = dir.appendingPathComponent("vault-broken-\(Int(Date().timeIntervalSince1970)).bin")
                try? fm.moveItem(at: dataURL, to: aside)
            }
        }
        // первый запуск с хранилищем: забираем то, что прошлые сборки успели положить в связку ключей
        if !UserDefaults.standard.bool(forKey: "mac.vault.migrated") {
            UserDefaults.standard.set(true, forKey: "mac.vault.migrated")
            let old = LegacyMacKeychain.takeAll()
            if !old.isEmpty {
                for (k, v) in old where items[k] == nil { items[k] = v }
                persist()
            }
        }
    }

    private func readKey() -> SymmetricKey? {
        guard let d = try? Data(contentsOf: keyURL), d.count == 32 else { return nil }
        return SymmetricKey(data: d)
    }

    private func keyForWriting() -> SymmetricKey? {
        if let k = readKey() { return k }
        let k = SymmetricKey(size: .bits256)
        let raw = k.withUnsafeBytes { Data($0) }
        let fm = FileManager.default
        guard fm.createFile(atPath: keyURL.path, contents: raw, attributes: [.posixPermissions: 0o600]) else { return nil }
        return k
    }

    private func persist() {
        guard let key = keyForWriting(),
              let plain = try? JSONEncoder().encode(items),
              let sealed = try? AES.GCM.seal(plain, using: key).combined else { return }
        // атомарно: при сбое посреди записи остаётся прошлый целый файл
        try? sealed.write(to: dataURL, options: .atomic)
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: dataURL.path)
    }
}

/// Что лежало в связке ключей у прошлых сборок для Mac. Читаем без окон с паролем Mac:
/// элементы чужой (старой) подписи без спроса не отдаются — их пропускаем, пароль введётся заново один раз
private enum LegacyMacKeychain {
    private static let service = "ru.student.safuhub"

    static func takeAll() -> [String: Data] {
        let ctx = LAContextShim.noUI()
        var q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecUseDataProtectionKeychain as String: false,
            kSecReturnAttributes as String: true,
            kSecMatchLimit as String: kSecMatchLimitAll,
        ]
        if let ctx { q[kSecUseAuthenticationContext as String] = ctx }
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let list = out as? [[String: Any]] else { return [:] }
        var result: [String: Data] = [:]
        for attrs in list {
            guard let account = attrs[kSecAttrAccount as String] as? String else { continue }
            var one: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: service,
                kSecAttrAccount as String: account,
                kSecUseDataProtectionKeychain as String: false,
                kSecReturnData as String: true,
                kSecMatchLimit as String: kSecMatchLimitOne,
            ]
            if let ctx { one[kSecUseAuthenticationContext as String] = ctx }
            var data: AnyObject?
            if SecItemCopyMatching(one as CFDictionary, &data) == errSecSuccess, let d = data as? Data {
                result[account] = d
                // перенесли — старую копию убираем (если связка позволит)
                one.removeValue(forKey: kSecReturnData as String)
                one.removeValue(forKey: kSecMatchLimit as String)
                SecItemDelete(one as CFDictionary)
            }
        }
        return result
    }
}

private enum LAContextShim {
    /// Контекст, который запрещает системе показывать окна с вопросом пароля
    static func noUI() -> LAContext? {
        let c = LAContext()
        c.interactionNotAllowed = true
        return c
    }
}
#endif

// MARK: - Сохранённые логины сайтов

struct SiteCredential: Codable, Identifiable, Equatable {
    var host: String
    var user: String
    var pass: String
    var id: String { host }
}

enum CredentialStore {
    private static let prefix = "cred:"

    static var enabled: Bool { UserDefaults.standard.object(forKey: "web.savePasswords") as? Bool ?? true }
    static var autoLogin: Bool { UserDefaults.standard.object(forKey: "web.autoLogin") as? Bool ?? true }

    static func get(_ host: String) -> SiteCredential? {
        guard let d = Keychain.get(prefix + host.lowercased()) else { return nil }
        return try? JSONDecoder().decode(SiteCredential.self, from: d)
    }

    static func save(_ c: SiteCredential) {
        var c = c
        c.host = c.host.lowercased()
        if let d = try? JSONEncoder().encode(c) { Keychain.set(d, for: prefix + c.host) }
    }

    static func delete(_ host: String) {
        Keychain.delete(prefix + host.lowercased())
    }

    static func all() -> [SiteCredential] {
        Keychain.accounts()
            .filter { $0.hasPrefix(prefix) }
            .compactMap { get(String($0.dropFirst(prefix.count))) }
            .sorted { $0.host < $1.host }
    }

    static func deleteAll() {
        for c in all() { delete(c.host) }
    }
}

// MARK: - Сохранение входа между перезапусками
// Сайты вуза хранят вход в «сессионных» cookie, которые iOS стирает при закрытии приложения.
// Мы сохраняем их в связку ключей и возвращаем при следующем открытии.

enum SessionKeeper {
    private struct StoredCookie: Codable {
        var name: String
        var value: String
        var domain: String
        var path: String
        var secure: Bool
        var httpOnly: Bool
    }

    private static let key = "cookies"
    private static var restored = false
    /// Запись в связку ключей — не на главном потоке, по очереди
    private static let queue = DispatchQueue(label: "safu.cookies.save", qos: .utility)
    /// Что уже лежит в связке ключей (трогается только из queue)
    private static var saved: Data?

    /// Каждый открытый сайт зовёт это раз в 20 секунд. Раньше разбор всех куки и две записи в связку ключей
    /// шли на главном потоке, даже когда ничего не поменялось, — прокрутка в это время спотыкалась.
    /// Теперь — в фоне и только если вход правда поменялся
    static func save(from store: WKHTTPCookieStore) {
        store.getAllCookies { cookies in
            queue.async {
                let list = cookies.map {
                    StoredCookie(name: $0.name, value: $0.value, domain: $0.domain, path: $0.path,
                                 secure: $0.isSecure, httpOnly: $0.isHTTPOnly)
                }
                .sorted { ($0.domain, $0.path, $0.name) < ($1.domain, $1.path, $1.name) }
                let enc = JSONEncoder()
                enc.outputFormatting = [.sortedKeys]
                guard let d = try? enc.encode(list) else { return }
                if saved == nil { saved = Keychain.get(key) }
                guard d != saved else { return }
                saved = d
                Keychain.set(d, for: key)
            }
        }
    }

    /// Возвращаем сохранённый вход (один раз за запуск приложения)
    static func restore(into store: WKHTTPCookieStore, done: @escaping () -> Void) {
        guard !restored, let d = Keychain.get(key),
              let list = try? JSONDecoder().decode([StoredCookie].self, from: d) else {
            done()
            return
        }
        restored = true
        let group = DispatchGroup()
        for c in list {
            var props: [HTTPCookiePropertyKey: Any] = [
                .name: c.name, .value: c.value, .domain: c.domain, .path: c.path,
                .expires: Date().addingTimeInterval(30 * 86_400)
            ]
            if c.secure { props[.secure] = "TRUE" }
            if c.httpOnly { props[HTTPCookiePropertyKey("HttpOnly")] = "TRUE" }
            if let cookie = HTTPCookie(properties: props) {
                group.enter()
                store.setCookie(cookie) { group.leave() }
            }
        }
        group.notify(queue: .main) { done() }
    }

    /// Выйти со всех сайтов
    static func clearAll(completion: @escaping () -> Void) {
        Keychain.delete(key)
        queue.async { saved = nil }
        restored = true
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        WKWebsiteDataStore.default().removeData(ofTypes: types, modifiedSince: .distantPast) {
            completion()
        }
    }
}

// MARK: - Скрипт: находит поля логина/пароля, подставляет сохранённые, ловит ввод

enum LoginScript {
    static let source = """
    (function(){
      if (window.__safuHooked) return; window.__safuHooked = true;
      function visible(el){ return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }
      function fields(){
        var ps = Array.prototype.slice.call(document.querySelectorAll('input[type="password"]')).filter(visible);
        if (!ps.length) return null;
        var p = ps[0];
        var scope = p.form || document;
        var all = Array.prototype.slice.call(scope.querySelectorAll('input')).filter(function(i){
          var t = (i.getAttribute('type') || 'text').toLowerCase();
          return (t === 'text' || t === 'email' || t === 'tel') && visible(i);
        });
        var u = null;
        for (var k = 0; k < all.length; k++) {
          if (all[k].compareDocumentPosition(p) & Node.DOCUMENT_POSITION_FOLLOWING) u = all[k];
        }
        if (!u && all.length) u = all[0];
        return { u: u, p: p, form: p.form };
      }
      function post(msg){ try { window.webkit.messageHandlers.safuLogin.postMessage(msg); } catch(e) {} }
      function setVal(el, v){
        if (!el) return;
        var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        setter.call(el, v);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      }
      window.__safuFill = function(user, pass, submit){
        var f = fields(); if (!f) return false;
        if (f.u && user) setVal(f.u, user);
        setVal(f.p, pass);
        if (submit) {
          setTimeout(function(){
            var scope = f.form || document;
            var b = scope.querySelector('#submitButton, button[type="submit"], input[type="submit"], button:not([type]), [role="button"], .login-button, .btn-login');
            if (b) { b.click(); }
            else if (f.form) { f.form.submit(); }
            else { f.p.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true })); }
          }, 400);
        }
        return true;
      };
      // Запоминаем то, что вводит пользователь (в том числе на сайтах без обычной формы, как почта)
      function capture(){
        var f = fields(); if (!f || !f.p.value) return;
        post({ kind: 'creds', host: location.host, user: f.u ? f.u.value : '', pass: f.p.value });
      }
      document.addEventListener('submit', capture, true);
      document.addEventListener('change', function(e){ if (e.target && e.target.type === 'password') capture(); }, true);
      document.addEventListener('input', function(e){ if (e.target && e.target.type === 'password') capture(); }, true);
      document.addEventListener('click', function(){ if (fields()) capture(); }, true);
      document.addEventListener('keydown', function(e){ if (e.key === 'Enter' && fields()) capture(); }, true);

      // Следим за появлением и исчезновением формы входа (одностраничные сайты не перезагружают страницу)
      var hadForm = false;
      function check(){
        var has = !!fields();
        if (has && !hadForm) { post({ kind: 'form', host: location.host }); }
        if (!has && hadForm) { post({ kind: 'gone', host: location.host }); }
        hadForm = has;
      }
      check();
      var timer = null;
      new MutationObserver(function(){
        if (timer) return;
        timer = setTimeout(function(){ timer = null; check(); }, 400);
      }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'hidden'] });
      window.addEventListener('load', check);
      setTimeout(check, 1500); setTimeout(check, 4000);
    })();
    """
}

/// Прокладка, чтобы WKUserContentController не держал WebModel в памяти вечно
final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(controller, didReceive: message)
    }
}
