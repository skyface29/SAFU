import SwiftUI
import Network
import UserNotifications
import UIKit

// MARK: - Уведомления о новых письмах в почте САФУ
// У университетской почты (Samoware) нет своего приложения с уведомлениями.
// Приложение само заглядывает в ящик — напрямую на сервер университета, без посредников, —
// и если пришло новое письмо, показывает уведомление: от кого и тема.
//
// Как заглядываем:
// 1. Основной способ — тем же протоколом, что и сам сайт почты: XIMSS поверх обычного HTTPS
//    (https://edu.narfu.ru/XIMSSLogin/ → /Session/<id>/sync). Раз сайт почты открывается, работает и он.
// 2. Запасной — IMAP (порт 993), если его включили на сервере.
// Письма не скачиваются и не помечаются прочитанными: смотрим только «от кого», «тема» и прочитано ли.

enum MailWatch {
    /// Сайт почты: для него сохранён логин и пароль
    static let webHost = "edu.narfu.ru"

    private static let d = UserDefaults.standard
    static var enabled: Bool {
        get { d.bool(forKey: "mail.notify") }
        set { d.set(newValue, forKey: "mail.notify") }
    }
    static var badge: Bool {
        get { d.object(forKey: "mail.badge") as? Bool ?? true }
        set { d.set(newValue, forKey: "mail.badge") }
    }
    /// Сервер почты (и для сайта, и для IMAP)
    static var server: String {
        get { (d.string(forKey: "mail.server") ?? "").isEmpty ? webHost : d.string(forKey: "mail.server")! }
        set { d.set(newValue.trimmingCharacters(in: .whitespaces), forKey: "mail.server") }
    }
    /// Порт IMAP
    static var port: Int {
        get { d.integer(forKey: "mail.port") > 0 ? d.integer(forKey: "mail.port") : 993 }
        set { d.set(newValue, forKey: "mail.port") }
    }

    enum Transport: String, CaseIterable, Identifiable {
        case auto, ximss, imap
        var id: String { rawValue }
        var title: String {
            switch self {
            case .auto: return "Автоматически"
            case .ximss: return "Как сайт почты"
            case .imap: return "IMAP"
            }
        }
    }
    static var transport: Transport {
        get { Transport(rawValue: d.string(forKey: "mail.transport") ?? "") ?? .auto }
        set { d.set(newValue.rawValue, forKey: "mail.transport") }
    }
    /// Каким способом получилось в последний раз
    static var workedVia: Transport? {
        get { Transport(rawValue: d.string(forKey: "mail.via") ?? "") }
        set { d.set(newValue?.rawValue, forKey: "mail.via") }
    }

    /// Последнее письмо, о котором уже знаем (номер письма на сервере)
    private static var lastUID: Int {
        get { d.integer(forKey: "mail.lastUID") }
        set { d.set(newValue, forKey: "mail.lastUID") }
    }
    static var unseen: Int {
        get { d.integer(forKey: "mail.unseen") }
        set { d.set(newValue, forKey: "mail.unseen") }
    }
    static var lastCheck: Date? {
        let t = d.double(forKey: "mail.lastCheck")
        return t > 0 ? Date(timeIntervalSince1970: t) : nil
    }
    static var lastSuccess: Date? {
        let t = d.double(forKey: "mail.lastSuccess")
        return t > 0 ? Date(timeIntervalSince1970: t) : nil
    }
    static var lastError: String? {
        get { d.string(forKey: "mail.lastError") }
        set { d.set(newValue, forKey: "mail.lastError") }
    }

    // MARK: Когда iOS будила приложение в фоне — видно в проверке по шагам

    static func noteBackgroundRun() {
        var list = backgroundRuns.filter { Date().timeIntervalSince($0) < 3 * 86400 }
        list.append(Date())
        d.set(list.suffix(60).map(\.timeIntervalSince1970), forKey: "bg.runs")
    }

    static var backgroundRuns: [Date] {
        ((d.array(forKey: "bg.runs") as? [Double]) ?? []).map { Date(timeIntervalSince1970: $0) }
    }

    // MARK: Логин и пароль

    /// Логин и пароль от почты. Своих нет — берём от Sakai или личного кабинета: у САФУ это одна учётная запись
    struct Account { let user: String; let pass: String; let source: String }

    static var account: Account? {
        func usable(_ c: SiteCredential) -> Bool {
            !c.user.trimmingCharacters(in: .whitespaces).isEmpty && !c.pass.isEmpty
        }
        func make(_ c: SiteCredential, _ source: String) -> Account {
            Account(user: c.user.trimmingCharacters(in: .whitespaces), pass: c.pass, source: source)
        }
        if let c = CredentialStore.get(webHost), usable(c) { return make(c, "почты") }
        // вход на других сайтах САФУ (Sakai, личный кабинет, единый вход) — та же учётная запись
        let others = CredentialStore.all().filter { $0.host.hasSuffix("narfu.ru") && usable($0) }
        let ranked = others.sorted { rank($0.host) < rank($1.host) }
        guard let c = ranked.first else { return nil }
        return make(c, c.host.contains("sakai") ? "Sakai" : c.host.hasPrefix("lk.") ? "личного кабинета" : c.host)
    }

    private static func rank(_ host: String) -> Int {
        if host.contains("sakai") { return 0 }
        if host.hasPrefix("lk.") { return 1 }
        return 2
    }

    static var credential: SiteCredential? { CredentialStore.get(webHost) }

    /// Логины, которые пробуем: как сохранён, а без «@» — ещё и полным адресом
    static func logins(_ user: String) -> [String] {
        user.contains("@") ? [user] : [user, user + "@" + webHost]
    }

    struct Message { let uid: Int; let from: String; let subject: String }
    struct Report { let unseen: Int; let fresh: [Message]; let via: Transport; let total: Int? }

    enum Failure: LocalizedError {
        case noPassword, network(String), login(String), server(String), unavailable(String), timeout
        var errorDescription: String? {
            switch self {
            case .noPassword: return "Нет логина и пароля от почты. Впиши их ниже — они сохранятся только на этом телефоне."
            case .network(let s): return "Нет связи с сервером почты: \(s)"
            case .login(let s): return "Сервер не принял логин или пароль. \(s)"
            case .server(let s): return "Сервер ответил ошибкой: \(s)"
            case .unavailable(let s): return s
            case .timeout: return "Сервер почты не ответил вовремя"
            }
        }
    }

    /// Не чаще раза в 50 секунд — и приложение, и фон могут позвать одновременно
    private static let gate = NSLock()
    private static var running = false

    /// Проверить, если уведомления включены. Ошибки запоминаются и видны в настройках
    static func checkIfEnabled(background: Bool = false) async {
        guard enabled else { return }
        if let last = lastCheck, Date().timeIntervalSince(last) < 50 { return }
        // у фоновой задачи iOS всего ~30 секунд на всё
        _ = try? await check(timeout: background ? 22 : 35)
    }

    /// Заглянуть в ящик. notify — показать уведомления о новых письмах
    @discardableResult
    static func check(notify: Bool = true, timeout: Double = 35) async throws -> Report {
        gate.lock()
        if running {
            gate.unlock()
            return Report(unseen: unseen, fresh: [], via: workedVia ?? .auto, total: nil)
        }
        running = true
        gate.unlock()
        defer { gate.lock(); running = false; gate.unlock() }

        do {
            let r = try await withTimeout(timeout) { try await fetch() }
            let now = Date().timeIntervalSince1970
            d.set(now, forKey: "mail.lastCheck")
            d.set(now, forKey: "mail.lastSuccess")
            lastError = nil
            unseen = r.unseen
            workedVia = r.via
            if notify { post(r.fresh) }
            if badge { try? await UNUserNotificationCenter.current().setBadgeCount(r.unseen) }
            return r
        } catch {
            d.set(Date().timeIntervalSince1970, forKey: "mail.lastCheck")
            lastError = error.localizedDescription
            throw error
        }
    }

    /// Выключили уведомления — убираем цифру с иконки
    static func disable() {
        enabled = false
        UNUserNotificationCenter.current().setBadgeCount(0)
    }

    // MARK: Разговор с сервером

    private static func fetch() async throws -> Report {
        guard let acc = account else { throw Failure.noPassword }
        let order: [Transport]
        switch transport {
        case .auto: order = workedVia == .imap ? [.imap, .ximss] : [.ximss, .imap]
        case .ximss: order = [.ximss]
        case .imap: order = [.imap]
        }
        var problems: [String] = []
        for t in order {
            do {
                if t == .imap { return try await imapCheck(acc) }
                return try await ximssCheck(acc)
            } catch Failure.login(let text) {
                // пароль не подошёл — другой способ не поможет, а лишние попытки могут заблокировать вход
                throw Failure.login(text)
            } catch is CancellationError {
                throw Failure.timeout
            } catch {
                problems.append("\(t.title): \(error.localizedDescription)")
            }
        }
        throw Failure.unavailable(problems.joined(separator: "\n"))
    }

    /// Какие из непрочитанных — новые, и запоминаем, до какого письма уже дошли.
    /// Первый раз (или ящик пересоздан) — только запоминаем, без потока уведомлений о старых письмах
    private static func advance(unseenUIDs: [Int], maxUID: Int, validity: Int, via: Transport) -> Set<Int> {
        let vKey = "mail.uidValidity." + via.rawValue
        let oldValidity = d.integer(forKey: vKey)
        var fresh = Set<Int>()
        if lastUID > 0 && validity == oldValidity && maxUID >= lastUID {
            fresh = Set(unseenUIDs.filter { $0 > lastUID }.suffix(5))
            lastUID = max(lastUID, maxUID)
        } else {
            lastUID = maxUID
        }
        d.set(validity, forKey: vKey)
        return fresh
    }

    // MARK: Как сайт почты (XIMSS поверх HTTPS)

    private static func ximssCheck(_ acc: Account) async throws -> Report {
        let c = XIMSSClient(host: server)
        try await c.login(candidates: logins(acc.user), password: acc.pass)
        do {
            let (items, total, unseenCount) = try await c.inbox(limit: 20)
            await c.bye()
            let unseenUIDs = items.filter { !$0.seen }.map(\.uid)
            let maxUID = items.map(\.uid).max() ?? 0
            let fresh = advance(unseenUIDs: unseenUIDs, maxUID: maxUID, validity: 0, via: .ximss)
            let messages = items.filter { fresh.contains($0.uid) }.sorted { $0.uid < $1.uid }
                .map { Message(uid: $0.uid, from: $0.from.isEmpty ? "Почта САФУ" : $0.from,
                               subject: $0.subject.isEmpty ? "(без темы)" : $0.subject) }
            return Report(unseen: unseenCount ?? unseenUIDs.count, fresh: messages, via: .ximss, total: total)
        } catch {
            await c.bye()
            throw error
        }
    }

    // MARK: IMAP (запасной способ)

    private static func imapCheck(_ acc: Account) async throws -> Report {
        let imap = IMAPConnection(host: server, port: port)
        defer { imap.close() }
        // время вышло — рвём соединение, иначе ожидание ответа сервера не прервать
        return try await withTaskCancellationHandler {
            try await imapSession(imap, acc)
        } onCancel: {
            imap.close()
        }
    }

    private static func imapSession(_ imap: IMAPConnection, _ acc: Account) async throws -> Report {
        try await imap.open()
        var lastNo = ""
        var ok = false
        for l in logins(acc.user) {
            do {
                _ = try await imap.command("LOGIN \(IMAPConnection.quote(l)) \(IMAPConnection.quote(acc.pass))", secret: true)
                ok = true
                break
            } catch IMAPConnection.Reply.no(let text) {
                lastNo = text
            }
        }
        guard ok else { throw Failure.login(lastNo) }

        // только чтение: письма не помечаются прочитанными
        let sel = try await imap.command("EXAMINE INBOX")
        let validity = Int(sel.firstMatch(#"UIDVALIDITY (\d+)"#) ?? "") ?? 0
        let uidNext = Int(sel.firstMatch(#"UIDNEXT (\d+)"#) ?? "") ?? 0
        let total = Int(sel.firstMatch(#"\* (\d+) EXISTS"#) ?? "")

        let search = try await imap.command("UID SEARCH UNSEEN")
        let unseenUIDs = search.components(separatedBy: "\r\n")
            .filter { $0.hasPrefix("* SEARCH") }
            .flatMap { $0.dropFirst(8).split(separator: " ").compactMap { Int($0) } }
            .sorted()

        let maxKnown = max(unseenUIDs.last ?? 0, uidNext - 1)
        let freshUIDs = advance(unseenUIDs: unseenUIDs, maxUID: maxKnown, validity: validity, via: .imap)
        var fresh: [Message] = []
        if !freshUIDs.isEmpty {
            let list = freshUIDs.sorted().map(String.init).joined(separator: ",")
            let resp = try await imap.command("UID FETCH \(list) (UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])")
            fresh = parseFetch(resp).sorted { $0.uid < $1.uid }
            // заголовки не пришли — всё равно скажем, что письмо есть
            if fresh.isEmpty { fresh = freshUIDs.sorted().map { Message(uid: $0, from: "Почта САФУ", subject: "Новое письмо") } }
        }
        _ = try? await imap.command("LOGOUT")
        return Report(unseen: unseenUIDs.count, fresh: fresh, via: .imap, total: total)
    }

    /// Ответ на FETCH → письма (от кого и тема)
    static func parseFetch(_ text: String) -> [Message] {
        var out: [Message] = []
        let blocks = text.components(separatedBy: "\r\n* ").dropFirst(text.hasPrefix("* ") ? 0 : 1)
        for raw in blocks {
            let b = raw.hasPrefix("* ") ? String(raw.dropFirst(2)) : raw
            guard b.range(of: #"^\d+ FETCH"#, options: .regularExpression) != nil,
                  let uid = Int(b.firstMatch(#"UID (\d+)"#) ?? "") else { continue }
            let headers = unfold(b)
            let from = headers.firstMatch(#"(?im)^From:\s*(.*)$"#).map { senderName(decodeMIME($0)) } ?? ""
            let subject = headers.firstMatch(#"(?im)^Subject:\s*(.*)$"#).map { decodeMIME($0) } ?? ""
            out.append(Message(uid: uid,
                               from: from.isEmpty ? "Почта САФУ" : from,
                               subject: subject.isEmpty ? "(без темы)" : subject))
        }
        return out
    }

    /// Длинные заголовки переносятся на следующую строку с пробелом в начале — склеиваем
    private static func unfold(_ s: String) -> String {
        s.replacingOccurrences(of: #"\r?\n[ \t]+"#, with: " ", options: .regularExpression)
    }

    /// «"Иванов И. И." <ivanov@narfu.ru>» → «Иванов И. И.»
    static func senderName(_ from: String) -> String {
        let f = from.trimmingCharacters(in: .whitespaces)
        if let lt = f.firstIndex(of: "<") {
            let name = f[..<lt].trimmingCharacters(in: CharacterSet(charactersIn: " \""))
            if !name.isEmpty { return name }
            return f[f.index(after: lt)...].trimmingCharacters(in: CharacterSet(charactersIn: "> "))
        }
        return f.trimmingCharacters(in: CharacterSet(charactersIn: "\""))
    }

    /// Русские темы приходят закодированными: =?UTF-8?B?0J/RgNC40LLQtdGC?=
    static func decodeMIME(_ s: String) -> String {
        let pattern = #"=\?([^?]+)\?([bBqQ])\?([^?]*)\?="#
        guard let rx = try? NSRegularExpression(pattern: pattern) else { return s }
        // пробелы между двумя закодированными кусками не считаются
        let joined = s.replacingOccurrences(of: #"(\?=)\s+(=\?)"#, with: "$1$2", options: .regularExpression)
        let ns = joined as NSString
        var result = ""
        var pos = 0
        for m in rx.matches(in: joined, range: NSRange(location: 0, length: ns.length)) {
            result += ns.substring(with: NSRange(location: pos, length: m.range.location - pos))
            let charset = ns.substring(with: m.range(at: 1))
            let kind = ns.substring(with: m.range(at: 2)).uppercased()
            let body = ns.substring(with: m.range(at: 3))
            var bytes: Data?
            if kind == "B" {
                var b64 = body
                while b64.count % 4 != 0 { b64 += "=" }
                bytes = Data(base64Encoded: b64)
            } else {
                var data = Data()
                var chars = Array(body.replacingOccurrences(of: "_", with: " ").utf8)[...]
                while let c = chars.popFirst() {
                    if c == UInt8(ascii: "="), chars.count >= 2,
                       let v = UInt8(String(decoding: chars.prefix(2), as: UTF8.self), radix: 16) {
                        data.append(v)
                        chars = chars.dropFirst(2)
                    } else {
                        data.append(c)
                    }
                }
                bytes = data
            }
            let cf = CFStringConvertIANACharSetNameToEncoding(charset as CFString)
            let enc = cf == kCFStringEncodingInvalidId ? String.Encoding.utf8
                : String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(cf))
            result += bytes.flatMap { String(data: $0, encoding: enc) } ?? ns.substring(with: m.range)
            pos = m.range.location + m.range.length
        }
        result += ns.substring(from: pos)
        return result.trimmingCharacters(in: .whitespaces)
    }

    // MARK: Уведомления

    private static func post(_ list: [Message]) {
        let center = UNUserNotificationCenter.current()
        for m in list.suffix(3) {
            let c = UNMutableNotificationContent()
            c.title = m.from
            c.body = m.subject
            c.sound = .default
            c.threadIdentifier = "mail"
            c.userInfo = [MailRouter.key: true]
            center.add(UNNotificationRequest(identifier: "mail.\(m.uid)", content: c, trigger: nil))
        }
        if list.count > 3 {
            let c = UNMutableNotificationContent()
            c.title = "Почта САФУ"
            c.body = "И ещё \(list.count - 3) новых писем"
            c.threadIdentifier = "mail"
            c.userInfo = [MailRouter.key: true]
            center.add(UNNotificationRequest(identifier: "mail.more.\(list.last?.uid ?? 0)", content: c, trigger: nil))
        }
    }

    /// Пробное уведомление через 5 секунд — видно, как оно выглядит и доходит ли вообще
    static func sendTestNotification() {
        let c = UNMutableNotificationContent()
        c.title = "Почта САФУ · проверка"
        c.body = "Так будет выглядеть уведомление о новом письме: от кого и тема"
        c.sound = .default
        c.threadIdentifier = "mail"
        c.userInfo = [MailRouter.key: true]
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "mail.test", content: c, trigger: trigger))
    }

    // MARK: Проверка по шагам

    struct DiagStep: Identifiable {
        let id = UUID()
        let title: String
        /// nil — просто сведения
        let ok: Bool?
        let detail: String
    }

    static func diagnose() async -> [DiagStep] {
        var steps: [DiagStep] = []

        // 1. разрешение на уведомления
        let center = UNUserNotificationCenter.current()
        var settings = await center.notificationSettings()
        if settings.authorizationStatus == .notDetermined {
            _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
            settings = await center.notificationSettings()
        }
        switch settings.authorizationStatus {
        case .authorized, .provisional, .ephemeral:
            let banners = settings.alertSetting == .enabled || settings.notificationCenterSetting == .enabled
                || settings.lockScreenSetting == .enabled
            steps.append(DiagStep(title: "Уведомления", ok: banners,
                                  detail: banners ? "Разрешены" : "Разрешены, но выключены баннеры, экран блокировки и Центр уведомлений: Настройки → САФУ → Уведомления"))
        default:
            steps.append(DiagStep(title: "Уведомления", ok: false,
                                  detail: "Запрещены. Включи: Настройки → САФУ → Уведомления"))
        }

        // 2. фоновое обновление
        let bg = await MainActor.run { UIApplication.shared.backgroundRefreshStatus }
        let lowPower = ProcessInfo.processInfo.isLowPowerModeEnabled
        switch bg {
        case .available where !lowPower:
            steps.append(DiagStep(title: "Фоновое обновление", ok: true, detail: "Включено — iOS может будить приложение, чтобы проверить почту"))
        case .available:
            steps.append(DiagStep(title: "Фоновое обновление", ok: false, detail: "Включён режим энергосбережения — пока он включён, iOS не будит приложения в фоне"))
        default:
            steps.append(DiagStep(title: "Фоновое обновление", ok: false,
                                  detail: "Выключено. Включи: Настройки → Основные → Обновление контента, и там же для САФУ"))
        }

        // 3. логин и пароль
        guard let acc = account else {
            steps.append(DiagStep(title: "Логин и пароль", ok: false, detail: "Не сохранены — впиши их выше"))
            return steps
        }
        steps.append(DiagStep(title: "Логин и пароль", ok: true, detail: "\(acc.user) · пароль от \(acc.source)"))

        // 4. сайт почты доступен
        let site = await siteProbe()
        steps.append(DiagStep(title: "Сайт почты", ok: site.ok, detail: site.text))

        // 5. вход тем же способом, что у сайта почты
        do {
            let c = XIMSSClient(host: server)
            try await withTimeout(25) {
                try await c.login(candidates: logins(acc.user), password: acc.pass)
            }
            do {
                let (items, total, unseenCount) = try await withTimeout(25) { try await c.inbox(limit: 5) }
                await c.bye()
                let unread = unseenCount ?? items.filter { !$0.seen }.count
                var text = "Вход работает. Во «Входящих» \(total.map(String.init) ?? "?") писем, непрочитанных: \(unread)"
                if let last = items.first { text += ". Последнее: «\(last.subject.isEmpty ? "без темы" : last.subject)» от \(last.from.isEmpty ? "?" : last.from)" }
                steps.append(DiagStep(title: "Почта (как сайт почты)", ok: true, detail: text))
            } catch {
                await c.bye()
                steps.append(DiagStep(title: "Почта (как сайт почты)", ok: false, detail: "Вход работает, но письма не прочитались: \(error.localizedDescription)"))
            }
        } catch {
            steps.append(DiagStep(title: "Почта (как сайт почты)", ok: false, detail: error.localizedDescription))
        }

        // 6. IMAP — запасной способ
        let imap = await imapProbe(acc)
        steps.append(DiagStep(title: "Почта (IMAP, запасной)", ok: imap.ok ? true : nil, detail: imap.text))

        // 7. будила ли iOS приложение в фоне
        let day = backgroundRuns.filter { Date().timeIntervalSince($0) < 86400 }
        if let last = backgroundRuns.last {
            steps.append(DiagStep(title: "Проверки в фоне", ok: day.isEmpty ? nil : true,
                                  detail: "За сутки iOS будила приложение \(day.count) раз, последний — \(Fmt.formatter("d MMM, HH:mm").string(from: last)). Чем чаще открываешь приложение, тем чаще iOS его будит."))
        } else {
            steps.append(DiagStep(title: "Проверки в фоне", ok: nil,
                                  detail: "iOS ещё ни разу не будила приложение в фоне. Обычно начинает через несколько часов после установки, а чаще — если открывать приложение каждый день."))
        }
        return steps
    }

    private static func siteProbe() async -> (ok: Bool, text: String) {
        guard let url = URL(string: "https://\(server)/") else { return (false, "Неверный адрес сервера: \(server)") }
        let req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            return (code > 0 && code < 500, "\(server) отвечает (HTTP \(code))")
        } catch {
            return (false, "\(server): \(error.localizedDescription)")
        }
    }

    private static func imapProbe(_ acc: Account) async -> (ok: Bool, text: String) {
        let imap = IMAPConnection(host: server, port: port)
        defer { imap.close() }
        do {
            return try await withTimeout(15) {
                try await withTaskCancellationHandler {
                    try await imap.open()
                    var last = ""
                    for l in logins(acc.user) {
                        do {
                            _ = try await imap.command("LOGIN \(IMAPConnection.quote(l)) \(IMAPConnection.quote(acc.pass))", secret: true)
                            _ = try? await imap.command("LOGOUT")
                            return (true, "Порт \(port): вход работает")
                        } catch IMAPConnection.Reply.no(let t) {
                            last = t
                        }
                    }
                    return (false, "Порт \(port): логин не принят. \(last)")
                } onCancel: {
                    imap.close()
                }
            }
        } catch {
            return (false, "Порт \(port) недоступен: \(error.localizedDescription). Это не страшно, если работает способ «как сайт почты»")
        }
    }

    static func withTimeout<T>(_ seconds: Double, _ op: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { g in
            g.addTask { try await op() }
            g.addTask {
                try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                throw Failure.timeout
            }
            defer { g.cancelAll() }
            guard let first = try await g.next() else { throw Failure.timeout }
            return first
        }
    }
}

/// Нажали на уведомление о письме — открываем почту
final class MailRouter: ObservableObject {
    static let shared = MailRouter()
    static let key = "safu.mail"
    /// Ждёт, пока главная откроет почту (главная могла ещё не загрузиться)
    @Published var pending = false
}

// MARK: - Клиент XIMSS: тот же протокол, которым пользуется сайт почты (Samoware)
// Вход:     POST https://<сервер>/XIMSSLogin/  (username, password, version, errorAsXML=1) → <session urlID="…"/>
// Запросы:  POST https://<сервер>/Session/<urlID>/sync  с телом <XIMSS>…</XIMSS>
// Выход:    <bye/>

final class XIMSSClient {
    struct Item { let uid: Int; let seen: Bool; let from: String; let subject: String }

    let host: String
    private let session: URLSession
    private var urlID: String?
    private var counter = 0

    init(host: String, timeout: TimeInterval = 15) {
        self.host = host
        let c = URLSessionConfiguration.ephemeral     // свои cookie на один сеанс, ничего не сохраняется
        c.timeoutIntervalForRequest = timeout
        c.timeoutIntervalForResource = timeout * 2
        c.waitsForConnectivity = false
        c.httpCookieAcceptPolicy = .always
        c.httpShouldSetCookies = true
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.urlCache = nil
        session = URLSession(configuration: c)
    }

    deinit { session.finishTasksAndInvalidate() }

    private static let unreserved = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")
    private static func form(_ items: [(String, String)]) -> String {
        items.map { "\($0.0)=\($0.1.addingPercentEncoding(withAllowedCharacters: unreserved) ?? $0.1)" }
            .joined(separator: "&")
    }

    private static func looksLikeAuth(_ text: String) -> Bool {
        let t = text.lowercased()
        return ["password", "пароль", "account", "учетн", "учётн", "authentic", "unknown user", "incorrect", "неверн", "credentials"]
            .contains { t.contains($0) }
    }

    private func send(_ req: URLRequest) async throws -> (root: XNode?, code: Int, head: String) {
        do {
            let (data, resp) = try await session.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            return (XNode.parse(data), code, String(decoding: data.prefix(200), as: UTF8.self))
        } catch let e as URLError where e.code == .cancelled {
            throw CancellationError()
        } catch let e as URLError {
            throw MailWatch.Failure.network(e.localizedDescription)
        }
    }

    func login(candidates: [String], password: String) async throws {
        guard let loginURL = URL(string: "https://\(host)/XIMSSLogin/") else {
            throw MailWatch.Failure.unavailable("Неверный адрес сервера: \(host)")
        }
        var lastAuth: String?
        for user in candidates {
            let params = [("username", user), ("password", password), ("version", "6.1"), ("errorAsXML", "1")]
            var req = URLRequest(url: loginURL)
            req.httpMethod = "POST"
            req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
            req.httpBody = Data(Self.form(params).utf8)
            var answer = try await send(req)
            let rejected = answer.root?.errorText.map(Self.looksLikeAuth) ?? false
            if answer.root?.sessionID == nil && !rejected {
                // так, как входит сам сайт почты: параметрами в адресе
                var comps = URLComponents(url: loginURL, resolvingAgainstBaseURL: false)
                comps?.percentEncodedQuery = Self.form(params)
                if let u = comps?.url { answer = try await send(URLRequest(url: u)) }
            }
            if let id = answer.root?.sessionID {
                urlID = id
                return
            }
            if let e = answer.root?.errorText {
                if Self.looksLikeAuth(e) { lastAuth = e; continue }
                throw MailWatch.Failure.server(e)
            }
            throw MailWatch.Failure.unavailable("Сайт почты не пустил приложение (HTTP \(answer.code))")
        }
        throw MailWatch.Failure.login(lastAuth ?? "")
    }

    func request(_ xml: String) async throws -> XNode {
        guard let id = urlID else { throw MailWatch.Failure.unavailable("Нет сеанса почты") }
        counter += 1
        guard let url = URL(string: "https://\(host)/Session/\(id)/sync?random=\(counter)") else {
            throw MailWatch.Failure.unavailable("Неверный адрес сеанса")
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.httpBody = Data("<XIMSS>\(xml)</XIMSS>".utf8)
        let answer = try await send(req)
        guard answer.code == 200 else { throw MailWatch.Failure.server("HTTP \(answer.code)") }
        guard let root = answer.root else {
            throw MailWatch.Failure.server("непонятный ответ: \(answer.head.prefix(80))")
        }
        return root
    }

    /// Последние письма «Входящих» (новые сверху), всего писем и непрочитанных — если сервер сообщил
    func inbox(limit: Int) async throws -> (items: [Item], total: Int?, unseen: Int?) {
        let fields = "<field>FLAGS</field><field>From</field><field>Subject</field>"
        var opened: XNode?
        var sorted = false
        var lastErr = ""
        for sort in [" sortField=\"INTERNALDATE\" sortOrder=\"desc\"", " sortField=\"Date\" sortOrder=\"desc\"", ""] {
            let r = try await request("<folderOpen id=\"open\" folder=\"INBOX\" mailbox=\"INBOX\"\(sort)>\(fields)</folderOpen>")
            if let e = r.error(for: "open") { lastErr = e; continue }
            opened = r
            sorted = !sort.isEmpty
            break
        }
        guard let opened else { throw MailWatch.Failure.unavailable("Не открылась папка «Входящие»: \(lastErr)") }
        let head = opened.all("folderReport").first
        let total = head?.attr("messages").flatMap { Int($0) }
        let unseen = head?.attr("unseen").flatMap { Int($0) }
        let n = total ?? limit
        var items: [Item] = []
        if n > 0 {
            let from = sorted ? 0 : max(0, n - limit)
            let till = sorted ? limit - 1 : max(0, n - 1)
            let b = try await request("<folderBrowse id=\"browse\" folder=\"INBOX\"><index from=\"\(from)\" till=\"\(till)\"/></folderBrowse>")
            if let e = b.error(for: "browse") { throw MailWatch.Failure.server(e) }
            items = b.all("folderReport").compactMap(Self.item)
            if !sorted { items.reverse() }
        }
        _ = try? await request("<folderClose id=\"close\" folder=\"INBOX\"/>")
        return (items, total, unseen)
    }

    func bye() async {
        guard urlID != nil else { return }
        _ = try? await request("<bye id=\"bye\"/>")
        urlID = nil
    }

    private static func item(_ n: XNode) -> Item? {
        guard let uid = n.attr("UID").flatMap({ Int($0) }) else { return nil }
        let flags = (n.child("FLAGS")?.fullText ?? "").lowercased()
            .split(whereSeparator: { $0 == "," || $0 == " " })
            .map { $0.trimmingCharacters(in: CharacterSet(charactersIn: "\\ ")) }
        var from = ""
        if let f = n.child("From") ?? n.child("E-From") {
            from = f.attr("realName") ?? f.children.first?.attr("realName") ?? f.fullText
        }
        from = MailWatch.senderName(MailWatch.decodeMIME(from.trimmingCharacters(in: .whitespacesAndNewlines)))
        let subject = MailWatch.decodeMIME((n.child("Subject")?.fullText ?? "").trimmingCharacters(in: .whitespacesAndNewlines))
        return Item(uid: uid, seen: flags.contains("seen"), from: from, subject: subject)
    }
}

/// Маленькое XML-дерево для ответов XIMSS
final class XNode {
    let name: String
    let attrs: [String: String]
    var text = ""
    var children: [XNode] = []

    init(name: String, attrs: [String: String]) {
        self.name = name
        self.attrs = attrs
    }

    func attr(_ key: String) -> String? {
        attrs.first { $0.key.caseInsensitiveCompare(key) == .orderedSame }?.value
    }

    func child(_ n: String) -> XNode? {
        children.first { $0.name.caseInsensitiveCompare(n) == .orderedSame }
    }

    func walk(_ f: (XNode) -> Void) {
        f(self)
        for c in children { c.walk(f) }
    }

    func all(_ n: String) -> [XNode] {
        var out: [XNode] = []
        walk { if $0.name.caseInsensitiveCompare(n) == .orderedSame { out.append($0) } }
        return out
    }

    var fullText: String { text + children.map(\.fullText).joined() }

    var sessionID: String? { all("session").compactMap { $0.attr("urlID") }.first }

    var errorText: String? {
        var e: String?
        walk { if e == nil, let t = $0.attr("errorText"), !t.isEmpty { e = t } }
        return e
    }

    /// Ошибка ответа на запрос с этим id
    func error(for id: String) -> String? {
        all("response").first { $0.attr("id") == id }?.attr("errorText")
    }

    static func parse(_ data: Data) -> XNode? {
        let p = XMLParser(data: data)
        let b = Builder()
        p.delegate = b
        return p.parse() ? b.root : nil
    }

    private final class Builder: NSObject, XMLParserDelegate {
        var root: XNode?
        var stack: [XNode] = []

        func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?,
                    qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
            let n = XNode(name: elementName, attrs: attributeDict)
            if let top = stack.last { top.children.append(n) } else if root == nil { root = n }
            stack.append(n)
        }

        func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
            _ = stack.popLast()
        }

        func parser(_ parser: XMLParser, foundCharacters string: String) {
            stack.last?.text += string
        }

        func parser(_ parser: XMLParser, foundCDATA CDATABlock: Data) {
            stack.last?.text += String(decoding: CDATABlock, as: UTF8.self)
        }
    }
}

// MARK: - Минимальный IMAP-клиент (TLS, порт 993)

final class IMAPConnection {
    enum Reply: Error { case no(String) }

    private let conn: NWConnection
    private var buffer = Data()
    private var counter = 0

    init(host: String, port: Int) {
        let params = NWParameters(tls: NWProtocolTLS.Options())
        conn = NWConnection(host: NWEndpoint.Host(host),
                            port: NWEndpoint.Port(rawValue: UInt16(clamping: port)) ?? 993,
                            using: params)
    }

    static func quote(_ s: String) -> String {
        "\"" + s.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }

    func open() async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            var done = false
            conn.stateUpdateHandler = { state in
                guard !done else { return }
                switch state {
                case .ready:
                    done = true; cont.resume()
                case .failed(let e):
                    done = true; cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription))
                case .waiting(let e):
                    done = true; cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription))
                case .cancelled:
                    done = true; cont.resume(throwing: MailWatch.Failure.network("соединение закрыто"))
                default: break
                }
            }
            conn.start(queue: .global(qos: .utility))
        }
        // приветствие сервера: «* OK …»
        let hello = try await readLine()
        guard hello.hasPrefix("* OK") || hello.hasPrefix("* PREAUTH") else { throw MailWatch.Failure.server(hello) }
    }

    func close() { conn.cancel() }

    /// Отправить команду и дождаться ответа с её меткой. NO/BAD → ошибка
    func command(_ cmd: String, secret: Bool = false) async throws -> String {
        counter += 1
        let tag = "s\(counter)"
        try await send(tag + " " + cmd + "\r\n")
        let text = try await readTagged(tag)
        let last = text.components(separatedBy: "\r\n").last { $0.hasPrefix(tag + " ") } ?? ""
        let status = last.dropFirst(tag.count + 1)
        if status.hasPrefix("OK") { return text }
        let msg = String(status.drop { $0 != " " }).trimmingCharacters(in: .whitespaces)
        if status.hasPrefix("NO") { throw Reply.no(msg) }
        throw MailWatch.Failure.server(secret ? "команда не принята" : msg)
    }

    private func send(_ s: String) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            conn.send(content: Data(s.utf8), completion: .contentProcessed { e in
                if let e { cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription)) } else { cont.resume() }
            })
        }
    }

    private func receive() async throws -> Data {
        try Task.checkCancellation()
        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
            conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { data, _, complete, e in
                if let e { cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription)); return }
                if let data, !data.isEmpty { cont.resume(returning: data); return }
                cont.resume(throwing: MailWatch.Failure.network(complete ? "сервер закрыл соединение" : "пустой ответ"))
            }
        }
    }

    private func readLine() async throws -> String {
        let crlf = Data("\r\n".utf8)
        while buffer.range(of: crlf) == nil { buffer.append(try await receive()) }
        let r = buffer.range(of: crlf)!
        let line = String(decoding: buffer[buffer.startIndex..<r.lowerBound], as: UTF8.self)
        buffer.removeSubrange(buffer.startIndex..<r.upperBound)
        return line
    }

    /// Читаем, пока не придёт строка «<метка> OK/NO/BAD …»
    private func readTagged(_ tag: String) async throws -> String {
        let crlf = Data("\r\n".utf8)
        let prefix = Data((tag + " ").utf8)
        while true {
            var start: Data.Index?
            if buffer.starts(with: prefix) {
                start = buffer.startIndex
            } else if let r = buffer.range(of: crlf + prefix) {
                start = r.lowerBound + 2
            }
            if let st = start, let end = buffer.range(of: crlf, in: st..<buffer.endIndex) {
                let chunk = buffer[buffer.startIndex..<end.upperBound]
                buffer.removeSubrange(buffer.startIndex..<end.upperBound)
                return String(decoding: chunk, as: UTF8.self)
            }
            buffer.append(try await receive())
        }
    }
}

private extension String {
    func firstMatch(_ pattern: String) -> String? {
        guard let rx = try? NSRegularExpression(pattern: pattern),
              let m = rx.firstMatch(in: self, range: NSRange(startIndex..., in: self)),
              m.numberOfRanges > 1, let r = Range(m.range(at: 1), in: self) else { return nil }
        return String(self[r]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Настройки

struct MailNotifyView: View {
    @State private var on = MailWatch.enabled
    @State private var badge = MailWatch.badge
    @State private var login = ""
    @State private var password = ""
    @State private var server = MailWatch.server
    @State private var port = String(MailWatch.port)
    @State private var transport = MailWatch.transport
    @State private var checking = false
    @State private var status: String?
    @State private var good = false
    @State private var steps: [MailWatch.DiagStep] = []
    @State private var diagnosing = false
    @State private var testSent = false
    @State private var bgOff = false
    @State private var notificationsOff = false

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $on) {
                    Label("Уведомлять о новых письмах", systemImage: "envelope.badge.fill")
                }
                .onChange(of: on) { v in
                    if v {
                        MailWatch.enabled = true
                        Task {
                            _ = try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
                            await refreshSystemStatus()
                        }
                        test()
                    } else {
                        MailWatch.disable()
                    }
                }
                Toggle(isOn: $badge) {
                    Label("Цифра непрочитанных на иконке", systemImage: "app.badge")
                }
                .onChange(of: badge) { v in
                    MailWatch.badge = v
                    if !v { UNUserNotificationCenter.current().setBadgeCount(0) }
                }
                if let last = MailWatch.lastCheck {
                    LabeledContent("Последняя проверка", value: Fmt.formatter("d MMM, HH:mm").string(from: last))
                    if MailWatch.lastError == nil {
                        LabeledContent("Непрочитанных", value: "\(MailWatch.unseen)")
                    }
                }
                if let e = MailWatch.lastError {
                    Label(e, systemImage: "exclamationmark.triangle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
            } footer: {
                Text("Пока приложение открыто, почта проверяется каждую минуту. Когда закрыто — iOS сама решает, когда разбудить приложение: обычно раз в 15–60 минут, реже ночью и при низком заряде. Мгновенно, как в мессенджерах, без своего сервера нельзя, а сервер мы не держим: пароль уходит только на почту САФУ.")
            }

            if bgOff || notificationsOff {
                Section {
                    if notificationsOff {
                        Label("Уведомления для САФУ выключены", systemImage: "bell.slash.fill").foregroundStyle(.red)
                    }
                    if bgOff {
                        Label("Фоновое обновление выключено или включён режим энергосбережения — в фоне почта не проверяется",
                              systemImage: "moon.zzz.fill").foregroundStyle(.orange)
                    }
                    Button {
                        if let u = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(u) }
                    } label: {
                        Label("Открыть настройки САФУ", systemImage: "gearshape.fill")
                    }
                }
            }

            Section {
                TextField("Логин (адрес почты САФУ)", text: $login)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.emailAddress)
                    .textContentType(.username)
                SecureField(MailWatch.account == nil ? "Пароль" : "Пароль сохранён — можно не вводить", text: $password)
                    .textContentType(.password)
                if let acc = MailWatch.account, MailWatch.credential == nil {
                    Text("Используется пароль от \(acc.source) — у САФУ это одна учётная запись.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Button {
                    saveCredential()
                    test()
                } label: {
                    HStack {
                        Label("Сохранить и проверить", systemImage: "checkmark.circle.fill")
                        if checking { Spacer(); ProgressView() }
                    }
                }
                .disabled(checking || login.trimmingCharacters(in: .whitespaces).isEmpty)
                if let status {
                    Label(status, systemImage: good ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .font(.subheadline)
                        .foregroundStyle(good ? .green : .orange)
                }
            } header: {
                Text("Вход в почту")
            } footer: {
                Text("Тот же логин и пароль, что на сайте почты edu.narfu.ru. Хранятся в связке ключей iPhone, только на этом телефоне.")
            }

            Section {
                Button {
                    runDiagnostics()
                } label: {
                    HStack {
                        Label("Проверить по шагам", systemImage: "stethoscope")
                        if diagnosing { Spacer(); ProgressView() }
                    }
                }
                .disabled(diagnosing)
                ForEach(steps) { s in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: s.ok == true ? "checkmark.circle.fill" : s.ok == false ? "xmark.octagon.fill" : "info.circle.fill")
                            .foregroundStyle(s.ok == true ? .green : s.ok == false ? .red : .secondary)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(s.title).font(.subheadline.weight(.semibold))
                            Text(s.detail).font(.caption).foregroundStyle(.secondary)
                                .textSelection(.enabled)
                        }
                    }
                    .padding(.vertical, 2)
                }
                Button {
                    MailWatch.sendTestNotification()
                    testSent = true
                    Haptics.success()
                } label: {
                    Label(testSent ? "Отправлено — придёт через 5 секунд" : "Прислать пробное уведомление", systemImage: "bell.badge.fill")
                }
            } header: {
                Text("Если уведомления не приходят")
            } footer: {
                Text("Проверка покажет, на каком шаге проблема. Сделай скриншот и пришли разработчику. Пробное уведомление можно встретить на заблокированном экране — заблокируй телефон сразу после нажатия.")
            }

            Section {
                TextField("Сервер", text: $server)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Picker("Способ", selection: $transport) {
                    ForEach(MailWatch.Transport.allCases) { t in Text(t.title).tag(t) }
                }
                TextField("Порт IMAP", text: $port)
                    .keyboardType(.numberPad)
                Button("Вернуть как было") {
                    server = MailWatch.webHost
                    port = "993"
                    transport = .auto
                }
            } header: {
                Text("Дополнительно")
            } footer: {
                if let via = MailWatch.workedVia, MailWatch.lastError == nil {
                    Text("Сейчас работает способ «\(via.title)». Менять ничего не нужно.")
                } else {
                    Text("Менять не нужно. «Как сайт почты» — тот же протокол, что у edu.narfu.ru, работает везде, где открывается сайт. IMAP — запасной.")
                }
            }
        }
        .navigationTitle("Уведомления почты")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            login = MailWatch.account?.user ?? ""
            Task { await refreshSystemStatus() }
        }
    }

    @MainActor
    private func refreshSystemStatus() async {
        bgOff = UIApplication.shared.backgroundRefreshStatus != .available || ProcessInfo.processInfo.isLowPowerModeEnabled
        let s = await UNUserNotificationCenter.current().notificationSettings()
        notificationsOff = s.authorizationStatus == .denied
    }

    private func applyServerSettings() {
        MailWatch.server = server
        MailWatch.port = Int(port) ?? 993
        MailWatch.transport = transport
    }

    private func saveCredential() {
        let user = login.trimmingCharacters(in: .whitespaces)
        let pass = password.isEmpty ? (MailWatch.account?.pass ?? "") : password
        guard !user.isEmpty, !pass.isEmpty else { return }
        CredentialStore.save(SiteCredential(host: MailWatch.webHost, user: user, pass: pass))
        password = ""
    }

    private func test() {
        applyServerSettings()
        checking = true
        status = nil
        Task {
            do {
                let r = try await MailWatch.check(notify: false)
                await MainActor.run {
                    good = true
                    status = "Работает (\(r.via.title.lowercased())). Непрочитанных: \(r.unseen). О новых письмах придёт уведомление."
                }
            } catch {
                await MainActor.run {
                    good = false
                    status = error.localizedDescription + " Нажми «Проверить по шагам» ниже."
                }
            }
            await MainActor.run { checking = false }
        }
    }

    private func runDiagnostics() {
        applyServerSettings()
        diagnosing = true
        steps = []
        Task {
            let result = await MailWatch.diagnose()
            await MainActor.run {
                steps = result
                diagnosing = false
            }
            await refreshSystemStatus()
        }
    }
}
