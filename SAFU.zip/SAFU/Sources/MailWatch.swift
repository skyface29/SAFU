import SwiftUI
import Network
import UserNotifications

// MARK: - Уведомления о новых письмах в почте САФУ
// У университетской почты (Samoware) нет своего приложения с уведомлениями.
// Приложение само заглядывает в ящик по IMAP — напрямую на сервер университета, без посредников, —
// и если пришло новое письмо, показывает уведомление: от кого и тема.
// Логин и пароль — те же, что сохранены для почты в приложении (связка ключей iPhone).
// Письма не скачиваются и не помечаются прочитанными: смотрим только «от кого» и «тема».

enum MailWatch {
    /// Сайт почты: для него сохранён логин и пароль
    static let webHost = "edu.narfu.ru"

    private static let d = UserDefaults.standard
    static var enabled: Bool {
        get { d.bool(forKey: "mail.notify") }
        set { d.set(newValue, forKey: "mail.notify") }
    }
    static var badge: Bool {
        get { d.object(forKey: "mail.badge") as? Bool ?? true }
        set { d.set(newValue, forKey: "mail.badge") }
    }
    static var server: String {
        get { (d.string(forKey: "mail.server") ?? "").isEmpty ? webHost : d.string(forKey: "mail.server")! }
        set { d.set(newValue.trimmingCharacters(in: .whitespaces), forKey: "mail.server") }
    }
    static var port: Int {
        get { d.integer(forKey: "mail.port") > 0 ? d.integer(forKey: "mail.port") : 993 }
        set { d.set(newValue, forKey: "mail.port") }
    }
    /// Последнее письмо, о котором уже сказали (номер письма на сервере)
    private static var lastUID: Int {
        get { d.integer(forKey: "mail.lastUID") }
        set { d.set(newValue, forKey: "mail.lastUID") }
    }
    private static var uidValidity: Int {
        get { d.integer(forKey: "mail.uidValidity") }
        set { d.set(newValue, forKey: "mail.uidValidity") }
    }
    static var unseen: Int {
        get { d.integer(forKey: "mail.unseen") }
        set { d.set(newValue, forKey: "mail.unseen") }
    }
    static var lastCheck: Date? {
        let t = d.double(forKey: "mail.lastCheck")
        return t > 0 ? Date(timeIntervalSince1970: t) : nil
    }
    static var lastError: String? {
        get { d.string(forKey: "mail.lastError") }
        set { d.set(newValue, forKey: "mail.lastError") }
    }

    static var credential: SiteCredential? { CredentialStore.get(webHost) }

    struct Message { let uid: Int; let from: String; let subject: String }
    struct Report { let unseen: Int; let fresh: [Message] }

    enum Failure: LocalizedError {
        case noPassword, network(String), login(String), server(String), timeout
        var errorDescription: String? {
            switch self {
            case .noPassword: return "Нет сохранённого пароля от почты. Открой почту в приложении, войди и сохрани пароль — или введи его здесь."
            case .network(let s): return "Нет связи с сервером почты: \(s)"
            case .login(let s): return "Сервер не принял логин или пароль. \(s)"
            case .server(let s): return "Сервер ответил ошибкой: \(s)"
            case .timeout: return "Сервер почты не ответил вовремя"
            }
        }
    }

    /// Не чаще раза в 50 секунд — и приложение, и фон могут позвать одновременно
    private static let gate = NSLock()
    private static var running = false

    /// Проверить, если уведомления включены. Ошибки запоминаются и видны в настройках
    static func checkIfEnabled() async {
        guard enabled else { return }
        if let last = lastCheck, Date().timeIntervalSince(last) < 50 { return }
        _ = try? await check()
    }

    /// Заглянуть в ящик. notify — показать уведомления о новых письмах
    @discardableResult
    static func check(notify: Bool = true) async throws -> Report {
        gate.lock()
        if running { gate.unlock(); return Report(unseen: unseen, fresh: []) }
        running = true
        gate.unlock()
        defer { gate.lock(); running = false; gate.unlock() }

        do {
            let r = try await withTimeout(30) { try await fetch() }
            d.set(Date().timeIntervalSince1970, forKey: "mail.lastCheck")
            lastError = nil
            unseen = r.unseen
            if notify { post(r.fresh) }
            if badge { try? await UNUserNotificationCenter.current().setBadgeCount(r.unseen) }
            return r
        } catch {
            d.set(Date().timeIntervalSince1970, forKey: "mail.lastCheck")
            lastError = error.localizedDescription
            throw error
        }
    }

    /// Выключили уведомления — убираем цифру с иконки
    static func disable() {
        enabled = false
        UNUserNotificationCenter.current().setBadgeCount(0)
    }

    // MARK: Разговор с сервером

    private static func fetch() async throws -> Report {
        guard let cred = credential, !cred.pass.isEmpty else { throw Failure.noPassword }
        let imap = IMAPConnection(host: server, port: port)
        defer { imap.close() }
        // время вышло — рвём соединение, иначе ожидание ответа сервера не прервать
        return try await withTaskCancellationHandler {
            try await session(imap, cred)
        } onCancel: {
            imap.close()
        }
    }

    private static func session(_ imap: IMAPConnection, _ cred: SiteCredential) async throws -> Report {
        try await imap.open()

        // логин как сохранён; не подошёл и в нём нет «@» — пробуем полный адрес
        var logins = [cred.user.trimmingCharacters(in: .whitespaces)]
        if !logins[0].contains("@") { logins.append(logins[0] + "@" + webHost) }
        var lastNo = ""
        var ok = false
        for l in logins {
            do {
                _ = try await imap.command("LOGIN \(IMAPConnection.quote(l)) \(IMAPConnection.quote(cred.pass))", secret: true)
                ok = true
                break
            } catch IMAPConnection.Reply.no(let text) {
                lastNo = text
            }
        }
        guard ok else { throw Failure.login(lastNo) }

        // только чтение: письма не помечаются прочитанными
        let sel = try await imap.command("EXAMINE INBOX")
        let validity = Int(sel.firstMatch(#"UIDVALIDITY (\d+)"#) ?? "") ?? 0
        let uidNext = Int(sel.firstMatch(#"UIDNEXT (\d+)"#) ?? "") ?? 0

        let search = try await imap.command("UID SEARCH UNSEEN")
        let unseenUIDs = search.components(separatedBy: "\r\n")
            .filter { $0.hasPrefix("* SEARCH") }
            .flatMap { $0.dropFirst(8).split(separator: " ").compactMap { Int($0) } }
            .sorted()

        let maxKnown = max(unseenUIDs.last ?? 0, uidNext - 1)
        var fresh: [Message] = []
        if lastUID > 0 && validity == uidValidity {
            let newUIDs = unseenUIDs.filter { $0 > lastUID }.suffix(5)
            if !newUIDs.isEmpty {
                let resp = try await imap.command("UID FETCH \(newUIDs.map(String.init).joined(separator: ",")) (UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])")
                fresh = parseFetch(resp).sorted { $0.uid < $1.uid }
                // заголовки не пришли — всё равно скажем, что письмо есть
                if fresh.isEmpty { fresh = newUIDs.map { Message(uid: $0, from: "Почта САФУ", subject: "Новое письмо") } }
            }
        }
        // первый раз (или ящик пересоздан) — просто запоминаем, где мы, без потока старых уведомлений
        uidValidity = validity
        lastUID = max(lastUID, maxKnown)
        _ = try? await imap.command("LOGOUT")
        return Report(unseen: unseenUIDs.count, fresh: fresh)
    }

    /// Ответ на FETCH → письма (от кого и тема)
    static func parseFetch(_ text: String) -> [Message] {
        var out: [Message] = []
        let blocks = text.components(separatedBy: "\r\n* ").dropFirst(text.hasPrefix("* ") ? 0 : 1)
        for raw in blocks {
            let b = raw.hasPrefix("* ") ? String(raw.dropFirst(2)) : raw
            guard b.range(of: #"^\d+ FETCH"#, options: .regularExpression) != nil,
                  let uid = Int(b.firstMatch(#"UID (\d+)"#) ?? "") else { continue }
            let headers = unfold(b)
            let from = headers.firstMatch(#"(?im)^From:\s*(.*)$"#).map { senderName(decodeMIME($0)) } ?? ""
            let subject = headers.firstMatch(#"(?im)^Subject:\s*(.*)$"#).map { decodeMIME($0) } ?? ""
            out.append(Message(uid: uid,
                               from: from.isEmpty ? "Почта САФУ" : from,
                               subject: subject.isEmpty ? "(без темы)" : subject))
        }
        return out
    }

    /// Длинные заголовки переносятся на следующую строку с пробелом в начале — склеиваем
    private static func unfold(_ s: String) -> String {
        s.replacingOccurrences(of: #"\r?\n[ \t]+"#, with: " ", options: .regularExpression)
    }

    /// «"Иванов И. И." <ivanov@narfu.ru>» → «Иванов И. И.»
    static func senderName(_ from: String) -> String {
        let f = from.trimmingCharacters(in: .whitespaces)
        if let lt = f.firstIndex(of: "<") {
            let name = f[..<lt].trimmingCharacters(in: CharacterSet(charactersIn: " \""))
            if !name.isEmpty { return name }
            return f[f.index(after: lt)...].trimmingCharacters(in: CharacterSet(charactersIn: "> "))
        }
        return f.trimmingCharacters(in: CharacterSet(charactersIn: "\""))
    }

    /// Русские темы приходят закодированными: =?UTF-8?B?0J/RgNC40LLQtdGC?=
    static func decodeMIME(_ s: String) -> String {
        let pattern = #"=\?([^?]+)\?([bBqQ])\?([^?]*)\?="#
        guard let rx = try? NSRegularExpression(pattern: pattern) else { return s }
        // пробелы между двумя закодированными кусками не считаются
        let joined = s.replacingOccurrences(of: #"(\?=)\s+(=\?)"#, with: "$1$2", options: .regularExpression)
        let ns = joined as NSString
        var result = ""
        var pos = 0
        for m in rx.matches(in: joined, range: NSRange(location: 0, length: ns.length)) {
            result += ns.substring(with: NSRange(location: pos, length: m.range.location - pos))
            let charset = ns.substring(with: m.range(at: 1))
            let kind = ns.substring(with: m.range(at: 2)).uppercased()
            let body = ns.substring(with: m.range(at: 3))
            var bytes: Data?
            if kind == "B" {
                var b64 = body
                while b64.count % 4 != 0 { b64 += "=" }
                bytes = Data(base64Encoded: b64)
            } else {
                var data = Data()
                var chars = Array(body.replacingOccurrences(of: "_", with: " ").utf8)[...]
                while let c = chars.popFirst() {
                    if c == UInt8(ascii: "="), chars.count >= 2,
                       let v = UInt8(String(decoding: chars.prefix(2), as: UTF8.self), radix: 16) {
                        data.append(v)
                        chars = chars.dropFirst(2)
                    } else {
                        data.append(c)
                    }
                }
                bytes = data
            }
            let cf = CFStringConvertIANACharSetNameToEncoding(charset as CFString)
            let enc = cf == kCFStringEncodingInvalidId ? String.Encoding.utf8
                : String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(cf))
            result += bytes.flatMap { String(data: $0, encoding: enc) } ?? ns.substring(with: m.range)
            pos = m.range.location + m.range.length
        }
        result += ns.substring(from: pos)
        return result.trimmingCharacters(in: .whitespaces)
    }

    // MARK: Уведомления

    private static func post(_ list: [Message]) {
        let center = UNUserNotificationCenter.current()
        for m in list.suffix(3) {
            let c = UNMutableNotificationContent()
            c.title = m.from
            c.body = m.subject
            c.sound = .default
            c.threadIdentifier = "mail"
            c.userInfo = [MailRouter.key: true]
            center.add(UNNotificationRequest(identifier: "mail.\(m.uid)", content: c, trigger: nil))
        }
        if list.count > 3 {
            let c = UNMutableNotificationContent()
            c.title = "Почта САФУ"
            c.body = "И ещё \(list.count - 3) новых писем"
            c.threadIdentifier = "mail"
            c.userInfo = [MailRouter.key: true]
            center.add(UNNotificationRequest(identifier: "mail.more.\(list.last?.uid ?? 0)", content: c, trigger: nil))
        }
    }

    private static func withTimeout<T>(_ seconds: Double, _ op: @escaping () async throws -> T) async throws -> T {
        try await withThrowingTaskGroup(of: T.self) { g in
            g.addTask { try await op() }
            g.addTask {
                try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                throw Failure.timeout
            }
            defer { g.cancelAll() }
            guard let first = try await g.next() else { throw Failure.timeout }
            return first
        }
    }
}

/// Нажали на уведомление о письме — открываем почту
final class MailRouter: ObservableObject {
    static let shared = MailRouter()
    static let key = "safu.mail"
    /// Ждёт, пока главная откроет почту (главная могла ещё не загрузиться)
    @Published var pending = false
}

// MARK: - Минимальный IMAP-клиент (TLS, порт 993)

final class IMAPConnection {
    enum Reply: Error { case no(String) }

    private let conn: NWConnection
    private var buffer = Data()
    private var counter = 0

    init(host: String, port: Int) {
        let params = NWParameters(tls: NWProtocolTLS.Options())
        conn = NWConnection(host: NWEndpoint.Host(host),
                            port: NWEndpoint.Port(rawValue: UInt16(clamping: port)) ?? 993,
                            using: params)
    }

    static func quote(_ s: String) -> String {
        "\"" + s.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }

    func open() async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            var done = false
            conn.stateUpdateHandler = { state in
                guard !done else { return }
                switch state {
                case .ready:
                    done = true; cont.resume()
                case .failed(let e):
                    done = true; cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription))
                case .waiting(let e):
                    done = true; cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription))
                case .cancelled:
                    done = true; cont.resume(throwing: MailWatch.Failure.network("соединение закрыто"))
                default: break
                }
            }
            conn.start(queue: .global(qos: .utility))
        }
        // приветствие сервера: «* OK …»
        let hello = try await readLine()
        guard hello.hasPrefix("* OK") || hello.hasPrefix("* PREAUTH") else { throw MailWatch.Failure.server(hello) }
    }

    func close() { conn.cancel() }

    /// Отправить команду и дождаться ответа с её меткой. NO/BAD → ошибка
    func command(_ cmd: String, secret: Bool = false) async throws -> String {
        counter += 1
        let tag = "s\(counter)"
        try await send(tag + " " + cmd + "\r\n")
        let text = try await readTagged(tag)
        let last = text.components(separatedBy: "\r\n").last { $0.hasPrefix(tag + " ") } ?? ""
        let status = last.dropFirst(tag.count + 1)
        if status.hasPrefix("OK") { return text }
        let msg = String(status.drop { $0 != " " }).trimmingCharacters(in: .whitespaces)
        if status.hasPrefix("NO") { throw Reply.no(msg) }
        throw MailWatch.Failure.server(secret ? "команда не принята" : msg)
    }

    private func send(_ s: String) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            conn.send(content: Data(s.utf8), completion: .contentProcessed { e in
                if let e { cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription)) } else { cont.resume() }
            })
        }
    }

    private func receive() async throws -> Data {
        try Task.checkCancellation()
        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Data, Error>) in
            conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { data, _, complete, e in
                if let e { cont.resume(throwing: MailWatch.Failure.network(e.localizedDescription)); return }
                if let data, !data.isEmpty { cont.resume(returning: data); return }
                cont.resume(throwing: MailWatch.Failure.network(complete ? "сервер закрыл соединение" : "пустой ответ"))
            }
        }
    }

    private func readLine() async throws -> String {
        let crlf = Data("\r\n".utf8)
        while buffer.range(of: crlf) == nil { buffer.append(try await receive()) }
        let r = buffer.range(of: crlf)!
        let line = String(decoding: buffer[buffer.startIndex..<r.lowerBound], as: UTF8.self)
        buffer.removeSubrange(buffer.startIndex..<r.upperBound)
        return line
    }

    /// Читаем, пока не придёт строка «<метка> OK/NO/BAD …»
    private func readTagged(_ tag: String) async throws -> String {
        let crlf = Data("\r\n".utf8)
        let prefix = Data((tag + " ").utf8)
        while true {
            var start: Data.Index?
            if buffer.starts(with: prefix) {
                start = buffer.startIndex
            } else if let r = buffer.range(of: crlf + prefix) {
                start = r.lowerBound + 2
            }
            if let st = start, let end = buffer.range(of: crlf, in: st..<buffer.endIndex) {
                let chunk = buffer[buffer.startIndex..<end.upperBound]
                buffer.removeSubrange(buffer.startIndex..<end.upperBound)
                return String(decoding: chunk, as: UTF8.self)
            }
            buffer.append(try await receive())
        }
    }
}

private extension String {
    func firstMatch(_ pattern: String) -> String? {
        guard let rx = try? NSRegularExpression(pattern: pattern),
              let m = rx.firstMatch(in: self, range: NSRange(startIndex..., in: self)),
              m.numberOfRanges > 1, let r = Range(m.range(at: 1), in: self) else { return nil }
        return String(self[r]).trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Настройки

struct MailNotifyView: View {
    @State private var on = MailWatch.enabled
    @State private var badge = MailWatch.badge
    @State private var login = ""
    @State private var password = ""
    @State private var server = MailWatch.server
    @State private var port = String(MailWatch.port)
    @State private var checking = false
    @State private var status: String?
    @State private var good = false

    var body: some View {
        Form {
            Section {
                Toggle(isOn: $on) {
                    Label("Уведомлять о новых письмах", systemImage: "envelope.badge.fill")
                }
                .onChange(of: on) { v in
                    if v {
                        Notifier.requestAuthorization()
                        MailWatch.enabled = true
                        test()
                    } else {
                        MailWatch.disable()
                    }
                }
                Toggle(isOn: $badge) {
                    Label("Цифра непрочитанных на иконке", systemImage: "app.badge")
                }
                .onChange(of: badge) { v in
                    MailWatch.badge = v
                    if !v { UNUserNotificationCenter.current().setBadgeCount(0) }
                }
            } footer: {
                Text("Пока приложение открыто, почта проверяется каждую минуту. В фоне iOS сама решает, когда разбудить приложение: обычно раз в 15–60 минут, реже — если батарея садится. Мгновенных уведомлений без своего сервера не бывает, а сервер мы не держим: пароль никуда, кроме почты САФУ, не уходит.")
            }

            Section {
                TextField("Логин (как на сайте почты)", text: $login)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textContentType(.username)
                SecureField(MailWatch.credential == nil ? "Пароль" : "Пароль сохранён — можно не вводить", text: $password)
                    .textContentType(.password)
                Button {
                    saveCredential()
                    test()
                } label: {
                    HStack {
                        Label("Сохранить и проверить", systemImage: "checkmark.circle.fill")
                        if checking { Spacer(); ProgressView() }
                    }
                }
                .disabled(checking || login.trimmingCharacters(in: .whitespaces).isEmpty)
                if let status {
                    Label(status, systemImage: good ? "checkmark.seal.fill" : "exclamationmark.triangle.fill")
                        .font(.subheadline)
                        .foregroundStyle(good ? .green : .orange)
                }
            } header: {
                Text("Вход в почту")
            } footer: {
                Text("Это тот же логин и пароль, что для почты на edu.narfu.ru. Хранятся в связке ключей iPhone, только на этом телефоне.")
            }

            Section {
                TextField("Сервер", text: $server)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                TextField("Порт", text: $port)
                    .keyboardType(.numberPad)
                Button("Вернуть как было") {
                    server = MailWatch.webHost
                    port = "993"
                }
            } header: {
                Text("Сервер IMAP")
            } footer: {
                Text("Менять не нужно. Если проверка не проходит — узнай в поддержке САФУ адрес IMAP-сервера студенческой почты и впиши сюда.")
            }

            if let last = MailWatch.lastCheck {
                Section {
                    LabeledContent("Проверено", value: Fmt.formatter("d MMM, HH:mm").string(from: last))
                    LabeledContent("Непрочитанных", value: "\(MailWatch.unseen)")
                    if let e = MailWatch.lastError { Text(e).font(.caption).foregroundStyle(.secondary) }
                }
            }
        }
        .navigationTitle("Уведомления почты")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            login = MailWatch.credential?.user ?? ""
        }
    }

    private func saveCredential() {
        let user = login.trimmingCharacters(in: .whitespaces)
        let pass = password.isEmpty ? (MailWatch.credential?.pass ?? "") : password
        guard !user.isEmpty, !pass.isEmpty else { return }
        CredentialStore.save(SiteCredential(host: MailWatch.webHost, user: user, pass: pass))
        password = ""
    }

    private func test() {
        MailWatch.server = server
        MailWatch.port = Int(port) ?? 993
        checking = true
        status = nil
        Task {
            do {
                let r = try await MailWatch.check(notify: false)
                await MainActor.run {
                    good = true
                    status = "Работает. Непрочитанных писем: \(r.unseen). О новых письмах придёт уведомление."
                }
            } catch {
                await MainActor.run {
                    good = false
                    status = error.localizedDescription
                }
            }
            await MainActor.run { checking = false }
        }
    }
}
