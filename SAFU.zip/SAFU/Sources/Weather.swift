import SwiftUI
import CoreLocation

// MARK: - Погода к выезду
// Прогноз по часам с Open-Meteo (бесплатно, без ключа). Показываем погоду на время автобуса
// и короткий совет: мороз, снег, ветер. Прогноз кешируется на час.

struct WeatherHour: Codable, Hashable {
    let time: Date
    let temp: Double
    let feels: Double
    let wind: Double
    let precip: Double
    let code: Int
}

enum WeatherCache {
    private struct Blob: Codable {
        var hours: [WeatherHour]
        var fetchedAt: Date
        var city: String
    }
    private static let key = "weather.cache"

    static func load() -> (hours: [WeatherHour], fetchedAt: Date?, city: String) {
        guard let raw = UserDefaults.standard.data(forKey: key),
              let b = try? JSONDecoder().decode(Blob.self, from: raw) else { return ([], nil, "") }
        return (b.hours, b.fetchedAt, b.city)
    }

    static func save(_ hours: [WeatherHour], city: String) {
        if let raw = try? JSONEncoder().encode(Blob(hours: hours, fetchedAt: Date(), city: city)) {
            UserDefaults.standard.set(raw, forKey: key)
        }
    }

    /// Час прогноза, ближайший к моменту (не дальше 90 минут)
    static func hour(at date: Date, in hours: [WeatherHour]) -> WeatherHour? {
        guard let best = hours.min(by: { abs($0.time.timeIntervalSince(date)) < abs($1.time.timeIntervalSince(date)) }),
              abs(best.time.timeIntervalSince(date)) <= 90 * 60 else { return nil }
        return best
    }

    /// Для уведомлений — из кеша, без сети
    static func cachedHour(at date: Date) -> WeatherHour? { hour(at: date, in: load().hours) }

    static func emoji(_ code: Int) -> String {
        switch code {
        case 0: return "☀️"
        case 1, 2: return "🌤"
        case 3: return "☁️"
        case 45, 48: return "🌫"
        case 51...67, 80...82: return "🌧"
        case 71...77, 85, 86: return "🌨"
        case 95...99: return "⛈"
        default: return "🌡"
        }
    }

    static func deg(_ v: Double) -> String {
        let r = Int(v.rounded())
        return r < 0 ? "−\(-r)°" : "\(r)°"
    }

    /// «🌨 −18° · ощущается −26° · ветер 9 м/с»
    static func line(_ h: WeatherHour) -> String {
        var s = "\(emoji(h.code)) \(deg(h.temp))"
        if abs(h.feels - h.temp) >= 3 { s += " · ощущается \(deg(h.feels))" }
        if h.wind >= 5 { s += " · ветер \(Int(h.wind.rounded())) м/с" }
        return s
    }

    /// Короткий совет или nil, если погода обычная
    static func advice(_ h: WeatherHour) -> String? {
        var parts: [String] = []
        if h.feels <= -25 {
            parts.append("Лютый мороз: выходи на пару минут раньше, автобус может опоздать")
        } else if h.feels <= -15 {
            parts.append("Морозно: шапка, шарф, перчатки")
        } else if h.feels <= -5 {
            parts.append("Холодно, оденься потеплее")
        }
        switch h.code {
        case 71...77, 85, 86:
            parts.append(h.precip >= 1 ? "Сильный снег — в дороге может быть медленно" : "Идёт снег")
        case 51...67, 80...82:
            parts.append("Дождь — возьми зонт")
        case 95...99:
            parts.append("Гроза")
        default:
            break
        }
        if h.wind >= 12 { parts.append("Сильный ветер") }
        return parts.isEmpty ? nil : parts.joined(separator: ". ")
    }
}

@MainActor
final class WeatherStore: ObservableObject {
    static let shared = WeatherStore()

    @Published private(set) var hours: [WeatherHour]
    private var fetchedAt: Date?
    private var city: String
    private var loading = false

    init() {
        let c = WeatherCache.load()
        hours = c.hours
        fetchedAt = c.fetchedAt
        city = c.city
    }

    func hour(at date: Date) -> WeatherHour? { WeatherCache.hour(at: date, in: hours) }

    func refresh(city c: HomeCity?) async {
        let place = c ?? .arkhangelsk
        if let f = fetchedAt, city == place.rawValue, Date().timeIntervalSince(f) < 60 * 60 { return }
        guard !loading else { return }
        loading = true
        defer { loading = false }
        let loc = place == .arkhangelsk ? HomeCity.arkhCenter : HomeCity.sevCenter
        let lat = loc.coordinate.latitude, lon = loc.coordinate.longitude
        let s = "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)"
            + "&hourly=temperature_2m,apparent_temperature,wind_speed_10m,precipitation,weather_code"
            + "&wind_speed_unit=ms&timezone=auto&forecast_days=3&timeformat=unixtime"
        guard let url = URL(string: s) else { return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 15
        guard let pair = try? await URLSession.shared.data(for: req),
              (pair.1 as? HTTPURLResponse)?.statusCode == 200,
              let obj = try? JSONSerialization.jsonObject(with: pair.0) as? [String: Any],
              let hourly = obj["hourly"] as? [String: Any],
              let times = hourly["time"] as? [Any] else { return }

        func col(_ k: String) -> [Double?] {
            ((hourly[k] as? [Any]) ?? []).map { v -> Double? in
                if let d = v as? Double { return d }
                if let i = v as? Int { return Double(i) }
                return nil
            }
        }
        let temp = col("temperature_2m"), feels = col("apparent_temperature"),
            wind = col("wind_speed_10m"), precip = col("precipitation"), code = col("weather_code")
        var out: [WeatherHour] = []
        for (i, t) in times.enumerated() {
            let ts: Double
            if let d = t as? Double { ts = d } else if let n = t as? Int { ts = Double(n) } else { continue }
            guard i < temp.count, let tv = temp[i] else { continue }
            out.append(WeatherHour(time: Date(timeIntervalSince1970: ts), temp: tv,
                                   feels: (i < feels.count ? feels[i] : nil) ?? tv,
                                   wind: (i < wind.count ? wind[i] : nil) ?? 0,
                                   precip: (i < precip.count ? precip[i] : nil) ?? 0,
                                   code: Int((i < code.count ? code[i] : nil) ?? 0)))
        }
        guard !out.isEmpty else { return }
        hours = out
        fetchedAt = Date()
        city = place.rawValue
        WeatherCache.save(out, city: place.rawValue)
    }
}

/// Строка погоды на время автобуса — для карточки «Дорога»
struct CommuteWeatherLine: View {
    let hour: WeatherHour

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(WeatherCache.line(hour))
                .font(.caption.weight(.bold))
            if let a = WeatherCache.advice(hour) {
                Text(a)
                    .font(.caption)
                    .foregroundStyle(hour.feels <= -25 ? Color.orange : Color.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}
