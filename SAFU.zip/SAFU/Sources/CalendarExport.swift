import Foundation
import EventKit
import UIKit

enum CalendarExporter {
    static let calendarTitle = "САФУ · Пары"

    enum ExportError: LocalizedError {
        case denied, noSource
        var errorDescription: String? {
            switch self {
            case .denied: return "Нет доступа к календарю. Разреши его в Настройках → САФУ."
            case .noSource: return "Не нашёл, где создать календарь."
            }
        }
    }

    static func export(data: ScheduleData, weeks: Int, alert: Bool) async throws -> Int {
        let store = EKEventStore()
        let granted: Bool
        if #available(iOS 17.0, *) {
            granted = try await store.requestFullAccessToEvents()
        } else {
            granted = try await store.requestAccess(to: .event)
        }
        guard granted else { throw ExportError.denied }

        // Старый календарь с парами удаляем, чтобы не было дублей
        for cal in store.calendars(for: .event) where cal.title == calendarTitle {
            try? store.removeCalendar(cal, commit: true)
        }

        let calendar = EKCalendar(for: .event, eventStore: store)
        calendar.title = calendarTitle
        calendar.cgColor = UIColor.systemBlue.cgColor
        guard let source = store.defaultCalendarForNewEvents?.source
                ?? store.sources.first(where: { $0.sourceType == .local })
                ?? store.sources.first else {
            throw ExportError.noSource
        }
        calendar.source = source
        try store.saveCalendar(calendar, commit: true)

        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        var count = 0
        for offset in 0..<(weeks * 7) {
            guard let day = cal.date(byAdding: .day, value: offset, to: today) else { continue }
            for s in ScheduleEngine.slots(on: day, data: data) {
                let ev = EKEvent(eventStore: store)
                ev.calendar = calendar
                ev.title = s.lesson.subject
                ev.startDate = s.start
                ev.endDate = s.end
                var place: [String] = []
                if !s.lesson.room.isEmpty { place.append("ауд. \(s.lesson.room)") }
                if !s.address.isEmpty { place.append(s.address) }
                ev.location = place.joined(separator: ", ")
                ev.notes = [s.lesson.kind, s.lesson.teacher].filter { !$0.isEmpty }.joined(separator: "\n")
                if alert { ev.addAlarm(EKAlarm(relativeOffset: -15 * 60)) }
                try store.save(ev, span: .thisEvent, commit: false)
                count += 1
            }
        }
        try store.commit()
        return count
    }
}
