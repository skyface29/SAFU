import SwiftUI
import UIKit

// MARK: - Тема

enum AccentTheme: String, CaseIterable, Identifiable {
    case blue, violet, teal, orange, pink

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .blue: return Color(red: 0.16, green: 0.45, blue: 0.98)
        case .violet: return Color(red: 0.52, green: 0.35, blue: 0.98)
        case .teal: return Color(red: 0.10, green: 0.68, blue: 0.66)
        case .orange: return Color(red: 0.98, green: 0.50, blue: 0.18)
        case .pink: return Color(red: 0.95, green: 0.30, blue: 0.55)
        }
    }

    var secondary: Color {
        switch self {
        case .blue: return Color(red: 0.30, green: 0.80, blue: 0.98)
        case .violet: return Color(red: 0.90, green: 0.40, blue: 0.90)
        case .teal: return Color(red: 0.35, green: 0.85, blue: 0.45)
        case .orange: return Color(red: 0.98, green: 0.78, blue: 0.25)
        case .pink: return Color(red: 0.98, green: 0.55, blue: 0.40)
        }
    }

    static var current: AccentTheme {
        AccentTheme(rawValue: UserDefaults.standard.string(forKey: "theme") ?? "") ?? .blue
    }
}

extension Color {
    static var brand: Color { AccentTheme.current.color }
    static var brand2: Color { AccentTheme.current.secondary }
}

var brandGradient: LinearGradient {
    LinearGradient(colors: [.brand, .brand2], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Живой фон

struct AmbientBackground: View {
    @State private var move = false
    @AppStorage("ambient") private var animated = true

    var body: some View {
        ZStack {
            Color(.systemBackground)
            Circle()
                .fill(Color.brand.opacity(0.35))
                .frame(width: 340, height: 340)
                .blur(radius: 90)
                .offset(x: move ? -120 : 90, y: move ? -300 : -180)
            Circle()
                .fill(Color.brand2.opacity(0.25))
                .frame(width: 280, height: 280)
                .blur(radius: 90)
                .offset(x: move ? 130 : -80, y: move ? 120 : 300)
            Circle()
                .fill(Color.brand.opacity(0.18))
                .frame(width: 260, height: 260)
                .blur(radius: 100)
                .offset(x: move ? 60 : 150, y: move ? 420 : -40)
        }
        .ignoresSafeArea()
        .onAppear {
            guard animated else { return }
            withAnimation(.easeInOut(duration: 14).repeatForever(autoreverses: true)) {
                move = true
            }
        }
    }
}

// MARK: - Стекло (на iOS 26 — настоящее Liquid Glass)

struct GlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool
    @AppStorage("cardStyle") private var cardStyle = 0

    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        if cardStyle == 1 {
            content
                .background(Color(.secondarySystemBackground), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.6))
        } else if cardStyle == 2 {
            content
                .background(Color.brand.opacity(0.14), in: shape)
                .overlay(shape.strokeBorder(Color.brand.opacity(0.25), lineWidth: 0.8))
        } else {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            if interactive {
                content.glassEffect(.regular.interactive(), in: shape)
            } else {
                content.glassEffect(.regular, in: shape)
            }
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        }
        #else
        content
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        #endif
        }
    }
}

struct TabBarMinimize: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(.onScrollDown)
        } else {
            content
        }
        #else
        content
        #endif
    }
}

extension View {
    func glass(_ radius: CGFloat = 24, interactive: Bool = false) -> some View {
        modifier(GlassModifier(radius: radius, interactive: interactive))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

// MARK: - Мелкие компоненты

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct ScreenHeader<Trailing: View>: View {
    let caption: String
    let title: String
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text(caption)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                Text(title)
                    .font(.system(size: 34, weight: .bold, design: .rounded))
            }
            Spacer()
            trailing()
        }
    }
}

struct CircleIconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .glass(22, interactive: true)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .glass(26)
    }
}

// MARK: - Вибрация и форматирование

enum Haptics {
    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true
    }
    static func tap() {
        guard enabled else { return }
        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
    }
    static func success() {
        guard enabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

enum Fmt {
    private static let ru = Locale(identifier: "ru_RU")

    static func relative(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.locale = ru
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }

    static func due(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "d MMM, HH:mm"
        return f.string(from: date)
    }

    static func today() -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "EEEE, d MMMM"
        return f.string(from: Date())
    }

    static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }
}


// MARK: - Анимации и цвета предметов

enum Prefs {
    static var animations: Bool { UserDefaults.standard.object(forKey: "animations") as? Bool ?? true }
}

struct PulsingDot: View {
    var color: Color = .brand
    @State private var on = false

    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(0.4))
                .frame(width: 16, height: 16)
                .scaleEffect(on ? 1.7 : 0.6)
                .opacity(on ? 0 : 1)
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
        }
        .frame(width: 18, height: 18)
        .onAppear {
            guard Prefs.animations else { return }
            withAnimation(.easeOut(duration: 1.3).repeatForever(autoreverses: false)) { on = true }
        }
    }
}

struct SpinningIcon: View {
    let spinning: Bool
    @State private var angle: Double = 0

    var body: some View {
        Image(systemName: "arrow.triangle.2.circlepath")
            .rotationEffect(.degrees(angle))
            .onAppear { start() }
            .onChange(of: spinning) { _ in start() }
    }

    private func start() {
        if spinning {
            withAnimation(.linear(duration: 1).repeatForever(autoreverses: false)) { angle = 360 }
        } else {
            withAnimation(.default) { angle = 0 }
        }
    }
}

enum SubjectColor {
    static func color(for subject: String) -> Color {
        guard UserDefaults.standard.object(forKey: "schedule.colors") as? Bool ?? true else { return .brand }
        var h: UInt64 = 5381
        for u in subject.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.55, brightness: 0.92)
    }
}

/// Плавное появление элементов списка по очереди
struct StaggerIn: ViewModifier {
    let index: Int
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 14)
            .onAppear {
                guard Prefs.animations else { shown = true; return }
                withAnimation(.spring(response: 0.5, dampingFraction: 0.82).delay(0.05 * Double(index))) {
                    shown = true
                }
            }
    }
}

extension View {
    func staggerIn(_ index: Int) -> some View { modifier(StaggerIn(index: index)) }
}
