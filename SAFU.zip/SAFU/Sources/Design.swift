import SwiftUI
import UIKit

// MARK: - Тема

enum AccentTheme: String, CaseIterable, Identifiable {
    case blue, violet, teal, orange, pink

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .blue: return Color(red: 0.16, green: 0.45, blue: 0.98)
        case .violet: return Color(red: 0.52, green: 0.35, blue: 0.98)
        case .teal: return Color(red: 0.10, green: 0.68, blue: 0.66)
        case .orange: return Color(red: 0.98, green: 0.50, blue: 0.18)
        case .pink: return Color(red: 0.95, green: 0.30, blue: 0.55)
        }
    }

    var secondary: Color {
        switch self {
        case .blue: return Color(red: 0.30, green: 0.80, blue: 0.98)
        case .violet: return Color(red: 0.90, green: 0.40, blue: 0.90)
        case .teal: return Color(red: 0.35, green: 0.85, blue: 0.45)
        case .orange: return Color(red: 0.98, green: 0.78, blue: 0.25)
        case .pink: return Color(red: 0.98, green: 0.55, blue: 0.40)
        }
    }

    static var current: AccentTheme {
        AccentTheme(rawValue: UserDefaults.standard.string(forKey: "theme") ?? "") ?? .blue
    }
}

extension Color {
    static var brand: Color { AccentTheme.current.color }
    static var brand2: Color { AccentTheme.current.secondary }
}

var brandGradient: LinearGradient {
    LinearGradient(colors: [.brand, .brand2], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Живой фон

struct AmbientBackground: View {
    @State private var move = false
    @AppStorage("ambient") private var animated = true

    var body: some View {
        ZStack {
            Color(.systemBackground)
            Circle()
                .fill(Color.brand.opacity(0.35))
                .frame(width: 340, height: 340)
                .blur(radius: 90)
                .offset(x: move ? -120 : 90, y: move ? -300 : -180)
            Circle()
                .fill(Color.brand2.opacity(0.25))
                .frame(width: 280, height: 280)
                .blur(radius: 90)
                .offset(x: move ? 130 : -80, y: move ? 120 : 300)
            Circle()
                .fill(Color.brand.opacity(0.18))
                .frame(width: 260, height: 260)
                .blur(radius: 100)
                .offset(x: move ? 60 : 150, y: move ? 420 : -40)
        }
        .ignoresSafeArea()
        .onAppear {
            guard animated else { return }
            withAnimation(.easeInOut(duration: 14).repeatForever(autoreverses: true)) {
                move = true
            }
        }
    }
}

// MARK: - Стекло (на iOS 26 — настоящее Liquid Glass)

struct GlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            if interactive {
                content.glassEffect(.regular.interactive(), in: shape)
            } else {
                content.glassEffect(.regular, in: shape)
            }
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        }
        #else
        content
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        #endif
    }
}

struct TabBarMinimize: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(.onScrollDown)
        } else {
            content
        }
        #else
        content
        #endif
    }
}

extension View {
    func glass(_ radius: CGFloat = 24, interactive: Bool = false) -> some View {
        modifier(GlassModifier(radius: radius, interactive: interactive))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

// MARK: - Мелкие компоненты

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct ScreenHeader<Trailing: View>: View {
    let caption: String
    let title: String
    @ViewBuilder var trailing: () -> Trailing

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text(caption)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .textCase(.uppercase)
                Text(title)
                    .font(.system(size: 34, weight: .bold, design: .rounded))
            }
            Spacer()
            trailing()
        }
    }
}

struct CircleIconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .glass(22, interactive: true)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .glass(26)
    }
}

// MARK: - Вибрация и форматирование

enum Haptics {
    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true
    }
    static func tap() {
        guard enabled else { return }
        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
    }
    static func success() {
        guard enabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

enum Fmt {
    private static let ru = Locale(identifier: "ru_RU")

    static func relative(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.locale = ru
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }

    static func due(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "d MMM, HH:mm"
        return f.string(from: date)
    }

    static func today() -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "EEEE, d MMMM"
        return f.string(from: Date())
    }

    static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }
}
