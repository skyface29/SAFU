import SwiftUI
import UIKit

// MARK: - Тема

enum AccentTheme: String, CaseIterable, Identifiable {
    case blue, violet, teal, orange, pink
    case cyber, aurora, ice, lime, crimson, gold, graphite, autumn
    case ios6, bond, rust

    var id: String { rawValue }

    var title: String {
        switch self {
        case .blue: return "Синяя"
        case .violet: return "Фиолет"
        case .teal: return "Бирюза"
        case .orange: return "Апельсин"
        case .pink: return "Розовая"
        case .cyber: return "Кибер"
        case .aurora: return "Сияние"
        case .ice: return "Лёд"
        case .lime: return "Лайм"
        case .crimson: return "Алая"
        case .gold: return "Золото"
        case .graphite: return "Графит"
        case .autumn: return "Осень"
        case .ios6: return "iOS 6"
        case .bond: return "Бонд"
        case .rust: return "Ржавчина"
        }
    }

    var color: Color {
        switch self {
        case .blue: return Color(red: 0.16, green: 0.45, blue: 0.98)
        case .violet: return Color(red: 0.52, green: 0.35, blue: 0.98)
        case .teal: return Color(red: 0.10, green: 0.68, blue: 0.66)
        case .orange: return Color(red: 0.98, green: 0.50, blue: 0.18)
        case .pink: return Color(red: 0.95, green: 0.30, blue: 0.55)
        case .cyber: return Color(red: 0.00, green: 0.78, blue: 0.95)
        case .aurora: return Color(red: 0.16, green: 0.80, blue: 0.62)
        case .ice: return Color(red: 0.35, green: 0.66, blue: 0.95)
        case .lime: return Color(red: 0.45, green: 0.80, blue: 0.10)
        case .crimson: return Color(red: 0.90, green: 0.16, blue: 0.30)
        case .gold: return Color(red: 0.92, green: 0.65, blue: 0.12)
        case .graphite: return Color(red: 0.38, green: 0.42, blue: 0.50)
        case .autumn: return Color(red: 0.93, green: 0.45, blue: 0.12)
        case .ios6: return Color(red: 0.20, green: 0.45, blue: 0.80)
        case .bond: return Color(red: 0.83, green: 0.67, blue: 0.33)
        case .rust: return Color(red: 0.72, green: 0.40, blue: 0.17)
        }
    }

    var secondary: Color {
        switch self {
        case .blue: return Color(red: 0.30, green: 0.80, blue: 0.98)
        case .violet: return Color(red: 0.90, green: 0.40, blue: 0.90)
        case .teal: return Color(red: 0.35, green: 0.85, blue: 0.45)
        case .orange: return Color(red: 0.98, green: 0.78, blue: 0.25)
        case .pink: return Color(red: 0.98, green: 0.55, blue: 0.40)
        case .cyber: return Color(red: 0.72, green: 0.35, blue: 1.00)
        case .aurora: return Color(red: 0.45, green: 0.40, blue: 0.95)
        case .ice: return Color(red: 0.70, green: 0.90, blue: 1.00)
        case .lime: return Color(red: 0.10, green: 0.75, blue: 0.60)
        case .crimson: return Color(red: 1.00, green: 0.50, blue: 0.30)
        case .gold: return Color(red: 0.98, green: 0.40, blue: 0.30)
        case .graphite: return Color(red: 0.62, green: 0.66, blue: 0.74)
        case .autumn: return Color(red: 0.80, green: 0.16, blue: 0.22)
        case .ios6: return Color(red: 0.42, green: 0.65, blue: 0.92)
        case .bond: return Color(red: 0.62, green: 0.10, blue: 0.12)
        case .rust: return Color(red: 0.37, green: 0.56, blue: 0.48)
        }
    }

    static var current: AccentTheme {
        if UserDefaults.standard.bool(forKey: "theme.seasonal") { return Season.current.theme }
        return AccentTheme(rawValue: UserDefaults.standard.string(forKey: "theme") ?? "") ?? .blue
    }
}

extension Color {
    static var brand: Color { AccentTheme.current.color }
    static var brand2: Color { AccentTheme.current.secondary }
}

var brandGradient: LinearGradient {
    LinearGradient(colors: [.brand, .brand2], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Живой фон

/// Какой фон под всеми экранами
enum BackdropStyle: String, CaseIterable, Identifiable {
    case seasonal, glow, leaves, petals, summer, aurora, grid, snow, wash, plain, matrix
    case soft, linen, barrel, workshop

    var id: String { rawValue }

    var title: String {
        switch self {
        case .seasonal: return "По сезону"
        case .glow: return "Свет"
        case .petals: return "Цветение"
        case .matrix: return "Матрица"
        case .summer: return "Лето"
        case .leaves: return "Листопад"
        case .aurora: return "Сияние"
        case .grid: return "Сетка"
        case .snow: return "Снег"
        case .wash: return "Градиент"
        case .plain: return "Чистый"
        case .soft: return "Мягкий"
        case .linen: return "iOS 6"
        case .barrel: return "Ствол"
        case .workshop: return "Мастерская"
        }
    }

    var icon: String {
        switch self {
        case .seasonal: return "calendar.circle.fill"
        case .glow: return "circle.hexagongrid.fill"
        case .petals: return "camera.macro"
        case .matrix: return "terminal.fill"
        case .summer: return "sun.max.fill"
        case .leaves: return "leaf.fill"
        case .aurora: return "wind"
        case .grid: return "grid"
        case .snow: return "snowflake"
        case .wash: return "paintbrush.pointed.fill"
        case .plain: return "square"
        case .soft: return "square.fill"
        case .linen: return "text.justify"
        case .barrel: return "scope"
        case .workshop: return "gearshape.2.fill"
        }
    }

    static var current: BackdropStyle {
        BackdropStyle(rawValue: UserDefaults.standard.string(forKey: "bg.style") ?? "") ?? .glow
    }
}

/// Время года — для фона и цвета «по сезону»
enum Season: String {
    case winter, spring, summer, autumn

    static var current: Season { of(Date()) }

    static func of(_ d: Date) -> Season {
        switch Calendar.current.component(.month, from: d) {
        case 12, 1, 2: return .winter
        case 3, 4, 5: return .spring
        case 6, 7, 8: return .summer
        default: return .autumn
        }
    }

    var title: String {
        switch self {
        case .winter: return "зима — снег"
        case .spring: return "весна — цветение"
        case .summer: return "лето — солнечные блики"
        case .autumn: return "осень — листопад"
        }
    }

    var backdrop: BackdropStyle {
        switch self {
        case .winter: return .snow
        case .spring: return .petals
        case .summer: return .summer
        case .autumn: return .leaves
        }
    }

    var theme: AccentTheme {
        switch self {
        case .winter: return .ice
        case .spring: return .pink
        case .summer: return .lime
        case .autumn: return .autumn
        }
    }
}

struct AmbientBackground: View {
    @State private var move = false
    @AppStorage("ambient") private var animated = true
    @AppStorage("bg.style") private var styleRaw = BackdropStyle.glow.rawValue
    @AppStorage("bg.intensity") private var intensity = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    @Environment(\.scenePhase) private var scenePhase
    @State private var onScreen = true

    private var style: BackdropStyle {
        let s = BackdropStyle(rawValue: styleRaw) ?? .glow
        return s == .seasonal ? Season.current.backdrop : s
    }
    /// Анимация фона стоит на паузе, когда экран не виден, приложение свёрнуто
    /// или включён режим энергосбережения — батарея и плавность важнее
    private var canAnimate: Bool {
        animated && onScreen && scenePhase == .active
            && !UIAccessibility.isReduceMotionEnabled
            && !ProcessInfo.processInfo.isLowPowerModeEnabled
    }

    /// Мягкое пятно света. Радиальный градиент вместо .blur(radius: 90):
    /// выглядит так же, но не пересчитывает размытие на весь экран каждый кадр.
    private func glow(_ color: Color, _ size: CGFloat) -> some View {
        Circle()
            .fill(RadialGradient(colors: [color, color.opacity(0)], center: .center,
                                 startRadius: 0, endRadius: size * 0.5))
            .frame(width: size * 1.6, height: size * 1.6)
    }

    var body: some View {
        // Пятна лежат в overlay: так они НЕ влияют на размер экрана
        // (иначе большие круги растягивают вёрстку шире экрана)
        Color(.systemBackground)
            .overlay { layer }
            .clipped()
            .compositingGroup()
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .id(themeRaw)
            .onAppear {
                onScreen = true
                guard canAnimate else { return }
                withAnimation(.easeInOut(duration: 18).repeatForever(autoreverses: true)) {
                    move = true
                }
            }
            .onDisappear { onScreen = false }
    }

    @ViewBuilder private var layer: some View {
        let k = intensity
        switch style {
        case .glow:
            glowLayer(k)
        case .aurora:
            AuroraLayer(animated: canAnimate, strength: k)
        case .grid:
            ZStack {
                glowLayer(k * 0.7)
                TechGrid(animated: canAnimate, strength: k)
            }
        case .leaves:
            ZStack {
                AutumnGlow(strength: k)
                LeavesLayer(animated: canAnimate, strength: k, petals: false)
            }
        case .petals:
            ZStack {
                glowLayer(k * 0.6)
                LeavesLayer(animated: canAnimate, strength: k, petals: true)
            }
        case .summer:
            ZStack {
                SummerSun(strength: k)
                SnowLayer(animated: canAnimate, strength: k, tint: Color(red: 1.0, green: 0.85, blue: 0.45), rising: true)
            }
        case .matrix:
            MatrixLayer(animated: canAnimate, strength: k)
        case .seasonal:
            EmptyView()
        case .snow:
            ZStack {
                glowLayer(k * 0.6)
                SnowLayer(animated: canAnimate, strength: k, tint: nil, rising: false)
            }
        case .wash:
            LinearGradient(colors: [Color.brand.opacity(0.22 * k), Color.brand2.opacity(0.10 * k), .clear],
                           startPoint: .topLeading, endPoint: .bottom)
        case .plain:
            Color.clear
        case .soft:
            Color(.systemGroupedBackground)
        case .linen:
            PinstripeLayer()
        case .barrel:
            GunBarrelLayer(animated: canAnimate, strength: k)
        case .workshop:
            WorkshopLayer(animated: canAnimate, strength: k)
        }
    }

    private func glowLayer(_ k: Double) -> some View {
        ZStack {
            glow(Color.brand.opacity(0.20 * k), 340)
                .offset(x: move ? -120 : 90, y: move ? -300 : -180)
            glow(Color.brand2.opacity(0.13 * k), 280)
                .offset(x: move ? 130 : -80, y: move ? 120 : 300)
            glow(Color.brand.opacity(0.09 * k), 260)
                .offset(x: move ? 60 : 150, y: move ? 420 : -40)
        }
        .frame(width: 0, height: 0)
    }
}

/// Технологичная сетка с точками на пересечениях и бегущей полосой «сканера»
private struct TechGrid: View {
    let animated: Bool
    let strength: Double
    @State private var scan = false
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Canvas { ctx, size in
                    let step: CGFloat = 26
                    let line = Color.primary.opacity((scheme == .dark ? 0.07 : 0.05) * strength)
                    var path = Path()
                    var x: CGFloat = 0
                    while x <= size.width { path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)); x += step }
                    var y: CGFloat = 0
                    while y <= size.height { path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); y += step }
                    ctx.stroke(path, with: .color(line), lineWidth: 0.5)
                    // яркие узлы через один
                    let dot = Color.brand.opacity(0.35 * strength)
                    var i = 0
                    x = 0
                    while x <= size.width {
                        y = 0
                        var j = 0
                        while y <= size.height {
                            if (i + j) % 7 == 0 {
                                ctx.fill(Path(ellipseIn: CGRect(x: x - 1.2, y: y - 1.2, width: 2.4, height: 2.4)), with: .color(dot))
                            }
                            y += step; j += 1
                        }
                        x += step; i += 1
                    }
                }
                // затухание сетки к низу
                .mask(LinearGradient(colors: [.black, .black.opacity(0.4), .clear], startPoint: .top, endPoint: .bottom))

                LinearGradient(colors: [.clear, Color.brand.opacity(0.10 * strength), .clear],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 140)
                    .offset(y: scan ? geo.size.height : -140)
            }
        }
        .onAppear {
            guard animated else { return }
            withAnimation(.linear(duration: 7).repeatForever(autoreverses: false)) { scan = true }
        }
    }
}

/// Северное сияние: на iOS 18 — живой MeshGradient, на iOS 17 — мягкие ленты
private struct AuroraLayer: View {
    let animated: Bool
    let strength: Double

    var body: some View {
        #if compiler(>=6.0)
        if #available(iOS 18.0, *) {
            TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !animated)) { ctx in
                MeshGradient(width: 3, height: 3,
                             points: Self.points(ctx.date.timeIntervalSinceReferenceDate),
                             colors: colors)
            }
        } else {
            fallback
        }
        #else
        fallback
        #endif
    }

    private var colors: [Color] {
        let k = strength
        return [Color.brand.opacity(0.35 * k), Color.brand2.opacity(0.25 * k), Color.brand.opacity(0.15 * k),
                Color.brand2.opacity(0.18 * k), Color.brand.opacity(0.10 * k), Color.brand2.opacity(0.22 * k),
                Color.clear, Color.clear, Color.clear]
    }

    private static func points(_ time: Double) -> [SIMD2<Float>] {
        let t = Float(time.truncatingRemainder(dividingBy: 3600))
        let l: Float = 0.5 + 0.12 * sin(t * 0.35)
        let cx: Float = 0.5 + 0.18 * cos(t * 0.27)
        let cy: Float = 0.45 + 0.12 * sin(t * 0.31)
        let r: Float = 0.5 + 0.12 * cos(t * 0.33)
        return [SIMD2<Float>(0, 0), SIMD2<Float>(0.5, 0), SIMD2<Float>(1, 0),
                SIMD2<Float>(0, l), SIMD2<Float>(cx, cy), SIMD2<Float>(1, r),
                SIMD2<Float>(0, 1), SIMD2<Float>(0.5, 1), SIMD2<Float>(1, 1)]
    }

    private var fallback: some View {
        LinearGradient(colors: [Color.brand.opacity(0.30 * strength), Color.brand2.opacity(0.18 * strength), .clear],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

/// Падающий снег — для университета у Белого моря
private struct SnowLayer: View {
    let animated: Bool
    let strength: Double
    /// nil — цвет темы
    var tint: Color? = nil
    /// Летом блики медленно всплывают вверх
    var rising: Bool = false

    private struct Flake { let x: Double; let y: Double; let r: Double; let speed: Double; let drift: Double }

    private static let flakes: [Flake] = {
        var seed: UInt64 = 42
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 33) / Double(UInt32.max >> 1)
        }
        return (0..<70).map { _ in
            Flake(x: rnd(), y: rnd(), r: 0.8 + rnd() * 2.2, speed: 0.015 + rnd() * 0.03, drift: rnd() * 6.28)
        }
    }()

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 10_000)
            let color = tint ?? Color.brand
            Canvas { g, size in
                for f in Self.flakes {
                    let p = (f.y + t * f.speed * (rising ? 0.35 : 1)).truncatingRemainder(dividingBy: 1.05)
                    let y = CGFloat(rising ? 1.02 - p : p) * size.height
                    let x = CGFloat(f.x) * size.width + CGFloat(sin(t * 0.6 + f.drift) * 14)
                    let r = CGFloat(f.r)
                    let rect = CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)
                    if rising {
                        // мягкий блик вместо точки
                        let big = rect.insetBy(dx: -r * 1.6, dy: -r * 1.6)
                        g.fill(Path(ellipseIn: big), with: .radialGradient(
                            Gradient(colors: [color.opacity(0.45 * strength), color.opacity(0)]),
                            center: CGPoint(x: big.midX, y: big.midY), startRadius: 0, endRadius: big.width / 2))
                    } else {
                        g.fill(Path(ellipseIn: rect), with: .color(color.opacity((0.18 + f.r * 0.08) * strength)))
                    }
                }
            }
        }
    }
}

// MARK: - Стекло (на iOS 26 — настоящее Liquid Glass)

/// Стили карточек
enum CardStyle: Int, CaseIterable, Identifiable {
    case glass = 0, solid = 1, tinted = 2, neon = 3, minimal = 4, raised = 5
    case clean = 6, skeuo = 7, tuxedo = 8, rusty = 9
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .glass: return "Стекло"
        case .solid: return "Сплошные"
        case .tinted: return "Цветные"
        case .neon: return "Неон"
        case .minimal: return "Контур"
        case .raised: return "Объём"
        case .clean: return "Чистые"
        case .skeuo: return "iOS 6"
        case .tuxedo: return "Смокинг"
        case .rusty: return "Ржавые"
        }
    }
}

struct GlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("ui.radius") private var radiusScale = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: max(4, radius * CGFloat(radiusScale)), style: .continuous)
        switch CardStyle(rawValue: cardStyle) ?? .glass {
        case .solid:
            content
                .background(Color(.secondarySystemBackground), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.6))
        case .tinted:
            content
                .background(Color.brand.opacity(0.14), in: shape)
                .overlay(shape.strokeBorder(Color.brand.opacity(0.25), lineWidth: 0.8))
        case .neon:
            content
                .background(Color(.secondarySystemBackground).opacity(0.55), in: shape)
                .overlay(shape.strokeBorder(LinearGradient(colors: [Color.brand, Color.brand2.opacity(0.35), Color.brand.opacity(0.6)],
                                                           startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.1))
                .shadow(color: Color.brand.opacity(0.22), radius: 10, y: 0)
        case .minimal:
            content
                .background(Color.primary.opacity(0.025), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.7))
        case .raised:
            content
                .background(Color(.secondarySystemGroupedBackground), in: shape)
                .shadow(color: .black.opacity(0.10), radius: 14, y: 6)
        case .clean:
            content
                .background(Color(.secondarySystemGroupedBackground), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.07), lineWidth: 0.5))
                .shadow(color: .black.opacity(0.06), radius: 10, y: 4)
        case .skeuo:
            SkeuoCard(content: content, shape: shape)
        case .tuxedo:
            TuxedoCard(content: content, shape: shape)
        case .rusty:
            RustyCard(content: content, shape: shape)
        case .glass:
            glassBody(content, shape)
        }
    }

    @ViewBuilder
    private func glassBody(_ content: Content, _ shape: RoundedRectangle) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            if interactive {
                content.glassEffect(.regular.interactive(), in: shape)
            } else {
                content.glassEffect(.regular, in: shape)
            }
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        }
        #else
        content
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        #endif
    }
}

struct TabBarMinimize: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(.onScrollDown)
        } else {
            content
        }
        #else
        content
        #endif
    }
}

extension View {
    func glass(_ radius: CGFloat = 24, interactive: Bool = false) -> some View {
        modifier(GlassModifier(radius: radius, interactive: interactive))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

// MARK: - Мелкие компоненты

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct ScreenHeader<Trailing: View>: View {
    let caption: String
    let title: String
    @ViewBuilder var trailing: () -> Trailing
    @AppStorage("ui.gradTitle") private var gradTitle = false
    @AppStorage("ui.font") private var fontRaw = AppFont.rounded.rawValue
    @AppStorage("look.pack") private var packRaw = ""

    private var titleFont: Font {
        if let name = (ThemePack(rawValue: packRaw) ?? .none).titleFont {
            return .custom(name, size: 30, relativeTo: .largeTitle)
        }
        return .system(size: 30, weight: .bold, design: (AppFont(rawValue: fontRaw) ?? .rounded).design)
    }

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    if gradTitle {
                        Capsule().fill(brandGradient).frame(width: 14, height: 3)
                    }
                    Text(caption)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                        .tracking(gradTitle ? 1.2 : 0)
                }
                Text(title)
                    .font(titleFont)
                    .foregroundStyle(gradTitle ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            Spacer()
            trailing()
        }
    }
}

struct CircleIconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .glass(22, interactive: true)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .glass(26)
    }
}

// MARK: - Вибрация и форматирование

enum Haptics {
    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true
    }
    static func tap() {
        guard enabled else { return }
        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
    }
    static func success() {
        guard enabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

enum Fmt {
    private static let ru = Locale(identifier: "ru_RU")

    // Форматтеры дорого создавать, а раньше они создавались на каждую отрисовку.
    // Теперь — один на шаблон, на всё приложение.
    private static var cache: [String: DateFormatter] = [:]
    private static let lock = NSLock()

    static func formatter(_ pattern: String) -> DateFormatter {
        lock.lock()
        defer { lock.unlock() }
        if let f = cache[pattern] { return f }
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = pattern
        cache[pattern] = f
        return f
    }

    private static let relativeFormatter: RelativeDateTimeFormatter = {
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.unitsStyle = .short
        return f
    }()

    static func relative(_ date: Date) -> String {
        lock.lock()
        defer { lock.unlock() }
        return relativeFormatter.localizedString(for: date, relativeTo: Date())
    }

    static func due(_ date: Date) -> String {
        let f = Fmt.formatter("d MMM, HH:mm")
        return f.string(from: date)
    }

    static func today() -> String {
        let f = Fmt.formatter("EEEE, d MMMM")
        return f.string(from: Date())
    }

    static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }
}


// MARK: - Анимации и цвета предметов

enum Prefs {
    static var animations: Bool { UserDefaults.standard.object(forKey: "animations") as? Bool ?? true }
}

struct PulsingDot: View {
    var color: Color = .brand
    @State private var on = false

    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(0.4))
                .frame(width: 16, height: 16)
                .scaleEffect(on ? 1.7 : 0.6)
                .opacity(on ? 0 : 1)
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
        }
        .frame(width: 18, height: 18)
        .onAppear {
            guard Prefs.animations else { return }
            withAnimation(.easeOut(duration: 1.3).repeatForever(autoreverses: false)) { on = true }
        }
    }
}

struct SpinningIcon: View {
    let spinning: Bool
    @State private var angle: Double = 0

    var body: some View {
        Image(systemName: "arrow.triangle.2.circlepath")
            .rotationEffect(.degrees(angle))
            .onAppear { start() }
            .onChange(of: spinning) { _ in start() }
    }

    private func start() {
        if spinning {
            withAnimation(.linear(duration: 1).repeatForever(autoreverses: false)) { angle = 360 }
        } else {
            withAnimation(.default) { angle = 0 }
        }
    }
}

enum SubjectColor {
    static func color(for subject: String) -> Color {
        guard UserDefaults.standard.object(forKey: "schedule.colors") as? Bool ?? true else { return .brand }
        var h: UInt64 = 5381
        for u in subject.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.55, brightness: 0.92)
    }
}

/// Плавное появление элементов списка по очереди
struct StaggerIn: ViewModifier {
    let index: Int
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 8)
            .onAppear {
                guard Prefs.animations, index < 10 else { shown = true; return }
                withAnimation(.spring(response: 0.32, dampingFraction: 0.86).delay(0.018 * Double(index))) {
                    shown = true
                }
            }
    }
}

extension View {
    func staggerIn(_ index: Int) -> some View { modifier(StaggerIn(index: index)) }
}


// MARK: - Листопад 🍁

/// Тёплая подсветка под листьями: солнце сверху и янтарная дымка снизу
private struct AutumnGlow: View {
    let strength: Double
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            RadialGradient(colors: [Color(red: 1.0, green: 0.72, blue: 0.30).opacity((dark ? 0.22 : 0.28) * strength), .clear],
                           center: UnitPoint(x: 0.85, y: 0.0), startRadius: 0, endRadius: 420)
            LinearGradient(colors: [.clear, .clear,
                                    Color(red: 0.85, green: 0.35, blue: 0.10).opacity((dark ? 0.16 : 0.12) * strength)],
                           startPoint: .top, endPoint: .bottom)
        }
    }
}

/// Падающие осенние листья: клён, берёза и простой лист.
/// Три слоя глубины (дальние мельче и чуть размыты), листья кружатся,
/// покачиваются и переворачиваются, как настоящие.
private struct LeavesLayer: View {
    let animated: Bool
    let strength: Double
    /// true — весенние лепестки вместо осенних листьев
    var petals: Bool = false
    @Environment(\.colorScheme) private var scheme

    enum Kind { case maple, oval, birch, petal }

    static let petalPalette: [(Color, Color)] = [
        (Color(red: 1.00, green: 0.86, blue: 0.92), Color(red: 0.98, green: 0.62, blue: 0.76)),
        (Color(red: 1.00, green: 0.95, blue: 0.97), Color(red: 0.96, green: 0.76, blue: 0.86)),
        (Color(red: 0.99, green: 0.74, blue: 0.84), Color(red: 0.90, green: 0.45, blue: 0.62)),
    ]

    static let petalLeaves: [Leaf] = {
        var seed: UInt64 = 314
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        return (0..<34).map { i in
            let depth = i < 14 ? 0 : (i < 27 ? 1 : 2)
            let base: Double = depth == 0 ? 6 : (depth == 1 ? 9 : 13)
            return Leaf(kind: .petal, x: rnd(), y: rnd(),
                        size: base + rnd() * base * 0.4,
                        speed: (0.014 + rnd() * 0.016) * (depth == 0 ? 0.7 : (depth == 1 ? 1.0 : 1.3)),
                        sway: 24 + rnd() * 40, swayFreq: 0.4 + rnd() * 0.5,
                        spin: (rnd() - 0.5) * 2.4, flipFreq: 0.6 + rnd() * 1.4,
                        phase: rnd() * 6.283, depth: depth,
                        colors: LeavesLayer.petalPalette[Int(rnd() * 3) % 3])
        }
    }()

    static let petalPath: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -0.72))
        p.addQuadCurve(to: CGPoint(x: 0.42, y: -1.0), control: CGPoint(x: 0.18, y: -1.05))
        p.addCurve(to: CGPoint(x: 0, y: 1.0), control1: CGPoint(x: 0.9, y: -0.6), control2: CGPoint(x: 0.45, y: 0.6))
        p.addCurve(to: CGPoint(x: -0.42, y: -1.0), control1: CGPoint(x: -0.45, y: 0.6), control2: CGPoint(x: -0.9, y: -0.6))
        p.addQuadCurve(to: CGPoint(x: 0, y: -0.72), control: CGPoint(x: -0.18, y: -1.05))
        p.closeSubpath()
        return p
    }()

    static let petalVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.85)); p.addLine(to: CGPoint(x: 0, y: -0.45))
        return p
    }()

    struct Leaf {
        let kind: Kind
        let x: Double          // 0…1 по ширине
        let y: Double          // стартовая фаза по высоте
        let size: Double       // пунктов
        let speed: Double      // доля экрана в секунду
        let sway: Double       // амплитуда покачивания
        let swayFreq: Double
        let spin: Double       // скорость вращения
        let flipFreq: Double   // скорость «переворота»
        let phase: Double
        let depth: Int         // 0 — дальний, 1 — средний, 2 — ближний
        let colors: (Color, Color)
    }

    /// Осенняя палитра: от золота до бордо
    static let palette: [(Color, Color)] = [
        (Color(red: 1.00, green: 0.78, blue: 0.20), Color(red: 0.95, green: 0.52, blue: 0.10)),   // золото
        (Color(red: 0.99, green: 0.55, blue: 0.12), Color(red: 0.86, green: 0.28, blue: 0.08)),   // оранжевый
        (Color(red: 0.93, green: 0.30, blue: 0.14), Color(red: 0.70, green: 0.10, blue: 0.10)),   // алый
        (Color(red: 0.78, green: 0.16, blue: 0.20), Color(red: 0.50, green: 0.06, blue: 0.14)),   // бордо
        (Color(red: 0.95, green: 0.68, blue: 0.25), Color(red: 0.62, green: 0.36, blue: 0.12)),   // охра
        (Color(red: 0.86, green: 0.72, blue: 0.22), Color(red: 0.55, green: 0.55, blue: 0.12)),   // жёлто-зелёный
    ]

    static let leaves: [Leaf] = {
        var seed: UInt64 = 2026
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        var list: [Leaf] = []
        for i in 0..<30 {
            let depth = i < 12 ? 0 : (i < 24 ? 1 : 2)
            let base: Double = depth == 0 ? 9 : (depth == 1 ? 15 : 22)
            let k = rnd()
            let kind: Kind = k < 0.5 ? .maple : (k < 0.78 ? .oval : .birch)
            list.append(Leaf(kind: kind,
                             x: rnd(), y: rnd(),
                             size: base + rnd() * base * 0.5,
                             speed: (0.018 + rnd() * 0.02) * (depth == 0 ? 0.7 : (depth == 1 ? 1.0 : 1.35)),
                             sway: 18 + rnd() * 34,
                             swayFreq: 0.35 + rnd() * 0.5,
                             spin: (rnd() - 0.5) * 1.6,
                             flipFreq: 0.4 + rnd() * 1.1,
                             phase: rnd() * 6.283,
                             depth: depth,
                             colors: LeavesLayer.palette[Int(rnd() * Double(LeavesLayer.palette.count)) % LeavesLayer.palette.count]))
        }
        return list
    }()

    // MARK: формы листьев (в единицах: высота ~2, центр в 0)

    static let maplePath: Path = {
        // правая половина кленового листа сверху вниз, левая — зеркально
        let right: [CGPoint] = [
            CGPoint(x: 0.00, y: -1.00),
            CGPoint(x: 0.10, y: -0.74), CGPoint(x: 0.26, y: -0.84), CGPoint(x: 0.21, y: -0.46),
            CGPoint(x: 0.44, y: -0.66), CGPoint(x: 0.52, y: -0.54), CGPoint(x: 0.80, y: -0.62),
            CGPoint(x: 0.70, y: -0.34), CGPoint(x: 0.84, y: -0.26), CGPoint(x: 0.48, y: 0.02),
            CGPoint(x: 0.54, y: 0.18), CGPoint(x: 0.12, y: 0.12), CGPoint(x: 0.03, y: 0.30),
        ]
        var p = Path()
        p.move(to: right[0])
        for pt in right.dropFirst() { p.addLine(to: pt) }
        for pt in right.dropFirst().reversed() { p.addLine(to: CGPoint(x: -pt.x, y: pt.y)) }
        p.closeSubpath()
        return p
    }()

    static let mapleVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.75)); p.addLine(to: CGPoint(x: 0, y: -0.9))      // черешок и главная жилка
        for s in [1.0, -1.0] {
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.72 * s, y: -0.55))
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.72 * s, y: -0.24))
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.42 * s, y: 0.12))
        }
        return p
    }()

    static let ovalPath: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -1.0))
        p.addCurve(to: CGPoint(x: 0, y: 0.72), control1: CGPoint(x: 0.62, y: -0.55), control2: CGPoint(x: 0.48, y: 0.45))
        p.addCurve(to: CGPoint(x: 0, y: -1.0), control1: CGPoint(x: -0.48, y: 0.45), control2: CGPoint(x: -0.62, y: -0.55))
        p.closeSubpath()
        return p
    }()

    static let ovalVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 1.0)); p.addLine(to: CGPoint(x: 0, y: -0.85))
        for (y, len) in [(-0.45, 0.28), (-0.1, 0.36), (0.25, 0.30)] {
            p.move(to: CGPoint(x: 0, y: y + 0.12)); p.addLine(to: CGPoint(x: len, y: y - 0.08))
            p.move(to: CGPoint(x: 0, y: y + 0.12)); p.addLine(to: CGPoint(x: -len, y: y - 0.08))
        }
        return p
    }()

    static let birchPath: Path = {
        // округлый берёзовый лист с острым кончиком
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -0.85))
        p.addCurve(to: CGPoint(x: 0, y: 0.55), control1: CGPoint(x: 0.35, y: -0.55), control2: CGPoint(x: 0.95, y: 0.35))
        p.addCurve(to: CGPoint(x: 0, y: -0.85), control1: CGPoint(x: -0.95, y: 0.35), control2: CGPoint(x: -0.35, y: -0.55))
        p.closeSubpath()
        return p
    }()

    static let birchVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.85)); p.addLine(to: CGPoint(x: 0, y: -0.7))
        for y in [-0.3, 0.05, 0.35] {
            p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: 0.38, y: y - 0.18))
            p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: -0.38, y: y - 0.18))
        }
        return p
    }()

    // MARK: отрисовка

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { ctx in
            let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 100_000) : 1234
            let list = petals ? Self.petalLeaves : Self.leaves
            Canvas { g, size in
                // дальние — мягче и чуть размыты, как в глубине кадра
                g.drawLayer { far in
                    far.addFilter(.blur(radius: 1.2))
                    for leaf in list where leaf.depth == 0 { draw(leaf, in: &far, size: size, t: t) }
                }
                for leaf in list where leaf.depth > 0 { draw(leaf, in: &g, size: size, t: t) }
            }
        }
    }

    private func draw(_ leaf: Leaf, in g: inout GraphicsContext, size: CGSize, t: Double) {
        let travel = size.height + 80
        let prog = (leaf.y + t * leaf.speed).truncatingRemainder(dividingBy: 1.0)
        let y = CGFloat(prog) * travel - 40
        let x = CGFloat(leaf.x) * size.width
            + CGFloat(sin(t * leaf.swayFreq + leaf.phase) * leaf.sway)
        // лист раскачивается как маятник и медленно докручивается
        let angle = sin(t * leaf.swayFreq + leaf.phase + 1.2) * 0.8 + t * leaf.spin * 0.25
        // «переворот» в воздухе: сжимаем по ширине
        let flip = cos(t * leaf.flipFreq + leaf.phase)
        let flipX = CGFloat(flip >= 0 ? max(flip, 0.12) : min(flip, -0.12))
        let s = CGFloat(leaf.size) / 2

        let dark = scheme == .dark
        let baseOpacity: Double = leaf.depth == 0 ? 0.45 : (leaf.depth == 1 ? 0.75 : 0.92)
        let opacity = min(1, baseOpacity * (dark ? 0.9 : 1.0) * strength)
        // обратная сторона листа светлее
        let back = flip < 0

        var c = g
        c.opacity = opacity
        c.translateBy(x: x, y: y)
        c.rotate(by: .radians(angle))
        c.scaleBy(x: s * flipX, y: s)

        let shape: Path, veins: Path
        switch leaf.kind {
        case .maple: shape = Self.maplePath; veins = Self.mapleVeins
        case .oval: shape = Self.ovalPath; veins = Self.ovalVeins
        case .birch: shape = Self.birchPath; veins = Self.birchVeins
        case .petal: shape = Self.petalPath; veins = Self.petalVeins
        }

        let top = back ? leaf.colors.0.opacity(0.85) : leaf.colors.0
        let bottom = back ? leaf.colors.0 : leaf.colors.1
        // лёгкая тень у ближних листьев
        if leaf.depth == 2 {
            var sh = c
            sh.translateBy(x: 0.12, y: 0.18)
            sh.fill(shape, with: .color(.black.opacity(dark ? 0.35 : 0.12)))
        }
        c.fill(shape, with: .linearGradient(Gradient(colors: [top, bottom]),
                                            startPoint: CGPoint(x: -0.4, y: -1), endPoint: CGPoint(x: 0.4, y: 0.8)))
        // блик
        c.fill(shape, with: .radialGradient(Gradient(colors: [.white.opacity(0.22), .clear]),
                                            center: CGPoint(x: -0.25, y: -0.45), startRadius: 0, endRadius: 0.9))
        // прожилки
        c.stroke(veins, with: .color(leaf.colors.1.opacity(back ? 0.35 : 0.55)),
                 style: StrokeStyle(lineWidth: 1.0 / s * 0.9, lineCap: .round))
    }
}


/// Летнее солнце в углу
private struct SummerSun: View {
    let strength: Double
    var body: some View {
        ZStack {
            RadialGradient(colors: [Color(red: 1.0, green: 0.86, blue: 0.40).opacity(0.35 * strength), .clear],
                           center: UnitPoint(x: 0.9, y: 0.02), startRadius: 0, endRadius: 380)
            RadialGradient(colors: [Color(red: 0.40, green: 0.85, blue: 0.60).opacity(0.14 * strength), .clear],
                           center: UnitPoint(x: 0.0, y: 1.0), startRadius: 0, endRadius: 420)
        }
    }
}
