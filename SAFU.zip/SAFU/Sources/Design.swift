import SwiftUI
import UIKit

// MARK: - Тема

enum AccentTheme: String, CaseIterable, Identifiable {
    case blue, violet, teal, orange, pink
    case cyber, aurora, ice, lime, crimson, gold, graphite, autumn
    case ios6, rust
    // строгие: спокойные глубокие цвета без кислотных переходов
    case navy, safu, bordeaux, forest, petrol, slate, olive, coffee, plum, ink

    var id: String { rawValue }

    static let vivid: [AccentTheme] = allCases.filter { !$0.isStrict }
    static let strict: [AccentTheme] = [.navy, .safu, .bordeaux, .forest, .petrol, .slate, .olive, .coffee, .plum, .ink]
    var isStrict: Bool {
        switch self {
        case .navy, .safu, .bordeaux, .forest, .petrol, .slate, .olive, .coffee, .plum, .ink: return true
        default: return false
        }
    }

    var title: String {
        switch self {
        case .blue: return "Синяя"
        case .violet: return "Фиолет"
        case .teal: return "Бирюза"
        case .orange: return "Апельсин"
        case .pink: return "Розовая"
        case .cyber: return "Кибер"
        case .aurora: return "Сияние"
        case .ice: return "Лёд"
        case .lime: return "Лайм"
        case .crimson: return "Алая"
        case .gold: return "Золото"
        case .graphite: return "Графит"
        case .autumn: return "Осень"
        case .ios6: return "Классика"
        case .rust: return "Ржавчина"
        case .navy: return "Тёмно-синяя"
        case .safu: return "САФУ"
        case .bordeaux: return "Бордо"
        case .forest: return "Хвоя"
        case .petrol: return "Петроль"
        case .slate: return "Сланец"
        case .olive: return "Олива"
        case .coffee: return "Кофе"
        case .plum: return "Слива"
        case .ink: return "Чернила"
        }
    }

    var color: Color {
        switch self {
        case .blue: return Color(red: 0.16, green: 0.45, blue: 0.98)
        case .violet: return Color(red: 0.52, green: 0.35, blue: 0.98)
        case .teal: return Color(red: 0.10, green: 0.68, blue: 0.66)
        case .orange: return Color(red: 0.98, green: 0.50, blue: 0.18)
        case .pink: return Color(red: 0.95, green: 0.30, blue: 0.55)
        case .cyber: return Color(red: 0.00, green: 0.78, blue: 0.95)
        case .aurora: return Color(red: 0.16, green: 0.80, blue: 0.62)
        case .ice: return Color(red: 0.35, green: 0.66, blue: 0.95)
        case .lime: return Color(red: 0.45, green: 0.80, blue: 0.10)
        case .crimson: return Color(red: 0.90, green: 0.16, blue: 0.30)
        case .gold: return Color(red: 0.92, green: 0.65, blue: 0.12)
        case .graphite: return Color(red: 0.38, green: 0.42, blue: 0.50)
        case .autumn: return Color(red: 0.93, green: 0.45, blue: 0.12)
        case .ios6: return Color(red: 0.20, green: 0.45, blue: 0.80)
        case .rust: return Color(red: 0.72, green: 0.40, blue: 0.17)
        // в тёмной теме строгие цвета чуть светлее, чтобы не тонули в фоне
        case .navy: return .dyn(0x1B3A6B, 0x5B7FC4)
        case .safu: return .dyn(0x004C97, 0x3D84D6)
        case .bordeaux: return .dyn(0x7A1F2B, 0xB5525E)
        case .forest: return .dyn(0x1F5A3D, 0x4F9A6E)
        case .petrol: return .dyn(0x0F5561, 0x3F939E)
        case .slate: return .dyn(0x3E4C5C, 0x7F8FA3)
        case .olive: return .dyn(0x5A5E28, 0x9A9E58)
        case .coffee: return .dyn(0x6B4630, 0xA67C5E)
        case .plum: return .dyn(0x5B2D66, 0x9A6BA6)
        case .ink: return .dyn(0x1E2126, 0x8C929C)
        }
    }

    var secondary: Color {
        switch self {
        case .blue: return Color(red: 0.30, green: 0.80, blue: 0.98)
        case .violet: return Color(red: 0.90, green: 0.40, blue: 0.90)
        case .teal: return Color(red: 0.35, green: 0.85, blue: 0.45)
        case .orange: return Color(red: 0.98, green: 0.78, blue: 0.25)
        case .pink: return Color(red: 0.98, green: 0.55, blue: 0.40)
        case .cyber: return Color(red: 0.72, green: 0.35, blue: 1.00)
        case .aurora: return Color(red: 0.45, green: 0.40, blue: 0.95)
        case .ice: return Color(red: 0.70, green: 0.90, blue: 1.00)
        case .lime: return Color(red: 0.10, green: 0.75, blue: 0.60)
        case .crimson: return Color(red: 1.00, green: 0.50, blue: 0.30)
        case .gold: return Color(red: 0.98, green: 0.40, blue: 0.30)
        case .graphite: return Color(red: 0.62, green: 0.66, blue: 0.74)
        case .autumn: return Color(red: 0.80, green: 0.16, blue: 0.22)
        case .ios6: return Color(red: 0.42, green: 0.65, blue: 0.92)
        case .rust: return Color(red: 0.37, green: 0.56, blue: 0.48)
        case .navy: return .dyn(0x2F5288, 0x7896D0)
        case .safu: return .dyn(0x1F66B0, 0x6AA2E0)
        case .bordeaux: return .dyn(0x96323F, 0xC56D77)
        case .forest: return .dyn(0x2F7250, 0x6BAE86)
        case .petrol: return .dyn(0x1E6C78, 0x5CA8B2)
        case .slate: return .dyn(0x566578, 0x98A6B8)
        case .olive: return .dyn(0x72773A, 0xB0B470)
        case .coffee: return .dyn(0x86593E, 0xBA9276)
        case .plum: return .dyn(0x74407F, 0xB085BB)
        case .ink: return .dyn(0x3A3F47, 0xA4AAB3)
        }
    }

    static var current: AccentTheme {
        if UserDefaults.standard.bool(forKey: "theme.seasonal") { return Season.current.theme }
        return AccentTheme(rawValue: UserDefaults.standard.string(forKey: "theme") ?? "") ?? .blue
    }
}

extension Color {
    /// Цвет, который сам подстраивается под светлую и тёмную тему
    static func dyn(_ light: UInt32, _ dark: UInt32) -> Color {
        func ui(_ h: UInt32) -> UIColor {
            UIColor(red: CGFloat((h >> 16) & 0xFF) / 255, green: CGFloat((h >> 8) & 0xFF) / 255,
                    blue: CGFloat(h & 0xFF) / 255, alpha: 1)
        }
        let l = ui(light), d = ui(dark)
        return Color(UIColor { $0.userInterfaceStyle == .dark ? d : l })
    }

    static var brand: Color { AccentTheme.current.color }
    static var brand2: Color { AccentTheme.current.secondary }
}

var brandGradient: LinearGradient {
    LinearGradient(colors: [.brand, .brand2], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Живой фон

/// Какой фон под всеми экранами
enum BackdropStyle: String, CaseIterable, Identifiable {
    case seasonal, glow, leaves, petals, summer, aurora, grid, snow, wash, plain, matrix
    case soft, linen, workshop

    var id: String { rawValue }

    var title: String {
        switch self {
        case .seasonal: return "По сезону"
        case .glow: return "Свет"
        case .petals: return "Цветение"
        case .matrix: return "Матрица"
        case .summer: return "Лето"
        case .leaves: return "Листопад"
        case .aurora: return "Сияние"
        case .grid: return "Сетка"
        case .snow: return "Снег"
        case .wash: return "Градиент"
        case .plain: return "Чистый"
        case .soft: return "Мягкий"
        case .linen: return "Классика"
        case .workshop: return "Мастерская"
        }
    }

    var icon: String {
        switch self {
        case .seasonal: return "calendar.circle.fill"
        case .glow: return "circle.hexagongrid.fill"
        case .petals: return "camera.macro"
        case .matrix: return "terminal.fill"
        case .summer: return "sun.max.fill"
        case .leaves: return "leaf.fill"
        case .aurora: return "wind"
        case .grid: return "grid"
        case .snow: return "snowflake"
        case .wash: return "paintbrush.pointed.fill"
        case .plain: return "square"
        case .soft: return "square.fill"
        case .linen: return "text.justify"
        case .workshop: return "gearshape.2.fill"
        }
    }

    static var current: BackdropStyle {
        BackdropStyle(rawValue: UserDefaults.standard.string(forKey: "bg.style") ?? "") ?? .glow
    }
}

/// Время года — для фона и цвета «по сезону»
enum Season: String {
    case winter, spring, summer, autumn

    static var current: Season { of(Date()) }

    static func of(_ d: Date) -> Season {
        switch Calendar.current.component(.month, from: d) {
        case 12, 1, 2: return .winter
        case 3, 4, 5: return .spring
        case 6, 7, 8: return .summer
        default: return .autumn
        }
    }

    var title: String {
        switch self {
        case .winter: return "зима — снег"
        case .spring: return "весна — цветение"
        case .summer: return "лето — солнечные блики"
        case .autumn: return "осень — листопад"
        }
    }

    var backdrop: BackdropStyle {
        switch self {
        case .winter: return .snow
        case .spring: return .petals
        case .summer: return .summer
        case .autumn: return .leaves
        }
    }

    var theme: AccentTheme {
        switch self {
        case .winter: return .ice
        case .spring: return .pink
        case .summer: return .lime
        case .autumn: return .autumn
        }
    }
}

/// Живой фон анимируется только на верхнем видимом экране.
/// Открыл лист поверх главной — фон главной замирает, работает один.
final class AmbientCoordinator: ObservableObject {
    static let shared = AmbientCoordinator()
    @Published private(set) var top: UUID?
    /// Пока палец листает экран, живой фон замирает: вся мощность — на плавную прокрутку
    @Published var scrolling = false
    private var stack: [UUID] = []

    func push(_ id: UUID) {
        stack.removeAll { $0 == id }
        stack.append(id)
        if top != id { top = id }
    }

    func pop(_ id: UUID) {
        stack.removeAll { $0 == id }
        if top != stack.last { top = stack.last }
    }
}

/// Экран поверх всего (сайт, почта): пока он открыт, все живые фоны под ним стоят на паузе
private struct PausesAmbient: ViewModifier {
    @State private var token = UUID()
    func body(content: Content) -> some View {
        content
            .onAppear { AmbientCoordinator.shared.push(token) }
            .onDisappear { AmbientCoordinator.shared.pop(token) }
    }
}

extension View {
    func pausesAmbient() -> some View { modifier(PausesAmbient()) }
}

struct AmbientBackground: View {
    @State private var token = UUID()
    @ObservedObject private var coordinator = AmbientCoordinator.shared
    @AppStorage("ambient") private var animated = true
    @AppStorage("bg.style") private var styleRaw = BackdropStyle.glow.rawValue
    @AppStorage("bg.intensity") private var intensity = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.colorScheme) private var scheme
    @State private var onScreen = true

    private var style: BackdropStyle {
        let s = BackdropStyle(rawValue: styleRaw) ?? .glow
        return s == .seasonal ? Season.current.backdrop : s
    }
    /// Анимация фона стоит на паузе, когда экран не виден, приложение свёрнуто
    /// или включён режим энергосбережения — батарея и плавность важнее
    private var canAnimate: Bool {
        animated && onScreen && scenePhase == .active && coordinator.top == token && !coordinator.scrolling
            && !UIAccessibility.isReduceMotionEnabled
            && !ProcessInfo.processInfo.isLowPowerModeEnabled
            // телефон нагрелся — живой фон замирает, чтобы не тормозило
            && ProcessInfo.processInfo.thermalState.rawValue < ProcessInfo.ThermalState.serious.rawValue
    }

    /// Мягкое пятно света. Радиальный градиент вместо .blur(radius: 90):
    /// выглядит так же, но не пересчитывает размытие на весь экран каждый кадр.
    private func glow(_ color: Color, _ size: CGFloat) -> some View {
        Circle()
            .fill(RadialGradient(colors: [color, color.opacity(0)], center: .center,
                                 startRadius: 0, endRadius: size * 0.5))
            .frame(width: size * 1.6, height: size * 1.6)
    }

    var body: some View {
        // Пятна лежат в overlay: так они НЕ влияют на размер экрана
        // (иначе большие круги растягивают вёрстку шире экрана)
        // без compositingGroup: он заставлял рисовать весь экран в отдельный буфер каждый кадр
        Color(.systemBackground)
            .overlay { layer }
            .clipped()
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .id(themeRaw)
            .onAppear {
                onScreen = true
                coordinator.push(token)
            }
            .onDisappear {
                onScreen = false
                coordinator.pop(token)
            }
    }

    @ViewBuilder private var layer: some View {
        let k = intensity
        let live = canAnimate
        let dark = scheme == .dark
        switch style {
        case .glow:
            ParticleField(kind: .glow, strength: k, animated: live)
        case .aurora:
            AuroraLayer(animated: live, strength: k)
        case .grid:
            ZStack {
                ParticleField(kind: .glow, strength: k * 0.7, animated: live)
                TechGrid(animated: live, strength: k)
            }
        case .leaves:
            ZStack {
                AutumnGlow(strength: k)
                ParticleField(kind: .leaves, strength: k, animated: live, dark: dark)
            }
        case .petals:
            ZStack {
                ParticleField(kind: .glow, strength: k * 0.6, animated: live)
                ParticleField(kind: .petals, strength: k, animated: live, dark: dark)
            }
        case .summer:
            ZStack {
                SummerSun(strength: k)
                ParticleField(kind: .rising, color: Color(red: 1.0, green: 0.85, blue: 0.45), strength: k, animated: live)
            }
        case .matrix:
            MatrixLayer(animated: live, strength: k)
        case .seasonal:
            EmptyView()
        case .snow:
            ZStack {
                ParticleField(kind: .glow, strength: k * 0.6, animated: live)
                ParticleField(kind: .snow, strength: k, animated: live)
            }
        case .wash:
            LinearGradient(colors: [Color.brand.opacity(0.22 * k), Color.brand2.opacity(0.10 * k), .clear],
                           startPoint: .topLeading, endPoint: .bottom)
        case .plain:
            Color.clear
        case .soft:
            Color(.systemGroupedBackground)
        case .linen:
            PinstripeLayer()
        case .workshop:
            WorkshopLayer(animated: live, strength: k)
        }
    }
}

/// Технологичная сетка с точками на пересечениях и бегущей полосой «сканера»
private struct TechGrid: View {
    let animated: Bool
    let strength: Double
    @State private var scan = false
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Canvas { ctx, size in
                    let step: CGFloat = 26
                    let line = Color.primary.opacity((scheme == .dark ? 0.07 : 0.05) * strength)
                    var path = Path()
                    var x: CGFloat = 0
                    while x <= size.width { path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)); x += step }
                    var y: CGFloat = 0
                    while y <= size.height { path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); y += step }
                    ctx.stroke(path, with: .color(line), lineWidth: 0.5)
                    // яркие узлы через один
                    let dot = Color.brand.opacity(0.35 * strength)
                    var i = 0
                    x = 0
                    while x <= size.width {
                        y = 0
                        var j = 0
                        while y <= size.height {
                            if (i + j) % 7 == 0 {
                                ctx.fill(Path(ellipseIn: CGRect(x: x - 1.2, y: y - 1.2, width: 2.4, height: 2.4)), with: .color(dot))
                            }
                            y += step; j += 1
                        }
                        x += step; i += 1
                    }
                }
                // затухание сетки к низу
                .mask(LinearGradient(colors: [.black, .black.opacity(0.4), .clear], startPoint: .top, endPoint: .bottom))

                LinearGradient(colors: [.clear, Color.brand.opacity(0.10 * strength), .clear],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 140)
                    .offset(y: scan ? geo.size.height : -140)
            }
        }
        .onAppear {
            guard animated else { return }
            withAnimation(.linear(duration: 7).repeatForever(autoreverses: false)) { scan = true }
        }
    }
}

/// Северное сияние: на iOS 18 — живой MeshGradient, на iOS 17 — мягкие ленты
private struct AuroraLayer: View {
    let animated: Bool
    let strength: Double

    var body: some View {
        #if compiler(>=6.0)
        if #available(iOS 18.0, *) {
            TimelineView(.animation(minimumInterval: 1.0 / 12, paused: !animated)) { ctx in
                MeshGradient(width: 3, height: 3,
                             points: Self.points(ctx.date.timeIntervalSinceReferenceDate),
                             colors: colors)
            }
        } else {
            fallback
        }
        #else
        fallback
        #endif
    }

    private var colors: [Color] {
        let k = strength
        return [Color.brand.opacity(0.35 * k), Color.brand2.opacity(0.25 * k), Color.brand.opacity(0.15 * k),
                Color.brand2.opacity(0.18 * k), Color.brand.opacity(0.10 * k), Color.brand2.opacity(0.22 * k),
                Color.clear, Color.clear, Color.clear]
    }

    private static func points(_ time: Double) -> [SIMD2<Float>] {
        let t = Float(time.truncatingRemainder(dividingBy: 3600))
        let l: Float = 0.5 + 0.12 * sin(t * 0.35)
        let cx: Float = 0.5 + 0.18 * cos(t * 0.27)
        let cy: Float = 0.45 + 0.12 * sin(t * 0.31)
        let r: Float = 0.5 + 0.12 * cos(t * 0.33)
        return [SIMD2<Float>(0, 0), SIMD2<Float>(0.5, 0), SIMD2<Float>(1, 0),
                SIMD2<Float>(0, l), SIMD2<Float>(cx, cy), SIMD2<Float>(1, r),
                SIMD2<Float>(0, 1), SIMD2<Float>(0.5, 1), SIMD2<Float>(1, 1)]
    }

    private var fallback: some View {
        LinearGradient(colors: [Color.brand.opacity(0.30 * strength), Color.brand2.opacity(0.18 * strength), .clear],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

// MARK: - Стекло (на iOS 26 — настоящее Liquid Glass)

/// Стили карточек
enum CardStyle: Int, CaseIterable, Identifiable {
    case glass = 0, solid = 1, tinted = 2, neon = 3, minimal = 4, raised = 5
    case clean = 6, skeuo = 7, rusty = 9
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .glass: return "Стекло"
        case .solid: return "Сплошные"
        case .tinted: return "Цветные"
        case .neon: return "Неон"
        case .minimal: return "Контур"
        case .raised: return "Объём"
        case .clean: return "Чистые"
        case .skeuo: return "Классика"
        case .rusty: return "Ржавые"
        }
    }
}

struct GlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool
    /// Настоящее «жидкое стекло» iOS 26 — только у редких плавающих кнопок (шапка экрана, панель сайта)
    var live = false
    /// Строка списка: вместо живого стекла — лёгкая полупрозрачная подложка (десятки стёкол в списке тормозят)
    var lite = false
    @Environment(\.colorScheme) private var scheme
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("ui.radius") private var radiusScale = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: max(4, radius * CGFloat(radiusScale)), style: .continuous)
        // вся карточка — область нажатия, а не только текст и стрелка
        return styled(content, shape).contentShape(shape)
    }

    @ViewBuilder
    private func styled(_ content: Content, _ shape: RoundedRectangle) -> some View {
        let style = CardStyle(rawValue: cardStyle) ?? .glass
        // Живое стекло iOS 26 пересчитывает фон под собой каждый кадр прокрутки: на десятке карточек
        // это и были лаги. Карточкам достаётся матовая подложка с бликом по краю — выглядит как стекло,
        // а рисуется один раз. Настоящее стекло остаётся у кнопок (interactive) — их на экране единицы
        if style == .glass && (lite || !live) {
            content
                .background(Color(.secondarySystemBackground).opacity(scheme == .dark ? 0.72 : 0.8), in: shape)
                .overlay(shape.strokeBorder(LinearGradient(colors: [Color.white.opacity(scheme == .dark ? 0.16 : 0.5),
                                                                    Color.white.opacity(scheme == .dark ? 0.04 : 0.15)],
                                                           startPoint: .top, endPoint: .bottom), lineWidth: 0.7))
        } else {
            styledCard(content, shape, style)
        }
    }

    @ViewBuilder
    private func styledCard(_ content: Content, _ shape: RoundedRectangle, _ style: CardStyle) -> some View {
        switch style {
        case .solid:
            content
                .background(Color(.secondarySystemBackground), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.6))
        case .tinted:
            content
                .background(Color.brand.opacity(0.14), in: shape)
                .overlay(shape.strokeBorder(Color.brand.opacity(0.25), lineWidth: 0.8))
        // тень рисуется только у подложки, а не у каждого текста и значка внутри карточки — так дешевле
        case .neon:
            content
                .background(shape.fill(Color(.secondarySystemBackground).opacity(0.55))
                                .shadow(color: Color.brand.opacity(0.22), radius: 10, y: 0))
                .overlay(shape.strokeBorder(LinearGradient(colors: [Color.brand, Color.brand2.opacity(0.35), Color.brand.opacity(0.6)],
                                                           startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.1))
        case .minimal:
            content
                .background(Color.primary.opacity(0.025), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.7))
        case .raised:
            content
                .background(shape.fill(Color(.secondarySystemGroupedBackground))
                                .shadow(color: .black.opacity(0.10), radius: 14, y: 6))
        case .clean:
            content
                .background(shape.fill(Color(.secondarySystemGroupedBackground))
                                .shadow(color: .black.opacity(0.06), radius: 10, y: 4))
                .overlay(shape.strokeBorder(Color.primary.opacity(0.07), lineWidth: 0.5))
        case .skeuo:
            SkeuoCard(content: content, shape: shape)
        case .rusty:
            RustyCard(content: content, shape: shape)
        case .glass:
            glassBody(content, shape)
        }
    }

    @ViewBuilder
    private func glassBody(_ content: Content, _ shape: RoundedRectangle) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            if interactive {
                content.glassEffect(.regular.interactive(), in: shape)
            } else {
                content.glassEffect(.regular, in: shape)
            }
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        }
        #else
        content
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        #endif
    }
}

/// Сжатие панели вкладок при прокрутке — по желанию. По умолчанию выключено: стеклянная панель
/// перестраивается каждый раз, когда список упирается в край и пружинит, и это давало рывки вверху и внизу
struct TabBarMinimize: ViewModifier {
    @AppStorage("ui.minimizeTabBar") private var minimize = false

    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(minimize ? .onScrollDown : .never)
        } else {
            content
        }
        #else
        content
        #endif
    }
}

extension View {
    func glass(_ radius: CGFloat = 24, interactive: Bool = false) -> some View {
        modifier(GlassModifier(radius: radius, interactive: interactive))
    }

    /// Живое стекло: пересчитывает фон под собой каждый кадр, поэтому — только для пары кнопок на экране,
    /// не для карточек и плиток в прокрутке (десяток таких и давал лаги)
    func liveGlass(_ radius: CGFloat = 24) -> some View {
        modifier(GlassModifier(radius: radius, interactive: true, live: true))
    }

    /// Карточка-строка длинного списка: выглядит так же, но без живого стекла — прокрутка плавная
    func glassRow(_ radius: CGFloat = 18) -> some View {
        modifier(GlassModifier(radius: radius, interactive: false, lite: true))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

// MARK: - Мелкие компоненты

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct ScreenHeader<Trailing: View>: View {
    let caption: String
    let title: String
    @ViewBuilder var trailing: () -> Trailing
    @AppStorage("ui.gradTitle") private var gradTitle = false
    @AppStorage("ui.font") private var fontRaw = AppFont.rounded.rawValue
    @AppStorage("look.pack") private var packRaw = ""

    private var titleFont: Font {
        if let name = (ThemePack(rawValue: packRaw) ?? .none).titleFont {
            return .custom(name, size: 30, relativeTo: .largeTitle)
        }
        return .system(size: 30, weight: .bold, design: (AppFont(rawValue: fontRaw) ?? .rounded).design)
    }

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    if gradTitle {
                        Capsule().fill(brandGradient).frame(width: 14, height: 3)
                    }
                    Text(caption)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                        .tracking(gradTitle ? 1.2 : 0)
                }
                Text(title)
                    .font(titleFont)
                    .foregroundStyle(gradTitle ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            Spacer()
            trailing()
        }
    }
}

struct CircleIconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .liveGlass(22)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .glass(26)
    }
}

// MARK: - Вибрация и форматирование

enum Haptics {
    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true
    }
    // Один заранее подготовленный генератор вместо нового на каждое нажатие:
    // так вибрация не запаздывает и не притормаживает саму кнопку
    private static let soft: UIImpactFeedbackGenerator = {
        let g = UIImpactFeedbackGenerator(style: .soft)
        g.prepare()
        return g
    }()
    private static let notify: UINotificationFeedbackGenerator = {
        let g = UINotificationFeedbackGenerator()
        g.prepare()
        return g
    }()

    static func tap() {
        guard enabled else { return }
        soft.impactOccurred()
        soft.prepare()
    }
    static func success() {
        guard enabled else { return }
        notify.notificationOccurred(.success)
        notify.prepare()
    }
}

enum Fmt {
    private static let ru = Locale(identifier: "ru_RU")

    // Форматтеры дорого создавать, а раньше они создавались на каждую отрисовку.
    // Теперь — один на шаблон, на всё приложение.
    private static var cache: [String: DateFormatter] = [:]
    private static let lock = NSLock()

    static func formatter(_ pattern: String) -> DateFormatter {
        lock.lock()
        defer { lock.unlock() }
        if let f = cache[pattern] { return f }
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = pattern
        cache[pattern] = f
        return f
    }

    private static let relativeFormatter: RelativeDateTimeFormatter = {
        let f = RelativeDateTimeFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.unitsStyle = .short
        return f
    }()

    static func relative(_ date: Date) -> String {
        lock.lock()
        defer { lock.unlock() }
        return relativeFormatter.localizedString(for: date, relativeTo: Date())
    }

    static func due(_ date: Date) -> String {
        let f = Fmt.formatter("d MMM, HH:mm")
        return f.string(from: date)
    }

    static func today() -> String {
        let f = Fmt.formatter("EEEE, d MMMM")
        return f.string(from: Date())
    }

    static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }
}


// MARK: - Анимации и цвета предметов

enum Prefs {
    static var animations: Bool { UserDefaults.standard.object(forKey: "animations") as? Bool ?? true }
}

/// Пульсирующая точка «идёт пара». Анимацию крутит Core Animation на видеокарте:
/// раньше SwiftUI пересчитывал её на главном потоке каждый кадр, и это мешало прокрутке
struct PulsingDot: View {
    var color: Color = .brand

    var body: some View {
        LoopLayerView(kind: .pulse, color: UIColor(color))
            .frame(width: 18, height: 18)
            .accessibilityHidden(true)
    }
}

/// Бесконечные мелкие анимации (пульс, мигание) — целиком в Core Animation, без участия SwiftUI
struct LoopLayerView: UIViewRepresentable {
    enum Kind { case pulse, blink }
    let kind: Kind
    let color: UIColor

    func makeUIView(context: Context) -> LoopLayerHost {
        let v = LoopLayerHost(kind: kind)
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        return v
    }

    func updateUIView(_ v: LoopLayerHost, context: Context) {
        v.setColor(color)
    }
}

final class LoopLayerHost: UIView {
    private let kind: LoopLayerView.Kind
    private let ring = CALayer()
    private let dot = CALayer()

    init(kind: LoopLayerView.Kind) {
        self.kind = kind
        super.init(frame: .zero)
        if kind == .pulse { layer.addSublayer(ring) }
        layer.addSublayer(dot)
    }

    required init?(coder: NSCoder) { fatalError() }

    func setColor(_ c: UIColor) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        ring.backgroundColor = c.withAlphaComponent(0.4).cgColor
        dot.backgroundColor = c.cgColor
        CATransaction.commit()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let c = CGPoint(x: bounds.midX, y: bounds.midY)
        let d: CGFloat = kind == .pulse ? 8 : min(bounds.width, bounds.height)
        dot.bounds = CGRect(x: 0, y: 0, width: d, height: d)
        dot.cornerRadius = d / 2
        dot.position = c
        ring.bounds = CGRect(x: 0, y: 0, width: 16, height: 16)
        ring.cornerRadius = 8
        ring.position = c
        CATransaction.commit()
    }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window != nil { start() } else { ring.removeAllAnimations(); dot.removeAllAnimations() }
    }

    private func start() {
        guard Prefs.animations, !UIAccessibility.isReduceMotionEnabled else { return }
        switch kind {
        case .pulse:
            guard ring.animation(forKey: "loop") == nil else { return }
            let scale = CABasicAnimation(keyPath: "transform.scale")
            scale.fromValue = 0.6
            scale.toValue = 1.7
            let fade = CABasicAnimation(keyPath: "opacity")
            fade.fromValue = 1
            fade.toValue = 0
            let g = CAAnimationGroup()
            g.animations = [scale, fade]
            g.duration = 1.3
            g.repeatCount = .infinity
            g.timingFunction = CAMediaTimingFunction(name: .easeOut)
            g.isRemovedOnCompletion = false     // переживает сворачивание приложения
            ring.add(g, forKey: "loop")
        case .blink:
            guard dot.animation(forKey: "loop") == nil else { return }
            let a = CABasicAnimation(keyPath: "opacity")
            a.fromValue = 1
            a.toValue = 0.3
            a.duration = 0.8
            a.autoreverses = true
            a.repeatCount = .infinity
            a.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            a.isRemovedOnCompletion = false
            dot.add(a, forKey: "loop")
        }
    }
}

struct SpinningIcon: View {
    let spinning: Bool
    @State private var angle: Double = 0

    var body: some View {
        Image(systemName: "arrow.triangle.2.circlepath")
            .rotationEffect(.degrees(angle))
            .onAppear { start() }
            .onChange(of: spinning) { _ in start() }
    }

    private func start() {
        if spinning {
            withAnimation(.linear(duration: 1).repeatForever(autoreverses: false)) { angle = 360 }
        } else {
            withAnimation(.default) { angle = 0 }
        }
    }
}

enum SubjectColor {
    static func color(for subject: String) -> Color {
        guard UserDefaults.standard.object(forKey: "schedule.colors") as? Bool ?? true else { return .brand }
        var h: UInt64 = 5381
        for u in subject.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.55, brightness: 0.92)
    }
}

/// Прокрутка: по умолчанию без эффектов — карточки просто едут за пальцем.
/// «Мягко» — блоки слегка тают у краёв экрана. Без наклонов, сдвигов и масштаба: они дёргали
/// верхние карточки, когда список упирался в край и пружинил
struct ScrollFX: ViewModifier {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AppStorage("ui.scrollFX") private var styleRaw = ScrollFXStyle.off.rawValue

    @ViewBuilder
    func body(content: Content) -> some View {
        let style = ScrollFXStyle(rawValue: styleRaw) ?? .off
        if style == .soft && !reduceMotion && Prefs.animations && !ProcessInfo.processInfo.isLowPowerModeEnabled {
            content.scrollTransition(.interactive(timingCurve: .easeOut), axis: .vertical) { v, phase in
                v.opacity(1 - abs(phase.value) * 0.35)
            }
        } else {
            content
        }
    }
}

/// Экран с прокруткой: пока листаешь, фон стоит (iOS 18+ сообщает, когда прокрутка идёт)
private struct PausesAmbientWhileScrolling: ViewModifier {
    func body(content: Content) -> some View {
        if #available(iOS 18.0, *) {
            content.onScrollPhaseChange { _, phase in
                let moving = phase != .idle
                if AmbientCoordinator.shared.scrolling != moving { AmbientCoordinator.shared.scrolling = moving }
            }
            // ушли с экрана посреди прокрутки — фон не должен остаться замершим
            .onDisappear { AmbientCoordinator.shared.scrolling = false }
        } else {
            content
        }
    }
}

extension View {
    func pausesAmbientWhileScrolling() -> some View { modifier(PausesAmbientWhileScrolling()) }
    func scrollFX() -> some View { modifier(ScrollFX()) }
}


// MARK: - Листопад 🍁

/// Тёплая подсветка под листьями: солнце сверху и янтарная дымка снизу
private struct AutumnGlow: View {
    let strength: Double
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let dark = scheme == .dark
        ZStack {
            RadialGradient(colors: [Color(red: 1.0, green: 0.72, blue: 0.30).opacity((dark ? 0.22 : 0.28) * strength), .clear],
                           center: UnitPoint(x: 0.85, y: 0.0), startRadius: 0, endRadius: 420)
            LinearGradient(colors: [.clear, .clear,
                                    Color(red: 0.85, green: 0.35, blue: 0.10).opacity((dark ? 0.16 : 0.12) * strength)],
                           startPoint: .top, endPoint: .bottom)
        }
    }
}

/// Падающие осенние листья: клён, берёза и простой лист.
/// Три слоя глубины (дальние мельче и чуть размыты), листья кружатся,
/// покачиваются и переворачиваются, как настоящие.
private struct LeavesLayer: View {
    let animated: Bool
    let strength: Double
    /// true — весенние лепестки вместо осенних листьев
    var petals: Bool = false
    @Environment(\.colorScheme) private var scheme

    enum Kind { case maple, oval, birch, petal }

    static let petalPalette: [(Color, Color)] = [
        (Color(red: 1.00, green: 0.86, blue: 0.92), Color(red: 0.98, green: 0.62, blue: 0.76)),
        (Color(red: 1.00, green: 0.95, blue: 0.97), Color(red: 0.96, green: 0.76, blue: 0.86)),
        (Color(red: 0.99, green: 0.74, blue: 0.84), Color(red: 0.90, green: 0.45, blue: 0.62)),
    ]

    static let petalLeaves: [Leaf] = {
        var seed: UInt64 = 314
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        return (0..<34).map { i in
            let depth = i < 14 ? 0 : (i < 27 ? 1 : 2)
            let base: Double = depth == 0 ? 6 : (depth == 1 ? 9 : 13)
            return Leaf(kind: .petal, x: rnd(), y: rnd(),
                        size: base + rnd() * base * 0.4,
                        speed: (0.014 + rnd() * 0.016) * (depth == 0 ? 0.7 : (depth == 1 ? 1.0 : 1.3)),
                        sway: 24 + rnd() * 40, swayFreq: 0.4 + rnd() * 0.5,
                        spin: (rnd() - 0.5) * 2.4, flipFreq: 0.6 + rnd() * 1.4,
                        phase: rnd() * 6.283, depth: depth,
                        colors: LeavesLayer.petalPalette[Int(rnd() * 3) % 3])
        }
    }()

    static let petalPath: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -0.72))
        p.addQuadCurve(to: CGPoint(x: 0.42, y: -1.0), control: CGPoint(x: 0.18, y: -1.05))
        p.addCurve(to: CGPoint(x: 0, y: 1.0), control1: CGPoint(x: 0.9, y: -0.6), control2: CGPoint(x: 0.45, y: 0.6))
        p.addCurve(to: CGPoint(x: -0.42, y: -1.0), control1: CGPoint(x: -0.45, y: 0.6), control2: CGPoint(x: -0.9, y: -0.6))
        p.addQuadCurve(to: CGPoint(x: 0, y: -0.72), control: CGPoint(x: -0.18, y: -1.05))
        p.closeSubpath()
        return p
    }()

    static let petalVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.85)); p.addLine(to: CGPoint(x: 0, y: -0.45))
        return p
    }()

    struct Leaf {
        let kind: Kind
        let x: Double          // 0…1 по ширине
        let y: Double          // стартовая фаза по высоте
        let size: Double       // пунктов
        let speed: Double      // доля экрана в секунду
        let sway: Double       // амплитуда покачивания
        let swayFreq: Double
        let spin: Double       // скорость вращения
        let flipFreq: Double   // скорость «переворота»
        let phase: Double
        let depth: Int         // 0 — дальний, 1 — средний, 2 — ближний
        let colors: (Color, Color)
    }

    /// Осенняя палитра: от золота до бордо
    static let palette: [(Color, Color)] = [
        (Color(red: 1.00, green: 0.78, blue: 0.20), Color(red: 0.95, green: 0.52, blue: 0.10)),   // золото
        (Color(red: 0.99, green: 0.55, blue: 0.12), Color(red: 0.86, green: 0.28, blue: 0.08)),   // оранжевый
        (Color(red: 0.93, green: 0.30, blue: 0.14), Color(red: 0.70, green: 0.10, blue: 0.10)),   // алый
        (Color(red: 0.78, green: 0.16, blue: 0.20), Color(red: 0.50, green: 0.06, blue: 0.14)),   // бордо
        (Color(red: 0.95, green: 0.68, blue: 0.25), Color(red: 0.62, green: 0.36, blue: 0.12)),   // охра
        (Color(red: 0.86, green: 0.72, blue: 0.22), Color(red: 0.55, green: 0.55, blue: 0.12)),   // жёлто-зелёный
    ]

    static let leaves: [Leaf] = {
        var seed: UInt64 = 2026
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        var list: [Leaf] = []
        for i in 0..<30 {
            let depth = i < 12 ? 0 : (i < 24 ? 1 : 2)
            let base: Double = depth == 0 ? 9 : (depth == 1 ? 15 : 22)
            let k = rnd()
            let kind: Kind = k < 0.5 ? .maple : (k < 0.78 ? .oval : .birch)
            list.append(Leaf(kind: kind,
                             x: rnd(), y: rnd(),
                             size: base + rnd() * base * 0.5,
                             speed: (0.018 + rnd() * 0.02) * (depth == 0 ? 0.7 : (depth == 1 ? 1.0 : 1.35)),
                             sway: 18 + rnd() * 34,
                             swayFreq: 0.35 + rnd() * 0.5,
                             spin: (rnd() - 0.5) * 1.6,
                             flipFreq: 0.4 + rnd() * 1.1,
                             phase: rnd() * 6.283,
                             depth: depth,
                             colors: LeavesLayer.palette[Int(rnd() * Double(LeavesLayer.palette.count)) % LeavesLayer.palette.count]))
        }
        return list
    }()

    // MARK: формы листьев (в единицах: высота ~2, центр в 0)

    static let maplePath: Path = {
        // правая половина кленового листа сверху вниз, левая — зеркально
        let right: [CGPoint] = [
            CGPoint(x: 0.00, y: -1.00),
            CGPoint(x: 0.10, y: -0.74), CGPoint(x: 0.26, y: -0.84), CGPoint(x: 0.21, y: -0.46),
            CGPoint(x: 0.44, y: -0.66), CGPoint(x: 0.52, y: -0.54), CGPoint(x: 0.80, y: -0.62),
            CGPoint(x: 0.70, y: -0.34), CGPoint(x: 0.84, y: -0.26), CGPoint(x: 0.48, y: 0.02),
            CGPoint(x: 0.54, y: 0.18), CGPoint(x: 0.12, y: 0.12), CGPoint(x: 0.03, y: 0.30),
        ]
        var p = Path()
        p.move(to: right[0])
        for pt in right.dropFirst() { p.addLine(to: pt) }
        for pt in right.dropFirst().reversed() { p.addLine(to: CGPoint(x: -pt.x, y: pt.y)) }
        p.closeSubpath()
        return p
    }()

    static let mapleVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.75)); p.addLine(to: CGPoint(x: 0, y: -0.9))      // черешок и главная жилка
        for s in [1.0, -1.0] {
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.72 * s, y: -0.55))
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.72 * s, y: -0.24))
            p.move(to: CGPoint(x: 0, y: 0.1)); p.addLine(to: CGPoint(x: 0.42 * s, y: 0.12))
        }
        return p
    }()

    static let ovalPath: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -1.0))
        p.addCurve(to: CGPoint(x: 0, y: 0.72), control1: CGPoint(x: 0.62, y: -0.55), control2: CGPoint(x: 0.48, y: 0.45))
        p.addCurve(to: CGPoint(x: 0, y: -1.0), control1: CGPoint(x: -0.48, y: 0.45), control2: CGPoint(x: -0.62, y: -0.55))
        p.closeSubpath()
        return p
    }()

    static let ovalVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 1.0)); p.addLine(to: CGPoint(x: 0, y: -0.85))
        for (y, len) in [(-0.45, 0.28), (-0.1, 0.36), (0.25, 0.30)] {
            p.move(to: CGPoint(x: 0, y: y + 0.12)); p.addLine(to: CGPoint(x: len, y: y - 0.08))
            p.move(to: CGPoint(x: 0, y: y + 0.12)); p.addLine(to: CGPoint(x: -len, y: y - 0.08))
        }
        return p
    }()

    static let birchPath: Path = {
        // округлый берёзовый лист с острым кончиком
        var p = Path()
        p.move(to: CGPoint(x: 0, y: -0.85))
        p.addCurve(to: CGPoint(x: 0, y: 0.55), control1: CGPoint(x: 0.35, y: -0.55), control2: CGPoint(x: 0.95, y: 0.35))
        p.addCurve(to: CGPoint(x: 0, y: -0.85), control1: CGPoint(x: -0.95, y: 0.35), control2: CGPoint(x: -0.35, y: -0.55))
        p.closeSubpath()
        return p
    }()

    static let birchVeins: Path = {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: 0.85)); p.addLine(to: CGPoint(x: 0, y: -0.7))
        for y in [-0.3, 0.05, 0.35] {
            p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: 0.38, y: y - 0.18))
            p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: -0.38, y: y - 0.18))
        }
        return p
    }()

    // MARK: отрисовка

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 15, paused: !animated)) { ctx in
            let t = animated ? ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 100_000) : 1234
            let list = petals ? Self.petalLeaves : Self.leaves
            Canvas { g, size in
                // дальние — бледнее и проще (раньше размывались фильтром на весь экран каждый кадр — дорого)
                for leaf in list { draw(leaf, in: &g, size: size, t: t) }
            }
        }
    }

    private func draw(_ leaf: Leaf, in g: inout GraphicsContext, size: CGSize, t: Double) {
        let travel = size.height + 80
        let prog = (leaf.y + t * leaf.speed).truncatingRemainder(dividingBy: 1.0)
        let y = CGFloat(prog) * travel - 40
        let x = CGFloat(leaf.x) * size.width
            + CGFloat(sin(t * leaf.swayFreq + leaf.phase) * leaf.sway)
        // лист раскачивается как маятник и медленно докручивается
        let angle = sin(t * leaf.swayFreq + leaf.phase + 1.2) * 0.8 + t * leaf.spin * 0.25
        // «переворот» в воздухе: сжимаем по ширине
        let flip = cos(t * leaf.flipFreq + leaf.phase)
        let flipX = CGFloat(flip >= 0 ? max(flip, 0.12) : min(flip, -0.12))
        let s = CGFloat(leaf.size) / 2

        let dark = scheme == .dark
        let baseOpacity: Double = leaf.depth == 0 ? 0.38 : (leaf.depth == 1 ? 0.75 : 0.92)
        let opacity = min(1, baseOpacity * (dark ? 0.9 : 1.0) * strength)
        // обратная сторона листа светлее
        let back = flip < 0

        var c = g
        c.opacity = opacity
        c.translateBy(x: x, y: y)
        c.rotate(by: .radians(angle))
        c.scaleBy(x: s * flipX, y: s)

        let shape: Path, veins: Path
        switch leaf.kind {
        case .maple: shape = Self.maplePath; veins = Self.mapleVeins
        case .oval: shape = Self.ovalPath; veins = Self.ovalVeins
        case .birch: shape = Self.birchPath; veins = Self.birchVeins
        case .petal: shape = Self.petalPath; veins = Self.petalVeins
        }

        let top = back ? leaf.colors.0.opacity(0.85) : leaf.colors.0
        let bottom = back ? leaf.colors.0 : leaf.colors.1
        // лёгкая тень у ближних листьев
        if leaf.depth == 2 {
            var sh = c
            sh.translateBy(x: 0.12, y: 0.18)
            sh.fill(shape, with: .color(.black.opacity(dark ? 0.35 : 0.12)))
        }
        c.fill(shape, with: .linearGradient(Gradient(colors: [top, bottom]),
                                            startPoint: CGPoint(x: -0.4, y: -1), endPoint: CGPoint(x: 0.4, y: 0.8)))
        // дальние мелкие листья — без блика и прожилок: их всё равно не видно
        guard leaf.depth > 0 else { return }
        // блик
        c.fill(shape, with: .radialGradient(Gradient(colors: [.white.opacity(0.22), .clear]),
                                            center: CGPoint(x: -0.25, y: -0.45), startRadius: 0, endRadius: 0.9))
        // прожилки
        c.stroke(veins, with: .color(leaf.colors.1.opacity(back ? 0.35 : 0.55)),
                 style: StrokeStyle(lineWidth: 1.0 / s * 0.9, lineCap: .round))
    }
}


/// Летнее солнце в углу
private struct SummerSun: View {
    let strength: Double
    var body: some View {
        ZStack {
            RadialGradient(colors: [Color(red: 1.0, green: 0.86, blue: 0.40).opacity(0.35 * strength), .clear],
                           center: UnitPoint(x: 0.9, y: 0.02), startRadius: 0, endRadius: 380)
            RadialGradient(colors: [Color(red: 0.40, green: 0.85, blue: 0.60).opacity(0.14 * strength), .clear],
                           center: UnitPoint(x: 0.0, y: 1.0), startRadius: 0, endRadius: 420)
        }
    }
}

// MARK: - Живой фон на Core Animation
//
// Раньше снег, листопад и свечение пересчитывались в SwiftUI 15–120 раз в секунду на главном потоке:
// каждая снежинка и каждый лист рисовались заново, и это спорило с прокруткой и нажатиями.
// Теперь каждая частица — слой с бесконечной анимацией: её ведёт сама система на видеочипе,
// главный поток свободен. Выглядит так же: листья падают, качаются, крутятся и переворачиваются.

enum ParticleKind: Equatable {
    case glow, snow, rising, leaves, petals
}

private struct ParticleConfig: Equatable {
    let kind: ParticleKind
    let color: UIColor
    let color2: UIColor
    let strength: Double
    let dark: Bool
}

struct ParticleField: UIViewRepresentable {
    let kind: ParticleKind
    var color: Color = .brand
    var color2: Color = .brand2
    let strength: Double
    let animated: Bool
    var dark = true

    func makeUIView(context: Context) -> ParticleHostView {
        let v = ParticleHostView()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        v.clipsToBounds = false
        return v
    }

    func updateUIView(_ v: ParticleHostView, context: Context) {
        v.configure(ParticleConfig(kind: kind, color: UIColor(color), color2: UIColor(color2),
                                   strength: strength, dark: dark))
        v.setAnimating(animated)
    }
}

final class ParticleHostView: UIView {
    private var config: ParticleConfig?
    private var builtSize: CGSize = .zero
    private var animating = true

    fileprivate func configure(_ c: ParticleConfig) {
        guard c != config else { return }
        config = c
        rebuild()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != builtSize { rebuild() }
    }

    /// Пауза без пересборки: время слоя замирает, при продолжении идёт с того же места
    func setAnimating(_ on: Bool) {
        guard on != animating else { return }
        animating = on
        let l = layer
        if on {
            let paused = l.timeOffset
            l.speed = 1
            l.timeOffset = 0
            l.beginTime = 0
            l.beginTime = l.convertTime(CACurrentMediaTime(), from: nil) - paused
        } else {
            let t = l.convertTime(CACurrentMediaTime(), from: nil)
            l.speed = 0
            l.timeOffset = t
        }
    }

    private func rebuild() {
        layer.sublayers?.forEach { $0.removeFromSuperlayer() }
        builtSize = bounds.size
        guard let c = config, bounds.width > 10, bounds.height > 10 else { return }
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        switch c.kind {
        case .glow: buildGlow(c)
        case .snow: buildFall(c, rising: false)
        case .rising: buildFall(c, rising: true)
        case .leaves: buildLeaves(c, list: LeavesLayer.leaves)
        case .petals: buildLeaves(c, list: LeavesLayer.petalLeaves)
        }
        CATransaction.commit()
    }

    private var now: CFTimeInterval { layer.convertTime(CACurrentMediaTime(), from: nil) }

    private func loop(_ key: String, from: Any, to: Any, duration: Double, phase: Double,
                      reverses: Bool = false, ease: Bool = false, additive: Bool = false) -> CABasicAnimation {
        let a = CABasicAnimation(keyPath: key)
        a.fromValue = from
        a.toValue = to
        a.duration = max(0.1, duration)
        a.autoreverses = reverses
        a.repeatCount = .infinity
        a.isAdditive = additive
        a.isRemovedOnCompletion = false
        a.timingFunction = CAMediaTimingFunction(name: ease ? .easeInEaseOut : .linear)
        a.beginTime = now - phase
        return a
    }

    // MARK: мягкие пятна света (фон по умолчанию)

    private func buildGlow(_ c: ParticleConfig) {
        let cx = bounds.midX, cy = bounds.midY
        let k = c.strength
        let blobs: [(UIColor, CGFloat, CGPoint, CGPoint)] = [
            (c.color.withAlphaComponent(0.20 * k), 340, CGPoint(x: cx + 90, y: cy - 180), CGPoint(x: cx - 120, y: cy - 300)),
            (c.color2.withAlphaComponent(0.13 * k), 280, CGPoint(x: cx - 80, y: cy + 300), CGPoint(x: cx + 130, y: cy + 120)),
            (c.color.withAlphaComponent(0.09 * k), 260, CGPoint(x: cx + 150, y: cy - 40), CGPoint(x: cx + 60, y: cy + 420)),
        ]
        for (color, size, a, b) in blobs {
            let g = CAGradientLayer()
            g.type = .radial
            g.colors = [color.cgColor, color.withAlphaComponent(0).cgColor]
            g.locations = [0, 0.625]
            g.startPoint = CGPoint(x: 0.5, y: 0.5)
            g.endPoint = CGPoint(x: 1, y: 1)
            g.bounds = CGRect(x: 0, y: 0, width: size * 1.6, height: size * 1.6)
            g.position = a
            g.add(loop("position", from: NSValue(cgPoint: a), to: NSValue(cgPoint: b),
                       duration: 18, phase: 0, reverses: true, ease: true), forKey: "drift")
            layer.addSublayer(g)
        }
    }

    // MARK: снег и летние блики

    private func buildFall(_ c: ParticleConfig, rising: Bool) {
        let w = bounds.width, h = bounds.height
        var seed: UInt64 = rising ? 7 : 42
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 11) / Double(1 << 53)
        }
        let image = rising ? ParticleArt.spark(c.color) : ParticleArt.dot(c.color)
        let count = rising ? 36 : 70
        for _ in 0..<count {
            let r = 0.8 + rnd() * 2.2
            let speed = 0.015 + rnd() * 0.03
            let x = CGFloat(rnd()) * w
            let drift = rnd()
            let startPhase = rnd()
            let side = CGFloat(rising ? r * 7 : r * 2)
            let s = CALayer()
            s.contents = image
            s.bounds = CGRect(x: 0, y: 0, width: side, height: side)
            s.position = CGPoint(x: x, y: -20)
            s.opacity = Float(min(1, rising ? 0.55 * c.strength : (0.18 + r * 0.08) * c.strength))
            let fallTime = rising ? 1.05 / (speed * 0.35) : 1.05 / speed
            s.add(loop("position.y", from: rising ? h + 20 : -20, to: rising ? -20 : h + 20,
                       duration: fallTime, phase: startPhase * fallTime), forKey: "fall")
            s.add(loop("position.x", from: x - 14, to: x + 14, duration: 5.2,
                       phase: drift * 10.4, reverses: true, ease: true), forKey: "sway")
            layer.addSublayer(s)
        }
    }

    // MARK: листопад и лепестки

    private func buildLeaves(_ c: ParticleConfig, list: [LeavesLayer.Leaf]) {
        let w = bounds.width, h = bounds.height
        for leaf in list {
            let side = CGFloat(leaf.size) * 1.25
            let base = leaf.depth == 0 ? 0.38 : (leaf.depth == 1 ? 0.75 : 0.92)
            // внешний слой — падает, качается и крутится; внутренний — переворачивается
            let holder = CALayer()
            holder.bounds = CGRect(x: 0, y: 0, width: side, height: side)
            let x = CGFloat(leaf.x) * w
            holder.position = CGPoint(x: x, y: -40)
            holder.opacity = Float(min(1, base * (c.dark ? 0.9 : 1.0) * c.strength))

            let sprite = CALayer()
            sprite.frame = holder.bounds
            sprite.contents = ParticleArt.leaf(leaf, side: side, dark: c.dark)
            holder.addSublayer(sprite)

            let fallTime = 1.0 / leaf.speed
            holder.add(loop("position.y", from: -40, to: h + 40, duration: fallTime,
                            phase: leaf.y * fallTime), forKey: "fall")
            let half = Double.pi / leaf.swayFreq
            let swayPhase = leaf.phase / leaf.swayFreq
            holder.add(loop("position.x", from: x - CGFloat(leaf.sway), to: x + CGFloat(leaf.sway),
                            duration: half, phase: swayPhase, reverses: true, ease: true), forKey: "sway")
            // маятник
            holder.add(loop("transform.rotation.z", from: -0.8, to: 0.8, duration: half,
                            phase: swayPhase + 1.2 / leaf.swayFreq, reverses: true, ease: true, additive: true),
                       forKey: "swing")
            // медленное докручивание
            let spin = leaf.spin * 0.25
            if abs(spin) > 0.02 {
                let turn = 2 * Double.pi * (spin > 0 ? 1 : -1)
                holder.add(loop("transform.rotation.z", from: 0, to: turn, duration: 2 * Double.pi / abs(spin),
                                phase: leaf.phase, additive: true), forKey: "spin")
            }
            // «переворот» в воздухе
            let flipHalf = Double.pi / leaf.flipFreq
            sprite.add(loop("transform.scale.x", from: 1, to: -1, duration: flipHalf,
                            phase: leaf.phase / leaf.flipFreq, reverses: true, ease: true), forKey: "flip")
            layer.addSublayer(holder)
        }
    }
}

/// Картинки частиц рисуются один раз и переиспользуются
private enum ParticleArt {
    private static var cache: [String: CGImage] = [:]

    private static func key(_ prefix: String, _ c: UIColor) -> String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        c.getRed(&r, green: &g, blue: &b, alpha: &a)
        return "\(prefix)-\(Int(r * 255))-\(Int(g * 255))-\(Int(b * 255))"
    }

    private static func render(_ size: CGFloat, _ draw: (CGContext) -> Void) -> CGImage? {
        let format = UIGraphicsImageRendererFormat()
        format.scale = UIScreen.main.scale
        format.opaque = false
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: format)
            .image { draw($0.cgContext) }.cgImage
    }

    static func dot(_ color: UIColor) -> CGImage? {
        let k = key("dot", color)
        if let hit = cache[k] { return hit }
        let img = render(8) { ctx in
            ctx.setFillColor(color.withAlphaComponent(1).cgColor)
            ctx.fillEllipse(in: CGRect(x: 0, y: 0, width: 8, height: 8))
        }
        cache[k] = img
        return img
    }

    static func spark(_ color: UIColor) -> CGImage? {
        let k = key("spark", color)
        if let hit = cache[k] { return hit }
        let img = render(24) { ctx in
            let colors = [color.withAlphaComponent(0.8).cgColor, color.withAlphaComponent(0).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                ctx.drawRadialGradient(g, startCenter: CGPoint(x: 12, y: 12), startRadius: 0,
                                       endCenter: CGPoint(x: 12, y: 12), endRadius: 12, options: [])
            }
        }
        cache[k] = img
        return img
    }

    /// Лист в тех же формах и красках, что раньше рисовались каждый кадр — теперь один раз
    static func leaf(_ leaf: LeavesLayer.Leaf, side: CGFloat, dark: Bool) -> CGImage? {
        let k = "leaf-\(leaf.kind)-\(Int(side))-\(dark)-" + key("c", UIColor(leaf.colors.0)) + key("d", UIColor(leaf.colors.1))
        if let hit = cache[k] { return hit }
        let s = CGFloat(leaf.size) / 2
        let shape: Path, veins: Path
        switch leaf.kind {
        case .maple: shape = LeavesLayer.maplePath; veins = LeavesLayer.mapleVeins
        case .oval: shape = LeavesLayer.ovalPath; veins = LeavesLayer.ovalVeins
        case .birch: shape = LeavesLayer.birchPath; veins = LeavesLayer.birchVeins
        case .petal: shape = LeavesLayer.petalPath; veins = LeavesLayer.petalVeins
        }
        let top = UIColor(leaf.colors.0).cgColor
        let bottom = UIColor(leaf.colors.1).cgColor
        let img = render(side) { ctx in
            ctx.translateBy(x: side / 2, y: side / 2)
            ctx.scaleBy(x: s, y: s)
            // лёгкая тень у ближних листьев — запечена в картинку, а не считается на лету
            if leaf.depth == 2 {
                ctx.saveGState()
                ctx.translateBy(x: 0.12, y: 0.18)
                ctx.addPath(shape.cgPath)
                ctx.setFillColor(UIColor.black.withAlphaComponent(dark ? 0.35 : 0.12).cgColor)
                ctx.fillPath()
                ctx.restoreGState()
            }
            ctx.saveGState()
            ctx.addPath(shape.cgPath)
            ctx.clip()
            if let g = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: [top, bottom] as CFArray, locations: [0, 1]) {
                ctx.drawLinearGradient(g, start: CGPoint(x: -0.4, y: -1), end: CGPoint(x: 0.4, y: 0.8),
                                       options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
            }
            if leaf.depth > 0,
               let hl = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                   colors: [UIColor.white.withAlphaComponent(0.22).cgColor, UIColor.white.withAlphaComponent(0).cgColor] as CFArray,
                                   locations: [0, 1]) {
                ctx.drawRadialGradient(hl, startCenter: CGPoint(x: -0.25, y: -0.45), startRadius: 0,
                                       endCenter: CGPoint(x: -0.25, y: -0.45), endRadius: 0.9, options: [])
            }
            ctx.restoreGState()
            if leaf.depth > 0 {
                ctx.addPath(veins.cgPath)
                ctx.setStrokeColor(UIColor(leaf.colors.1).withAlphaComponent(0.55).cgColor)
                ctx.setLineWidth(0.9 / s)
                ctx.setLineCap(.round)
                ctx.strokePath()
            }
        }
        cache[k] = img
        return img
    }
}

// MARK: - Мягкое затемнение под часами: контент, уходящий под статус-бар, не лезет под время и батарею

struct StatusBarScrim: ViewModifier {
    func body(content: Content) -> some View {
        content.overlay(alignment: .top) {
            LinearGradient(colors: [Color(.systemBackground).opacity(0.9),
                                    Color(.systemBackground).opacity(0.55),
                                    Color(.systemBackground).opacity(0)],
                           startPoint: .top, endPoint: .bottom)
                .frame(height: 22)
                .ignoresSafeArea(edges: .top)
                .allowsHitTesting(false)
        }
    }
}

extension View {
    func statusBarScrim() -> some View { modifier(StatusBarScrim()) }
}
