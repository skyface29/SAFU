import SwiftUI
import UIKit

extension Color {
    static let safuBlue = Color(red: 0.16, green: 0.45, blue: 0.95)
    static let safuCyan = Color(red: 0.25, green: 0.80, blue: 0.95)
    static let safuViolet = Color(red: 0.50, green: 0.36, blue: 0.95)
}

/// Живой фон: медленно плавающие размытые пятна
struct AmbientBackground: View {
    @State private var move = false

    var body: some View {
        ZStack {
            Color(.systemBackground)
            Circle()
                .fill(Color.safuBlue.opacity(0.35))
                .frame(width: 340, height: 340)
                .blur(radius: 90)
                .offset(x: move ? -120 : 90, y: move ? -300 : -180)
            Circle()
                .fill(Color.safuCyan.opacity(0.22))
                .frame(width: 280, height: 280)
                .blur(radius: 90)
                .offset(x: move ? 130 : -80, y: move ? 120 : 300)
            Circle()
                .fill(Color.safuViolet.opacity(0.22))
                .frame(width: 260, height: 260)
                .blur(radius: 100)
                .offset(x: move ? 60 : 150, y: move ? 420 : -40)
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.easeInOut(duration: 14).repeatForever(autoreverses: true)) {
                move = true
            }
        }
    }
}

extension View {
    /// Стеклянная подложка
    func glass(_ radius: CGFloat = 24) -> some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        return self
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

/// Кнопка, которая мягко сжимается при нажатии
struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .soft).impactOccurred() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
}
