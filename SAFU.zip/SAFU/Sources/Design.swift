import SwiftUI
import UIKit

// MARK: - Тема

enum AccentTheme: String, CaseIterable, Identifiable {
    case blue, violet, teal, orange, pink
    case cyber, aurora, ice, lime, crimson, gold, graphite

    var id: String { rawValue }

    var title: String {
        switch self {
        case .blue: return "Синяя"
        case .violet: return "Фиолет"
        case .teal: return "Бирюза"
        case .orange: return "Апельсин"
        case .pink: return "Розовая"
        case .cyber: return "Кибер"
        case .aurora: return "Сияние"
        case .ice: return "Лёд"
        case .lime: return "Лайм"
        case .crimson: return "Алая"
        case .gold: return "Золото"
        case .graphite: return "Графит"
        }
    }

    var color: Color {
        switch self {
        case .blue: return Color(red: 0.16, green: 0.45, blue: 0.98)
        case .violet: return Color(red: 0.52, green: 0.35, blue: 0.98)
        case .teal: return Color(red: 0.10, green: 0.68, blue: 0.66)
        case .orange: return Color(red: 0.98, green: 0.50, blue: 0.18)
        case .pink: return Color(red: 0.95, green: 0.30, blue: 0.55)
        case .cyber: return Color(red: 0.00, green: 0.78, blue: 0.95)
        case .aurora: return Color(red: 0.16, green: 0.80, blue: 0.62)
        case .ice: return Color(red: 0.35, green: 0.66, blue: 0.95)
        case .lime: return Color(red: 0.45, green: 0.80, blue: 0.10)
        case .crimson: return Color(red: 0.90, green: 0.16, blue: 0.30)
        case .gold: return Color(red: 0.92, green: 0.65, blue: 0.12)
        case .graphite: return Color(red: 0.38, green: 0.42, blue: 0.50)
        }
    }

    var secondary: Color {
        switch self {
        case .blue: return Color(red: 0.30, green: 0.80, blue: 0.98)
        case .violet: return Color(red: 0.90, green: 0.40, blue: 0.90)
        case .teal: return Color(red: 0.35, green: 0.85, blue: 0.45)
        case .orange: return Color(red: 0.98, green: 0.78, blue: 0.25)
        case .pink: return Color(red: 0.98, green: 0.55, blue: 0.40)
        case .cyber: return Color(red: 0.72, green: 0.35, blue: 1.00)
        case .aurora: return Color(red: 0.45, green: 0.40, blue: 0.95)
        case .ice: return Color(red: 0.70, green: 0.90, blue: 1.00)
        case .lime: return Color(red: 0.10, green: 0.75, blue: 0.60)
        case .crimson: return Color(red: 1.00, green: 0.50, blue: 0.30)
        case .gold: return Color(red: 0.98, green: 0.40, blue: 0.30)
        case .graphite: return Color(red: 0.62, green: 0.66, blue: 0.74)
        }
    }

    static var current: AccentTheme {
        AccentTheme(rawValue: UserDefaults.standard.string(forKey: "theme") ?? "") ?? .blue
    }
}

extension Color {
    static var brand: Color { AccentTheme.current.color }
    static var brand2: Color { AccentTheme.current.secondary }
}

var brandGradient: LinearGradient {
    LinearGradient(colors: [.brand, .brand2], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// MARK: - Живой фон

/// Какой фон под всеми экранами
enum BackdropStyle: String, CaseIterable, Identifiable {
    case glow, aurora, grid, snow, wash, plain

    var id: String { rawValue }

    var title: String {
        switch self {
        case .glow: return "Свет"
        case .aurora: return "Сияние"
        case .grid: return "Сетка"
        case .snow: return "Снег"
        case .wash: return "Градиент"
        case .plain: return "Чистый"
        }
    }

    var icon: String {
        switch self {
        case .glow: return "circle.hexagongrid.fill"
        case .aurora: return "wind"
        case .grid: return "grid"
        case .snow: return "snowflake"
        case .wash: return "paintbrush.pointed.fill"
        case .plain: return "square"
        }
    }

    static var current: BackdropStyle {
        BackdropStyle(rawValue: UserDefaults.standard.string(forKey: "bg.style") ?? "") ?? .glow
    }
}

struct AmbientBackground: View {
    @State private var move = false
    @AppStorage("ambient") private var animated = true
    @AppStorage("bg.style") private var styleRaw = BackdropStyle.glow.rawValue
    @AppStorage("bg.intensity") private var intensity = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    private var style: BackdropStyle { BackdropStyle(rawValue: styleRaw) ?? .glow }
    private var canAnimate: Bool { animated && !UIAccessibility.isReduceMotionEnabled }

    /// Мягкое пятно света. Радиальный градиент вместо .blur(radius: 90):
    /// выглядит так же, но не пересчитывает размытие на весь экран каждый кадр.
    private func glow(_ color: Color, _ size: CGFloat) -> some View {
        Circle()
            .fill(RadialGradient(colors: [color, color.opacity(0)], center: .center,
                                 startRadius: 0, endRadius: size * 0.5))
            .frame(width: size * 1.6, height: size * 1.6)
    }

    var body: some View {
        // Пятна лежат в overlay: так они НЕ влияют на размер экрана
        // (иначе большие круги растягивают вёрстку шире экрана)
        Color(.systemBackground)
            .overlay { layer }
            .clipped()
            .compositingGroup()
            .ignoresSafeArea()
            .allowsHitTesting(false)
            .accessibilityHidden(true)
            .id(themeRaw)
            .onAppear {
                guard canAnimate else { return }
                withAnimation(.easeInOut(duration: 18).repeatForever(autoreverses: true)) {
                    move = true
                }
            }
    }

    @ViewBuilder private var layer: some View {
        let k = intensity
        switch style {
        case .glow:
            glowLayer(k)
        case .aurora:
            AuroraLayer(animated: canAnimate, strength: k)
        case .grid:
            ZStack {
                glowLayer(k * 0.7)
                TechGrid(animated: canAnimate, strength: k)
            }
        case .snow:
            ZStack {
                glowLayer(k * 0.6)
                SnowLayer(animated: canAnimate, strength: k)
            }
        case .wash:
            LinearGradient(colors: [Color.brand.opacity(0.22 * k), Color.brand2.opacity(0.10 * k), .clear],
                           startPoint: .topLeading, endPoint: .bottom)
        case .plain:
            Color.clear
        }
    }

    private func glowLayer(_ k: Double) -> some View {
        ZStack {
            glow(Color.brand.opacity(0.20 * k), 340)
                .offset(x: move ? -120 : 90, y: move ? -300 : -180)
            glow(Color.brand2.opacity(0.13 * k), 280)
                .offset(x: move ? 130 : -80, y: move ? 120 : 300)
            glow(Color.brand.opacity(0.09 * k), 260)
                .offset(x: move ? 60 : 150, y: move ? 420 : -40)
        }
        .frame(width: 0, height: 0)
    }
}

/// Технологичная сетка с точками на пересечениях и бегущей полосой «сканера»
private struct TechGrid: View {
    let animated: Bool
    let strength: Double
    @State private var scan = false
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                Canvas { ctx, size in
                    let step: CGFloat = 26
                    let line = Color.primary.opacity((scheme == .dark ? 0.07 : 0.05) * strength)
                    var path = Path()
                    var x: CGFloat = 0
                    while x <= size.width { path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)); x += step }
                    var y: CGFloat = 0
                    while y <= size.height { path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); y += step }
                    ctx.stroke(path, with: .color(line), lineWidth: 0.5)
                    // яркие узлы через один
                    let dot = Color.brand.opacity(0.35 * strength)
                    var i = 0
                    x = 0
                    while x <= size.width {
                        y = 0
                        var j = 0
                        while y <= size.height {
                            if (i + j) % 7 == 0 {
                                ctx.fill(Path(ellipseIn: CGRect(x: x - 1.2, y: y - 1.2, width: 2.4, height: 2.4)), with: .color(dot))
                            }
                            y += step; j += 1
                        }
                        x += step; i += 1
                    }
                }
                // затухание сетки к низу
                .mask(LinearGradient(colors: [.black, .black.opacity(0.4), .clear], startPoint: .top, endPoint: .bottom))

                LinearGradient(colors: [.clear, Color.brand.opacity(0.10 * strength), .clear],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 140)
                    .offset(y: scan ? geo.size.height : -140)
            }
        }
        .onAppear {
            guard animated else { return }
            withAnimation(.linear(duration: 7).repeatForever(autoreverses: false)) { scan = true }
        }
    }
}

/// Северное сияние: на iOS 18 — живой MeshGradient, на iOS 17 — мягкие ленты
private struct AuroraLayer: View {
    let animated: Bool
    let strength: Double

    var body: some View {
        #if compiler(>=6.0)
        if #available(iOS 18.0, *) {
            TimelineView(.animation(minimumInterval: 1.0 / 20, paused: !animated)) { ctx in
                MeshGradient(width: 3, height: 3,
                             points: Self.points(ctx.date.timeIntervalSinceReferenceDate),
                             colors: colors)
            }
        } else {
            fallback
        }
        #else
        fallback
        #endif
    }

    private var colors: [Color] {
        let k = strength
        return [Color.brand.opacity(0.35 * k), Color.brand2.opacity(0.25 * k), Color.brand.opacity(0.15 * k),
                Color.brand2.opacity(0.18 * k), Color.brand.opacity(0.10 * k), Color.brand2.opacity(0.22 * k),
                Color.clear, Color.clear, Color.clear]
    }

    private static func points(_ time: Double) -> [SIMD2<Float>] {
        let t = Float(time.truncatingRemainder(dividingBy: 3600))
        let l: Float = 0.5 + 0.12 * sin(t * 0.35)
        let cx: Float = 0.5 + 0.18 * cos(t * 0.27)
        let cy: Float = 0.45 + 0.12 * sin(t * 0.31)
        let r: Float = 0.5 + 0.12 * cos(t * 0.33)
        return [SIMD2<Float>(0, 0), SIMD2<Float>(0.5, 0), SIMD2<Float>(1, 0),
                SIMD2<Float>(0, l), SIMD2<Float>(cx, cy), SIMD2<Float>(1, r),
                SIMD2<Float>(0, 1), SIMD2<Float>(0.5, 1), SIMD2<Float>(1, 1)]
    }

    private var fallback: some View {
        LinearGradient(colors: [Color.brand.opacity(0.30 * strength), Color.brand2.opacity(0.18 * strength), .clear],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

/// Падающий снег — для университета у Белого моря
private struct SnowLayer: View {
    let animated: Bool
    let strength: Double

    private struct Flake { let x: Double; let y: Double; let r: Double; let speed: Double; let drift: Double }

    private static let flakes: [Flake] = {
        var seed: UInt64 = 42
        func rnd() -> Double {
            seed = seed &* 6364136223846793005 &+ 1442695040888963407
            return Double(seed >> 33) / Double(UInt32.max >> 1)
        }
        return (0..<70).map { _ in
            Flake(x: rnd(), y: rnd(), r: 0.8 + rnd() * 2.2, speed: 0.015 + rnd() * 0.03, drift: rnd() * 6.28)
        }
    }()

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animated)) { ctx in
            let t = ctx.date.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 10_000)
            Canvas { g, size in
                for f in Self.flakes {
                    let y = CGFloat((f.y + t * f.speed).truncatingRemainder(dividingBy: 1.05)) * size.height
                    let x = CGFloat(f.x) * size.width + CGFloat(sin(t * 0.6 + f.drift) * 14)
                    let r = CGFloat(f.r)
                    let rect = CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)
                    g.fill(Path(ellipseIn: rect), with: .color(Color.brand.opacity((0.18 + f.r * 0.08) * strength)))
                }
            }
        }
    }
}

// MARK: - Стекло (на iOS 26 — настоящее Liquid Glass)

/// Стили карточек
enum CardStyle: Int, CaseIterable, Identifiable {
    case glass = 0, solid = 1, tinted = 2, neon = 3, minimal = 4, raised = 5
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .glass: return "Стекло"
        case .solid: return "Сплошные"
        case .tinted: return "Цветные"
        case .neon: return "Неон"
        case .minimal: return "Контур"
        case .raised: return "Объём"
        }
    }
}

struct GlassModifier: ViewModifier {
    let radius: CGFloat
    let interactive: Bool
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("ui.radius") private var radiusScale = 1.0
    @AppStorage("theme") private var themeRaw = AccentTheme.blue.rawValue

    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: max(4, radius * CGFloat(radiusScale)), style: .continuous)
        switch CardStyle(rawValue: cardStyle) ?? .glass {
        case .solid:
            content
                .background(Color(.secondarySystemBackground), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.06), lineWidth: 0.6))
        case .tinted:
            content
                .background(Color.brand.opacity(0.14), in: shape)
                .overlay(shape.strokeBorder(Color.brand.opacity(0.25), lineWidth: 0.8))
        case .neon:
            content
                .background(Color(.secondarySystemBackground).opacity(0.55), in: shape)
                .overlay(shape.strokeBorder(LinearGradient(colors: [Color.brand, Color.brand2.opacity(0.35), Color.brand.opacity(0.6)],
                                                           startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.1))
                .shadow(color: Color.brand.opacity(0.22), radius: 10, y: 0)
        case .minimal:
            content
                .background(Color.primary.opacity(0.025), in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.12), lineWidth: 0.7))
        case .raised:
            content
                .background(Color(.secondarySystemGroupedBackground), in: shape)
                .shadow(color: .black.opacity(0.10), radius: 14, y: 6)
        case .glass:
            glassBody(content, shape)
        }
    }

    @ViewBuilder
    private func glassBody(_ content: Content, _ shape: RoundedRectangle) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            if interactive {
                content.glassEffect(.regular.interactive(), in: shape)
            } else {
                content.glassEffect(.regular, in: shape)
            }
        } else {
            content
                .background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        }
        #else
        content
            .background(.ultraThinMaterial, in: shape)
            .overlay(shape.strokeBorder(Color.white.opacity(0.14), lineWidth: 0.6))
        #endif
    }
}

struct TabBarMinimize: ViewModifier {
    @ViewBuilder
    func body(content: Content) -> some View {
        #if compiler(>=6.2)
        if #available(iOS 26.0, *) {
            content.tabBarMinimizeBehavior(.onScrollDown)
        } else {
            content
        }
        #else
        content
        #endif
    }
}

extension View {
    func glass(_ radius: CGFloat = 24, interactive: Bool = false) -> some View {
        modifier(GlassModifier(radius: radius, interactive: interactive))
    }

    func bounce(on value: Int) -> some View {
        modifier(BounceModifier(value: value))
    }
}

private struct BounceModifier: ViewModifier {
    let value: Int
    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            content.symbolEffect(.bounce, value: value)
        } else {
            content
        }
    }
}

// MARK: - Мелкие компоненты

struct PressableStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.95 : 1)
            .opacity(configuration.isPressed ? 0.85 : 1)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct SectionTitle: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.system(.title3, design: .rounded).weight(.bold))
    }
}

struct ScreenHeader<Trailing: View>: View {
    let caption: String
    let title: String
    @ViewBuilder var trailing: () -> Trailing
    @AppStorage("ui.gradTitle") private var gradTitle = false
    @AppStorage("ui.font") private var fontRaw = AppFont.rounded.rawValue

    var body: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    if gradTitle {
                        Capsule().fill(brandGradient).frame(width: 14, height: 3)
                    }
                    Text(caption)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .textCase(.uppercase)
                        .tracking(gradTitle ? 1.2 : 0)
                }
                Text(title)
                    .font(.system(size: 30, weight: .bold, design: (AppFont(rawValue: fontRaw) ?? .rounded).design))
                    .foregroundStyle(gradTitle ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.primary))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            Spacer()
            trailing()
        }
    }
}

struct CircleIconButton: View {
    let icon: String
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .foregroundStyle(.primary)
            .frame(width: 44, height: 44)
            .glass(22, interactive: true)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let text: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 40, weight: .semibold))
                .foregroundStyle(brandGradient)
            Text(title)
                .font(.headline)
            Text(text)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(28)
        .glass(26)
    }
}

// MARK: - Вибрация и форматирование

enum Haptics {
    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "haptics") as? Bool ?? true
    }
    static func tap() {
        guard enabled else { return }
        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
    }
    static func success() {
        guard enabled else { return }
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }
}

enum Fmt {
    private static let ru = Locale(identifier: "ru_RU")

    static func relative(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.locale = ru
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }

    static func due(_ date: Date) -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "d MMM, HH:mm"
        return f.string(from: date)
    }

    static func today() -> String {
        let f = DateFormatter()
        f.locale = ru
        f.dateFormat = "EEEE, d MMMM"
        return f.string(from: Date())
    }

    static var greeting: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Доброе утро"
        case 12..<18: return "Добрый день"
        case 18..<23: return "Добрый вечер"
        default: return "Доброй ночи"
        }
    }
}


// MARK: - Анимации и цвета предметов

enum Prefs {
    static var animations: Bool { UserDefaults.standard.object(forKey: "animations") as? Bool ?? true }
}

struct PulsingDot: View {
    var color: Color = .brand
    @State private var on = false

    var body: some View {
        ZStack {
            Circle()
                .fill(color.opacity(0.4))
                .frame(width: 16, height: 16)
                .scaleEffect(on ? 1.7 : 0.6)
                .opacity(on ? 0 : 1)
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
        }
        .frame(width: 18, height: 18)
        .onAppear {
            guard Prefs.animations else { return }
            withAnimation(.easeOut(duration: 1.3).repeatForever(autoreverses: false)) { on = true }
        }
    }
}

struct SpinningIcon: View {
    let spinning: Bool
    @State private var angle: Double = 0

    var body: some View {
        Image(systemName: "arrow.triangle.2.circlepath")
            .rotationEffect(.degrees(angle))
            .onAppear { start() }
            .onChange(of: spinning) { _ in start() }
    }

    private func start() {
        if spinning {
            withAnimation(.linear(duration: 1).repeatForever(autoreverses: false)) { angle = 360 }
        } else {
            withAnimation(.default) { angle = 0 }
        }
    }
}

enum SubjectColor {
    static func color(for subject: String) -> Color {
        guard UserDefaults.standard.object(forKey: "schedule.colors") as? Bool ?? true else { return .brand }
        var h: UInt64 = 5381
        for u in subject.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
        return Color(hue: Double(h % 360) / 360.0, saturation: 0.55, brightness: 0.92)
    }
}

/// Плавное появление элементов списка по очереди
struct StaggerIn: ViewModifier {
    let index: Int
    @State private var shown = false

    func body(content: Content) -> some View {
        content
            .opacity(shown ? 1 : 0)
            .offset(y: shown ? 0 : 8)
            .onAppear {
                guard Prefs.animations, index < 10 else { shown = true; return }
                withAnimation(.spring(response: 0.32, dampingFraction: 0.86).delay(0.018 * Double(index))) {
                    shown = true
                }
            }
    }
}

extension View {
    func staggerIn(_ index: Int) -> some View { modifier(StaggerIn(index: index)) }
}
