import SwiftUI
import UIKit
import CoreLocation
#if canImport(YandexMapsMobile)
import YandexMapsMobile
#endif

// MARK: - Карта транспорта (Yandex MapKit)
// Если библиотека не подключилась или ключа нет — показываем Яндекс Карты во встроенном Safari.

enum YandexMap {
    /// Ключ подставляется при сборке из секрета GitHub YANDEX_MAPKIT_KEY
    static var apiKey: String {
        let k = (Bundle.main.object(forInfoDictionaryKey: "YandexMapKitKey") as? String) ?? ""
        return k.hasPrefix("$(") ? "" : k.trimmingCharacters(in: .whitespaces)
    }

    static var isAvailable: Bool {
        #if canImport(YandexMapsMobile)
        return !apiKey.isEmpty
        #else
        return false
        #endif
    }
}

/// Экран «Транспорт»: сама карта или запасной вариант
struct TransportMapScreen: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL

    var body: some View {
        if YandexMap.isAvailable {
            NavigationStack {
                ZStack(alignment: .bottom) {
                    TransportMapContainer()
                        .ignoresSafeArea(edges: .bottom)
                    Text("Автобусы видны, если перевозчик передаёт GPS в Яндекс")
                        .font(.caption2.weight(.semibold))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(.ultraThinMaterial, in: Capsule())
                        .padding(.bottom, 24)
                }
                .navigationTitle("Транспорт")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button { openURL(Bus150.yandexURL) } label: {
                            Image(systemName: "arrow.up.forward.app")
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Готово") { dismiss() }.fontWeight(.semibold)
                    }
                }
            }
        } else {
            SafariView(url: Bus150.yandexURL).ignoresSafeArea()
        }
    }
}

#if canImport(YandexMapsMobile)

private enum MapKitBoot {
    static var started = false
    static func start() {
        guard !started else { return }
        YMKMapKit.setApiKey(YandexMap.apiKey)
        YMKMapKit.setLocale("ru_RU")
        YMKMapKit.sharedInstance().onStart()
        started = true
    }
}

/// Карта + кнопки «Я», «Архангельск», «Северодвинск»
private struct TransportMapContainer: View {
    @State private var command: MapCommand?

    var body: some View {
        ZStack(alignment: .topTrailing) {
            YandexMapRepresentable(command: $command)
            VStack(spacing: 10) {
                mapButton("location.fill") { command = .me }
                mapButton("building.2.fill", label: "Арх") { command = .arkhangelsk }
                mapButton("house.fill", label: "Свд") { command = .severodvinsk }
            }
            .padding(.top, 12)
            .padding(.trailing, 12)
        }
    }

    private func mapButton(_ icon: String, label: String? = nil, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            action()
        } label: {
            VStack(spacing: 1) {
                Image(systemName: icon).font(.system(size: 15, weight: .bold))
                if let label { Text(label).font(.system(size: 9, weight: .bold)) }
            }
            .foregroundStyle(Color.brand)
            .frame(width: 46, height: 46)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(color: .black.opacity(0.15), radius: 6, y: 2)
        }
        .buttonStyle(.plain)
    }
}

private enum MapCommand: Equatable {
    case me, arkhangelsk, severodvinsk
}

private struct YandexMapRepresentable: UIViewRepresentable {
    @Binding var command: MapCommand?

    final class Coordinator {
        var userLayer: YMKUserLocationLayer?
        var transportLayer: YMKMasstransitLayer?
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> YMKMapView {
        MapKitBoot.start()
        // работает и если init вернёт Optional, и если нет
        let view = (YMKMapView(frame: .zero) as YMKMapView?)!
        let map = view.mapWindow.map
        // стартуем с того города, где ты сейчас
        let city = CityLocator.shared.city ?? .arkhangelsk
        move(map, to: city == .severodvinsk ? HomeCity.sevCenter : HomeCity.arkhCenter, zoom: 12, animated: false)

        // моя точка
        let user = YMKMapKit.sharedInstance().createUserLocationLayer(with: view.mapWindow)
        user.setVisibleWithOn(true)
        context.coordinator.userLayer = user

        // общественный транспорт: машины на линии и остановки
        let transport = YMKTransportFactory.instance().createMasstransitLayer(with: view.mapWindow)
        transport.setVehiclesVisibleWithOn(true)
        transport.setStopsVisibleWithOn(true)
        context.coordinator.transportLayer = transport
        return view
    }

    func updateUIView(_ view: YMKMapView, context: Context) {
        guard let cmd = command else { return }
        let map = view.mapWindow.map
        switch cmd {
        case .arkhangelsk: move(map, to: HomeCity.arkhCenter, zoom: 12)
        case .severodvinsk: move(map, to: HomeCity.sevCenter, zoom: 12)
        case .me:
            // последняя известная точка телефона (разрешение уже дано для автобуса)
            if let loc = CLLocationManager().location {
                move(map, to: loc, zoom: 15)
            }
        }
        DispatchQueue.main.async { command = nil }
    }

    private func move(_ map: YMKMap, to loc: CLLocation, zoom: Float, animated: Bool = true) {
        let pos = YMKCameraPosition(target: YMKPoint(latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude),
                                    zoom: zoom, azimuth: 0, tilt: 0)
        if animated {
            map.move(with: pos, animation: YMKAnimation(type: .smooth, duration: 0.6), cameraCallback: nil)
        } else {
            map.move(with: pos)
        }
    }
}


#else

/// Без библиотеки карты — пустышка (сюда не попадём: isAvailable == false)
private struct TransportMapContainer: View {
    var body: some View { Color.clear }
}

#endif
