import SwiftUI
import UIKit
import UserNotifications
import UniformTypeIdentifiers

// Посещаемость для старосты и зама: перекличка свайпами, отчёт картинкой,
// напоминание на паре, рапортичка за месяц и обмен отметками файлом

// MARK: - Перекличка свайпами

struct RollCallView: View {
    let slot: LessonSlot
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var queue: [Student] = []
    @State private var index = 0
    @State private var history: [Step] = []
    @State private var drag: CGSize = .zero
    /// Взялись за верхнюю половину карточки — наклон как у листа в руке, за нижнюю — в обратную сторону
    @State private var grabTop = true
    /// Отметка, которую уже «взяли» дотянув до порога: от неё вибрация и печать
    @State private var armed: Mark?
    /// Карточки, которые ещё летят за экран: следующую можно листать, не дожидаясь их
    @State private var flyers: [Flyer] = []
    /// Свайп от левого края: на сколько вытянули прошлую карточку
    @State private var back: CGFloat = 0
    @State private var backArmed = false
    /// Карточка возвращается после отмены — без печати и подсветки той отметки, что сняли
    @State private var returning = false
    @State private var started = false
    @State private var prevKey: String?
    @State private var share: ShareItem?
    @State private var cheer = false

    private struct Step {
        let student: Student
        let old: Mark?
        let new: Mark
    }

    /// Насколько далеко улетает карточка — с запасом за край любого iPhone
    private static let away: CGFloat = 700
    /// Откуда выезжает карточка при свайпе от края: сразу за левым краем экрана
    private static let edgeStart: CGFloat = -460

    private var key: String { AttendanceStore.key(for: slot) }
    private var done: Bool { started && index >= queue.count }
    /// Итог — когда последняя карточка уже улетела
    private var finished: Bool { done && flyers.isEmpty }
    /// Куда сейчас тянут верхнюю карточку
    private var heading: Mark? { returning ? nil : direction(drag) }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.05, green: 0.07, blue: 0.17), Color(red: 0.11, green: 0.08, blue: 0.24)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            // фон подсвечивается цветом отметки, пока тянешь карточку
            (heading?.color ?? .clear)
                .opacity(0.28 * progress(drag))
                .ignoresSafeArea()
                .allowsHitTesting(false)

            VStack(spacing: 18) {
                topBar
                if finished {
                    finish
                } else {
                    Spacer(minLength: 0)
                    cards
                        .zIndex(1)   // улетающая карточка — поверх кнопок
                    hint
                    Spacer(minLength: 0)
                    buttons
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 10)
        }
        .overlay(alignment: .leading) { edge }
        .preferredColorScheme(.dark)
        .onAppear(perform: setup)
        .sheet(item: $share) { ShareSheet(items: $0.items) }
    }

    private func setup() {
        guard !started else { return }
        let all = attendance.sortedStudents
        let open = all.filter { attendance.mark(of: $0, in: key) == nil }
        // все уже отмечены — проходим заново, чтобы проверить
        queue = open.isEmpty ? all : open
        prevKey = attendance.previousLesson(before: slot)?.key
        started = true
    }

    // MARK: Шапка

    private var topBar: some View {
        HStack(spacing: 12) {
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .frame(width: 36, height: 36)
                    .background(.white.opacity(0.12), in: Circle())
            }
            VStack(alignment: .leading, spacing: 1) {
                Text(slot.lesson.subject)
                    .font(.subheadline.weight(.bold))
                    .lineLimit(1)
                Text(KindStyle.of(slot.lesson.kind).label + " · " + Fmt.formatter("H:mm").string(from: slot.start))
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.6))
            }
            Spacer()
            if !finished {
                Text("\(min(index + 1, queue.count)) / \(queue.count)")
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .monospacedDigit()
                    .contentTransition(.numericText())
            }
            Button { undo() } label: {
                Image(systemName: "arrow.uturn.backward")
                    .font(.system(size: 15, weight: .bold))
                    .frame(width: 36, height: 36)
                    .background(.white.opacity(0.12), in: Circle())
            }
            .disabled(history.isEmpty)
            .opacity(history.isEmpty ? 0.35 : 1)
        }
        .foregroundStyle(.white)
        .padding(.top, 8)
        .overlay(alignment: .bottom) {
            GeometryReader { g in
                Capsule().fill(.white.opacity(0.1))
                    .overlay(alignment: .leading) {
                        Capsule().fill(brandGradient)
                            .frame(width: g.size.width * (queue.isEmpty ? 0 : CGFloat(index) / CGFloat(queue.count)))
                    }
            }
            .frame(height: 4)
            .offset(y: 12)
        }
    }

    // MARK: Карточки

    private var visible: [Student] {
        Array(queue[min(index, queue.count)..<min(index + 3, queue.count)])
    }

    private var cards: some View {
        let p = progress(drag)
        return ZStack {
            ForEach(Array(visible.enumerated()), id: \.element.id) { depth, s in
                // как глубоко карточка в стопке: пока тянешь верхнюю, нижние подъезжают на её место
                let pos: Double = max(0, Double(depth) - p)
                let top = depth == 0
                card(s, stamp: top ? heading : nil, strength: p, popped: armed != nil)
                    // нижние карточки притемнены накладкой, а не прозрачностью — так дешевле для видеокарты
                    .overlay(
                        RoundedRectangle(cornerRadius: 30, style: .continuous)
                            .fill(Color.black.opacity(0.32 * pos))
                            .allowsHitTesting(false)
                    )
                    .scaleEffect(CGFloat(1 - 0.06 * pos))
                    .offset(y: CGFloat(18 * pos))
                    .offset(top ? drag : .zero)
                    .rotationEffect(.degrees(top ? tilt(drag) : 0))
                    .zIndex(Double(3 - depth))
                    .transition(.asymmetric(insertion: .opacity.combined(with: .scale(scale: 0.9)), removal: .identity))
            }
            // прошлая карточка выезжает из-за левого края вслед за пальцем
            if back > 0, let last = history.last {
                let x = Self.edgeStart + back * 1.3
                card(last.student, stamp: nil, strength: 0, popped: false)
                    .offset(x: x)
                    .rotationEffect(.degrees(Double(x) / 20))
                    .zIndex(10)
                    .allowsHitTesting(false)
            }
            ForEach(flyers) { f in
                FlyingCard(flyer: f, done: { land(f) }) {
                    card(f.student, stamp: f.mark, strength: 1, popped: true)
                }
                .zIndex(20)
                .transition(.identity)
            }
        }
        .frame(height: 380)
        .contentShape(Rectangle())
        .gesture(swipe)
    }

    private func card(_ s: Student, stamp: Mark?, strength: Double, popped: Bool) -> some View {
        let was = prevKey.flatMap { attendance.mark(of: s, in: $0) }
        let note = attendance.excuse(for: s, at: slot.start)
        let tint = SubjectColor.color(for: s.name)
        return VStack(spacing: 16) {
            Text(initials(s.name))
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .frame(width: 96, height: 96)
                .background(LinearGradient(colors: [tint, tint.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: Circle())
            Text(s.name)
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.6)
                .padding(.horizontal, 16)
            HStack(spacing: 8) {
                if let was {
                    tag(L("на прошлой: \(was.title.lowercased())"), was.color)
                }
                if let note {
                    tag(L("справка") + (note.reason.isEmpty ? "" : " · \(note.reason)"), Mark.excused.color)
                }
                if let m = attendance.explicitMark(of: s, in: key) {
                    tag(L("сейчас: \(m.title.lowercased())"), m.color)
                }
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity)
        .frame(height: 360)
        .background(
            RoundedRectangle(cornerRadius: 30, style: .continuous)
                .fill(Color(red: 0.14, green: 0.15, blue: 0.27))
                .overlay(
                    // карточка окрашивается в цвет отметки, пока её тянешь
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .fill((stamp?.color ?? .clear).opacity(0.16 * strength))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .strokeBorder((stamp?.color ?? .white).opacity(stamp == nil ? 0.12 : 0.9), lineWidth: 2)
                )
                .shadow(color: .black.opacity(0.35), radius: 18, y: 10)
        )
        .overlay(alignment: .top) {
            if let stamp {
                Text(stamp.stamp)
                    .font(.system(size: 26, weight: .heavy, design: .rounded))
                    .tracking(1.5)
                    .foregroundStyle(stamp.color)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 6)
                    .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(stamp.color, lineWidth: 3))
                    .rotationEffect(.degrees(stamp == .present ? -12 : (stamp == .absent ? 12 : 0)))
                    // дотянул до порога — печать «шлёпается» на карточку
                    .scaleEffect(popped ? 1 : 0.8)
                    .animation(.spring(response: 0.22, dampingFraction: 0.5), value: popped)
                    .opacity(strength)
                    .padding(.top, 22)
            }
        }
    }

    private func tag(_ t: String, _ c: Color) -> some View {
        Text(t)
            .font(.caption.weight(.semibold))
            .foregroundStyle(c)
            .lineLimit(1)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(c.opacity(0.16), in: Capsule())
    }

    private func initials(_ name: String) -> String {
        name.split(separator: " ").prefix(2).compactMap { $0.first.map(String.init) }.joined().uppercased()
    }

    private var hint: some View {
        Text(history.isEmpty ? L("→ был   ← н/б   ↑ уважительная   ↓ опоздал")
             : history.count == 1 ? L("Ошибся? Потяни от левого края — карточка вернётся") : " ")
            .font(.caption.weight(.semibold))
            .foregroundStyle(.white.opacity(0.55))
            .lineLimit(1)
            .minimumScaleFactor(0.8)
            .frame(height: 16)
            .animation(.easeInOut(duration: 0.25), value: history.count)
    }

    // MARK: Жесты

    private func direction(_ t: CGSize) -> Mark? {
        if abs(t.height) > abs(t.width) {
            if t.height < -24 { return .excused }
            if t.height > 24 { return .late }
            return nil
        }
        if t.width > 24 { return .present }
        if t.width < -24 { return .absent }
        return nil
    }

    /// Насколько дотянули до порога (1 — отметка взята)
    private func progress(_ t: CGSize) -> Double {
        min(1, reach(t) / 110)
    }

    private func reach(_ t: CGSize) -> Double {
        Double(max(abs(t.width), abs(t.height)))
    }

    private func tilt(_ t: CGSize) -> Double {
        Double(t.width) / 20 * (grabTop ? 1 : -1)
    }

    private var swipe: some Gesture {
        DragGesture(minimumDistance: 2)
            .onChanged { v in
                guard index < queue.count, back == 0 else { return }
                if drag == .zero || returning {
                    grabTop = v.startLocation.y < 190
                    returning = false
                }
                drag = v.translation
                let d = progress(v.translation) >= 1 ? direction(v.translation) : nil
                if d != armed {
                    armed = d
                    if d != nil { Haptics.tap() }
                }
            }
            .onEnded { v in
                guard index < queue.count, back == 0 else { return }
                armed = nil
                // бросок: короткое, но быстрое движение тоже засчитывается
                let fling = v.predictedEndTranslation
                if let d = direction(v.translation) ?? direction(fling),
                   progress(v.translation) >= 1 || (direction(fling) == d && reach(fling) >= 220) {
                    commit(d, velocity: v.velocity)
                } else {
                    withAnimation(.interpolatingSpring(stiffness: 260, damping: 22)) { drag = .zero }
                }
            }
    }

    /// Куда улетает карточка: в сторону отметки и чуть вверх или вниз — куда вёл палец
    private func exitPoint(_ m: Mark, from t: CGSize, velocity v: CGSize) -> CGSize {
        let side = max(-260, min(260, t.height + v.height * 0.1))
        let lift = max(-260, min(260, t.width + v.width * 0.1))
        switch m {
        case .present: return CGSize(width: Self.away, height: side)
        case .absent: return CGSize(width: -Self.away, height: side)
        case .excused: return CGSize(width: lift, height: -Self.away - 200)
        case .late: return CGSize(width: lift, height: Self.away + 200)
        }
    }

    private func commit(_ m: Mark, velocity v: CGSize = .zero) {
        guard index < queue.count else { return }
        let s = queue[index]
        history.append(Step(student: s, old: attendance.explicitMark(of: s, in: key), new: m))
        attendance.set(m, for: s, slot: slot)
        Haptics.tap()
        let from = drag
        let to = exitPoint(m, from: from, velocity: v)
        // скорость пальца передаётся карточке: брошенная быстро и улетает быстро
        let dx = to.width - from.width, dy = to.height - from.height
        let dist = max(1, hypot(dx, dy))
        let along = (v.width * dx + v.height * dy) / dist
        let speed = Double(min(10, max(0, along / dist)))
        let angle = returning ? 0 : tilt(from)
        let spin: Double = m == .present ? 14 : (m == .absent ? -14 : 0)
        flyers.append(Flyer(student: s, mark: m, from: from, to: to, angle: angle,
                            endAngle: angle + spin * (grabTop ? 1 : -1), speed: speed))
        returning = false
        withAnimation(.spring(response: 0.34, dampingFraction: 0.86)) {
            index += 1
            drag = .zero
        }
        if index >= queue.count { Haptics.success() }
    }

    /// Карточка улетела за экран
    private func land(_ f: Flyer) {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) {
            flyers.removeAll { $0.id == f.id }
        }
    }

    /// Вернуть последнюю карточку: прилетает оттуда, куда ушла, или из-под пальца при свайпе от края
    private func undo(from start: CGSize? = nil) {
        guard let last = history.popLast(),
              let i = queue.firstIndex(where: { $0.id == last.student.id }) else { return }
        attendance.set(last.old, for: last.student, slot: slot)
        Haptics.tap()
        var t = Transaction()
        t.disablesAnimations = true
        withTransaction(t) {
            flyers.removeAll { $0.student.id == last.student.id }
            index = i
            drag = start ?? exitPoint(last.new, from: .zero, velocity: .zero)
            back = 0
            armed = nil
            returning = true
        }
        // на следующем кадре — уже с анимацией, чтобы карточка именно прилетела, а не появилась
        DispatchQueue.main.async {
            withAnimation(.spring(response: 0.42, dampingFraction: 0.8)) { drag = .zero }
        }
    }

    /// Полоска у левого края: потянул вправо — прошлая карточка возвращается
    private var edge: some View {
        Color.clear
            .frame(width: 18)
            .frame(maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 6, coordinateSpace: .global)
                    .onChanged { v in
                        guard !history.isEmpty, drag == .zero || returning else { return }
                        back = max(0, v.translation.width)
                        let over = back >= 140
                        if over != backArmed {
                            backArmed = over
                            if over { Haptics.tap() }
                        }
                    }
                    .onEnded { v in
                        backArmed = false
                        guard !history.isEmpty, back > 0 else { back = 0; return }
                        if back >= 140 || v.predictedEndTranslation.width >= 260 {
                            undo(from: CGSize(width: Self.edgeStart + back * 1.3, height: 0))
                        } else {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { back = 0 }
                        }
                    }
            )
            .ignoresSafeArea()
    }

    private var buttons: some View {
        let d = heading
        let p = progress(drag)
        return HStack(spacing: 14) {
            roundButton(.absent, "xmark", 64, d, p)
            roundButton(.late, "clock.fill", 52, d, p)
            roundButton(.excused, "doc.text.fill", 52, d, p)
            roundButton(.present, "checkmark", 64, d, p)
        }
        .padding(.bottom, 6)
    }

    private func roundButton(_ m: Mark, _ icon: String, _ size: CGFloat, _ d: Mark?, _ p: Double) -> some View {
        // кнопка той отметки, куда тянешь, подрастает, остальные притухают
        let lit = d == m ? p : 0
        let dim = d != nil && d != m ? p : 0
        return Button { commit(m) } label: {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: size * 0.38, weight: .heavy))
                    .foregroundStyle(.white)
                    .frame(width: size, height: size)
                    .background(m.color.gradient, in: Circle())
                    .shadow(color: m.color.opacity(0.5), radius: 10, y: 4)
                    .scaleEffect(1 + 0.18 * lit)
                Text(m.title)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.75))
            }
            .opacity(1 - 0.5 * dim)
        }
        .buttonStyle(.plain)
        .disabled(index >= queue.count)
    }

    // MARK: Итог

    private var finish: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 46))
                    .foregroundStyle(Mark.present.color)
                    .symbolEffect(.bounce, value: cheer)
                    .padding(.top, 18)
                    .onAppear { cheer.toggle() }
                Text(L("Перекличка готова"))
                    .font(.system(.title2, design: .rounded).weight(.bold))
                AttendanceShareCard(r: AttendanceReport(slot: slot, store: attendance), framed: false)
                    .environment(\.colorScheme, .light)
                Button { shareImage() } label: {
                    Label(L("Отправить картинкой"), systemImage: "paperplane.fill")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(brandGradient, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)
                HStack(spacing: 12) {
                    ShareLink(item: attendance.report(for: slot)) {
                        Label(L("Текстом"), systemImage: "text.alignleft")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    Button { dismiss() } label: {
                        Text(L("Готово"))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                fixList
            }
            .padding(.bottom, 20)
        }
        .transition(.opacity.combined(with: .scale(scale: 0.96)))
    }

    /// Поправить любую отметку прямо в итоге — отчёт выше сразу пересчитывается
    private var fixList: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(L("Поправить отметку"))
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white.opacity(0.8))
                .padding(.bottom, 4)
            ForEach(attendance.sortedStudents) { s in
                fixRow(s)
            }
        }
        .padding(14)
        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func fixRow(_ s: Student) -> some View {
        let m = attendance.mark(of: s, in: key)
        return Menu {
            ForEach(Mark.allCases, id: \.self) { mk in
                Button {
                    Haptics.tap()
                    attendance.set(mk, for: s, slot: slot)
                } label: {
                    Label(mk.title, systemImage: mk.icon)
                }
            }
            if attendance.explicitMark(of: s, in: key) != nil {
                Button(role: .destructive) {
                    attendance.set(nil, for: s, slot: slot)
                } label: {
                    Label(L("Снять отметку"), systemImage: "minus.circle")
                }
            }
        } label: {
            HStack(spacing: 10) {
                Text(s.name)
                    .font(.subheadline)
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Spacer(minLength: 8)
                Text(m?.title ?? "—")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(m?.color ?? .white.opacity(0.5))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background((m?.color ?? .white).opacity(0.16), in: Capsule())
            }
            .padding(.vertical, 5)
            .contentShape(Rectangle())
        }
    }

    @MainActor
    private func shareImage() {
        Haptics.tap()
        if let img = AttendanceShareCard.render(slot: slot, store: attendance) {
            share = ShareItem(items: [img])
        } else {
            share = ShareItem(items: [attendance.report(for: slot)])
        }
    }
}

/// Карточка, улетевшая с переклички: летит сама, со скоростью пальца, и не мешает листать дальше
fileprivate struct Flyer: Identifiable {
    let id = UUID()
    let student: Student
    let mark: Mark
    let from: CGSize
    let to: CGSize
    let angle: Double
    let endAngle: Double
    /// Скорость пальца в долях пути за секунду — начальная скорость пружины
    let speed: Double
}

private struct FlyingCard<Content: View>: View {
    let flyer: Flyer
    let done: () -> Void
    let content: Content
    @State private var gone = false

    init(flyer: Flyer, done: @escaping () -> Void, @ViewBuilder content: () -> Content) {
        self.flyer = flyer
        self.done = done
        self.content = content()
    }

    var body: some View {
        content
            .offset(gone ? flyer.to : flyer.from)
            .rotationEffect(.degrees(gone ? flyer.endAngle : flyer.angle))
            .allowsHitTesting(false)
            .onAppear {
                withAnimation(.interpolatingSpring(mass: 1, stiffness: 150, damping: 24, initialVelocity: flyer.speed)) {
                    gone = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: done)
            }
    }
}

fileprivate extension Mark {
    /// Надпись-печать на карточке
    var stamp: String {
        switch self {
        case .present: return L("БЫЛ")
        case .late: return L("ОПОЗДАЛ")
        case .absent: return L("НЕ БЫЛ")
        case .excused: return L("УВАЖИТ.")
        }
    }

    var icon: String {
        switch self {
        case .present: return "checkmark"
        case .late: return "clock.fill"
        case .absent: return "xmark"
        case .excused: return "doc.text.fill"
        }
    }
}

// MARK: - Отчёт по занятию картинкой

struct AttendanceReport {
    let subject: String
    let kind: String
    let start: Date
    let end: Date
    let total: Int
    var present: [String] = []
    var late: [String] = []
    var absent: [String] = []
    var excused: [String] = []

    var attended: Int { present.count + late.count }
    var unmarked: Int { total - present.count - late.count - absent.count - excused.count }

    init(slot: LessonSlot, store: AttendanceStore) {
        subject = slot.lesson.subject
        kind = slot.lesson.kind
        start = slot.start
        end = slot.end
        let list = store.sortedStudents
        total = list.count
        let k = AttendanceStore.key(for: slot)
        for s in list {
            switch store.mark(of: s, in: k) {
            case .present?: present.append(s.name)
            case .late?: late.append(s.name)
            case .absent?: absent.append(s.name)
            case .excused?: excused.append(s.name)
            case nil: break
            }
        }
    }
}

struct AttendanceShareCard: View {
    let r: AttendanceReport
    /// Для картинки — с подложкой и тенью; в приложении — просто карточка
    var framed = true

    @MainActor
    static func render(slot: LessonSlot, store: AttendanceStore) -> UIImage? {
        let card = AttendanceShareCard(r: AttendanceReport(slot: slot, store: store)).environment(\.colorScheme, .light)
        let renderer = ImageRenderer(content: card)
        renderer.scale = 3
        return renderer.uiImage
    }

    var body: some View {
        let color = SubjectColor.color(for: r.subject)
        let card = VStack(alignment: .leading, spacing: 0) {
            header(color)
            VStack(alignment: .leading, spacing: 14) {
                overview(color)
                if r.absent.isEmpty && r.unmarked == 0 {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.seal.fill").foregroundStyle(Mark.present.color)
                        Text(L("Отсутствующих нет")).font(.system(size: 15, weight: .semibold))
                    }
                    .foregroundStyle(Color(white: 0.15))
                }
                if !r.present.isEmpty { names(L("Присутствуют"), r.present, .present) }
                if !r.late.isEmpty { names(L("Опоздали"), r.late, .late) }
                if !r.absent.isEmpty { names(L("Отсутствуют"), r.absent, .absent) }
                if !r.excused.isEmpty { names(L("По уважительной"), r.excused, .excused) }
                if r.unmarked > 0 {
                    Text(L("Не отмечены: \(r.unmarked)"))
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color(white: 0.5))
                }
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)

            HStack(spacing: 5) {
                Image(systemName: "snowflake")
                Text(L("Арктика"))
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(Color(white: 0.6))
            .padding(.horizontal, 18)
            .padding(.bottom, 14)
        }
        .frame(width: framed ? 360 : nil)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))

        if framed {
            card
                .shadow(color: .black.opacity(0.12), radius: 14, y: 6)
                .padding(18)
                .background(LinearGradient(colors: [color.opacity(0.16), Color.brand.opacity(0.10)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing))
                .background(Color.white)
        } else {
            card
        }
    }

    private func header(_ color: Color) -> some View {
        let group = UserDefaults.standard.string(forKey: "group") ?? ""
        let day = Fmt.formatter("EEEE, d MMMM").string(from: r.start)
        let time = Fmt.formatter("H:mm").string(from: r.start) + "–" + Fmt.formatter("H:mm").string(from: r.end)
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "person.3.fill")
                Text(L("ПОСЕЩАЕМОСТЬ")).tracking(1.2)
                Spacer()
                if !group.isEmpty {
                    Text(L("гр. \(group)"))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(.white.opacity(0.25), in: Capsule())
                }
            }
            .font(.system(size: 11, weight: .heavy))
            .foregroundStyle(.white.opacity(0.9))
            Text(r.subject)
                .font(.system(size: 23, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 6) {
                Image(systemName: "calendar")
                Text(KindStyle.of(r.kind).label + " · " + day + " · " + time)
            }
            .font(.system(size: 13, weight: .semibold))
            .foregroundStyle(.white.opacity(0.95))
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [color, Color.brand], startPoint: .topLeading, endPoint: .bottomTrailing))
    }

    private func overview(_ color: Color) -> some View {
        let frac = r.total == 0 ? 0 : CGFloat(r.attended) / CGFloat(r.total)
        return HStack(spacing: 16) {
            ZStack {
                Circle().stroke(Color(white: 0.92), lineWidth: 9)
                Circle()
                    .trim(from: 0, to: frac)
                    .stroke(LinearGradient(colors: [Mark.present.color, Color(red: 0.1, green: 0.62, blue: 0.55)],
                                           startPoint: .top, endPoint: .bottom),
                            style: StrokeStyle(lineWidth: 9, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                VStack(spacing: 0) {
                    Text("\(r.attended)")
                        .font(.system(size: 26, weight: .bold, design: .rounded))
                        .foregroundStyle(Color(white: 0.1))
                    Text(L("из \(r.total)"))
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(Color(white: 0.5))
                }
            }
            .frame(width: 84, height: 84)
            VStack(spacing: 8) {
                HStack(spacing: 8) {
                    stat(r.present.count, L("были"), .present)
                    stat(r.late.count, L("опоздали"), .late)
                }
                HStack(spacing: 8) {
                    stat(r.absent.count, L("н/б"), .absent)
                    stat(r.excused.count, L("уважит."), .excused)
                }
            }
        }
    }

    private func stat(_ n: Int, _ t: String, _ m: Mark) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("\(n)")
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(m.color)
            Text(t)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(Color(white: 0.45))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(m.color.opacity(0.1), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
    }

    private func names(_ title: String, _ list: [String], _ m: Mark) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Circle().fill(m.color).frame(width: 8, height: 8)
                Text(title.uppercased())
                    .font(.system(size: 11, weight: .heavy))
                    .tracking(0.8)
                    .foregroundStyle(m.color)
                Text("\(list.count)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 1)
                    .background(m.color, in: Capsule())
            }
            VStack(alignment: .leading, spacing: 5) {
                ForEach(Array(list.enumerated()), id: \.offset) { i, n in
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("\(i + 1).")
                            .font(.system(size: 13, weight: .semibold).monospacedDigit())
                            .foregroundStyle(Color(white: 0.55))
                            .frame(width: 24, alignment: .trailing)
                        Text(n)
                            .font(.system(size: 15))
                            .foregroundStyle(Color(white: 0.12))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(m.color.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

// MARK: - Напоминание отметить ребят

enum AttendanceReminder {
    static let subjectKey = "att.subject"
    static let startKey = "att.start"
    private static let ids = (0..<16).map { "att.\($0)" }

    /// Только старосте и заму, и пока не выключили
    static var enabled: Bool {
        let d = UserDefaults.standard
        let role = d.integer(forKey: "user.role")
        return (role == 1 || role == 2) && (d.object(forKey: "att.remind") as? Bool ?? true)
    }

    /// Через 10 минут после начала каждой пары на ближайшие дни
    static func schedule(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ids)
        guard enabled, AttendanceStore.hasRoster else { return }
        let now = Date()
        var seen = Set<Int>()
        let plan = ScheduleQuery.slots(data, from: 0, days: 4)
            .sorted { $0.start < $1.start }
            .filter { s in
                let fire = s.start.addingTimeInterval(600)
                // подгруппы в одно время — одно напоминание
                return fire > now && fire < s.end && seen.insert(Int(s.start.timeIntervalSince1970)).inserted
            }
            .prefix(ids.count)
        for (i, s) in plan.enumerated() {
            let content = UNMutableNotificationContent()
            content.title = L("Отметь, кто на паре")
            content.body = L("\(s.lesson.subject) · \(KindStyle.of(s.lesson.kind).label.lowercased()). Перекличка свайпами — меньше минуты")
            content.sound = .default
            content.threadIdentifier = "attendance"
            content.userInfo = [subjectKey: s.lesson.subject, startKey: s.start.timeIntervalSince1970]
            let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: s.start.addingTimeInterval(600))
            let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
            center.add(UNNotificationRequest(identifier: ids[i], content: content, trigger: trigger))
        }
    }
}

/// Открывает перекличку из уведомления и принимает файл с отметками от старосты или зама
final class AttendanceRouter: ObservableObject {
    static let shared = AttendanceRouter()

    struct Target: Identifiable {
        let id = UUID()
        let subject: String
        let start: Date
    }

    @Published var rollCall: Target?
    @Published var incoming: MarksPackageFile?

    /// Файл .arkmarks открыли из Telegram, Файлов или AirDrop
    func open(_ url: URL) -> Bool {
        guard url.isFileURL, url.pathExtension.lowercased() == AttendanceExchange.ext else { return false }
        if let p = AttendanceExchange.read(url) { incoming = MarksPackageFile(package: p) }
        return true
    }
}

/// Перекличка, открытая из уведомления: находим эту пару в расписании
struct AttendanceRollCallHost: View {
    let target: AttendanceRouter.Target
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        if let slot = ScheduleEngine.slots(on: target.start, data: schedule.data)
            .first(where: { $0.lesson.subject == target.subject && abs($0.start.timeIntervalSince(target.start)) < 120 }) {
            RollCallView(slot: slot)
        } else {
            VStack(spacing: 14) {
                Image(systemName: "calendar.badge.exclamationmark").font(.largeTitle)
                Text(L("Эта пара пропала из расписания")).font(.headline)
                Button(L("Закрыть")) { dismiss() }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// MARK: - Справки

struct ExcusesView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var adding = false

    var body: some View {
        let byID = Dictionary(attendance.students.map { ($0.id, $0.name) }, uniquingKeysWith: { a, _ in a })
        let list = attendance.excuses.sorted { $0.from > $1.from }
        List {
            Section {
                Button { adding = true } label: { Label(L("Добавить справку"), systemImage: "plus.circle.fill") }
            } footer: {
                Text(L("На все пары этих дней студент получит «У» сам — отмечать вручную не нужно."))
            }
            if !list.isEmpty {
                Section(L("Справки")) {
                    ForEach(list) { e in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(byID[e.studentID] ?? L("Студент удалён")).font(.subheadline.weight(.semibold))
                            Text(period(e) + (e.reason.isEmpty ? "" : " · \(e.reason)"))
                                .font(.caption)
                                .foregroundStyle(e.covers(Date()) ? Mark.excused.color : .secondary)
                        }
                    }
                    .onDelete { idx in
                        for i in idx { attendance.removeExcuse(list[i]) }
                    }
                }
            }
        }
        .navigationTitle(L("Справки"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button(L("Готово")) { dismiss() } }
        }
        .sheet(isPresented: $adding) {
            NavigationStack { ExcuseEditor() }.environmentObject(attendance)
        }
    }

    private func period(_ e: Excuse) -> String {
        let f = Fmt.formatter("d MMM")
        return Calendar.current.isDate(e.from, inSameDayAs: e.to) ? f.string(from: e.from)
            : f.string(from: e.from) + " – " + f.string(from: e.to)
    }
}

private struct ExcuseEditor: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var student: UUID?
    @State private var from = Date()
    @State private var to = Date()
    @State private var reason = L("Справка")
    private let reasons = [L("Справка"), L("Больничный"), L("Соревнования"), L("Заявление"), L("Военкомат")]

    var body: some View {
        Form {
            Picker(L("Студент"), selection: $student) {
                Text(L("Выбери")).tag(UUID?.none)
                ForEach(attendance.sortedStudents) { Text($0.name).tag(UUID?.some($0.id)) }
            }
            .pickerStyle(.navigationLink)
            Section(L("Период")) {
                DatePicker(L("С"), selection: $from, displayedComponents: .date)
                DatePicker(L("По"), selection: $to, in: from..., displayedComponents: .date)
            }
            Section(L("Причина")) {
                TextField(L("Справка"), text: $reason)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(reasons, id: \.self) { r in
                            Button(r) { reason = r }
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(reason == r ? Mark.excused.color.opacity(0.25) : Color.primary.opacity(0.07), in: Capsule())
                                .buttonStyle(.plain)
                        }
                    }
                }
            }
        }
        .onChange(of: from) { v in if to < v { to = v } }
        .navigationTitle(L("Новая справка"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button(L("Отмена")) { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button(L("Сохранить")) {
                    guard let id = student else { return }
                    attendance.addExcuse(Excuse(studentID: id, from: from, to: max(from, to),
                                                reason: reason.trimmingCharacters(in: .whitespacesAndNewlines)))
                    Haptics.success()
                    dismiss()
                }
                .disabled(student == nil)
            }
        }
    }
}

// MARK: - Рапортичка за месяц

struct AttendanceMonthView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var month = Date()
    @State private var expanded: UUID?
    @State private var files: [URL] = []

    /// В рапортичке пропуски считают в академических часах: одна пара — два часа
    static let hoursPerPair = 2

    struct SubjectStats {
        let subject: String
        let stats: AttendanceStore.Stats
    }

    struct Row {
        let student: Student
        let total: AttendanceStore.Stats
        let bySubject: [SubjectStats]
        var absentHours: Int { total.absent * AttendanceMonthView.hoursPerPair }
        var excusedHours: Int { total.excused * AttendanceMonthView.hoursPerPair }
        /// Много прогулов — выделяем красным
        var alarming: Bool { absentHours >= 8 || (total.percent ?? 100) < 70 }
    }

    private var range: Range<Date> {
        let i = Calendar.current.dateInterval(of: .month, for: month) ?? DateInterval(start: month, duration: 86_400 * 30)
        return i.start..<i.end
    }

    private var title: String { Fmt.formatter("LLLL yyyy").string(from: month).capitalized }

    private var lessonCount: Int {
        attendance.recordedLessons.filter { range.contains($0.start) }.count
    }

    private func rows() -> [Row] {
        let subjects = Set(attendance.recordedLessons.filter { range.contains($0.start) }.map(\.subject)).sorted()
        return attendance.sortedStudents.map { s in
            Row(student: s,
                total: attendance.stats(for: s, in: range),
                bySubject: subjects.map { SubjectStats(subject: $0, stats: attendance.stats(for: s, subject: $0, in: range)) }
                    .filter { $0.stats.total > 0 })
        }
    }

    var body: some View {
        let list = rows()
        List {
            Section {
                HStack {
                    Button { shift(-1) } label: { Image(systemName: "chevron.left") }
                    Spacer()
                    Text(title).font(.headline)
                    Spacer()
                    Button { shift(1) } label: { Image(systemName: "chevron.right") }
                        .disabled(range.upperBound > Date())
                }
                .buttonStyle(.borderless)
                .font(.headline)
                Text(L("Отмечено занятий: \(lessonCount) · 1 пара = \(Self.hoursPerPair) часа"))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section {
                ForEach(list, id: \.student.id) { r in
                    Button {
                        withAnimation(.snappy) { expanded = expanded == r.student.id ? nil : r.student.id }
                    } label: {
                        HStack(spacing: 8) {
                            Text(r.student.name)
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(r.alarming ? Mark.absent.color : .primary)
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            cell("\(r.absentHours)", Mark.absent.color)
                            cell("\(r.excusedHours)", Mark.excused.color)
                            cell("\(r.total.late)", Mark.late.color)
                            cell(r.total.percent.map { "\($0)%" } ?? "—", .secondary)
                        }
                    }
                    .buttonStyle(.plain)
                    if expanded == r.student.id {
                        ForEach(r.bySubject, id: \.subject) { b in
                            HStack(spacing: 8) {
                                Text(b.subject)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                cell("\(b.stats.absent * Self.hoursPerPair)", Mark.absent.color, small: true)
                                cell("\(b.stats.excused * Self.hoursPerPair)", Mark.excused.color, small: true)
                                cell("\(b.stats.late)", Mark.late.color, small: true)
                                cell(b.stats.percent.map { "\($0)%" } ?? "—", .secondary, small: true)
                            }
                            .padding(.leading, 12)
                        }
                        if r.bySubject.isEmpty {
                            Text(L("В этом месяце отметок нет")).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            } header: {
                HStack(spacing: 8) {
                    Text(L("Студент")).frame(maxWidth: .infinity, alignment: .leading)
                    Text(L("н/б, ч")).frame(width: 46)
                    Text(L("уваж, ч")).frame(width: 46)
                    Text(L("опозд")).frame(width: 46)
                    Text("%").frame(width: 46)
                }
            } footer: {
                Text(L("Нажми на студента — покажу по предметам. Красным — 8 и больше часов прогулов или посещаемость ниже 70%."))
            }

            Section {
                Button { export(list) } label: {
                    Label(L("Сделать PDF и таблицу Excel"), systemImage: "doc.richtext")
                }
                if !files.isEmpty {
                    ShareLink(items: files) {
                        Label(L("Отправить рапортичку"), systemImage: "square.and.arrow.up")
                    }
                }
            } footer: {
                Text(L("Файлы сохраняются в «Файлы › Отчёты»."))
            }
        }
        .navigationTitle(L("Рапортичка"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button(L("Готово")) { dismiss() } }
        }
    }

    private func cell(_ t: String, _ c: Color, small: Bool = false) -> some View {
        Text(t)
            .font(.system(small ? .caption : .subheadline, design: .rounded).weight(.bold))
            .monospacedDigit()
            .foregroundStyle(c)
            .frame(width: 46)
    }

    private func shift(_ n: Int) {
        month = Calendar.current.date(byAdding: .month, value: n, to: month) ?? month
        files = []
        expanded = nil
        Haptics.tap()
    }

    private func export(_ list: [Row]) {
        let dir = FileService.root.appendingPathComponent("Отчёты", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let pdf = dir.appendingPathComponent("Рапортичка \(title).pdf")
        let csv = dir.appendingPathComponent("Рапортичка \(title).csv")
        try? Self.pdf(list, title: title, lessons: lessonCount).write(to: pdf)
        try? (Data([0xEF, 0xBB, 0xBF]) + Data(Self.csv(list).utf8)).write(to: csv)
        files = [pdf, csv]
        Haptics.success()
    }

    static func csv(_ list: [Row]) -> String {
        func q(_ s: String) -> String { "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        let subjects = Array(Set(list.flatMap { $0.bySubject.map(\.subject) })).sorted()
        var header = ["№", L("Студент"), L("Н/б, ч"), L("Уваж., ч"), L("Опоздания"), L("Посещаемость, %")]
        header += subjects.map { L("Н/б, ч: \($0)") }
        var lines = [header.map(q).joined(separator: ";")]
        for (i, r) in list.enumerated() {
            var cells = ["\(i + 1)", r.student.name, "\(r.absentHours)", "\(r.excusedHours)", "\(r.total.late)",
                         r.total.percent.map { "\($0)" } ?? ""]
            for s in subjects {
                let st = r.bySubject.first { $0.subject == s }?.stats
                cells.append(st.map { "\($0.absent * hoursPerPair)" } ?? "")
            }
            lines.append(cells.map(q).joined(separator: ";"))
        }
        return lines.joined(separator: "\n")
    }

    /// Рапортичка на листе A4: таблица по группе и пропуски по предметам
    static func pdf(_ list: [Row], title: String, lessons: Int) -> Data {
        let page = CGRect(x: 0, y: 0, width: 595, height: 842)
        let margin: CGFloat = 36
        let group = UserDefaults.standard.string(forKey: "group") ?? ""
        let red = UIColor(red: 0.85, green: 0.18, blue: 0.2, alpha: 1)
        func attrs(_ size: CGFloat, _ w: UIFont.Weight = .regular, _ c: UIColor = .black) -> [NSAttributedString.Key: Any] {
            [.font: UIFont.systemFont(ofSize: size, weight: w), .foregroundColor: c]
        }
        let cols: [(String, CGFloat)] = [("№", 26), (L("Студент"), 231), (L("Н/б, ч"), 62), (L("Уваж., ч"), 62), (L("Опозд."), 56), ("%", 86)]
        return UIGraphicsPDFRenderer(bounds: page).pdfData { ctx in
            var y: CGFloat = 0
            func newPage() {
                ctx.beginPage()
                y = margin
            }
            func ensure(_ h: CGFloat) { if y + h > page.height - margin { newPage() } }
            func row(_ cells: [String], bold: Bool = false, color: UIColor = .black, fill: UIColor? = nil) {
                ensure(20)
                if let fill {
                    fill.setFill()
                    UIBezierPath(rect: CGRect(x: margin, y: y, width: page.width - margin * 2, height: 20)).fill()
                }
                var x = margin + 4
                for (i, c) in cells.enumerated() {
                    let w = cols[i].1
                    (c as NSString).draw(in: CGRect(x: x, y: y + 4, width: w - 6, height: 14),
                                         withAttributes: attrs(10, bold ? .semibold : .regular, i == 1 ? color : (bold ? .black : .darkGray)))
                    x += w
                }
                y += 20
            }

            newPage()
            (L("Рапортичка посещаемости") as NSString).draw(at: CGPoint(x: margin, y: y), withAttributes: attrs(20, .bold))
            y += 28
            let sub = [title, group.isEmpty ? nil : L("группа \(group)"), L("занятий с отметками: \(lessons)"), L("1 пара = \(hoursPerPair) часа")]
                .compactMap { $0 }.joined(separator: " · ")
            (sub as NSString).draw(at: CGPoint(x: margin, y: y), withAttributes: attrs(11, .regular, .darkGray))
            y += 26

            row(cols.map { $0.0 }, bold: true, fill: UIColor(white: 0.9, alpha: 1))
            for (i, r) in list.enumerated() {
                row(["\(i + 1)", r.student.name, "\(r.absentHours)", "\(r.excusedHours)", "\(r.total.late)",
                     r.total.percent.map { "\($0)%" } ?? "—"],
                    color: r.alarming ? red : .black,
                    fill: i % 2 == 1 ? UIColor(white: 0.97, alpha: 1) : nil)
            }
            let sumAbsent = list.reduce(0) { $0 + $1.absentHours }
            let sumExcused = list.reduce(0) { $0 + $1.excusedHours }
            let sumLate = list.reduce(0) { $0 + $1.total.late }
            row(["", L("Итого по группе"), "\(sumAbsent)", "\(sumExcused)", "\(sumLate)", ""], bold: true, fill: UIColor(white: 0.9, alpha: 1))

            let withAbsences = list.filter { r in r.bySubject.contains { $0.stats.absent > 0 } }
            if !withAbsences.isEmpty {
                y += 18
                ensure(24)
                (L("Пропуски по предметам") as NSString).draw(at: CGPoint(x: margin, y: y), withAttributes: attrs(13, .bold))
                y += 22
                for r in withAbsences {
                    let parts = r.bySubject.filter { $0.stats.absent > 0 }
                        .map { L("\($0.subject) — \($0.stats.absent * hoursPerPair) ч") }
                        .joined(separator: "; ")
                    let text = NSAttributedString(string: r.student.name + ": " + parts, attributes: attrs(10))
                    let rect = text.boundingRect(with: CGSize(width: page.width - margin * 2, height: 400),
                                                 options: [.usesLineFragmentOrigin], context: nil)
                    ensure(rect.height + 6)
                    text.draw(with: CGRect(x: margin, y: y, width: page.width - margin * 2, height: rect.height + 2),
                              options: [.usesLineFragmentOrigin], context: nil)
                    y += rect.height + 6
                }
            }

            ensure(40)
            y += 24
            (L("Староста / зам. старосты ______________________") as NSString)
                .draw(at: CGPoint(x: margin, y: y), withAttributes: attrs(11, .regular, .darkGray))
        }
    }
}

// MARK: - Обмен отметками между старостой и замом

/// Отметки в файле: студенты по именам, чтобы сошлись списки с разных телефонов
struct MarksPackage: Codable {
    var app = AttendanceExchange.appID
    var version = 1
    var sender: String
    var created: Date
    var students: [String]
    var lessons: [AttendanceLesson]
    var marks: [String: [String: Mark]]
    var edited: [String: Date]
    var excuses: [PackedExcuse]

    struct PackedExcuse: Codable {
        var name: String
        var from: Date
        var to: Date
        var reason: String
    }
}

struct MarksPackageFile: Identifiable {
    let id = UUID()
    let package: MarksPackage
}

extension UTType {
    static let arktikaMarks = UTType(exportedAs: "ru.student.safuhub.marks", conformingTo: .json)
}

enum AttendanceExchange {
    static let appID = "arktika.marks"
    static let ext = "arkmarks"

    static func file(from store: AttendanceStore) -> URL? {
        let sender = UserDefaults.standard.string(forKey: "user.name") ?? ""
        let p = store.package(sender: sender)
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        guard let data = try? enc.encode(p) else { return nil }
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("marks", isDirectory: true)
        try? FileManager.default.removeItem(at: dir)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let who = sender.split(separator: " ").first.map { " " + String($0) } ?? ""
        let name = (L("Отметки") + who + " " + Fmt.formatter("d.MM").string(from: Date()))
            .replacingOccurrences(of: "/", with: "-")
        let url = dir.appendingPathComponent(name).appendingPathExtension(ext)
        do { try data.write(to: url) } catch { return nil }
        return url
    }

    static func read(_ url: URL) -> MarksPackage? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url) else { return nil }
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        guard let p = try? dec.decode(MarksPackage.self, from: data), p.app == appID else { return nil }
        return p
    }
}

extension AttendanceStore {
    /// Одинаковые имена с разных телефонов: без регистра, «ё» как «е», лишние пробелы не важны
    static func norm(_ s: String) -> String {
        s.lowercased().replacingOccurrences(of: "ё", with: "е")
            .split(whereSeparator: \.isWhitespace).joined(separator: " ")
    }

    func package(sender: String) -> MarksPackage {
        let names = Dictionary(students.map { ($0.id.uuidString, $0.name) }, uniquingKeysWith: { a, _ in a })
        var out: [String: [String: Mark]] = [:]
        for (k, m) in marks where !m.isEmpty {
            var byName: [String: Mark] = [:]
            for (id, v) in m { if let n = names[id] { byName[n] = v } }
            out[k] = byName
        }
        let byID = Dictionary(students.map { ($0.id, $0.name) }, uniquingKeysWith: { a, _ in a })
        return MarksPackage(sender: sender, created: Date(),
                            students: sortedStudents.map(\.name),
                            lessons: out.keys.compactMap { lessons[$0] },
                            marks: out,
                            edited: edited.filter { out[$0.key] != nil },
                            excuses: excuses.compactMap { e in
                                byID[e.studentID].map { MarksPackage.PackedExcuse(name: $0, from: e.from, to: e.to, reason: e.reason) }
                            })
    }

    struct MergeResult {
        var newStudents = 0
        var newMarks = 0
        var updatedMarks = 0
        var lessons = 0
        var excuses = 0
        var isEmpty: Bool { newStudents + newMarks + updatedMarks + excuses == 0 }
    }

    /// Объединяет отметки из файла: новое добавляется, а где отметили по-разному — побеждает более свежая правка.
    /// apply: false — только посчитать, что изменится
    @discardableResult
    func merge(_ p: MarksPackage, apply: Bool) -> MergeResult {
        var r = MergeResult()
        var studs = students
        var index = Dictionary(studs.map { (Self.norm($0.name), $0.id) }, uniquingKeysWith: { a, _ in a })
        for n in p.students {
            let name = n.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !name.isEmpty, index[Self.norm(name)] == nil else { continue }
            let s = Student(name: name)
            studs.append(s)
            index[Self.norm(name)] = s.id
            r.newStudents += 1
        }
        var ls = lessons, ms = marks, ed = edited
        let theirLessons = Dictionary(p.lessons.map { ($0.key, $0) }, uniquingKeysWith: { a, _ in a })
        for (k, theirs) in p.marks {
            var mine = ms[k] ?? [:]
            let wasEmpty = mine.isEmpty
            let newer = (p.edited[k] ?? .distantPast) > (ed[k] ?? .distantPast)
            var touched = false
            for (name, m) in theirs {
                guard let id = index[Self.norm(name)]?.uuidString else { continue }
                if let old = mine[id] {
                    if old != m && newer { mine[id] = m; r.updatedMarks += 1; touched = true }
                } else {
                    mine[id] = m
                    r.newMarks += 1
                    touched = true
                }
            }
            guard touched else { continue }
            if wasEmpty { r.lessons += 1 }
            ms[k] = mine
            if ls[k] == nil { ls[k] = theirLessons[k] }
            if newer { ed[k] = p.edited[k] }
        }
        var ex = excuses
        let cal = Calendar.current
        for e in p.excuses {
            guard let id = index[Self.norm(e.name)] else { continue }
            let dup = ex.contains {
                $0.studentID == id && cal.isDate($0.from, inSameDayAs: e.from) && cal.isDate($0.to, inSameDayAs: e.to)
            }
            guard !dup else { continue }
            ex.append(Excuse(studentID: id, from: e.from, to: e.to, reason: e.reason))
            r.excuses += 1
        }
        if apply && !r.isEmpty {
            students = studs
            lessons = ls
            marks = ms
            edited = ed
            excuses = ex
        }
        return r
    }
}

struct AttendanceExchangeView: View {
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var fileURL: URL?
    @State private var importing = false
    @State private var incoming: MarksPackageFile?
    @State private var failed = false

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Image(systemName: "arrow.left.arrow.right.circle.fill")
                        .font(.system(size: 34))
                        .foregroundStyle(brandGradient)
                    Text(L("Староста и зам отмечают каждый на своём телефоне"))
                        .font(.headline)
                    Text(L("Скиньте друг другу файл с отметками в Telegram или по AirDrop. Арктика добавит новые отметки и справки, а если одну пару отметили по-разному — оставит более свежую правку."))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }

            Section(L("Отправить свои")) {
                if attendance.students.isEmpty {
                    Text(L("Пока нечего отправлять — добавь группу")).foregroundStyle(.secondary)
                } else if let u = fileURL {
                    ShareLink(item: u) {
                        Label(L("Отправить файл с отметками"), systemImage: "paperplane.fill")
                    }
                } else {
                    ProgressView()
                }
            }

            Section {
                Button { importing = true } label: {
                    Label(L("Открыть файл от старосты или зама"), systemImage: "tray.and.arrow.down.fill")
                }
                if failed {
                    Text(L("Это не файл с отметками Арктики")).font(.caption).foregroundStyle(Mark.absent.color)
                }
            } header: {
                Text(L("Получить"))
            } footer: {
                Text(L("Файл из Telegram можно открыть сразу: нажми на него, затем «Поделиться» › Арктика."))
            }
        }
        .navigationTitle(L("Обмен отметками"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) { Button(L("Готово")) { dismiss() } }
        }
        .onAppear {
            if fileURL == nil, !attendance.students.isEmpty { fileURL = AttendanceExchange.file(from: attendance) }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.arktikaMarks, .json]) { result in
            guard case .success(let url) = result else { return }
            if let p = AttendanceExchange.read(url) {
                failed = false
                incoming = MarksPackageFile(package: p)
            } else {
                failed = true
            }
        }
        .sheet(item: $incoming, onDismiss: { fileURL = AttendanceExchange.file(from: attendance) }) { f in
            NavigationStack { AttendanceImportView(file: f) }.environmentObject(attendance)
        }
    }
}

struct AttendanceImportView: View {
    let file: MarksPackageFile
    @EnvironmentObject private var attendance: AttendanceStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        let p = file.package
        let preview = attendance.merge(p, apply: false)
        List {
            Section {
                Label(p.sender.isEmpty ? L("Отметки без имени") : p.sender, systemImage: "person.crop.circle.fill")
                    .font(.headline)
                Text(L("Файл от \(Fmt.formatter("d MMMM, H:mm").string(from: p.created)) · занятий: \(p.marks.count) · студентов: \(p.students.count)"))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Section(L("Что изменится")) {
                line(L("Новые студенты"), preview.newStudents, "person.badge.plus")
                line(L("Новые отметки"), preview.newMarks, "plus.circle")
                line(L("Обновятся (у них свежее)"), preview.updatedMarks, "arrow.triangle.2.circlepath")
                line(L("Справки"), preview.excuses, "cross.case")
            }
            Section {
                Button {
                    attendance.merge(p, apply: true)
                    Haptics.success()
                    dismiss()
                } label: {
                    Label(preview.isEmpty ? L("Всё уже совпадает") : L("Объединить отметки"), systemImage: "checkmark.circle.fill")
                        .font(.headline)
                }
                .disabled(preview.isEmpty)
            }
        }
        .navigationTitle(L("Отметки из файла"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button(L("Отмена")) { dismiss() } }
        }
    }

    private func line(_ t: String, _ n: Int, _ icon: String) -> some View {
        HStack {
            Label(t, systemImage: icon)
            Spacer()
            Text("\(n)")
                .font(.system(.headline, design: .rounded))
                .foregroundStyle(n > 0 ? Color.primary : Color.secondary)
        }
    }
}
