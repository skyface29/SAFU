import SwiftUI
import UIKit
import Vision
import PhotosUI

// MARK: - Матрицы по фото
// Сфоткал матрицу из задачника или с доски → числа распознаются прямо на телефоне (Vision, без интернета)
// → проверяешь, правишь → определитель, обратная, ранг и т. д. считаются сразу,
// а «Решение в Wolfram|Alpha» открывает сайт с этой же матрицей (там же собственные числа и шаги решения).

struct Matrix: Equatable {
    var rows: Int
    var cols: Int
    var a: [[Double]]

    init(rows: Int, cols: Int, fill: Double = 0) {
        self.rows = rows
        self.cols = cols
        a = Array(repeating: Array(repeating: fill, count: cols), count: rows)
    }

    init(_ a: [[Double]]) {
        self.a = a
        rows = a.count
        cols = a.first?.count ?? 0
    }

    var isSquare: Bool { rows == cols }

    var transposed: Matrix {
        var m = Matrix(rows: cols, cols: rows)
        for i in 0..<rows { for j in 0..<cols { m.a[j][i] = a[i][j] } }
        return m
    }

    static func * (l: Matrix, r: Matrix) -> Matrix? {
        guard l.cols == r.rows else { return nil }
        var m = Matrix(rows: l.rows, cols: r.cols)
        for i in 0..<l.rows { for j in 0..<r.cols {
            var s = 0.0
            for k in 0..<l.cols { s += l.a[i][k] * r.a[k][j] }
            m.a[i][j] = s
        } }
        return m
    }

    /// Ступенчатый вид (метод Гаусса — Жордана): матрица, ранг и определитель (для квадратной)
    func reduced() -> (m: Matrix, rank: Int, det: Double) {
        var m = self
        var det = 1.0
        var r = 0
        let eps = 1e-10
        for c in 0..<cols where r < rows {
            // строка с самым большим по модулю элементом — меньше ошибок округления
            var p = r
            for i in r..<rows where abs(m.a[i][c]) > abs(m.a[p][c]) { p = i }
            guard abs(m.a[p][c]) > eps else { det = 0; continue }
            if p != r { m.a.swapAt(p, r); det = -det }
            let pv = m.a[r][c]
            det *= pv
            for j in 0..<cols { m.a[r][j] /= pv }
            for i in 0..<rows where i != r {
                let f = m.a[i][c]
                if f != 0 { for j in 0..<cols { m.a[i][j] -= f * m.a[r][j] } }
            }
            r += 1
        }
        if r < min(rows, cols) || !isSquare { det = isSquare ? 0 : .nan }
        for i in 0..<rows { for j in 0..<cols where abs(m.a[i][j]) < eps { m.a[i][j] = 0 } }
        return (m, r, det)
    }

    var inverse: Matrix? {
        guard isSquare else { return nil }
        var aug = Matrix(rows: rows, cols: cols * 2)
        for i in 0..<rows {
            for j in 0..<cols { aug.a[i][j] = a[i][j] }
            aug.a[i][cols + i] = 1
        }
        let r = aug.reduced()
        for i in 0..<rows where abs(r.m.a[i][i] - 1) > 1e-8 { return nil }
        return Matrix(r.m.a.map { Array($0[cols...]) })
    }

    /// Запись для Wolfram|Alpha: {{1,2},{3,4}}
    var wolfram: String {
        "{" + a.map { "{" + $0.map { MatrixFmt.nice($0) }.joined(separator: ",") + "}" }.joined(separator: ",") + "}"
    }

    var text: String {
        a.map { $0.map { MatrixFmt.nice($0) }.joined(separator: "\t") }.joined(separator: "\n")
    }
}

enum MatrixFmt {
    /// Красиво: целые — целыми, «почти дроби» — дробью (0.3333… → 1/3)
    static func nice(_ x: Double) -> String {
        guard x.isFinite else { return "—" }
        if abs(x - x.rounded()) < 1e-9 { return String(Int(x.rounded())) }
        for d in 2...1000 {
            let n = x * Double(d)
            if abs(n - n.rounded()) < 1e-7 * Double(d) { return "\(Int(n.rounded()))/\(d)" }
        }
        return plain(x)
    }

    static func plain(_ x: Double) -> String {
        guard x.isFinite else { return "0" }
        if abs(x - x.rounded()) < 1e-9 { return String(Int(x.rounded())) }
        var s = String(format: "%.6f", x)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }

    /// Разбор ввода: «-3», «2,5», «1/3», «−7»
    static func parse(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: "−", with: "-")
            .replacingOccurrences(of: "–", with: "-")
            .replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: ",", with: ".")
        if t.isEmpty { return 0 }
        if let i = t.firstIndex(of: "/") {
            guard let n = Double(t[..<i]), let d = Double(t[t.index(after: i)...]), d != 0 else { return nil }
            return n / d
        }
        return Double(t)
    }
}

// MARK: - Распознавание матрицы на фото

enum MatrixOCR {
    private struct Token { let value: Double; let x: Double; let y: Double; let h: Double }

    static func recognize(_ image: UIImage) -> Matrix? {
        guard let cg = image.cgImage else { return nil }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["en-US"]
        req.usesLanguageCorrection = false   // иначе «1O» превращается в слово
        let handler = VNImageRequestHandler(cgImage: cg, orientation: orientation(image), options: [:])
        try? handler.perform([req])

        let pattern = try! NSRegularExpression(pattern: #"[-−–—]?\s?\d+(?:[.,]\d+)?(?:/\d+)?"#)
        var tokens: [Token] = []
        for obs in req.results ?? [] {
            guard let cand = obs.topCandidates(1).first else { continue }
            let s = cand.string
            let ns = s as NSString
            for m in pattern.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
                let raw = ns.substring(with: m.range).replacingOccurrences(of: " ", with: "")
                guard let v = MatrixFmt.parse(raw), let r = Range(m.range, in: s) else { continue }
                let box = (try? cand.boundingBox(for: r))?.boundingBox ?? obs.boundingBox
                tokens.append(Token(value: v, x: box.midX, y: box.midY, h: max(box.height, 0.005)))
            }
        }
        guard !tokens.isEmpty else { return nil }

        // строки: близкие по высоте числа (в Vision y растёт снизу вверх)
        let hs = tokens.map(\.h).sorted()
        let gap = hs[hs.count / 2] * 0.6
        var rows: [[Token]] = []
        for t in tokens.sorted(by: { $0.y > $1.y }) {
            if let last = rows.last, let y0 = last.first?.y, abs(y0 - t.y) < gap {
                rows[rows.count - 1].append(t)
            } else {
                rows.append([t])
            }
        }
        rows = rows.map { $0.sorted { $0.x < $1.x } }

        // сколько столбцов: самое частое число чисел в строке
        let counts = Dictionary(grouping: rows.map(\.count), by: { $0 }).mapValues(\.count)
        guard let n = counts.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key else { return nil }
        // случайные надписи (номер задачи, «A =») отбрасываем
        rows = rows.filter { $0.count * 2 >= n && $0.count <= n + 1 }
        guard !rows.isEmpty, n > 0 else { return nil }

        // центры столбцов — по «полным» строкам; числа неполных строк ставим в ближайший столбец
        let full = rows.filter { $0.count == n }
        let centers = (0..<n).map { j in full.map { $0[j].x }.reduce(0, +) / Double(max(full.count, 1)) }
        var result: [[Double]] = []
        for row in rows.prefix(10) {
            if row.count == n { result.append(row.map(\.value)); continue }
            var line = Array(repeating: 0.0, count: n)
            for t in row.prefix(n) {
                let j = centers.indices.min { abs(centers[$0] - t.x) < abs(centers[$1] - t.x) } ?? 0
                line[j] = t.value
            }
            result.append(line)
        }
        let m = Matrix(result.map { Array($0.prefix(10)) })
        return m.rows > 0 && m.cols > 0 ? m : nil
    }

    private static func orientation(_ img: UIImage) -> CGImagePropertyOrientation {
        switch img.imageOrientation {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}

// MARK: - Экран

struct MatrixView: View {
    private enum Op: String, CaseIterable, Identifiable {
        case det, inverse, rank, rref, transpose, square
        var id: String { rawValue }
        var title: String {
            switch self {
            case .det: return "Определитель"
            case .inverse: return "Обратная"
            case .rank: return "Ранг"
            case .rref: return "Ступенчатый вид"
            case .transpose: return "Транспонировать"
            case .square: return "A²"
            }
        }
        var wolfram: String {
            switch self {
            case .det: return "determinant"
            case .inverse: return "inverse"
            case .rank: return "rank"
            case .rref: return "row reduce"
            case .transpose: return "transpose"
            case .square: return "square"
            }
        }
    }

    private enum Route: Identifiable {
        case camera, web(URL)
        var id: String {
            switch self {
            case .camera: return "camera"
            case .web(let u): return u.absoluteString
            }
        }
    }

    @AppStorage("matrix.last") private var saved = ""
    @State private var rows = 3
    @State private var cols = 3
    @State private var cells: [[String]] = Array(repeating: Array(repeating: "", count: 3), count: 3)
    @State private var op: Op = .det
    @State private var route: Route?
    @State private var photo: PhotosPickerItem?
    @State private var busy = false
    @State private var note: String?
    @FocusState private var focus: Bool

    private var matrix: Matrix? {
        var out: [[Double]] = []
        for i in 0..<rows {
            var line: [Double] = []
            for j in 0..<cols {
                guard let v = MatrixFmt.parse(cell(i, j)) else { return nil }
                line.append(v)
            }
            out.append(line)
        }
        return Matrix(out)
    }

    var body: some View {
        Form {
            Section {
                HStack(spacing: 10) {
                    Button { route = .camera } label: {
                        Label("Сфоткать", systemImage: "camera.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    PhotosPicker(selection: $photo, matching: .images) {
                        Label("Из фото", systemImage: "photo").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .disabled(busy)
                if busy {
                    HStack { ProgressView(); Text("Распознаю числа…").foregroundStyle(.secondary) }
                }
                if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
            } footer: {
                Text("Снимай одну матрицу крупно и ровно. Числа распознаются на телефоне, фото никуда не отправляется. Проверь ячейки — камера может ошибиться.")
            }

            Section("Матрица") {
                // размер сетки меняем сразу вместе с ячейками — иначе экран успевал обратиться к несуществующей строке
                Stepper("Строк: \(rows)", value: Binding(get: { rows }, set: { rows = $0; resize() }), in: 1...8)
                Stepper("Столбцов: \(cols)", value: Binding(get: { cols }, set: { cols = $0; resize() }), in: 1...8)
                grid
                    .listRowInsets(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
                HStack {
                    Button("Очистить", role: .destructive) { resize(clear: true) }
                    Spacer()
                    Button { UIPasteboard.general.string = matrix?.text; Haptics.success() } label: {
                        Label("Копировать", systemImage: "doc.on.doc")
                    }
                    .disabled(matrix == nil)
                }
                .buttonStyle(.borderless)
                .font(.subheadline)
            }

            Section("Посчитать") {
                Picker("Действие", selection: $op) {
                    ForEach(Op.allCases) { Text($0.title).tag($0) }
                }
                result
            }

            Section {
                Button { openWolfram(op.wolfram) } label: {
                    Label("\(op.title) — решение в Wolfram|Alpha", systemImage: "function")
                }
                Button { openWolfram("eigenvalues") } label: {
                    Label("Собственные числа и векторы", systemImage: "sparkle")
                }
                Button { openWolfram("") } label: {
                    Label("Всё о матрице", systemImage: "square.grid.3x3")
                }
            } header: {
                Text("Wolfram|Alpha")
            } footer: {
                Text("Откроется сайт wolframalpha.com с этой матрицей. Подробные шаги решения там платные, ответ — бесплатно.")
            }
            .disabled(matrix == nil)
        }
        .navigationTitle("Матрицы")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("Готово") { focus = false }
            }
        }
        .onChange(of: cells) { _ in if let m = matrix { saved = m.wolfram } }
        .onChange(of: photo) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                    await MainActor.run { recognize(img) }
                }
                await MainActor.run { photo = nil }
            }
        }
        .onAppear(perform: restore)
        .sheet(item: $route) { r in
            switch r {
            case .camera:
                CameraPicker { img in
                    route = nil
                    if let img { recognize(img) }
                }
                .ignoresSafeArea()
            case .web(let u):
                SafariView(url: u).ignoresSafeArea()
            }
        }
    }

    private var grid: some View {
        let w: CGFloat = cols > 5 ? 44 : 56
        return ScrollView(.horizontal, showsIndicators: false) {
            VStack(spacing: 6) {
                ForEach(0..<rows, id: \.self) { i in
                    HStack(spacing: 6) {
                        ForEach(0..<cols, id: \.self) { j in
                            TextField("0", text: cellBinding(i, j))
                                .keyboardType(.numbersAndPunctuation)
                                .multilineTextAlignment(.center)
                                .font(.system(.body, design: .monospaced))
                                .frame(width: w, height: 40)
                                .background(
                                    (MatrixFmt.parse(cell(i, j)) == nil ? Color.red.opacity(0.18) : Color.primary.opacity(0.06)),
                                    in: RoundedRectangle(cornerRadius: 9, style: .continuous)
                                )
                                .focused($focus)
                        }
                    }
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
        }
    }

    private func cell(_ i: Int, _ j: Int) -> String {
        cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : ""
    }

    private func cellBinding(_ i: Int, _ j: Int) -> Binding<String> {
        Binding(get: { cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : "" },
                set: { v in if cells.indices.contains(i) && cells[i].indices.contains(j) { cells[i][j] = v } })
    }

    @ViewBuilder private var result: some View {
        if let m = matrix {
            switch op {
            case .det:
                if m.isSquare { value("det A = \(MatrixFmt.nice(m.reduced().det))") }
                else { hint("Определитель есть только у квадратной матрицы") }
            case .rank:
                value("rang A = \(m.reduced().rank)")
            case .inverse:
                if !m.isSquare { hint("Обратная есть только у квадратной матрицы") }
                else if let inv = m.inverse { matrixResult(inv) }
                else { hint("Определитель равен 0 — обратной матрицы нет") }
            case .rref: matrixResult(m.reduced().m)
            case .transpose: matrixResult(m.transposed)
            case .square:
                if let sq = m * m { matrixResult(sq) } else { hint("A² есть только у квадратной матрицы") }
            }
        } else {
            hint("В красных ячейках не число. Можно писать 3, -2, 1,5 или 1/3")
        }
    }

    private func value(_ s: String) -> some View {
        Text(s)
            .font(.system(.title3, design: .monospaced).weight(.bold))
            .textSelection(.enabled)
    }

    private func hint(_ s: String) -> some View {
        Text(s).font(.subheadline).foregroundStyle(.secondary)
    }

    private func matrixResult(_ m: Matrix) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ScrollView(.horizontal, showsIndicators: false) {
                Grid(horizontalSpacing: 14, verticalSpacing: 6) {
                    ForEach(0..<m.rows, id: \.self) { i in
                        GridRow {
                            ForEach(0..<m.cols, id: \.self) { j in
                                Text(MatrixFmt.nice(m.a[i][j]))
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .gridColumnAlignment(.trailing)
                            }
                        }
                    }
                }
                .padding(.vertical, 4)
            }
            HStack {
                Button { UIPasteboard.general.string = m.text; Haptics.success() } label: {
                    Label("Копировать", systemImage: "doc.on.doc")
                }
                Spacer()
                Button { load(m) } label: {
                    Label("В матрицу", systemImage: "arrow.up.doc")
                }
            }
            .buttonStyle(.borderless)
            .font(.caption.weight(.semibold))
        }
    }

    // MARK: - Действия

    private func recognize(_ img: UIImage) {
        busy = true
        note = nil
        Task.detached(priority: .userInitiated) {
            let m = MatrixOCR.recognize(img)
            await MainActor.run {
                busy = false
                if let m {
                    load(m)
                    Haptics.success()
                    note = "Распознал \(m.rows)×\(m.cols). Сверь с фото и поправь, если что-то не так."
                } else {
                    note = "Не нашёл чисел на фото. Сфоткай ближе и ровнее или введи вручную."
                }
            }
        }
    }

    private func load(_ m: Matrix) {
        let r = min(m.rows, 8), c = min(m.cols, 8)
        rows = r
        cols = c
        cells = (0..<r).map { i in (0..<c).map { j in MatrixFmt.nice(m.a[i][j]) } }
    }

    private func resize(clear: Bool = false) {
        cells = (0..<rows).map { i in
            (0..<cols).map { j in
                !clear && cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : ""
            }
        }
    }

    private func restore() {
        // последняя матрица: {{1,2},{3,4}}
        guard !saved.isEmpty else { return }
        let body = saved.dropFirst(2).dropLast(2)
        let parsed = body.components(separatedBy: "},{").map { $0.split(separator: ",").compactMap { MatrixFmt.parse(String($0)) } }
        guard let c = parsed.first?.count, c > 0, parsed.allSatisfy({ $0.count == c }) else { return }
        load(Matrix(parsed))
    }

    private func openWolfram(_ command: String) {
        guard let m = matrix else { return }
        let q = command.isEmpty ? m.wolfram : "\(command) \(m.wolfram)"
        var comp = URLComponents(string: "https://www.wolframalpha.com/input")!
        comp.queryItems = [URLQueryItem(name: "i", value: q)]
        // «+», «{» и «,» в запросе нужно экранировать явно
        comp.percentEncodedQuery = comp.percentEncodedQuery?
            .replacingOccurrences(of: "+", with: "%2B")
        if let u = comp.url { route = .web(u) }
    }
}
