import SwiftUI
import UIKit
import Vision
import PhotosUI
import ImageIO

// MARK: - Матрицы по фото
// Сфоткал матрицу из задачника или с доски → обвёл рамкой (она сама встаёт на матрицу) → числа
// распознаются прямо на телефоне (Vision, без интернета) → проверяешь, правишь → определитель, обратная,
// ранг, системы (Гаусс, Крамер, матричный метод), собственные числа и действия с двумя матрицами
// считаются сразу и расписываются по шагам, как в тетради.
// Всё считается в точных дробях: 1/3 остаётся 1/3, а не 0,3333…

// MARK: - Точное число

/// Число в матрице: точная дробь p/q, пока числитель и знаменатель помещаются в Int,
/// иначе — обычное десятичное приближение (так бывает только на очень больших матрицах)
struct MNum: Hashable {
    /// Числитель и знаменатель: знаменатель > 0, дробь несократимая. Знаменатель 0 — число неточное
    let n: Int
    let d: Int
    /// Значение неточного числа
    let approx: Double

    static let zero = MNum(0)
    static let one = MNum(1)

    init(_ i: Int) {
        if i == Int.min {
            n = 0; d = 0; approx = Double(i)
        } else {
            n = i; d = 1; approx = 0
        }
    }

    private init(raw n: Int, _ d: Int) {
        self.n = n
        self.d = d
        approx = 0
    }

    /// Неточное число; целое значение всё равно становится точным
    init(approx x: Double) {
        if x.isFinite, abs(x) < 9e15, x == x.rounded() {
            n = Int(x); d = 1; approx = 0
        } else {
            n = 0; d = 0; approx = x
        }
    }

    var isExact: Bool { d != 0 }
    var isInteger: Bool { d == 1 }
    var value: Double { d != 0 ? Double(n) / Double(d) : approx }
    var isZero: Bool { d != 0 ? n == 0 : abs(approx) < 1e-9 }
    var isNegative: Bool { d != 0 ? n < 0 : (approx < 0 && !isZero) }
    var isOne: Bool { d == 1 && n == 1 }
    /// ±1 — с таким ведущим элементом удобнее всего считать руками
    var isUnit: Bool { d == 1 && (n == 1 || n == -1) }
    var absValue: MNum { isNegative ? -self : self }

    static func gcd(_ a: Int, _ b: Int) -> Int {
        var x = a.magnitude, y = b.magnitude
        while y != 0 { (x, y) = (y, x % y) }
        return x == 0 ? 1 : Int(clamping: x)
    }

    /// Несократимая дробь p/q
    static func fraction(_ p: Int, _ q: Int) -> MNum {
        if q == 0 { return MNum(approx: .nan) }
        if p == 0 { return .zero }
        if p == Int.min || q == Int.min { return MNum(approx: Double(p) / Double(q)) }
        let g = gcd(p, q)
        var a = p / g, b = q / g
        if b < 0 { a = -a; b = -b }
        return MNum(raw: a, b)
    }

    static prefix func - (x: MNum) -> MNum {
        x.d == 0 ? MNum(approx: -x.approx) : MNum(raw: -x.n, x.d)
    }

    static func + (a: MNum, b: MNum) -> MNum {
        guard a.d != 0, b.d != 0 else { return MNum(approx: a.value + b.value) }
        if a.d == 1 && b.d == 1 {
            let (s, o) = a.n.addingReportingOverflow(b.n)
            return o ? MNum(approx: a.value + b.value) : MNum(s)
        }
        let g = gcd(a.d, b.d)
        let (l, o1) = a.d.multipliedReportingOverflow(by: b.d / g)
        let (x, o2) = a.n.multipliedReportingOverflow(by: b.d / g)
        let (y, o3) = b.n.multipliedReportingOverflow(by: a.d / g)
        let (s, o4) = x.addingReportingOverflow(y)
        if o1 || o2 || o3 || o4 { return MNum(approx: a.value + b.value) }
        return fraction(s, l)
    }

    static func - (a: MNum, b: MNum) -> MNum { a + (-b) }

    static func * (a: MNum, b: MNum) -> MNum {
        guard a.d != 0, b.d != 0 else { return MNum(approx: a.value * b.value) }
        if a.n == 0 || b.n == 0 { return .zero }
        let g1 = gcd(a.n, b.d), g2 = gcd(b.n, a.d)
        let (p, o1) = (a.n / g1).multipliedReportingOverflow(by: b.n / g2)
        let (q, o2) = (a.d / g2).multipliedReportingOverflow(by: b.d / g1)
        if o1 || o2 { return MNum(approx: a.value * b.value) }
        return fraction(p, q)
    }

    static func / (a: MNum, b: MNum) -> MNum {
        if b.isZero { return MNum(approx: .nan) }
        guard a.d != 0, b.d != 0 else { return MNum(approx: a.value / b.value) }
        return a * fraction(b.d, b.n)
    }

    /// «3», «−2», «1/3», «−7/2» — как в учебнике, с настоящим минусом
    var text: String {
        guard d != 0 else { return MatrixFmt.nice(approx) }
        let s = d == 1 ? "\(n.magnitude)" : "\(n.magnitude)/\(d)"
        return n < 0 ? "−" + s : s
    }

    /// Для копирования, Wolfram и таблиц: обычный минус и точка
    var plain: String {
        guard d != 0 else { return MatrixFmt.plain(approx) }
        return d == 1 ? "\(n)" : "\(n)/\(d)"
    }

    /// В скобках, если отрицательное: «(−2)»
    var paren: String { isNegative ? "(\(text))" : text }

    /// Множитель перед буквой или строкой: дробь — в скобках, «(1/2)·стр. 1»
    var coef: String { d > 1 ? "(\(text))" : text }

    /// Десятичная подсказка к дроби: « ≈ 0,3333»; у целых — пусто
    var hint: String { d > 1 ? " ≈ " + MatrixFmt.decimal(value) : "" }

    /// Разбор ввода: «-3», «2,5», «1/3», «−7», «+4», «½»; пустая ячейка — 0
    static func parse(_ s: String) -> MNum? {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        for (k, v) in MatrixFmt.unicodeFractions where t.contains(k) {
            t = t.replacingOccurrences(of: k, with: v)
        }
        t = t.replacingOccurrences(of: "−", with: "-")
            .replacingOccurrences(of: "–", with: "-")
            .replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: ",", with: ".")
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "\u{00A0}", with: "")
            .replacingOccurrences(of: "÷", with: "/")
        if t.isEmpty { return .zero }
        if let i = t.firstIndex(of: "/") {
            let top = String(t[..<i]), bottom = String(t[t.index(after: i)...])
            guard !top.isEmpty, !bottom.isEmpty, !bottom.contains("/"),
                  let p = decimal(top), let q = decimal(bottom), !q.isZero else { return nil }
            return p / q
        }
        return decimal(t)
    }

    /// «-12.375» → −99/8 точно; очень длинные числа и «1e5» — приближённо
    private static func decimal(_ raw: String) -> MNum? {
        var s = Substring(raw)
        var neg = false
        while let c = s.first, c == "+" || c == "-" {
            if c == "-" { neg.toggle() }
            s = s.dropFirst()
        }
        guard !s.isEmpty else { return nil }
        if s.contains(where: { $0 == "e" || $0 == "E" }) {
            guard let x = Double(String(s)), x.isFinite else { return nil }
            return MNum(approx: neg ? -x : x)
        }
        let parts = s.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count <= 2 else { return nil }
        let whole = String(parts[0]), frac = parts.count == 2 ? String(parts[1]) : ""
        let digits = whole + frac
        guard !digits.isEmpty, digits.allSatisfy({ $0 >= "0" && $0 <= "9" }) else { return nil }
        guard digits.count <= 18, frac.count <= 15 else {
            guard let x = Double(String(s)) else { return nil }
            return MNum(approx: neg ? -x : x)
        }
        var num = 0
        for ch in digits { num = num * 10 + (ch.wholeNumberValue ?? 0) }
        var den = 1
        for _ in 0..<frac.count { den *= 10 }
        return fraction(neg ? -num : num, den)
    }
}

enum MatrixFmt {
    static let unicodeFractions: [String: String] = [
        "½": "1/2", "⅓": "1/3", "⅔": "2/3", "¼": "1/4", "¾": "3/4", "⅕": "1/5",
        "⅖": "2/5", "⅗": "3/5", "⅘": "4/5", "⅙": "1/6", "⅚": "5/6", "⅛": "1/8",
    ]

    /// Неточное число красиво: целые — целыми, «почти дроби» — дробью (0.3333… → 1/3)
    static func nice(_ x: Double) -> String {
        guard x.isFinite else { return "—" }
        guard abs(x) < 1e12 else { return minus(String(format: "%.6g", x)) }
        if abs(x - x.rounded()) < 1e-9 { return minus(String(Int(x.rounded()))) }
        for d in 2...1000 {
            let n = x * Double(d)
            if abs(n - n.rounded()) < 1e-7 * Double(d) { return minus("\(Int(n.rounded()))/\(d)") }
        }
        return minus(decimalText(x, digits: 6))
    }

    /// Для копирования и Wolfram: обычная точка и минус
    static func plain(_ x: Double) -> String {
        guard x.isFinite else { return "0" }
        if abs(x) < 1e15, abs(x - x.rounded()) < 1e-9 { return String(Int(x.rounded())) }
        var s = String(format: "%.8f", x)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }

    /// Десятичная запись для подсказок: «2,3333»
    static func decimal(_ x: Double) -> String {
        guard x.isFinite else { return "—" }
        return minus(decimalText(x, digits: 4))
    }

    private static func decimalText(_ x: Double, digits: Int) -> String {
        var s = String(format: "%.\(digits)f", x)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        if s == "-0" { s = "0" }
        return s.replacingOccurrences(of: ".", with: ",")
    }

    /// Настоящий знак минус «−» вместо дефиса — как в учебнике
    static func minus(_ s: String) -> String {
        s.hasPrefix("-") ? "−" + s.dropFirst() : s
    }

    /// x₁, x₂… — индексы мелкими цифрами
    static func sub(_ n: Int) -> String {
        let digits = ["₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"]
        return String(n).compactMap { $0.wholeNumberValue.map { digits[$0] } }.joined()
    }

    /// λ², λ³ — степени маленькими цифрами
    static func sup(_ n: Int) -> String {
        let digits = ["⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹"]
        return String(n).compactMap { $0.wholeNumberValue.map { digits[$0] } }.joined()
    }
}

// MARK: - Матрица

struct Matrix: Equatable {
    var rows: Int
    var cols: Int
    var a: [[MNum]]

    init(rows: Int, cols: Int, fill: MNum = .zero) {
        self.rows = rows
        self.cols = cols
        a = Array(repeating: Array(repeating: fill, count: cols), count: rows)
    }

    init(_ a: [[MNum]]) {
        self.a = a
        rows = a.count
        cols = a.first?.count ?? 0
    }

    static func identity(_ n: Int) -> Matrix {
        var m = Matrix(rows: n, cols: n)
        for i in 0..<n { m.a[i][i] = .one }
        return m
    }

    var isSquare: Bool { rows == cols }
    var isExact: Bool { a.allSatisfy { $0.allSatisfy(\.isExact) } }

    var transposed: Matrix {
        var m = Matrix(rows: cols, cols: rows)
        for i in 0..<rows { for j in 0..<cols { m.a[j][i] = a[i][j] } }
        return m
    }

    var trace: MNum {
        var s = MNum.zero
        for i in 0..<min(rows, cols) { s = s + a[i][i] }
        return s
    }

    /// Без строки i и столбца j — из неё считается минор Mᵢⱼ
    func minor(_ i: Int, _ j: Int) -> Matrix {
        var out: [[MNum]] = []
        for (r, row) in a.enumerated() where r != i {
            var line: [MNum] = []
            for (c, x) in row.enumerated() where c != j { line.append(x) }
            out.append(line)
        }
        return Matrix(out)
    }

    static func + (l: Matrix, r: Matrix) -> Matrix? {
        guard l.rows == r.rows, l.cols == r.cols else { return nil }
        var m = l
        for i in 0..<l.rows { for j in 0..<l.cols { m.a[i][j] = l.a[i][j] + r.a[i][j] } }
        return m
    }

    static func - (l: Matrix, r: Matrix) -> Matrix? {
        guard l.rows == r.rows, l.cols == r.cols else { return nil }
        var m = l
        for i in 0..<l.rows { for j in 0..<l.cols { m.a[i][j] = l.a[i][j] - r.a[i][j] } }
        return m
    }

    static func * (l: Matrix, r: Matrix) -> Matrix? {
        guard l.cols == r.rows else { return nil }
        var m = Matrix(rows: l.rows, cols: r.cols)
        for i in 0..<l.rows {
            for j in 0..<r.cols {
                var s = MNum.zero
                for k in 0..<l.cols { s = s + l.a[i][k] * r.a[k][j] }
                m.a[i][j] = s
            }
        }
        return m
    }

    func scaled(_ k: MNum) -> Matrix {
        var m = self
        for i in 0..<rows { for j in 0..<cols { m.a[i][j] = a[i][j] * k } }
        return m
    }

    /// Aⁿ быстрым возведением в степень; A⁰ = E
    func power(_ k: Int) -> Matrix? {
        guard isSquare, k >= 0 else { return nil }
        var result = Matrix.identity(rows)
        var base = self
        var e = k
        while e > 0 {
            if e & 1 == 1 { result = (result * base) ?? result }
            e >>= 1
            if e > 0 { base = (base * base) ?? base }
        }
        return result
    }

    /// Неточные «почти нули» после вычитаний — настоящие нули
    mutating func clean() {
        for i in 0..<rows {
            for j in 0..<cols where !a[i][j].isExact && abs(a[i][j].approx) < 1e-10 { a[i][j] = .zero }
        }
    }

    /// Ступенчатый вид (Гаусс — Жордан): матрица, ранг, столбцы с ведущими единицами и определитель (у квадратной)
    func reduced() -> (m: Matrix, rank: Int, pivots: [Int], det: MNum?) {
        var m = self
        var det = MNum.one
        var r = 0
        var pivots: [Int] = []
        for c in 0..<cols where r < rows {
            guard let p = MatrixSolver.pivotRow(m, col: c, from: r) else { continue }
            if p != r {
                m.a.swapAt(p, r)
                det = -det
            }
            let pv = m.a[r][c]
            det = det * pv
            for j in 0..<cols { m.a[r][j] = m.a[r][j] / pv }
            m.a[r][c] = .one
            for i in 0..<rows where i != r {
                let f = m.a[i][c]
                guard !f.isZero else { continue }
                for j in 0..<cols { m.a[i][j] = m.a[i][j] - f * m.a[r][j] }
                m.a[i][c] = .zero
            }
            pivots.append(c)
            r += 1
        }
        m.clean()
        var detOut: MNum? = nil
        if isSquare { detOut = r == rows ? det : MNum.zero }
        return (m, r, pivots, detOut)
    }

    var determinant: MNum? { isSquare ? reduced().det : nil }

    var inverse: Matrix? {
        guard isSquare, rows > 0 else { return nil }
        var aug = Matrix(rows: rows, cols: cols * 2)
        for i in 0..<rows {
            for j in 0..<cols { aug.a[i][j] = a[i][j] }
            aug.a[i][cols + i] = .one
        }
        let r = aug.reduced()
        guard Array(r.pivots.prefix(rows)) == Array(0..<rows) else { return nil }
        return Matrix(r.m.a.map { Array($0[cols...]) })
    }

    /// Общий знаменатель за скобку: A = 1/k · B с целой B — так обратную пишут в ответах
    var factored: (k: Int, m: Matrix)? {
        guard isExact else { return nil }
        var l = 1
        for row in a {
            for x in row where x.d > 1 {
                let g = MNum.gcd(l, x.d)
                let (v, o) = (l / g).multipliedReportingOverflow(by: x.d)
                if o { return nil }
                l = v
            }
        }
        guard l > 1 else { return nil }
        return (l, scaled(MNum(l)))
    }

    /// Запись для Wolfram|Alpha: {{1,2},{3,4}}
    var wolfram: String {
        "{" + a.map { "{" + $0.map(\.plain).joined(separator: ",") + "}" }.joined(separator: ",") + "}"
    }

    /// Для копирования в таблицы и заметки: числа через табуляцию, обычный минус
    var text: String {
        a.map { $0.map(\.plain).joined(separator: "\t") }.joined(separator: "\n")
    }

    /// Для чата: как на экране, с настоящим минусом
    var pretty: String {
        a.map { $0.map(\.text).joined(separator: "\t") }.joined(separator: "\n")
    }

    private static let bracketRow = try? NSRegularExpression(pattern: #"[\{\[]([^\{\}\[\]]*)[\}\]]"#)

    /// Матрица из текста: строки — с новой строки, числа — через пробел, табуляцию или «;».
    /// Понимает и записи {{1,2},{3,4}} (Wolfram), [[1, 2], [3, 4]] (Python) и [1 2; 3 4] (MATLAB)
    static func parse(text raw: String) -> Matrix? {
        let t = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return nil }
        var lines: [[MNum]] = []
        let ns = t as NSString
        let groups = bracketRow?.matches(in: t, range: NSRange(location: 0, length: ns.length)) ?? []
        if (t.hasPrefix("{") || t.hasPrefix("[")) && !groups.isEmpty {
            let bodies = groups.map { ns.substring(with: $0.range(at: 1)) }
            if bodies.count == 1, bodies[0].contains(";") {
                lines = bodies[0].split(separator: ";").map { cells(String($0), commas: true) }
            } else {
                lines = bodies.map { cells($0, commas: true) }
            }
        } else {
            lines = t.split(whereSeparator: \.isNewline).map { line -> [MNum] in
                let s = String(line)
                // запятая — разделитель, если после неё пробел или запятых много, а точек нет
                let commaList = s.contains(", ") || (s.filter { $0 == "," }.count >= 2 && !s.contains("."))
                return cells(s, commas: commaList)
            }
        }
        lines = lines.filter { !$0.isEmpty }
        guard let c = lines.map(\.count).max(), c > 0 else { return nil }
        return Matrix(lines.map { $0 + Array(repeating: MNum.zero, count: c - $0.count) })
    }

    private static func cells(_ s: String, commas: Bool) -> [MNum] {
        s.split(whereSeparator: { $0 == " " || $0 == "\t" || $0 == ";" || (commas && $0 == ",") })
            .compactMap { MNum.parse(String($0)) }
    }
}

// MARK: - Решение по шагам

/// Один шаг решения: что сделали и что получилось
struct MatrixStep: Identifiable {
    let id = UUID()
    let title: String
    var lines: [String] = []
    var matrix: Matrix? = nil
    /// Столбец, перед которым черта (расширенная матрица)
    var bar: Int? = nil
}

/// Решение целиком: шаги и короткий ответ
struct MatrixSolution {
    var steps: [MatrixStep]
    var answer: [String]
}

/// Расписывает решение, как его пишут в тетради: перестановки строк, вычитание строк, деление на ведущий элемент
enum MatrixSolver {
    /// Ведущий элемент столбца: лучше ±1 (так проще считать руками), иначе первый ненулевой — меньше перестановок.
    /// Если числа неточные — самый большой по модулю: так меньше ошибок округления
    static func pivotRow(_ m: Matrix, col c: Int, from r: Int) -> Int? {
        guard r < m.rows, c < m.cols else { return nil }
        let list = (r..<m.rows).filter { !m.a[$0][c].isZero }
        guard let first = list.first else { return nil }
        if list.contains(where: { !m.a[$0][c].isExact }) {
            return list.max { abs(m.a[$0][c].value) < abs(m.a[$1][c].value) }
        }
        return list.first { m.a[$0][c].isUnit } ?? first
    }

    /// «стр. 2 − 3·стр. 1»: из строки dst вычитаем f раз строку src
    private static func rowOp(_ dst: Int, _ f: MNum, _ src: Int) -> String {
        let k = f.absValue
        let coef = k.isOne ? "" : k.coef + "·"
        return L("стр. \(dst + 1) \(f.isNegative ? "+" : "−") \(coef)стр. \(src + 1)")
    }

    private static func subtract(_ m: inout Matrix, row i: Int, _ f: MNum, pivotRow r: Int) {
        for j in 0..<m.cols { m.a[i][j] = m.a[i][j] - f * m.a[r][j] }
    }

    static func sub(_ n: Int) -> String { MatrixFmt.sub(n) }

    private static func idx(_ i: Int, _ j: Int) -> String { sub(i + 1) + sub(j + 1) }

    // MARK: определитель

    /// Определитель: формула для 2×2, Саррюс для 3×3, разложение по строке с нулями, потом метод Гаусса
    static func determinant(_ m0: Matrix) -> [MatrixStep] {
        let n = m0.rows
        var steps = [MatrixStep(title: L("Исходная матрица"), matrix: m0)]
        guard n > 0, m0.isSquare else { return steps }
        let a = m0.a
        if n == 1 {
            steps.append(MatrixStep(title: L("Матрица 1×1"), lines: ["det A = \(a[0][0].text)"]))
            return steps
        }
        if n == 2 {
            let x = a[0][0] * a[1][1], y = a[0][1] * a[1][0]
            let d = x - y
            steps.append(MatrixStep(title: L("Формула для 2×2"), lines: [
                "det A = a₁₁·a₂₂ − a₁₂·a₂₁",
                "= \(a[0][0].paren)·\(a[1][1].paren) − \(a[0][1].paren)·\(a[1][0].paren)",
                "= \(x.text) − \(y.paren)",
                "= \(d.text)" + d.hint]))
            return steps
        }
        if n == 3 {
            let plus = [a[0][0] * a[1][1] * a[2][2], a[0][1] * a[1][2] * a[2][0], a[0][2] * a[1][0] * a[2][1]]
            let minus = [a[0][2] * a[1][1] * a[2][0], a[0][0] * a[1][2] * a[2][1], a[0][1] * a[1][0] * a[2][2]]
            let d = plus.reduce(MNum.zero, +) - minus.reduce(MNum.zero, +)
            func p(_ x: MNum) -> String { x.paren }
            steps.append(MatrixStep(title: L("Правило треугольников (Саррюса)"), lines: [
                "det A = a₁₁a₂₂a₃₃ + a₁₂a₂₃a₃₁ + a₁₃a₂₁a₃₂ − a₁₃a₂₂a₃₁ − a₁₁a₂₃a₃₂ − a₁₂a₂₁a₃₃",
                "= \(p(a[0][0]))·\(p(a[1][1]))·\(p(a[2][2])) + \(p(a[0][1]))·\(p(a[1][2]))·\(p(a[2][0])) + \(p(a[0][2]))·\(p(a[1][0]))·\(p(a[2][1]))",
                "  − \(p(a[0][2]))·\(p(a[1][1]))·\(p(a[2][0])) − \(p(a[0][0]))·\(p(a[1][2]))·\(p(a[2][1])) − \(p(a[0][1]))·\(p(a[1][0]))·\(p(a[2][2]))",
                "= \(plus[0].text) + \(plus[1].paren) + \(plus[2].paren) − \(minus[0].paren) − \(minus[1].paren) − \(minus[2].paren)",
                "= \(d.text)" + d.hint]))
        }
        if n <= 5 { steps.append(expansion(m0)) }
        steps.append(MatrixStep(title: n <= 5 ? L("Проверка методом Гаусса") : L("Метод Гаусса: приводим к треугольному виду")))
        var m = m0
        var swapped = false
        for c in 0..<n {
            guard let p = pivotRow(m, col: c, from: c) else {
                steps.append(MatrixStep(title: L("Столбец \(c + 1)"),
                                        lines: [L("На диагонали и ниже — одни нули, значит det A = 0")]))
                return steps
            }
            var lines: [String] = []
            if p != c {
                m.a.swapAt(p, c)
                swapped.toggle()
                lines.append(L("Меняем местами строки \(c + 1) и \(p + 1) — знак определителя меняется"))
            }
            for i in (c + 1)..<n where !m.a[i][c].isZero {
                let f = m.a[i][c] / m.a[c][c]
                subtract(&m, row: i, f, pivotRow: c)
                m.a[i][c] = .zero
                lines.append(L("стр. \(i + 1) → ") + rowOp(i, f, c))
            }
            m.clean()
            if !lines.isEmpty {
                steps.append(MatrixStep(title: L("Нули под диагональю в столбце \(c + 1)"), lines: lines, matrix: m))
            }
        }
        var d = swapped ? -MNum.one : MNum.one
        var factors: [String] = []
        for i in 0..<n {
            d = d * m.a[i][i]
            factors.append(m.a[i][i].paren)
        }
        steps.append(MatrixStep(title: L("Матрица треугольная"), lines: [
            L("Определитель — произведение чисел на диагонали") + (swapped ? L(", со знаком «−»: строки менялись нечётное число раз") : ""),
            "det A = \(swapped ? "−" : "")\(factors.joined(separator: " · ")) = \(d.text)" + d.hint]))
        return steps
    }

    /// Разложение по строке или столбцу, где больше всего нулей: det A = Σ aᵢⱼ·Aᵢⱼ
    private static func expansion(_ m: Matrix) -> MatrixStep {
        let n = m.rows
        var byRow = true, k = 0, zeros = -1
        for i in 0..<n {
            let zr = (0..<n).filter { m.a[i][$0].isZero }.count
            if zr > zeros { byRow = true; k = i; zeros = zr }
            let zc = (0..<n).filter { m.a[$0][i].isZero }.count
            if zc > zeros { byRow = false; k = i; zeros = zc }
        }
        var formula: [String] = [], values: [String] = [], lines: [String] = []
        var sum = MNum.zero
        for t in 0..<n {
            let (i, j) = byRow ? (k, t) : (t, k)
            let s = idx(i, j)
            formula.append("a\(s)·A\(s)")
            let aij = m.a[i][j]
            guard !aij.isZero else { continue }
            let minor = m.minor(i, j)
            let md = minor.determinant ?? .zero
            let cof = (i + j) % 2 == 0 ? md : -md
            lines.append(cofactorLine(i, j, minor, cof))
            sum = sum + aij * cof
            values.append("\(aij.paren)·\(cof.paren)")
        }
        let what = byRow ? L("по \(k + 1)-й строке") : L("по \(k + 1)-му столбцу")
        var out = ["det A = " + formula.joined(separator: " + ")]
        if zeros > 0 { out.append(L("Здесь больше всего нулей — их слагаемые сразу равны 0")) }
        out += lines
        out.append("det A = " + (values.isEmpty ? "0" : values.joined(separator: " + ")) + " = \(sum.text)" + sum.hint)
        return MatrixStep(title: L("Разложение \(what)"), lines: out)
    }

    /// «A₁₂ = −M₁₂ = −(4·9 − 6·7) = 6»
    private static func cofactorLine(_ i: Int, _ j: Int, _ minor: Matrix, _ cof: MNum) -> String {
        let s = idx(i, j)
        let plus = (i + j) % 2 == 0
        let head = "A\(s) = \(plus ? "" : "−")M\(s)"
        if minor.rows <= 1 { return "\(head) = \(cof.text)" }
        return "\(head) = \(plus ? "" : "−")\(minorText(minor)) = \(cof.text)"
    }

    /// Минор словами: 2×2 — «(a·d − b·c)», больше — его значение
    private static func minorText(_ m: Matrix) -> String {
        if m.rows == 1 { return m.a[0][0].paren }
        if m.rows == 2 {
            let a = m.a
            return "(\(a[0][0].paren)·\(a[1][1].paren) − \(a[0][1].paren)·\(a[1][0].paren))"
        }
        return (m.determinant ?? .zero).paren
    }

    // MARK: Гаусс — Жордан

    /// В каждом столбце ведущая единица, над и под ней нули
    static func gaussJordan(_ m0: Matrix, columns: Int, bar: Int?, steps: inout [MatrixStep]) -> (m: Matrix, pivots: [Int]) {
        var m = m0
        var r = 0
        var pivots: [Int] = []
        for c in 0..<min(columns, m.cols) where r < m.rows {
            guard let p = pivotRow(m, col: c, from: r) else { continue }
            var lines: [String] = []
            if p != r {
                m.a.swapAt(p, r)
                lines.append(L("Меняем местами строки \(r + 1) и \(p + 1)"))
            }
            let pv = m.a[r][c]
            if !pv.isOne {
                for j in 0..<m.cols { m.a[r][j] = m.a[r][j] / pv }
                m.a[r][c] = .one
                lines.append(pv.isUnit ? L("стр. \(r + 1) · (−1)") : L("стр. \(r + 1) : \(pv.paren)"))
            }
            for i in 0..<m.rows where i != r && !m.a[i][c].isZero {
                let f = m.a[i][c]
                subtract(&m, row: i, f, pivotRow: r)
                m.a[i][c] = .zero
                lines.append(L("стр. \(i + 1) → ") + rowOp(i, f, r))
            }
            m.clean()
            pivots.append(c)
            if !lines.isEmpty {
                steps.append(MatrixStep(title: L("Столбец \(c + 1): ведущий элемент в строке \(r + 1)"),
                                        lines: lines, matrix: m, bar: bar))
            }
            r += 1
        }
        return (m, pivots)
    }

    // MARK: обратная

    /// Обратная матрица: [A | E] → [E | A⁻¹]
    static func inverse(_ a: Matrix) -> [MatrixStep] {
        let n = a.rows
        var aug = Matrix(rows: n, cols: 2 * n)
        for i in 0..<n {
            for j in 0..<n { aug.a[i][j] = a.a[i][j] }
            aug.a[i][n + i] = .one
        }
        var steps = [MatrixStep(title: L("Приписываем справа единичную матрицу: [A | E]"), matrix: aug, bar: n)]
        let res = gaussJordan(aug, columns: n, bar: n, steps: &steps)
        if res.pivots.count < n {
            steps.append(MatrixStep(title: L("Слева не получилась единичная матрица"),
                                    lines: [L("Ранг меньше \(n): det A = 0, обратной матрицы нет")]))
        } else {
            let inv = Matrix(res.m.a.map { Array($0[n...]) })
            steps.append(MatrixStep(title: L("Слева — E, справа — обратная матрица"), lines: ["A⁻¹ ="], matrix: inv))
            if let f = inv.factored {
                steps.append(MatrixStep(title: L("Общий знаменатель за скобку"), lines: ["A⁻¹ = 1/\(f.k) ·"], matrix: f.m))
            }
            if let check = check(a, inv) { steps.append(check) }
        }
        return steps
    }

    /// Обратная через алгебраические дополнения: A⁻¹ = 1/det A · Ã, Ã — транспонированная матрица дополнений
    static func inverseAdjugate(_ a: Matrix) -> [MatrixStep] {
        let n = a.rows
        var steps = [MatrixStep(title: L("Исходная матрица"), matrix: a)]
        guard n > 0, a.isSquare else { return steps }
        let det = a.determinant ?? .zero
        steps.append(MatrixStep(title: L("Определитель"), lines: [
            "det A = \(det.text)" + (det.isZero ? L(" — обратной матрицы нет") : L(" ≠ 0 — обратная есть"))]))
        guard !det.isZero else { return steps }
        if n == 1 {
            let inv = MNum.one / a.a[0][0]
            steps.append(MatrixStep(title: L("Ответ"), lines: ["A⁻¹ = 1/\(a.a[0][0].paren) = \(inv.text)"]))
            return steps
        }
        var cof = Matrix(rows: n, cols: n)
        var lines: [String] = []
        for i in 0..<n {
            for j in 0..<n {
                let minor = a.minor(i, j)
                let md = minor.determinant ?? .zero
                cof.a[i][j] = (i + j) % 2 == 0 ? md : -md
                lines.append(cofactorLine(i, j, minor, cof.a[i][j]))
            }
        }
        steps.append(MatrixStep(title: L("Алгебраические дополнения Aᵢⱼ = (−1)ⁱ⁺ʲ·Mᵢⱼ"), lines: lines, matrix: cof))
        let adj = cof.transposed
        steps.append(MatrixStep(title: L("Присоединённая матрица Ã — дополнения, записанные по столбцам"), matrix: adj))
        let inv = adj.scaled(MNum.one / det)
        steps.append(MatrixStep(title: "A⁻¹ = 1/det A · Ã", lines: ["A⁻¹ = 1/\(det.paren) · Ã ="], matrix: inv))
        if let check = check(a, inv) { steps.append(check) }
        return steps
    }

    /// Проверка A·A⁻¹ = E — как просят в контрольных
    private static func check(_ a: Matrix, _ inv: Matrix) -> MatrixStep? {
        guard a.isExact, inv.isExact, let p = a * inv, p == Matrix.identity(a.rows) else { return nil }
        return MatrixStep(title: L("Проверка"), lines: ["A·A⁻¹ = E ✓"])
    }

    // MARK: ранг

    /// Ранг: сколько ненулевых строк осталось в ступенчатом виде
    static func rank(_ a: Matrix) -> [MatrixStep] {
        var steps = [MatrixStep(title: L("Исходная матрица"), matrix: a)]
        let res = gaussJordan(a, columns: a.cols, bar: nil, steps: &steps)
        steps.append(MatrixStep(title: L("Ступенчатый вид"),
                                lines: [L("Ненулевых строк: \(res.pivots.count)"), "rang A = \(res.pivots.count)"],
                                matrix: res.m))
        return steps
    }

    // MARK: системы

    /// Метод Гаусса: последний столбец — правые части
    static func system(_ a: Matrix) -> MatrixSolution {
        let vars = a.cols - 1
        var steps = [MatrixStep(title: L("Расширенная матрица системы (A | b)"), matrix: a, bar: vars)]
        guard vars >= 1 else { return MatrixSolution(steps: steps, answer: []) }
        let res = gaussJordan(a, columns: vars, bar: vars, steps: &steps)
        let m = res.m
        // строка «0 = b» с b ≠ 0 — противоречие
        for i in 0..<m.rows {
            let zeros = (0..<vars).allSatisfy { m.a[i][$0].isZero }
            if zeros && !m.a[i][vars].isZero {
                let answer = [L("Строка \(i + 1): 0 = \(m.a[i][vars].text) — противоречие"),
                              L("Система несовместна: решений нет")]
                steps.append(MatrixStep(title: L("Ответ"), lines: answer))
                return MatrixSolution(steps: steps, answer: answer)
            }
        }
        let free = (0..<vars).filter { !res.pivots.contains($0) }
        var answer: [String] = []
        for (row, c) in res.pivots.enumerated() {
            var parts: [String] = []
            let b = m.a[row][vars]
            if !b.isZero { parts.append(b.text) }
            for f in free where !m.a[row][f].isZero {
                let k = -m.a[row][f]
                let term = (k.absValue.isOne ? "" : k.absValue.coef + "·") + "x" + sub(f + 1)
                if parts.isEmpty {
                    parts.append((k.isNegative ? "−" : "") + term)
                } else {
                    parts.append((k.isNegative ? "− " : "+ ") + term)
                }
            }
            answer.append("x\(sub(c + 1)) = " + (parts.isEmpty ? "0" : parts.joined(separator: " ")) + (free.isEmpty ? b.hint : ""))
        }
        if free.isEmpty {
            answer.append(L("Решение единственное"))
            steps.append(MatrixStep(title: L("Ответ"), lines: answer))
            let x = (0..<vars).map { m.a[$0][vars] }
            if let check = substitution(a, vars: vars, x: x) { steps.append(check) }
        } else {
            answer.append(free.map { "x" + sub($0 + 1) }.joined(separator: ", ")
                          + L(" — свободные (любые числа): решений бесконечно много"))
            steps.append(MatrixStep(title: L("Ответ"), lines: answer))
        }
        return MatrixSolution(steps: steps, answer: answer)
    }

    /// Метод Крамера: xₖ = Δₖ / Δ
    static func cramer(_ ab: Matrix) -> MatrixSolution {
        let n = ab.rows
        var steps = [MatrixStep(title: L("Система (A | b)"), matrix: ab, bar: max(ab.cols - 1, 0))]
        guard n >= 1, ab.cols == n + 1 else {
            let msg = [L("Метод Крамера — только когда уравнений столько же, сколько неизвестных")]
            steps.append(MatrixStep(title: L("Не подходит"), lines: msg))
            return MatrixSolution(steps: steps, answer: msg)
        }
        let main = Matrix(ab.a.map { Array($0.prefix(n)) })
        let b = ab.a.map { $0[n] }
        let delta = main.determinant ?? .zero
        steps.append(MatrixStep(title: L("Главный определитель Δ = det A"), lines: ["Δ = \(delta.text)"], matrix: main))
        guard !delta.isZero else {
            let msg = [L("Δ = 0 — метод Крамера не подходит: решений нет или их бесконечно много"),
                       L("Метод Гаусса покажет, какой из случаев")]
            steps.append(MatrixStep(title: L("Ответ"), lines: msg))
            return MatrixSolution(steps: steps, answer: msg)
        }
        var answer: [String] = []
        var x: [MNum] = []
        for k in 0..<n {
            var mk = main
            for i in 0..<n { mk.a[i][k] = b[i] }
            let dk = mk.determinant ?? .zero
            let xk = dk / delta
            x.append(xk)
            steps.append(MatrixStep(title: L("Δ\(sub(k + 1)): вместо \(k + 1)-го столбца — правые части"),
                                    lines: ["Δ\(sub(k + 1)) = \(dk.text)"], matrix: mk))
            answer.append("x\(sub(k + 1)) = Δ\(sub(k + 1))/Δ = \(dk.text)/\(delta.paren) = \(xk.text)" + xk.hint)
        }
        steps.append(MatrixStep(title: L("Ответ"), lines: answer))
        if let check = substitution(ab, vars: n, x: x) { steps.append(check) }
        return MatrixSolution(steps: steps, answer: answer)
    }

    /// Матричный метод: X = A⁻¹·B
    static func matrixMethod(_ ab: Matrix) -> MatrixSolution {
        let n = ab.rows
        var steps = [MatrixStep(title: L("Система A·X = B"), matrix: ab, bar: max(ab.cols - 1, 0))]
        guard n >= 1, ab.cols == n + 1 else {
            let msg = [L("Матричный метод — только когда уравнений столько же, сколько неизвестных")]
            steps.append(MatrixStep(title: L("Не подходит"), lines: msg))
            return MatrixSolution(steps: steps, answer: msg)
        }
        let main = Matrix(ab.a.map { Array($0.prefix(n)) })
        let b = ab.a.map { $0[n] }
        guard let inv = main.inverse else {
            let msg = [L("det A = 0 — обратной матрицы нет, матричный метод не подходит"),
                       L("Метод Гаусса покажет, есть ли решения")]
            steps.append(MatrixStep(title: L("Ответ"), lines: msg))
            return MatrixSolution(steps: steps, answer: msg)
        }
        steps.append(MatrixStep(title: L("det A = \((main.determinant ?? .zero).text) ≠ 0 — находим A⁻¹"),
                                lines: [L("Как её найти — по шагам в «Обратной». A⁻¹ =")], matrix: inv))
        if let f = inv.factored {
            steps.append(MatrixStep(title: L("Без дробей внутри"), lines: ["A⁻¹ = 1/\(f.k) ·"], matrix: f.m))
        }
        var lines: [String] = [], answer: [String] = []
        var x: [MNum] = []
        for i in 0..<n {
            var v = MNum.zero
            var terms: [String] = []
            for j in 0..<n {
                v = v + inv.a[i][j] * b[j]
                terms.append("\(inv.a[i][j].paren)·\(b[j].paren)")
            }
            x.append(v)
            lines.append("x\(sub(i + 1)) = " + terms.joined(separator: " + ") + " = \(v.text)")
            answer.append("x\(sub(i + 1)) = \(v.text)" + v.hint)
        }
        steps.append(MatrixStep(title: L("X = A⁻¹·B: строки A⁻¹ на столбец правых частей"), lines: lines))
        steps.append(MatrixStep(title: L("Ответ"), lines: answer))
        if let check = substitution(ab, vars: n, x: x) { steps.append(check) }
        return MatrixSolution(steps: steps, answer: answer)
    }

    /// Проверка подстановкой: каждое уравнение — левая часть с найденными x
    private static func substitution(_ a: Matrix, vars: Int, x: [MNum]) -> MatrixStep? {
        guard vars <= 6, x.count == vars, a.isExact, x.allSatisfy(\.isExact) else { return nil }
        var lines: [String] = []
        for i in 0..<a.rows {
            var terms: [String] = []
            var sum = MNum.zero
            for j in 0..<vars where !a.a[i][j].isZero {
                terms.append("\(a.a[i][j].paren)·\(x[j].paren)")
                sum = sum + a.a[i][j] * x[j]
            }
            let ok = sum == a.a[i][vars]
            lines.append((terms.isEmpty ? "0" : terms.joined(separator: " + ")) + " = \(sum.text)"
                         + (ok ? " ✓" : " ≠ \(a.a[i][vars].text)"))
        }
        return MatrixStep(title: L("Проверка: подставляем ответ в каждое уравнение"), lines: lines)
    }

    // MARK: две матрицы

    /// A·B: каждый элемент — строка A на столбец B
    static func product(_ l: Matrix, _ r: Matrix) -> [MatrixStep] {
        var steps = [MatrixStep(title: L("Матрица A"), matrix: l), MatrixStep(title: L("Матрица B"), matrix: r)]
        guard let c = l * r else {
            steps.append(MatrixStep(title: L("Умножить нельзя"),
                                    lines: [L("Столбцов в A (\(l.cols)) должно быть столько же, сколько строк в B (\(r.rows))")]))
            return steps
        }
        var lines: [String] = []
        if c.rows * c.cols <= 25 && l.cols <= 6 {
            for i in 0..<c.rows {
                for j in 0..<c.cols {
                    let terms = (0..<l.cols).map { "\(l.a[i][$0].paren)·\(r.a[$0][j].paren)" }.joined(separator: " + ")
                    lines.append("c\(idx(i, j)) = \(terms) = \(c.a[i][j].text)")
                }
            }
        } else {
            lines.append(L("cᵢⱼ — сумма произведений i-й строки A на j-й столбец B"))
        }
        steps.append(MatrixStep(title: L("Строка на столбец: cᵢⱼ = aᵢ₁b₁ⱼ + aᵢ₂b₂ⱼ + …"), lines: lines))
        steps.append(MatrixStep(title: L("Ответ: A·B"), matrix: c))
        return steps
    }
}

// MARK: - Собственные числа и векторы

enum MatrixEigen {
    struct Root {
        enum Kind {
            /// Рациональный корень — точно
            case exact(MNum)
            /// Пара mid ± spread (иррациональные), с точной записью через корень, если она есть
            case realPair(String?, Double, Double)
            /// Комплексная пара re ± im·i
            case complexPair(String?, Double, Double)
            /// Найден только приближённо
            case real(Double)
        }
        var kind: Kind
        var mult: Int

        var exact: MNum? {
            if case .exact(let x) = kind { return x }
            return nil
        }

        /// Сколько λ в этой записи (пара — два)
        var count: Int {
            switch kind {
            case .realPair, .complexPair: return 2 * mult
            default: return mult
            }
        }

        var sortKey: Double {
            switch kind {
            case .exact(let x): return x.value
            case .real(let x): return x
            case .realPair(_, let mid, let spread): return mid - spread
            case .complexPair: return .infinity
            }
        }

        var text: String {
            switch kind {
            case .exact(let x):
                return x.text + x.hint
            case .real(let x):
                return "≈ " + MatrixFmt.decimal(x)
            case .realPair(let surd, let mid, let spread):
                let approx = L("\(MatrixFmt.decimal(mid + spread)) и \(MatrixFmt.decimal(mid - spread))")
                return surd.map { "\($0) ≈ \(approx)" } ?? "≈ " + approx
            case .complexPair(let surd, let re, let im):
                let approx = "\(MatrixFmt.decimal(re)) ± \(MatrixFmt.decimal(im))i"
                return surd.map { "\($0) ≈ \(approx)" } ?? "≈ " + approx
            }
        }
    }

    /// Коэффициенты det(λE − A) от λⁿ до свободного члена — метод Фаддеева — Леверье, в точных дробях
    static func charPoly(_ a: Matrix) -> [MNum] {
        let n = a.rows
        var c = [MNum](repeating: .zero, count: n + 1)
        c[0] = .one
        guard n > 0 else { return c }
        var m = Matrix(rows: n, cols: n)
        for k in 1...n {
            var next = (a * m) ?? Matrix(rows: n, cols: n)
            for i in 0..<n { next.a[i][i] = next.a[i][i] + c[k - 1] }
            m = next
            let am = (a * m) ?? Matrix(rows: n, cols: n)
            c[k] = -(am.trace / MNum(k))
        }
        return c
    }

    /// «−λ³ + 6λ² − 11λ + 6» — коэффициенты от старшей степени
    static func polyText(_ coeffs: [MNum], v: String = "λ") -> String {
        let n = coeffs.count - 1
        var out = ""
        for (i, c) in coeffs.enumerated() where !c.isZero {
            let deg = n - i
            let mag = c.absValue
            var term = ""
            if deg == 0 { term = mag.text } else if !mag.isOne { term = mag.coef }
            if deg >= 1 { term += v + (deg >= 2 ? MatrixFmt.sup(deg) : "") }
            if out.isEmpty {
                out = (c.isNegative ? "−" : "") + term
            } else {
                out += (c.isNegative ? " − " : " + ") + term
            }
        }
        return out.isEmpty ? "0" : out
    }

    /// Корни многочлена (коэффициенты от старшей степени): рациональные — точно,
    /// квадратный остаток — через корень, остальное — численно
    static func roots(_ coeffs: [MNum]) -> [Root] {
        var p = coeffs
        while p.count > 1, let f = p.first, f.isZero { p.removeFirst() }
        var out: [Root] = []
        func add(_ r: Root) {
            if let x = r.exact, let i = out.firstIndex(where: { $0.exact == x }) {
                out[i].mult += r.mult
                return
            }
            if case .real(let x) = r.kind, let i = out.firstIndex(where: { other in
                if case .real(let y) = other.kind { return abs(x - y) < 1e-6 * (1 + abs(x)) }
                return false
            }) {
                out[i].mult += r.mult
                return
            }
            out.append(r)
        }
        // нулевые корни
        while p.count > 1, let last = p.last, last.isZero {
            p.removeLast()
            add(Root(kind: .exact(.zero), mult: 1))
        }
        if p.count > 1, p.allSatisfy(\.isExact) {
            for r in rationalCandidates(p) where p.count > 1 {
                while p.count > 1, horner(p, r).isZero {
                    p = deflate(p, r)
                    add(Root(kind: .exact(r), mult: 1))
                }
            }
            if p.count == 3 {
                for r in quadratic(p[0], p[1], p[2]) { add(r) }
                p = [p[0]]
            } else if p.count == 2 {
                add(Root(kind: .exact(-(p[1] / p[0])), mult: 1))
                p = [p[0]]
            }
        }
        if p.count > 1 {
            for (re, im) in numericRoots(p.map(\.value)) {
                if abs(im) < 1e-6 * (1 + abs(re)) {
                    add(Root(kind: .real(re), mult: 1))
                } else if im > 0 {
                    add(Root(kind: .complexPair(nil, re, im), mult: 1))
                }
            }
        }
        return out.sorted { $0.sortKey < $1.sortKey }
    }

    private static func horner(_ p: [MNum], _ x: MNum) -> MNum {
        var acc = MNum.zero
        for c in p { acc = acc * x + c }
        return acc
    }

    /// Деление на (λ − r) по схеме Горнера
    private static func deflate(_ p: [MNum], _ r: MNum) -> [MNum] {
        var out: [MNum] = []
        var acc = MNum.zero
        for c in p.dropLast() {
            acc = acc * r + c
            out.append(acc)
        }
        return out
    }

    /// Кандидаты в рациональные корни: ±(делитель свободного члена)/(делитель старшего)
    private static func rationalCandidates(_ p: [MNum]) -> [MNum] {
        var l = 1
        for c in p where c.d > 1 {
            let g = MNum.gcd(l, c.d)
            let (v, o) = (l / g).multipliedReportingOverflow(by: c.d)
            if o { return [] }
            l = v
        }
        var ints: [Int] = []
        for c in p {
            let (v, o) = c.n.multipliedReportingOverflow(by: l / c.d)
            if o { return [] }
            ints.append(v)
        }
        guard let lead = ints.first, let constant = ints.last, lead != 0, constant != 0 else { return [] }
        let ps = divisors(constant.magnitude), qs = divisors(lead.magnitude)
        guard !ps.isEmpty, !qs.isEmpty, ps.count * qs.count <= 20_000 else { return [] }
        var seen = Set<MNum>()
        var list: [MNum] = []
        for q in qs {
            for d in ps {
                for s in [1, -1] {
                    let r = MNum.fraction(s * d, q)
                    if seen.insert(r).inserted { list.append(r) }
                }
            }
        }
        return list.sorted { abs($0.value) < abs($1.value) }
    }

    private static func divisors(_ x: UInt) -> [Int] {
        guard x > 0, x <= 1_000_000_000_000 else { return [] }
        var small: [Int] = [], large: [Int] = []
        var i: UInt = 1
        while i * i <= x {
            if x % i == 0 {
                small.append(Int(i))
                if i != x / i { large.append(Int(x / i)) }
            }
            i += 1
        }
        return small + large.reversed()
    }

    /// aλ² + bλ + c: корни mid ± √D/(2a)
    private static func quadratic(_ a: MNum, _ b: MNum, _ c: MNum) -> [Root] {
        let two = MNum(2) * a
        let mid = -(b / two)
        let disc = b * b - MNum(4) * a * c
        if disc.isZero { return [Root(kind: .exact(mid), mult: 2)] }
        let half = (abs(disc.value)).squareRoot() / abs(two.value)
        let surd = surdText(mid: mid, disc: disc, two: two)
        if !disc.isNegative {
            if let r = surd.rational {
                return [Root(kind: .exact(mid + r), mult: 1), Root(kind: .exact(mid - r), mult: 1)]
            }
            return [Root(kind: .realPair(surd.text, mid.value, half), mult: 1)]
        }
        return [Root(kind: .complexPair(surd.text, mid.value, half), mult: 1)]
    }

    /// «3/2 ± (1/2)·√5» — точная запись корней квадратного уравнения
    private static func surdText(mid: MNum, disc: MNum, two: MNum) -> (text: String?, rational: MNum?) {
        guard disc.isExact, two.isExact, mid.isExact else { return (nil, nil) }
        let neg = disc.isNegative
        let dd = disc.absValue
        let (pq, o) = dd.n.multipliedReportingOverflow(by: dd.d)
        guard !o, pq > 0, pq <= 1_000_000_000_000 else { return (nil, nil) }
        // √(p/q) = √(p·q)/q, p·q = s²·t
        var s = 1, t = pq, f = 2
        while f * f <= t {
            while t % (f * f) == 0 {
                t /= f * f
                s *= f
            }
            f += 1
        }
        let k = MNum.fraction(s, dd.d) / two.absValue
        if t == 1 && !neg { return (nil, k) }
        let root = (t == 1 ? "" : "√\(t)") + (neg ? (t == 1 ? "i" : "·i") : "")
        let kText = k.isOne ? "" : k.coef + (t == 1 ? "" : "·")
        let head = mid.isZero ? "±" : "\(mid.text) ± "
        return (head + kText + root, nil)
    }

    /// Все корни численно (метод Дюрана — Кернера): пары (вещественная часть, мнимая)
    private static func numericRoots(_ c: [Double]) -> [(Double, Double)] {
        let n = c.count - 1
        guard n >= 1, c[0] != 0, c.allSatisfy(\.isFinite) else { return [] }
        let a = c.map { $0 / c[0] }
        var re = [Double](), im = [Double]()
        var zr = 1.0, zi = 0.0
        for _ in 0..<n {
            let r = zr * 0.4 - zi * 0.9
            let i = zr * 0.9 + zi * 0.4
            zr = r
            zi = i
            re.append(zr)
            im.append(zi)
        }
        for _ in 0..<800 {
            var delta = 0.0
            for k in 0..<n {
                var pr = 1.0, pi = 0.0
                for j in 1...n {
                    let nr = pr * re[k] - pi * im[k] + a[j]
                    let ni = pr * im[k] + pi * re[k]
                    pr = nr
                    pi = ni
                }
                var dr = 1.0, di = 0.0
                for j in 0..<n where j != k {
                    let xr = re[k] - re[j], xi = im[k] - im[j]
                    let nr = dr * xr - di * xi
                    let ni = dr * xi + di * xr
                    dr = nr
                    di = ni
                }
                let den = dr * dr + di * di
                guard den > 1e-300 else { continue }
                let qr = (pr * dr + pi * di) / den
                let qi = (pi * dr - pr * di) / den
                re[k] -= qr
                im[k] -= qi
                delta = max(delta, abs(qr) + abs(qi))
            }
            if delta < 1e-14 { break }
        }
        return Array(zip(re, im))
    }

    /// Базис собственных векторов для точного λ: решаем (A − λE)·x = 0
    static func eigenvectors(_ a: Matrix, _ l: MNum) -> [[MNum]] {
        var n = a
        for i in 0..<a.rows { n.a[i][i] = n.a[i][i] - l }
        let r = n.reduced()
        let free = (0..<a.cols).filter { !r.pivots.contains($0) }
        return free.map { f -> [MNum] in
            var v = [MNum](repeating: .zero, count: a.cols)
            v[f] = .one
            for (row, pc) in r.pivots.enumerated() { v[pc] = -r.m.a[row][f] }
            return integerVector(v)
        }
    }

    /// Вектор без дробей и с первым ненулевым > 0: (1/2; 1) → (1; 2)
    private static func integerVector(_ v: [MNum]) -> [MNum] {
        guard v.allSatisfy(\.isExact) else { return v }
        var l = 1
        for x in v where x.d > 1 {
            let g = MNum.gcd(l, x.d)
            let (m, o) = (l / g).multipliedReportingOverflow(by: x.d)
            if o { return v }
            l = m
        }
        var w = v.map { $0 * MNum(l) }
        let g = w.filter { !$0.isZero }.reduce(0) { MNum.gcd($0, $1.n) }
        if g > 1 { w = w.map { MNum.fraction($0.n, g) } }
        if let first = w.first(where: { !$0.isZero }), first.isNegative { w = w.map { -$0 } }
        return w
    }

    private static func vectorsText(_ vs: [[MNum]]) -> String {
        guard !vs.isEmpty else { return "0" }
        let parts = vs.map { "(" + $0.map(\.text).joined(separator: "; ") + ")ᵀ" }
        if parts.count == 1 { return "C·" + parts[0] + ", C ≠ 0" }
        return parts.enumerated().map { "C\(MatrixFmt.sub($0.offset + 1))·\($0.element)" }.joined(separator: " + ")
    }

    /// Собственные числа по шагам: характеристическое уравнение, его корни, векторы для точных λ
    static func solve(_ a: Matrix) -> MatrixSolution {
        let n = a.rows
        var steps = [MatrixStep(title: L("Исходная матрица"), matrix: a)]
        guard n >= 1, a.isSquare else { return MatrixSolution(steps: steps, answer: []) }
        let p = charPoly(a)
        // |A − λE| = (−1)ⁿ·det(λE − A)
        let q = n % 2 == 0 ? p : p.map { -$0 }
        var lines: [String] = []
        if n == 2 {
            let m = a.a
            lines.append("|A − λE| = (\(m[0][0].text) − λ)·(\(m[1][1].text) − λ) − \(m[0][1].paren)·\(m[1][0].paren)")
        }
        lines.append("|A − λE| = \(polyText(q)) = 0")
        lines.append(L("Для проверки: сумма корней = tr A = \(a.trace.text), произведение = det A = \((a.determinant ?? .zero).text)"))
        steps.append(MatrixStep(title: L("Характеристическое уравнение"), lines: lines))
        let rs = roots(p)
        var answer: [String] = []
        var k = 1
        for r in rs {
            let label = (k..<(k + r.count)).map { MatrixFmt.sub($0) }.joined(separator: ",")
            k += r.count
            answer.append("λ\(label) = \(r.text)" + (r.mult > 1 ? L(" (кратный)") : ""))
        }
        steps.append(MatrixStep(title: L("Собственные числа — корни уравнения"), lines: answer))
        for r in rs {
            guard let l = r.exact else { continue }
            var shifted = a
            for i in 0..<n { shifted.a[i][i] = shifted.a[i][i] - l }
            let v = vectorsText(eigenvectors(a, l))
            let what: String
            if l.isZero {
                what = "A"
            } else if l.isNegative {
                what = "A + \(l.absValue.isOne ? "" : l.absValue.coef)E"
            } else {
                what = "A − \(l.isOne ? "" : l.coef)E"
            }
            steps.append(MatrixStep(title: L("λ = \(l.text): решаем (\(what))·x = 0"), lines: ["x = " + v], matrix: shifted))
            answer.append("λ = \(l.text): x = " + v)
        }
        if rs.contains(where: { $0.exact == nil }) {
            let note = L("Векторы для иррациональных и комплексных λ — в Wolfram|Alpha ниже")
            steps.append(MatrixStep(title: L("Остальные векторы"), lines: [note]))
            answer.append(note)
        }
        return MatrixSolution(steps: steps, answer: answer)
    }
}

// MARK: - Распознавание матрицы на фото

enum MatrixOCR {
    struct Result {
        var matrix: Matrix
        /// Ячейки, где камера могла ошибиться (ключ i·100 + j) — подсвечиваются оранжевым
        var doubts: Set<Int>
        /// Ячейки, где числа не нашлось — остаются пустыми
        var missing: Set<Int>
        /// По бокам высокие черты — похоже на определитель
        var bars: Bool
        /// Система записана уравнениями: последний столбец — правые части
        var system: Bool
        /// Где на снимке матрица: доли, начало сверху слева
        var area: CGRect
    }

    private struct Token {
        var value: MNum
        var x: Double
        var y: Double
        let h: Double
        /// Рамка числа: доли снимка, начало сверху слева
        let box: CGRect
        var doubt: Bool
    }

    private static let numberRegex = try? NSRegularExpression(pattern: #"[-−–—]?\s?\d+(?:[.,]\d+)?(?:/\d+)?"#)
    private static let lonelyDash = try? NSRegularExpression(pattern: #"(?:^|\s)([-−–—])(?=\s|$)"#)
    private static let termRegex = try? NSRegularExpression(pattern: #"([+-]?)(\d+(?:\.\d+)?(?:/\d+)?)?\*?([a-z])(\d{0,2})"#)
    /// Черты определителя и скобки — не цифры
    private static let edgeMarks: Set<Character> = ["|", "‖", "¦", "[", "]", "(", ")", "{", "}"]
    private static let zeroLike: Set<Character> = ["O", "o", "О", "о", "Q"]
    private static let oneLike: Set<Character> = ["l", "I", "!"]

    // MARK: подготовка снимка

    /// Снимок «как видно глазами»: повёрнут правильно и уменьшен до ~2600 точек по длинной стороне —
    /// распознаётся быстрее и тратит меньше памяти, а цифры остаются чёткими
    static func prepare(_ image: UIImage, maxSide: CGFloat = 2600) -> UIImage {
        let w = image.size.width * image.scale, h = image.size.height * image.scale
        guard w > 0, h > 0 else { return image }
        let k = min(1, maxSide / max(w, h))
        let size = CGSize(width: max(1, (w * k).rounded()), height: max(1, (h * k).rounded()))
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        return UIGraphicsImageRenderer(size: size, format: format).image { ctx in
            UIColor.white.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            image.draw(in: CGRect(origin: .zero, size: size))
        }
    }

    /// Фото из галереи сразу уменьшенным: 48-Мп снимок целиком занял бы ~200 МБ памяти
    static func prepare(data: Data, maxSide: CGFloat = 2600) -> UIImage? {
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceThumbnailMaxPixelSize: maxSide,
        ]
        if let src = CGImageSourceCreateWithData(data as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
           let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) {
            return UIImage(cgImage: cg)
        }
        return UIImage(data: data).map { prepare($0, maxSide: maxSide) }
    }

    /// Кусок снимка внутри рамки (рамка в долях, начало сверху слева)
    static func crop(_ image: UIImage, to r: CGRect) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let w = CGFloat(cg.width), h = CGFloat(cg.height)
        let rect = CGRect(x: r.minX * w, y: r.minY * h, width: r.width * w, height: r.height * h).integral
            .intersection(CGRect(x: 0, y: 0, width: w, height: h))
        guard !rect.isNull, rect.width > 8, rect.height > 8, let piece = cg.cropping(to: rect) else { return image }
        return UIImage(cgImage: piece)
    }

    // MARK: распознавание

    static func recognize(_ image: UIImage) -> Result? {
        guard let cg = image.cgImage, let pattern = numberRegex else { return nil }
        let w = Double(cg.width), h = Double(cg.height)
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["en-US"]
        req.usesLanguageCorrection = false   // иначе «1O» превращается в слово
        req.minimumTextHeight = 0.01
        let handler = VNImageRequestHandler(cgImage: cg, orientation: .up, options: [:])
        do { try handler.perform([req]) } catch { return nil }
        let observations = req.results ?? []
        guard !observations.isEmpty else { return nil }

        // система, записанная уравнениями «2x + 3y = 5», — свой разбор
        if let sys = equations(observations) { return sys }

        var tokens: [Token] = []
        var dashes: [CGRect] = []
        for obs in observations {
            guard let cand = obs.topCandidates(1).first else { continue }
            let raw = cand.string
            let s = fixLine(cand)
            let unsure = cand.confidence < 0.5
            let ns = s as NSString
            let all = NSRange(location: 0, length: ns.length)
            for m in pattern.matches(in: s, range: all) {
                let num = ns.substring(with: m.range).replacingOccurrences(of: " ", with: "")
                guard let v = MNum.parse(num) else { continue }
                var b = obs.boundingBox
                var changed = true
                if let r = Range(m.range, in: raw), let r2 = Range(m.range, in: s) {
                    changed = raw[r] != s[r2]
                    if let bb = try? cand.boundingBox(for: r) { b = bb.boundingBox }
                }
                let box = CGRect(x: b.minX, y: 1 - b.maxY, width: b.width, height: b.height)
                tokens.append(Token(value: v, x: Double(box.midX) * w, y: Double(box.midY) * h,
                                    h: max(Double(box.height) * h, 1), box: box, doubt: unsure || changed))
            }
            // одинокий минус: Vision иногда отрывает его от числа
            for m in lonelyDash?.matches(in: s, range: all) ?? [] {
                if let r = Range(m.range(at: 1), in: raw), let bb = try? cand.boundingBox(for: r) {
                    let b = bb.boundingBox
                    dashes.append(CGRect(x: b.minX, y: 1 - b.maxY, width: b.width, height: b.height))
                }
            }
        }
        guard !tokens.isEmpty else { return nil }

        // скобки и черты определителя часто читаются как высокая «1» — отбрасываем всё, что намного выше чисел
        let hs = tokens.map(\.h).sorted()
        let medianH = hs[hs.count / 2]
        let tall = tokens.filter { $0.h >= medianH * 2.2 }
        tokens = tokens.filter { $0.h < medianH * 2.2 }
        guard !tokens.isEmpty else { return nil }
        let minX = tokens.map(\.x).min() ?? 0, maxX = tokens.map(\.x).max() ?? 0
        let bars = tall.contains { $0.x < minX } && tall.contains { $0.x > maxX }

        // минус слева от числа на той же строке — число отрицательное
        for d in dashes {
            let right = Double(d.maxX) * w, mid = Double(d.midY) * h
            let near = tokens.indices.filter { i in
                let gap = Double(tokens[i].box.minX) * w - right
                return abs(tokens[i].y - mid) < medianH * 0.6 && gap > -medianH * 0.3 && gap < medianH * 1.6
            }
            if let k = near.min(by: { tokens[$0].x < tokens[$1].x }),
               !tokens[k].value.isNegative, !tokens[k].value.isZero {
                tokens[k].value = -tokens[k].value
                tokens[k].doubt = true
            }
        }

        // снимок под наклоном: соседи по строке должны лежать на одной горизонтали — выравниваем
        var angles: [Double] = []
        for t in tokens {
            var best: Token?
            for u in tokens where u.x > t.x + medianH * 0.5 && abs(u.y - t.y) < medianH * 1.2 && u.x - t.x < medianH * 14 {
                if let b = best, u.x >= b.x { continue }
                best = u
            }
            if let b = best { angles.append(atan2(b.y - t.y, b.x - t.x)) }
        }
        if angles.count >= 3 {
            let a = angles.sorted()[angles.count / 2]
            if abs(a) > 0.012, abs(a) < 0.35 {
                let c = cos(-a), sn = sin(-a)
                for i in tokens.indices {
                    let x = tokens[i].x, y = tokens[i].y
                    tokens[i].x = x * c - y * sn
                    tokens[i].y = x * sn + y * c
                }
            }
        }

        // строки: близкие по высоте числа (сравниваем со средним по строке)
        let gap = medianH * 0.65
        var rows: [[Token]] = []
        for t in tokens.sorted(by: { $0.y < $1.y }) {
            if let last = rows.last {
                let y0 = last.map(\.y).reduce(0, +) / Double(last.count)
                if abs(t.y - y0) < gap {
                    rows[rows.count - 1].append(t)
                    continue
                }
            }
            rows.append([t])
        }
        rows = trimOutliers(rows.map { $0.sorted { $0.x < $1.x } })

        // сколько столбцов: самое частое число чисел в строке
        let counts = Dictionary(grouping: rows.map(\.count), by: { $0 }).mapValues(\.count)
        guard let n = counts.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key, n > 0 else { return nil }
        // случайные надписи (номер задачи, «A =») отбрасываем
        rows = rows.filter { $0.count * 2 >= n && $0.count <= n + 1 }
        let full = rows.filter { $0.count == n }
        guard !rows.isEmpty, !full.isEmpty else { return nil }

        // центры столбцов — по полным строкам, потом уточняем по всем числам
        var centers = (0..<n).map { j in full.map { $0[j].x }.reduce(0, +) / Double(full.count) }
        for _ in 0..<2 {
            var sum = [Double](repeating: 0, count: n)
            var cnt = [Int](repeating: 0, count: n)
            for row in rows {
                for t in row {
                    let j = nearest(centers, t.x)
                    sum[j] += t.x
                    cnt[j] += 1
                }
            }
            for j in 0..<n where cnt[j] > 0 { centers[j] = sum[j] / Double(cnt[j]) }
        }

        // раскладываем по ячейкам; два числа в одну ячейку или пустая ячейка — под сомнением
        let size = min(rows.count, 10), width = min(n, 10)
        var values = [[MNum]](repeating: [MNum](repeating: .zero, count: width), count: size)
        var taken = [[Double]](repeating: [Double](repeating: .infinity, count: width), count: size)
        var doubts = Set<Int>(), missing = Set<Int>()
        var area = CGRect.null
        for (i, row) in rows.prefix(size).enumerated() {
            for t in row {
                let j = nearest(centers, t.x)
                guard j < width else { continue }
                let dist = abs(centers[j] - t.x)
                if dist < taken[i][j] {
                    if taken[i][j] < .infinity { doubts.insert(i * 100 + j) }
                    taken[i][j] = dist
                    values[i][j] = t.value
                    if t.doubt { doubts.insert(i * 100 + j) }
                } else {
                    doubts.insert(i * 100 + j)
                }
                area = area.union(t.box)
            }
            for j in 0..<width where taken[i][j] == .infinity {
                missing.insert(i * 100 + j)
                doubts.insert(i * 100 + j)
            }
        }
        return Result(matrix: Matrix(values), doubts: doubts, missing: missing, bars: bars, system: false,
                      area: area.isNull ? CGRect(x: 0, y: 0, width: 1, height: 1) : area)
    }

    /// Строки, далеко оторванные сверху или снизу (номер задачи, подпись), — не матрица
    private static func trimOutliers(_ rows: [[Token]]) -> [[Token]] {
        guard rows.count >= 3 else { return rows }
        let ys = rows.map { r in r.map(\.y).reduce(0, +) / Double(r.count) }
        let gaps = zip(ys.dropFirst(), ys).map { $0 - $1 }.sorted()
        let typical = gaps[(gaps.count - 1) / 2]
        guard typical > 0 else { return rows }
        var lo = 0, hi = rows.count - 1
        while hi - lo >= 2, ys[lo + 1] - ys[lo] > typical * 2.2 { lo += 1 }
        while hi - lo >= 2, ys[hi] - ys[hi - 1] > typical * 2.2 { hi -= 1 }
        return Array(rows[lo...hi])
    }

    private static func nearest(_ centers: [Double], _ x: Double) -> Int {
        var best = 0
        for j in centers.indices where abs(centers[j] - x) < abs(centers[best] - x) { best = j }
        return best
    }

    /// Чинит строку распознавания: буквы-двойники цифр внутри чисел («1O» → 10, «S» → 5),
    /// а черты и скобки у краёв чисел убирает (раньше «|2» читалось как 12).
    /// Длина строки не меняется — выброшенное становится пробелом, поэтому рамки берутся по исходной строке
    private static func fixLine(_ cand: VNRecognizedText) -> String {
        let raw = cand.string
        let idx = Array(raw.indices)
        var out = Array(raw)
        guard out.count == idx.count else { return raw }
        func isDigit(_ c: Character) -> Bool { c >= "0" && c <= "9" }
        func height(_ from: Int, _ to: Int) -> Double? {
            guard from <= to, to < idx.count else { return nil }
            let range = idx[from]..<raw.index(after: idx[to])
            guard let box = try? cand.boundingBox(for: range) else { return nil }
            return Double(box.boundingBox.height)
        }
        var s = 0
        while s < out.count {
            if out[s] == " " {
                s += 1
                continue
            }
            var e = s
            while e < out.count && out[e] != " " { e += 1 }
            let word = Array(out[s..<e])
            let hasDigit = word.contains(where: isDigit)
            if hasDigit || word.allSatisfy({ zeroLike.contains($0) }) {
                // высота самих цифр — чтобы отличить единицу от черты определителя
                let digitIdx = (s..<e).filter { isDigit(out[$0]) }
                var digitH: Double?
                if let f = digitIdx.first, let l = digitIdx.last { digitH = height(f, l) }
                for i in s..<e {
                    let c = out[i]
                    if edgeMarks.contains(c) {
                        out[i] = " "
                        continue
                    }
                    if zeroLike.contains(c) {
                        out[i] = "0"
                        continue
                    }
                    guard hasDigit else { continue }
                    if oneLike.contains(c) {
                        let edge = i == s || i == e - 1
                        if edge, let dh = digitH, dh > 0, let ch = height(i, i), ch > dh * 1.6 {
                            out[i] = " "
                        } else {
                            out[i] = "1"
                        }
                        continue
                    }
                    switch c {
                    case "S", "s": out[i] = "5"
                    case "B": out[i] = "8"
                    case "Z", "z": out[i] = "2"
                    case "G", "б": out[i] = "6"
                    case "g", "q": out[i] = "9"
                    default: break
                    }
                }
            } else if word.count == 1, oneLike.contains(word[0]) || word[0] == "|" {
                // одиночная «l» или «|»: единица или черта — решит высота (черты гораздо выше цифр)
                out[s] = "1"
            }
            s = e
        }
        return String(out)
    }

    // MARK: системы уравнениями

    /// Система, записанная уравнениями: «2x + 3y − z = 5» → строка (2  3  −1 | 5)
    private static func equations(_ observations: [VNRecognizedTextObservation]) -> Result? {
        struct Piece {
            let text: String
            let box: CGRect
        }
        var pieces: [Piece] = []
        for obs in observations {
            guard let c = obs.topCandidates(1).first else { continue }
            let b = obs.boundingBox
            pieces.append(Piece(text: c.string, box: CGRect(x: b.minX, y: 1 - b.maxY, width: b.width, height: b.height)))
        }
        guard pieces.filter({ $0.text.contains("=") }).count >= 2 else { return nil }
        // куски одной строки (Vision иногда режет уравнение на части) склеиваем
        var lines: [[Piece]] = []
        for p in pieces.sorted(by: { $0.box.midY < $1.box.midY }) {
            if let ref = lines.last?.first,
               abs(ref.box.midY - p.box.midY) < max(ref.box.height, p.box.height) * 0.5 {
                lines[lines.count - 1].append(p)
            } else {
                lines.append([p])
            }
        }
        var parsed: [(coeffs: [String: MNum], rhs: MNum)] = []
        var area = CGRect.null
        for line in lines {
            let text = line.sorted { $0.box.minX < $1.box.minX }.map(\.text).joined(separator: " ")
            guard let eq = equation(text) else { continue }
            parsed.append(eq)
            for p in line { area = area.union(p.box) }
        }
        guard parsed.count >= 2 else { return nil }
        let names = Set(parsed.flatMap { $0.coeffs.keys }).sorted { a, b in
            let la = a.prefix(1), lb = b.prefix(1)
            if la != lb { return la < lb }
            return (Int(a.dropFirst()) ?? 0) < (Int(b.dropFirst()) ?? 0)
        }
        guard !names.isEmpty, names.count <= 9 else { return nil }
        let rows = parsed.prefix(10).map { eq -> [MNum] in
            names.map { eq.coeffs[$0] ?? .zero } + [eq.rhs]
        }
        return Result(matrix: Matrix(rows), doubts: [], missing: [], bars: false, system: true,
                      area: area.isNull ? CGRect(x: 0, y: 0, width: 1, height: 1) : area)
    }

    /// Одно уравнение: коэффициенты при переменных и правая часть
    private static func equation(_ raw: String) -> (coeffs: [String: MNum], rhs: MNum)? {
        var s = raw.lowercased()
        let map: [String: String] = [
            "−": "-", "–": "-", "—": "-", "х": "x", "у": "y", ",": ".", " ": "", "·": "",
            "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4", "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9",
        ]
        for (k, v) in map where s.contains(k) { s = s.replacingOccurrences(of: k, with: v) }
        let sides = s.split(separator: "=", omittingEmptySubsequences: false)
        guard sides.count == 2 else { return nil }
        let right = String(sides[1]).trimmingCharacters(in: CharacterSet(charactersIn: ";.}])|"))
        let left = String(sides[0]).trimmingCharacters(in: CharacterSet(charactersIn: "{[(|"))
        guard !left.isEmpty, !right.isEmpty, let rhs = MNum.parse(right), let rx = termRegex else { return nil }
        let ns = left as NSString
        var coeffs: [String: MNum] = [:]
        var covered = 0
        for m in rx.matches(in: left, range: NSRange(location: 0, length: ns.length)) {
            // между членами не должно быть ничего лишнего
            guard m.range.location == covered else { return nil }
            covered = m.range.location + m.range.length
            let sign = ns.substring(with: m.range(at: 1))
            let numRange = m.range(at: 2)
            var k = numRange.location == NSNotFound ? MNum.one : (MNum.parse(ns.substring(with: numRange)) ?? .one)
            if sign == "-" { k = -k }
            let name = ns.substring(with: m.range(at: 3)) + ns.substring(with: m.range(at: 4))
            coeffs[name] = (coeffs[name] ?? .zero) + k
        }
        guard covered == ns.length, !coeffs.isEmpty else { return nil }
        return (coeffs, rhs)
    }
}

// MARK: - Экран

/// Что посчитать
private enum MatrixOp: String, CaseIterable, Identifiable {
    case det, inverse, inverseAdj, rank, solve, cramer, matrixMethod, eigen, rref, transpose, power, add, sub, mul

    var id: String { rawValue }

    var title: String {
        switch self {
        case .det: return L("Определитель")
        case .inverse: return L("Обратная (метод Гаусса)")
        case .inverseAdj: return L("Обратная через дополнения")
        case .rank: return L("Ранг")
        case .solve: return L("Система: метод Гаусса")
        case .cramer: return L("Система: метод Крамера")
        case .matrixMethod: return L("Система: матричный метод")
        case .eigen: return L("Собственные числа и векторы")
        case .rref: return L("Ступенчатый вид")
        case .transpose: return L("Транспонировать")
        case .power: return L("Степень Aⁿ")
        case .add: return "A + B"
        case .sub: return "A − B"
        case .mul: return "A · B"
        }
    }

    /// Нужна вторая матрица
    var needsB: Bool { self == .add || self == .sub || self == .mul }
    /// Последний столбец — правые части
    var isSystem: Bool { self == .solve || self == .cramer || self == .matrixMethod }
    /// Есть ли расписанное решение
    var hasSteps: Bool { !(self == .transpose || self == .power || self == .add || self == .sub) }
}

/// Сетка ввода: числа строками, как их набрали
private struct GridInput: Equatable {
    static let maxSize = 10
    var rows = 3
    var cols = 3
    var cells: [[String]] = Array(repeating: Array(repeating: "", count: 3), count: 3)

    func cell(_ i: Int, _ j: Int) -> String {
        cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : ""
    }

    mutating func set(_ i: Int, _ j: Int, _ v: String) {
        guard cells.indices.contains(i), cells[i].indices.contains(j) else { return }
        cells[i][j] = v
    }

    var matrix: Matrix? {
        var out: [[MNum]] = []
        for i in 0..<rows {
            var line: [MNum] = []
            for j in 0..<cols {
                guard let v = MNum.parse(cell(i, j)) else { return nil }
                line.append(v)
            }
            out.append(line)
        }
        return Matrix(out)
    }

    /// Размер поменяли — числа на своих местах остаются
    mutating func resize(clear: Bool = false) {
        let old = cells
        cells = (0..<rows).map { i -> [String] in
            (0..<cols).map { j -> String in
                !clear && old.indices.contains(i) && old[i].indices.contains(j) ? old[i][j] : ""
            }
        }
    }

    mutating func load(_ m: Matrix, empty: Set<Int> = []) {
        rows = min(max(m.rows, 1), Self.maxSize)
        cols = min(max(m.cols, 1), Self.maxSize)
        cells = (0..<rows).map { i -> [String] in
            (0..<cols).map { j -> String in
                guard i < m.rows, j < m.cols, !empty.contains(i * 100 + j) else { return "" }
                return m.a[i][j].text
            }
        }
    }
}

/// Ячейка под курсором: матрица A или B, строка, столбец
private struct CellID: Hashable {
    let b: Bool
    let i: Int
    let j: Int
}

private struct MatrixCropJob: Identifiable {
    let id = UUID()
    let image: UIImage
}

struct MatrixView: View {
    private enum Route: Identifiable {
        case web(URL)
        var id: String {
            switch self {
            case .web(let u): return u.absoluteString
            }
        }
    }

    @AppStorage("matrix.last") private var saved = ""
    @AppStorage("matrix.lastB") private var savedB = ""
    @AppStorage("matrix.op") private var op: MatrixOp = .det
    @State private var gridA = GridInput()
    @State private var gridB = GridInput()
    @State private var power = 2
    /// Ячейки A, где камера не уверена (ключ i·100 + j)
    @State private var doubts: Set<Int> = []
    @State private var restored = false
    @State private var route: Route?
    @State private var camera = false
    @State private var photo: PhotosPickerItem?
    @State private var crop: MatrixCropJob?
    @State private var busy = false
    @State private var busyText = ""
    @State private var note: String?
    /// Кусок снимка, с которого распознали, — чтобы сверить числа
    @State private var source: UIImage?
    @State private var showSource = false
    @FocusState private var focus: CellID?

    var body: some View {
        Form {
            scanSection
            gridSection(b: false)
            if op.needsB { gridSection(b: true) }
            computeSection
            wolframSection
        }
        .navigationTitle(L("Матрицы"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Button { moveFocus(-1) } label: { Image(systemName: "chevron.left") }
                    .disabled(focus == nil || focus == CellID(b: false, i: 0, j: 0))
                Button { moveFocus(1) } label: { Image(systemName: "chevron.right") }
                    .disabled(focus == nil)
                Button { toggleSign() } label: { Text("±").font(.title3.weight(.semibold)) }
                Spacer()
                Button(L("Готово")) { focus = nil }
            }
        }
        .onChange(of: gridA) { if let m = gridA.matrix { saved = m.wolfram } }
        .onChange(of: gridB) { if let m = gridB.matrix { savedB = m.wolfram } }
        .onChange(of: photo) {
            guard let item = photo else { return }
            let picked = Date()
            busy = true
            busyText = L("Открываю фото…")
            note = nil
            Task {
                let data = try? await item.loadTransferable(type: Data.self)
                let prepared = await Task.detached(priority: .userInitiated) {
                    data.flatMap { MatrixOCR.prepare(data: $0) }
                }.value
                await MainActor.run {
                    photo = nil
                    guard let prepared else {
                        busy = false
                        note = L("Не получилось открыть это фото")
                        return
                    }
                    showCrop(prepared, after: picked)
                }
            }
        }
        .onAppear(perform: restore)
        // камера на весь экран, как везде в приложении (в листе она обрезалась и иногда не закрывалась)
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { img in
                camera = false
                guard let img else { return }
                let closed = Date()
                busy = true
                busyText = L("Готовлю снимок…")
                note = nil
                Task.detached(priority: .userInitiated) {
                    let prepared = MatrixOCR.prepare(img)
                    await MainActor.run { showCrop(prepared, after: closed) }
                }
            }
            .ignoresSafeArea()
        }
        .fullScreenCover(item: $crop) { job in
            MatrixCropView(image: job.image) { rect in
                crop = nil
                guard let rect else { return }
                recognize(job.image, rect: rect)
            }
        }
        .sheet(item: $route) { r in
            switch r {
            case .web(let u):
                SafariView(url: u).ignoresSafeArea()
            }
        }
        .fullScreenCover(isPresented: $showSource) {
            if let source {
                MatrixPhotoView(image: source)
            }
        }
    }

    // MARK: разделы

    private var scanSection: some View {
        Section {
            HStack(spacing: 10) {
                Button { camera = true } label: {
                    Label(L("Сфоткать"), systemImage: "camera.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                PhotosPicker(selection: $photo, matching: .images) {
                    Label(L("Из фото"), systemImage: "photo").frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }
            .disabled(busy)
            if busy {
                HStack {
                    ProgressView()
                    Text(busyText).foregroundStyle(.secondary)
                }
            }
            if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
            if let source {
                Button { showSource = true } label: {
                    HStack(spacing: 12) {
                        Image(uiImage: source)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 56, height: 56)
                            .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(L("Сверить с фото")).font(.subheadline.weight(.semibold))
                            Text(L("Открыть снимок крупно")).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "arrow.up.left.and.arrow.down.right").foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(.plain)
            }
        } footer: {
            Text(L("Сними матрицу или систему крупно и ровно, потом обведи её рамкой — без номера задачи и текста вокруг. Числа распознаются на телефоне, фото никуда не отправляется. Оранжевые ячейки — проверь: в них камера не уверена."))
        }
    }

    private func gridSection(b: Bool) -> some View {
        let g = b ? gridB : gridA
        return Section {
            // размер сетки меняем сразу вместе с ячейками — иначе экран успевал обратиться к несуществующей строке
            Stepper(L("Строк: \(g.rows)"), value: Binding(get: { (b ? gridB : gridA).rows },
                                                       set: { v in update(b) { $0.rows = v; $0.resize() } }),
                    in: 1...GridInput.maxSize)
            Stepper(L("Столбцов: \(g.cols)"), value: Binding(get: { (b ? gridB : gridA).cols },
                                                          set: { v in update(b) { $0.cols = v; $0.resize() } }),
                    in: 1...GridInput.maxSize)
            grid(b: b)
                .listRowInsets(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
            HStack {
                Button(L("Очистить"), role: .destructive) {
                    update(b) { $0.resize(clear: true) }
                    if !b { doubts = [] }
                }
                Spacer()
                Button { UIPasteboard.general.string = g.matrix?.text; Haptics.success() } label: {
                    Label(L("Копировать"), systemImage: "doc.on.doc")
                }
                .disabled(g.matrix == nil)
                Spacer()
                Button { paste(b) } label: {
                    Label(L("Вставить"), systemImage: "doc.on.clipboard")
                }
            }
            .buttonStyle(.borderless)
            .font(.subheadline)
            if b {
                HStack {
                    Button("B = A") { gridB = gridA }
                    Spacer()
                    Button {
                        let t = gridA
                        gridA = gridB
                        gridB = t
                        doubts = []
                    } label: {
                        Label(L("Поменять A и B"), systemImage: "arrow.up.arrow.down")
                    }
                }
                .buttonStyle(.borderless)
                .font(.subheadline)
            }
        } header: {
            Text(b ? L("Матрица B") : L("Матрица A"))
        } footer: {
            if !b {
                Text(L("Можно писать 3, −2, 1,5 или 1/3. «Далее» на клавиатуре — к следующей ячейке, «±» меняет знак. Для системы последний столбец — правые части. «Вставить» понимает и запись {{1,2},{3,4}}."))
            }
        }
    }

    private func grid(b: Bool) -> some View {
        let g = b ? gridB : gridA
        let w: CGFloat = g.cols > 6 ? 46 : (g.cols > 4 ? 54 : 62)
        return ScrollView(.horizontal, showsIndicators: false) {
            VStack(spacing: 6) {
                ForEach(0..<g.rows, id: \.self) { i in
                    HStack(spacing: 6) {
                        ForEach(0..<g.cols, id: \.self) { j in
                            cellField(b: b, i: i, j: j, g: g, width: w)
                        }
                    }
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
        }
    }

    private func cellField(b: Bool, i: Int, j: Int, g: GridInput, width: CGFloat) -> some View {
        let id = CellID(b: b, i: i, j: j)
        let bad = MNum.parse(g.cell(i, j)) == nil
        let doubt = !b && doubts.contains(i * 100 + j)
        let last = i == g.rows - 1 && j == g.cols - 1 && (b || !op.needsB)
        let fill: Color = bad ? Color.red.opacity(0.18)
            : (doubt ? Color.orange.opacity(0.3) : (focus == id ? Color.brand.opacity(0.16) : Color.primary.opacity(0.06)))
        return TextField("0", text: Binding(get: { (b ? gridB : gridA).cell(i, j) },
                                            set: { v in
                                                update(b) { $0.set(i, j, v) }
                                                if !b, doubts.contains(i * 100 + j) { doubts.remove(i * 100 + j) }
                                            }))
            .keyboardType(.numbersAndPunctuation)
            .multilineTextAlignment(.center)
            .font(.system(.body, design: .monospaced))
            .submitLabel(last ? .done : .next)
            .onSubmit { moveFocus(1) }
            .focused($focus, equals: id)
            .frame(width: width, height: 42)
            .background(fill, in: RoundedRectangle(cornerRadius: 9, style: .continuous))
            .overlay(alignment: .trailing) {
                // черта перед правыми частями системы
                if !b && op.isSystem && j == g.cols - 2 && g.cols > 1 {
                    Rectangle().fill(Color.secondary.opacity(0.6)).frame(width: 1.5).offset(x: 4)
                }
            }
    }

    private var computeSection: some View {
        Section(L("Посчитать")) {
            Picker(L("Действие"), selection: $op) {
                ForEach(MatrixOp.allCases) { Text($0.title).tag($0) }
            }
            if op == .power {
                Stepper(L("Степень: \(power)"), value: $power, in: 0...20)
            }
            result
            if let input = stepsInput {
                NavigationLink {
                    MatrixStepsScreen(op: op, a: input.a, b: input.b)
                } label: {
                    Label(L("Решение по шагам"), systemImage: "list.number")
                        .font(.subheadline.weight(.semibold))
                }
            }
        }
    }

    private var wolframSection: some View {
        Section {
            Button { openWolfram(wolframQuery) } label: {
                Label(L("\(op.title) — в Wolfram|Alpha"), systemImage: "function")
            }
            Button { openWolfram(gridA.matrix?.wolfram ?? "") } label: {
                Label(L("Всё о матрице A"), systemImage: "square.grid.3x3")
            }
        } header: {
            Text("Wolfram|Alpha")
        } footer: {
            Text(L("Откроется сайт wolframalpha.com с этой матрицей — сверить ответ. Шаги там платные, а здесь бесплатно — в «Решении по шагам»."))
        }
        .disabled(gridA.matrix == nil)
    }

    // MARK: ответ

    @ViewBuilder private var result: some View {
        if let m = gridA.matrix {
            switch op {
            case .det:
                if let d = m.determinant { value("det A = \(d.text)", d.hint) }
                else { hint(L("Определитель есть только у квадратной матрицы")) }
            case .rank:
                value("rang A = \(m.reduced().rank)")
            case .inverse, .inverseAdj:
                if !m.isSquare { hint(L("Обратная есть только у квадратной матрицы")) }
                else if op == .inverseAdj && m.rows > 5 { hint(L("Через дополнения — до 5×5. Для больших матриц выбери «Обратная (метод Гаусса)»")) }
                else if let inv = m.inverse { matrixResult(inv, prefix: "A⁻¹ =", factor: true) }
                else { hint(L("Определитель равен 0 — обратной матрицы нет")) }
            case .solve:
                if m.cols < 2 { hint(L("Нужно хотя бы два столбца: коэффициенты и правые части")) }
                else { answerLines(MatrixSolver.system(m).answer) }
            case .cramer, .matrixMethod:
                if m.cols != m.rows + 1 {
                    hint(L("Здесь уравнений должно быть столько же, сколько неизвестных: матрица n×(n+1), последний столбец — правые части. Метод Гаусса решает любую систему"))
                } else {
                    answerLines(op == .cramer ? MatrixSolver.cramer(m).answer : MatrixSolver.matrixMethod(m).answer)
                }
            case .eigen:
                if !m.isSquare { hint(L("Собственные числа есть только у квадратной матрицы")) }
                else if m.rows > 4 { hint(L("Здесь — до 4×4. Для больших матриц — Wolfram|Alpha ниже")) }
                else { answerLines(MatrixEigen.solve(m).answer) }
            case .rref:
                matrixResult(m.reduced().m)
            case .transpose:
                matrixResult(m.transposed, prefix: "Aᵀ =")
            case .power:
                if let p = m.power(power) { matrixResult(p, prefix: "A\(MatrixFmt.sup(power)) =") }
                else { hint(L("Степень есть только у квадратной матрицы")) }
            case .add, .sub, .mul:
                if let b = gridB.matrix { twoResult(m, b) }
                else { hint(L("В красных ячейках B не число")) }
            }
        } else {
            hint(L("В красных ячейках не число. Можно писать 3, -2, 1,5 или 1/3"))
        }
    }

    @ViewBuilder private func twoResult(_ a: Matrix, _ b: Matrix) -> some View {
        switch op {
        case .add:
            if let s = a + b { matrixResult(s, prefix: "A + B =") }
            else { hint(L("Складывать можно только матрицы одного размера")) }
        case .sub:
            if let s = a - b { matrixResult(s, prefix: "A − B =") }
            else { hint(L("Вычитать можно только матрицы одного размера")) }
        default:
            if let s = a * b { matrixResult(s, prefix: "A·B =") }
            else { hint(L("Столбцов в A (\(a.cols)) должно быть столько же, сколько строк в B (\(b.rows))")) }
        }
    }

    /// Для чего есть решение по шагам и подходят ли данные
    private var stepsInput: (a: Matrix, b: Matrix?)? {
        guard op.hasSteps, let m = gridA.matrix else { return nil }
        let ok: Bool
        switch op {
        case .det, .inverse: ok = m.isSquare
        case .inverseAdj: ok = m.isSquare && m.rows <= 5
        case .eigen: ok = m.isSquare && m.rows <= 4
        case .solve: ok = m.cols >= 2
        case .cramer, .matrixMethod: ok = m.cols == m.rows + 1
        case .rank, .rref: ok = true
        case .mul:
            guard let b = gridB.matrix, m.cols == b.rows else { return nil }
            return (a: m, b: b)
        default: ok = false
        }
        guard ok else { return nil }
        return (a: m, b: nil)
    }

    private func value(_ s: String, _ extra: String = "") -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(s)
                .font(.system(.title3, design: .monospaced).weight(.bold))
                .textSelection(.enabled)
            if !extra.isEmpty {
                Text(extra.trimmingCharacters(in: .whitespaces))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func hint(_ s: String) -> some View {
        Text(s).font(.subheadline).foregroundStyle(.secondary)
    }

    private func answerLines(_ lines: [String]) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            ForEach(Array(lines.enumerated()), id: \.offset) { _, line in
                Text(line)
                    .font(.system(.body, design: .monospaced).weight(.semibold))
                    .textSelection(.enabled)
            }
        }
    }

    private func matrixResult(_ m: Matrix, prefix: String? = nil, factor: Bool = false) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                if let prefix {
                    Text(prefix).font(.system(.body, design: .monospaced).weight(.semibold))
                }
                MatrixGridView(m: m)
            }
            if factor, let f = m.factored {
                HStack(spacing: 8) {
                    Text("= 1/\(f.k) ·").font(.system(.body, design: .monospaced).weight(.semibold))
                    MatrixGridView(m: f.m)
                }
            }
            HStack {
                Button { UIPasteboard.general.string = m.text; Haptics.success() } label: {
                    Label(L("Копировать"), systemImage: "doc.on.doc")
                }
                Spacer()
                Button {
                    gridA.load(m)
                    doubts = []
                } label: {
                    Label(L("В матрицу A"), systemImage: "arrow.up.doc")
                }
            }
            .buttonStyle(.borderless)
            .font(.caption.weight(.semibold))
        }
    }

    // MARK: действия

    private func update(_ b: Bool, _ change: (inout GridInput) -> Void) {
        if b { change(&gridB) } else { change(&gridA) }
    }

    /// Окно рамки открываем, когда камера или галерея уже закрылись: два окна подряд iOS иногда теряет
    private func showCrop(_ image: UIImage, after closed: Date) {
        let wait = max(0, 0.65 - Date().timeIntervalSince(closed))
        DispatchQueue.main.asyncAfter(deadline: .now() + wait) {
            busy = false
            crop = MatrixCropJob(image: image)
        }
    }

    private func recognize(_ img: UIImage, rect: CGRect) {
        busy = true
        busyText = L("Распознаю числа…")
        note = nil
        Task.detached(priority: .userInitiated) {
            let piece = MatrixOCR.crop(img, to: rect)
            let found = MatrixOCR.recognize(piece)
            await MainActor.run {
                busy = false
                source = piece
                guard let found else {
                    note = L("Не нашёл чисел. Обведи матрицу плотнее или сфоткай ближе и ровнее — или введи вручную.")
                    return
                }
                gridA.load(found.matrix, empty: found.missing)
                doubts = found.doubts
                var text = found.system
                    ? L("Распознал систему: \(found.matrix.rows) уравн., \(max(found.matrix.cols - 1, 0)) неизв.")
                    : L("Распознал \(found.matrix.rows)×\(found.matrix.cols).")
                if found.system && !op.isSystem {
                    op = found.matrix.cols == found.matrix.rows + 1 ? .cramer : .solve
                } else if found.bars && found.matrix.isSquare && op != .det {
                    op = .det
                    text += L(" Похоже на определитель — выбрал его.")
                }
                text += found.doubts.isEmpty
                    ? L(" Сверь с фото и поправь, если что-то не так.")
                    : L(" Проверь оранжевые ячейки — в них камера не уверена.")
                note = text
                Haptics.success()
            }
        }
    }

    private func moveFocus(_ d: Int) {
        guard let f = focus else {
            focus = CellID(b: false, i: 0, j: 0)
            return
        }
        let g = f.b ? gridB : gridA
        let n = f.i * g.cols + f.j + d
        if n >= 0 && n < g.rows * g.cols {
            focus = CellID(b: f.b, i: n / g.cols, j: n % g.cols)
        } else if !f.b && n >= g.rows * g.cols && op.needsB {
            focus = CellID(b: true, i: 0, j: 0)
        } else if f.b && n < 0 {
            focus = CellID(b: false, i: gridA.rows - 1, j: gridA.cols - 1)
        } else {
            focus = nil
        }
    }

    /// «±» — поменять знак в текущей ячейке (на цифровой клавиатуре минус искать неудобно)
    private func toggleSign() {
        guard let f = focus else { return }
        update(f.b) { g in
            var t = g.cell(f.i, f.j).trimmingCharacters(in: .whitespaces)
            if t.hasPrefix("-") || t.hasPrefix("−") { t.removeFirst() } else { t = "-" + t }
            g.set(f.i, f.j, t)
        }
        Haptics.tap()
    }

    /// Матрица из буфера: столбики через пробел или «;», строки — с новой строки, или {{1,2},{3,4}}
    private func paste(_ b: Bool) {
        guard let text = UIPasteboard.general.string, let m = Matrix.parse(text: text) else {
            note = L("В буфере обмена нет чисел матрицы")
            return
        }
        update(b) { $0.load(m) }
        if !b { doubts = [] }
        Haptics.success()
    }

    /// Последние матрицы возвращаются один раз — при открытии экрана, а не после каждого возврата с шагов
    private func restore() {
        guard !restored else { return }
        restored = true
        if let m = Matrix.parse(text: saved) { gridA.load(m) }
        if let m = Matrix.parse(text: savedB) { gridB.load(m) }
    }

    private var wolframQuery: String {
        guard let a = gridA.matrix?.wolfram else { return "" }
        let b = gridB.matrix?.wolfram ?? ""
        switch op {
        case .det: return "determinant " + a
        case .inverse, .inverseAdj: return "inverse " + a
        case .rank: return "rank " + a
        case .solve, .cramer, .matrixMethod, .rref: return "row reduce " + a
        case .eigen: return "eigenvalues " + a
        case .transpose: return "transpose " + a
        case .power: return "MatrixPower[\(a), \(power)]"
        case .add: return b.isEmpty ? a : "\(a) + \(b)"
        case .sub: return b.isEmpty ? a : "\(a) - \(b)"
        case .mul: return b.isEmpty ? a : "\(a) . \(b)"
        }
    }

    private func openWolfram(_ q: String) {
        guard !q.isEmpty, var comp = URLComponents(string: "https://www.wolframalpha.com/input") else { return }
        comp.queryItems = [URLQueryItem(name: "i", value: q)]
        // «+» в запросе нужно экранировать явно
        comp.percentEncodedQuery = comp.percentEncodedQuery?
            .replacingOccurrences(of: "+", with: "%2B")
        if let u = comp.url { route = .web(u) }
    }
}

/// Шаги считаются только когда их открыли, а не на каждую набранную цифру
private struct MatrixStepsScreen: View {
    let op: MatrixOp
    let a: Matrix
    let b: Matrix?

    var body: some View {
        MatrixStepsView(title: op.title, steps: steps)
    }

    private var steps: [MatrixStep] {
        switch op {
        case .det: return MatrixSolver.determinant(a)
        case .inverse: return MatrixSolver.inverse(a)
        case .inverseAdj: return MatrixSolver.inverseAdjugate(a)
        case .rank, .rref: return MatrixSolver.rank(a)
        case .solve: return MatrixSolver.system(a).steps
        case .cramer: return MatrixSolver.cramer(a).steps
        case .matrixMethod: return MatrixSolver.matrixMethod(a).steps
        case .eigen: return MatrixEigen.solve(a).steps
        case .mul: return b.map { MatrixSolver.product(a, $0) } ?? []
        case .transpose, .power, .add, .sub: return []
        }
    }
}

/// Матрица числами в скобках; `bar` — черта перед правой частью
struct MatrixGridView: View {
    let m: Matrix
    var bar: Int? = nil

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                bracket(left: true)
                Grid(horizontalSpacing: 14, verticalSpacing: 6) {
                    ForEach(0..<m.rows, id: \.self) { i in
                        GridRow {
                            ForEach(0..<m.cols, id: \.self) { j in
                                Text(m.a[i][j].text)
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .gridColumnAlignment(.trailing)
                                    .overlay(alignment: .leading) {
                                        if let bar, j == bar {
                                            Rectangle().fill(Color.secondary.opacity(0.7)).frame(width: 1.2).offset(x: -8)
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.vertical, 4)
                bracket(left: false)
            }
            .padding(.vertical, 2)
        }
    }

    private func bracket(left: Bool) -> some View {
        Rectangle()
            .fill(Color.primary.opacity(0.7))
            .frame(width: 1.5)
            .overlay(alignment: .top) { Rectangle().fill(Color.primary.opacity(0.7)).frame(width: 6, height: 1.5).offset(x: left ? 2.25 : -2.25) }
            .overlay(alignment: .bottom) { Rectangle().fill(Color.primary.opacity(0.7)).frame(width: 6, height: 1.5).offset(x: left ? 2.25 : -2.25) }
    }
}

/// Решение по шагам — как в тетради
struct MatrixStepsView: View {
    let title: String
    let steps: [MatrixStep]

    var body: some View {
        List {
            ForEach(Array(steps.enumerated()), id: \.offset) { i, s in
                Section {
                    ForEach(Array(s.lines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(.subheadline, design: .monospaced))
                            .textSelection(.enabled)
                    }
                    if let m = s.matrix {
                        MatrixGridView(m: m, bar: s.bar)
                    }
                } header: {
                    Text("\(i + 1). \(s.title)")
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                ShareLink(item: plainText) { Image(systemName: "square.and.arrow.up") }
            }
        }
    }

    /// Всё решение текстом — отправить в чат или вставить в отчёт
    private var plainText: String {
        var out = [title]
        for (i, s) in steps.enumerated() {
            out.append("")
            out.append("\(i + 1). \(s.title)")
            out += s.lines
            if let m = s.matrix { out.append(m.pretty) }
        }
        return out.joined(separator: "\n")
    }
}

/// Рамка вокруг матрицы на снимке: распознаётся только то, что внутри. Сама встаёт на найденную матрицу
private struct MatrixCropView: View {
    let image: UIImage
    let onDone: (CGRect?) -> Void
    @State private var rect = CGRect(x: 0.05, y: 0.1, width: 0.9, height: 0.8)
    @State private var start: CGRect?
    @State private var touched = false
    @State private var hint = L("Ищу матрицу на фото…")

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                Text(hint)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                GeometryReader { geo in
                    let fit = Self.fit(image.size, in: geo.size)
                    let sel = CGRect(x: fit.minX + rect.minX * fit.width, y: fit.minY + rect.minY * fit.height,
                                     width: rect.width * fit.width, height: rect.height * fit.height)
                    ZStack {
                        Image(uiImage: image)
                            .resizable()
                            .frame(width: fit.width, height: fit.height)
                            .position(x: fit.midX, y: fit.midY)
                            .allowsHitTesting(false)
                        Path { p in
                            p.addRect(fit)
                            p.addRect(sel)
                        }
                        .fill(Color.black.opacity(0.55), style: FillStyle(eoFill: true))
                        .allowsHitTesting(false)
                        Rectangle()
                            .strokeBorder(Color.white, lineWidth: 2)
                            .frame(width: max(sel.width, 1), height: max(sel.height, 1))
                            .contentShape(Rectangle())
                            .gesture(drag(fit: fit, corner: nil))
                            .position(x: sel.midX, y: sel.midY)
                        ForEach(0..<4, id: \.self) { c in
                            Circle()
                                .fill(Color.white)
                                .frame(width: 22, height: 22)
                                .shadow(color: .black.opacity(0.4), radius: 3)
                                .frame(width: 48, height: 48)
                                .contentShape(Rectangle())
                                .gesture(drag(fit: fit, corner: c))
                                .position(x: c % 2 == 0 ? sel.minX : sel.maxX, y: c < 2 ? sel.minY : sel.maxY)
                        }
                    }
                }
                .padding(.horizontal, 12)
                HStack(spacing: 10) {
                    Button(L("Отмена")) { onDone(nil) }
                        .buttonStyle(.bordered)
                        .tint(.white)
                    Button(L("Всё фото")) {
                        touched = true
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) {
                            rect = CGRect(x: 0, y: 0, width: 1, height: 1)
                        }
                    }
                    .buttonStyle(.bordered)
                    .tint(.white)
                    Button { onDone(rect) } label: {
                        Label(L("Распознать"), systemImage: "text.viewfinder").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 10)
            }
        }
        .task { await detect() }
    }

    static func fit(_ img: CGSize, in box: CGSize) -> CGRect {
        guard img.width > 0, img.height > 0, box.width > 0, box.height > 0 else { return .zero }
        let k = min(box.width / img.width, box.height / img.height)
        let w = img.width * k, h = img.height * k
        return CGRect(x: (box.width - w) / 2, y: (box.height - h) / 2, width: w, height: h)
    }

    /// corner: nil — двигаем рамку целиком; 0…3 — тянем угол (левый верхний, правый верхний, левый нижний, правый нижний)
    private func drag(fit: CGRect, corner: Int?) -> some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                guard fit.width > 0, fit.height > 0 else { return }
                touched = true
                let s = start ?? rect
                if start == nil { start = rect }
                let dx = v.translation.width / fit.width, dy = v.translation.height / fit.height
                guard let corner else {
                    rect = CGRect(x: min(max(s.minX + dx, 0), 1 - s.width), y: min(max(s.minY + dy, 0), 1 - s.height),
                                  width: s.width, height: s.height)
                    return
                }
                let m: CGFloat = 0.06
                var x0 = s.minX, y0 = s.minY, x1 = s.maxX, y1 = s.maxY
                if corner % 2 == 0 { x0 = min(max(0, s.minX + dx), x1 - m) } else { x1 = max(min(1, s.maxX + dx), x0 + m) }
                if corner < 2 { y0 = min(max(0, s.minY + dy), y1 - m) } else { y1 = max(min(1, s.maxY + dy), y0 + m) }
                rect = CGRect(x: x0, y: y0, width: x1 - x0, height: y1 - y0)
            }
            .onEnded { _ in start = nil }
    }

    /// Пока человек смотрит на снимок, ищем на нём матрицу и ставим рамку на неё
    private func detect() async {
        let img = image
        let found = await Task.detached(priority: .userInitiated) { MatrixOCR.recognize(img) }.value
        guard !touched else { return }
        guard let f = found else {
            hint = L("Обведи рамкой только саму матрицу — без номера задачи и текста вокруг")
            return
        }
        let r = f.area.insetBy(dx: -0.04, dy: -0.04)
        let x0 = max(0, r.minX), y0 = max(0, r.minY), x1 = min(1, r.maxX), y1 = min(1, r.maxY)
        if x1 - x0 > 0.06, y1 - y0 > 0.06 {
            withAnimation(.spring(response: 0.39, dampingFraction: 0.85)) {
                rect = CGRect(x: x0, y: y0, width: x1 - x0, height: y1 - y0)
            }
        }
        hint = f.system
            ? L("Нашёл систему из \(f.matrix.rows) уравнений. Поправь рамку, если надо, и жми «Распознать»")
            : L("Нашёл матрицу \(f.matrix.rows)×\(f.matrix.cols). Поправь рамку, если захватило лишнее, и жми «Распознать»")
    }
}

/// Снимок крупно: щипком приблизить, пальцем двигать, двойной тап — крупнее, смахнуть вниз — закрыть
private struct MatrixPhotoView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var last: CGSize = .zero

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .scaleEffect(scale)
                .offset(offset)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(
                    SimultaneousGesture(
                        MagnificationGesture()
                            .onChanged { scale = max(1, min(6, base * $0)) }
                            .onEnded { _ in
                                base = scale
                                if scale <= 1 {
                                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { offset = .zero }
                                    last = .zero
                                }
                            },
                        DragGesture()
                            .onChanged { v in
                                offset = CGSize(width: last.width + v.translation.width, height: last.height + v.translation.height)
                            }
                            .onEnded { v in
                                if scale <= 1 {
                                    if v.translation.height > 120 { dismiss() }
                                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { offset = .zero }
                                    last = .zero
                                } else {
                                    last = offset
                                }
                            }
                    )
                )
                .onTapGesture(count: 2) {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                        if scale > 1 {
                            scale = 1
                            offset = .zero
                        } else {
                            scale = 2.5
                        }
                        base = scale
                        last = offset
                    }
                }
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .padding(16)
        }
    }
}
