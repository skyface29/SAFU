import SwiftUI
import UIKit
import Vision
import PhotosUI

// MARK: - Матрицы по фото
// Сфоткал матрицу из задачника или с доски → числа распознаются прямо на телефоне (Vision, без интернета)
// → проверяешь, правишь → определитель, обратная, ранг, система уравнений считаются сразу
// и расписываются по шагам, как в тетради. «Решение в Wolfram|Alpha» открывает сайт с этой же матрицей.

struct Matrix: Equatable {
    var rows: Int
    var cols: Int
    var a: [[Double]]

    init(rows: Int, cols: Int, fill: Double = 0) {
        self.rows = rows
        self.cols = cols
        a = Array(repeating: Array(repeating: fill, count: cols), count: rows)
    }

    init(_ a: [[Double]]) {
        self.a = a
        rows = a.count
        cols = a.first?.count ?? 0
    }

    var isSquare: Bool { rows == cols }

    var transposed: Matrix {
        var m = Matrix(rows: cols, cols: rows)
        for i in 0..<rows { for j in 0..<cols { m.a[j][i] = a[i][j] } }
        return m
    }

    static func * (l: Matrix, r: Matrix) -> Matrix? {
        guard l.cols == r.rows else { return nil }
        var m = Matrix(rows: l.rows, cols: r.cols)
        for i in 0..<l.rows { for j in 0..<r.cols {
            var s = 0.0
            for k in 0..<l.cols { s += l.a[i][k] * r.a[k][j] }
            m.a[i][j] = s
        } }
        return m
    }

    /// Ступенчатый вид (метод Гаусса — Жордана): матрица, ранг и определитель (для квадратной)
    func reduced() -> (m: Matrix, rank: Int, det: Double) {
        var m = self
        var det = 1.0
        var r = 0
        let eps = 1e-10
        for c in 0..<cols where r < rows {
            // строка с самым большим по модулю элементом — меньше ошибок округления
            var p = r
            for i in r..<rows where abs(m.a[i][c]) > abs(m.a[p][c]) { p = i }
            guard abs(m.a[p][c]) > eps else { det = 0; continue }
            if p != r { m.a.swapAt(p, r); det = -det }
            let pv = m.a[r][c]
            det *= pv
            for j in 0..<cols { m.a[r][j] /= pv }
            for i in 0..<rows where i != r {
                let f = m.a[i][c]
                if f != 0 { for j in 0..<cols { m.a[i][j] -= f * m.a[r][j] } }
            }
            r += 1
        }
        if r < min(rows, cols) || !isSquare { det = isSquare ? 0 : .nan }
        for i in 0..<rows { for j in 0..<cols where abs(m.a[i][j]) < eps { m.a[i][j] = 0 } }
        return (m, r, det)
    }

    var inverse: Matrix? {
        guard isSquare else { return nil }
        var aug = Matrix(rows: rows, cols: cols * 2)
        for i in 0..<rows {
            for j in 0..<cols { aug.a[i][j] = a[i][j] }
            aug.a[i][cols + i] = 1
        }
        let r = aug.reduced()
        for i in 0..<rows where abs(r.m.a[i][i] - 1) > 1e-8 { return nil }
        return Matrix(r.m.a.map { Array($0[cols...]) })
    }

    /// Запись для Wolfram|Alpha: {{1,2},{3,4}}
    var wolfram: String {
        "{" + a.map { "{" + $0.map { MatrixFmt.nice($0) }.joined(separator: ",") + "}" }.joined(separator: ",") + "}"
    }

    var text: String {
        a.map { $0.map { MatrixFmt.nice($0) }.joined(separator: "\t") }.joined(separator: "\n")
    }
}

enum MatrixFmt {
    /// Красиво: целые — целыми, «почти дроби» — дробью (0.3333… → 1/3)
    static func nice(_ x: Double) -> String {
        guard x.isFinite else { return "—" }
        if abs(x - x.rounded()) < 1e-9 { return minus(String(Int(x.rounded()))) }
        for d in 2...1000 {
            let n = x * Double(d)
            if abs(n - n.rounded()) < 1e-7 * Double(d) { return minus("\(Int(n.rounded()))/\(d)") }
        }
        return minus(plain(x))
    }

    /// Настоящий знак минус «−» вместо дефиса — как в учебнике
    private static func minus(_ s: String) -> String {
        s.hasPrefix("-") ? "−" + s.dropFirst() : s
    }

    /// Число в скобках, если оно отрицательное: «(−2)»
    static func paren(_ x: Double) -> String {
        let s = nice(x)
        return x < 0 ? "(\(s))" : s
    }

    static func plain(_ x: Double) -> String {
        guard x.isFinite else { return "0" }
        if abs(x - x.rounded()) < 1e-9 { return String(Int(x.rounded())) }
        var s = String(format: "%.6f", x)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s
    }

    /// Разбор ввода: «-3», «2,5», «1/3», «−7», «+4»
    static func parse(_ s: String) -> Double? {
        var t = s.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: "−", with: "-")
            .replacingOccurrences(of: "–", with: "-")
            .replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: ",", with: ".")
            .replacingOccurrences(of: " ", with: "")
        if t.hasPrefix("+") { t.removeFirst() }
        if t.isEmpty || t == "-" { return t.isEmpty ? 0 : nil }
        if let i = t.firstIndex(of: "/") {
            guard let n = Double(t[..<i]), let d = Double(t[t.index(after: i)...]), d != 0 else { return nil }
            return n / d
        }
        return Double(t)
    }
}

// MARK: - Решение по шагам

/// Один шаг решения: что сделали и что получилось
struct MatrixStep: Identifiable {
    let id = UUID()
    let title: String
    var lines: [String] = []
    var matrix: Matrix? = nil
    /// Столбец, перед которым черта (расширенная матрица)
    var bar: Int? = nil
}

/// Расписывает решение, как его пишут в тетради: перестановки строк, вычитание строк, деление на ведущий элемент
enum MatrixSolver {
    private static let eps = 1e-9

    /// Ведущий элемент столбца: лучше ±1 (так проще считать руками), иначе первый ненулевой
    private static func pivotRow(_ m: Matrix, col c: Int, from r: Int) -> Int? {
        guard r < m.rows else { return nil }
        var first: Int?
        for i in r..<m.rows where abs(m.a[i][c]) > eps {
            if abs(abs(m.a[i][c]) - 1) < eps { return i }
            if first == nil { first = i }
        }
        return first
    }

    private static func clean(_ m: inout Matrix) {
        for i in 0..<m.rows { for j in 0..<m.cols where abs(m.a[i][j]) < 1e-10 { m.a[i][j] = 0 } }
    }

    /// «Стр. 2 − 3·стр. 1» (вычитаем f раз строку src)
    private static func rowOp(_ dst: Int, _ f: Double, _ src: Int) -> String {
        let k = abs(f)
        let coef = abs(k - 1) < eps ? "" : MatrixFmt.nice(k) + "·"
        return "стр. \(dst + 1) \(f > 0 ? "−" : "+") \(coef)стр. \(src + 1)"
    }

    private static func subtract(_ m: inout Matrix, row i: Int, _ f: Double, pivotRow r: Int) {
        for j in 0..<m.cols { m.a[i][j] -= f * m.a[r][j] }
    }

    /// Определитель: приводим к треугольному виду, потом перемножаем диагональ
    static func determinant(_ m0: Matrix) -> [MatrixStep] {
        var m = m0
        let n = m.rows
        var steps = [MatrixStep(title: "Исходная матрица", matrix: m)]
        if n == 2 {
            let a = m.a
            let d = a[0][0] * a[1][1] - a[0][1] * a[1][0]
            steps.append(MatrixStep(title: "Формула для 2×2", lines: [
                "det A = a₁₁·a₂₂ − a₁₂·a₂₁",
                "= \(MatrixFmt.paren(a[0][0]))·\(MatrixFmt.paren(a[1][1])) − \(MatrixFmt.paren(a[0][1]))·\(MatrixFmt.paren(a[1][0]))",
                "= \(MatrixFmt.nice(d))"]))
            return steps
        }
        if n == 3 {
            let a = m.a
            func p(_ x: Double) -> String { MatrixFmt.paren(x) }
            let plus = [a[0][0] * a[1][1] * a[2][2], a[0][1] * a[1][2] * a[2][0], a[0][2] * a[1][0] * a[2][1]]
            let minus = [a[0][2] * a[1][1] * a[2][0], a[0][0] * a[1][2] * a[2][1], a[0][1] * a[1][0] * a[2][2]]
            let d = plus.reduce(0, +) - minus.reduce(0, +)
            steps.append(MatrixStep(title: "Правило треугольников (Саррюса)", lines: [
                "det A = a₁₁a₂₂a₃₃ + a₁₂a₂₃a₃₁ + a₁₃a₂₁a₃₂ − a₁₃a₂₂a₃₁ − a₁₁a₂₃a₃₂ − a₁₂a₂₁a₃₃",
                "= \(p(a[0][0]))·\(p(a[1][1]))·\(p(a[2][2])) + \(p(a[0][1]))·\(p(a[1][2]))·\(p(a[2][0])) + \(p(a[0][2]))·\(p(a[1][0]))·\(p(a[2][1]))",
                "  − \(p(a[0][2]))·\(p(a[1][1]))·\(p(a[2][0])) − \(p(a[0][0]))·\(p(a[1][2]))·\(p(a[2][1])) − \(p(a[0][1]))·\(p(a[1][0]))·\(p(a[2][2]))",
                "= \(MatrixFmt.nice(plus[0])) + \(MatrixFmt.paren(plus[1])) + \(MatrixFmt.paren(plus[2])) − \(MatrixFmt.paren(minus[0])) − \(MatrixFmt.paren(minus[1])) − \(MatrixFmt.paren(minus[2]))",
                "= \(MatrixFmt.nice(d))"]))
            steps.append(MatrixStep(title: "Проверка методом Гаусса"))
        }
        var sign = 1.0
        for c in 0..<n {
            guard let p = pivotRow(m, col: c, from: c) else {
                steps.append(MatrixStep(title: "Столбец \(c + 1)",
                                        lines: ["На диагонали и ниже — одни нули, значит det A = 0"]))
                return steps
            }
            var lines: [String] = []
            if p != c {
                m.a.swapAt(p, c)
                sign = -sign
                lines.append("Меняем местами строки \(c + 1) и \(p + 1) — знак определителя меняется")
            }
            for i in (c + 1)..<n where abs(m.a[i][c]) > eps {
                let f = m.a[i][c] / m.a[c][c]
                subtract(&m, row: i, f, pivotRow: c)
                m.a[i][c] = 0
                lines.append("стр. \(i + 1) → " + rowOp(i, f, c))
            }
            clean(&m)
            if !lines.isEmpty {
                steps.append(MatrixStep(title: "Нули под диагональю в столбце \(c + 1)", lines: lines, matrix: m))
            }
        }
        var d = sign
        var factors: [String] = []
        for i in 0..<n {
            d *= m.a[i][i]
            factors.append(MatrixFmt.paren(m.a[i][i]))
        }
        steps.append(MatrixStep(title: "Матрица треугольная", lines: [
            "Определитель — произведение чисел на диагонали" + (sign < 0 ? ", со знаком «−»: строки менялись нечётное число раз" : ""),
            "det A = \(sign < 0 ? "−" : "")\(factors.joined(separator: " · ")) = \(MatrixFmt.nice(d))"]))
        return steps
    }

    /// Метод Гаусса — Жордана: в каждом столбце ведущая единица, над и под ней нули
    static func gaussJordan(_ m0: Matrix, columns: Int, bar: Int?, steps: inout [MatrixStep]) -> (m: Matrix, pivots: [Int]) {
        var m = m0
        var r = 0
        var pivots: [Int] = []
        for c in 0..<min(columns, m.cols) where r < m.rows {
            guard let p = pivotRow(m, col: c, from: r) else { continue }
            var lines: [String] = []
            if p != r {
                m.a.swapAt(p, r)
                lines.append("Меняем местами строки \(r + 1) и \(p + 1)")
            }
            let pv = m.a[r][c]
            if abs(pv - 1) > eps {
                for j in 0..<m.cols { m.a[r][j] /= pv }
                lines.append(abs(pv + 1) < eps ? "стр. \(r + 1) · (−1)" : "стр. \(r + 1) : \(MatrixFmt.paren(pv))")
            }
            for i in 0..<m.rows where i != r && abs(m.a[i][c]) > eps {
                let f = m.a[i][c]
                subtract(&m, row: i, f, pivotRow: r)
                m.a[i][c] = 0
                lines.append("стр. \(i + 1) → " + rowOp(i, f, r))
            }
            clean(&m)
            pivots.append(c)
            if !lines.isEmpty {
                steps.append(MatrixStep(title: "Столбец \(c + 1): ведущий элемент в строке \(r + 1)",
                                        lines: lines, matrix: m, bar: bar))
            }
            r += 1
        }
        return (m, pivots)
    }

    /// Обратная матрица: [A | E] → [E | A⁻¹]
    static func inverse(_ a: Matrix) -> [MatrixStep] {
        let n = a.rows
        var aug = Matrix(rows: n, cols: 2 * n)
        for i in 0..<n {
            for j in 0..<n { aug.a[i][j] = a.a[i][j] }
            aug.a[i][n + i] = 1
        }
        var steps = [MatrixStep(title: "Приписываем справа единичную матрицу: [A | E]", matrix: aug, bar: n)]
        let res = gaussJordan(aug, columns: n, bar: n, steps: &steps)
        if res.pivots.count < n {
            steps.append(MatrixStep(title: "Слева не получилась единичная матрица",
                                    lines: ["Ранг меньше \(n): det A = 0, обратной матрицы нет"]))
        } else {
            let inv = Matrix(res.m.a.map { Array($0[n...]) })
            steps.append(MatrixStep(title: "Слева — E, справа — обратная матрица", lines: ["A⁻¹ ="], matrix: inv))
        }
        return steps
    }

    /// Ранг: сколько ненулевых строк осталось в ступенчатом виде
    static func rank(_ a: Matrix) -> [MatrixStep] {
        var steps = [MatrixStep(title: "Исходная матрица", matrix: a)]
        let res = gaussJordan(a, columns: a.cols, bar: nil, steps: &steps)
        steps.append(MatrixStep(title: "Ступенчатый вид",
                                lines: ["Ненулевых строк: \(res.pivots.count)", "rang A = \(res.pivots.count)"]))
        return steps
    }

    /// Система уравнений: последний столбец — правые части
    static func system(_ a: Matrix) -> (steps: [MatrixStep], answer: [String]) {
        let vars = a.cols - 1
        var steps = [MatrixStep(title: "Расширенная матрица системы (A | b)", matrix: a, bar: vars)]
        let res = gaussJordan(a, columns: vars, bar: vars, steps: &steps)
        let m = res.m
        // строка «0 = b» с b ≠ 0 — противоречие
        for i in 0..<m.rows {
            let zeros = (0..<vars).allSatisfy { abs(m.a[i][$0]) < 1e-9 }
            if zeros && abs(m.a[i][vars]) > 1e-9 {
                let answer = ["Строка \(i + 1): 0 = \(MatrixFmt.nice(m.a[i][vars])) — противоречие",
                              "Система несовместна: решений нет"]
                steps.append(MatrixStep(title: "Ответ", lines: answer))
                return (steps, answer)
            }
        }
        var answer: [String] = []
        let free = (0..<vars).filter { !res.pivots.contains($0) }
        for (row, c) in res.pivots.enumerated() {
            var s = "x\(sub(c + 1)) = \(MatrixFmt.nice(m.a[row][vars]))"
            for f in free where abs(m.a[row][f]) > 1e-9 {
                let k = -m.a[row][f]
                let coef = abs(abs(k) - 1) < 1e-9 ? "" : MatrixFmt.nice(abs(k)) + "·"
                s += " \(k > 0 ? "+" : "−") \(coef)x\(sub(f + 1))"
            }
            if s.hasSuffix("= 0 ") { s.removeLast() }
            answer.append(s)
        }
        if free.isEmpty {
            answer.append("Решение единственное")
        } else {
            answer.append(free.map { "x\(sub($0 + 1))" }.joined(separator: ", ")
                          + " — свободные (любые числа): решений бесконечно много")
        }
        steps.append(MatrixStep(title: "Ответ", lines: answer))
        return (steps, answer)
    }

    /// x₁, x₂… — индексы мелкими цифрами
    static func sub(_ n: Int) -> String {
        let digits = ["₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"]
        return String(n).compactMap { $0.wholeNumberValue.map { digits[$0] } }.joined()
    }
}

// MARK: - Распознавание матрицы на фото

enum MatrixOCR {
    private struct Token { let value: Double; let x: Double; let y: Double; let h: Double }

    private static let numberRegex = try? NSRegularExpression(pattern: #"[-−–—]?\s?\d+(?:[.,]\d+)?(?:/\d+)?"#)

    /// Частые ошибки распознавания внутри чисел: «О» вместо нуля, «l» и «I» вместо единицы, «S» вместо пятёрки
    private static func fixDigits(_ s: String) -> String {
        s.split(separator: " ", omittingEmptySubsequences: false).map { w -> String in
            let word = String(w)
            let hasDigit = word.contains { $0.isNumber }
            let onlyO = !word.isEmpty && word.allSatisfy { "OoОо".contains($0) }
            guard hasDigit || onlyO else { return word }
            var out = ""
            for ch in word {
                switch ch {
                case "O", "o", "О", "о", "Q", "D": out.append("0")
                case "l", "I", "|", "!": out.append(hasDigit ? "1" : String(ch))
                case "S", "s": out.append(hasDigit ? "5" : String(ch))
                case "B": out.append(hasDigit ? "8" : String(ch))
                case "Z", "z": out.append(hasDigit ? "2" : String(ch))
                default: out.append(ch)
                }
            }
            return out
        }.joined(separator: " ")
    }

    static func recognize(_ image: UIImage) -> Matrix? {
        guard let cg = image.cgImage, let pattern = numberRegex else { return nil }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["en-US"]
        req.usesLanguageCorrection = false   // иначе «1O» превращается в слово
        req.minimumTextHeight = 0.012
        let handler = VNImageRequestHandler(cgImage: cg, orientation: orientation(image), options: [:])
        try? handler.perform([req])

        var tokens: [Token] = []
        for obs in req.results ?? [] {
            guard let cand = obs.topCandidates(1).first else { continue }
            let raw = cand.string
            let s = fixDigits(raw)
            let ns = s as NSString
            for m in pattern.matches(in: s, range: NSRange(location: 0, length: ns.length)) {
                let num = ns.substring(with: m.range).replacingOccurrences(of: " ", with: "")
                guard let v = MatrixFmt.parse(num) else { continue }
                // рамку берём по исходной строке (длина та же: заменялись отдельные символы)
                var box = obs.boundingBox
                if raw.count == s.count, let r = Range(m.range, in: raw), let b = try? cand.boundingBox(for: r) {
                    box = b.boundingBox
                }
                tokens.append(Token(value: v, x: box.midX, y: box.midY, h: max(box.height, 0.005)))
            }
        }
        guard !tokens.isEmpty else { return nil }

        // скобки и черты определителя часто читаются как высокая «1» — отбрасываем всё, что намного выше чисел
        let hs = tokens.map(\.h).sorted()
        let medianH = hs[hs.count / 2]
        tokens = tokens.filter { $0.h < medianH * 2.2 }
        guard !tokens.isEmpty else { return nil }

        // строки: близкие по высоте числа (в Vision y растёт снизу вверх); сравниваем со средним по строке
        let gap = medianH * 0.65
        var rows: [[Token]] = []
        for t in tokens.sorted(by: { $0.y > $1.y }) {
            if let last = rows.last {
                let y0 = last.map(\.y).reduce(0, +) / Double(last.count)
                if abs(y0 - t.y) < gap {
                    rows[rows.count - 1].append(t)
                    continue
                }
            }
            rows.append([t])
        }
        rows = rows.map { $0.sorted { $0.x < $1.x } }

        // сколько столбцов: самое частое число чисел в строке
        let counts = Dictionary(grouping: rows.map(\.count), by: { $0 }).mapValues(\.count)
        guard let n = counts.max(by: { $0.value == $1.value ? $0.key < $1.key : $0.value < $1.value })?.key else { return nil }
        // случайные надписи (номер задачи, «A =») отбрасываем
        rows = rows.filter { $0.count * 2 >= n && $0.count <= n + 1 }
        guard !rows.isEmpty, n > 0 else { return nil }

        // центры столбцов — по «полным» строкам; числа неполных строк ставим в ближайший столбец
        let full = rows.filter { $0.count == n }
        let centers = (0..<n).map { j in full.map { $0[j].x }.reduce(0, +) / Double(max(full.count, 1)) }
        var result: [[Double]] = []
        for row in rows.prefix(10) {
            if row.count == n { result.append(row.map(\.value)); continue }
            var line = Array(repeating: 0.0, count: n)
            for t in row.prefix(n) {
                let j = centers.indices.min { abs(centers[$0] - t.x) < abs(centers[$1] - t.x) } ?? 0
                line[j] = t.value
            }
            result.append(line)
        }
        let m = Matrix(result.map { Array($0.prefix(10)) })
        return m.rows > 0 && m.cols > 0 ? m : nil
    }

    private static func orientation(_ img: UIImage) -> CGImagePropertyOrientation {
        switch img.imageOrientation {
        case .up: return .up
        case .down: return .down
        case .left: return .left
        case .right: return .right
        case .upMirrored: return .upMirrored
        case .downMirrored: return .downMirrored
        case .leftMirrored: return .leftMirrored
        case .rightMirrored: return .rightMirrored
        @unknown default: return .up
        }
    }
}

// MARK: - Экран

struct MatrixView: View {
    private enum Op: String, CaseIterable, Identifiable {
        case det, inverse, rank, solve, rref, transpose, square
        var id: String { rawValue }
        var title: String {
            switch self {
            case .det: return "Определитель"
            case .inverse: return "Обратная"
            case .rank: return "Ранг"
            case .solve: return "Система уравнений"
            case .rref: return "Ступенчатый вид"
            case .transpose: return "Транспонировать"
            case .square: return "A²"
            }
        }
        var wolfram: String {
            switch self {
            case .det: return "determinant"
            case .inverse: return "inverse"
            case .rank: return "rank"
            case .solve, .rref: return "row reduce"
            case .transpose: return "transpose"
            case .square: return "square"
            }
        }
        /// Есть ли расписанное решение
        var hasSteps: Bool { [.det, .inverse, .rank, .solve, .rref].contains(self) }
    }

    private enum Route: Identifiable {
        case web(URL)
        var id: String {
            switch self {
            case .web(let u): return u.absoluteString
            }
        }
    }

    @AppStorage("matrix.last") private var saved = ""
    @State private var rows = 3
    @State private var cols = 3
    @State private var cells: [[String]] = Array(repeating: Array(repeating: "", count: 3), count: 3)
    @State private var op: Op = .det
    @State private var route: Route?
    @State private var camera = false
    @State private var photo: PhotosPickerItem?
    @State private var busy = false
    @State private var note: String?
    /// Снимок, с которого распознали — чтобы сверить числа
    @State private var source: UIImage?
    @State private var showSource = false
    @FocusState private var focus: Int?

    private var matrix: Matrix? {
        var out: [[Double]] = []
        for i in 0..<rows {
            var line: [Double] = []
            for j in 0..<cols {
                guard let v = MatrixFmt.parse(cell(i, j)) else { return nil }
                line.append(v)
            }
            out.append(line)
        }
        return Matrix(out)
    }

    var body: some View {
        Form {
            Section {
                HStack(spacing: 10) {
                    Button { camera = true } label: {
                        Label("Сфоткать", systemImage: "camera.fill").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    PhotosPicker(selection: $photo, matching: .images) {
                        Label("Из фото", systemImage: "photo").frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
                .disabled(busy)
                if busy {
                    HStack { ProgressView(); Text("Распознаю числа…").foregroundStyle(.secondary) }
                }
                if let note { Text(note).font(.footnote).foregroundStyle(.secondary) }
                if let source {
                    Button { showSource = true } label: {
                        HStack(spacing: 12) {
                            Image(uiImage: source)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 56, height: 56)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Сверить с фото").font(.subheadline.weight(.semibold))
                                Text("Открыть снимок крупно").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "arrow.up.left.and.arrow.down.right").foregroundStyle(.secondary)
                        }
                    }
                    .buttonStyle(.plain)
                }
            } footer: {
                Text("Снимай одну матрицу крупно и ровно, без лишнего текста вокруг. Числа распознаются на телефоне, фото никуда не отправляется. Проверь ячейки — камера может ошибиться.")
            }

            Section {
                // размер сетки меняем сразу вместе с ячейками — иначе экран успевал обратиться к несуществующей строке
                Stepper("Строк: \(rows)", value: Binding(get: { rows }, set: { rows = $0; resize() }), in: 1...8)
                Stepper("Столбцов: \(cols)", value: Binding(get: { cols }, set: { cols = $0; resize() }), in: 1...8)
                grid
                    .listRowInsets(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
                HStack {
                    Button("Очистить", role: .destructive) { resize(clear: true) }
                    Spacer()
                    Button { UIPasteboard.general.string = matrix?.text; Haptics.success() } label: {
                        Label("Копировать", systemImage: "doc.on.doc")
                    }
                    .disabled(matrix == nil)
                    Spacer()
                    Button { paste() } label: {
                        Label("Вставить", systemImage: "doc.on.clipboard")
                    }
                }
                .buttonStyle(.borderless)
                .font(.subheadline)
            } header: {
                Text("Матрица")
            } footer: {
                Text("Можно писать 3, −2, 1,5 или 1/3. «Далее» на клавиатуре переходит к следующей ячейке. Для системы уравнений последний столбец — правые части.")
            }

            Section("Посчитать") {
                Picker("Действие", selection: $op) {
                    ForEach(Op.allCases) { Text($0.title).tag($0) }
                }
                result
                if op.hasSteps, let m = matrix, let steps = steps(for: m) {
                    NavigationLink {
                        MatrixStepsView(title: op.title, steps: steps)
                    } label: {
                        Label("Решение по шагам", systemImage: "list.number")
                            .font(.subheadline.weight(.semibold))
                    }
                }
            }

            Section {
                Button { openWolfram(op.wolfram) } label: {
                    Label("\(op.title) — решение в Wolfram|Alpha", systemImage: "function")
                }
                Button { openWolfram("eigenvalues") } label: {
                    Label("Собственные числа и векторы", systemImage: "sparkle")
                }
                Button { openWolfram("") } label: {
                    Label("Всё о матрице", systemImage: "square.grid.3x3")
                }
            } header: {
                Text("Wolfram|Alpha")
            } footer: {
                Text("Откроется сайт wolframalpha.com с этой матрицей. Подробные шаги там платные, ответ — бесплатно; свои шаги — выше, в «Решении по шагам».")
            }
            .disabled(matrix == nil)
        }
        .navigationTitle("Матрицы")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Button { moveFocus(-1) } label: { Image(systemName: "chevron.left") }
                    .disabled((focus ?? 0) <= 0)
                Button { moveFocus(1) } label: { Image(systemName: "chevron.right") }
                    .disabled((focus ?? 0) >= rows * cols - 1)
                Button { toggleSign() } label: { Text("±").font(.title3.weight(.semibold)) }
                Spacer()
                Button("Готово") { focus = nil }
            }
        }
        .onChange(of: cells) { if let m = matrix { saved = m.wolfram } }
        .onChange(of: photo) {
            guard let item = photo else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                    await MainActor.run { recognize(img) }
                }
                await MainActor.run { photo = nil }
            }
        }
        .onAppear(perform: restore)
        // камера на весь экран, как везде в приложении (в листе она обрезалась и иногда не закрывалась)
        .fullScreenCover(isPresented: $camera) {
            CameraPicker { img in
                camera = false
                if let img { recognize(img) }
            }
            .ignoresSafeArea()
        }
        .sheet(item: $route) { r in
            switch r {
            case .web(let u):
                SafariView(url: u).ignoresSafeArea()
            }
        }
        .fullScreenCover(isPresented: $showSource) {
            if let source {
                MatrixPhotoView(image: source)
            }
        }
    }

    private var grid: some View {
        let w: CGFloat = cols > 5 ? 46 : 58
        return ScrollView(.horizontal, showsIndicators: false) {
            VStack(spacing: 6) {
                ForEach(0..<rows, id: \.self) { i in
                    HStack(spacing: 6) {
                        ForEach(0..<cols, id: \.self) { j in
                            let idx = i * cols + j
                            TextField("0", text: cellBinding(i, j))
                                .keyboardType(.numbersAndPunctuation)
                                .multilineTextAlignment(.center)
                                .font(.system(.body, design: .monospaced))
                                .submitLabel(idx == rows * cols - 1 ? .done : .next)
                                .onSubmit { moveFocus(1) }
                                .focused($focus, equals: idx)
                                .frame(width: w, height: 42)
                                .background(
                                    (MatrixFmt.parse(cell(i, j)) == nil ? Color.red.opacity(0.18)
                                     : focus == idx ? Color.brand.opacity(0.16) : Color.primary.opacity(0.06)),
                                    in: RoundedRectangle(cornerRadius: 9, style: .continuous)
                                )
                                .overlay(alignment: .trailing) {
                                    // черта перед правыми частями системы
                                    if op == .solve && j == cols - 2 && cols > 1 {
                                        Rectangle().fill(Color.secondary.opacity(0.6)).frame(width: 1.5).offset(x: 4)
                                    }
                                }
                        }
                    }
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
        }
    }

    private func cell(_ i: Int, _ j: Int) -> String {
        cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : ""
    }

    private func cellBinding(_ i: Int, _ j: Int) -> Binding<String> {
        Binding(get: { cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : "" },
                set: { v in if cells.indices.contains(i) && cells[i].indices.contains(j) { cells[i][j] = v } })
    }

    private func moveFocus(_ d: Int) {
        guard let f = focus else { focus = 0; return }
        let n = f + d
        if n < 0 || n >= rows * cols { focus = nil } else { focus = n }
    }

    /// «±» — поменять знак в текущей ячейке (на цифровой клавиатуре минус искать неудобно)
    private func toggleSign() {
        guard let f = focus else { return }
        let i = f / max(cols, 1), j = f % max(cols, 1)
        guard cells.indices.contains(i), cells[i].indices.contains(j) else { return }
        var t = cells[i][j].trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("-") || t.hasPrefix("−") { t.removeFirst() } else { t = "-" + t }
        cells[i][j] = t
        Haptics.tap()
    }

    @ViewBuilder private var result: some View {
        if let m = matrix {
            switch op {
            case .det:
                if m.isSquare { value("det A = \(MatrixFmt.nice(m.reduced().det))") }
                else { hint("Определитель есть только у квадратной матрицы") }
            case .rank:
                value("rang A = \(m.reduced().rank)")
            case .inverse:
                if !m.isSquare { hint("Обратная есть только у квадратной матрицы") }
                else if let inv = m.inverse { matrixResult(inv) }
                else { hint("Определитель равен 0 — обратной матрицы нет") }
            case .solve:
                if m.cols < 2 { hint("Нужно хотя бы два столбца: коэффициенты и правые части") }
                else {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(MatrixSolver.system(m).answer, id: \.self) { line in
                            Text(line).font(.system(.body, design: .monospaced).weight(.semibold))
                                .textSelection(.enabled)
                        }
                    }
                }
            case .rref: matrixResult(m.reduced().m)
            case .transpose: matrixResult(m.transposed)
            case .square:
                if let sq = m * m { matrixResult(sq) } else { hint("A² есть только у квадратной матрицы") }
            }
        } else {
            hint("В красных ячейках не число. Можно писать 3, -2, 1,5 или 1/3")
        }
    }

    private func steps(for m: Matrix) -> [MatrixStep]? {
        switch op {
        case .det: return m.isSquare ? MatrixSolver.determinant(m) : nil
        case .inverse: return m.isSquare ? MatrixSolver.inverse(m) : nil
        case .rank, .rref: return MatrixSolver.rank(m)
        case .solve: return m.cols >= 2 ? MatrixSolver.system(m).steps : nil
        default: return nil
        }
    }

    private func value(_ s: String) -> some View {
        Text(s)
            .font(.system(.title3, design: .monospaced).weight(.bold))
            .textSelection(.enabled)
    }

    private func hint(_ s: String) -> some View {
        Text(s).font(.subheadline).foregroundStyle(.secondary)
    }

    private func matrixResult(_ m: Matrix) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            MatrixGridView(m: m)
            HStack {
                Button { UIPasteboard.general.string = m.text; Haptics.success() } label: {
                    Label("Копировать", systemImage: "doc.on.doc")
                }
                Spacer()
                Button { load(m) } label: {
                    Label("В матрицу", systemImage: "arrow.up.doc")
                }
            }
            .buttonStyle(.borderless)
            .font(.caption.weight(.semibold))
        }
    }

    // MARK: - Действия

    private func recognize(_ img: UIImage) {
        busy = true
        note = nil
        source = img
        Task.detached(priority: .userInitiated) {
            let m = MatrixOCR.recognize(img)
            await MainActor.run {
                busy = false
                if let m {
                    load(m)
                    Haptics.success()
                    note = "Распознал \(m.rows)×\(m.cols). Сверь с фото и поправь, если что-то не так."
                } else {
                    note = "Не нашёл чисел на фото. Сфоткай ближе и ровнее или введи вручную."
                }
            }
        }
    }

    private func load(_ m: Matrix) {
        let r = min(m.rows, 8), c = min(m.cols, 8)
        rows = r
        cols = c
        cells = (0..<r).map { i in (0..<c).map { j in MatrixFmt.nice(m.a[i][j]) } }
    }

    private func resize(clear: Bool = false) {
        cells = (0..<rows).map { i in
            (0..<cols).map { j in
                !clear && cells.indices.contains(i) && cells[i].indices.contains(j) ? cells[i][j] : ""
            }
        }
    }

    /// Матрица из буфера: строки — с новой строки, числа — через пробел, табуляцию или «;»
    private func paste() {
        guard let text = UIPasteboard.general.string else { return }
        let lines = text.split(whereSeparator: \.isNewline).map { line in
            line.split(whereSeparator: { $0 == " " || $0 == "\t" || $0 == ";" })
                .compactMap { MatrixFmt.parse(String($0)) }
        }.filter { !$0.isEmpty }
        guard let c = lines.map(\.count).max(), c > 0 else { return }
        load(Matrix(lines.map { $0 + Array(repeating: 0, count: c - $0.count) }))
        Haptics.success()
    }

    private func restore() {
        // последняя матрица: {{1,2},{3,4}}
        guard !saved.isEmpty else { return }
        let body = saved.dropFirst(2).dropLast(2)
        let parsed = body.components(separatedBy: "},{").map { $0.split(separator: ",").compactMap { MatrixFmt.parse(String($0)) } }
        guard let c = parsed.first?.count, c > 0, parsed.allSatisfy({ $0.count == c }) else { return }
        load(Matrix(parsed))
    }

    private func openWolfram(_ command: String) {
        guard let m = matrix else { return }
        // Wolfram понимает только обычный минус
        let w = m.wolfram.replacingOccurrences(of: "−", with: "-")
        let q = command.isEmpty ? w : "\(command) \(w)"
        var comp = URLComponents(string: "https://www.wolframalpha.com/input")!
        comp.queryItems = [URLQueryItem(name: "i", value: q)]
        // «+», «{» и «,» в запросе нужно экранировать явно
        comp.percentEncodedQuery = comp.percentEncodedQuery?
            .replacingOccurrences(of: "+", with: "%2B")
        if let u = comp.url { route = .web(u) }
    }
}

/// Матрица числами в скобках; `bar` — черта перед правой частью
struct MatrixGridView: View {
    let m: Matrix
    var bar: Int? = nil

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                bracket(left: true)
                Grid(horizontalSpacing: 14, verticalSpacing: 6) {
                    ForEach(0..<m.rows, id: \.self) { i in
                        GridRow {
                            ForEach(0..<m.cols, id: \.self) { j in
                                Text(MatrixFmt.nice(m.a[i][j]))
                                    .font(.system(.body, design: .monospaced).weight(.semibold))
                                    .gridColumnAlignment(.trailing)
                                    .overlay(alignment: .leading) {
                                        if let bar, j == bar {
                                            Rectangle().fill(Color.secondary.opacity(0.7)).frame(width: 1.2).offset(x: -8)
                                        }
                                    }
                            }
                        }
                    }
                }
                .padding(.vertical, 4)
                bracket(left: false)
            }
            .padding(.vertical, 2)
        }
    }

    private func bracket(left: Bool) -> some View {
        Rectangle()
            .fill(Color.primary.opacity(0.7))
            .frame(width: 1.5)
            .overlay(alignment: .top) { Rectangle().fill(Color.primary.opacity(0.7)).frame(width: 6, height: 1.5).offset(x: left ? 2.25 : -2.25) }
            .overlay(alignment: .bottom) { Rectangle().fill(Color.primary.opacity(0.7)).frame(width: 6, height: 1.5).offset(x: left ? 2.25 : -2.25) }
    }
}

/// Решение по шагам — как в тетради
struct MatrixStepsView: View {
    let title: String
    let steps: [MatrixStep]

    var body: some View {
        List {
            ForEach(Array(steps.enumerated()), id: \.element.id) { i, s in
                Section {
                    ForEach(s.lines, id: \.self) { line in
                        Text(line)
                            .font(.system(.subheadline, design: .monospaced))
                            .textSelection(.enabled)
                    }
                    if let m = s.matrix {
                        MatrixGridView(m: m, bar: s.bar)
                    }
                } header: {
                    Text("\(i + 1). \(s.title)")
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                ShareLink(item: plainText) { Image(systemName: "square.and.arrow.up") }
            }
        }
    }

    /// Всё решение текстом — отправить в чат или вставить в отчёт
    private var plainText: String {
        var out = [title]
        for (i, s) in steps.enumerated() {
            out.append("")
            out.append("\(i + 1). \(s.title)")
            out += s.lines
            if let m = s.matrix { out.append(m.text) }
        }
        return out.joined(separator: "\n")
    }
}

/// Снимок крупно: щипком приблизить, смахнуть вниз — закрыть
private struct MatrixPhotoView: View {
    let image: UIImage
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1
    @State private var base: CGFloat = 1

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color.black.ignoresSafeArea()
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .scaleEffect(scale)
                .gesture(
                    MagnificationGesture()
                        .onChanged { scale = max(1, min(5, base * $0)) }
                        .onEnded { _ in base = scale }
                )
                .onTapGesture(count: 2) {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                        scale = scale > 1 ? 1 : 2.5
                        base = scale
                    }
                }
            Button { dismiss() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 38, height: 38)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .padding(16)
        }
    }
}
