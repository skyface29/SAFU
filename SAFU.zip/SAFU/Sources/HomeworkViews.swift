import SwiftUI

// MARK: - Вкладка «ДЗ»

enum HWMode: String, CaseIterable, Identifiable {
    case pairs, subjects, dates
    var id: String { rawValue }
    var title: String {
        switch self {
        case .pairs: return "К парам"
        case .subjects: return "Предметы"
        case .dates: return "По датам"
        }
    }
}

enum HWFocus: String {
    case overdue, soon, week
}

enum HWText {
    /// 1 задание · 2 задания · 5 заданий
    static func plural(_ n: Int, _ one: String, _ few: String, _ many: String) -> String {
        let a = abs(n) % 100
        let b = a % 10
        if a > 10 && a < 20 { return many }
        if b > 1 && b < 5 { return few }
        if b == 1 { return one }
        return many
    }

    static func tasks(_ n: Int) -> String { "\(n) \(plural(n, "задание", "задания", "заданий"))" }
}

private struct HWGroup: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let color: Color
    var kind: String = ""
    var date: Date?
    var showSubject = false
    /// Группа «к паре»: показать полоску с датой пары, по нажатию — в расписание
    var pairStrip = false
    var room: String = ""
    var estimated = false
    let items: [Homework]
}

struct HomeworkView: View {
    @EnvironmentObject private var schedule: ScheduleStore
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var store = HomeworkStore.shared
    @AppStorage("hw.mode") private var modeRaw = HWMode.pairs.rawValue
    @State private var subjectFilter: String?
    @State private var focus: HWFocus?
    @State private var query = ""
    @State private var showDone = false
    @State private var showSettings = false
    @State private var confirmClear = false
    @State private var route: HWEditorRoute?
    /// Открыт с главной поверх экрана (нет вкладки в панели)
    var embedded = false

    private var mode: HWMode { HWMode(rawValue: modeRaw) ?? .pairs }

    private var endOfTomorrow: Date {
        let cal = Calendar.current
        let t = cal.date(byAdding: .day, value: 2, to: cal.startOfDay(for: Date())) ?? Date()
        return t
    }

    private var overdueCount: Int { store.active.filter { $0.due < Date() }.count }
    private var soonCount: Int { store.active.filter { $0.due >= Date() && $0.due < endOfTomorrow }.count }
    private var weekCount: Int {
        let limit = Date().addingTimeInterval(7 * 86_400)
        return store.active.filter { $0.due >= Date() && $0.due < limit }.count
    }

    private var filtered: [Homework] {
        let now = Date()
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let weekLimit = now.addingTimeInterval(7 * 86_400)
        let tomorrow = endOfTomorrow
        return store.active.filter { h in
            if let s = subjectFilter, !h.isSameSubject(s) { return false }
            switch focus {
            case .overdue?: if h.due >= now { return false }
            case .soon?: if h.due < now || h.due >= tomorrow { return false }
            case .week?: if h.due < now || h.due >= weekLimit { return false }
            case nil: break
            }
            if !q.isEmpty {
                let hay = ([h.text, h.subject, h.note] + h.steps.map(\.text)).joined(separator: " ").lowercased()
                if !hay.contains(q) { return false }
            }
            return true
        }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            AmbientBackground()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    ScreenHeader(caption: headerCaption, title: "Домашка") {
                        HStack(spacing: 10) {
                            Button { showSettings = true } label: { CircleIconButton(icon: "slider.horizontal.3") }
                                .buttonStyle(PressableStyle())
                            if embedded {
                                Button { dismiss() } label: { CircleIconButton(icon: "xmark") }
                                    .buttonStyle(PressableStyle())
                            }
                        }
                    }

                    summary

                    if let s = HWPlanner.suggestedSlot(schedule.data) {
                        fromPairCard(s)
                    }

                    if !store.active.isEmpty {
                        controls
                    }

                    content

                    doneSection
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 120)
                .animation(.spring(response: 0.4, dampingFraction: 0.85), value: store.items)
                .glassGroup()
            }
            .pausesAmbientWhileScrolling()

            addButton
        }
        .onAppear {
            store.reconcile(schedule.data)
            store.cleanupFinished()
        }
        .sheet(item: $route) { r in
            HomeworkEditor(route: r, data: schedule.data)
                .environmentObject(schedule)
        }
        .sheet(isPresented: $showSettings) {
            HomeworkSettingsView(data: schedule.data)
        }
        .confirmationDialog("Удалить всё сделанное ДЗ?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Удалить", role: .destructive) { withAnimation { store.clearFinished() } }
        }
    }

    private var headerCaption: String {
        let n = store.active.count
        return n == 0 ? "Всё сделано" : "Открыто: \(HWText.tasks(n))"
    }

    // MARK: сводка

    private var summary: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                statTile(overdueCount, "просрочено", icon: "exclamationmark.circle.fill", color: .red, focus: .overdue)
                statTile(soonCount, "до завтра", icon: "clock.fill", color: .orange, focus: .soon)
                statTile(weekCount, "на неделе", icon: "calendar", color: Color.brand, focus: .week)
            }
            let st = store.weekStats
            if st.total > 0 {
                HStack(spacing: 10) {
                    ProgressView(value: Double(st.done), total: Double(max(st.total, 1)))
                        .tint(.green)
                    Text("сделано \(st.done) из \(st.total) за неделю")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .monospacedDigit()
                        .fixedSize()
                }
            }
        }
    }

    private func statTile(_ value: Int, _ title: String, icon: String, color: Color, focus f: HWFocus) -> some View {
        let selected = focus == f
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { focus = selected ? nil : f }
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                Image(systemName: icon)
                    .font(.subheadline)
                    .foregroundStyle(value > 0 ? color : Color.secondary)
                Text("\(value)")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(value > 0 ? Color.primary : Color.secondary)
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .glass(18)
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(color, lineWidth: selected ? 2 : 0)
            )
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: записать с текущей пары

    private func fromPairCard(_ s: LessonSlot) -> some View {
        let color = SubjectColor.color(for: s.lesson.subject)
        let now = Date()
        let live = s.start <= now && s.end > now
        let already = store.given(at: s).count
        return Button {
            Haptics.tap()
            route = HWEditorRoute(homework: nil, slot: s, subject: nil)
        } label: {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12, style: .continuous).fill(color.gradient)
                    Image(systemName: "square.and.pencil").font(.headline).foregroundStyle(.white)
                }
                .frame(width: 42, height: 42)
                VStack(alignment: .leading, spacing: 3) {
                    Text(live ? "Идёт пара — что задали?" : "Пара закончилась — что задали?")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(color)
                    Text(s.lesson.subject)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    HStack(spacing: 6) {
                        KindBadge(kind: s.lesson.kind, size: 9)
                        if already > 0 {
                            Text("уже записано: \(already)").font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
                Spacer(minLength: 4)
                Image(systemName: "plus.circle.fill")
                    .font(.title2)
                    .foregroundStyle(color)
            }
            .padding(12)
            .glass(20)
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: режимы, поиск, фильтр по предмету

    private var controls: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("Вид", selection: $modeRaw) {
                ForEach(HWMode.allCases) { m in
                    Text(m.title).tag(m.rawValue)
                }
            }
            .pickerStyle(.segmented)

            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Поиск по заданиям", text: $query)
                    .submitLabel(.search)
                if !query.isEmpty {
                    Button { query = "" } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .font(.subheadline)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .glass(14)

            if store.subjects.count > 1 {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        subjectChip(nil)
                        ForEach(store.subjects, id: \.self) { s in subjectChip(s) }
                    }
                    .padding(.vertical, 2)
                }
            }
        }
    }

    private func subjectChip(_ s: String?) -> some View {
        let selected = subjectFilter.map { HWPlanner.key($0) } == s.map { HWPlanner.key($0) }
        let color = s.map { SubjectColor.color(for: $0) } ?? Color.brand
        let count = s.map { store.openCount(subject: $0) } ?? store.active.count
        return Button {
            Haptics.tap()
            withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) { subjectFilter = s }
        } label: {
            HStack(spacing: 6) {
                if s != nil { Circle().fill(color).frame(width: 8, height: 8) }
                Text(s ?? "Все").lineLimit(1)
                Text("\(count)").foregroundStyle(selected ? Color.white.opacity(0.8) : Color.secondary)
            }
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 11)
            .padding(.vertical, 7)
            .foregroundStyle(selected ? Color.white : Color.primary)
            .background(selected ? AnyShapeStyle(color.gradient) : AnyShapeStyle(Color.primary.opacity(0.07)), in: Capsule())
        }
        .buttonStyle(PressableStyle())
    }

    // MARK: список

    @ViewBuilder
    private var content: some View {
        let list = filtered
        if store.active.isEmpty {
            EmptyState(icon: "book.closed.fill",
                       title: "Домашки нет",
                       text: "Нажми «Записать ДЗ» внизу. Выбери пару — срок сам встанет к следующей паре по расписанию, а если её перенесут, срок переедет вместе с ней.")
        } else if list.isEmpty {
            VStack(spacing: 10) {
                Text("Ничего не нашлось")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
                Button("Сбросить фильтры") {
                    withAnimation {
                        focus = nil
                        subjectFilter = nil
                        query = ""
                    }
                }
                .font(.subheadline.weight(.semibold))
            }
            .frame(maxWidth: .infinity)
            .padding(24)
            .glass(20)
        } else {
            ForEach(groups(list)) { g in
                groupView(g)
            }
        }
    }

    private func groups(_ list: [Homework]) -> [HWGroup] {
        switch mode {
        case .pairs: return pairGroups(list)
        case .subjects: return subjectGroups(list)
        case .dates: return dateGroups(list)
        }
    }

    /// К какой паре сдавать: одна группа — одна пара
    private func pairGroups(_ list: [Homework]) -> [HWGroup] {
        var order: [String] = []
        var map: [String: [Homework]] = [:]
        for h in list {
            let k = "\(Int(h.due.timeIntervalSince1970 / 60))|\(HWPlanner.key(h.subject))"
            if map[k] == nil { order.append(k) }
            map[k, default: []].append(h)
        }
        return order.compactMap { k in
            guard let items = map[k], let first = items.first else { return nil }
            var sub = HWFormat.dayTime(first.due).capitalizedFirst
            if !first.dueRoom.isEmpty { sub += AddressFormat.isRemote(first.dueRoom) ? " · дистант" : " · ауд. \(first.dueRoom)" }
            if first.dueEstimated { sub += " · примерно" }
            return HWGroup(id: k,
                           title: first.subject.isEmpty ? "Без предмета" : first.subject,
                           subtitle: sub,
                           color: SubjectColor.color(for: first.subject),
                           kind: first.dueKind,
                           date: first.due,
                           showSubject: false,
                           pairStrip: true,
                           room: first.dueRoom,
                           estimated: first.dueEstimated,
                           items: items.sorted { ($0.important ? 0 : 1) < ($1.important ? 0 : 1) })
        }
    }

    private func subjectGroups(_ list: [Homework]) -> [HWGroup] {
        var order: [String] = []
        var map: [String: [Homework]] = [:]
        for h in list {
            let k = HWPlanner.key(h.subject)
            if map[k] == nil { order.append(k) }
            map[k, default: []].append(h)
        }
        return order.compactMap { k in
            guard let items = map[k], let first = items.first else { return nil }
            return HWGroup(id: "s|" + k,
                           title: first.subject.isEmpty ? "Без предмета" : first.subject,
                           subtitle: "\(HWText.tasks(items.count)) · ближайшее \(HWFormat.chip(first.due))",
                           color: SubjectColor.color(for: first.subject),
                           date: nil,
                           showSubject: false,
                           items: items)
        }
    }

    private func dateGroups(_ list: [Homework]) -> [HWGroup] {
        let cal = Calendar.current
        let now = Date()
        let today = cal.startOfDay(for: now)
        let tomorrow = cal.date(byAdding: .day, value: 1, to: today) ?? now
        let after = cal.date(byAdding: .day, value: 2, to: today) ?? now
        let week = cal.date(byAdding: .day, value: 7, to: today) ?? now
        let buckets: [(String, String, Color, (Homework) -> Bool)] = [
            ("overdue", "Просрочено", .red, { $0.due < now }),
            ("today", "Сегодня", .orange, { $0.due >= now && $0.due < tomorrow }),
            ("tomorrow", "Завтра", Color.brand, { $0.due >= tomorrow && $0.due < after }),
            ("week", "На неделе", Color.brand, { $0.due >= after && $0.due < week }),
            ("later", "Позже", .secondary, { $0.due >= week })
        ]
        return buckets.compactMap { b in
            let items = list.filter(b.3)
            guard !items.isEmpty else { return nil }
            return HWGroup(id: b.0, title: b.1, subtitle: HWText.tasks(items.count), color: b.2,
                           date: nil, showSubject: true, items: items)
        }
    }

    private func groupView(_ g: HWGroup) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .center, spacing: 10) {
                Capsule().fill(g.color.gradient).frame(width: 4, height: g.pairStrip ? 22 : 32)
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 6) {
                        Text(g.title)
                            .font(.system(.headline, design: .rounded))
                            .lineLimit(1)
                        if !g.kind.isEmpty { KindBadge(kind: g.kind, size: 9) }
                    }
                    if !g.pairStrip {
                        Text(g.subtitle)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 4)
                if let d = g.date, !g.pairStrip {
                    Text(HWFormat.chip(d))
                        .font(.caption.weight(.bold))
                        .foregroundStyle(HWFormat.urgency(d))
                }
            }
            if g.pairStrip, let d = g.date {
                PairStrip(date: d, room: g.room, estimated: g.estimated, color: g.color)
            }
            ForEach(g.items) { h in
                row(h, showSubject: g.showSubject, showDue: !g.pairStrip)
            }
        }
    }

    private func row(_ h: Homework, showSubject: Bool, showDue: Bool = true) -> some View {
        HWRow(hw: h, showSubject: showSubject, showDue: showDue,
              onToggle: { withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { store.toggle(h) } },
              onOpen: { route = HWEditorRoute(homework: h, slot: nil, subject: nil) })
            .contextMenu { menu(h) }
            .transition(.asymmetric(insertion: .scale(scale: 0.96).combined(with: .opacity), removal: .opacity))
    }

    @ViewBuilder
    private func menu(_ h: Homework) -> some View {
        Button { withAnimation { store.toggle(h) } } label: {
            Label(h.done ? "Вернуть в работу" : "Сделано", systemImage: h.done ? "arrow.uturn.backward" : "checkmark.circle")
        }
        Button { route = HWEditorRoute(homework: h, slot: nil, subject: nil) } label: {
            Label("Изменить", systemImage: "pencil")
        }
        if !h.done {
            Button { withAnimation { store.postpone(h, data: schedule.data) } } label: {
                Label(h.rule == .pair ? "Перенести на следующую пару" : "Перенести на день", systemImage: "arrow.turn.down.right")
            }
        }
        Button { ScheduleJump.shared.show(h.due) } label: {
            Label("Показать в расписании", systemImage: "calendar")
        }
        Button { store.duplicate(h) } label: {
            Label("Дублировать", systemImage: "plus.square.on.square")
        }
        ShareLink(item: shareText(h)) {
            Label("Отправить", systemImage: "square.and.arrow.up")
        }
        Button(role: .destructive) { withAnimation { store.delete(h) } } label: {
            Label("Удалить", systemImage: "trash")
        }
    }

    /// Текст для чата группы
    private func shareText(_ h: Homework) -> String {
        var lines: [String] = []
        lines.append("📚 \(h.subject.isEmpty ? "ДЗ" : h.subject)")
        if !h.text.isEmpty { lines.append(h.text) }
        for s in h.steps { lines.append("• \(s.text)") }
        lines.append("Сдать: \(HWFormat.dayTime(h.due))")
        return lines.joined(separator: "\n")
    }

    // MARK: сделанное

    @ViewBuilder
    private var doneSection: some View {
        let done = store.finished
        if !done.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                Button {
                    Haptics.tap()
                    withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { showDone.toggle() }
                } label: {
                    HStack {
                        Label("Сделано · \(done.count)", systemImage: "checkmark.seal.fill")
                            .font(.system(.headline, design: .rounded))
                            .foregroundStyle(.primary)
                        Spacer()
                        Image(systemName: "chevron.down")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.secondary)
                            .rotationEffect(.degrees(showDone ? 180 : 0))
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)

                if showDone {
                    ForEach(done.prefix(40)) { h in
                        row(h, showSubject: true)
                    }
                    Button(role: .destructive) { confirmClear = true } label: {
                        Text("Удалить всё сделанное")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 10)
                    }
                    let keep = HWPrefs.keepDoneDays
                    if keep > 0 {
                        Text("Сделанное старше \(keep) дн. убирается само — это меняется в настройках")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                            .frame(maxWidth: .infinity)
                            .multilineTextAlignment(.center)
                    }
                }
            }
        }
    }

    private var addButton: some View {
        Button {
            Haptics.tap()
            route = HWEditorRoute(homework: nil, slot: nil, subject: subjectFilter)
        } label: {
            Label("Записать ДЗ", systemImage: "plus")
                .font(.headline)
                .foregroundStyle(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 15)
                .background(brandGradient, in: Capsule())
                .shadow(color: Color.brand.opacity(0.35), radius: 14, y: 6)
        }
        .buttonStyle(PressableStyle())
        .padding(.bottom, 16)
    }
}

// MARK: - Строка ДЗ

struct HWRow: View {
    let hw: Homework
    var showSubject = true
    /// В режиме «К парам» срок уже написан на полоске пары над заданиями
    var showDue = true
    var compact = false
    let onToggle: () -> Void
    let onOpen: () -> Void
    @ObservedObject private var store = HomeworkStore.shared

    private var color: Color { SubjectColor.color(for: hw.subject) }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button(action: onToggle) { checkbox }
                .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline, spacing: 5) {
                    if hw.important && !hw.done {
                        Image(systemName: "star.fill").font(.caption).foregroundStyle(.orange)
                    }
                    Text(hw.title)
                        .font(.body.weight(.semibold))
                        .strikethrough(hw.done)
                        .foregroundStyle(hw.done ? Color.secondary : Color.primary)
                        .lineLimit(compact ? 2 : 4)
                        .multilineTextAlignment(.leading)
                }
                meta
                if !compact && !hw.steps.isEmpty && !hw.done {
                    stepsInline
                }
                if !hw.shiftNote.isEmpty && !hw.done {
                    Label(hw.shiftNote, systemImage: "arrow.triangle.2.circlepath")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.orange)
                }
            }

            Spacer(minLength: 6)

            if showDue || hw.done { dueChip }
        }
        .padding(compact ? 12 : 14)
        .glassRow(20)
        .contentShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .onTapGesture(perform: onOpen)
    }

    private var checkbox: some View {
        ZStack {
            Circle()
                .strokeBorder(hw.done ? color : color.opacity(0.6), lineWidth: 2)
                .frame(width: 26, height: 26)
            if hw.done {
                Circle().fill(color.gradient).frame(width: 26, height: 26)
                Image(systemName: "checkmark")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white)
            } else if !hw.steps.isEmpty && hw.stepsDone > 0 {
                Circle()
                    .trim(from: 0, to: hw.stepsProgress)
                    .stroke(color, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .frame(width: 20, height: 20)
            }
        }
        .frame(width: 32, height: 32)
        .contentShape(Circle())
    }

    private var meta: some View {
        HStack(spacing: 5) {
            Image(systemName: hw.kind.icon).foregroundStyle(hw.kind.color)
            if showSubject && !hw.subject.isEmpty {
                Text(hw.subject).lineLimit(1)
            } else {
                Text(hw.kind.title).lineLimit(1)
            }
            if !hw.steps.isEmpty {
                Text("· \(hw.stepsDone)/\(hw.steps.count)").monospacedDigit()
            }
            if !hw.photos.isEmpty {
                Image(systemName: "photo")
                Text("\(hw.photos.count)")
            }
            if !hw.note.isEmpty {
                Image(systemName: "note.text")
            }
        }
        .font(.caption)
        .foregroundStyle(.secondary)
    }

    private var stepsInline: some View {
        VStack(alignment: .leading, spacing: 5) {
            ForEach(hw.steps.prefix(5)) { st in
                Button {
                    store.toggleStep(hw, step: st)
                } label: {
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Image(systemName: st.done ? "checkmark.circle.fill" : "circle")
                            .foregroundStyle(st.done ? color : Color.secondary)
                        Text(st.text)
                            .strikethrough(st.done)
                            .foregroundStyle(st.done ? Color.secondary : Color.primary)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                    }
                    .font(.caption)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
            if hw.steps.count > 5 {
                Text("ещё \(hw.steps.count - 5)")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(.top, 2)
    }

    private var dueChip: some View {
        let urg = HWFormat.urgency(hw.due, done: hw.done)
        return VStack(alignment: .trailing, spacing: 3) {
            Text((hw.dueEstimated && !hw.done ? "≈ " : "") + HWFormat.chip(hw.due, done: hw.done))
                .font(.caption.weight(.bold))
                .foregroundStyle(urg)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(urg.opacity(0.13), in: Capsule())
                .lineLimit(1)
                .fixedSize()
            if !hw.dueKind.isEmpty && !hw.done {
                Text("к \(kindDative(hw.dueKind))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private func kindDative(_ kind: String) -> String {
        switch KindStyle.of(kind).label {
        case "Лекция": return "лекции"
        case "Практика": return "практике"
        case "Лабораторная": return "лабе"
        case "Семинар": return "семинару"
        case "Консультация": return "консультации"
        case "Зачёт": return "зачёту"
        case "Экзамен": return "экзамену"
        default: return "паре"
        }
    }
}

/// Строка для списков в системном стиле (лист предмета)
struct HWListRow: View {
    let hw: Homework
    let onOpen: () -> Void
    @ObservedObject private var store = HomeworkStore.shared

    var body: some View {
        HStack(spacing: 12) {
            Button {
                withAnimation { store.toggle(hw) }
            } label: {
                Image(systemName: hw.done ? "checkmark.circle.fill" : "circle")
                    .font(.title3)
                    .foregroundStyle(hw.done ? AnyShapeStyle(Color.green) : AnyShapeStyle(SubjectColor.color(for: hw.subject)))
            }
            .buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 2) {
                Text(hw.title)
                    .font(.subheadline.weight(.semibold))
                    .strikethrough(hw.done)
                    .foregroundStyle(hw.done ? Color.secondary : Color.primary)
                    .lineLimit(3)
                HStack(spacing: 4) {
                    Image(systemName: hw.kind.icon)
                    Text(HWFormat.dayTime(hw.due))
                    if !hw.steps.isEmpty { Text("· \(hw.stepsDone)/\(hw.steps.count)") }
                }
                .font(.caption)
                .foregroundStyle(hw.isOverdue ? Color.red : Color.secondary)
            }
            Spacer(minLength: 0)
        }
        .contentShape(Rectangle())
        .onTapGesture(perform: onOpen)
    }
}

// MARK: - Раскладка «в строку с переносом» (для чипов)

struct HWFlow: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let maxWidth = proposal.width ?? .infinity
        var x: CGFloat = 0
        var y: CGFloat = 0
        var rowHeight: CGFloat = 0
        var widest: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > 0 && x + s.width > maxWidth {
                x = 0
                y += rowHeight + spacing
                rowHeight = 0
            }
            x += s.width + spacing
            rowHeight = max(rowHeight, s.height)
            widest = max(widest, x - spacing)
        }
        return CGSize(width: maxWidth.isFinite ? maxWidth : widest, height: y + rowHeight)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX
        var y = bounds.minY
        var rowHeight: CGFloat = 0
        for v in subviews {
            let s = v.sizeThatFits(.unspecified)
            if x > bounds.minX && x + s.width > bounds.maxX {
                x = bounds.minX
                y += rowHeight + spacing
                rowHeight = 0
            }
            v.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(s))
            x += s.width + spacing
            rowHeight = max(rowHeight, s.height)
        }
    }
}

// MARK: - Фото

struct HWPhotoRef: Identifiable {
    let owner: UUID
    let name: String
    var id: String { owner.uuidString + "/" + name }
}

struct HWThumb: View {
    let id: UUID
    let name: String
    var size: CGFloat = 64
    @State private var image: UIImage?

    var body: some View {
        ZStack {
            Color.primary.opacity(0.06)
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: "photo").foregroundStyle(.tertiary)
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .task(id: name) {
            let owner = id
            let file = name
            image = await Task.detached(priority: .utility) {
                HWFiles.image(owner, file)?.preparingThumbnail(of: CGSize(width: 240, height: 240))
            }.value
        }
    }
}

struct HWPhotoViewer: View {
    let ref: HWPhotoRef
    @Environment(\.dismiss) private var dismiss
    @State private var scale: CGFloat = 1

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                if let img = HWFiles.image(ref.owner, ref.name) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(scale)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { scale = max(1, $0) }
                                .onEnded { _ in withAnimation(.spring()) { scale = 1 } }
                        )
                } else {
                    Text("Фото не найдено").foregroundStyle(.white)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    ShareLink(item: HWFiles.url(ref.owner, ref.name)) {
                        Image(systemName: "square.and.arrow.up")
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
            .toolbarBackground(.hidden, for: .navigationBar)
        }
        .preferredColorScheme(.dark)
    }
}

// MARK: - Блок на главной

struct HWHomeCard: View {
    let data: ScheduleData
    let onOpenAll: () -> Void
    @ObservedObject private var store = HomeworkStore.shared
    @AppStorage("hw.home.count") private var count = 3

    var body: some View {
        let list = Array(store.active.prefix(max(1, count)))
        let overdue = store.overdue.count
        let suggested = HWPlanner.suggestedSlot(data)
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "book.closed.fill").foregroundStyle(brandGradient)
                Text("Домашка").font(.system(.headline, design: .rounded))
                if overdue > 0 {
                    Text("\(overdue) просрочено")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.red)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.red.opacity(0.12), in: Capsule())
                }
                Spacer()
                Button {
                    Haptics.tap()
                    onOpenAll()
                } label: {
                    HStack(spacing: 3) {
                        Text(store.active.count > list.count ? "Все \(store.active.count)" : "Открыть")
                        Image(systemName: "chevron.right")
                    }
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                Menu {
                    Button { onOpenAll() } label: { Label("Вся домашка", systemImage: "book.closed") }
                    Button(role: .destructive) {
                        Haptics.tap()
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.85)) { HomeSection.setHomework(false) }
                    } label: {
                        Label("Убрать с главной", systemImage: "eye.slash")
                    }
                } label: {
                    Image(systemName: "ellipsis")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.secondary)
                        .frame(width: 30, height: 26)
                        .contentShape(Rectangle())
                }
            }

            if list.isEmpty {
                Text("Всё сделано. Задали что-то — запиши, срок встанет к следующей паре.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                VStack(spacing: 8) {
                    ForEach(list) { h in compactRow(h) }
                }
            }

            Button {
                Haptics.tap()
                HomeworkRouter.shared.new(slot: suggested)
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "plus")
                    if let s = suggested {
                        Text("Записать с пары «\(s.lesson.subject)»").lineLimit(1)
                    } else {
                        Text("Записать ДЗ")
                    }
                }
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PressableStyle())
        }
        .padding(16)
        .glass(24)
    }

    private func compactRow(_ h: Homework) -> some View {
        let color = SubjectColor.color(for: h.subject)
        let urg = HWFormat.urgency(h.due)
        return HStack(spacing: 10) {
            Button {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { store.toggle(h) }
            } label: {
                Image(systemName: "circle")
                    .font(.title3)
                    .foregroundStyle(color)
            }
            .buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 1) {
                Text(h.title)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                Text(h.subject)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 4)
            Text((h.dueEstimated ? "≈ " : "") + HWFormat.chip(h.due))
                .font(.caption.weight(.bold))
                .foregroundStyle(urg)
                .lineLimit(1)
                .fixedSize()
        }
        .contentShape(Rectangle())
        .onTapGesture { HomeworkRouter.shared.edit(h) }
    }
}

// MARK: - ДЗ в подробностях пары

struct HWPairSection: View {
    let slot: LessonSlot
    let onAdd: () -> Void
    let onOpen: (Homework) -> Void
    @ObservedObject private var store = HomeworkStore.shared

    var body: some View {
        let dueHere = store.due(at: slot)
        let given = store.given(at: slot).filter { g in !dueHere.contains { $0.id == g.id } }
        let upcoming = slot.start > Date()
        VStack(alignment: .leading, spacing: 10) {
            Label("Домашка", systemImage: "book.closed.fill")
                .font(.headline)
            if !dueHere.isEmpty {
                Text("Сдать на этой паре")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                ForEach(dueHere) { h in
                    HWRow(hw: h, showSubject: false, compact: true,
                          onToggle: { withAnimation { store.toggle(h) } },
                          onOpen: { onOpen(h) })
                }
            }
            if !given.isEmpty {
                Text("Задали на этой паре")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                ForEach(given) { h in
                    HWRow(hw: h, showSubject: false, compact: true,
                          onToggle: { withAnimation { store.toggle(h) } },
                          onOpen: { onOpen(h) })
                }
            }
            if dueHere.isEmpty && given.isEmpty {
                Text(upcoming ? "К этой паре ничего не задано" : "С этой пары ДЗ не записано")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Button(action: onAdd) {
                Label(upcoming ? "Записать ДЗ к этой паре" : "Записать, что задали", systemImage: "plus.circle.fill")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(brandGradient, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .buttonStyle(PressableStyle())
        }
        .padding(16)
        .glass(22)
    }
}

// MARK: - Настройки домашки

struct HomeworkSettingsView: View {
    let data: ScheduleData
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var store = HomeworkStore.shared

    @AppStorage("hw.defaultDue") private var defaultDue = "next"
    @AppStorage("hw.follow") private var follow = true
    @AppStorage("hw.skipRemote") private var skipRemote = true
    @AppStorage("hw.notifyShift") private var notifyShift = true
    @AppStorage("hw.eveningHour") private var eveningHour = 20
    @AppStorage("hw.eveningMinute") private var eveningMinute = 0
    @AppStorage("hw.morningHour") private var morningHour = 7
    @AppStorage("hw.morningMinute") private var morningMinute = 30
    @AppStorage("hw.remind.evening") private var remindEvening = true
    @AppStorage("hw.remind.morning") private var remindMorning = false
    @AppStorage("hw.remind.hour") private var remindHour = true
    @AppStorage("hw.ask") private var ask = false
    @AppStorage("hw.ask.delay") private var askDelay = 3
    @AppStorage("hw.ask.lecture") private var askLecture = false
    @AppStorage("hw.ask.practice") private var askPractice = true
    @AppStorage("hw.ask.lab") private var askLab = true
    @AppStorage("hw.ask.seminar") private var askSeminar = true
    @AppStorage("hw.guessKind") private var guessKind = true
    @AppStorage("hw.celebrate") private var celebrate = true
    @AppStorage("hw.badge") private var badge = true
    @AppStorage("hw.nowChip") private var nowChip = true
    @AppStorage("hw.home.count") private var homeCount = 3
    @AppStorage("hw.keepDone") private var keepDone = 30
    @AppStorage("home.order") private var homeOrder = HomeSection.defaultRaw
    @State private var confirmClear = false

    private var homeBlock: Binding<Bool> {
        Binding(get: { homeOrder.split(separator: ",").contains("homework") },
                set: { HomeSection.setHomework($0) })
    }

    private func time(_ h: Binding<Int>, _ m: Binding<Int>) -> Binding<Date> {
        Binding(
            get: { Calendar.current.date(bySettingHour: h.wrappedValue, minute: m.wrappedValue, second: 0, of: Date()) ?? Date() },
            set: { d in
                let c = Calendar.current.dateComponents([.hour, .minute], from: d)
                h.wrappedValue = c.hour ?? h.wrappedValue
                m.wrappedValue = c.minute ?? m.wrappedValue
                HomeworkStore.shared.rescheduleAll()
            })
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Срок по умолчанию", selection: $defaultDue) {
                        Text("К следующей паре").tag("next")
                        Text("К такой же паре (практика → практика)").tag("nextSame")
                        Text("Через одну пару").tag("skip1")
                        Text("Завтра").tag("tomorrow")
                        Text("Через неделю").tag("week")
                    }
                    Toggle("Пропускать дистанционные пары", isOn: $skipRemote)
                    Toggle("Следить за расписанием", isOn: $follow)
                    Toggle("Сообщать, когда срок сдвинулся", isOn: $notifyShift)
                        .disabled(!follow)
                } header: {
                    Text("Сроки")
                } footer: {
                    Text("«Пропускать дистанционные»: срок «к следующей паре» встаёт на ближайшую очную пару, дистанционные в расписании остаются. У каждого ДЗ это можно поменять отдельно. Срок «к паре» считается по расписанию РУЗ. Если пару перенесут или отменят, срок переедет на новую пару. Если РУЗ ещё не выложил следующую неделю, срок считается по прошлым неделям (помечен «≈») и уточнится сам.")
                }

                Section {
                    Toggle("Вечером накануне", isOn: $remindEvening)
                    if remindEvening {
                        DatePicker("Во сколько вечером", selection: time($eveningHour, $eveningMinute), displayedComponents: .hourAndMinute)
                    }
                    Toggle("Утром в день сдачи", isOn: $remindMorning)
                    if remindMorning {
                        DatePicker("Во сколько утром", selection: time($morningHour, $morningMinute), displayedComponents: .hourAndMinute)
                    }
                    Toggle("За час до срока", isOn: $remindHour)
                } header: {
                    Text("Напоминания для нового ДЗ")
                } footer: {
                    Text("У каждого ДЗ напоминания можно поменять отдельно. Новое время «вечером» и «утром» сразу применяется ко всем открытым заданиям.")
                }

                Section {
                    Toggle("Спрашивать после пары «Что задали?»", isOn: $ask)
                    if ask {
                        Toggle("После лекций", isOn: $askLecture)
                        Toggle("После практик", isOn: $askPractice)
                        Toggle("После лабораторных", isOn: $askLab)
                        Toggle("После семинаров", isOn: $askSeminar)
                        Stepper("Через \(askDelay) мин после конца", value: $askDelay, in: 0...30)
                    }
                } header: {
                    Text("Чтобы не забыть записать")
                } footer: {
                    Text("После пары придёт уведомление. Нажмёшь — откроется запись ДЗ уже с этой парой и сроком.")
                }

                Section {
                    Toggle("Блок «Домашка» на главной", isOn: homeBlock)
                    Toggle("Угадывать тип задания по тексту", isOn: $guessKind)
                    Toggle("Кнопка «ДЗ» в карточке пары", isOn: $nowChip)
                    Toggle("Счётчик на вкладке", isOn: $badge)
                    Toggle("Салют, когда сделал", isOn: $celebrate)
                    Stepper("На главной: \(homeCount) \(HWText.plural(homeCount, "задание", "задания", "заданий"))", value: $homeCount, in: 1...8)
                    Picker("Хранить сделанное", selection: $keepDone) {
                        Text("Неделю").tag(7)
                        Text("2 недели").tag(14)
                        Text("Месяц").tag(30)
                        Text("3 месяца").tag(90)
                        Text("Всегда").tag(0)
                    }
                } header: {
                    Text("Удобство")
                }

                Section {
                    LabeledContent("Открыто", value: "\(store.active.count)")
                    LabeledContent("Сделано", value: "\(store.finished.count)")
                    Button("Удалить всё сделанное", role: .destructive) { confirmClear = true }
                        .disabled(store.finished.isEmpty)
                } header: {
                    Text("Данные")
                } footer: {
                    Text("ДЗ хранится на телефоне и попадает в резервную копию приложения.")
                }
            }
            .navigationTitle("Настройки домашки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }
                }
            }
            .onChange(of: ask) { HWAsk.schedule(data) }
            .onChange(of: askDelay) { HWAsk.schedule(data) }
            .onChange(of: askLecture) { HWAsk.schedule(data) }
            .onChange(of: askPractice) { HWAsk.schedule(data) }
            .onChange(of: askLab) { HWAsk.schedule(data) }
            .onChange(of: askSeminar) { HWAsk.schedule(data) }
            .onChange(of: follow) { if follow { store.reconcile(data) } }
            .onChange(of: ask) {
                if ask { HWNotifier.requestAuthorization() }
            }
            .confirmationDialog("Удалить всё сделанное ДЗ?", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) { store.clearFinished() }
            }
        }
    }
}

// MARK: - Корень приложения: редактор ДЗ отовсюду и подстройка под расписание

struct HomeworkRoot: ViewModifier {
    @Binding var tab: String
    let tabsRaw: String
    @EnvironmentObject private var schedule: ScheduleStore
    @ObservedObject private var router = HomeworkRouter.shared
    @ObservedObject private var jump = ScheduleJump.shared
    @State private var showHomework = false

    func body(content: Content) -> some View {
        content
            .sheet(item: $router.editor) { r in
                HomeworkEditor(route: r, data: schedule.data)
                    .environmentObject(schedule)
            }
            .sheet(isPresented: $showHomework) {
                HomeworkView(embedded: true)
                    .environmentObject(schedule)
            }
            .onChange(of: router.openTab) {
                guard router.openTab else { return }
                router.openTab = false
                if AppTab.parse(tabsRaw).contains(.homework) {
                    tab = AppTab.homework.rawValue
                } else {
                    showHomework = true
                }
            }
            // «показать в расписании» — на вкладку «Пары» (закрыв домашку, если она открыта поверх)
            .onChange(of: jump.target) { _, new in
                guard new != nil else { return }
                showHomework = false
                if AppTab.parse(tabsRaw).contains(.schedule) {
                    tab = AppTab.schedule.rawValue
                }
            }
            // расписание обновилось — сроки «к паре» переезжают, вопросы «что задали?» пересчитываются
            .onChange(of: schedule.data.lastSync) {
                HomeworkStore.shared.reconcile(schedule.data)
                HWAsk.schedule(schedule.data)
            }
            .onChange(of: schedule.data.lessons) {
                HomeworkStore.shared.reconcile(schedule.data)
                HWAsk.schedule(schedule.data)
            }
    }
}


// MARK: - Полоска «пара, к которой сдавать»: нажал — открылось расписание на этот день

struct PairStrip: View {
    let date: Date
    var room: String = ""
    var estimated = false
    let color: Color

    private var dateLine: String {
        let day = Fmt.formatter("EE, d MMMM").string(from: date).capitalizedFirst
        return HWFormat.isEndOfDay(date) ? day : "\(day) · \(hmString(date))"
    }

    private var roomLine: String? {
        let r = room.trimmingCharacters(in: .whitespaces)
        guard !r.isEmpty else { return nil }
        return AddressFormat.isRemote(r) ? "дистант" : "ауд. \(r)"
    }

    private var left: String {
        let cal = Calendar.current
        let now = Date()
        if date < now { return "прошла" }
        if cal.isDateInToday(date) { return "сегодня" }
        if cal.isDateInTomorrow(date) { return "завтра" }
        let n = cal.dateComponents([.day], from: cal.startOfDay(for: now), to: cal.startOfDay(for: date)).day ?? 0
        return "через \(n) \(HWText.plural(n, "день", "дня", "дней"))"
    }

    var body: some View {
        Button {
            ScheduleJump.shared.show(date)
        } label: {
            HStack(spacing: 8) {
                Image(systemName: "calendar")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(color)
                VStack(alignment: .leading, spacing: 1) {
                    Text((estimated ? "≈ " : "") + dateLine)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    if let roomLine {
                        Text(roomLine)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                }
                Spacer(minLength: 6)
                Text(left)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(HWFormat.urgency(date))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(HWFormat.urgency(date).opacity(0.13), in: Capsule())
                    .fixedSize()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(color.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(color.opacity(0.25), lineWidth: 0.8)
            )
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(PressableStyle())
        .accessibilityLabel("Открыть в расписании: \(dateLine)")
    }
}
