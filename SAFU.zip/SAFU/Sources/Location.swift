import Foundation
import CoreLocation
import Combine

// MARK: - Где я: Архангельск или Северодвинск

enum HomeCity: String {
    case arkhangelsk, severodvinsk

    var title: String { self == .arkhangelsk ? "Архангельске" : "Северодвинске" }

    /// Куда логично ехать из этого города
    var busDirection: Bus150.Direction { self == .arkhangelsk ? .toSeverodvinsk : .toArkhangelsk }

    // Центры городов
    static let arkhCenter = CLLocation(latitude: 64.5393, longitude: 40.5170)
    static let sevCenter = CLLocation(latitude: 64.5635, longitude: 39.8302)

    /// Ближайший город, если до него не дальше 40 км (иначе — ты где-то в дороге или уехал)
    static func nearest(to loc: CLLocation) -> HomeCity? {
        let a = loc.distance(from: arkhCenter)
        let s = loc.distance(from: sevCenter)
        guard min(a, s) < 40_000 else { return nil }
        return a < s ? .arkhangelsk : .severodvinsk
    }
}

/// Один запрос геолокации по требованию. Координаты никуда не отправляются —
/// приложение запоминает только город.
final class CityLocator: NSObject, ObservableObject, CLLocationManagerDelegate {
    static let shared = CityLocator()

    @Published private(set) var city: HomeCity?
    @Published private(set) var denied = false

    private let manager = CLLocationManager()
    private let d = UserDefaults.standard

    static var enabled: Bool { UserDefaults.standard.object(forKey: "commute.geo") as? Bool ?? true }

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyKilometer   // точность до города, батарею не ест
        // последний известный город (если определяли меньше 3 часов назад)
        if let raw = d.string(forKey: "geo.city"), let c = HomeCity(rawValue: raw),
           Date().timeIntervalSince1970 - d.double(forKey: "geo.time") < 3 * 3600 {
            city = c
        }
        denied = manager.authorizationStatus == .denied || manager.authorizationStatus == .restricted
    }

    /// Обновить, если давно не обновляли (не чаще раза в 10 минут)
    func refresh(force: Bool = false) {
        guard Self.enabled else { return }
        if !force, Date().timeIntervalSince1970 - d.double(forKey: "geo.time") < 600, city != nil { return }
        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways:
            manager.requestLocation()
        default:
            denied = true
        }
    }

    func locationManagerDidChangeAuthorization(_ m: CLLocationManager) {
        let st = m.authorizationStatus
        DispatchQueue.main.async { self.denied = st == .denied || st == .restricted }
        if st == .authorizedWhenInUse || st == .authorizedAlways { m.requestLocation() }
    }

    func locationManager(_ m: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        let c = HomeCity.nearest(to: loc)
        DispatchQueue.main.async {
            self.city = c
            self.d.set(c?.rawValue, forKey: "geo.city")
            self.d.set(Date().timeIntervalSince1970, forKey: "geo.time")
        }
    }

    func locationManager(_ m: CLLocationManager, didFailWithError error: Error) {}
}

/// Какое направление показать: по геолокации, иначе — последний выбор
enum BusDirectionMemory {
    static func suggested() -> Bus150.Direction {
        if CityLocator.enabled, let c = CityLocator.shared.city { return c.busDirection }
        return UserDefaults.standard.string(forKey: "bus.lastDirection") == "sev" ? .toSeverodvinsk : .toArkhangelsk
    }

    static func remember(_ d: Bus150.Direction) {
        UserDefaults.standard.set(d == .toSeverodvinsk ? "sev" : "arh", forKey: "bus.lastDirection")
    }
}
