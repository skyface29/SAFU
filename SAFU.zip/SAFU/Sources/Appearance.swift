import SwiftUI

// MARK: - Шрифт и тема

enum AppFont: String, CaseIterable, Identifiable {
    case rounded, standard, mono, serif
    var id: String { rawValue }
    var title: String {
        switch self {
        case .rounded: return "Круглый"
        case .standard: return "Строгий"
        case .mono: return "Код"
        case .serif: return "Книжный"
        }
    }
    var design: Font.Design {
        switch self {
        case .rounded: return .rounded
        case .standard: return .default
        case .mono: return .monospaced
        case .serif: return .serif
        }
    }
}

enum SchemePref: Int, CaseIterable, Identifiable {
    case system = 0, light = 1, dark = 2
    var id: Int { rawValue }
    var title: String {
        switch self {
        case .system: return "Авто"
        case .light: return "Светлая"
        case .dark: return "Тёмная"
        }
    }
    var scheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

/// Шрифт и светлая/тёмная тема на всё приложение
struct AppearanceRoot: ViewModifier {
    @AppStorage("ui.font") private var fontRaw = AppFont.rounded.rawValue
    @AppStorage("ui.scheme") private var schemeRaw = 0

    func body(content: Content) -> some View {
        content
            .fontDesign((AppFont(rawValue: fontRaw) ?? .rounded).design)
            .preferredColorScheme((SchemePref(rawValue: schemeRaw) ?? .system).scheme)
    }
}

// MARK: - Готовые стили

struct LookPreset: Identifiable {
    let id: String
    let title: String
    let icon: String
    let theme: AccentTheme
    let backdrop: BackdropStyle
    let card: CardStyle
    let font: AppFont
    let radius: Double
    let gradTitle: Bool
    let scheme: SchemePref

    static let all: [LookPreset] = [
        LookPreset(id: "season", title: "По сезону", icon: "calendar.circle.fill", theme: Season.current.theme, backdrop: .seasonal,
                   card: .glass, font: .rounded, radius: 1.05, gradTitle: true, scheme: .system),
        LookPreset(id: "autumn", title: "Осень", icon: "leaf.fill", theme: .autumn, backdrop: .leaves, card: .glass,
                   font: .rounded, radius: 1.1, gradTitle: true, scheme: .system),
        LookPreset(id: "tech", title: "Техно", icon: "cpu", theme: .cyber, backdrop: .grid, card: .neon,
                   font: .mono, radius: 0.55, gradTitle: true, scheme: .dark),
        LookPreset(id: "arctic", title: "Арктика", icon: "snowflake", theme: .ice, backdrop: .snow, card: .glass,
                   font: .rounded, radius: 1.0, gradTitle: false, scheme: .system),
        LookPreset(id: "aurora", title: "Сияние", icon: "sparkles", theme: .aurora, backdrop: .aurora, card: .glass,
                   font: .rounded, radius: 1.15, gradTitle: true, scheme: .dark),
        LookPreset(id: "minimal", title: "Минимал", icon: "circle.dashed", theme: .graphite, backdrop: .plain, card: .minimal,
                   font: .standard, radius: 0.7, gradTitle: false, scheme: .system),
        LookPreset(id: "paper", title: "Конспект", icon: "book.closed", theme: .gold, backdrop: .wash, card: .raised,
                   font: .serif, radius: 0.8, gradTitle: false, scheme: .light),
        LookPreset(id: "classic", title: "Классика", icon: "drop.fill", theme: .blue, backdrop: .glow, card: .glass,
                   font: .rounded, radius: 1.0, gradTitle: false, scheme: .system),
    ]
}

// MARK: - Экран «Оформление»

struct AppearanceView: View {
    @AppStorage("theme") private var theme = AccentTheme.blue.rawValue
    @AppStorage("bg.style") private var backdrop = BackdropStyle.glow.rawValue
    @AppStorage("bg.intensity") private var intensity = 1.0
    @AppStorage("cardStyle") private var cardStyle = 0
    @AppStorage("ui.radius") private var radius = 1.0
    @AppStorage("ui.font") private var font = AppFont.rounded.rawValue
    @AppStorage("ui.scheme") private var scheme = 0
    @AppStorage("ui.gradTitle") private var gradTitle = false
    @AppStorage("ambient") private var ambient = true
    @AppStorage("animations") private var animations = true
    @AppStorage("haptics") private var haptics = true
    @AppStorage("theme.seasonal") private var seasonalTheme = false

    var body: some View {
        Form {
            Section {
                preview
                    .listRowInsets(EdgeInsets())
                    .listRowBackground(Color.clear)
            }

            Section {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(LookPreset.all) { p in presetChip(p) }
                    }
                    .padding(.vertical, 4)
                }
            } header: {
                Text("Готовые стили")
            } footer: {
                Text("Один тап — и всё сразу. Потом можно докрутить любую мелочь ниже.")
            }

            Section {
                Toggle(isOn: $seasonalTheme) {
                    Label("Цвет по сезону", systemImage: "calendar.circle.fill")
                }
                if !seasonalTheme {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 52), spacing: 12)], spacing: 14) {
                    ForEach(AccentTheme.allCases) { th in
                        VStack(spacing: 5) {
                            Circle()
                                .fill(LinearGradient(colors: [th.color, th.secondary],
                                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                                .frame(width: 36, height: 36)
                                .overlay(
                                    Circle()
                                        .strokeBorder(Color.primary.opacity(theme == th.rawValue ? 0.8 : 0), lineWidth: 2)
                                        .padding(-5)
                                )
                            Text(th.title)
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(theme == th.rawValue ? Color.primary : Color.secondary)
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            Haptics.tap()
                            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { theme = th.rawValue }
                        }
                    }
                }
                .padding(.vertical, 6)
                }
            } header: {
                Text("Цвет")
            } footer: {
                Text(seasonalTheme ? "Сейчас \(Season.current.title): цвет меняется сам — зимой лёд, весной розовый, летом лайм, осенью оранжевый." : "")
            }

            Section {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 10)], spacing: 10) {
                    ForEach(BackdropStyle.allCases) { b in
                        optionTile(icon: b.icon, title: b.title, selected: backdrop == b.rawValue) {
                            backdrop = b.rawValue
                        }
                    }
                }
                .padding(.vertical, 4)
                if backdrop != BackdropStyle.plain.rawValue {
                    HStack {
                        Image(systemName: "sun.min").foregroundStyle(.secondary)
                        Slider(value: $intensity, in: 0.3...1.8)
                        Image(systemName: "sun.max.fill").foregroundStyle(Color.brand)
                    }
                    Toggle("Движение фона", isOn: $ambient)
                }
            } header: {
                Text("Фон")
            } footer: {
                Text("«По сезону» меняется сам: сейчас \(Season.current.title). «Листопад» — клёны и берёзы кружатся и переворачиваются в воздухе. «Сияние» на iOS 18+ переливается как настоящее северное. «Снег» и «Сетка» почти не тратят батарею, но если жалко — выключи движение.")
            }

            Section {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 92), spacing: 10)], spacing: 10) {
                    ForEach(CardStyle.allCases) { c in
                        Button {
                            Haptics.tap()
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { cardStyle = c.rawValue }
                        } label: {
                            VStack(spacing: 6) {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.clear)
                                    .frame(height: 30)
                                    .overlay(Text("Aa").font(.caption.weight(.bold)))
                                    .modifier(CardSample(style: c))
                                Text(c.title).font(.caption2.weight(.semibold))
                            }
                            .padding(8)
                            .background(Color.brand.opacity(cardStyle == c.rawValue ? 0.12 : 0),
                                        in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .strokeBorder(cardStyle == c.rawValue ? Color.brand : Color.clear, lineWidth: 1.5))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, 4)
                HStack {
                    Image(systemName: "square").foregroundStyle(.secondary)
                    Slider(value: $radius, in: 0.3...1.4)
                    Image(systemName: "circle").foregroundStyle(.secondary)
                }
            } header: {
                Text("Карточки")
            } footer: {
                Text("Ползунок — насколько скруглены углы: от строгих до мягких.")
            }

            Section("Текст") {
                Picker("Шрифт", selection: $font) {
                    ForEach(AppFont.allCases) { f in
                        Text(f.title).font(.system(.body, design: f.design)).tag(f.rawValue)
                    }
                }
                .pickerStyle(.segmented)
                Toggle("Цветные заголовки", isOn: $gradTitle)
            }

            Section("Тема") {
                Picker("Тема", selection: $scheme) {
                    ForEach(SchemePref.allCases) { s in Text(s.title).tag(s.rawValue) }
                }
                .pickerStyle(.segmented)
                Toggle("Анимации", isOn: $animations)
                Toggle("Вибрация", isOn: $haptics)
            }

            Section {
                NavigationLink {
                    AppIconPicker()
                } label: {
                    Label("Иконка приложения", systemImage: "app.badge.fill")
                }
                Button("Сбросить оформление", role: .destructive) {
                    if let p = LookPreset.all.first(where: { $0.id == "classic" }) { apply(p) }
                }
            }
        }
        .navigationTitle("Оформление")
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: превью

    private var preview: some View {
        ZStack(alignment: .topLeading) {
            AmbientBackground()
            VStack(alignment: .leading, spacing: 10) {
                ScreenHeader(caption: "пятница, 25 сентября", title: "Привет!") { EmptyView() }
                HStack(spacing: 10) {
                    Circle().fill(brandGradient).frame(width: 34, height: 34)
                        .overlay(Image(systemName: "clock.fill").font(.system(size: 14, weight: .bold)).foregroundStyle(.white))
                    VStack(alignment: .leading, spacing: 1) {
                        Text("Сейчас · 2 пара").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                        Text("Информатика").font(.headline)
                    }
                    Spacer()
                    Text("32 мин")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Color.brand.opacity(0.14), in: Capsule())
                }
                .padding(12)
                .glass(20)
                HStack(spacing: 10) {
                    ForEach(["calendar", "checklist", "folder.fill"], id: \.self) { i in
                        Image(systemName: i)
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(brandGradient)
                            .frame(maxWidth: .infinity)
                            .frame(height: 46)
                            .glass(16)
                    }
                }
            }
            .padding(16)
        }
        .frame(height: 250)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .animation(.spring(response: 0.4, dampingFraction: 0.85), value: theme)
    }

    // MARK: мелочи

    private func presetChip(_ p: LookPreset) -> some View {
        Button {
            Haptics.success()
            withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) { apply(p) }
        } label: {
            VStack(spacing: 6) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(LinearGradient(colors: [p.theme.color, p.theme.secondary],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: p.icon)
                        .font(.system(size: 20, weight: .bold))
                        .foregroundStyle(.white)
                }
                .frame(width: 64, height: 52)
                Text(p.title)
                    .font(.system(size: 11, weight: .semibold, design: p.font.design))
                    .foregroundStyle(.primary)
            }
        }
        .buttonStyle(PressableStyle())
    }

    private func optionTile(icon: String, title: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button {
            Haptics.tap()
            withAnimation(.easeInOut(duration: 0.3)) { action() }
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(selected ? AnyShapeStyle(brandGradient) : AnyShapeStyle(Color.secondary))
                    .frame(height: 24)
                Text(title).font(.caption2.weight(.semibold)).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(Color.brand.opacity(selected ? 0.12 : 0.0), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous)
                .strokeBorder(selected ? Color.brand : Color.primary.opacity(0.1), lineWidth: selected ? 1.5 : 1))
        }
        .buttonStyle(.plain)
    }

    private func apply(_ p: LookPreset) {
        seasonalTheme = p.id == "season"
        theme = p.theme.rawValue
        backdrop = p.backdrop.rawValue
        cardStyle = p.card.rawValue
        font = p.font.rawValue
        radius = p.radius
        gradTitle = p.gradTitle
        scheme = p.scheme.rawValue
        intensity = 1.0
    }
}

/// Мини-образец стиля карточки для выбора (без чтения настроек)
private struct CardSample: ViewModifier {
    let style: CardStyle
    @ViewBuilder
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 8, style: .continuous)
        switch style {
        case .glass:
            content.background(.ultraThinMaterial, in: shape)
                .overlay(shape.strokeBorder(Color.primary.opacity(0.1), lineWidth: 0.6))
        case .solid:
            content.background(Color(.secondarySystemBackground), in: shape)
        case .tinted:
            content.background(Color.brand.opacity(0.18), in: shape)
        case .neon:
            content.overlay(shape.strokeBorder(brandGradient, lineWidth: 1.2))
                .shadow(color: Color.brand.opacity(0.3), radius: 5)
        case .minimal:
            content.overlay(shape.strokeBorder(Color.primary.opacity(0.2), lineWidth: 0.8))
        case .raised:
            content.background(Color(.secondarySystemGroupedBackground), in: shape)
                .shadow(color: .black.opacity(0.15), radius: 4, y: 2)
        }
    }
}

/// Оформление открывается шторкой поверх всего приложения:
/// так смена цвета не сбрасывает экран, на котором ты находишься.
struct AppearanceSheet: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            AppearanceView()
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Готово") { dismiss() }.fontWeight(.semibold)
                    }
                }
        }
        .tint(Color.brand)
        .presentationDragIndicator(.visible)
    }
}
