import SwiftUI
import SafariServices
import UserNotifications

// MARK: - Автобус № 150 «Архангельск (м.р. вокзал) — Северодвинск (о. Ягры)»
// Расписание из PDF, который прислал пользователь (круглогодично, пн–пт / сб / вс).

enum Bus150 {
    enum Direction { case toArkhangelsk, toSeverodvinsk }

    private static let weekdayToArkh = "06:20 06:40 07:00 07:25 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:00 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let weekdayToSev = "06:10 07:40 08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 15:30 16:00 16:30 17:00 17:30 18:15 19:00 20:00"
    private static let satToArkh = "06:40 07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let satToSev = "08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00"
    private static let sunToArkh = "07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let sunToSev = "08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00"

    /// Маршрут 150 в Яндекс Картах: там видно автобусы на линии, если перевозчик передаёт GPS
    static let yandexURL = URL(string: "https://yandex.ru/maps/20/arkhangelsk/routes/bus_150/796d617073626d313a2f2f7472616e7369742f6c696e653f69643d31373034383535383634266c6c3d34302e31383136333325324336342e353534353734266e616d653d31353026723d313833383726747970653d627573/")!

    static let fromStop = "о. Ягры"
    static let toStop = "м.р. вокзал"

    enum DayType: Int, CaseIterable, Identifiable {
        case weekday, saturday, sunday
        var id: Int { rawValue }
        var title: String {
            switch self {
            case .weekday: return "Пн–Пт"
            case .saturday: return "Суббота"
            case .sunday: return "Воскресенье"
            }
        }
        static func of(_ day: Date) -> DayType {
            switch ScheduleEngine.weekday(of: day) {   // 1 = пн … 7 = вс
            case 6: return .saturday
            case 7: return .sunday
            default: return .weekday
            }
        }
    }

    static func times(_ d: Direction, type: DayType) -> [String] {
        let raw: String
        switch (d, type) {
        case (.toArkhangelsk, .saturday): raw = satToArkh
        case (.toSeverodvinsk, .saturday): raw = satToSev
        case (.toArkhangelsk, .sunday): raw = sunToArkh
        case (.toSeverodvinsk, .sunday): raw = sunToSev
        case (.toArkhangelsk, .weekday): raw = weekdayToArkh
        case (.toSeverodvinsk, .weekday): raw = weekdayToSev
        }
        return raw.split(separator: " ").map(String.init)
    }

    static func times(_ d: Direction, on day: Date) -> [String] {
        times(d, type: DayType.of(day))
    }

    struct Trip: Hashable {
        let departure: Date
        let arrival: Date
    }

    static func trips(_ d: Direction, on day: Date) -> [Trip] {
        let cal = Calendar.current
        let travel = Double(CommuteSettings.travelMinutes) * 60
        return times(d, on: day).compactMap { t in
            let p = t.split(separator: ":").compactMap { Int($0) }
            guard p.count == 2, let dep = cal.date(bySettingHour: p[0], minute: p[1], second: 0, of: day) else { return nil }
            return Trip(departure: dep, arrival: dep.addingTimeInterval(travel))
        }
    }
}

enum CommuteSettings {
    private static var d: UserDefaults { .standard }
    static var enabled: Bool { d.object(forKey: "commute.enabled") as? Bool ?? true }
    static var walkMinutes: Int { let v = d.integer(forKey: "commute.walk"); return v == 0 ? 15 : v }
    static var homeMinutes: Int { let v = d.integer(forKey: "commute.home"); return v == 0 ? 10 : v }
    static var travelMinutes: Int { let v = d.integer(forKey: "commute.travel"); return v == 0 ? 90 : v }
    /// Для пар не в 8:20 и не в 10:10: выезжать не позже, чем за столько минут до начала.
    /// Новый ключ, чтобы старое сохранённое значение не ломало расчёт.
    static var leadMinutes: Int { let v = d.integer(forKey: "commute.lead2"); return v == 0 ? 100 : v }
    static var notify: Bool { d.object(forKey: "commute.notify") as? Bool ?? true }
}

enum CommutePlanner {
    /// Твои правила: пара в 8:20 → автобус 7:00, пара в 10:10 → автобус 8:30.
    /// Для остальных пар — последний автобус, который уходит за «лид» минут до начала.
    static func latestDeparture(for start: Date) -> Date {
        let cal = Calendar.current
        let hm = cal.component(.hour, from: start) * 60 + cal.component(.minute, from: start)
        func at(_ h: Int, _ m: Int) -> Date { cal.date(bySettingHour: h, minute: m, second: 0, of: start) ?? start }
        if hm <= 8 * 60 + 20 { return at(7, 0) }            // 1 пара
        if hm <= 10 * 60 + 10 { return at(8, 30) }          // 2 пара
        return start.addingTimeInterval(-Double(CommuteSettings.leadMinutes) * 60)
    }

    /// Автобус из Северодвинска к первой паре
    static func morning(for first: LessonSlot) -> Bus150.Trip? {
        let latest = latestDeparture(for: first.start)
        return Bus150.trips(.toArkhangelsk, on: first.start).last { $0.departure <= latest }
    }

    /// Ближайшие автобусы домой после пар
    static func afterClasses(from time: Date, count: Int = 3) -> [Bus150.Trip] {
        let walk = Double(CommuteSettings.walkMinutes) * 60
        let ready = time.addingTimeInterval(walk)
        return Array(Bus150.trips(.toSeverodvinsk, on: time).filter { $0.departure >= ready }.prefix(count))
    }

    static func firstPair(on day: Date, data: ScheduleData) -> LessonSlot? {
        ScheduleEngine.slots(on: day, data: data).first { !AddressFormat.isRemote($0.address) }
    }

    static func lastPair(on day: Date, data: ScheduleData) -> LessonSlot? {
        ScheduleEngine.slots(on: day, data: data).last { !AddressFormat.isRemote($0.address) }
    }

    /// Напоминания «пора выходить» на неделю вперёд
    static func scheduleNotifications(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        let on = CommuteSettings.enabled && CommuteSettings.notify
        let home = Double(CommuteSettings.homeMinutes) * 60
        center.getPendingNotificationRequests { reqs in
            center.removePendingNotificationRequests(withIdentifiers: reqs.map(\.identifier).filter { $0.hasPrefix("commute-") })
            guard on else { return }
            let cal = Calendar.current
            for offset in 0..<7 {
                guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: Date())),
                      let first = firstPair(on: day, data: data),
                      let trip = morning(for: first) else { continue }
                let fire = trip.departure.addingTimeInterval(-home - 10 * 60)
                guard fire > Date() else { continue }
                let c = UNMutableNotificationContent()
                c.title = "Через 10 мин выходи 🚌"
                c.body = "Автобус 150 в \(hmString(trip.departure)) с о. Ягры. Пара «\(first.lesson.subject)» в \(hmString(first.start))."
                c.sound = .default
                let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                center.add(UNNotificationRequest(identifier: "commute-\(offset)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            }
        }
    }
}

func hmString(_ d: Date) -> String { LiveFormat.hmText(d) }

private func minutesText(_ m: Int) -> String {
    if m < 60 { return "\(m) мин" }
    return "\(m / 60) ч \(m % 60) мин"
}

// MARK: - Карточка «Дорога» на главной

/// Виды карточки автобуса
enum CommuteStyle: String, CaseIterable, Identifiable {
    case full, compact, line, board
    var id: String { rawValue }
    var title: String {
        switch self {
        case .full: return "Подробно"
        case .compact: return "Компактно"
        case .line: return "Одной строкой"
        case .board: return "Табло"
        }
    }
    var icon: String {
        switch self {
        case .full: return "rectangle.grid.1x2"
        case .compact: return "rectangle"
        case .line: return "minus.rectangle"
        case .board: return "tablecells"
        }
    }
}

/// Что показывать сейчас: утренняя поездка или дорога домой
private struct CommuteInfo {
    var title: String            // «Сегодня в пары», «Завтра», «Домой»
    var busTime: Date?
    var subtitle: String         // «с о. Ягры · пара в 8:20»
    var hint: String             // «выйти в 6:50» / «дома ~12:50»
    var badge: String            // «выйти через 25 мин»
    var badgeUrgent: Bool
    var others: [Date]           // следующие рейсы
    var toCity: Bool
    var empty: String?
}

struct CommuteCard: View {
    let data: ScheduleData
    var onHide: (() -> Void)? = nil
    @AppStorage("commute.style") private var styleRaw = CommuteStyle.full.rawValue
    @State private var showTimetable = false
    @ObservedObject private var locator = CityLocator.shared

    private var style: CommuteStyle { CommuteStyle(rawValue: styleRaw) ?? .full }

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            let info = makeInfo(now: ctx.date)
            Group {
                switch style {
                case .full: full(info)
                case .compact: compact(info)
                case .line: line(info)
                case .board: board(info)
                }
            }
            .contentShape(Rectangle())
            .onTapGesture {
                Haptics.tap()
                showTimetable = true
            }
            .contextMenu { menuItems }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.85), value: styleRaw)
        .sheet(isPresented: $showTimetable) {
            BusTimetableView(data: data)
        }
        .onAppear { locator.refresh() }
    }

    // MARK: меню вида

    @ViewBuilder private var menuItems: some View {
        Button { showTimetable = true } label: {
            Label("Всё расписание 150", systemImage: "list.bullet.rectangle")
        }
        Picker("Вид", selection: $styleRaw) {
            ForEach(CommuteStyle.allCases) { s in
                Label(s.title, systemImage: s.icon).tag(s.rawValue)
            }
        }
        if let onHide {
            Divider()
            Button(role: .destructive) { onHide() } label: {
                Label("Убрать с главной", systemImage: "eye.slash")
            }
        }
    }

    private var menuButton: some View {
        Menu { menuItems } label: {
            Image(systemName: "ellipsis.circle.fill")
                .font(.title3)
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(Color.brand)
        }
    }

    private var header: some View {
        HStack(spacing: 6) {
            Image(systemName: "bus.fill")
            Text("АВТОБУС 150")
            Spacer()
            Text("расписание ›")
                .font(.caption2.weight(.bold))
                .foregroundStyle(.secondary)
            menuButton
        }
        .font(.caption.weight(.heavy))
        .foregroundStyle(Color.brand)
    }

    // MARK: виды

    private func full(_ i: CommuteInfo) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            header
            if let e = i.empty {
                Text(e).font(.subheadline).foregroundStyle(.secondary)
            } else {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(alignment: .firstTextBaseline) {
                        Text(i.title).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                        Spacer()
                        badge(i)
                    }
                    if let t = i.busTime {
                        Text("Автобус в \(hmString(t))")
                            .font(.system(.title3, design: .rounded).weight(.bold))
                    }
                    Text(i.subtitle).font(.caption).foregroundStyle(.secondary)
                    if !i.hint.isEmpty { Text(i.hint).font(.caption.weight(.semibold)) }
                    if !i.others.isEmpty {
                        Text("Следующие: " + i.others.map(hmString).joined(separator: ", "))
                            .font(.caption.weight(.semibold))
                    }
                }
            }
        }
        .padding(16)
        .glass(24)
    }

    private func compact(_ i: CommuteInfo) -> some View {
        HStack(spacing: 12) {
            busIcon(size: 42)
            VStack(alignment: .leading, spacing: 2) {
                if let e = i.empty {
                    Text(e).font(.subheadline.weight(.semibold))
                } else {
                    Text(i.busTime.map { "\(i.title) · \(hmString($0))" } ?? i.title)
                        .font(.system(.headline, design: .rounded))
                    Text(i.hint.isEmpty ? i.subtitle : i.hint)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 4)
            if i.empty == nil { badge(i) }
            menuButton
        }
        .padding(12)
        .glass(22)
    }

    private func line(_ i: CommuteInfo) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "bus.fill").foregroundStyle(Color.brand)
            if let e = i.empty {
                Text(e).foregroundStyle(.secondary)
            } else if let t = i.busTime {
                Text("150 · \(hmString(t))").fontWeight(.bold)
                Text(i.toCity ? "в город" : "домой").foregroundStyle(.secondary)
            }
            Spacer(minLength: 4)
            if i.empty == nil { badge(i) }
            menuButton
        }
        .font(.subheadline)
        .lineLimit(1)
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .glass(18)
    }

    private func board(_ i: CommuteInfo) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            header
            if let e = i.empty {
                Text(e).font(.subheadline).foregroundStyle(.secondary)
            } else {
                HStack(alignment: .center, spacing: 14) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(i.toCity ? "О. ЯГРЫ → ВОКЗАЛ" : "ВОКЗАЛ → О. ЯГРЫ")
                            .font(.caption2.weight(.heavy))
                            .foregroundStyle(.secondary)
                        if let t = i.busTime {
                            Text(hmString(t))
                                .font(.system(size: 44, weight: .heavy, design: .rounded))
                                .monospacedDigit()
                                .foregroundStyle(brandGradient)
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 6) {
                        badge(i)
                        ForEach(i.others.prefix(2), id: \.self) { t in
                            Text(hmString(t))
                                .font(.system(.subheadline, design: .rounded).weight(.bold))
                                .monospacedDigit()
                                .padding(.horizontal, 10)
                                .padding(.vertical, 4)
                                .background(Color.primary.opacity(0.07), in: Capsule())
                        }
                    }
                }
                Text(i.hint.isEmpty ? i.subtitle : "\(i.subtitle) · \(i.hint)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .glass(24)
    }

    // MARK: мелочи

    private func busIcon(size: CGFloat) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.3, style: .continuous).fill(brandGradient)
            Image(systemName: "bus.fill")
                .font(.system(size: size * 0.45, weight: .bold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
    }

    @ViewBuilder private func badge(_ i: CommuteInfo) -> some View {
        if !i.badge.isEmpty {
            Text(i.badge)
                .font(.caption.weight(.bold))
                .foregroundStyle(i.badgeUrgent ? Color.orange : Color.brand)
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background((i.badgeUrgent ? Color.orange : Color.brand).opacity(0.14), in: Capsule())
                .fixedSize()
        }
    }

    // MARK: расчёт

    private func makeInfo(now: Date) -> CommuteInfo {
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let first = CommutePlanner.firstPair(on: today, data: data)
        let last = CommutePlanner.lastPair(on: today, data: data)

        // Знаем город — решаем по нему, а не только по времени
        if CityLocator.enabled, let city = locator.city {
            let here = "📍 в \(city.title)"
            switch city {
            case .arkhangelsk:
                // ты в городе — показываем дорогу домой
                var info = homeInfo(after: max(now, last?.end ?? now), lastEnd: last?.end ?? now, now: now)
                info.title = (last.map { now < $0.end } ?? false) ? "После пар · \(here)" : "Домой · \(here)"
                return info
            case .severodvinsk:
                // ты дома — ближайшая пара сегодня, на которую ещё можно успеть, иначе следующий учебный день
                let upcoming = ScheduleEngine.slots(on: today, data: data)
                    .first { !AddressFormat.isRemote($0.address) && $0.start > now }
                if let p = upcoming, let trip = CommutePlanner.morning(for: p), trip.departure > now {
                    var info = morningInfo(trip: trip, pair: p, now: now, title: "В пары")
                    info.title = "В пары · \(here)"
                    return info
                }
                if let next = nextStudyDay(after: today), let f = CommutePlanner.firstPair(on: next, data: data),
                   let trip = CommutePlanner.morning(for: f) {
                    var info = morningInfo(trip: trip, pair: f, now: now,
                                           title: cal.isDateInTomorrow(next) ? "Завтра" : dayName(next))
                    info.title += " · \(here)"
                    return info
                }
            }
        }

        if let f = first, now < f.start, let trip = CommutePlanner.morning(for: f) {
            return morningInfo(trip: trip, pair: f, now: now, title: "Сегодня в пары")
        }
        if let l = last, now < l.end.addingTimeInterval(4 * 3600) {
            return homeInfo(after: max(now, l.end), lastEnd: l.end, now: now)
        }
        if let next = nextStudyDay(after: today), let f = CommutePlanner.firstPair(on: next, data: data),
           let trip = CommutePlanner.morning(for: f) {
            return morningInfo(trip: trip, pair: f, now: now, title: cal.isDateInTomorrow(next) ? "Завтра" : dayName(next))
        }
        return CommuteInfo(title: "", busTime: nil, subtitle: "", hint: "", badge: "", badgeUrgent: false,
                           others: [], toCity: true, empty: "На неделю поездок нет")
    }

    private func morningInfo(trip: Bus150.Trip, pair: LessonSlot, now: Date, title: String) -> CommuteInfo {
        let leave = trip.departure.addingTimeInterval(-Double(CommuteSettings.homeMinutes) * 60)
        let mins = Int(leave.timeIntervalSince(now) / 60)
        var badge = ""
        if mins >= 0 && mins < 180 { badge = mins == 0 ? "выходи сейчас" : "выйти через \(minutesText(mins))" }
        return CommuteInfo(title: title, busTime: trip.departure,
                           subtitle: "с \(Bus150.fromStop) · пара в \(hmString(pair.start))",
                           hint: "выйти из дома в \(hmString(leave))",
                           badge: badge, badgeUrgent: mins <= 10,
                           others: [], toCity: true, empty: nil)
    }

    private func homeInfo(after time: Date, lastEnd: Date, now: Date) -> CommuteInfo {
        let buses = CommutePlanner.afterClasses(from: time)
        guard let b = buses.first else {
            return CommuteInfo(title: "Домой", busTime: nil, subtitle: "", hint: "", badge: "", badgeUrgent: false,
                               others: [], toCity: false, empty: "Сегодня автобусов домой больше нет")
        }
        let m = Int(b.departure.timeIntervalSince(now) / 60)
        return CommuteInfo(title: now < lastEnd ? "После пар" : "Домой", busTime: b.departure,
                           subtitle: "от \(Bus150.toStop)" + (now < lastEnd ? " · конец пар \(hmString(lastEnd))" : ""),
                           hint: "дома ~\(hmString(b.arrival))",
                           badge: m <= 0 ? "уходит" : "через \(minutesText(m))", badgeUrgent: m <= 15,
                           others: buses.dropFirst().map(\.departure), toCity: false, empty: nil)
    }

    private func nextStudyDay(after today: Date) -> Date? {
        let cal = Calendar.current
        for i in 1..<8 {
            if let d = cal.date(byAdding: .day, value: i, to: today), CommutePlanner.firstPair(on: d, data: data) != nil { return d }
        }
        return nil
    }

    private func dayName(_ d: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EEEE"
        return f.string(from: d).capitalizedFirst
    }
}

// MARK: - Настройки дороги

struct CommuteSettingsView: View {
    @AppStorage("commute.enabled") private var enabled = true
    @AppStorage("commute.walk") private var walk = 15
    @AppStorage("commute.home") private var home = 10
    @AppStorage("commute.travel") private var travel = 90
    @AppStorage("commute.notify") private var notify = true
    @AppStorage("commute.lead2") private var lead = 100
    @AppStorage("commute.style") private var style = CommuteStyle.full.rawValue
    @AppStorage("commute.geo") private var geo = true
    @EnvironmentObject private var schedule: ScheduleStore

    var body: some View {
        Form {
            Section {
                Toggle("Показывать дорогу", isOn: $enabled)
                Toggle("Напоминать, когда выходить", isOn: $notify)
                Toggle("Определять город по геолокации", isOn: $geo)
                    .onChange(of: geo) { on in if on { CityLocator.shared.refresh(force: true) } }
                Picker("Вид на главной", selection: $style) {
                    ForEach(CommuteStyle.allCases) { s in Text(s.title).tag(s.rawValue) }
                }
            } footer: {
                Text("Маршрут: автобус 150, Северодвинск (о. Ягры) ⇄ Архангельск (м.р. вокзал). Расписание пн–пт, сб и вс из твоего PDF.")
            }
            Section {
                Stepper("До остановки из дома: \(home) мин", value: $home, in: 0...60, step: 5)
                Stepper("Другие пары: выезд за \(lead) мин", value: $lead, in: 50...180, step: 5)
                Stepper("После пар до вокзала: \(walk) мин", value: $walk, in: 0...60, step: 5)
                Stepper("Домой едет: \(travel) мин", value: $travel, in: 60...150, step: 5)
            } header: {
                Text("Время")
            } footer: {
                Text("Пара в 8:20 → автобус 7:00. Пара в 10:10 → автобус 8:30. Если первая пара позже — берётся последний автобус, который уходит не позже чем за указанное время до начала.")
            }
            Section("Расписание сегодня") {
                Text("В Архангельск: " + Bus150.times(.toArkhangelsk, on: Date()).joined(separator: " "))
                    .font(.caption)
                Text("В Северодвинск: " + Bus150.times(.toSeverodvinsk, on: Date()).joined(separator: " "))
                    .font(.caption)
            }
        }
        .navigationTitle("Дорога")
        .onDisappear { schedule.refreshSideEffects() }
    }
}


// MARK: - Полное расписание автобуса 150

struct BusTimetableView: View {
    let data: ScheduleData
    @Environment(\.dismiss) private var dismiss
    @State private var direction: Bus150.Direction = BusDirectionMemory.suggested()
    @State private var dayType: Bus150.DayType = Bus150.DayType.of(Date())
    @State private var userPicked = false
    @ObservedObject private var locator = CityLocator.shared
    @State private var showLive = false
    @Environment(\.openURL) private var openURL

    private var isToday: Bool { dayType == Bus150.DayType.of(Date()) }

    /// Времена выбранного направления и типа дня как даты «сегодня»
    private var trips: [Date] {
        let cal = Calendar.current
        let today = Date()
        return Bus150.times(direction, type: dayType).compactMap { t in
            let p = t.split(separator: ":").compactMap { Int($0) }
            guard p.count == 2 else { return nil }
            return cal.date(bySettingHour: p[0], minute: p[1], second: 0, of: today)
        }
    }

    /// Рекомендуемый рейс к первой паре сегодня (только «в Архангельск»)
    private var myTrip: Date? {
        guard direction == .toArkhangelsk, isToday,
              let f = CommutePlanner.firstPair(on: Date(), data: data) else { return nil }
        return CommutePlanner.morning(for: f)?.departure
    }

    var body: some View {
        NavigationStack {
            TimelineView(.periodic(from: .now, by: 30)) { ctx in
                let now = ctx.date
                let next = isToday ? trips.first { $0 >= now } : nil
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        geoBanner
                        routeCard
                        Picker("День", selection: $dayType) {
                            ForEach(Bus150.DayType.allCases) { Text($0.title).tag($0) }
                        }
                        .pickerStyle(.segmented)
                        nextCard(next: next, now: now)
                        liveCard
                        board(now: now, next: next)
                        legend
                    }
                    .padding(20)
                }
            }
            .background(AmbientBackground())
            .onAppear { locator.refresh(force: true) }
            .onChange(of: locator.city) { c in
                // геолокация пришла позже — переключаем, если ты сам ещё не выбирал
                guard let c, !userPicked else { return }
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { direction = c.busDirection }
            }
            .sheet(isPresented: $showLive) {
                TransportMapScreen()
            }
            .navigationTitle("Автобус 150")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { dismiss() }.fontWeight(.semibold)
                }
            }
        }
        .presentationDragIndicator(.visible)
    }

    /// Где автобус сейчас — Яндекс Карты
    private var liveCard: some View {
        HStack(spacing: 12) {
            Button {
                Haptics.tap()
                showLive = true
            } label: {
                HStack(spacing: 12) {
                    ZStack {
                        Circle().fill(Color.red.opacity(0.15)).frame(width: 42, height: 42)
                        Image(systemName: "dot.radiowaves.left.and.right")
                            .font(.system(size: 17, weight: .bold))
                            .foregroundStyle(.red)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Где автобус сейчас").font(.system(.headline, design: .rounded))
                        Text(YandexMap.isAvailable ? "Карта транспорта в реальном времени" : "Яндекс Карты, маршрут 150")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(PressableStyle())
            Button {
                Haptics.tap()
                openURL(Bus150.yandexURL)   // откроет приложение Яндекс Карт, если оно установлено
            } label: {
                Image(systemName: "arrow.up.forward.app.fill")
                    .font(.system(size: 22))
                    .foregroundStyle(Color.brand)
            }
            .buttonStyle(PressableStyle())
        }
        .foregroundStyle(.primary)
        .padding(14)
        .glass(22)
    }

    /// Подсказка, откуда взялось направление
    @ViewBuilder private var geoBanner: some View {
        if CityLocator.enabled, let c = locator.city {
            Label("Ты в \(c.title) — показываю рейсы \(c == .arkhangelsk ? "домой" : "в Архангельск")",
                  systemImage: "location.fill")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color.brand)
                .padding(.horizontal, 12)
                .padding(.vertical, 7)
                .background(Color.brand.opacity(0.12), in: Capsule())
        } else if CityLocator.enabled && locator.denied {
            Label("Геолокация выключена — запоминаю последний выбор", systemImage: "location.slash")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
        }
    }

    // Откуда → куда, с кнопкой смены направления
    private var routeCard: some View {
        let from = direction == .toArkhangelsk ? "Северодвинск" : "Архангельск"
        let fromStop = direction == .toArkhangelsk ? Bus150.fromStop : Bus150.toStop
        let to = direction == .toArkhangelsk ? "Архангельск" : "Северодвинск"
        let toStop = direction == .toArkhangelsk ? Bus150.toStop : Bus150.fromStop
        return HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 10) {
                stop(city: from, stop: fromStop, icon: "circle.fill")
                stop(city: to, stop: toStop, icon: "mappin.circle.fill")
            }
            Spacer()
            Button {
                Haptics.tap()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                    direction = direction == .toArkhangelsk ? .toSeverodvinsk : .toArkhangelsk
                }
                userPicked = true
                BusDirectionMemory.remember(direction)
            } label: {
                Image(systemName: "arrow.up.arrow.down")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(brandGradient, in: Circle())
            }
            .buttonStyle(PressableStyle())
        }
        .padding(16)
        .glass(22)
    }

    private func stop(city: String, stop: String, icon: String) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color.brand)
                .frame(width: 18)
            VStack(alignment: .leading, spacing: 1) {
                Text(city).font(.system(.headline, design: .rounded))
                Text(stop).font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    // Ближайший рейс
    @ViewBuilder private func nextCard(next: Date?, now: Date) -> some View {
        if let n = next {
            let mins = max(0, Int(n.timeIntervalSince(now) / 60))
            let arrive = n.addingTimeInterval(Double(CommuteSettings.travelMinutes) * 60)
            HStack(alignment: .center) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("БЛИЖАЙШИЙ").font(.caption2.weight(.heavy)).foregroundStyle(.secondary)
                    Text(hmString(n))
                        .font(.system(size: 44, weight: .heavy, design: .rounded))
                        .monospacedDigit()
                        .foregroundStyle(brandGradient)
                    Text("прибытие ~\(hmString(arrive))").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(mins == 0 ? "сейчас" : "через")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                    if mins > 0 {
                        Text(mins < 60 ? "\(mins) мин" : "\(mins / 60) ч \(mins % 60) мин")
                            .font(.system(.title3, design: .rounded).weight(.bold))
                            .foregroundStyle(mins <= 15 ? Color.orange : Color.primary)
                    }
                }
            }
            .padding(18)
            .glass(24)
        } else if isToday {
            Label("Сегодня рейсов в эту сторону больше нет", systemImage: "moon.zzz.fill")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16)
                .glass(20)
        }
    }

    // Табло по часам
    private func board(now: Date, next: Date?) -> some View {
        let cal = Calendar.current
        let groups = Dictionary(grouping: trips) { cal.component(.hour, from: $0) }
        let hours = groups.keys.sorted()
        return VStack(spacing: 0) {
            ForEach(hours, id: \.self) { h in
                let list = groups[h] ?? []
                let hourPast = isToday && (list.last.map { $0 < now } ?? false)
                HStack(alignment: .center, spacing: 12) {
                    Text(String(format: "%02d", h))
                        .font(.system(.title3, design: .rounded).weight(.heavy))
                        .monospacedDigit()
                        .foregroundStyle(hourPast ? Color.secondary.opacity(0.5) : Color.primary)
                        .frame(width: 38, alignment: .leading)
                    FlowChips(times: list, now: now, next: next, mine: myTrip, today: isToday)
                    Spacer(minLength: 0)
                }
                .padding(.vertical, 9)
                .padding(.horizontal, 14)
                if h != hours.last {
                    Divider().padding(.leading, 64)
                }
            }
        }
        .padding(.vertical, 6)
        .glass(22)
    }

    private var legend: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 14) {
                legendItem(color: Color.brand, filled: true, text: "ближайший")
                if direction == .toArkhangelsk {
                    legendItem(color: .green, filled: false, text: "твой к первой паре")
                }
            }
            Text("Расписание из PDF: будни, суббота и воскресенье. В дороге ~\(CommuteSettings.travelMinutes) мин (меняется в настройках «Дорога»).")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private func legendItem(color: Color, filled: Bool, text: String) -> some View {
        HStack(spacing: 5) {
            Capsule()
                .fill(filled ? color : color.opacity(0.18))
                .overlay(Capsule().strokeBorder(color, lineWidth: filled ? 0 : 1.5))
                .frame(width: 22, height: 12)
            Text(text).font(.caption2.weight(.semibold)).foregroundStyle(.secondary)
        }
    }
}

/// Минуты одного часа в виде капсул
private struct FlowChips: View {
    let times: [Date]
    let now: Date
    let next: Date?
    let mine: Date?
    let today: Bool

    var body: some View {
        HStack(spacing: 6) {
            ForEach(times, id: \.self) { t in
                let past = today && t < now
                let isNext = next == t
                let isMine = mine == t
                Text(hmString(t))
                    .font(.system(.subheadline, design: .rounded).weight(isNext || isMine ? .heavy : .semibold))
                    .monospacedDigit()
                    .foregroundStyle(isNext ? Color.white : (past ? Color.secondary.opacity(0.45) : Color.primary))
                    .strikethrough(past, color: Color.secondary.opacity(0.4))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background {
                        if isNext {
                            Capsule().fill(brandGradient)
                        } else if isMine {
                            Capsule().fill(Color.green.opacity(0.18))
                        } else {
                            Capsule().fill(Color.primary.opacity(past ? 0.03 : 0.07))
                        }
                    }
                    .overlay {
                        if isMine { Capsule().strokeBorder(Color.green, lineWidth: 1.5) }
                    }
            }
        }
    }
}


/// Встроенный Safari: Яндекс Карты открываются прямо в приложении
struct SafariView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController {
        let vc = SFSafariViewController(url: url)
        vc.preferredControlTintColor = UIColor(Color.brand)
        return vc
    }
    func updateUIViewController(_ vc: SFSafariViewController, context: Context) {}
}
