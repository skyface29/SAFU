import SwiftUI
import UserNotifications

// MARK: - Автобус № 150 «Архангельск (м.р. вокзал) — Северодвинск (о. Ягры)»
// Расписание из PDF, который прислал пользователь (круглогодично, пн–пт / сб / вс).

enum Bus150 {
    enum Direction { case toArkhangelsk, toSeverodvinsk }

    private static let weekdayToArkh = "06:20 06:40 07:00 07:25 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:00 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let weekdayToSev = "06:10 07:40 08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 15:30 16:00 16:30 17:00 17:30 18:15 19:00 20:00"
    private static let satToArkh = "06:40 07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let satToSev = "08:15 08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00"
    private static let sunToArkh = "07:10 07:50 08:30 09:35 10:30 11:10 12:00 12:40 13:20 14:30 15:10 16:00 16:35 17:30 18:30 19:30"
    private static let sunToSev = "08:40 09:20 10:00 10:35 11:10 12:00 13:00 14:00 14:50 16:00 16:30 17:00 17:30 18:15 19:00 20:00"

    static let fromStop = "о. Ягры"
    static let toStop = "м.р. вокзал"

    static func times(_ d: Direction, on day: Date) -> [String] {
        let wd = ScheduleEngine.weekday(of: day)   // 1 = пн … 7 = вс
        let raw: String
        switch (d, wd) {
        case (.toArkhangelsk, 6): raw = satToArkh
        case (.toSeverodvinsk, 6): raw = satToSev
        case (.toArkhangelsk, 7): raw = sunToArkh
        case (.toSeverodvinsk, 7): raw = sunToSev
        case (.toArkhangelsk, _): raw = weekdayToArkh
        case (.toSeverodvinsk, _): raw = weekdayToSev
        }
        return raw.split(separator: " ").map(String.init)
    }

    struct Trip: Hashable {
        let departure: Date
        let arrival: Date
    }

    static func trips(_ d: Direction, on day: Date) -> [Trip] {
        let cal = Calendar.current
        let travel = Double(CommuteSettings.travelMinutes) * 60
        return times(d, on: day).compactMap { t in
            let p = t.split(separator: ":").compactMap { Int($0) }
            guard p.count == 2, let dep = cal.date(bySettingHour: p[0], minute: p[1], second: 0, of: day) else { return nil }
            return Trip(departure: dep, arrival: dep.addingTimeInterval(travel))
        }
    }
}

enum CommuteSettings {
    private static var d: UserDefaults { .standard }
    static var enabled: Bool { d.object(forKey: "commute.enabled") as? Bool ?? true }
    static var walkMinutes: Int { let v = d.integer(forKey: "commute.walk"); return v == 0 ? 15 : v }
    static var homeMinutes: Int { let v = d.integer(forKey: "commute.home"); return v == 0 ? 10 : v }
    static var travelMinutes: Int { let v = d.integer(forKey: "commute.travel"); return v == 0 ? 90 : v }
    static var notify: Bool { d.object(forKey: "commute.notify") as? Bool ?? true }
}

enum CommutePlanner {
    /// Последний автобус из Северодвинска, с которым успеваешь к первой паре
    static func morning(for first: LessonSlot) -> Bus150.Trip? {
        let walk = Double(CommuteSettings.walkMinutes) * 60
        let trips = Bus150.trips(.toArkhangelsk, on: first.start)
        return trips.last { $0.arrival.addingTimeInterval(walk) <= first.start }
    }

    /// Ближайшие автобусы домой после пар
    static func afterClasses(from time: Date, count: Int = 3) -> [Bus150.Trip] {
        let walk = Double(CommuteSettings.walkMinutes) * 60
        let ready = time.addingTimeInterval(walk)
        return Array(Bus150.trips(.toSeverodvinsk, on: time).filter { $0.departure >= ready }.prefix(count))
    }

    static func firstPair(on day: Date, data: ScheduleData) -> LessonSlot? {
        ScheduleEngine.slots(on: day, data: data).first { !AddressFormat.isRemote($0.address) }
    }

    static func lastPair(on day: Date, data: ScheduleData) -> LessonSlot? {
        ScheduleEngine.slots(on: day, data: data).last { !AddressFormat.isRemote($0.address) }
    }

    /// Напоминания «пора выходить» на неделю вперёд
    static func scheduleNotifications(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        let on = CommuteSettings.enabled && CommuteSettings.notify
        let home = Double(CommuteSettings.homeMinutes) * 60
        center.getPendingNotificationRequests { reqs in
            center.removePendingNotificationRequests(withIdentifiers: reqs.map(\.identifier).filter { $0.hasPrefix("commute-") })
            guard on else { return }
            let cal = Calendar.current
            for offset in 0..<7 {
                guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: Date())),
                      let first = firstPair(on: day, data: data),
                      let trip = morning(for: first) else { continue }
                let fire = trip.departure.addingTimeInterval(-home - 10 * 60)
                guard fire > Date() else { continue }
                let c = UNMutableNotificationContent()
                c.title = "Через 10 мин выходи 🚌"
                c.body = "Автобус 150 в \(hmString(trip.departure)) с о. Ягры. Пара «\(first.lesson.subject)» в \(hmString(first.start))."
                c.sound = .default
                let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                center.add(UNNotificationRequest(identifier: "commute-\(offset)", content: c,
                                                 trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)))
            }
        }
    }
}

func hmString(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

private func minutesText(_ m: Int) -> String {
    if m < 60 { return "\(m) мин" }
    return "\(m / 60) ч \(m % 60) мин"
}

// MARK: - Карточка «Дорога» на главной

struct CommuteCard: View {
    let data: ScheduleData

    var body: some View {
        TimelineView(.periodic(from: .now, by: 30)) { ctx in
            content(now: ctx.date)
        }
    }

    @ViewBuilder
    private func content(now: Date) -> some View {
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        let first = CommutePlanner.firstPair(on: today, data: data)
        let last = CommutePlanner.lastPair(on: today, data: data)

        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                Image(systemName: "bus.fill")
                Text("АВТОБУС 150")
            }
            .font(.caption.weight(.heavy))
            .foregroundStyle(Color.brand)

            if let f = first, now < f.start, let trip = CommutePlanner.morning(for: f) {
                morning(trip: trip, pair: f, now: now, title: "Сегодня в пары")
            } else if let l = last, now < l.end.addingTimeInterval(4 * 3600) {
                home(after: max(now, l.end), lastEnd: l.end, now: now)
            } else if let next = nextStudyDay(after: today), let f = CommutePlanner.firstPair(on: next, data: data),
                      let trip = CommutePlanner.morning(for: f) {
                morning(trip: trip, pair: f, now: now, title: cal.isDateInTomorrow(next) ? "Завтра" : dayName(next))
            } else {
                Text("На ближайшую неделю поездок нет")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .glass(24)
    }

    private func nextStudyDay(after today: Date) -> Date? {
        let cal = Calendar.current
        for i in 1..<8 {
            if let d = cal.date(byAdding: .day, value: i, to: today), CommutePlanner.firstPair(on: d, data: data) != nil { return d }
        }
        return nil
    }

    private func dayName(_ d: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EEEE"
        return f.string(from: d).capitalizedFirst
    }

    private func morning(trip: Bus150.Trip, pair: LessonSlot, now: Date, title: String) -> some View {
        let leave = trip.departure.addingTimeInterval(-Double(CommuteSettings.homeMinutes) * 60)
        let mins = Int(leave.timeIntervalSince(now) / 60)
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                Spacer()
                if mins >= 0 && mins < 180 {
                    Text(mins == 0 ? "выходи сейчас" : "выйти через \(minutesText(mins))")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(mins <= 10 ? Color.orange : Color.brand)
                }
            }
            Text("Автобус в \(hmString(trip.departure))")
                .font(.system(.title3, design: .rounded).weight(.bold))
            Text("\(Bus150.fromStop) → \(Bus150.toStop) ~\(hmString(trip.arrival)) · пара в \(hmString(pair.start))")
                .font(.caption)
                .foregroundStyle(.secondary)
            Text("Выйти из дома в \(hmString(leave))")
                .font(.caption.weight(.semibold))
        }
    }

    private func home(after time: Date, lastEnd: Date, now: Date) -> some View {
        let buses = CommutePlanner.afterClasses(from: time)
        return VStack(alignment: .leading, spacing: 6) {
            Text(now < lastEnd ? "После пар (конец в \(hmString(lastEnd)))" : "Домой в Северодвинск")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
            if let b = buses.first {
                HStack(alignment: .firstTextBaseline) {
                    Text("Автобус в \(hmString(b.departure))")
                        .font(.system(.title3, design: .rounded).weight(.bold))
                    Spacer()
                    let m = Int(b.departure.timeIntervalSince(now) / 60)
                    Text(m <= 0 ? "уходит" : "через \(minutesText(m))")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(m <= 15 ? Color.orange : Color.brand)
                }
                Text("от \(Bus150.toStop), дома ~\(hmString(b.arrival))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if buses.count > 1 {
                    Text("Следующие: " + buses.dropFirst().map { hmString($0.departure) }.joined(separator: ", "))
                        .font(.caption.weight(.semibold))
                }
            } else {
                Text("Сегодня автобусов домой больше нет")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.orange)
            }
        }
    }
}

// MARK: - Настройки дороги

struct CommuteSettingsView: View {
    @AppStorage("commute.enabled") private var enabled = true
    @AppStorage("commute.walk") private var walk = 15
    @AppStorage("commute.home") private var home = 10
    @AppStorage("commute.travel") private var travel = 90
    @AppStorage("commute.notify") private var notify = true
    @EnvironmentObject private var schedule: ScheduleStore

    var body: some View {
        Form {
            Section {
                Toggle("Показывать дорогу", isOn: $enabled)
                Toggle("Напоминать, когда выходить", isOn: $notify)
            } footer: {
                Text("Маршрут: автобус 150, Северодвинск (о. Ягры) ⇄ Архангельск (м.р. вокзал). Расписание пн–пт, сб и вс из твоего PDF.")
            }
            Section("Время") {
                Stepper("До остановки из дома: \(home) мин", value: $home, in: 0...60, step: 5)
                Stepper("В пути на автобусе: \(travel) мин", value: $travel, in: 60...150, step: 5)
                Stepper("От вокзала до корпуса: \(walk) мин", value: $walk, in: 0...60, step: 5)
            }
            Section("Расписание сегодня") {
                Text("В Архангельск: " + Bus150.times(.toArkhangelsk, on: Date()).joined(separator: " "))
                    .font(.caption)
                Text("В Северодвинск: " + Bus150.times(.toSeverodvinsk, on: Date()).joined(separator: " "))
                    .font(.caption)
            }
        }
        .navigationTitle("Дорога")
        .onDisappear { schedule.refreshSideEffects() }
    }
}
