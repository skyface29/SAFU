import SwiftUI
import PhotosUI
import WidgetKit

// MARK: - Настройка «прозрачного» виджета
// Скриншот пустого экрана «Домой» → рамка размера виджета → двигаешь её на место виджета → «Сохранить».
// Виджет «Пары · Прозрачный» рисует этот кусок обоев фоном и выглядит прозрачным.

struct WidgetWallpaperView: View {
    @State private var item: PhotosPickerItem?
    @State private var image: UIImage?
    @State private var family = "small"
    /// Центр рамки в долях скриншота (0…1)
    @State private var center = CGPoint(x: 0.28, y: 0.30)
    @State private var dragStart: CGPoint?
    @State private var scale = 1.0
    @State private var result: String?

    private var screen: CGSize { UIScreen.main.bounds.size }

    /// Примерный размер виджета в точках экрана; ползунок подгоняет точно
    private var widgetSize: CGSize {
        let w = screen.width
        let small = w * 0.402
        switch family {
        case "medium": return CGSize(width: w * 0.86, height: small)
        case "large": return CGSize(width: w * 0.86, height: small * 2.24)
        default: return CGSize(width: small, height: small)
        }
    }

    /// Рамка в долях скриншота (скриншот = весь экран)
    private var frameN: CGSize {
        CGSize(width: widgetSize.width * scale / screen.width, height: widgetSize.height * scale / screen.height)
    }

    var body: some View {
        Form {
            Section {
                InfoRow(icon: "1.circle.fill", text: "Удержи экран «Домой» → листай вправо до пустой страницы → сделай скриншот (без иконок).")
                InfoRow(icon: "2.circle.fill", text: "Выбери скриншот ниже и размер виджета.")
                InfoRow(icon: "3.circle.fill", text: "Двигай рамку туда, где стоит виджет, ползунком подгони размер → «Сохранить».")
                InfoRow(icon: "4.circle.fill", text: "Добавь виджет «Пары · Прозрачный» (в галерее САФУ листай вбок).")
            } header: {
                Text("Как сделать")
            }

            Section {
                PhotosPicker(selection: $item, matching: .screenshots) {
                    Label(image == nil ? "Выбрать скриншот" : "Другой скриншот", systemImage: "photo.on.rectangle")
                }
                Picker("Размер виджета", selection: $family) {
                    Text("Маленький").tag("small")
                    Text("Средний").tag("medium")
                    Text("Большой").tag("large")
                }
                .pickerStyle(.segmented)
            }

            if let image {
                Section {
                    editor(image)
                        .listRowInsets(EdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8))
                    HStack {
                        Image(systemName: "minus.magnifyingglass").foregroundStyle(.secondary)
                        Slider(value: $scale, in: 0.85...1.15)
                        Image(systemName: "plus.magnifyingglass").foregroundStyle(.secondary)
                    }
                    Button {
                        save(image)
                    } label: {
                        Label("Сохранить для \(familyTitle) виджета", systemImage: "checkmark.circle.fill")
                    }
                } header: {
                    Text("Совмести рамку с местом виджета")
                } footer: {
                    if let result { Text(result) }
                }
            }

            Section {
                Button(role: .destructive) {
                    WidgetWallpaper.remove(family: family)
                    WidgetCenter.shared.reloadAllTimelines()
                    result = "Фон \(familyTitle) виджета убран"
                } label: {
                    Label("Убрать фон \(familyTitle) виджета", systemImage: "trash")
                }
            } footer: {
                Text("Для каждого размера — свой кусок обоев. Сменил обои или переставил виджет — сделай заново.")
            }
        }
        .navigationTitle("Прозрачный виджет")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: item) { new in
            guard let new else { return }
            Task {
                if let data = try? await new.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                    await MainActor.run { image = img; result = nil }
                }
            }
        }
        .onChange(of: family) { _ in result = nil }
    }

    private var familyTitle: String {
        switch family {
        case "medium": return "среднего"
        case "large": return "большого"
        default: return "маленького"
        }
    }

    private func editor(_ img: UIImage) -> some View {
        let aspect = img.size.height / max(img.size.width, 1)
        return GeometryReader { geo in
            let w = geo.size.width
            let h = w * aspect
            let fw = frameN.width * w
            let fh = frameN.height * h
            ZStack(alignment: .topLeading) {
                Image(uiImage: img)
                    .resizable()
                    .frame(width: w, height: h)
                    .overlay(Color.black.opacity(0.35))
                // рамка виджета: внутри — без затемнения
                Image(uiImage: img)
                    .resizable()
                    .frame(width: w, height: h)
                    .mask(
                        RoundedRectangle(cornerRadius: fw * 0.13, style: .continuous)
                            .frame(width: fw, height: fh)
                            .position(x: center.x * w, y: center.y * h)
                    )
                RoundedRectangle(cornerRadius: fw * 0.13, style: .continuous)
                    .strokeBorder(Color.white, lineWidth: 2)
                    .frame(width: fw, height: fh)
                    .position(x: center.x * w, y: center.y * h)
                    .shadow(radius: 3)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture()
                    .onChanged { v in
                        let start = dragStart ?? center
                        if dragStart == nil { dragStart = center }
                        let x = start.x + v.translation.width / w
                        let y = start.y + v.translation.height / h
                        center = CGPoint(x: min(max(x, frameN.width / 2), 1 - frameN.width / 2),
                                         y: min(max(y, frameN.height / 2), 1 - frameN.height / 2))
                    }
                    .onEnded { _ in dragStart = nil }
            )
        }
        .aspectRatio(1 / aspect, contentMode: .fit)
    }

    private func save(_ img: UIImage) {
        guard let cg = img.cgImage else { return }
        let pw = CGFloat(cg.width), ph = CGFloat(cg.height)
        let rect = CGRect(x: (center.x - frameN.width / 2) * pw, y: (center.y - frameN.height / 2) * ph,
                          width: frameN.width * pw, height: frameN.height * ph).integral
        guard let piece = cg.cropping(to: rect) else { return }
        let r = WidgetWallpaper.save(UIImage(cgImage: piece), family: family)
        WidgetCenter.shared.reloadAllTimelines()
        Haptics.success()
        if r.folder || r.keychain {
            result = "Сохранено. Виджет «Пары · Прозрачный» \(familyTitle) размера обновится через несколько секунд."
        } else {
            result = "Не удалось передать картинку виджету: подпись приложения не даёт общих данных."
        }
    }
}
