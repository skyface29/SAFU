import SwiftUI
import UIKit

// MARK: - Загрузки с сайтов — как в браузере
// Скачал файл с сайта → сразу открывается «Поделиться»: оттуда «Сохранить в Файлы» (в свои папки iPhone),
// в Telegram или на почту. Всё скачанное — за кнопкой «Загрузки» в нижней панели сайта (как в Safari):
// пока качается — на кнопке кольцо прогресса, внутри — список, где файл можно сразу открыть или отправить.
// Ленты над страницей больше нет: она отнимала место у сайта и перерисовывалась на каждый процент.
// Открытый на странице файл приложение не навязывает: на кнопке точка, «Скачать» — в списке и в меню «⋯».

/// Скачанный файл в списке загрузок
struct WebDownload: Identifiable, Codable, Equatable {
    var id = UUID()
    /// Путь внутри «Файлов» приложения — относительно папки документов, так он переживает обновления
    var path: String
    var name: String
    /// Откуда скачан: по нему видно, что открытый на странице файл уже скачан
    var source: String
    var date = Date()

    var url: URL { FileService.root.appendingPathComponent(path) }
    var exists: Bool { FileManager.default.fileExists(atPath: url.path) }

    /// Значок по типу файла
    var icon: String { WebDownload.icon(for: (name as NSString).pathExtension) }

    static func icon(for ext: String) -> String {
        switch ext.lowercased() {
        case "pdf", "djvu", "djv", "epub", "fb2": return "doc.richtext"
        case "doc", "docx", "rtf", "odt", "txt": return "doc.text"
        case "xls", "xlsx", "ods", "csv": return "tablecells"
        case "ppt", "pptx", "pps", "ppsx", "odp": return "rectangle.on.rectangle"
        case "jpg", "jpeg", "png", "heic", "gif", "webp": return "photo"
        case "mp3", "m4a", "wav", "ogg": return "waveform"
        case "mp4", "mov", "m4v", "avi": return "film"
        case "zip", "rar", "7z": return "doc.zipper"
        default: return "doc"
        }
    }
}

/// Идущее сейчас скачивание
struct WebDownloadProgress: Identifiable, Equatable {
    let id: ObjectIdentifier
    var name: String
    var progress: Double
}

/// Все загрузки с сайтов приложения (общие для всех сайтов, как в браузере)
final class WebDownloads: ObservableObject {
    static let shared = WebDownloads()
    private let key = "web.downloads.v1"
    static let limit = 100

    @Published private(set) var items: [WebDownload] = []
    @Published private(set) var active: [WebDownloadProgress] = []
    /// Размеры файлов: считаем один раз при открытии списка, а не на каждой перерисовке
    private(set) var sizes: [UUID: Int64] = [:]

    private init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([WebDownload].self, from: raw) {
            items = list
        }
        prune()
    }

    /// Удалённые и переименованные в «Файлах» — из списка убираем (раньше это проверялось
    /// для каждого файла на каждой перерисовке ленты). Диск проверяется в фоне: при первом открытии
    /// сайта это было до сотни обращений к файлам прямо на главном потоке (рывок до 120 мс)
    func prune() {
        let files = items.map { ($0.id, $0.url.path) }
        guard !files.isEmpty else { return }
        DispatchQueue.global(qos: .utility).async {
            var sizes: [UUID: Int64] = [:]
            var gone = Set<UUID>()
            for (id, path) in files {
                if let a = try? FileManager.default.attributesOfItem(atPath: path) {
                    sizes[id] = (a[.size] as? NSNumber)?.int64Value ?? 0
                } else {
                    gone.insert(id)
                }
            }
            DispatchQueue.main.async {
                self.sizes.merge(sizes) { _, new in new }
                if gone.isEmpty {
                    self.objectWillChange.send()   // список загрузок покажет размеры
                } else {
                    for id in gone { self.sizes[id] = nil }
                    self.items.removeAll { gone.contains($0.id) }
                    self.save()
                }
            }
        }
    }

    // MARK: идущие скачивания

    func begin(_ id: ObjectIdentifier, name: String) {
        guard !active.contains(where: { $0.id == id }) else { return }
        active.append(WebDownloadProgress(id: id, name: name, progress: 0))
    }

    func rename(_ id: ObjectIdentifier, _ name: String) {
        if let i = active.firstIndex(where: { $0.id == id }) { active[i].name = name }
    }

    /// Доля скачанного: обновляем по процентам, а не на каждый пришедший кусок
    func update(_ id: ObjectIdentifier, progress: Double) {
        guard let i = active.firstIndex(where: { $0.id == id }),
              abs(active[i].progress - progress) >= 0.01 || progress >= 1 else { return }
        active[i].progress = progress
    }

    func end(_ id: ObjectIdentifier) {
        active.removeAll { $0.id == id }
    }

    // MARK: список

    func add(_ file: URL, source: URL?) {
        let root = FileService.path(FileService.root)
        let full = FileService.path(file)
        let rel = full.hasPrefix(root + "/") ? String(full.dropFirst(root.count + 1)) : file.lastPathComponent
        items.removeAll { $0.path == rel }
        let d = WebDownload(path: rel, name: file.lastPathComponent, source: source?.absoluteString ?? "")
        sizes[d.id] = ((try? FileManager.default.attributesOfItem(atPath: file.path))?[.size] as? NSNumber)?.int64Value
        items.insert(d, at: 0)
        if items.count > Self.limit { items.removeLast(items.count - Self.limit) }
        save()
    }

    func remove(_ d: WebDownload) {
        items.removeAll { $0.id == d.id }
        save()
    }

    func clear() {
        items = []
        save()
    }

    /// Этот адрес уже скачивали, и файл на месте
    func downloaded(_ source: URL) -> WebDownload? {
        let s = source.absoluteString
        return items.first { $0.source == s && $0.exists }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(items) { UserDefaults.standard.set(raw, forKey: key) }
    }
}

// MARK: - «Поделиться» для файлов

enum FileShare {
    /// Сразу после скачивания открывать «Поделиться»
    static var afterDownload: Bool { UserDefaults.standard.object(forKey: "web.shareAfterDownload") as? Bool ?? true }

    /// Открывает «Поделиться» поверх того, что сейчас на экране (карточки сайта или окна).
    /// false — показать не получилось (уже открыто другое «Поделиться» или окно закрывается)
    @discardableResult
    static func present(_ urls: [URL]) -> Bool {
        let files = urls.filter { FileManager.default.fileExists(atPath: $0.path) }
        guard !files.isEmpty else { return true }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first,
              let window = scene.windows.first(where: { $0.isKeyWindow }) ?? scene.windows.first,
              var top = window.rootViewController else { return false }
        while let p = top.presentedViewController { top = p }
        if top is UIActivityViewController || top.isBeingDismissed || top.isBeingPresented { return false }
        let vc = UIActivityViewController(activityItems: files, applicationActivities: nil)
        if let pop = vc.popoverPresentationController {
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.maxY - 60, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        top.present(vc, animated: true)
        return true
    }
}

// MARK: - Кнопка «Загрузки» в нижней панели сайта

/// Как в Safari: пока качается — кольцо прогресса вокруг стрелки, открыт ещё не скачанный файл — точка.
/// Страницу не наблюдает (у неё прогресс загрузки меняется постоянно) — только список загрузок и открытый файл
struct WebDownloadsButton: View {
    let model: WebModel
    let pageFile: WebFile?
    /// Сайт в карточке: скачанное открывается карточкой поверх
    let embedded: Bool
    @ObservedObject private var store = WebDownloads.shared
    @State private var showAll = false

    var body: some View {
        let busy = !store.active.isEmpty
        let label: String = busy ? "Загрузки, \(Int(progress * 100))%" : "Загрузки"
        Button {
            Haptics.tap()
            showAll = true
        } label: {
            ZStack {
                if busy {
                    Circle()
                        .stroke(Color.brand.opacity(0.2), lineWidth: 2.5)
                    Circle()
                        .trim(from: 0, to: max(0.04, progress))
                        .stroke(Color.brand, style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .animation(.easeOut(duration: 0.25), value: progress)
                    Image(systemName: "arrow.down")
                        .font(.system(size: 11, weight: .bold))
                } else {
                    Image(systemName: "arrow.down.circle")
                        .font(.system(size: 19, weight: .medium))
                }
            }
            .frame(width: 22, height: 22)
            .frame(width: 44, height: 44)
            .overlay(alignment: .topTrailing) {
                if hint {
                    Circle()
                        .fill(Color.brand)
                        .frame(width: 7, height: 7)
                        .offset(x: -7, y: 9)
                        .transition(.scale.combined(with: .opacity))
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(Color.brand)
        .frame(maxWidth: .infinity)
        .animation(.spring(response: 0.3, dampingFraction: 0.82), value: busy)
        .animation(.spring(response: 0.3, dampingFraction: 0.82), value: hint)
        .accessibilityLabel(label)
        .sheet(isPresented: $showAll) {
            WebDownloadsSheet(model: model, pageFile: pageFile, embedded: embedded)
        }
    }

    /// Средний процент всех идущих скачиваний
    private var progress: Double {
        guard !store.active.isEmpty else { return 0 }
        return store.active.reduce(0) { $0 + $1.progress } / Double(store.active.count)
    }

    /// На странице открыт файл, который ещё не скачан
    private var hint: Bool {
        guard let f = pageFile, store.active.isEmpty else { return false }
        return store.downloaded(f.url) == nil
    }
}

// MARK: - Список загрузок

/// Все загрузки, как в браузере: нажал — открыл, кнопка справа — «Поделиться», смахнул — убрал из списка
/// (сам файл остаётся в «Файлах» приложения). Сверху — то, что качается сейчас, и файл с открытой страницы
struct WebDownloadsSheet: View {
    let model: WebModel?
    var pageFile: WebFile? = nil
    let embedded: Bool
    @ObservedObject private var store = WebDownloads.shared
    @AppStorage("web.shareAfterDownload") private var shareAfter = true
    @Environment(\.dismiss) private var dismiss
    @State private var preview: URL? = nil

    var body: some View {
        NavigationStack {
            List {
                if !store.active.isEmpty {
                    Section("Скачивается") {
                        ForEach(store.active) { a in activeRow(a) }
                    }
                }
                if let f = pageFile, let model {
                    Section("На этой странице") { pageRow(f, model: model) }
                }
                if store.items.isEmpty {
                    if store.active.isEmpty && pageFile == nil {
                        Section {
                            VStack(spacing: 8) {
                                Image(systemName: "arrow.down.circle")
                                    .font(.system(size: 34, weight: .light))
                                    .foregroundStyle(Color.brand)
                                Text("Пока ничего не скачано").font(.headline)
                                Text("Файлы с сайтов появятся здесь: их можно открыть или сразу отправить.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 18)
                        }
                    }
                } else {
                    Section("Скачанное") {
                        ForEach(store.items) { d in fileRow(d) }
                    }
                }
                Section {
                    Toggle("Сразу открывать «Поделиться»", isOn: $shareAfter)
                } footer: {
                    Text("После скачивания сразу откроется «Поделиться» — там «Сохранить в Файлы», Telegram и почта. Копия файла всегда остаётся в «Файлах» приложения: в «Загрузках» или в папке предмета.")
                }
            }
            .animation(.spring(response: 0.32, dampingFraction: 0.86), value: store.items)
            .animation(.spring(response: 0.32, dampingFraction: 0.86), value: store.active.map(\.id))
            .navigationTitle("Загрузки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } }
                if !store.items.isEmpty {
                    ToolbarItem(placement: .destructiveAction) {
                        Button("Очистить") { store.clear() }
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .onAppear { store.prune() }
        .filePreview($preview)
    }

    private func activeRow(_ a: WebDownloadProgress) -> some View {
        HStack(spacing: 12) {
            Image(systemName: WebDownload.icon(for: (a.name as NSString).pathExtension))
                .font(.title3)
                .foregroundStyle(Color.brand)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 6) {
                Text(a.name).lineLimit(1).truncationMode(.middle)
                ProgressView(value: max(0.02, a.progress))
                    .tint(Color.brand)
                    .animation(.easeOut(duration: 0.25), value: a.progress)
            }
            Text("\(Int(a.progress * 100))%")
                .font(.caption.weight(.semibold))
                .monospacedDigit()
                .foregroundStyle(.secondary)
                .frame(minWidth: 36, alignment: .trailing)
        }
    }

    /// Файл, открытый на странице: не скачан — «Скачать», качается — кружок, скачан — открыть или отправить
    @ViewBuilder private func pageRow(_ f: WebFile, model: WebModel) -> some View {
        let done = store.downloaded(f.url)
        HStack(spacing: 12) {
            Image(systemName: WebDownload.icon(for: (f.name as NSString).pathExtension))
                .font(.title3)
                .foregroundStyle(Color.brand)
                .frame(width: 30)
            VStack(alignment: .leading, spacing: 2) {
                Text(f.name).lineLimit(2)
                if done != nil {
                    Label("Уже скачан", systemImage: "checkmark.circle.fill")
                        .font(.caption)
                        .foregroundStyle(.green)
                }
            }
            Spacer(minLength: 4)
            if let done {
                shareButton(done.url)
            } else if model.isDownloading(f.url) {
                ProgressView().controlSize(.small)
            } else {
                Button { model.save(f) } label: {
                    Text("Скачать")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 7)
                        .background(Color.brand, in: Capsule())
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Скачать \(f.name)")
            }
        }
        .contentShape(Rectangle())
        .onTapGesture { if let done { open(done) } }
    }

    private func fileRow(_ d: WebDownload) -> some View {
        HStack(spacing: 12) {
            Button { open(d) } label: {
                HStack(spacing: 12) {
                    Image(systemName: d.icon)
                        .font(.title3)
                        .foregroundStyle(Color.brand)
                        .frame(width: 30)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(d.name).lineLimit(2).foregroundStyle(.primary)
                        Text(subtitle(d)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                    }
                    Spacer(minLength: 4)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.borderless)
            .accessibilityLabel("Открыть \(d.name)")
            shareButton(d.url)
        }
        .swipeActions {
            Button(role: .destructive) { store.remove(d) } label: {
                Label("Убрать", systemImage: "xmark")
            }
        }
        .contextMenu {
            Button { open(d) } label: { Label("Открыть", systemImage: "doc.viewfinder") }
            Button { FileShare.present([d.url]) } label: {
                Label("Поделиться или сохранить в Файлы", systemImage: "square.and.arrow.up")
            }
            Button(role: .destructive) { store.remove(d) } label: {
                Label("Убрать из списка", systemImage: "xmark")
            }
        }
    }

    private func shareButton(_ url: URL) -> some View {
        Button { FileShare.present([url]) } label: {
            Image(systemName: "square.and.arrow.up")
                .font(.system(size: 17, weight: .medium))
                .foregroundStyle(Color.brand)
                .frame(width: 40, height: 40)
                .background(Color.brand.opacity(0.12), in: Circle())
        }
        .buttonStyle(.borderless)
        .accessibilityLabel("Поделиться")
    }

    /// Сайт в карточке — файл открывается карточкой поверх (сайт уходит в свёрнутые), в окне — просмотром
    private func open(_ d: WebDownload) {
        Haptics.tap()
        if embedded {
            dismiss()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { SiteTabs.shared.openFile(d.url) }
        } else {
            preview = d.url
        }
    }

    private func subtitle(_ d: WebDownload) -> String {
        let folder = (d.path as NSString).deletingLastPathComponent
        let place = folder.isEmpty ? "Файлы" : (folder as NSString).lastPathComponent
        let size = store.sizes[d.id].map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) } ?? ""
        let host = URL(string: d.source)?.host ?? ""
        return [size, place, Fmt.relative(d.date), host].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}
