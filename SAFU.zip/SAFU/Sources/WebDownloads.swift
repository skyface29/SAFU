import SwiftUI
import UIKit

// MARK: - Загрузки с сайтов — как в браузере
// Скачал файл с сайта → сразу открывается «Поделиться»: оттуда «Сохранить в Файлы» (в свои папки iPhone),
// в Telegram или на почту. Всё скачанное видно в мини-ленте над страницей — она есть на каждом сайте,
// пока в списке что-то лежит. Открытый на странице файл приложение больше не навязывает большой кнопкой:
// в ленте — маленькая «Скачать», а если файл уже скачан — «Скачан», без повторного предложения.

/// Скачанный файл в ленте загрузок
struct WebDownload: Identifiable, Codable, Equatable {
    var id = UUID()
    /// Путь внутри «Файлов» приложения — относительно папки документов, так он переживает обновления
    var path: String
    var name: String
    /// Откуда скачан: по нему видно, что открытый на странице файл уже скачан
    var source: String
    var date = Date()

    var url: URL { FileService.root.appendingPathComponent(path) }
    var exists: Bool { FileManager.default.fileExists(atPath: url.path) }

    /// Значок по типу файла
    var icon: String { WebDownload.icon(for: (name as NSString).pathExtension) }

    static func icon(for ext: String) -> String {
        switch ext.lowercased() {
        case "pdf", "djvu", "djv", "epub", "fb2": return "doc.richtext"
        case "doc", "docx", "rtf", "odt", "txt": return "doc.text"
        case "xls", "xlsx", "ods", "csv": return "tablecells"
        case "ppt", "pptx", "pps", "ppsx", "odp": return "rectangle.on.rectangle"
        case "jpg", "jpeg", "png", "heic", "gif", "webp": return "photo"
        case "mp3", "m4a", "wav", "ogg": return "waveform"
        case "mp4", "mov", "m4v", "avi": return "film"
        case "zip", "rar", "7z": return "doc.zipper"
        default: return "doc"
        }
    }
}

/// Идущее сейчас скачивание
struct WebDownloadProgress: Identifiable, Equatable {
    let id: ObjectIdentifier
    var name: String
    var progress: Double
}

/// Все загрузки с сайтов приложения (общие для всех сайтов, как в браузере)
final class WebDownloads: ObservableObject {
    static let shared = WebDownloads()
    private let key = "web.downloads.v1"
    static let limit = 40

    @Published private(set) var items: [WebDownload] = []
    @Published private(set) var active: [WebDownloadProgress] = []

    private init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([WebDownload].self, from: raw) {
            // удалённые и переименованные в «Файлах» — из списка убираем
            items = list.filter(\.exists)
        }
    }

    // MARK: идущие скачивания

    func begin(_ id: ObjectIdentifier, name: String) {
        guard !active.contains(where: { $0.id == id }) else { return }
        active.append(WebDownloadProgress(id: id, name: name, progress: 0))
    }

    func rename(_ id: ObjectIdentifier, _ name: String) {
        if let i = active.firstIndex(where: { $0.id == id }) { active[i].name = name }
    }

    /// Доля скачанного: обновляем по процентам, а не на каждый пришедший кусок
    func update(_ id: ObjectIdentifier, progress: Double) {
        guard let i = active.firstIndex(where: { $0.id == id }),
              abs(active[i].progress - progress) >= 0.01 || progress >= 1 else { return }
        active[i].progress = progress
    }

    func end(_ id: ObjectIdentifier) {
        active.removeAll { $0.id == id }
    }

    // MARK: список

    func add(_ file: URL, source: URL?) {
        let root = FileService.path(FileService.root)
        let full = FileService.path(file)
        let rel = full.hasPrefix(root + "/") ? String(full.dropFirst(root.count + 1)) : file.lastPathComponent
        items.removeAll { $0.path == rel }
        items.insert(WebDownload(path: rel, name: file.lastPathComponent, source: source?.absoluteString ?? ""), at: 0)
        if items.count > Self.limit { items.removeLast(items.count - Self.limit) }
        save()
    }

    func remove(_ d: WebDownload) {
        items.removeAll { $0.id == d.id }
        save()
    }

    func clear() {
        items = []
        save()
    }

    /// Этот адрес уже скачивали, и файл на месте
    func downloaded(_ source: URL) -> WebDownload? {
        let s = source.absoluteString
        return items.first { $0.source == s && $0.exists }
    }

    private func save() {
        if let raw = try? JSONEncoder().encode(items) { UserDefaults.standard.set(raw, forKey: key) }
    }
}

// MARK: - «Поделиться» для файлов

enum FileShare {
    /// Сразу после скачивания открывать «Поделиться»
    static var afterDownload: Bool { UserDefaults.standard.object(forKey: "web.shareAfterDownload") as? Bool ?? true }

    /// Открывает «Поделиться» поверх того, что сейчас на экране (карточки сайта или окна).
    /// false — показать не получилось (уже открыто другое «Поделиться» или окно закрывается)
    @discardableResult
    static func present(_ urls: [URL]) -> Bool {
        let files = urls.filter { FileManager.default.fileExists(atPath: $0.path) }
        guard !files.isEmpty else { return true }
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        guard let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first,
              let window = scene.windows.first(where: { $0.isKeyWindow }) ?? scene.windows.first,
              var top = window.rootViewController else { return false }
        while let p = top.presentedViewController { top = p }
        if top is UIActivityViewController || top.isBeingDismissed || top.isBeingPresented { return false }
        let vc = UIActivityViewController(activityItems: files, applicationActivities: nil)
        if let pop = vc.popoverPresentationController {
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.maxY - 60, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        top.present(vc, animated: true)
        return true
    }
}

// MARK: - Мини-лента загрузок над страницей

struct WebDownloadsBar: View {
    @ObservedObject var model: WebModel
    /// Сайт в карточке: скачанное можно открыть карточкой поверх
    let embedded: Bool
    @ObservedObject private var store = WebDownloads.shared
    @State private var showAll = false

    var body: some View {
        let files = store.items.filter(\.exists)
        if !files.isEmpty || !store.active.isEmpty || model.pageFile != nil {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    Button { showAll = true } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.down.circle.fill")
                            if !files.isEmpty { Text("\(files.count)").monospacedDigit() }
                        }
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(Color.brand)
                        .padding(.horizontal, 10)
                        .frame(height: 28)
                        .background(Color.brand.opacity(0.14), in: Capsule())
                    }
                    .accessibilityLabel("Все загрузки")
                    ForEach(store.active) { a in
                        HStack(spacing: 6) {
                            ProgressView(value: max(0.02, a.progress))
                                .progressViewStyle(.circular)
                                .controlSize(.mini)
                            Text(a.name)
                                .lineLimit(1)
                                .truncationMode(.middle)
                                .frame(maxWidth: 130, alignment: .leading)
                            if a.progress > 0 {
                                Text("\(Int(a.progress * 100))%").monospacedDigit().foregroundStyle(.secondary)
                            }
                        }
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 10)
                        .frame(height: 28)
                        .background(Color.primary.opacity(0.06), in: Capsule())
                    }
                    if let f = model.pageFile { pageChip(f) }
                    ForEach(files.prefix(15)) { d in fileChip(d) }
                }
                .padding(.horizontal, 10)
            }
            .frame(height: 38)
            .frame(maxWidth: .infinity)
            .background(MiniChrome.headerColor)
            .overlay(alignment: .bottom) { MiniChrome.hairline }
            .animation(.spring(response: 0.32, dampingFraction: 0.86), value: store.items)
            .animation(.spring(response: 0.32, dampingFraction: 0.86), value: store.active)
            .sheet(isPresented: $showAll) {
                WebDownloadsSheet(embedded: embedded)
            }
        }
    }

    /// Файл, открытый на странице: не скачан — маленькая «Скачать», скачан — «Скачан» (нажал — «Поделиться»)
    @ViewBuilder private func pageChip(_ f: WebFile) -> some View {
        if let done = store.downloaded(f.url) {
            Button { FileShare.present([done.url]) } label: {
                Label("Скачан", systemImage: "checkmark.circle.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.green)
                    .padding(.horizontal, 10)
                    .frame(height: 28)
                    .background(Color.green.opacity(0.12), in: Capsule())
            }
        } else if !store.active.isEmpty && model.isDownloading(f.url) {
            EmptyView()
        } else {
            Button { model.save(f) } label: {
                Label("Скачать", systemImage: "arrow.down.to.line")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(Color.brand)
                    .padding(.horizontal, 10)
                    .frame(height: 28)
                    .overlay(Capsule().strokeBorder(Color.brand.opacity(0.5), lineWidth: 1))
            }
            .accessibilityLabel("Скачать \(f.name)")
        }
    }

    private func fileChip(_ d: WebDownload) -> some View {
        Button { FileShare.present([d.url]) } label: {
            HStack(spacing: 5) {
                Image(systemName: d.icon).foregroundStyle(Color.brand)
                Text(d.name)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .frame(maxWidth: 150, alignment: .leading)
                    .foregroundStyle(.primary)
            }
            .font(.caption.weight(.semibold))
            .padding(.horizontal, 10)
            .frame(height: 28)
            .background(Color.primary.opacity(0.06), in: Capsule())
        }
        .contextMenu {
            Button { FileShare.present([d.url]) } label: {
                Label("Поделиться или сохранить в Файлы", systemImage: "square.and.arrow.up")
            }
            if embedded {
                Button { SiteTabs.shared.openFile(d.url) } label: {
                    Label("Открыть", systemImage: "doc.viewfinder")
                }
            }
            Button(role: .destructive) { store.remove(d) } label: {
                Label("Убрать из списка", systemImage: "xmark")
            }
        }
    }
}

/// Все загрузки: нажал — «Поделиться», смахнул — убрал из списка (сам файл остаётся в «Файлах» приложения)
struct WebDownloadsSheet: View {
    let embedded: Bool
    @ObservedObject private var store = WebDownloads.shared
    @AppStorage("web.shareAfterDownload") private var shareAfter = true
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Toggle("Сразу открывать «Поделиться»", isOn: $shareAfter)
                } footer: {
                    Text("После скачивания сразу откроется «Поделиться» — там «Сохранить в Файлы», Telegram и почта. Копия файла всегда остаётся в «Файлах» приложения: в «Загрузках» или в папке предмета.")
                }
                let files = store.items.filter(\.exists)
                if files.isEmpty {
                    Text("Пока ничего не скачано").foregroundStyle(.secondary)
                } else {
                    Section("Скачанное") {
                        ForEach(files) { d in
                            Button { FileShare.present([d.url]) } label: {
                                HStack(spacing: 12) {
                                    Image(systemName: d.icon)
                                        .font(.title3)
                                        .foregroundStyle(Color.brand)
                                        .frame(width: 30)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(d.name).lineLimit(2).foregroundStyle(.primary)
                                        Text(subtitle(d)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                    Spacer(minLength: 4)
                                    Image(systemName: "square.and.arrow.up").foregroundStyle(.secondary)
                                }
                            }
                            .swipeActions {
                                Button(role: .destructive) { store.remove(d) } label: {
                                    Label("Убрать", systemImage: "xmark")
                                }
                            }
                            .contextMenu {
                                if embedded {
                                    Button {
                                        dismiss()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { SiteTabs.shared.openFile(d.url) }
                                    } label: {
                                        Label("Открыть", systemImage: "doc.viewfinder")
                                    }
                                }
                                Button(role: .destructive) { store.remove(d) } label: {
                                    Label("Убрать из списка", systemImage: "xmark")
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Загрузки")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } }
                if !store.items.isEmpty {
                    ToolbarItem(placement: .destructiveAction) {
                        Button("Очистить") { store.clear() }
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    private func subtitle(_ d: WebDownload) -> String {
        let folder = (d.path as NSString).deletingLastPathComponent
        let place = folder.isEmpty ? "Файлы" : (folder as NSString).lastPathComponent
        let host = URL(string: d.source)?.host ?? ""
        return [place, Fmt.relative(d.date), host].filter { !$0.isEmpty }.joined(separator: " · ")
    }
}
