import Foundation
import ActivityKit
import UserNotifications
import AppIntents

// MARK: - Live Activity: текущая/следующая пара на экране блокировки и в Dynamic Island

enum LiveActivityManager {
    static var enabled: Bool { UserDefaults.standard.object(forKey: "live.enabled") as? Bool ?? true }

    static func update(data: ScheduleData) {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        let now = Date()
        let r = ScheduleEngine.nowAndNext(at: now, data: data)

        var main: LessonSlot? = r.current
        var isNow = true
        if main == nil, let n = r.next, n.start.timeIntervalSince(now) < 90 * 60 {
            main = n
            isNow = false
        }

        guard enabled, let s = main else {
            endAll()
            return
        }

        let next: LessonSlot? = isNow
            ? r.next
            : ScheduleEngine.nowAndNext(at: s.start.addingTimeInterval(60), data: data).next
        let sameDayNext = next.flatMap { Calendar.current.isDate($0.start, inSameDayAs: s.start) ? $0 : nil }

        let state = PairActivityAttributes.ContentState(
            subject: s.lesson.subject, kind: s.lesson.kind, room: s.lesson.room, address: s.address,
            teacher: s.lesson.teacher, start: s.start, end: s.end, isNow: isNow, pair: s.lesson.pair,
            nextSubject: sameDayNext?.lesson.subject ?? "", nextRoom: sameDayNext?.lesson.room ?? "",
            nextStart: sameDayNext?.start,
            theme: UserDefaults.standard.string(forKey: "live.theme") ?? LiveTheme.night.rawValue,
            layout: UserDefaults.standard.string(forKey: "live.layout") ?? LiveLayout.full.rawValue)
        let content = ActivityContent(state: state, staleDate: isNow ? s.end : s.start.addingTimeInterval(15 * 60))

        let existing = Activity<PairActivityAttributes>.activities
        Task {
            if let a = existing.first {
                await a.update(content)
                for extra in existing.dropFirst() { await extra.end(nil, dismissalPolicy: .immediate) }
            } else {
                _ = try? Activity.request(attributes: PairActivityAttributes(group: data.ruzGroupNumber),
                                          content: content, pushType: nil)
            }
        }
    }

    static func endAll() {
        let all = Activity<PairActivityAttributes>.activities
        guard !all.isEmpty else { return }
        Task {
            for a in all { await a.end(nil, dismissalPolicy: .immediate) }
        }
    }
}

// MARK: - Напоминания перед парами

enum PairNotifier {
    static var enabled: Bool { UserDefaults.standard.object(forKey: "notify.pairs") as? Bool ?? true }
    static var minutes: Int {
        let v = UserDefaults.standard.integer(forKey: "notify.pairMinutes")
        return v == 0 ? 10 : v
    }

    static func reschedule(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        let on = enabled
        let mins = minutes
        center.getPendingNotificationRequests { reqs in
            let old = reqs.map(\.identifier).filter { $0.hasPrefix("pair-") }
            center.removePendingNotificationRequests(withIdentifiers: old)
            guard on else { return }
            let now = Date()
            let cal = Calendar.current
            var count = 0
            for offset in 0..<7 {
                guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: now)) else { continue }
                for s in ScheduleEngine.slots(on: day, data: data) {
                    let fire = s.start.addingTimeInterval(-Double(mins) * 60)
                    guard fire > now, count < 40 else { continue }
                    let c = UNMutableNotificationContent()
                    c.title = "Через \(mins) мин: \(s.lesson.subject)"
                    c.body = [s.lesson.kind, s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)", s.address]
                        .filter { !$0.isEmpty }.joined(separator: " · ")
                    c.sound = .default
                    let comps = cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                    let req = UNNotificationRequest(identifier: "pair-\(Int(s.start.timeIntervalSince1970))-\(count)",
                                                    content: c,
                                                    trigger: UNCalendarNotificationTrigger(dateMatching: comps, repeats: false))
                    center.add(req)
                    count += 1
                }
            }
        }
    }
}

// MARK: - Изменения расписания

struct ScheduleChange: Codable, Identifiable, Hashable {
    var id = UUID()
    var date: Date
    var text: String
}

enum ChangeDetector {
    private static func key(_ s: LessonSlot) -> String {
        "\(Int(s.start.timeIntervalSince1970))|\(s.lesson.subject.lowercased())"
    }

    static func upcoming(_ data: ScheduleData, days: Int = 14) -> [String: LessonSlot] {
        var result: [String: LessonSlot] = [:]
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())
        for offset in 0..<days {
            guard let d = cal.date(byAdding: .day, value: offset, to: today) else { continue }
            for s in ScheduleEngine.slots(on: d, data: data) where s.end > Date() {
                result[key(s)] = s
            }
        }
        return result
    }

    static func diff(before: [String: LessonSlot], after: [String: LessonSlot]) -> [ScheduleChange] {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EE d MMM, H:mm"
        var out: [ScheduleChange] = []
        for (k, s) in before where after[k] == nil {
            out.append(ScheduleChange(date: s.start, text: "Отменена: \(s.lesson.subject), \(f.string(from: s.start))"))
        }
        for (k, s) in after {
            if let old = before[k] {
                if old.lesson.room != s.lesson.room || old.address != s.address {
                    let from = old.lesson.room.isEmpty ? "—" : old.lesson.room
                    let to = s.lesson.room.isEmpty ? "—" : s.lesson.room
                    out.append(ScheduleChange(date: s.start,
                                              text: "Новая аудитория: \(s.lesson.subject), \(f.string(from: s.start)): \(from) → \(to)"))
                }
            } else {
                out.append(ScheduleChange(date: s.start,
                                          text: "Добавлена: \(s.lesson.subject), \(f.string(from: s.start))\(s.lesson.room.isEmpty ? "" : ", ауд. \(s.lesson.room)")"))
            }
        }
        return out.sorted { $0.date < $1.date }
    }

    static func notify(_ changes: [ScheduleChange]) {
        guard !changes.isEmpty,
              UserDefaults.standard.object(forKey: "notify.changes") as? Bool ?? true else { return }
        let c = UNMutableNotificationContent()
        c.title = "Расписание изменилось (\(changes.count))"
        c.body = changes.prefix(3).map(\.text).joined(separator: "\n")
        c.sound = .default
        UNUserNotificationCenter.current().add(
            UNNotificationRequest(identifier: "changes-\(UUID().uuidString)", content: c, trigger: nil))
    }
}

// MARK: - Siri и «Быстрые команды»

struct NextPairIntent: AppIntent {
    static let title: LocalizedStringResource = "Следующая пара"
    static let description = IntentDescription("Какая пара сейчас или следующая, аудитория и адрес.")

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let data = SharedSchedule.load()
        let r = ScheduleEngine.nowAndNext(at: Date(), data: data)
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "H:mm"
        func place(_ s: LessonSlot) -> String {
            [s.lesson.room.isEmpty ? "" : "аудитория \(s.lesson.room)", s.address]
                .filter { !$0.isEmpty }.joined(separator: ", ")
        }
        let text: String
        if let c = r.current {
            text = "Сейчас \(c.lesson.subject) до \(f.string(from: c.end)). \(place(c))."
        } else if let n = r.next {
            let day = Calendar.current.isDateInToday(n.start) ? "" : (Calendar.current.isDateInTomorrow(n.start) ? "завтра " : "")
            text = "Следующая пара \(day)в \(f.string(from: n.start)): \(n.lesson.subject). \(place(n))."
        } else {
            text = "Ближайших пар нет."
        }
        return .result(dialog: "\(text)")
    }
}

struct SAFUShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: NextPairIntent(),
                    phrases: ["Следующая пара в \(.applicationName)",
                              "Какая пара в \(.applicationName)",
                              "Где пара в \(.applicationName)"],
                    shortTitle: "Следующая пара",
                    systemImageName: "calendar")
        AppShortcut(intent: NextBusIntent(),
                    phrases: ["Автобус в \(.applicationName)",
                              "Когда автобус \(.applicationName)"],
                    shortTitle: "Автобус 150",
                    systemImageName: "bus.fill")
    }
}


// MARK: - Итоги недели (воскресенье, 19:00)

enum WeeklyDigest {
    static var enabled: Bool { UserDefaults.standard.object(forKey: "notify.digest") as? Bool ?? true }

    static func schedule(data: ScheduleData) {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["digest"])
        guard enabled else { return }
        let cal = Calendar.current
        // ближайшее воскресенье 19:00
        var comps = DateComponents()
        comps.weekday = 1
        comps.hour = 19
        comps.minute = 0
        guard let fire = cal.nextDate(after: Date(), matching: comps, matchingPolicy: .nextTime),
              let monday = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: fire)) else { return }

        var slots: [LessonSlot] = []
        for i in 0..<6 {
            if let d = cal.date(byAdding: .day, value: i, to: monday) { slots += ScheduleEngine.slots(on: d, data: data) }
        }
        let labs = slots.filter { $0.lesson.kind.lowercased().hasPrefix("лаб") }.count
        let exams = slots.filter { let k = $0.lesson.kind.lowercased(); return k.contains("экзам") || k.contains("зач") }
        let weekEnd = monday.addingTimeInterval(7 * 86_400)
        var dueCount = 0
        if let raw = UserDefaults.standard.data(forKey: "tasks.v1"),
           let tasks = try? JSONDecoder().decode([StudyTask].self, from: raw) {
            dueCount = tasks.filter { !$0.done && $0.due >= monday && $0.due < weekEnd }.count
        }
        var lines = ["Пар: \(slots.count), лабораторных: \(labs)"]
        if !exams.isEmpty { lines.append("Экзамены и зачёты: " + exams.map(\.lesson.subject).joined(separator: ", ")) }
        lines.append(dueCount == 0 ? "Дедлайнов на неделе нет" : "Дедлайнов на неделе: \(dueCount)")

        let c = UNMutableNotificationContent()
        c.title = "Следующая неделя 📚"
        c.body = lines.joined(separator: "\n")
        c.sound = .default
        let trig = UNCalendarNotificationTrigger(dateMatching: cal.dateComponents([.year, .month, .day, .hour, .minute], from: fire),
                                                 repeats: false)
        center.add(UNNotificationRequest(identifier: "digest", content: c, trigger: trig))
    }
}
