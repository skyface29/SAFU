# Сполох — исходники

iOS-приложение «Сполох» (пары и учёба для студентов САФУ). Проект описан в `project.yml` для XcodeGen.

```bash
brew install xcodegen
xcodegen generate
open SAFU.xcodeproj
```

- `Sources/` — приложение (SwiftUI)
- `Shared/` — общий код приложения и виджета: РУЗ, расписание, Live Activity
- `Widget/` — виджеты и Live Activity
- `Store.entitlements` — права для сборки в App Store (общая связка ключей с виджетом)

Как выпустить в App Store — `APP_STORE.md` в корне репозитория.
