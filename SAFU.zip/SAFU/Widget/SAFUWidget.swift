import WidgetKit
import SwiftUI

struct PairEntry: TimelineEntry {
    let date: Date
    let current: LessonSlot?
    let next: LessonSlot?
    let hasLessons: Bool
}

struct PairProvider: TimelineProvider {
    func placeholder(in context: Context) -> PairEntry {
        let start = Date().addingTimeInterval(20 * 60)
        let sample = LessonSlot(lesson: Lesson(subject: "Информатика", kind: "Лекция", room: "3104", building: "Главный корпус"),
                                start: start, end: start.addingTimeInterval(90 * 60),
                                address: "наб. Северной Двины, 17")
        return PairEntry(date: Date(), current: nil, next: sample, hasLessons: true)
    }

    func getSnapshot(in context: Context, completion: @escaping (PairEntry) -> Void) {
        if context.isPreview {
            completion(placeholder(in: context))
        } else {
            completion(makeEntry(at: Date(), data: SharedSchedule.load()))
        }
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<PairEntry>) -> Void) {
        let data = SharedSchedule.load()
        let now = Date()
        let dates = Array(([now] + ScheduleEngine.boundaries(after: now, data: data)).prefix(40))
        let entries = dates.map { makeEntry(at: $0, data: data) }
        let refresh = now.addingTimeInterval(6 * 3600)
        completion(Timeline(entries: entries, policy: .after(refresh)))
    }

    private func makeEntry(at date: Date, data: ScheduleData) -> PairEntry {
        let r = ScheduleEngine.nowAndNext(at: date, data: data)
        return PairEntry(date: date, current: r.current, next: r.next, hasLessons: !data.lessons.isEmpty)
    }
}

private let accent = Color(red: 0.45, green: 0.75, blue: 1.0)

private func timeString(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

private func whenString(_ slot: LessonSlot, from now: Date) -> String {
    let cal = Calendar.current
    if cal.isDate(slot.start, inSameDayAs: now) { return "в \(timeString(slot.start))" }
    if cal.isDateInTomorrow(slot.start) { return "завтра в \(timeString(slot.start))" }
    let wd = ScheduleEngine.weekday(of: slot.start)
    return "\(Lesson.dayFullNames[wd - 1]) в \(timeString(slot.start))"
}

struct PairWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PairEntry

    private var slot: LessonSlot? { entry.current ?? entry.next }
    private var isNow: Bool { entry.current != nil }

    var body: some View {
        content
            .widgetURL(URL(string: "safu://schedule"))
            .modifier(WidgetBackground(family: family))
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline:
            inline
        case .accessoryRectangular:
            rectangular
        case .systemMedium:
            medium
        default:
            small
        }
    }

    // MARK: экран блокировки

    private var inline: some View {
        Group {
            if let s = slot {
                Text("\(isNow ? "Сейчас" : whenString(s, from: entry.date)): \(s.lesson.subject)")
            } else {
                Text("Пар нет")
            }
        }
    }

    private var rectangular: some View {
        VStack(alignment: .leading, spacing: 1) {
            if let s = slot {
                HStack(spacing: 4) {
                    Image(systemName: "snowflake")
                    if isNow {
                        Text("до ") + Text(s.end, style: .time)
                    } else {
                        Text(whenString(s, from: entry.date))
                    }
                }
                .font(.caption2.weight(.semibold))
                Text(s.lesson.subject)
                    .font(.headline)
                    .lineLimit(1)
                Text(s.place.isEmpty ? s.lesson.kind : s.place)
                    .font(.caption)
                    .lineLimit(1)
            } else {
                Text("САФУ").font(.caption2.weight(.semibold))
                Text(entry.hasLessons ? "Пар больше нет" : "Добавь пары")
                    .font(.headline)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: главный экран

    private var small: some View {
        VStack(alignment: .leading, spacing: 4) {
            label(isNow ? "СЕЙЧАС" : "ДАЛЕЕ")
            if let s = slot {
                Text(s.lesson.subject)
                    .font(.system(.headline, design: .rounded))
                    .lineLimit(3)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 2)
                if !s.lesson.room.isEmpty {
                    Label(s.lesson.room, systemImage: "door.left.hand.open")
                        .font(.caption.weight(.semibold))
                        .lineLimit(1)
                }
                timeLine(s)
            } else {
                Spacer(minLength: 2)
                emptyText
                Spacer(minLength: 2)
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private var medium: some View {
        HStack(alignment: .top, spacing: 14) {
            VStack(alignment: .leading, spacing: 4) {
                label(isNow ? "СЕЙЧАС" : "ДАЛЕЕ")
                if let s = slot {
                    Text(s.lesson.subject)
                        .font(.system(.headline, design: .rounded))
                        .lineLimit(2)
                    Text(s.lesson.kind)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.7))
                    Spacer(minLength: 2)
                    timeLine(s)
                } else {
                    Spacer(minLength: 2)
                    emptyText
                    Spacer(minLength: 2)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)

            if let s = slot {
                VStack(alignment: .leading, spacing: 6) {
                    if !s.place.isEmpty {
                        Label(s.place, systemImage: "mappin.and.ellipse")
                            .font(.caption.weight(.semibold))
                            .lineLimit(2)
                    }
                    if !s.address.isEmpty {
                        Text(s.address)
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.7))
                            .lineLimit(2)
                    }
                    Spacer(minLength: 2)
                    if isNow, let n = entry.next {
                        VStack(alignment: .leading, spacing: 1) {
                            Text("Потом \(whenString(n, from: entry.date))")
                                .font(.caption2)
                                .foregroundStyle(.white.opacity(0.7))
                            Text(n.lesson.subject)
                                .font(.caption.weight(.semibold))
                                .lineLimit(1)
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func label(_ text: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: "snowflake")
            Text(text)
        }
        .font(.caption2.weight(.heavy))
        .foregroundStyle(accent)
    }

    @ViewBuilder private func timeLine(_ s: LessonSlot) -> some View {
        if isNow {
            HStack(spacing: 3) {
                Text("ещё")
                Text(s.end, style: .relative)
            }
            .font(.caption.weight(.semibold))
            .foregroundStyle(accent)
        } else {
            Text(whenString(s, from: entry.date))
                .font(.caption.weight(.semibold))
                .foregroundStyle(accent)
        }
    }

    private var emptyText: some View {
        Text(entry.hasLessons ? "Пар больше нет" : "Открой САФУ и добавь пары")
            .font(.subheadline.weight(.semibold))
    }
}

private struct WidgetBackground: ViewModifier {
    let family: WidgetFamily

    private var isAccessory: Bool {
        family == .accessoryInline || family == .accessoryRectangular || family == .accessoryCircular
    }

    private var gradient: LinearGradient {
        LinearGradient(colors: [Color(red: 0.08, green: 0.22, blue: 0.52),
                                Color(red: 0.03, green: 0.08, blue: 0.22)],
                       startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    @ViewBuilder
    func body(content: Content) -> some View {
        if #available(iOS 17.0, *) {
            if isAccessory {
                content.containerBackground(for: .widget) { Color.clear }
            } else {
                content.containerBackground(for: .widget) { gradient }
            }
        } else {
            if isAccessory {
                content
            } else {
                content.padding().background(gradient)
            }
        }
    }
}

struct PairWidget: Widget {
    let kind = "PairWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PairProvider()) { entry in
            PairWidgetView(entry: entry)
        }
        .configurationDisplayName("Пара")
        .description("Текущая или следующая пара, аудитория и адрес.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular, .accessoryInline])
    }
}

@main
struct SAFUWidgets: WidgetBundle {
    var body: some Widget {
        PairWidget()
    }
}
