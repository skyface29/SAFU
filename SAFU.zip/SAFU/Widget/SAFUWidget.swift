import WidgetKit
import SwiftUI
import AppIntents

// Виджет работает сам по себе: сам ходит в РУЗ и хранит кеш у себя.
// Поэтому ему не нужны общие данные с приложением (App Groups), которые теряются при переподписи.

// MARK: - Группа виджета
// Статичная конфигурация 8.8 — та, что точно отображалась. Своей группы по умолчанию нет:
// виджет узнаёт её сам — из общих данных, из общей связки ключей или из Live Activity пары.

enum WidgetGroup {
    static var number: String {
        let d = UserDefaults.standard
        let shared = SharedSchedule.load()
        if !shared.ruzGroupNumber.isEmpty {
            d.set(shared.ruzGroupNumber, forKey: "widget.group")
            d.set(shared.ruzInstitution, forKey: "widget.institution")
            return shared.ruzGroupNumber
        }
        if let b = WidgetBridge.read() {
            d.set(b.ruzGroupNumber, forKey: "widget.group")
            d.set(b.ruzInstitution, forKey: "widget.institution")
            return b.ruzGroupNumber
        }
        return d.string(forKey: "widget.group") ?? ""
    }

    /// Live Activity пары рисуется этим же расширением — запоминаем её группу для виджета
    static func learn(_ group: String) {
        let digits = group.filter(\.isNumber)
        guard digits.count >= 4, UserDefaults.standard.string(forKey: "widget.group") != digits else { return }
        UserDefaults.standard.set(digits, forKey: "widget.group")
        WidgetCenter.shared.reloadTimelines(ofKind: "PairWidgetV3")
    }
    static var institution: Int {
        let v = UserDefaults.standard.integer(forKey: "widget.institution")
        return v == 0 ? 3 : v
    }
}

// MARK: - Кнопка «обновить» прямо в виджете (без открытия приложения)

struct RefreshRuzIntent: AppIntent {
    static let title: LocalizedStringResource = "Обновить расписание"
    static let isDiscoverable = false

    @Parameter(title: "Группа")
    var group: String

    @Parameter(title: "Высшая школа")
    var institution: Int

    init() {}

    init(group: String, institution: Int) {
        self.group = group
        self.institution = institution
    }

    func perform() async throws -> some IntentResult {
        WidgetStore.clearCrash()
        _ = await WidgetStore.data(group: group, institution: institution, force: true)
        return .result()
    }
}

// MARK: - Данные

struct PairEntry: TimelineEntry {
    let date: Date
    let group: String
    var institution: Int = 3
    let current: LessonSlot?
    let next: LessonSlot?
    let dayTitle: String
    let daySlots: [LessonSlot]
    let tomorrowInfo: String
    let lastSync: Date?
    let status: String?
}

enum WidgetStore {
    private static func key(_ group: String) -> String { "widget.cache.\(group)" }

    static func loadCache(_ group: String) -> ScheduleData? {
        guard let raw = UserDefaults.standard.data(forKey: key(group)) else { return nil }
        return try? JSONDecoder().decode(ScheduleData.self, from: raw)
    }

    static func saveCache(_ data: ScheduleData, _ group: String) {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: key(group))
        }
    }

    /// Берём данные приложения (если доступны), иначе свой кеш; при необходимости обновляем из РУЗ
    /// Выполнить с ограничением по времени, чтобы виджет не завис на «сером» заглушечном виде
    static func withTimeout<T: Sendable>(_ seconds: Double, _ op: @escaping @Sendable () async -> T?) async -> T? {
        await withTaskGroup(of: Optional<T>.self) { g in
            g.addTask { await op() }
            g.addTask {
                try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                return nil
            }
            let first = await g.next() ?? nil
            g.cancelAll()
            return first
        }
    }

    // MARK: защита от падений: если прошлая загрузка оборвалась, виджет это видит и не повторяет её сразу

    private static let inflightKey = "widget.inflight"
    private static let crashKey = "widget.lastCrash"
    private static let stageKey = "widget.stage"

    static func stage(_ text: String) {
        UserDefaults.standard.set(text, forKey: stageKey)
    }

    static func clearCrash() {
        UserDefaults.standard.set(false, forKey: inflightKey)
        UserDefaults.standard.removeObject(forKey: crashKey)
    }

    /// Текст про последний сбой, если он был недавно
    static var crashInfo: String? {
        guard let d = UserDefaults.standard.object(forKey: crashKey) as? Date,
              Date().timeIntervalSince(d) < 3600 else { return nil }
        let stage = UserDefaults.standard.string(forKey: stageKey) ?? "?"
        return L("Сбой загрузки на шаге «\(stage)». Нажми ↻")
    }

    static func data(group: String, institution: Int, force: Bool = false) async -> (ScheduleData, String?) {
        let d = UserDefaults.standard
        // прошлый запуск не дошёл до конца → считаем, что он упал
        if d.bool(forKey: inflightKey) {
            d.set(false, forKey: inflightKey)
            d.set(Date(), forKey: crashKey)
        }

        let shared = SharedSchedule.load()
        var data: ScheduleData
        if shared.usesRuz, !shared.ruzEvents.isEmpty, shared.ruzGroupNumber == group {
            data = shared
            if let own = loadCache(group), let a = own.lastSync, let b = shared.lastSync, a > b { data = own }
        } else if let own = loadCache(group) {
            data = own
        } else {
            data = ScheduleData()
            data.ruzGroupNumber = group
            data.ruzInstitution = institution
        }
        data.source = 1

        var status: String? = crashInfo
        let stale = data.lastSync.map { Date().timeIntervalSince($0) > 2 * 3600 } ?? true
        let recentlyCrashed = crashInfo != nil
        guard (stale && !recentlyCrashed) || force else { return (data, status) }

        RuzClient.requestTimeout = 7
        RuzClient.useICS = false
        d.set(true, forKey: inflightKey)
        let base = data
        let fresh: (ScheduleData, String?)? = await withTimeout(force ? 20 : 11) {
            var x = base
            do {
                if x.ruzGroupID.isEmpty {
                    stage(L("поиск группы \(group)"))
                    x.ruzGroupID = try await RuzClient.findGroupID(number: group, institution: institution,
                                                                   searchAll: false) ?? ""
                }
                if x.ruzGroupID.isEmpty { return (x, L("Группа \(group) не найдена в РУЗ")) }
                stage(L("загрузка расписания"))
                let r = try await RuzClient.load(groupID: x.ruzGroupID)
                stage(L("разбор"))
                if !r.events.isEmpty { x.mergeRuz(r.events) }
                x.lastSync = Date()
                return (x, r.events.isEmpty ? (r.notice ?? L("В РУЗ нет пар на эти недели")) : nil)
            } catch {
                return (x, L("Нет связи с РУЗ"))
            }
        }
        d.set(false, forKey: inflightKey)

        if let fresh = fresh {
            data = fresh.0
            status = data.ruzEvents.isEmpty ? fresh.1 : nil
            if data.lastSync != nil || !data.ruzGroupID.isEmpty { saveCache(data, group) }
        } else if data.ruzEvents.isEmpty {
            status = L("РУЗ не ответил вовремя. Нажми ↻")
        }
        stage(L("готово"))
        return (data, status)
    }

    static func entry(at date: Date, group: String, institution: Int = 3, data: ScheduleData, status: String?) -> PairEntry {
        let cal = Calendar.current
        let r = ScheduleEngine.nowAndNext(at: date, data: data)

        // Какой день показывать списком: сегодня, а если пары кончились — ближайший учебный
        var showDay = date
        var slots = ScheduleEngine.slots(on: date, data: data)
        if slots.isEmpty || (slots.last.map { $0.end <= date } ?? true) {
            for offset in 1..<8 {
                guard let d = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: date)) else { continue }
                let s = ScheduleEngine.slots(on: d, data: data)
                if !s.isEmpty { showDay = d; slots = s; break }
            }
        }

        var tomorrowInfo = ""
        if let t = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: showDay)) {
            let s = ScheduleEngine.slots(on: t, data: data)
            if let first = s.first {
                tomorrowInfo = L("\(dayName(t, from: date)): \(s.count) \(pairsWord(s.count)), с \(hm(first.start))")
            }
        }

        return PairEntry(date: date, group: group, institution: institution, current: r.current, next: r.next,
                         dayTitle: dayName(showDay, from: date).capitalizedFirstLetter,
                         daySlots: slots, tomorrowInfo: tomorrowInfo,
                         lastSync: data.lastSync, status: status)
    }

    static func dayName(_ d: Date, from now: Date) -> String {
        let cal = Calendar.current
        if cal.isDate(d, inSameDayAs: now) { return L("сегодня") }
        if let t = cal.date(byAdding: .day, value: 1, to: now), cal.isDate(d, inSameDayAs: t) { return L("завтра") }
        return dayFormatter.string(from: d)
    }

    /// Форматтеры создаются один раз: у виджета мало памяти, а записей в таймлайне до 40
    private static let dayFormatter: DateFormatter = {
        let f = DateFormatter()
        f.locale = Lang.locale
        f.dateFormat = "EEEE, d MMM"
        return f
    }()

    static func pairsWord(_ n: Int) -> String {
        let m10 = Lang.en ? (n == 1 ? 1 : 0) : n % 10, m100 = Lang.en ? 0 : n % 100
        if m10 == 1 && m100 != 11 { return L("пара") }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return L("пары") }
        return L("пар")
    }
}

private let hmFormatter: DateFormatter = {
    let f = DateFormatter()
    f.locale = Lang.locale
    f.dateFormat = "H:mm"
    return f
}()

func hm(_ d: Date) -> String { hmFormatter.string(from: d) }

extension String {
    var capitalizedFirstLetter: String { prefix(1).uppercased() + dropFirst() }
}

func subjectColor(_ s: String) -> Color {
    var h: UInt64 = 5381
    for u in s.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
    return Color(hue: Double(h % 360) / 360.0, saturation: 0.5, brightness: 1.0)
}

// MARK: - Провайдер

struct PairProvider: TimelineProvider {
    func placeholder(in context: Context) -> PairEntry {
        let start = Date().addingTimeInterval(-30 * 60)
        let a = LessonSlot(lesson: Lesson(subject: L("Алгоритмизация и программирование"), kind: L("Лекция"),
                                          pair: 2, room: "3104", building: L("наб. Северной Двины, 17"),
                                          teacher: L("Иванов И.И.")),
                           start: start, end: start.addingTimeInterval(95 * 60),
                           address: L("наб. Северной Двины, 17"))
        let b = LessonSlot(lesson: Lesson(subject: L("Иностранный язык"), kind: L("Практика"), pair: 3, room: "42"),
                           start: start.addingTimeInterval(110 * 60), end: start.addingTimeInterval(205 * 60),
                           address: L("наб. Северной Двины, д. 2"))
        return PairEntry(date: Date(), group: "151621", current: a, next: b, dayTitle: L("Сегодня"),
                         daySlots: [a, b], tomorrowInfo: L("завтра: 3 пары, с 8:20"), lastSync: Date(), status: nil)
    }

    func getSnapshot(in context: Context, completion: @escaping (PairEntry) -> Void) {
        if context.isPreview {
            completion(placeholder(in: context))
            return
        }
        let group = WidgetGroup.number
        let data = WidgetStore.loadCache(group) ?? ScheduleData()
        completion(WidgetStore.entry(at: Date(), group: group, institution: WidgetGroup.institution,
                                     data: data, status: WidgetStore.crashInfo))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<PairEntry>) -> Void) {
        let group = WidgetGroup.number
        let inst = WidgetGroup.institution
        // группа ещё неизвестна — сразу показываем подсказку, в РУЗ не ходим
        guard !group.isEmpty else {
            let e = WidgetStore.entry(at: Date(), group: "", institution: inst, data: ScheduleData(),
                                      status: L("Открой Арктику — виджет возьмёт группу"))
            completion(Timeline(entries: [e], policy: .after(Date().addingTimeInterval(15 * 60))))
            return
        }
        Task {
            let (data, status) = await WidgetStore.data(group: group, institution: inst)
            let now = Date()
            let dates = Array(([now] + ScheduleEngine.boundaries(after: now, data: data)).prefix(40))
            let entries = dates.map { WidgetStore.entry(at: $0, group: group, institution: inst, data: data, status: status) }
            let refresh = data.ruzEvents.isEmpty ? now.addingTimeInterval(15 * 60) : now.addingTimeInterval(3600)
            completion(Timeline(entries: entries, policy: .after(refresh)))
        }
    }
}

// MARK: - Вид

// MARK: - Стили виджета
// Каждый стиль — отдельный виджет в галерее со своей проверенной статичной схемой (как 8.8).
// Так оформление работает без общих данных с приложением и без настройки внутри виджета (она ломала показ).

struct WidgetStyle {
    let id: String
    let name: String
    let top: Color
    let bottom: Color
    let accent: Color
    let ink: Color
    /// Без фона: на iOS 18 в режиме «Прозрачный» экрана «Домой» сквозь виджет видны обои
    var clear = false

    static let night = WidgetStyle(id: "night", name: L("Ночь"),
                                   top: Color(red: 0.09, green: 0.20, blue: 0.48), bottom: Color(red: 0.03, green: 0.07, blue: 0.20),
                                   accent: Color(red: 0.50, green: 0.78, blue: 1.0), ink: .white)
    static let aurora = WidgetStyle(id: "aurora", name: L("Сияние"),
                                    top: Color(red: 0.05, green: 0.36, blue: 0.40), bottom: Color(red: 0.16, green: 0.08, blue: 0.34),
                                    accent: Color(red: 0.45, green: 1.0, blue: 0.78), ink: .white)
    static let graphite = WidgetStyle(id: "graphite", name: L("Графит"),
                                      top: Color(red: 0.20, green: 0.21, blue: 0.24), bottom: Color(red: 0.07, green: 0.07, blue: 0.09),
                                      accent: Color(red: 0.80, green: 0.84, blue: 0.90), ink: .white)
    static let bordeaux = WidgetStyle(id: "bordeaux", name: L("Бордо"),
                                      top: Color(red: 0.42, green: 0.08, blue: 0.16), bottom: Color(red: 0.14, green: 0.02, blue: 0.06),
                                      accent: Color(red: 1.0, green: 0.62, blue: 0.66), ink: .white)
    static let forest = WidgetStyle(id: "forest", name: L("Хвоя"),
                                    top: Color(red: 0.08, green: 0.32, blue: 0.20), bottom: Color(red: 0.02, green: 0.10, blue: 0.07),
                                    accent: Color(red: 0.58, green: 0.95, blue: 0.66), ink: .white)
    static let sunset = WidgetStyle(id: "sunset", name: L("Закат"),
                                    top: Color(red: 0.95, green: 0.45, blue: 0.20), bottom: Color(red: 0.55, green: 0.10, blue: 0.35),
                                    accent: Color(red: 1.0, green: 0.90, blue: 0.55), ink: .white)
    static let light = WidgetStyle(id: "light", name: L("Светлый"),
                                   top: Color(red: 0.98, green: 0.98, blue: 1.0), bottom: Color(red: 0.90, green: 0.92, blue: 0.97),
                                   accent: Color(red: 0.10, green: 0.40, blue: 0.90), ink: Color(red: 0.08, green: 0.10, blue: 0.16))
    static let transparent = WidgetStyle(id: "clear", name: L("Прозрачный"),
                                         top: .clear, bottom: .clear,
                                         accent: Color(red: 0.45, green: 0.75, blue: 1.0), ink: .primary, clear: true)
}

struct PairWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PairEntry
    var style: WidgetStyle = .night

    private var accent: Color { style.accent }
    private var wallKey: String {
        switch family {
        case .systemMedium: return "medium"
        case .systemLarge, .systemExtraLarge: return "large"
        default: return "small"
        }
    }
    private var ink: Color { style.ink }

    private var slot: LessonSlot? { entry.current ?? entry.next }
    private var isNow: Bool { entry.current != nil }

    var body: some View {
        content
            .invalidatableContent()
            .widgetURL(URL(string: "safu://schedule"))
            .containerBackground(for: .widget) {
                if family == .accessoryInline || family == .accessoryRectangular || family == .accessoryCircular {
                    Color.clear
                } else if style.clear {
                    // вырезанный кусок обоев (Профиль → Виджет → «Прозрачный фон») — выглядит прозрачным
                    if let wall = WidgetWallpaper.load(family: wallKey) {
                        Image(uiImage: wall).resizable().scaledToFill()
                    } else {
                        Color.clear
                    }
                } else {
                    LinearGradient(colors: [style.top, style.bottom], startPoint: .topLeading, endPoint: .bottomTrailing)
                }
            }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline: inline
        case .accessoryRectangular: rectangular
        case .accessoryCircular: circular
        case .systemMedium: medium
        case .systemLarge, .systemExtraLarge: large
        default: small
        }
    }

    // MARK: общие куски

    private var refreshButton: some View {
        Button(intent: RefreshRuzIntent(group: entry.group, institution: entry.institution)) {
            Image(systemName: "arrow.clockwise")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(ink)
                .frame(width: 24, height: 24)
                .background(ink.opacity(0.18), in: Circle())
        }
        .buttonStyle(.plain)
    }

    private var updatedText: String {
        guard let last = entry.lastSync else { return L("не обновлялось") }
        return L("РУЗ \(hm(last))")
    }

    private func header(_ text: String, color: Color? = nil) -> some View {
        let color = color ?? accent
        return HStack(spacing: 4) {
            Image(systemName: isNow ? "dot.radiowaves.left.and.right" : "snowflake")
            Text(text)
        }
        .font(.system(size: 11, weight: .heavy))
        .foregroundStyle(color)
    }

    private func whenText(_ s: LessonSlot) -> String {
        let name = WidgetStore.dayName(s.start, from: entry.date)
        return name == L("сегодня") ? L("в \(hm(s.start))") : L("\(name) в \(hm(s.start))")
    }

    @ViewBuilder private func timeInfo(_ s: LessonSlot) -> some View {
        if isNow {
            VStack(alignment: .leading, spacing: 3) {
                ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .tint(subjectColor(s.lesson.subject))
                HStack(spacing: 3) {
                    Text(L("до \(hm(s.end)) ·"))
                    Text(s.end, style: .relative)
                }
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(ink.opacity(0.8))
            }
        } else {
            HStack(spacing: 3) {
                Text(whenText(s))
                if Calendar.current.isDate(s.start, inSameDayAs: entry.date) {
                    Text(L("· через"))
                    Text(s.start, style: .relative)
                }
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(accent)
            .lineLimit(1)
        }
    }

    private var emptyView: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                header(entry.group.isEmpty ? L("Пары") : L("Пары · \(entry.group)"))
                Spacer()
                if !entry.group.isEmpty { refreshButton }
            }
            Spacer(minLength: 0)
            Text(entry.status ?? L("Пар на неделе нет"))
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(ink)
                .minimumScaleFactor(0.6)
            Text(entry.group.isEmpty ? L("Или дождись пары — группу подскажет Live Activity") : L("Нажми ↻, чтобы загрузить из РУЗ"))
                .font(.system(size: 10))
                .foregroundStyle(ink.opacity(0.6))
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    /// Аудитория и ПОЛНЫЙ адрес корпуса
    private func placeBlock(_ s: LessonSlot, addressLines: Int = 2, size: CGFloat = 12) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            if !s.lesson.room.isEmpty {
                HStack(spacing: 4) {
                    Image(systemName: "door.left.hand.open")
                    Text(L("ауд. \(s.lesson.room)"))
                }
                .font(.system(size: size, weight: .heavy))
                .foregroundStyle(ink)
                .lineLimit(1)
            }
            if !s.address.isEmpty {
                HStack(alignment: .top, spacing: 4) {
                    Image(systemName: "mappin.and.ellipse")
                    Text(AddressFormat.full(s.address))
                }
                .font(.system(size: size - 1, weight: .semibold))
                .foregroundStyle(ink.opacity(0.85))
                .lineLimit(addressLines)
                .minimumScaleFactor(0.6)
            }
        }
    }

    // MARK: маленький

    @ViewBuilder private var small: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    header(isNow ? L("СЕЙЧАС · \(s.lesson.pair)") : L("ДАЛЕЕ · \(s.lesson.pair)"), color: subjectColor(s.lesson.subject))
                    Spacer()
                    refreshButton
                }
                KindBadge(kind: s.lesson.kind, size: 9)
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(ink)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 2)
                if !s.lesson.room.isEmpty || !s.address.isEmpty { placeBlock(s) }
                timeInfo(s)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    // MARK: средний

    @ViewBuilder private var medium: some View {
        if let s = slot {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    header(isNow ? L("СЕЙЧАС · \(s.lesson.pair) ПАРА") : L("ДАЛЕЕ · \(s.lesson.pair) ПАРА"),
                           color: subjectColor(s.lesson.subject))
                    Text(s.lesson.subject)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(ink)
                        .lineLimit(2)
                    HStack(spacing: 5) {
                        KindBadge(kind: s.lesson.kind, size: 9)
                        Text("\(hm(s.start))–\(hm(s.end))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(ink.opacity(0.75))
                    }
                    Spacer(minLength: 2)
                    if !s.lesson.room.isEmpty || !s.address.isEmpty { placeBlock(s) }
                    timeInfo(s)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(entry.dayTitle.uppercased())
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundStyle(ink.opacity(0.6))
                            .lineLimit(1)
                        Spacer(minLength: 2)
                        refreshButton
                    }
                    let rest = entry.daySlots.filter { $0.key != s.key && $0.end > entry.date }.prefix(3)
                    if rest.isEmpty {
                        Text(entry.tomorrowInfo.isEmpty ? L("Больше пар нет") : entry.tomorrowInfo.capitalizedFirstLetter)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(ink.opacity(0.8))
                    } else {
                        ForEach(Array(rest), id: \.key) { r in
                            miniRow(r)
                        }
                    }
                    Spacer(minLength: 0)
                    Text(updatedText)
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(ink.opacity(0.45))
                }
                .frame(width: 124, alignment: .leading)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    private func miniRow(_ r: LessonSlot) -> some View {
        HStack(alignment: .top, spacing: 6) {
            RoundedRectangle(cornerRadius: 2)
                .fill(KindStyle.of(r.lesson.kind).color)
                .frame(width: 3, height: 26)
            VStack(alignment: .leading, spacing: 1) {
                Text("\(hm(r.start)) · \(KindStyle.of(r.lesson.kind).label)\(r.lesson.room.isEmpty ? "" : " · \(r.lesson.room)")")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(ink.opacity(0.7))
                Text(r.lesson.subject)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(ink)
                    .lineLimit(1)
            }
        }
    }

    // MARK: большой — весь день
    // Пары растягиваются на всю высоту виджета (раньше жались кверху).
    // Нажал на пару — открывается её предмет: закреплённые материалы, файлы, заметки.
    // Камера справа — фото доски сразу в папку этого предмета.

    private func link(_ kind: String, _ r: LessonSlot) -> URL {
        var c = URLComponents()
        c.scheme = "safu"
        c.host = kind
        c.queryItems = [URLQueryItem(name: "subject", value: r.lesson.subject),
                        URLQueryItem(name: "start", value: String(Int(r.start.timeIntervalSince1970)))]
        return c.url ?? URL(string: "safu://schedule")!
    }

    @ViewBuilder private var large: some View {
        if entry.daySlots.isEmpty && slot == nil {
            emptyView
        } else {
            let rows = Array(entry.daySlots.prefix(6))
            let roomy = rows.count <= 4
            let upcoming = entry.daySlots.first { $0.start > entry.date }
            VStack(alignment: .leading, spacing: 6) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(entry.dayTitle)
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                            .foregroundStyle(ink)
                        HStack(spacing: 3) {
                            Text("\(entry.group) · \(entry.daySlots.count) \(WidgetStore.pairsWord(entry.daySlots.count))")
                            if let c = entry.current, entry.daySlots.contains(where: { $0.key == c.key }) {
                                Text(L("· идёт \(c.lesson.pair)-я, конец в \(hm(c.end))"))
                            } else if let u = upcoming {
                                Text(L("· первая через"))
                                Text(u.start, style: .relative)
                            }
                        }
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(ink.opacity(0.65))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    }
                    Spacer(minLength: 6)
                    refreshButton
                }

                VStack(spacing: 5) {
                    ForEach(rows, id: \.key) { r in
                        largeRow(r, roomy: roomy)
                            .frame(maxHeight: roomy ? 92 : .infinity)
                    }
                    if entry.daySlots.count > rows.count {
                        Text(L("+ ещё \(entry.daySlots.count - rows.count) — в приложении"))
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(ink.opacity(0.6))
                    }
                }
                .frame(maxHeight: .infinity, alignment: .top)

                HStack {
                    if !entry.tomorrowInfo.isEmpty {
                        Text(entry.tomorrowInfo.capitalizedFirstLetter)
                    }
                    Spacer()
                    Text(updatedText)
                }
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(ink.opacity(0.55))
                .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }

    private func largeRow(_ r: LessonSlot, roomy: Bool) -> some View {
        let active = r.start <= entry.date && entry.date < r.end
        let past = r.end <= entry.date
        let color = KindStyle.of(r.lesson.kind).color
        let place = [r.lesson.room.isEmpty ? "" : L("ауд. \(r.lesson.room)"), AddressFormat.full(r.address)]
            .filter { !$0.isEmpty }.joined(separator: " · ")
        return HStack(spacing: 8) {
            Link(destination: link("pair", r)) {
                HStack(spacing: 8) {
                    VStack(alignment: .trailing, spacing: 1) {
                        Text(hm(r.start)).font(.system(size: roomy ? 14 : 12, weight: .bold)).monospacedDigit()
                        Text(hm(r.end)).font(.system(size: roomy ? 10 : 9)).monospacedDigit().opacity(0.6)
                    }
                    .frame(width: 38, alignment: .trailing)
                    .foregroundStyle(ink)
                    RoundedRectangle(cornerRadius: 2)
                        .fill(color)
                        .frame(width: 4)
                        .frame(maxHeight: .infinity)
                    VStack(alignment: .leading, spacing: roomy ? 3 : 1) {
                        HStack(spacing: 4) {
                            KindBadge(kind: r.lesson.kind, size: 8)
                            if active {
                                Text(L("СЕЙЧАС"))
                                    .font(.system(size: 8, weight: .heavy))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 5)
                                    .padding(.vertical, 2)
                                    .background(Color.green, in: Capsule())
                            }
                        }
                        Text(r.lesson.subject)
                            .font(.system(size: roomy ? 14 : 12, weight: .bold, design: .rounded))
                            .foregroundStyle(ink)
                            .lineLimit(roomy ? 2 : 1)
                            .minimumScaleFactor(0.85)
                        if !place.isEmpty {
                            Text(place)
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(ink.opacity(0.75))
                                .lineLimit(1)
                                .minimumScaleFactor(0.7)
                        }
                        if roomy && !r.lesson.teacher.isEmpty {
                            Label(r.lesson.teacher, systemImage: "person.fill")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundStyle(ink.opacity(0.6))
                                .lineLimit(1)
                        }
                        if active {
                            ProgressView(timerInterval: r.start...max(r.end, r.start.addingTimeInterval(60)), countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(color)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            // фото доски — сразу в папку этого предмета
            Link(destination: link("photo", r)) {
                Image(systemName: "camera.fill")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(ink)
                    .frame(width: 30, height: 30)
                    .background(ink.opacity(0.14), in: Circle())
            }
        }
        .padding(.vertical, roomy ? 7 : 4)
        .padding(.horizontal, 8)
        .frame(maxHeight: .infinity)
        .background(ink.opacity(active ? 0.16 : 0.07), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        .opacity(past ? 0.5 : 1)
    }

    // MARK: экран блокировки

    @ViewBuilder private var inline: some View {
        if let s = slot {
            let place = [KindStyle.of(s.lesson.kind).label, s.lesson.room.isEmpty ? "" : L("ауд. \(s.lesson.room)")]
                .filter { !$0.isEmpty }.joined(separator: ", ")
            Text(isNow ? L("До \(hm(s.end)) · \(place)") : "\(hm(s.start)) · \(place)")
        } else {
            Text(L("Пар нет"))
        }
    }

    private func rectTop(_ s: LessonSlot) -> String {
        var parts: [String] = [isNow ? L("до \(hm(s.end))") : whenText(s)]
        parts.append(KindStyle.of(s.lesson.kind).label)
        if !s.lesson.room.isEmpty { parts.append(L("ауд. \(s.lesson.room)")) }
        return parts.joined(separator: " · ")
    }

    @ViewBuilder private var rectangular: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Image(systemName: "snowflake")
                    Text(rectTop(s))
                }
                .font(.system(size: 11, weight: .bold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                .widgetAccentable()
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold))
                    .lineLimit(1)
                Text(s.address.isEmpty ? s.lesson.kind : AddressFormat.full(s.address))
                    .font(.system(size: 12))
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
            VStack(alignment: .leading) {
                Text(L("Пары")).font(.system(size: 11, weight: .bold))
                Text(entry.status ?? L("Пар нет")).font(.system(size: 14, weight: .bold))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder private var circular: some View {
        if let s = slot, isNow {
            ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: true) {
                EmptyView()
            } currentValueLabel: {
                Text(s.lesson.room.isEmpty ? "\(s.lesson.pair)" : s.lesson.room)
                    .font(.system(size: 12, weight: .bold))
                    .minimumScaleFactor(0.5)
            }
            .progressViewStyle(.circular)
        } else if let s = slot {
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: 0) {
                    Text(hm(s.start)).font(.system(size: 13, weight: .bold)).minimumScaleFactor(0.6)
                    Text(s.lesson.room.isEmpty ? L("\(s.lesson.pair) п.") : s.lesson.room)
                        .font(.system(size: 10))
                        .minimumScaleFactor(0.5)
                }
            }
        } else {
            ZStack {
                AccessoryWidgetBackground()
                Image(systemName: "snowflake")
            }
        }
    }
}

// MARK: - Виджет

struct PairWidget: Widget {
    let kind = "PairWidgetV3"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PairProvider()) { entry in
            PairWidgetView(entry: entry)
        }
        .configurationDisplayName(L("Пары"))
        .description(L("Текущая и следующая пара, аудитория, адрес и весь день. Данные из РУЗ."))
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge,
                            .accessoryRectangular, .accessoryInline, .accessoryCircular])
    }
}

// MARK: - Виджеты разных стилей
// Основной «Пары САФУ» (Ночь) не трогаем — он работает. Остальные стили — отдельные виджеты в галерее:
// удержи экран «Домой» → «+» → САФУ и листай — там Сияние, Графит, Бордо, Хвоя, Закат, Светлый и Прозрачный.

func styledPairWidget(_ style: WidgetStyle) -> some WidgetConfiguration {
    StaticConfiguration(kind: "PairWidgetV3." + style.id, provider: PairProvider()) { entry in
        PairWidgetView(entry: entry, style: style)
    }
    .configurationDisplayName(Text(L("Пары · ") + style.name))
    .description(Text(style.clear
                      ? L("Без фона. На iOS 18 включи «Изменить» → «Настроить» → «Прозрачный» на экране «Домой» — будут видны обои.")
                      : L("Текущая и следующая пара, аудитория и весь день — в стиле «") + style.name + "»."))
    .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
}

struct PairWidgetAurora: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.aurora) }
}
struct PairWidgetGraphite: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.graphite) }
}
struct PairWidgetBordeaux: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.bordeaux) }
}
struct PairWidgetForest: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.forest) }
}
struct PairWidgetSunset: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.sunset) }
}
struct PairWidgetLight: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.light) }
}
struct PairWidgetClear: Widget {
    var body: some WidgetConfiguration { styledPairWidget(.transparent) }
}

struct PairStyleWidgets: WidgetBundle {
    var body: some Widget {
        PairWidgetAurora()
        PairWidgetGraphite()
        PairWidgetBordeaux()
        PairWidgetForest()
        PairWidgetSunset()
        PairWidgetLight()
        PairWidgetClear()
    }
}

@main
struct SAFUWidgets: WidgetBundle {
    var body: some Widget {
        PairWidget()
        PairStyleWidgets().body
        PairLiveActivity()
        BusLiveActivity()
    }
}
