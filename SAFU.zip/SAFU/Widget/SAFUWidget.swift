import WidgetKit
import SwiftUI
import AppIntents

// Виджет работает сам по себе: сам ходит в РУЗ и хранит кеш у себя.
// Поэтому ему не нужны общие данные с приложением (App Groups), которые теряются при переподписи.

// MARK: - Группа виджета
// Группа — та, что выбрана в приложении при регистрации (через общие данные).
// Если общие данные недоступны (после переподписи), виджет помнит последнюю известную группу.

enum WidgetGroup {
    /// Группа из настройки виджета («Изменить виджет»), если указана; иначе — как раньше
    static func resolve(_ configured: String?) -> String {
        let digits = (configured ?? "").filter(\.isNumber)
        if digits.count >= 4 {
            UserDefaults.standard.set(digits, forKey: "widget.group")
            return digits
        }
        return number
    }

    static var number: String {
        // 1) общие данные (если App Group работает) 2) мост от приложения 3) последняя известная группа
        let shared = SharedSchedule.load()
        let known = !shared.ruzGroupNumber.isEmpty ? shared : WidgetBridge.read()
        if let known, !known.ruzGroupNumber.isEmpty {
            UserDefaults.standard.set(known.ruzGroupNumber, forKey: "widget.group")
            UserDefaults.standard.set(known.ruzInstitution, forKey: "widget.institution")
            return known.ruzGroupNumber
        }
        return UserDefaults.standard.string(forKey: "widget.group") ?? ""
    }
    static var institution: Int {
        let v = UserDefaults.standard.integer(forKey: "widget.institution")
        return v == 0 ? 3 : v
    }
}

// MARK: - Настройка виджета (удержать виджет → «Изменить виджет»)

enum WidgetTheme: String, AppEnum {
    case night, aurora, graphite, bordeaux, forest, cosmos, subject

    static let typeDisplayRepresentation: TypeDisplayRepresentation = "Оформление"
    static let caseDisplayRepresentations: [WidgetTheme: DisplayRepresentation] = [
        .night: "Ночь", .aurora: "Сияние", .graphite: "Графит", .bordeaux: "Бордо",
        .forest: "Хвоя", .cosmos: "Космос", .subject: "Цвет предмета",
    ]

    /// Верх и низ градиента, акцент
    func colors(subject: Color?) -> (Color, Color, Color) {
        switch self {
        case .night: return (Color(red: 0.09, green: 0.20, blue: 0.48), Color(red: 0.03, green: 0.07, blue: 0.20), Color(red: 0.50, green: 0.78, blue: 1.0))
        case .aurora: return (Color(red: 0.05, green: 0.36, blue: 0.40), Color(red: 0.16, green: 0.08, blue: 0.34), Color(red: 0.45, green: 1.0, blue: 0.78))
        case .graphite: return (Color(red: 0.20, green: 0.21, blue: 0.24), Color(red: 0.07, green: 0.07, blue: 0.09), Color(red: 0.80, green: 0.84, blue: 0.90))
        case .bordeaux: return (Color(red: 0.42, green: 0.08, blue: 0.16), Color(red: 0.14, green: 0.02, blue: 0.06), Color(red: 1.0, green: 0.62, blue: 0.66))
        case .forest: return (Color(red: 0.08, green: 0.32, blue: 0.20), Color(red: 0.02, green: 0.10, blue: 0.07), Color(red: 0.58, green: 0.95, blue: 0.66))
        case .cosmos: return (Color(red: 0.20, green: 0.06, blue: 0.36), Color(red: 0.02, green: 0.01, blue: 0.08), Color(red: 0.85, green: 0.62, blue: 1.0))
        case .subject:
            let c = subject ?? Color(red: 0.09, green: 0.20, blue: 0.48)
            return (c.opacity(0.95), Color(red: 0.04, green: 0.05, blue: 0.10), .white)
        }
    }
}

enum WidgetSchool: String, AppEnum {
    case vshitas, vish, vshenit, vshsgn, vsheup, vsheng, vshppfk, fish

    static let typeDisplayRepresentation: TypeDisplayRepresentation = "Высшая школа"
    static let caseDisplayRepresentations: [WidgetSchool: DisplayRepresentation] = [
        .vshitas: "ВШИТАС", .vish: "Высшая инженерная школа", .vshenit: "ВШ естественных наук",
        .vshsgn: "ВШ соц.-гум. наук", .vsheup: "ВШ экономики и права", .vsheng: "ВШ энергетики",
        .vshppfk: "ВШ педагогики и физкультуры", .fish: "ВШ рыболовства",
    ]

    var ruzID: Int {
        switch self {
        case .vshitas: return 3
        case .vish: return 15
        case .vshenit: return 1
        case .vshsgn: return 4
        case .vsheup: return 28
        case .vsheng: return 12
        case .vshppfk: return 13
        case .fish: return 36
        }
    }
}

struct PairWidgetConfig: WidgetConfigurationIntent {
    static let title: LocalizedStringResource = "Пары САФУ"
    static let description = IntentDescription("Номер группы и оформление виджета")

    @Parameter(title: "Номер группы", description: "Пусто — группа из приложения")
    var group: String?

    @Parameter(title: "Высшая школа", description: "Ускоряет первую загрузку. Не знаешь — оставь пустым")
    var school: WidgetSchool?

    @Parameter(title: "Оформление", default: .night)
    var theme: WidgetTheme

    @Parameter(title: "Показывать преподавателя", default: true)
    var showTeacher: Bool

    init() {}
}

// MARK: - Кнопка «обновить» прямо в виджете (без открытия приложения)

struct RefreshRuzIntent: AppIntent {
    static let title: LocalizedStringResource = "Обновить расписание"
    static let isDiscoverable = false

    @Parameter(title: "Группа")
    var group: String

    @Parameter(title: "Высшая школа")
    var institution: Int

    init() {}

    init(group: String, institution: Int) {
        self.group = group
        self.institution = institution
    }

    func perform() async throws -> some IntentResult {
        WidgetStore.clearCrash()
        _ = await WidgetStore.data(group: group, institution: institution, force: true)
        return .result()
    }
}

// MARK: - Данные

struct PairEntry: TimelineEntry {
    let date: Date
    let group: String
    var institution: Int = 3
    let current: LessonSlot?
    let next: LessonSlot?
    let dayTitle: String
    let daySlots: [LessonSlot]
    let tomorrowInfo: String
    let lastSync: Date?
    let status: String?
    var theme: WidgetTheme = .night
    var showTeacher = true
}

enum WidgetStore {
    private static func key(_ group: String) -> String { "widget.cache.\(group)" }

    static func loadCache(_ group: String) -> ScheduleData? {
        guard let raw = UserDefaults.standard.data(forKey: key(group)) else { return nil }
        return try? JSONDecoder().decode(ScheduleData.self, from: raw)
    }

    static func saveCache(_ data: ScheduleData, _ group: String) {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: key(group))
        }
    }

    /// Берём данные приложения (если доступны), иначе свой кеш; при необходимости обновляем из РУЗ
    /// Выполнить с ограничением по времени, чтобы виджет не завис на «сером» заглушечном виде
    static func withTimeout<T: Sendable>(_ seconds: Double, _ op: @escaping @Sendable () async -> T?) async -> T? {
        await withTaskGroup(of: Optional<T>.self) { g in
            g.addTask { await op() }
            g.addTask {
                try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
                return nil
            }
            let first = await g.next() ?? nil
            g.cancelAll()
            return first
        }
    }

    // MARK: защита от падений: если прошлая загрузка оборвалась, виджет это видит и не повторяет её сразу

    private static let inflightKey = "widget.inflight"
    private static let crashKey = "widget.lastCrash"
    private static let stageKey = "widget.stage"

    static func stage(_ text: String) {
        UserDefaults.standard.set(text, forKey: stageKey)
    }

    static func clearCrash() {
        UserDefaults.standard.set(false, forKey: inflightKey)
        UserDefaults.standard.removeObject(forKey: crashKey)
    }

    /// Текст про последний сбой, если он был недавно (10 минут, а не час — чтобы виджет не «засыпал»)
    static var crashInfo: String? {
        guard let d = UserDefaults.standard.object(forKey: crashKey) as? Date,
              Date().timeIntervalSince(d) < 600 else { return nil }
        let stage = UserDefaults.standard.string(forKey: stageKey) ?? "?"
        return "Сбой загрузки на шаге «\(stage)». Нажми ↻"
    }

    static func data(group: String, institution: Int, force: Bool = false) async -> (ScheduleData, String?) {
        let d = UserDefaults.standard
        // прошлый запуск не дошёл до конца → считаем, что он упал
        if d.bool(forKey: inflightKey) {
            d.set(false, forKey: inflightKey)
            d.set(Date(), forKey: crashKey)
        }

        let shared = SharedSchedule.load()
        var data: ScheduleData
        if shared.usesRuz, !shared.ruzEvents.isEmpty, shared.ruzGroupNumber == group {
            data = shared
            if let own = loadCache(group), let a = own.lastSync, let b = shared.lastSync, a > b { data = own }
        } else if let own = loadCache(group) {
            data = own
        } else {
            data = ScheduleData()
            data.ruzGroupNumber = group
            data.ruzInstitution = institution
        }
        // мост от приложения: свежие пары без похода в РУЗ
        if let b = WidgetBridge.read(), b.ruzGroupNumber == group, !b.ruzEvents.isEmpty,
           (data.lastSync ?? .distantPast) < (b.lastSync ?? .distantPast) || data.ruzEvents.isEmpty {
            data = b
            if !b.ruzGroupID.isEmpty { d.set(b.ruzGroupID, forKey: "widget.gid.\(group)") }
            saveCache(b, group)
        }
        data.source = 1
        // номер группы в РУЗ, найденный раньше, — второй раз не ищем (это самый долгий шаг)
        let gidKey = "widget.gid.\(group)"
        if data.ruzGroupID.isEmpty, let saved = d.string(forKey: gidKey), !saved.isEmpty { data.ruzGroupID = saved }

        var status: String? = crashInfo
        let stale = data.lastSync.map { Date().timeIntervalSince($0) > 2 * 3600 } ?? true
        // после сбоя не повторяем сразу, только если уже есть что показать
        let recentlyCrashed = crashInfo != nil && !data.ruzEvents.isEmpty
        guard (stale && !recentlyCrashed) || force else { return (data, status) }

        RuzClient.requestTimeout = 10
        RuzClient.useICS = false
        d.set(true, forKey: inflightKey)
        let base = data
        let fresh: (ScheduleData, String?)? = await withTimeout(force ? 28 : 22) {
            var x = base
            do {
                if x.ruzGroupID.isEmpty {
                    stage("поиск группы \(group)")
                    // сначала в своей школе, потом во всех остальных
                    x.ruzGroupID = try await RuzClient.findGroupID(number: group, institution: institution,
                                                                   searchAll: true) ?? ""
                    // запоминаем сразу — даже если расписание не успеет загрузиться
                    if !x.ruzGroupID.isEmpty { UserDefaults.standard.set(x.ruzGroupID, forKey: gidKey) }
                }
                if x.ruzGroupID.isEmpty { return (x, "Группа \(group) не найдена в РУЗ") }
                stage("загрузка расписания")
                let r = try await RuzClient.load(groupID: x.ruzGroupID)
                stage("разбор")
                if !r.events.isEmpty { x.mergeRuz(r.events) }
                x.lastSync = Date()
                return (x, r.events.isEmpty ? (r.notice ?? "В РУЗ нет пар на эти недели") : nil)
            } catch {
                return (x, "Нет связи с РУЗ")
            }
        }
        d.set(false, forKey: inflightKey)

        if let fresh = fresh {
            data = fresh.0
            status = data.ruzEvents.isEmpty ? fresh.1 : nil
            if data.lastSync != nil || !data.ruzGroupID.isEmpty { saveCache(data, group) }
        } else if data.ruzEvents.isEmpty {
            status = "РУЗ не ответил вовремя. Нажми ↻"
        }
        stage("готово")
        return (data, status)
    }

    static func entry(at date: Date, group: String, institution: Int = 3, data: ScheduleData, status: String?) -> PairEntry {
        let cal = Calendar.current
        let r = ScheduleEngine.nowAndNext(at: date, data: data)

        // Какой день показывать списком: сегодня, а если пары кончились — ближайший учебный
        var showDay = date
        var slots = ScheduleEngine.slots(on: date, data: data)
        if slots.isEmpty || (slots.last.map { $0.end <= date } ?? true) {
            for offset in 1..<8 {
                guard let d = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: date)) else { continue }
                let s = ScheduleEngine.slots(on: d, data: data)
                if !s.isEmpty { showDay = d; slots = s; break }
            }
        }

        var tomorrowInfo = ""
        if let t = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: showDay)) {
            let s = ScheduleEngine.slots(on: t, data: data)
            if let first = s.first {
                tomorrowInfo = "\(dayName(t, from: date)): \(s.count) \(pairsWord(s.count)), с \(hm(first.start))"
            }
        }

        return PairEntry(date: date, group: group, institution: institution, current: r.current, next: r.next,
                         dayTitle: dayName(showDay, from: date).capitalizedFirstLetter,
                         daySlots: slots, tomorrowInfo: tomorrowInfo,
                         lastSync: data.lastSync, status: status)
    }

    static func dayName(_ d: Date, from now: Date) -> String {
        let cal = Calendar.current
        if cal.isDate(d, inSameDayAs: now) { return "сегодня" }
        if let t = cal.date(byAdding: .day, value: 1, to: now), cal.isDate(d, inSameDayAs: t) { return "завтра" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EEEE, d MMM"
        return f.string(from: d)
    }

    static func pairsWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "пара" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "пары" }
        return "пар"
    }
}

func hm(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

extension String {
    var capitalizedFirstLetter: String { prefix(1).uppercased() + dropFirst() }
}

func subjectColor(_ s: String) -> Color {
    var h: UInt64 = 5381
    for u in s.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
    return Color(hue: Double(h % 360) / 360.0, saturation: 0.5, brightness: 1.0)
}

// MARK: - Провайдер

struct PairProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PairEntry {
        let start = Date().addingTimeInterval(-30 * 60)
        let a = LessonSlot(lesson: Lesson(subject: "Алгоритмизация и программирование", kind: "Лекция",
                                          pair: 2, room: "3104", building: "наб. Северной Двины, 17",
                                          teacher: "Иванов И.И."),
                           start: start, end: start.addingTimeInterval(95 * 60),
                           address: "наб. Северной Двины, 17")
        let b = LessonSlot(lesson: Lesson(subject: "Иностранный язык", kind: "Практика", pair: 3, room: "42"),
                           start: start.addingTimeInterval(110 * 60), end: start.addingTimeInterval(205 * 60),
                           address: "наб. Северной Двины, д. 2")
        return PairEntry(date: Date(), group: "", current: a, next: b, dayTitle: "Сегодня",
                         daySlots: [a, b], tomorrowInfo: "завтра: 3 пары, с 8:20", lastSync: Date(), status: nil)
    }

    func snapshot(for configuration: PairWidgetConfig, in context: Context) async -> PairEntry {
        if context.isPreview {
            var e = placeholder(in: context)
            e.theme = configuration.theme
            return e
        }
        let group = WidgetGroup.resolve(configuration.group)
        let data = WidgetStore.loadCache(group) ?? ScheduleData()
        var e = WidgetStore.entry(at: Date(), group: group, institution: WidgetGroup.institution,
                                  data: data, status: WidgetStore.crashInfo)
        e.theme = configuration.theme
        e.showTeacher = configuration.showTeacher
        return e
    }

    func timeline(for configuration: PairWidgetConfig, in context: Context) async -> Timeline<PairEntry> {
        let group = WidgetGroup.resolve(configuration.group)
        let inst = configuration.school?.ruzID ?? WidgetGroup.institution
        // группа неизвестна — подсказываем, как её указать, в РУЗ не ходим
        guard !group.isEmpty else {
            var e = WidgetStore.entry(at: Date(), group: "", institution: inst, data: ScheduleData(),
                                      status: "Удержи виджет → «Изменить виджет» → номер группы")
            e.theme = configuration.theme
            return Timeline(entries: [e], policy: .after(Date().addingTimeInterval(30 * 60)))
        }
        let (data, status) = await WidgetStore.data(group: group, institution: inst)
        let now = Date()
        let dates = Array(([now] + ScheduleEngine.boundaries(after: now, data: data)).prefix(40))
        let entries = dates.map { d -> PairEntry in
            var e = WidgetStore.entry(at: d, group: group, institution: inst, data: data, status: status)
            e.theme = configuration.theme
            e.showTeacher = configuration.showTeacher
            return e
        }
        let refresh = data.ruzEvents.isEmpty ? now.addingTimeInterval(15 * 60) : now.addingTimeInterval(3600)
        return Timeline(entries: entries, policy: .after(refresh))
    }
}

// MARK: - Вид


struct PairWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PairEntry

    private var slot: LessonSlot? { entry.current ?? entry.next }
    private var isNow: Bool { entry.current != nil }
    private var palette: (Color, Color, Color) {
        entry.theme.colors(subject: slot.map { subjectColor($0.lesson.subject) })
    }
    private var accent: Color { palette.2 }

    var body: some View {
        content
            .invalidatableContent()
            .widgetURL(URL(string: "safu://schedule"))
            .containerBackground(for: .widget) {
                if family == .accessoryInline || family == .accessoryRectangular || family == .accessoryCircular {
                    Color.clear
                } else {
                    ZStack {
                        LinearGradient(colors: [palette.0, palette.1], startPoint: .topLeading, endPoint: .bottomTrailing)
                        // мягкий блик сверху — «стеклянный» объём
                        RadialGradient(colors: [Color.white.opacity(0.16), .clear], center: .topLeading, startRadius: 0, endRadius: 220)
                    }
                }
            }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline: inline
        case .accessoryRectangular: rectangular
        case .accessoryCircular: circular
        case .systemMedium: medium
        case .systemLarge, .systemExtraLarge: large
        default: small
        }
    }

    // MARK: общие куски

    private var refreshButton: some View {
        Button(intent: RefreshRuzIntent(group: entry.group, institution: entry.institution)) {
            Image(systemName: "arrow.clockwise")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 24, height: 24)
                .background(.white.opacity(0.18), in: Circle())
        }
        .buttonStyle(.plain)
    }

    private var updatedText: String {
        guard let last = entry.lastSync else { return "не обновлялось" }
        return "РУЗ \(hm(last))"
    }

    private func header(_ text: String, color: Color? = nil) -> some View {
        let color = color ?? accent
        return HStack(spacing: 4) {
            Image(systemName: isNow ? "dot.radiowaves.left.and.right" : "snowflake")
            Text(text)
        }
        .font(.system(size: 11, weight: .heavy))
        .foregroundStyle(color)
    }

    private func whenText(_ s: LessonSlot) -> String {
        let name = WidgetStore.dayName(s.start, from: entry.date)
        return name == "сегодня" ? "в \(hm(s.start))" : "\(name) в \(hm(s.start))"
    }

    @ViewBuilder private func timeInfo(_ s: LessonSlot) -> some View {
        if isNow {
            VStack(alignment: .leading, spacing: 3) {
                ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .tint(subjectColor(s.lesson.subject))
                HStack(spacing: 3) {
                    Text("до \(hm(s.end)) ·")
                    Text(s.end, style: .relative)
                }
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.white.opacity(0.8))
            }
        } else {
            HStack(spacing: 3) {
                Text(whenText(s))
                if Calendar.current.isDate(s.start, inSameDayAs: entry.date) {
                    Text("· через")
                    Text(s.start, style: .relative)
                }
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(accent)
            .lineLimit(1)
        }
    }

    private var emptyView: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                header("САФУ · \(entry.group)")
                Spacer()
                refreshButton
            }
            Spacer(minLength: 0)
            Text(entry.status ?? "Пар на неделе нет")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
            Text("Нажми ↻, чтобы загрузить из РУЗ")
                .font(.system(size: 10))
                .foregroundStyle(.white.opacity(0.6))
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    /// Аудитория и ПОЛНЫЙ адрес корпуса
    private func placeBlock(_ s: LessonSlot, addressLines: Int = 2, size: CGFloat = 12) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            if !s.lesson.room.isEmpty {
                HStack(spacing: 4) {
                    Image(systemName: "door.left.hand.open")
                    Text("ауд. \(s.lesson.room)")
                }
                .font(.system(size: size, weight: .heavy))
                .foregroundStyle(.white)
                .lineLimit(1)
            }
            if !s.address.isEmpty {
                HStack(alignment: .top, spacing: 4) {
                    Image(systemName: "mappin.and.ellipse")
                    Text(AddressFormat.full(s.address))
                }
                .font(.system(size: size - 1, weight: .semibold))
                .foregroundStyle(.white.opacity(0.85))
                .lineLimit(addressLines)
                .minimumScaleFactor(0.6)
            }
        }
    }

    // MARK: маленький

    @ViewBuilder private var small: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    header(isNow ? "СЕЙЧАС · \(s.lesson.pair)" : "ДАЛЕЕ · \(s.lesson.pair)", color: subjectColor(s.lesson.subject))
                    Spacer()
                    refreshButton
                }
                KindBadge(kind: s.lesson.kind, size: 9)
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 2)
                if !s.lesson.room.isEmpty || !s.address.isEmpty { placeBlock(s) }
                timeInfo(s)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    // MARK: средний

    @ViewBuilder private var medium: some View {
        if let s = slot {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    header(isNow ? "СЕЙЧАС · \(s.lesson.pair) ПАРА" : "ДАЛЕЕ · \(s.lesson.pair) ПАРА",
                           color: subjectColor(s.lesson.subject))
                    Text(s.lesson.subject)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                    HStack(spacing: 5) {
                        KindBadge(kind: s.lesson.kind, size: 9)
                        Text("\(hm(s.start))–\(hm(s.end))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.75))
                    }
                    if entry.showTeacher && !s.lesson.teacher.isEmpty {
                        Label(s.lesson.teacher, systemImage: "person.fill")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.7))
                            .lineLimit(1)
                    }
                    Spacer(minLength: 2)
                    if !s.lesson.room.isEmpty || !s.address.isEmpty { placeBlock(s) }
                    timeInfo(s)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(entry.dayTitle.uppercased())
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundStyle(.white.opacity(0.6))
                            .lineLimit(1)
                        Spacer(minLength: 2)
                        refreshButton
                    }
                    let rest = entry.daySlots.filter { $0.key != s.key && $0.end > entry.date }.prefix(3)
                    if rest.isEmpty {
                        Text(entry.tomorrowInfo.isEmpty ? "Больше пар нет" : entry.tomorrowInfo.capitalizedFirstLetter)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.8))
                    } else {
                        ForEach(Array(rest), id: \.key) { r in
                            miniRow(r)
                        }
                    }
                    Spacer(minLength: 0)
                    Text(updatedText)
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.45))
                }
                .frame(width: 124, alignment: .leading)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    private func miniRow(_ r: LessonSlot) -> some View {
        HStack(alignment: .top, spacing: 6) {
            RoundedRectangle(cornerRadius: 2)
                .fill(KindStyle.of(r.lesson.kind).color)
                .frame(width: 3, height: 26)
            VStack(alignment: .leading, spacing: 1) {
                Text("\(hm(r.start)) · \(KindStyle.of(r.lesson.kind).label)\(r.lesson.room.isEmpty ? "" : " · \(r.lesson.room)")")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.7))
                Text(r.lesson.subject)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }
        }
    }

    // MARK: большой — весь день

    @ViewBuilder private var large: some View {
        if entry.daySlots.isEmpty && slot == nil {
            emptyView
        } else {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(entry.dayTitle)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Группа \(entry.group) · \(entry.daySlots.count) \(WidgetStore.pairsWord(entry.daySlots.count))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.65))
                    }
                    Spacer()
                    refreshButton
                }

                if let s = slot, isNow {
                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 6) {
                            header("СЕЙЧАС", color: subjectColor(s.lesson.subject))
                            KindBadge(kind: s.lesson.kind, size: 9)
                        }
                        Text(s.lesson.subject)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        if !s.lesson.room.isEmpty || !s.address.isEmpty { placeBlock(s) }
                        timeInfo(s)
                    }
                    .padding(10)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }

                VStack(alignment: .leading, spacing: 5) {
                    ForEach(entry.daySlots.prefix(7), id: \.key) { r in
                        largeRow(r)
                    }
                }

                Spacer(minLength: 0)

                HStack {
                    if !entry.tomorrowInfo.isEmpty {
                        Text(entry.tomorrowInfo.capitalizedFirstLetter)
                    }
                    Spacer()
                    Text(updatedText)
                }
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.white.opacity(0.55))
                .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }

    private func largeRow(_ r: LessonSlot) -> some View {
        let active = r.start <= entry.date && entry.date < r.end
        let past = r.end <= entry.date
        return HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .trailing, spacing: 0) {
                Text(hm(r.start)).font(.system(size: 11, weight: .bold)).monospacedDigit()
                Text(hm(r.end)).font(.system(size: 9)).monospacedDigit().opacity(0.6)
            }
            .frame(width: 34, alignment: .trailing)
            .foregroundStyle(.white)
            RoundedRectangle(cornerRadius: 2)
                .fill(KindStyle.of(r.lesson.kind).color)
                .frame(width: 4, height: 30)
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    KindBadge(kind: r.lesson.kind, size: 8)
                    Text(r.lesson.subject)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }
                Text([r.lesson.room.isEmpty ? "" : "ауд. \(r.lesson.room)", AddressFormat.full(r.address), entry.showTeacher ? r.lesson.teacher : ""]
                        .filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.75))
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
            Spacer(minLength: 0)
            if active {
                Circle().fill(subjectColor(r.lesson.subject)).frame(width: 7, height: 7)
            }
        }
        .padding(.vertical, 2)
        .padding(.horizontal, 6)
        .background(active ? Color.white.opacity(0.10) : Color.clear,
                    in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .opacity(past ? 0.45 : 1)
    }

    // MARK: экран блокировки

    @ViewBuilder private var inline: some View {
        if let s = slot {
            let place = [KindStyle.of(s.lesson.kind).label, s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)"]
                .filter { !$0.isEmpty }.joined(separator: ", ")
            Text(isNow ? "До \(hm(s.end)) · \(place)" : "\(hm(s.start)) · \(place)")
        } else {
            Text("Пар нет")
        }
    }

    private func rectTop(_ s: LessonSlot) -> String {
        var parts: [String] = [isNow ? "до \(hm(s.end))" : whenText(s)]
        parts.append(KindStyle.of(s.lesson.kind).label)
        if !s.lesson.room.isEmpty { parts.append("ауд. \(s.lesson.room)") }
        return parts.joined(separator: " · ")
    }

    @ViewBuilder private var rectangular: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Image(systemName: "snowflake")
                    Text(rectTop(s))
                }
                .font(.system(size: 11, weight: .bold))
                .lineLimit(1)
                .minimumScaleFactor(0.7)
                .widgetAccentable()
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold))
                    .lineLimit(1)
                Text(s.address.isEmpty ? s.lesson.kind : AddressFormat.full(s.address))
                    .font(.system(size: 12))
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
            VStack(alignment: .leading) {
                Text("САФУ").font(.system(size: 11, weight: .bold))
                Text(entry.status ?? "Пар нет").font(.system(size: 14, weight: .bold))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder private var circular: some View {
        if let s = slot, isNow {
            ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: true) {
                EmptyView()
            } currentValueLabel: {
                Text(s.lesson.room.isEmpty ? "\(s.lesson.pair)" : s.lesson.room)
                    .font(.system(size: 12, weight: .bold))
                    .minimumScaleFactor(0.5)
            }
            .progressViewStyle(.circular)
        } else if let s = slot {
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: 0) {
                    Text(hm(s.start)).font(.system(size: 13, weight: .bold)).minimumScaleFactor(0.6)
                    Text(s.lesson.room.isEmpty ? "\(s.lesson.pair) п." : s.lesson.room)
                        .font(.system(size: 10))
                        .minimumScaleFactor(0.5)
                }
            }
        } else {
            ZStack {
                AccessoryWidgetBackground()
                Image(systemName: "snowflake")
            }
        }
    }
}

// MARK: - Виджет

struct PairWidget: Widget {
    let kind = "PairWidgetV3"

    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: PairWidgetConfig.self, provider: PairProvider()) { entry in
            PairWidgetView(entry: entry)
        }
        .configurationDisplayName("Пары САФУ")
        .description("Текущая и следующая пара, аудитория, адрес и весь день. Удержи виджет → «Изменить виджет»: группа и оформление.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge,
                            .accessoryRectangular, .accessoryInline, .accessoryCircular])
    }
}

@main
struct SAFUWidgets: WidgetBundle {
    var body: some Widget {
        PairWidget()
        PairLiveActivity()
        BusLiveActivity()
    }
}
