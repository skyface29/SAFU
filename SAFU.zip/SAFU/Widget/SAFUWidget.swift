import WidgetKit
import SwiftUI
import AppIntents

// Виджет работает сам по себе: сам ходит в РУЗ и хранит кеш у себя.
// Поэтому ему не нужны общие данные с приложением (App Groups), которые теряются при переподписи.

// MARK: - Настройка виджета (удержать виджет → «Изменить виджет»)

enum InstitutionOption: Int, AppEnum {
    case vshitas = 3, vish = 15, natural = 1, humanities = 4, economics = 28, energy = 12, pedagogy = 13, fishery = 36

    static let typeDisplayRepresentation: TypeDisplayRepresentation = "Высшая школа"
    static let caseDisplayRepresentations: [InstitutionOption: DisplayRepresentation] = [
        .vshitas: "ВШИТАС",
        .vish: "Высшая инженерная школа",
        .natural: "ВШ естественных наук",
        .humanities: "ВШ соц.-гум. наук",
        .economics: "ВШ экономики и права",
        .energy: "ВШ энергетики",
        .pedagogy: "ВШ педагогики",
        .fishery: "ВШ рыболовства"
    ]
}

struct PairConfigIntent: WidgetConfigurationIntent {
    static let title: LocalizedStringResource = "Расписание САФУ"
    static let description = IntentDescription("Группа, для которой показывать пары из РУЗ.")

    @Parameter(title: "Группа", default: "151621")
    var group: String

    @Parameter(title: "Высшая школа", default: .vshitas)
    var institution: InstitutionOption

    init() {}
}

// MARK: - Данные

struct PairEntry: TimelineEntry {
    let date: Date
    let group: String
    let current: LessonSlot?
    let next: LessonSlot?
    let dayTitle: String
    let daySlots: [LessonSlot]
    let tomorrowInfo: String
    let lastSync: Date?
    let status: String?
}

enum WidgetStore {
    private static func key(_ group: String) -> String { "widget.cache.\(group)" }

    static func loadCache(_ group: String) -> ScheduleData? {
        guard let raw = UserDefaults.standard.data(forKey: key(group)) else { return nil }
        return try? JSONDecoder().decode(ScheduleData.self, from: raw)
    }

    static func saveCache(_ data: ScheduleData, _ group: String) {
        if let raw = try? JSONEncoder().encode(data) {
            UserDefaults.standard.set(raw, forKey: key(group))
        }
    }

    /// Берём данные приложения (если доступны), иначе свой кеш; при необходимости обновляем из РУЗ
    static func data(group: String, institution: Int) async -> (ScheduleData, String?) {
        let shared = SharedSchedule.load()
        var data: ScheduleData
        if shared.usesRuz, !shared.ruzEvents.isEmpty, shared.ruzGroupNumber == group {
            data = shared
            if let own = loadCache(group), let a = own.lastSync, let b = shared.lastSync, a > b { data = own }
        } else if let own = loadCache(group) {
            data = own
        } else {
            data = ScheduleData()
            data.source = 1
            data.ruzGroupNumber = group
            data.ruzInstitution = institution
        }
        data.source = 1

        var status: String?
        let stale = data.lastSync.map { Date().timeIntervalSince($0) > 2 * 3600 } ?? true
        if stale {
            do {
                if data.ruzGroupID.isEmpty {
                    data.ruzGroupID = try await RuzClient.findGroupID(number: group, institution: institution,
                                                                      searchAll: false) ?? ""
                }
                if data.ruzGroupID.isEmpty {
                    status = "Группа \(group) не найдена"
                } else {
                    let r = try await RuzClient.load(groupID: data.ruzGroupID)
                    if !r.events.isEmpty { data.mergeRuz(r.events) }
                    data.lastSync = Date()
                    if r.events.isEmpty { status = r.notice }
                }
                saveCache(data, group)
            } catch {
                status = data.ruzEvents.isEmpty ? "Нет связи с РУЗ" : nil
            }
        }
        return (data, status)
    }

    static func entry(at date: Date, group: String, data: ScheduleData, status: String?) -> PairEntry {
        let cal = Calendar.current
        let r = ScheduleEngine.nowAndNext(at: date, data: data)

        // Какой день показывать списком: сегодня, а если пары кончились — ближайший учебный
        var showDay = date
        var slots = ScheduleEngine.slots(on: date, data: data)
        if slots.isEmpty || (slots.last.map { $0.end <= date } ?? true) {
            for offset in 1..<8 {
                guard let d = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: date)) else { continue }
                let s = ScheduleEngine.slots(on: d, data: data)
                if !s.isEmpty { showDay = d; slots = s; break }
            }
        }

        var tomorrowInfo = ""
        if let t = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: showDay)) {
            let s = ScheduleEngine.slots(on: t, data: data)
            if let first = s.first {
                tomorrowInfo = "\(dayName(t, from: date)): \(s.count) \(pairsWord(s.count)), с \(hm(first.start))"
            }
        }

        return PairEntry(date: date, group: group, current: r.current, next: r.next,
                         dayTitle: dayName(showDay, from: date).capitalizedFirstLetter,
                         daySlots: slots, tomorrowInfo: tomorrowInfo,
                         lastSync: data.lastSync, status: status)
    }

    static func dayName(_ d: Date, from now: Date) -> String {
        let cal = Calendar.current
        if cal.isDate(d, inSameDayAs: now) { return "сегодня" }
        if let t = cal.date(byAdding: .day, value: 1, to: now), cal.isDate(d, inSameDayAs: t) { return "завтра" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EEEE, d MMM"
        return f.string(from: d)
    }

    static func pairsWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "пара" }
        if (2...4).contains(m10) && !(12...14).contains(m100) { return "пары" }
        return "пар"
    }
}

func hm(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

extension String {
    var capitalizedFirstLetter: String { prefix(1).uppercased() + dropFirst() }
}

func subjectColor(_ s: String) -> Color {
    var h: UInt64 = 5381
    for u in s.lowercased().unicodeScalars { h = (h &* 33) &+ UInt64(u.value) }
    return Color(hue: Double(h % 360) / 360.0, saturation: 0.5, brightness: 1.0)
}

// MARK: - Провайдер

struct PairProvider: AppIntentTimelineProvider {
    func placeholder(in context: Context) -> PairEntry {
        let start = Date().addingTimeInterval(-30 * 60)
        let a = LessonSlot(lesson: Lesson(subject: "Алгоритмизация и программирование", kind: "Лекция",
                                          pair: 2, room: "3104", building: "наб. Северной Двины, 17",
                                          teacher: "Иванов И.И."),
                           start: start, end: start.addingTimeInterval(95 * 60),
                           address: "наб. Северной Двины, 17")
        let b = LessonSlot(lesson: Lesson(subject: "Иностранный язык", kind: "Практика", pair: 3, room: "42"),
                           start: start.addingTimeInterval(110 * 60), end: start.addingTimeInterval(205 * 60),
                           address: "наб. Северной Двины, д. 2")
        return PairEntry(date: Date(), group: "151621", current: a, next: b, dayTitle: "Сегодня",
                         daySlots: [a, b], tomorrowInfo: "завтра: 3 пары, с 8:20", lastSync: Date(), status: nil)
    }

    func snapshot(for configuration: PairConfigIntent, in context: Context) async -> PairEntry {
        if context.isPreview { return placeholder(in: context) }
        let group = configuration.group.trimmingCharacters(in: .whitespaces)
        let (data, status) = await WidgetStore.data(group: group, institution: configuration.institution.rawValue)
        return WidgetStore.entry(at: Date(), group: group, data: data, status: status)
    }

    func timeline(for configuration: PairConfigIntent, in context: Context) async -> Timeline<PairEntry> {
        let group = configuration.group.trimmingCharacters(in: .whitespaces)
        let (data, status) = await WidgetStore.data(group: group, institution: configuration.institution.rawValue)
        let now = Date()
        let dates = Array(([now] + ScheduleEngine.boundaries(after: now, data: data)).prefix(40))
        let entries = dates.map { WidgetStore.entry(at: $0, group: group, data: data, status: status) }
        return Timeline(entries: entries, policy: .after(now.addingTimeInterval(3600)))
    }
}

// MARK: - Вид

private let bgTop = Color(red: 0.09, green: 0.20, blue: 0.48)
private let bgBottom = Color(red: 0.03, green: 0.07, blue: 0.20)
private let accent = Color(red: 0.50, green: 0.78, blue: 1.0)

struct PairWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: PairEntry

    private var slot: LessonSlot? { entry.current ?? entry.next }
    private var isNow: Bool { entry.current != nil }

    var body: some View {
        content
            .widgetURL(URL(string: "safu://schedule"))
            .containerBackground(for: .widget) {
                if family == .accessoryInline || family == .accessoryRectangular || family == .accessoryCircular {
                    Color.clear
                } else {
                    LinearGradient(colors: [bgTop, bgBottom], startPoint: .topLeading, endPoint: .bottomTrailing)
                }
            }
    }

    @ViewBuilder private var content: some View {
        switch family {
        case .accessoryInline: inline
        case .accessoryRectangular: rectangular
        case .accessoryCircular: circular
        case .systemMedium: medium
        case .systemLarge, .systemExtraLarge: large
        default: small
        }
    }

    // MARK: общие куски

    private func header(_ text: String, color: Color = accent) -> some View {
        HStack(spacing: 4) {
            Image(systemName: isNow ? "dot.radiowaves.left.and.right" : "snowflake")
            Text(text)
        }
        .font(.system(size: 11, weight: .heavy))
        .foregroundStyle(color)
    }

    private func whenText(_ s: LessonSlot) -> String {
        let name = WidgetStore.dayName(s.start, from: entry.date)
        return name == "сегодня" ? "в \(hm(s.start))" : "\(name) в \(hm(s.start))"
    }

    @ViewBuilder private func timeInfo(_ s: LessonSlot) -> some View {
        if isNow {
            VStack(alignment: .leading, spacing: 3) {
                ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .tint(subjectColor(s.lesson.subject))
                HStack(spacing: 3) {
                    Text("до \(hm(s.end)) ·")
                    Text(s.end, style: .relative)
                }
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.white.opacity(0.8))
            }
        } else {
            HStack(spacing: 3) {
                Text(whenText(s))
                if Calendar.current.isDate(s.start, inSameDayAs: entry.date) {
                    Text("· через")
                    Text(s.start, style: .relative)
                }
            }
            .font(.system(size: 11, weight: .semibold))
            .foregroundStyle(accent)
            .lineLimit(1)
        }
    }

    private var emptyView: some View {
        VStack(alignment: .leading, spacing: 4) {
            header("САФУ · \(entry.group)")
            Spacer(minLength: 0)
            Text(entry.status ?? "Пар на неделе нет")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
            Text("Удерживай виджет → «Изменить», чтобы сменить группу")
                .font(.system(size: 10))
                .foregroundStyle(.white.opacity(0.6))
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private func roomLine(_ s: LessonSlot) -> some View {
        HStack(spacing: 4) {
            Image(systemName: "mappin.circle.fill")
            Text(s.lesson.room.isEmpty ? s.address : "ауд. \(s.lesson.room)")
                .lineLimit(1)
        }
        .font(.system(size: 12, weight: .bold))
        .foregroundStyle(.white)
    }

    // MARK: маленький

    @ViewBuilder private var small: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    header(isNow ? "СЕЙЧАС" : "ДАЛЕЕ", color: subjectColor(s.lesson.subject))
                    Spacer()
                    Text("\(s.lesson.pair)")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white.opacity(0.7))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(.white.opacity(0.15), in: Capsule())
                }
                Text(s.lesson.subject)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(3)
                    .minimumScaleFactor(0.8)
                Text(s.lesson.kind)
                    .font(.system(size: 11))
                    .foregroundStyle(.white.opacity(0.65))
                Spacer(minLength: 2)
                if !s.lesson.room.isEmpty || !s.address.isEmpty { roomLine(s) }
                timeInfo(s)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    // MARK: средний

    @ViewBuilder private var medium: some View {
        if let s = slot {
            HStack(alignment: .top, spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    header(isNow ? "СЕЙЧАС · \(s.lesson.pair) ПАРА" : "ДАЛЕЕ · \(s.lesson.pair) ПАРА",
                           color: subjectColor(s.lesson.subject))
                    Text(s.lesson.subject)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                    Text("\(s.lesson.kind) · \(hm(s.start))–\(hm(s.end))")
                        .font(.system(size: 11))
                        .foregroundStyle(.white.opacity(0.7))
                    Spacer(minLength: 2)
                    if !s.lesson.room.isEmpty || !s.address.isEmpty { roomLine(s) }
                    timeInfo(s)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .leading, spacing: 6) {
                    Text(entry.dayTitle.uppercased())
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundStyle(.white.opacity(0.6))
                        .lineLimit(1)
                    let rest = entry.daySlots.filter { $0.key != s.key && $0.end > entry.date }.prefix(3)
                    if rest.isEmpty {
                        Text(entry.tomorrowInfo.isEmpty ? "Больше пар нет" : entry.tomorrowInfo.capitalizedFirstLetter)
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.8))
                    } else {
                        ForEach(Array(rest), id: \.key) { r in
                            miniRow(r)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .frame(width: 120, alignment: .leading)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        } else {
            emptyView
        }
    }

    private func miniRow(_ r: LessonSlot) -> some View {
        HStack(alignment: .top, spacing: 6) {
            RoundedRectangle(cornerRadius: 2)
                .fill(subjectColor(r.lesson.subject))
                .frame(width: 3, height: 26)
            VStack(alignment: .leading, spacing: 1) {
                Text("\(hm(r.start)) · \(r.lesson.room.isEmpty ? r.lesson.kind : r.lesson.room)")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.7))
                Text(r.lesson.subject)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }
        }
    }

    // MARK: большой — весь день

    @ViewBuilder private var large: some View {
        if entry.daySlots.isEmpty && slot == nil {
            emptyView
        } else {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .firstTextBaseline) {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(entry.dayTitle)
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Группа \(entry.group) · \(entry.daySlots.count) \(WidgetStore.pairsWord(entry.daySlots.count))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.65))
                    }
                    Spacer()
                    Image(systemName: "snowflake")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(accent)
                }

                if let s = slot, isNow {
                    VStack(alignment: .leading, spacing: 4) {
                        header("СЕЙЧАС", color: subjectColor(s.lesson.subject))
                        Text(s.lesson.subject)
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        if !s.lesson.room.isEmpty || !s.address.isEmpty { roomLine(s) }
                        timeInfo(s)
                    }
                    .padding(10)
                    .background(.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }

                VStack(alignment: .leading, spacing: 5) {
                    ForEach(entry.daySlots.prefix(7), id: \.key) { r in
                        largeRow(r)
                    }
                }

                Spacer(minLength: 0)

                HStack {
                    if !entry.tomorrowInfo.isEmpty {
                        Text(entry.tomorrowInfo.capitalizedFirstLetter)
                    }
                    Spacer()
                    if let last = entry.lastSync {
                        Text("РУЗ \(hm(last))")
                    }
                }
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.white.opacity(0.55))
                .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
    }

    private func largeRow(_ r: LessonSlot) -> some View {
        let active = r.start <= entry.date && entry.date < r.end
        let past = r.end <= entry.date
        return HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .trailing, spacing: 0) {
                Text(hm(r.start)).font(.system(size: 11, weight: .bold)).monospacedDigit()
                Text(hm(r.end)).font(.system(size: 9)).monospacedDigit().opacity(0.6)
            }
            .frame(width: 34, alignment: .trailing)
            .foregroundStyle(.white)
            RoundedRectangle(cornerRadius: 2)
                .fill(subjectColor(r.lesson.subject))
                .frame(width: 3, height: 28)
            VStack(alignment: .leading, spacing: 1) {
                Text(r.lesson.subject)
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text([r.lesson.kind, r.lesson.room.isEmpty ? "" : "ауд. \(r.lesson.room)", r.lesson.teacher]
                        .filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 10))
                    .foregroundStyle(.white.opacity(0.65))
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            if active {
                Circle().fill(subjectColor(r.lesson.subject)).frame(width: 7, height: 7)
            }
        }
        .padding(.vertical, 2)
        .padding(.horizontal, 6)
        .background(active ? Color.white.opacity(0.10) : Color.clear,
                    in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .opacity(past ? 0.45 : 1)
    }

    // MARK: экран блокировки

    @ViewBuilder private var inline: some View {
        if let s = slot {
            if isNow {
                Text("До \(hm(s.end)): \(s.lesson.subject)\(s.lesson.room.isEmpty ? "" : ", \(s.lesson.room)")")
            } else {
                Text("\(hm(s.start)) \(s.lesson.subject)\(s.lesson.room.isEmpty ? "" : ", \(s.lesson.room)")")
            }
        } else {
            Text("Пар нет")
        }
    }

    @ViewBuilder private var rectangular: some View {
        if let s = slot {
            VStack(alignment: .leading, spacing: 1) {
                HStack(spacing: 4) {
                    Image(systemName: "snowflake")
                    if isNow {
                        Text("СЕЙЧАС · до \(hm(s.end))")
                    } else {
                        Text(whenText(s).uppercased())
                    }
                }
                .font(.system(size: 11, weight: .bold))
                .widgetAccentable()
                Text(s.lesson.subject)
                    .font(.system(size: 14, weight: .bold))
                    .lineLimit(1)
                Text([s.lesson.room.isEmpty ? "" : "ауд. \(s.lesson.room)", "\(s.lesson.pair) пара", s.lesson.kind]
                        .filter { !$0.isEmpty }.joined(separator: " · "))
                    .font(.system(size: 12))
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        } else {
            VStack(alignment: .leading) {
                Text("САФУ").font(.system(size: 11, weight: .bold))
                Text(entry.status ?? "Пар нет").font(.system(size: 14, weight: .bold))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    @ViewBuilder private var circular: some View {
        if let s = slot, isNow {
            ProgressView(timerInterval: s.start...max(s.end, s.start.addingTimeInterval(60)), countsDown: true) {
                EmptyView()
            } currentValueLabel: {
                Text(s.lesson.room.isEmpty ? "\(s.lesson.pair)" : s.lesson.room)
                    .font(.system(size: 12, weight: .bold))
                    .minimumScaleFactor(0.5)
            }
            .progressViewStyle(.circular)
        } else if let s = slot {
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: 0) {
                    Text(hm(s.start)).font(.system(size: 13, weight: .bold)).minimumScaleFactor(0.6)
                    Text(s.lesson.room.isEmpty ? "\(s.lesson.pair) п." : s.lesson.room)
                        .font(.system(size: 10))
                        .minimumScaleFactor(0.5)
                }
            }
        } else {
            ZStack {
                AccessoryWidgetBackground()
                Image(systemName: "snowflake")
            }
        }
    }
}

// MARK: - Виджет

struct PairWidget: Widget {
    let kind = "PairWidgetV2"

    var body: some WidgetConfiguration {
        AppIntentConfiguration(kind: kind, intent: PairConfigIntent.self, provider: PairProvider()) { entry in
            PairWidgetView(entry: entry)
        }
        .configurationDisplayName("Пары САФУ")
        .description("Текущая и следующая пара, аудитория, адрес и весь день. Данные из РУЗ.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge,
                            .accessoryRectangular, .accessoryInline, .accessoryCircular])
    }
}

@main
struct SAFUWidgets: WidgetBundle {
    var body: some Widget {
        PairWidget()
    }
}
