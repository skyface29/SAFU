import WidgetKit
import SwiftUI
import ActivityKit

private let islandAccent = Color(red: 0.50, green: 0.78, blue: 1.0)

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            let theme = LiveTheme(rawValue: context.state.theme) ?? .night
            LiveLockScreenView(state: context.state)
                .widgetURL(URL(string: "safu://schedule"))
                .activityBackgroundTint(theme.tint)
                .activitySystemActionForegroundColor(theme.adaptiveText ? .primary : .white)
        } dynamicIsland: { context in
            let s = context.state
            let st = KindStyle.of(s.kind)
            let place = LivePlace(s)
            let target = s.isNow ? s.end : s.start
            return DynamicIsland {
                // слева: тип пары и номер
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 3) {
                        LiveKindBadge(kind: s.kind, size: 10)
                        Text((s.pair > 0 ? "\(s.pair) пара · " : "") + LiveFormat.hmText(s.start))
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .padding(.leading, 4)
                }
                // справа: таймер
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        LiveTimer(to: target, width: 66)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(islandAccent)
                        Text(s.isNow ? "до конца" : "до начала")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.trailing, 4)
                }
                // снизу: предмет, аудитория, адрес, преподаватель, прогресс
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(s.subject)
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        HStack(spacing: 6) {
                            if !place.roomText.isEmpty {
                                Label(place.roomText, systemImage: "mappin.circle.fill")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(st.color)
                                    .fixedSize()
                            }
                            Text(place.address)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                            Spacer(minLength: 4)
                            if !s.teacher.isEmpty {
                                Text(s.teacher)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                        if s.isNow {
                            ProgressView(timerInterval: s.start...s.end, countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(st.color)
                        }
                    }
                    .padding(.horizontal, 4)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: st.icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(st.color)
                    .padding(.leading, 2)
            } compactTrailing: {
                LiveTimer(to: target, width: 44)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(islandAccent)
            } minimal: {
                if s.isNow {
                    ProgressView(timerInterval: s.start...s.end, countsDown: true) {
                        EmptyView()
                    } currentValueLabel: {
                        Image(systemName: st.icon).font(.system(size: 9, weight: .bold))
                    }
                    .progressViewStyle(.circular)
                    .tint(st.color)
                } else {
                    Image(systemName: st.icon)
                        .foregroundStyle(st.color)
                }
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(st.color)
        }
    }
}


// MARK: - Автобус 150

private let busOrange = Color(red: 0.95, green: 0.55, blue: 0.10)

struct BusLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: BusActivityAttributes.self) { context in
            let theme = LiveTheme(rawValue: context.state.theme) ?? .night
            BusLockScreenView(state: context.state)
                .widgetURL(URL(string: "safu://home"))
                .activityBackgroundTint(theme.tint)
                .activitySystemActionForegroundColor(theme.adaptiveText ? .primary : .white)
        } dynamicIsland: { context in
            let s = context.state
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label("150", systemImage: "bus.fill")
                        .font(.subheadline.weight(.heavy))
                        .foregroundStyle(busOrange)
                        .padding(.leading, 4)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        LiveTimer(to: s.departure, width: 66)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(busOrange)
                        Text("до отправления").font(.caption2).foregroundStyle(.secondary)
                    }
                    .padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(s.from) → \(s.to)")
                            .font(.system(size: 14, weight: .semibold))
                            .lineLimit(1)
                        HStack(spacing: 6) {
                            Text(LiveFormat.hmText(s.departure)).font(.caption.weight(.bold))
                            ProgressView(timerInterval: s.departure...s.arrival, countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(busOrange)
                            Text("~" + LiveFormat.hmText(s.arrival)).font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        }
                    }
                    .padding(.horizontal, 4)
                }
            } compactLeading: {
                Image(systemName: "bus.fill").foregroundStyle(busOrange)
            } compactTrailing: {
                LiveTimer(to: s.departure, width: 44)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(busOrange)
            } minimal: {
                Image(systemName: "bus.fill").foregroundStyle(busOrange)
            }
            .widgetURL(URL(string: "safu://home"))
            .keylineTint(busOrange)
        }
    }
}
