import WidgetKit
import SwiftUI
import ActivityKit

private let islandAccent = Color(red: 0.50, green: 0.78, blue: 1.0)

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            let theme = LiveTheme(rawValue: context.state.theme) ?? .night
            LiveLockScreenView(state: context.state)
                .widgetURL(URL(string: "safu://schedule"))
                .activityBackgroundTint(theme.tint)
                .activitySystemActionForegroundColor(theme.adaptiveText ? .primary : .white)
        } dynamicIsland: { context in
            let s = context.state
            let st = KindStyle.of(s.kind)
            let place = LivePlace(s)
            let target = s.isNow ? s.end : s.start
            return DynamicIsland {
                // слева: тип пары и номер
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 3) {
                        LiveKindBadge(kind: s.kind, size: 10)
                        Text((s.pair > 0 ? "\(s.pair) пара · " : "") + LiveFormat.hmText(s.start))
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .padding(.leading, 4)
                }
                // справа: таймер
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        LiveTimer(to: target, width: 66)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(islandAccent)
                        Text(s.isNow ? "до конца" : "до начала")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.trailing, 4)
                }
                // снизу: предмет, аудитория, адрес, преподаватель, прогресс
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(s.subject)
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        HStack(spacing: 6) {
                            if !place.roomText.isEmpty {
                                Label(place.roomText, systemImage: "mappin.circle.fill")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(st.color)
                                    .fixedSize()
                            }
                            Text(place.address)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                            Spacer(minLength: 4)
                            if !s.teacher.isEmpty {
                                Text(s.teacher)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                        if s.isNow {
                            ProgressView(timerInterval: s.start...s.end, countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(st.color)
                        }
                    }
                    .padding(.horizontal, 4)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: st.icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(st.color)
                    .padding(.leading, 2)
            } compactTrailing: {
                LiveTimer(to: target, width: 44)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(islandAccent)
            } minimal: {
                if s.isNow {
                    ProgressView(timerInterval: s.start...s.end, countsDown: true) {
                        EmptyView()
                    } currentValueLabel: {
                        Image(systemName: st.icon).font(.system(size: 9, weight: .bold))
                    }
                    .progressViewStyle(.circular)
                    .tint(st.color)
                } else {
                    Image(systemName: st.icon)
                        .foregroundStyle(st.color)
                }
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(st.color)
        }
    }
}


// MARK: - Автобус (любой маршрут)

struct BusLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: BusActivityAttributes.self) { context in
            let theme = LiveTheme(rawValue: context.state.theme) ?? .night
            BusLockScreenView(state: context.state, route: context.attributes.route, color: context.attributes.color)
                .widgetURL(URL(string: "safu://home"))
                .activityBackgroundTint(theme.tint)
                .activitySystemActionForegroundColor(theme.adaptiveText ? .primary : .white)
        } dynamicIsland: { context in
            let s = context.state
            let busColor = context.attributes.color
            let route = context.attributes.route
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label(route, systemImage: "bus.fill")
                        .font(.subheadline.weight(.heavy))
                        .foregroundStyle(busColor)
                        .padding(.leading, 4)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        LiveTimer(to: s.departure, width: 66)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(busColor)
                        Text("до отправления").font(.caption2).foregroundStyle(.secondary)
                    }
                    .padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("\(s.from) → \(s.to)")
                            .font(.system(size: 14, weight: .semibold))
                            .lineLimit(1)
                        HStack(spacing: 6) {
                            Text(LiveFormat.hmText(s.departure)).font(.caption.weight(.bold))
                            ProgressView(timerInterval: s.departure...s.arrival, countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(busColor)
                            Text("~" + LiveFormat.hmText(s.arrival)).font(.caption.weight(.bold)).foregroundStyle(.secondary)
                        }
                        Button(intent: StopBusLiveIntent()) {
                            Label("Убрать автобус", systemImage: "xmark.circle.fill")
                                .font(.caption.weight(.semibold))
                                .frame(maxWidth: .infinity)
                        }
                        .tint(busColor)
                    }
                    .padding(.horizontal, 4)
                }
            } compactLeading: {
                HStack(spacing: 2) {
                    Image(systemName: "bus.fill")
                    Text(route).font(.system(size: 11, weight: .heavy))
                }
                .foregroundStyle(busColor)
            } compactTrailing: {
                LiveTimer(to: s.departure, width: 44)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(busColor)
            } minimal: {
                Image(systemName: "bus.fill").foregroundStyle(busColor)
            }
            .widgetURL(URL(string: "safu://home"))
            .keylineTint(busColor)
        }
    }
}
