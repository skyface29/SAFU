import WidgetKit
import SwiftUI
import ActivityKit

private let liveAccent = Color(red: 0.50, green: 0.78, blue: 1.0)

private func liveHM(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

/// Таймер без падения, если время уже прошло
private struct SafeTimer: View {
    let to: Date
    var body: some View {
        let now = Date()
        Text(timerInterval: min(now, to)...max(now, to), countsDown: true)
            .monospacedDigit()
    }
}

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            LiveLockScreenView(state: context.state)
                .activityBackgroundTint(Color(red: 0.05, green: 0.10, blue: 0.25))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            let s = context.state
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(s.isNow ? "СЕЙЧАС" : "ДАЛЕЕ")
                            .font(.caption2.weight(.heavy))
                            .foregroundStyle(liveAccent)
                        Text("\(s.pair) пара")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 2) {
                        SafeTimer(to: s.isNow ? s.end : s.start)
                            .font(.headline)
                            .frame(maxWidth: 80, alignment: .trailing)
                        Text(s.isNow ? "до конца" : "до начала")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
                DynamicIslandExpandedRegion(.center) {
                    VStack(spacing: 2) {
                        KindBadge(kind: s.kind, size: 9)
                        Text(s.subject)
                            .font(.subheadline.weight(.bold))
                            .lineLimit(1)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        if !s.room.isEmpty || !s.address.isEmpty {
                            HStack(spacing: 6) {
                                Image(systemName: "mappin.and.ellipse")
                                    .foregroundStyle(liveAccent)
                                Text([s.room.isEmpty ? "" : "ауд. \(s.room)", AddressFormat.full(s.address)]
                                        .filter { !$0.isEmpty }.joined(separator: " · "))
                                    .lineLimit(2)
                            }
                            .font(.caption.weight(.semibold))
                        }
                        if !s.nextSubject.isEmpty, let ns = s.nextStart {
                            Text("Потом в \(liveHM(ns)): \(s.nextSubject)\(s.nextRoom.isEmpty ? "" : ", ауд. \(s.nextRoom)")")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                HStack(spacing: 3) {
                    Image(systemName: "snowflake")
                        .foregroundStyle(liveAccent)
                    Text(s.room.isEmpty ? "\(s.pair)" : s.room)
                        .font(.caption2.weight(.bold))
                        .lineLimit(1)
                }
            } compactTrailing: {
                SafeTimer(to: s.isNow ? s.end : s.start)
                    .font(.caption2.weight(.semibold))
                    .frame(maxWidth: 44)
            } minimal: {
                Image(systemName: "snowflake")
                    .foregroundStyle(liveAccent)
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(liveAccent)
        }
    }
}

struct LiveLockScreenView: View {
    let state: PairActivityAttributes.ContentState

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                HStack(spacing: 5) {
                    Image(systemName: "snowflake")
                    Text(state.isNow ? "СЕЙЧАС · \(state.pair) ПАРА" : "СЛЕДУЮЩАЯ · \(state.pair) ПАРА")
                }
                .font(.caption.weight(.heavy))
                .foregroundStyle(liveAccent)
                Spacer()
                VStack(alignment: .trailing, spacing: 0) {
                    SafeTimer(to: state.isNow ? state.end : state.start)
                        .font(.title3.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: 100, alignment: .trailing)
                    Text(state.isNow ? "до конца" : "до начала")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.6))
                }
            }

            HStack(spacing: 6) {
                KindBadge(kind: state.kind, size: 10)
                Text(state.subject)
                    .font(.headline)
                    .foregroundStyle(.white)
                    .lineLimit(2)
            }

            Text("\(liveHM(state.start))–\(liveHM(state.end))\(state.teacher.isEmpty ? "" : " · \(state.teacher)")")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.7))
                .lineLimit(1)

            if !state.room.isEmpty || !state.address.isEmpty {
                HStack(alignment: .top, spacing: 6) {
                    Image(systemName: "mappin.circle.fill")
                        .foregroundStyle(liveAccent)
                    VStack(alignment: .leading, spacing: 1) {
                        if !state.room.isEmpty {
                            Text("ауд. \(state.room)").font(.subheadline.weight(.bold))
                        }
                        if !state.address.isEmpty {
                            Text(AddressFormat.full(state.address)).font(.caption.weight(.semibold)).lineLimit(2)
                        }
                    }
                    .foregroundStyle(.white)
                }
            }

            if state.isNow {
                ProgressView(timerInterval: state.start...max(state.end, state.start.addingTimeInterval(60)),
                             countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .tint(liveAccent)
            }

            if !state.nextSubject.isEmpty, let ns = state.nextStart {
                Text("Потом в \(liveHM(ns)): \(state.nextSubject)\(state.nextRoom.isEmpty ? "" : ", ауд. \(state.nextRoom)")")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.6))
                    .lineLimit(1)
            }
        }
        .padding(16)
    }
}
