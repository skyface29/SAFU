import WidgetKit
import SwiftUI
import ActivityKit

private let islandAccent = Color(red: 0.50, green: 0.78, blue: 1.0)

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            let theme = LiveTheme(rawValue: context.state.theme) ?? .night
            LiveLockScreenView(state: context.state)
                .widgetURL(URL(string: "safu://schedule"))
                .activityBackgroundTint(theme.tint)
                .activitySystemActionForegroundColor(theme.adaptiveText ? .primary : .white)
        } dynamicIsland: { context in
            let s = context.state
            let st = KindStyle.of(s.kind)
            let place = LivePlace(s)
            let target = s.isNow ? s.end : s.start
            return DynamicIsland {
                // слева: тип пары и номер
                DynamicIslandExpandedRegion(.leading) {
                    VStack(alignment: .leading, spacing: 3) {
                        LiveKindBadge(kind: s.kind, size: 10)
                        Text((s.pair > 0 ? "\(s.pair) пара · " : "") + LiveFormat.hmText(s.start))
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .padding(.leading, 4)
                }
                // справа: таймер
                DynamicIslandExpandedRegion(.trailing) {
                    VStack(alignment: .trailing, spacing: 1) {
                        LiveTimer(to: target, width: 66)
                            .font(.system(size: 20, weight: .bold, design: .rounded))
                            .foregroundStyle(islandAccent)
                        Text(s.isNow ? "до конца" : "до начала")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.trailing, 4)
                }
                // снизу: предмет, аудитория, адрес, преподаватель, прогресс
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(s.subject)
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                        HStack(spacing: 6) {
                            if !place.roomText.isEmpty {
                                Label(place.roomText, systemImage: "mappin.circle.fill")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(st.color)
                                    .fixedSize()
                            }
                            Text(place.address)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                            Spacer(minLength: 4)
                            if !s.teacher.isEmpty {
                                Text(s.teacher)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                        if s.isNow {
                            ProgressView(timerInterval: s.start...s.end, countsDown: false) {
                                EmptyView()
                            } currentValueLabel: {
                                EmptyView()
                            }
                            .tint(st.color)
                        }
                    }
                    .padding(.horizontal, 4)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: st.icon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(st.color)
                    .padding(.leading, 2)
            } compactTrailing: {
                LiveTimer(to: target, width: 44)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(islandAccent)
            } minimal: {
                if s.isNow {
                    ProgressView(timerInterval: s.start...s.end, countsDown: true) {
                        EmptyView()
                    } currentValueLabel: {
                        Image(systemName: st.icon).font(.system(size: 9, weight: .bold))
                    }
                    .progressViewStyle(.circular)
                    .tint(st.color)
                } else {
                    Image(systemName: st.icon)
                        .foregroundStyle(st.color)
                }
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(st.color)
        }
    }
}
