import WidgetKit
import SwiftUI
import ActivityKit

private let liveAccent = Color(red: 0.50, green: 0.78, blue: 1.0)

/// Обратный отсчёт фиксированной ширины (иначе таймер растягивается и вылезает за край)
private struct SafeTimer: View {
    let to: Date
    var width: CGFloat = 64
    var body: some View {
        let now = Date()
        Text(timerInterval: min(now, to)...max(now, to), countsDown: true)
            .monospacedDigit()
            .multilineTextAlignment(.trailing)
            .lineLimit(1)
            .frame(width: width, alignment: .trailing)
    }
}

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            LiveLockScreenView(state: context.state)
                .activityBackgroundTint(Color(red: 0.05, green: 0.10, blue: 0.25))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            let s = context.state
            let st = KindStyle.of(s.kind)
            let target = s.isNow ? s.end : s.start
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label(st.label, systemImage: st.icon)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(st.color)
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    SafeTimer(to: target, width: 64)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(liveAccent)
                }
            } compactLeading: {
                Image(systemName: st.icon)
                    .foregroundStyle(st.color)
            } compactTrailing: {
                SafeTimer(to: target, width: 42)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(liveAccent)
            } minimal: {
                Image(systemName: st.icon)
                    .foregroundStyle(st.color)
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(st.color)
        }
    }
}

/// Экран блокировки: одна тонкая строка — тип пары и сколько осталось
struct LiveLockScreenView: View {
    let state: PairActivityAttributes.ContentState

    var body: some View {
        let st = KindStyle.of(state.kind)
        HStack(spacing: 6) {
            Image(systemName: st.icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(st.color)
            Text(st.label)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
            Spacer(minLength: 4)
            Text(state.isNow ? "ещё" : "через")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.white.opacity(0.55))
            SafeTimer(to: state.isNow ? state.end : state.start, width: 58)
                .font(.system(size: 15, weight: .bold))
                .foregroundStyle(liveAccent)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
    }
}
