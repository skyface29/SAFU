import WidgetKit
import SwiftUI
import ActivityKit

private let liveAccent = Color(red: 0.50, green: 0.78, blue: 1.0)
private let liveDim = Color.white.opacity(0.62)

private func liveHM(_ d: Date) -> String {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ru_RU")
    f.dateFormat = "H:mm"
    return f.string(from: d)
}

/// Обратный отсчёт фиксированной ширины (иначе таймер растягивается и вылезает за край)
private struct SafeTimer: View {
    let to: Date
    var width: CGFloat = 64
    var body: some View {
        let now = Date()
        Text(timerInterval: min(now, to)...max(now, to), countsDown: true)
            .monospacedDigit()
            .multilineTextAlignment(.trailing)
            .lineLimit(1)
            .frame(width: width, alignment: .trailing)
    }
}

/// Аудитория и адрес в нормальном виде
private struct LivePlace {
    let room: String
    let address: String

    init(_ s: PairActivityAttributes.ContentState) {
        if AddressFormat.isRemote(s.address) {
            room = s.room
            address = "Дистанционно"
        } else {
            let d = AddressFormat.decode(room: s.room, address: s.address, buildings: [])
            room = d.room
            address = d.address
        }
    }

    var roomText: String { room.isEmpty ? "" : "ауд. \(room)" }
}

struct PairLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: PairActivityAttributes.self) { context in
            LiveLockScreenView(state: context.state)
                .activityBackgroundTint(Color(red: 0.05, green: 0.10, blue: 0.25))
                .activitySystemActionForegroundColor(.white)
        } dynamicIsland: { context in
            let s = context.state
            let st = KindStyle.of(s.kind)
            let place = LivePlace(s)
            let target = s.isNow ? s.end : s.start
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label(st.label, systemImage: st.icon)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(st.color)
                        .lineLimit(1)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    SafeTimer(to: target, width: 64)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(liveAccent)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(s.subject)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(1)
                        Text([place.roomText, place.address].filter { !$0.isEmpty }.joined(separator: " · "))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            } compactLeading: {
                Image(systemName: st.icon)
                    .foregroundStyle(st.color)
            } compactTrailing: {
                SafeTimer(to: target, width: 42)
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(liveAccent)
            } minimal: {
                Image(systemName: st.icon)
                    .foregroundStyle(st.color)
            }
            .widgetURL(URL(string: "safu://schedule"))
            .keylineTint(st.color)
        }
    }
}

/// Экран блокировки: компактно, но всё видно —
/// тип · номер · время | таймер
/// предмет
/// аудитория · адрес | преподаватель
struct LiveLockScreenView: View {
    let state: PairActivityAttributes.ContentState

    var body: some View {
        let st = KindStyle.of(state.kind)
        let place = LivePlace(state)

        VStack(alignment: .leading, spacing: 4) {
            // 1. тип пары, номер, время + таймер
            HStack(spacing: 6) {
                HStack(spacing: 3) {
                    Image(systemName: st.icon)
                    Text(st.label.uppercased())
                }
                .font(.system(size: 10, weight: .heavy))
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(st.color, in: Capsule())
                .fixedSize()

                Text((state.pair > 0 ? "\(state.pair) пара · " : "") + "\(liveHM(state.start))–\(liveHM(state.end))")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(liveDim)
                    .lineLimit(1)

                Spacer(minLength: 4)

                Text(state.isNow ? "ещё" : "через")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(liveDim)
                SafeTimer(to: state.isNow ? state.end : state.start, width: 56)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(liveAccent)
            }

            // 2. предмет
            Text(state.subject)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.8)

            // 3. аудитория, адрес, преподаватель
            HStack(spacing: 6) {
                if !place.roomText.isEmpty {
                    Label(place.roomText, systemImage: "mappin.circle.fill")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                        .labelStyle(.titleAndIcon)
                        .fixedSize()
                }
                if !place.address.isEmpty {
                    Text(place.address)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(liveDim)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                Spacer(minLength: 4)
                if !state.teacher.isEmpty {
                    Label(state.teacher, systemImage: "person.fill")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(liveDim)
                        .lineLimit(1)
                        .layoutPriority(1)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
    }
}
