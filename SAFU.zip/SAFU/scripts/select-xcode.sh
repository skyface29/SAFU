#!/bin/bash
# Выбираем самый новый Xcode 26 на сервере сборки, чтобы включился Liquid Glass.
# Если его нет, сборка пойдёт на Xcode по умолчанию (будет обычное стекло).
X=$(ls -d /Applications/Xcode_26*.app 2>/dev/null | grep -v -i beta | sort -V | tail -n 1)
if [ -z "$X" ]; then
  X=$(ls -d /Applications/Xcode_26*.app 2>/dev/null | sort -V | tail -n 1)
fi
if [ -n "$X" ]; then
  echo "Using $X"
  sudo xcode-select -s "$X/Contents/Developer" || true
fi
xcodebuild -version || true
exit 0
