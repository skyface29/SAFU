import Foundation

// MARK: - Пара из РУЗ

struct RuzEvent: Codable, Hashable, Identifiable {
    var start: Date
    var end: Date
    var subject: String
    var kind: String
    var teacher: String
    var room: String
    var address: String
    var note: String

    var id: String { "\(Int(start.timeIntervalSince1970))-\(subject)-\(room)" }
}

struct RuzResult {
    let events: [RuzEvent]
    let method: String
    let notice: String?
}

// MARK: - Помощники для регулярок

extension String {
    func rx(_ pattern: String, _ options: NSRegularExpression.Options = []) -> [NSTextCheckingResult] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        return re.matches(in: self, range: NSRange(location: 0, length: (self as NSString).length))
    }

    func sub(_ range: NSRange) -> String {
        guard range.location != NSNotFound else { return "" }
        return (self as NSString).substring(with: range)
    }

    var squeezed: String {
        replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Разбор текста пары: «Лекции Предмет ( Иванов И.И.) Подгруппа … ауд. 42, адрес»

enum EventText {
    static let kinds = [
        "Лабораторная работа", "Лабораторные работы", "Лабораторные занятия", "Лабораторное занятие",
        "Практическое занятие", "Практические занятия", "Дифференцированный зачет", "Зачет с оценкой",
        "Курсовое проектирование", "Контрольная работа", "Консультация", "Экзамен", "Семинар",
        "Лекции", "Лекция", "Зачет", "Зачёт"
    ]

    struct Parsed {
        var kind = "Занятие"
        var subject = ""
        var teacher = ""
        var room = ""
        var address = ""
        var note = ""
    }

    static func shortKind(_ k: String) -> String {
        let l = k.lowercased()
        if l.hasPrefix("лекц") { return "Лекция" }
        if l.hasPrefix("практ") { return "Практика" }
        if l.hasPrefix("лаб") { return "Лабораторная" }
        return k
    }

    static func parseLocation(_ raw: String) -> (room: String, address: String) {
        let t = raw.squeezed
        guard let r = t.range(of: "ауд.") else { return ("", t) }
        let rest = t[r.upperBound...].trimmingCharacters(in: .whitespaces)
        if let comma = rest.firstIndex(of: ",") {
            let room = String(rest[..<comma]).trimmingCharacters(in: .whitespaces)
            let addr = String(rest[rest.index(after: comma)...]).trimmingCharacters(in: .whitespaces)
            return (room, addr)
        }
        return (String(rest), "")
    }

    static func parse(_ raw: String) -> Parsed {
        var p = Parsed()
        var t = raw.squeezed

        for k in kinds where t.lowercased().hasPrefix(k.lowercased()) {
            p.kind = shortKind(k)
            t = String(t.dropFirst(k.count)).trimmingCharacters(in: .whitespaces)
            break
        }

        if let r = t.range(of: "ауд.") {
            let loc = parseLocation(String(t[r.lowerBound...]))
            p.room = loc.room
            p.address = loc.address
            t = String(t[..<r.lowerBound]).trimmingCharacters(in: .whitespaces)
        }

        // Преподаватель — последние скобки с инициалами: «( Яковленкова А.О.)»
        let parens = t.rx("\\(([^()]*)\\)")
        if let m = parens.last(where: { t.sub($0.range(at: 1)).rx("[А-ЯЁ]\\.").count > 0 }) {
            p.teacher = t.sub(m.range(at: 1)).squeezed
            let ns = t as NSString
            p.subject = ns.substring(to: m.range.location).squeezed
            p.note = ns.substring(from: m.range.location + m.range.length).squeezed
        } else {
            p.subject = t
        }
        if p.subject.isEmpty { p.subject = p.kind }
        return p
    }
}

// MARK: - Клиент РУЗ

enum RuzClient {
    static let base = "https://ruz.narfu.ru/"
    static let moscow = TimeZone(identifier: "Europe/Moscow") ?? .current

    static let institutions: [(Int, String)] = [
        (3, "ВШИТАС"), (15, "Высшая инженерная школа"), (1, "ВШ естественных наук"),
        (4, "ВШ соц.-гум. наук"), (28, "ВШ экономики и права"), (12, "ВШ энергетики"),
        (13, "ВШ педагогики и физкультуры"), (36, "ВШ рыболовства")
    ]

    static func timetableURL(groupID: String) -> URL? {
        URL(string: "\(base)?timetable&group=\(groupID)")
    }

    static func groupID(in url: URL) -> String? {
        URLComponents(url: url, resolvingAgainstBaseURL: false)?
            .queryItems?.first(where: { $0.name == "group" })?.value
            .flatMap { $0.allSatisfy(\.isNumber) && !$0.isEmpty ? $0 : nil }
    }

    static func groupNumber(fromTitle title: String) -> String? {
        guard let m = title.rx("\\b(\\d{6})\\b").first else { return nil }
        return title.sub(m.range(at: 1))
    }

    /// В виджете ставим меньше: системе нельзя долго ждать
    static var requestTimeout: TimeInterval = 25
    /// iCal — лишние запросы; в виджете выключаем
    static var useICS = true

    static func fetch(_ url: URL) async throws -> String {
        var req = URLRequest(url: url)
        req.timeoutInterval = requestTimeout
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
                     forHTTPHeaderField: "User-Agent")
        let (data, _) = try await URLSession.shared.data(for: req)
        return String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .windowsCP1251)
            ?? ""
    }

    // MARK: поиск группы

    static func findGroupID(number: String, institution: Int, searchAll: Bool = true) async throws -> String? {
        var order = [institution]
        if searchAll { order += institutions.map(\.0).filter { $0 != institution } }
        for inst in order {
            guard let url = URL(string: "\(base)?groups&institution=\(inst)") else { continue }
            let html = try await fetch(url)
            if let id = extractGroupID(html, number: number) { return id }
        }
        return nil
    }

    static func extractGroupID(_ html: String, number: String) -> String? {
        let ms = html.rx("group=(\\d+)")
        let ns = html as NSString
        for (i, m) in ms.enumerated() {
            let from = m.range.location + m.range.length
            let to = i + 1 < ms.count ? ms[i + 1].range.location : min(ns.length, from + 600)
            guard to > from else { continue }
            let segment = stripTags(ns.substring(with: NSRange(location: from, length: to - from)))
            if segment.contains(number) { return html.sub(m.range(at: 1)) }
        }
        return nil
    }

    // MARK: загрузка расписания

    static func load(groupID: String) async throws -> RuzResult {
        guard let url = timetableURL(groupID: groupID) else {
            return RuzResult(events: [], method: "", notice: "Неверная группа")
        }
        let html = try await fetch(url)

        // 1. iCal с сайта — самый надёжный вариант
        for link in (useICS ? Array(icsLinks(in: html).prefix(2)) : []) {
            if let text = try? await fetch(link), text.contains("BEGIN:VCALENDAR") {
                let events = ICS.parse(text)
                if !events.isEmpty { return RuzResult(events: events, method: "iCal", notice: nil) }
            }
        }

        // 2. Разбор самой страницы
        let events = parseHTML(html)
        var notice: String?
        if events.isEmpty {
            if html.lowercased().contains("modeus") {
                notice = "В РУЗ пока нет пар для этой группы. Потяни вниз, чтобы проверить ещё раз."
            } else if html.contains("отсутствуют") {
                notice = "В РУЗ пока нет пар на эти недели."
            }
        }
        return RuzResult(events: events, method: "страница РУЗ", notice: notice)
    }

    static func icsLinks(in html: String) -> [URL] {
        var result: [URL] = []
        var seen = Set<String>()
        for m in html.rx("href\\s*=\\s*[\"']([^\"']+)[\"']", .caseInsensitive) {
            var href = decodeEntities(html.sub(m.range(at: 1)))
            let l = href.lowercased()
            guard l.contains("ical") || l.contains(".ics") || l.contains("calendar") || l.hasPrefix("webcal") else { continue }
            if l.hasPrefix("webcal://") { href = "https://" + href.dropFirst("webcal://".count) }
            let absolute: String
            if href.lowercased().hasPrefix("http") {
                absolute = href
            } else if href.hasPrefix("//") {
                absolute = "https:" + href
            } else if href.hasPrefix("/") {
                absolute = "https://ruz.narfu.ru" + href
            } else {
                absolute = base + href
            }
            if seen.insert(absolute).inserted, let u = URL(string: absolute) { result.append(u) }
        }
        return result
    }

    // MARK: HTML → текст

    static func decodeEntities(_ s: String) -> String {
        var r = s
        let map = ["&nbsp;": " ", "&quot;": "\"", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&#39;": "'",
                   "&laquo;": "«", "&raquo;": "»", "&ndash;": "–", "&mdash;": "—", "&apos;": "'"]
        for (k, v) in map { r = r.replacingOccurrences(of: k, with: v) }
        let numeric = r.rx("&#(\\d+);")
        for m in numeric.reversed() {
            if let code = UInt32(r.sub(m.range(at: 1))), let scalar = UnicodeScalar(code) {
                r = (r as NSString).replacingCharacters(in: m.range, with: String(Character(scalar)))
            }
        }
        return r
    }

    static func stripTags(_ s: String) -> String {
        decodeEntities(s.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)).squeezed
    }

    static func htmlToText(_ html: String) -> String {
        var s = html
        s = s.replacingOccurrences(of: "<script[\\s\\S]*?</script>", with: " ", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<style[\\s\\S]*?</style>", with: " ", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<br\\s*/?>", with: "\n", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "</(div|p|li|tr|h[1-6]|ul|table|section)>", with: "\n", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        s = decodeEntities(s)
        s = s.replacingOccurrences(of: "[ \\t\\u00A0]+", with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: "\\s*\\n\\s*", with: "\n", options: .regularExpression)
        return s
    }

    private static func makeDate(_ y: Int, _ mo: Int, _ d: Int, _ h: Int, _ mi: Int) -> Date? {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = moscow
        return cal.date(from: DateComponents(year: y, month: mo, day: d, hour: h, minute: mi))
    }

    private static func stripTrailingPairNumbers(_ text: String) -> String {
        var t = text.trimmingCharacters(in: .whitespaces)
        while let r = t.range(of: "\\s+[1-8]$", options: .regularExpression) {
            let before = t[..<r.lowerBound]
            if before.hasSuffix(".") || before.hasSuffix(",") || before.lowercased().hasSuffix("корп") { break }
            t = String(before).trimmingCharacters(in: .whitespaces)
        }
        return t
    }

    static func parseHTML(_ html: String) -> [RuzEvent] {
        // Берём только часть страницы с расписанием — меньше памяти (у виджета её очень мало)
        var src = html
        if let r = html.range(of: "понедельник|вторник|среда|четверг|пятница|суббота",
                              options: [.regularExpression, .caseInsensitive]) {
            let start = html.index(r.lowerBound, offsetBy: -1500, limitedBy: html.startIndex) ?? html.startIndex
            src = String(html[start...])
        }
        let text = htmlToText(src)
        let ns = text as NSString
        let days = text.rx("(понедельник|вторник|среда|четверг|пятница|суббота|воскресенье),?\\s*(\\d{2})\\.(\\d{2})\\.(\\d{4})",
                           .caseInsensitive)
        var result: [RuzEvent] = []
        for (i, d) in days.enumerated() {
            let from = d.range.location + d.range.length
            let to = i + 1 < days.count ? days[i + 1].range.location : ns.length
            guard to > from else { continue }
            let block = ns.substring(with: NSRange(location: from, length: to - from))
            let day = Int(text.sub(d.range(at: 2))) ?? 1
            let month = Int(text.sub(d.range(at: 3))) ?? 1
            let year = Int(text.sub(d.range(at: 4))) ?? 2026

            let bns = block as NSString
            let evs = block.rx("(?:^|\\s)([1-8])\\s+(\\d{1,2}):(\\d{2})\\s*[–—-]\\s*(\\d{1,2}):(\\d{2})")
            for (j, m) in evs.enumerated() {
                let tFrom = m.range.location + m.range.length
                let tTo = j + 1 < evs.count ? evs[j + 1].range.location : bns.length
                guard tTo > tFrom else { continue }
                let body = stripTrailingPairNumbers(
                    bns.substring(with: NSRange(location: tFrom, length: tTo - tFrom))
                        .replacingOccurrences(of: "\n", with: " ").squeezed
                )
                guard body.count > 2 else { continue }
                guard let start = makeDate(year, month, day,
                                           Int(block.sub(m.range(at: 2))) ?? 8, Int(block.sub(m.range(at: 3))) ?? 0),
                      let end = makeDate(year, month, day,
                                         Int(block.sub(m.range(at: 4))) ?? 9, Int(block.sub(m.range(at: 5))) ?? 35)
                else { continue }
                let p = EventText.parse(body)
                result.append(RuzEvent(start: start, end: end, subject: p.subject, kind: p.kind,
                                       teacher: p.teacher, room: p.room, address: p.address, note: p.note))
            }
        }
        return result
    }
}

// MARK: - iCalendar

enum ICS {
    static func parse(_ raw: String) -> [RuzEvent] {
        let text = raw
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\n ", with: "")
            .replacingOccurrences(of: "\n\t", with: "")
        var events: [RuzEvent] = []
        var cur: [String: String]?
        for line in text.components(separatedBy: "\n") {
            if line == "BEGIN:VEVENT" {
                cur = [:]
            } else if line == "END:VEVENT" {
                if let c = cur, let e = makeEvent(c) { events.append(e) }
                cur = nil
            } else if cur != nil, let idx = line.firstIndex(of: ":") {
                let keyPart = String(line[..<idx])
                let value = String(line[line.index(after: idx)...])
                let name = keyPart.split(separator: ";").first.map(String.init) ?? keyPart
                cur?[name] = value
                cur?[name + "#params"] = keyPart
            }
        }
        return events
    }

    private static func unescape(_ s: String) -> String {
        s.replacingOccurrences(of: "\\n", with: " ")
            .replacingOccurrences(of: "\\N", with: " ")
            .replacingOccurrences(of: "\\,", with: ",")
            .replacingOccurrences(of: "\\;", with: ";")
            .replacingOccurrences(of: "\\\\", with: "\\")
            .squeezed
    }

    private static func date(_ value: String?, _ params: String?) -> Date? {
        guard let value = value else { return nil }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        if value.hasSuffix("Z") {
            f.timeZone = TimeZone(identifier: "UTC")
            f.dateFormat = "yyyyMMdd'T'HHmmss'Z'"
        } else {
            var tz = RuzClient.moscow
            if let params = params, let r = params.range(of: "TZID=") {
                let id = params[r.upperBound...].split(separator: ";").first.map(String.init) ?? ""
                if let z = TimeZone(identifier: id.replacingOccurrences(of: "\"", with: "")) { tz = z }
            }
            f.timeZone = tz
            f.dateFormat = value.count == 8 ? "yyyyMMdd" : "yyyyMMdd'T'HHmmss"
        }
        return f.date(from: value)
    }

    private static func makeEvent(_ c: [String: String]) -> RuzEvent? {
        guard let start = date(c["DTSTART"], c["DTSTART#params"]) else { return nil }
        let end = date(c["DTEND"], c["DTEND#params"]) ?? start.addingTimeInterval(95 * 60)
        let summary = unescape(c["SUMMARY"] ?? "")
        let location = unescape(c["LOCATION"] ?? "")
        let description = unescape(c["DESCRIPTION"] ?? "")

        var p = EventText.parse(summary)
        if !location.isEmpty {
            let loc = EventText.parseLocation(location)
            if p.room.isEmpty { p.room = loc.room }
            if p.address.isEmpty { p.address = loc.address }
        }
        if p.teacher.isEmpty, let m = description.rx("[А-ЯЁ][а-яё-]+\\s+[А-ЯЁ]\\.\\s?[А-ЯЁ]?\\.?").first {
            p.teacher = description.sub(m.range)
        }
        if p.note.isEmpty { p.note = description }
        return RuzEvent(start: start, end: end, subject: p.subject, kind: p.kind,
                        teacher: p.teacher, room: p.room, address: p.address, note: p.note)
    }
}
