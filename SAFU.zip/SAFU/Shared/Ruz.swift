import Foundation

// MARK: - Пара из РУЗ

struct RuzEvent: Codable, Hashable, Identifiable {
    var start: Date
    var end: Date
    var subject: String
    var kind: String
    var teacher: String
    var room: String
    var address: String
    var note: String

    var id: String { "\(Int(start.timeIntervalSince1970))-\(subject)-\(room)" }
}

struct RuzResult {
    let events: [RuzEvent]
    let method: String
    let notice: String?
}

// MARK: - Помощники для регулярок

extension String {
    func rx(_ pattern: String, _ options: NSRegularExpression.Options = []) -> [NSTextCheckingResult] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: options) else { return [] }
        return re.matches(in: self, range: NSRange(location: 0, length: (self as NSString).length))
    }

    func sub(_ range: NSRange) -> String {
        guard range.location != NSNotFound else { return "" }
        return (self as NSString).substring(with: range)
    }

    var squeezed: String {
        replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - Разбор текста пары: «Лекции Предмет ( Иванов И.И.) Подгруппа … ауд. 42, адрес»

enum EventText {
    static let kinds = [
        "Лабораторная работа", "Лабораторные работы", "Лабораторные занятия", "Лабораторное занятие",
        "Практическое занятие", "Практические занятия", "Дифференцированный зачет", "Зачет с оценкой",
        "Курсовое проектирование", "Контрольная работа", "Консультация", "Экзамен", "Семинар",
        "Лекции", "Лекция", "Зачет", "Зачёт"
    ]

    struct Parsed {
        var kind = "Занятие"
        var subject = ""
        var teacher = ""
        var room = ""
        var address = ""
        var note = ""
    }

    static func shortKind(_ k: String) -> String {
        let l = k.lowercased()
        if l.hasPrefix("лекц") { return "Лекция" }
        if l.hasPrefix("практ") { return "Практика" }
        if l.hasPrefix("лаб") { return "Лабораторная" }
        return k
    }

    static func parseLocation(_ raw: String) -> (room: String, address: String) {
        let t = raw.squeezed
        guard let r = t.range(of: "ауд.") else { return ("", t) }
        let rest = t[r.upperBound...].trimmingCharacters(in: .whitespaces)
        if let comma = rest.firstIndex(of: ",") {
            let room = String(rest[..<comma]).trimmingCharacters(in: .whitespaces)
            let addr = String(rest[rest.index(after: comma)...]).trimmingCharacters(in: .whitespaces)
            return (room, addr)
        }
        return (String(rest), "")
    }

    static func parse(_ raw: String) -> Parsed {
        var p = Parsed()
        var t = raw.squeezed

        for k in kinds where t.lowercased().hasPrefix(k.lowercased()) {
            p.kind = shortKind(k)
            t = String(t.dropFirst(k.count)).trimmingCharacters(in: .whitespaces)
            break
        }

        if let r = t.range(of: "ауд.") {
            let loc = parseLocation(String(t[r.lowerBound...]))
            p.room = loc.room
            p.address = loc.address
            t = String(t[..<r.lowerBound]).trimmingCharacters(in: .whitespaces)
        }

        // Преподаватель — последние скобки с инициалами: «( Яковленкова А.О.)»
        let parens = t.rx("\\(([^()]*)\\)")
        if let m = parens.last(where: { t.sub($0.range(at: 1)).rx("[А-ЯЁ]\\.").count > 0 }) {
            p.teacher = t.sub(m.range(at: 1)).squeezed
            let ns = t as NSString
            p.subject = ns.substring(to: m.range.location).squeezed
            p.note = ns.substring(from: m.range.location + m.range.length).squeezed
        } else {
            p.subject = t
        }
        // «История России Ссылка на курс Курс лекций на платформе Sakai…» → предмет + заметка
        let cleaned = cleanSubject(p.subject)
        p.subject = cleaned.subject
        if !cleaned.extra.isEmpty { p.note = (cleaned.extra + " " + p.note).squeezed }
        return p
    }

    /// Отрезаем от названия предмета служебные хвосты РУЗ (ссылки на курсы, подгруппы, потоки)
    static let subjectMarkers = ["ссылка на курс", "курс лекций", "http", "подгруппа", "поток ",
                                 "онлайн-курс", "ссылка", "платформе sakai"]

    static func cleanSubject(_ raw: String) -> (subject: String, extra: String) {
        let t = raw.squeezed
        let low = t.lowercased()
        var cut: String.Index?
        for m in subjectMarkers {
            if let r = low.range(of: m) {
                let idx = t.index(t.startIndex, offsetBy: low.distance(from: low.startIndex, to: r.lowerBound))
                if cut == nil || idx < cut! { cut = idx }
            }
        }
        guard let c = cut else { return (t, "") }
        let subject = String(t[..<c]).trimmingCharacters(in: CharacterSet(charactersIn: " ,;:-–—"))
        return (subject, String(t[c...]).squeezed)
    }
}

// MARK: - Клиент РУЗ

enum RuzClient {
    static let base = "https://ruz.narfu.ru/"
    static let moscow = TimeZone(identifier: "Europe/Moscow") ?? .current

    static let institutions: [(Int, String)] = [
        (3, "ВШИТАС"), (15, "Высшая инженерная школа"), (1, "ВШ естественных наук"),
        (4, "ВШ соц.-гум. наук"), (28, "ВШ экономики и права"), (12, "ВШ энергетики"),
        (13, "ВШ педагогики и физкультуры"), (36, "ВШ рыболовства")
    ]

    static func timetableURL(groupID: String) -> URL? {
        URL(string: "\(base)?timetable&group=\(groupID)")
    }

    static func groupID(in url: URL) -> String? {
        URLComponents(url: url, resolvingAgainstBaseURL: false)?
            .queryItems?.first(where: { $0.name == "group" })?.value
            .flatMap { $0.allSatisfy(\.isNumber) && !$0.isEmpty ? $0 : nil }
    }

    static func groupNumber(fromTitle title: String) -> String? {
        guard let m = title.rx("\\b(\\d{6})\\b").first else { return nil }
        return title.sub(m.range(at: 1))
    }

    /// В виджете ставим меньше: системе нельзя долго ждать
    static var requestTimeout: TimeInterval = 25
    /// iCal — лишние запросы; в виджете выключаем
    static var useICS = true

    static func fetch(_ url: URL, session: URLSession = .shared) async throws -> String {
        var req = URLRequest(url: url)
        req.timeoutInterval = requestTimeout
        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
                     forHTTPHeaderField: "User-Agent")
        let (data, _) = try await session.data(for: req)
        return String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .windowsCP1251)
            ?? ""
    }

    // MARK: поиск группы

    static func findGroupID(number: String, institution: Int, searchAll: Bool = true) async throws -> String? {
        var order = [institution]
        if searchAll { order += institutions.map(\.0).filter { $0 != institution } }
        for inst in order {
            guard let url = URL(string: "\(base)?groups&institution=\(inst)") else { continue }
            let html = try await fetch(url)
            if let id = extractGroupID(html, number: number) { return id }
        }
        return nil
    }

    static func extractGroupID(_ html: String, number: String) -> String? {
        let ms = html.rx("group=(\\d+)")
        let ns = html as NSString
        for (i, m) in ms.enumerated() {
            let from = m.range.location + m.range.length
            let to = i + 1 < ms.count ? ms[i + 1].range.location : min(ns.length, from + 600)
            guard to > from else { continue }
            let segment = stripTags(ns.substring(with: NSRange(location: from, length: to - from)))
            if segment.contains(number) { return html.sub(m.range(at: 1)) }
        }
        return nil
    }

    // MARK: загрузка расписания

    static func load(groupID: String) async throws -> RuzResult {
        guard let url = timetableURL(groupID: groupID) else {
            return RuzResult(events: [], method: "", notice: "Неверная группа")
        }
        let html = try await fetch(url)
        rememberLecturers(from: html)

        // 1. Страница РУЗ — в ней есть тип пары (лекция/практика/лаба) и преподаватель
        let page = parseHTML(html)

        // 2. iCal — часто содержит больше недель (в том числе прошлые), но без типа и преподавателя.
        //    Берём из него только те дни, которых нет на странице.
        var extra: [RuzEvent] = []
        if useICS {
            for link in Array(icsLinks(in: html).prefix(2)) {
                if let text = try? await fetch(link), text.contains("BEGIN:VCALENDAR") {
                    let ics = ICS.parse(text)
                    if !ics.isEmpty && !sameGroup(page: page, ics: ics) { break }   // календарь чужой группы — не берём
                    if !ics.isEmpty {
                        let cal = Calendar.current
                        let pageDays = Set(page.map { cal.startOfDay(for: $0.start) })
                        if let lo = page.map(\.start).min(), let hi = page.map(\.start).max() {
                            let loDay = cal.startOfDay(for: lo)
                            let hiDay = cal.startOfDay(for: hi)
                            extra = ics.filter {
                                let d = cal.startOfDay(for: $0.start)
                                return (d < loDay || d > hiDay) && !pageDays.contains(d)
                            }
                        } else {
                            extra = ics
                        }
                        break
                    }
                }
            }
        }

        let events = page + extra
        var notice: String?
        if events.isEmpty {
            if html.lowercased().contains("modeus") {
                notice = "В РУЗ пока нет пар для этой группы. Потяни вниз, чтобы проверить ещё раз."
            } else if html.contains("отсутствуют") {
                notice = "В РУЗ пока нет пар на эти недели."
            }
        }
        let method = page.isEmpty ? (extra.isEmpty ? "страница РУЗ" : "iCal") : "страница РУЗ"
        return RuzResult(events: events, method: method, notice: notice)
    }

    /// iCal должен совпадать со страницей группы в общие дни: иначе это чужой календарь
    /// (РУЗ иногда отдаёт ссылку на «последнюю открытую группу» из своей сессии)
    static func sameGroup(page: [RuzEvent], ics: [RuzEvent]) -> Bool {
        guard !page.isEmpty else { return true }
        let cal = Calendar.current
        let pageDays = Set(page.map { cal.startOfDay(for: $0.start) })
        let pageKeys = Set(page.map { "\(Int($0.start.timeIntervalSince1970))|\($0.subject.lowercased().prefix(12))" })
        let shared = ics.filter { pageDays.contains(cal.startOfDay(for: $0.start)) }
        guard shared.count >= 2 else { return true }
        let match = shared.filter { pageKeys.contains("\(Int($0.start.timeIntervalSince1970))|\($0.subject.lowercased().prefix(12))") }.count
        return Double(match) / Double(shared.count) >= 0.5
    }

    // MARK: прошлые недели

    private static func format(_ d: Date, _ fmt: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = moscow
        f.dateFormat = fmt
        return f.string(from: d)
    }

    /// Пытаемся загрузить конкретную неделю. Сначала узнаём формат ссылок на недели со страницы РУЗ,
    /// потом пробуем типовые варианты. Принимаем только пары, которые реально попали в нужную неделю.
    static func loadWeek(groupID: String, monday: Date) async -> [RuzEvent] {
        guard let url = timetableURL(groupID: groupID), let html = try? await fetch(url) else { return [] }
        var candidates: [String] = []
        let linkPattern = "href\\s*=\\s*[\"']([^\"']*group=" + groupID + "[^\"']*)[\"']"
        for m in html.rx(linkPattern, .caseInsensitive) {
            let href = decodeEntities(html.sub(m.range(at: 1)))
            if let dm = href.rx("([A-Za-z_]+)=(\\d{2}\\.\\d{2}\\.\\d{4}|\\d{4}-\\d{2}-\\d{2})").first {
                let name = href.sub(dm.range(at: 1))
                let value = href.sub(dm.range(at: 2))
                let fmt = value.contains("-") ? "yyyy-MM-dd" : "dd.MM.yyyy"
                candidates.append("\(base)?timetable&group=\(groupID)&\(name)=\(format(monday, fmt))")
                break
            }
        }
        for name in ["date", "week", "start"] {
            for fmt in ["dd.MM.yyyy", "yyyy-MM-dd"] {
                candidates.append("\(base)?timetable&group=\(groupID)&\(name)=\(format(monday, fmt))")
            }
        }
        let weekEnd = monday.addingTimeInterval(7 * 86_400)
        var seen = Set<String>()
        for c in candidates where seen.insert(c).inserted {
            guard let u = URL(string: c), let page = try? await fetch(u) else { continue }
            let events = parseHTML(page).filter { $0.start >= monday && $0.start < weekEnd }
            if !events.isEmpty { return events }
        }
        return []
    }

    static func icsLinks(in html: String) -> [URL] {
        var result: [URL] = []
        var seen = Set<String>()
        for m in html.rx("href\\s*=\\s*[\"']([^\"']+)[\"']", .caseInsensitive) {
            var href = decodeEntities(html.sub(m.range(at: 1)))
            let l = href.lowercased()
            guard l.contains("ical") || l.contains(".ics") || l.contains("calendar") || l.hasPrefix("webcal") else { continue }
            if l.hasPrefix("webcal://") { href = "https://" + href.dropFirst("webcal://".count) }
            let absolute: String
            if href.lowercased().hasPrefix("http") {
                absolute = href
            } else if href.hasPrefix("//") {
                absolute = "https:" + href
            } else if href.hasPrefix("/") {
                absolute = "https://ruz.narfu.ru" + href
            } else {
                absolute = base + href
            }
            if seen.insert(absolute).inserted, let u = URL(string: absolute) { result.append(u) }
        }
        return result
    }

    // MARK: HTML → текст

    static func decodeEntities(_ s: String) -> String {
        var r = s
        let map = ["&nbsp;": " ", "&quot;": "\"", "&amp;": "&", "&lt;": "<", "&gt;": ">", "&#39;": "'",
                   "&laquo;": "«", "&raquo;": "»", "&ndash;": "–", "&mdash;": "—", "&apos;": "'"]
        for (k, v) in map { r = r.replacingOccurrences(of: k, with: v) }
        let numeric = r.rx("&#(\\d+);")
        for m in numeric.reversed() {
            if let code = UInt32(r.sub(m.range(at: 1))), let scalar = UnicodeScalar(code) {
                r = (r as NSString).replacingCharacters(in: m.range, with: String(Character(scalar)))
            }
        }
        return r
    }

    static func stripTags(_ s: String) -> String {
        decodeEntities(s.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)).squeezed
    }

    static func htmlToText(_ html: String) -> String {
        var s = html
        s = s.replacingOccurrences(of: "<script[\\s\\S]*?</script>", with: " ", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<style[\\s\\S]*?</style>", with: " ", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<br\\s*/?>", with: "\n", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "</(div|p|li|tr|h[1-6]|ul|table|section)>", with: "\n", options: [.regularExpression, .caseInsensitive])
        s = s.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        s = decodeEntities(s)
        s = s.replacingOccurrences(of: "[ \\t\\u00A0]+", with: " ", options: .regularExpression)
        s = s.replacingOccurrences(of: "\\s*\\n\\s*", with: "\n", options: .regularExpression)
        return s
    }

    private static func makeDate(_ y: Int, _ mo: Int, _ d: Int, _ h: Int, _ mi: Int) -> Date? {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = moscow
        return cal.date(from: DateComponents(year: y, month: mo, day: d, hour: h, minute: mi))
    }

    private static func stripTrailingPairNumbers(_ text: String) -> String {
        var t = text.trimmingCharacters(in: .whitespaces)
        while let r = t.range(of: "\\s+[1-8]$", options: .regularExpression) {
            let before = t[..<r.lowerBound]
            if before.hasSuffix(".") || before.hasSuffix(",") || before.lowercased().hasSuffix("корп") { break }
            t = String(before).trimmingCharacters(in: .whitespaces)
        }
        return t
    }

    static func parseHTML(_ html: String) -> [RuzEvent] {
        // Берём только часть страницы с расписанием — меньше памяти (у виджета её очень мало)
        var src = html
        if let r = html.range(of: "понедельник|вторник|среда|четверг|пятница|суббота",
                              options: [.regularExpression, .caseInsensitive]) {
            let start = html.index(r.lowerBound, offsetBy: -1500, limitedBy: html.startIndex) ?? html.startIndex
            src = String(html[start...])
        }
        let text = htmlToText(src)
        let ns = text as NSString
        let days = text.rx("(понедельник|вторник|среда|четверг|пятница|суббота|воскресенье),?\\s*(\\d{2})\\.(\\d{2})\\.(\\d{4})",
                           .caseInsensitive)
        var result: [RuzEvent] = []
        for (i, d) in days.enumerated() {
            let from = d.range.location + d.range.length
            let to = i + 1 < days.count ? days[i + 1].range.location : ns.length
            guard to > from else { continue }
            let block = ns.substring(with: NSRange(location: from, length: to - from))
            let day = Int(text.sub(d.range(at: 2))) ?? 1
            let month = Int(text.sub(d.range(at: 3))) ?? 1
            let year = Int(text.sub(d.range(at: 4))) ?? 2026

            let bns = block as NSString
            let evs = block.rx("(?:^|\\s)([1-8])\\s+(\\d{1,2}):(\\d{2})\\s*[–—-]\\s*(\\d{1,2}):(\\d{2})")
            for (j, m) in evs.enumerated() {
                let tFrom = m.range.location + m.range.length
                let tTo = j + 1 < evs.count ? evs[j + 1].range.location : bns.length
                guard tTo > tFrom else { continue }
                let body = stripTrailingPairNumbers(
                    bns.substring(with: NSRange(location: tFrom, length: tTo - tFrom))
                        .replacingOccurrences(of: "\n", with: " ").squeezed
                )
                guard body.count > 2 else { continue }
                guard let start = makeDate(year, month, day,
                                           Int(block.sub(m.range(at: 2))) ?? 8, Int(block.sub(m.range(at: 3))) ?? 0),
                      let end = makeDate(year, month, day,
                                         Int(block.sub(m.range(at: 4))) ?? 9, Int(block.sub(m.range(at: 5))) ?? 35)
                else { continue }
                let p = EventText.parse(body)
                result.append(RuzEvent(start: start, end: end, subject: p.subject, kind: p.kind,
                                       teacher: p.teacher, room: p.room, address: p.address, note: p.note))
            }
        }
        return result
    }
}

// MARK: - iCalendar

enum ICS {
    static func parse(_ raw: String) -> [RuzEvent] {
        let text = raw
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\n ", with: "")
            .replacingOccurrences(of: "\n\t", with: "")
        var events: [RuzEvent] = []
        var cur: [String: String]?
        for line in text.components(separatedBy: "\n") {
            if line == "BEGIN:VEVENT" {
                cur = [:]
            } else if line == "END:VEVENT" {
                if let c = cur, let e = makeEvent(c) { events.append(e) }
                cur = nil
            } else if cur != nil, let idx = line.firstIndex(of: ":") {
                let keyPart = String(line[..<idx])
                let value = String(line[line.index(after: idx)...])
                let name = keyPart.split(separator: ";").first.map(String.init) ?? keyPart
                cur?[name] = value
                cur?[name + "#params"] = keyPart
            }
        }
        return events
    }

    private static func unescape(_ s: String) -> String {
        s.replacingOccurrences(of: "\\n", with: " ")
            .replacingOccurrences(of: "\\N", with: " ")
            .replacingOccurrences(of: "\\,", with: ",")
            .replacingOccurrences(of: "\\;", with: ";")
            .replacingOccurrences(of: "\\\\", with: "\\")
            .squeezed
    }

    private static func date(_ value: String?, _ params: String?) -> Date? {
        guard let value = value else { return nil }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        if value.hasSuffix("Z") {
            f.timeZone = TimeZone(identifier: "UTC")
            f.dateFormat = "yyyyMMdd'T'HHmmss'Z'"
        } else {
            var tz = RuzClient.moscow
            if let params = params, let r = params.range(of: "TZID=") {
                let id = params[r.upperBound...].split(separator: ";").first.map(String.init) ?? ""
                if let z = TimeZone(identifier: id.replacingOccurrences(of: "\"", with: "")) { tz = z }
            }
            f.timeZone = tz
            f.dateFormat = value.count == 8 ? "yyyyMMdd" : "yyyyMMdd'T'HHmmss"
        }
        return f.date(from: value)
    }

    private static func makeEvent(_ c: [String: String]) -> RuzEvent? {
        guard let start = date(c["DTSTART"], c["DTSTART#params"]) else { return nil }
        let end = date(c["DTEND"], c["DTEND#params"]) ?? start.addingTimeInterval(95 * 60)
        let summary = unescape(c["SUMMARY"] ?? "")
        let location = unescape(c["LOCATION"] ?? "")
        let description = unescape(c["DESCRIPTION"] ?? "")

        var p = EventText.parse(summary)
        if !location.isEmpty {
            let loc = EventText.parseLocation(location)
            if p.room.isEmpty { p.room = loc.room }
            if p.address.isEmpty { p.address = loc.address }
        }
        if p.teacher.isEmpty, let m = description.rx("[А-ЯЁ][а-яё-]+\\s+[А-ЯЁ]\\.\\s?[А-ЯЁ]?\\.?").first {
            p.teacher = description.sub(m.range)
        }
        if p.note.isEmpty { p.note = description }
        return RuzEvent(start: start, end: end, subject: p.subject, kind: p.kind,
                        teacher: p.teacher, room: p.room, address: p.address, note: p.note)
    }
}

// MARK: - Расписание преподавателя по всему вузу (?timetable&lecturer=ID)
// У РУЗ есть страница преподавателя со всеми его парами во всех группах и школах.
// Её номер берём из ссылок на ФИО на странице группы (запоминаем при каждой загрузке).

struct RuzLecturer: Codable, Hashable {
    let id: String
    let name: String
}

extension RuzClient {
    static let lecturersKey = "ruz.lecturers"

    static func lecturerURL(_ id: String) -> URL? {
        URL(string: "\(base)?timetable&lecturer=\(id)")
    }

    /// Ссылки на преподавателей на странице РУЗ: ФИО → номер
    static func lecturerLinks(in html: String) -> [RuzLecturer] {
        var out: [RuzLecturer] = []
        var seen = Set<String>()
        let pattern = "<a\\b[^>]*href\\s*=\\s*[\"']([^\"']*lecturer=(\\d+)[^\"']*)[\"'][^>]*>([\\s\\S]*?)</a>"
        for m in html.rx(pattern, .caseInsensitive) {
            let id = html.sub(m.range(at: 2))
            let name = stripTags(html.sub(m.range(at: 3)))
            guard name.count > 2, name.rx("[А-ЯЁ]").count > 0 else { continue }
            if seen.insert(id + "|" + name).inserted { out.append(RuzLecturer(id: id, name: name)) }
        }
        return out
    }

    /// Запомнить номера преподавателей со страницы (страница группы, недели, школы)
    static func rememberLecturers(from html: String) {
        let found = lecturerLinks(in: html)
        guard !found.isEmpty else { return }
        let d = UserDefaults.standard
        var map = d.dictionary(forKey: lecturersKey) as? [String: String] ?? [:]
        var changed = false
        for l in found where map[l.name] != l.id { map[l.name] = l.id; changed = true }
        if changed { d.set(map, forKey: lecturersKey) }
    }

    /// «Иванов И.И.», «Иванов Иван Иванович» → фамилия и первые буквы имени и отчества
    static func nameKey(_ s: String) -> (surname: String, initials: [Character]) {
        let parts = s.lowercased().replacingOccurrences(of: "ё", with: "е")
            .components(separatedBy: CharacterSet.letters.inverted)
            .filter { !$0.isEmpty }
        guard let surname = parts.first else { return ("", []) }
        return (surname, Array(parts.dropFirst().compactMap(\.first).prefix(2)))
    }

    static func sameLecturer(_ a: String, _ b: String) -> Bool {
        let x = nameKey(a), y = nameKey(b)
        guard !x.surname.isEmpty, x.surname == y.surname else { return false }
        let n = min(x.initials.count, y.initials.count)
        return Array(x.initials.prefix(n)) == Array(y.initials.prefix(n))
    }

    /// Номер преподавателя, если он уже встречался на страницах РУЗ
    static func knownLecturerID(for name: String) -> String? {
        let map = UserDefaults.standard.dictionary(forKey: lecturersKey) as? [String: String] ?? [:]
        if let id = map[name] { return id }
        let candidates = Set(map.filter { sameLecturer($0.key, name) }.map(\.value))
        return candidates.count == 1 ? candidates.first : nil
    }

    /// Ищем номер преподавателя на странице своей группы (и на следующей неделе — вдруг его пары там)
    static func findLecturerID(name: String, groupID: String) async -> String? {
        if let id = knownLecturerID(for: name) { return id }
        guard let url = timetableURL(groupID: groupID), let html = try? await fetch(url) else { return nil }
        rememberLecturers(from: html)
        if let id = knownLecturerID(for: name) { return id }
        // ссылки на другие недели этой группы
        for href in weekLinks(in: html, key: "group", id: groupID).prefix(3) {
            guard let page = try? await fetch(href.url) else { continue }
            rememberLecturers(from: page)
            if let id = knownLecturerID(for: name) { return id }
        }
        return nil
    }

    // MARK: недели

    private static func moscowCalendar() -> Calendar {
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = moscow
        cal.firstWeekday = 2
        return cal
    }

    /// Ссылки-вкладки недель («28.09.2026», «05.10.2026» …) для группы или преподавателя
    static func weekLinks(in html: String, key: String, id: String) -> [(date: Date, url: URL)] {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = moscow
        var out: [(Date, URL)] = []
        var seen = Set<String>()
        let pattern = "href\\s*=\\s*[\"']([^\"']*\(key)=\(id)\\b[^\"']*)[\"']"
        for m in html.rx(pattern, .caseInsensitive) {
            let href = decodeEntities(html.sub(m.range(at: 1)))
            guard let dm = href.rx("=(\\d{2}\\.\\d{2}\\.\\d{4}|\\d{4}-\\d{2}-\\d{2})").first else { continue }
            let value = href.sub(dm.range(at: 1))
            f.dateFormat = value.contains("-") ? "yyyy-MM-dd" : "dd.MM.yyyy"
            guard let date = f.date(from: value) else { continue }
            let absolute: String
            if href.lowercased().hasPrefix("http") { absolute = href }
            else if href.hasPrefix("/") { absolute = "https://ruz.narfu.ru" + href }
            else if href.hasPrefix("?") { absolute = base + href }
            else { absolute = base + href }
            guard seen.insert(absolute).inserted, let u = URL(string: absolute) else { continue }
            out.append((date, u))
        }
        return out.sorted { $0.0 < $1.0 }
    }

    /// Запасной путь, если на странице нет вкладок недель: пробуем типовые параметры даты
    private static func guessWeekURL(key: String, id: String, monday: Date) async -> (URL, [RuzEvent])? {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.timeZone = moscow
        let end = monday.addingTimeInterval(7 * 86_400)
        for name in ["date", "week", "start"] {
            for fmt in ["dd.MM.yyyy", "yyyy-MM-dd"] {
                f.dateFormat = fmt
                guard let u = URL(string: "\(base)?timetable&\(key)=\(id)&\(name)=\(f.string(from: monday))"),
                      let page = try? await fetch(u) else { continue }
                let ev = parseLecturerPage(page).filter { $0.start >= monday && $0.start < end }
                if !ev.isEmpty { return (u, ev) }
            }
        }
        return nil
    }

    // MARK: страница преподавателя

    /// В строке пары у преподавателя вместо ФИО — «Группа "151512"» или «Поток "151612, 151613"»
    static func lecturerEvent(_ e: RuzEvent) -> RuzEvent {
        var r = e
        var groups: [String] = []
        let marker = "(?<![А-Яа-яЁё])(?:Группы|Группа|Потоки|Поток)\\s*[«\"“„]([^»\"”“]+)[»\"”“]"
        func take(_ s: String) -> String {
            var t = s
            for m in t.rx(marker).reversed() {
                let inner = t.sub(m.range(at: 1))
                groups += inner.components(separatedBy: CharacterSet(charactersIn: ",;")).map(\.squeezed).filter { !$0.isEmpty }
                t = (t as NSString).replacingCharacters(in: m.range, with: " ")
            }
            return t.squeezed
        }
        r.subject = take(r.subject).trimmingCharacters(in: CharacterSet(charactersIn: " ,;:-–—"))
        r.note = take(r.note)
        if groups.isEmpty {
            // без кавычек: «Группа 151512»
            let plain = "(?<![А-Яа-яЁё])(?:Группы|Группа|Потоки|Поток)\\s+((?:\\d{4,}[ ,;]*)+)"
            for src in [r.subject, r.note] {
                for m in src.rx(plain) {
                    groups += src.sub(m.range(at: 1)).rx("\\d{4,}").map { src.sub($0.range) }
                }
            }
            if !groups.isEmpty {
                r.subject = r.subject.replacingOccurrences(of: plain, with: " ", options: .regularExpression).squeezed
                r.note = r.note.replacingOccurrences(of: plain, with: " ", options: .regularExpression).squeezed
            }
        }
        var uniq: [String] = []
        for g in groups where !uniq.contains(g) { uniq.append(g) }
        if !uniq.isEmpty {
            r.teacher = (uniq.count == 1 ? "Группа " : "Группы ") + uniq.joined(separator: ", ")
        }
        return r
    }

    static func parseLecturerPage(_ html: String) -> [RuzEvent] {
        parseHTML(html).map(lecturerEvent)
    }

    private static func lecturerCacheURL(_ id: String) -> URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("lecturer-\(id).json")
    }

    /// Сохранённое расписание преподавателя и когда оно загружено
    static func cachedLecturer(_ id: String) -> (events: [RuzEvent], at: Date)? {
        let url = lecturerCacheURL(id)
        guard let raw = try? Data(contentsOf: url),
              let ev = try? JSONDecoder().decode([RuzEvent].self, from: raw) else { return nil }
        let at = (try? url.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
        return (ev, at)
    }

    /// Все пары преподавателя по всему вузу: текущая неделя и ещё несколько вперёд
    static func loadLecturer(id: String, weeks: Int = 4) async throws -> [RuzEvent] {
        guard let url = lecturerURL(id) else { return [] }
        let html = try await fetch(url)
        rememberLecturers(from: html)
        var all = parseLecturerPage(html)

        let cal = moscowCalendar()
        let thisMonday = cal.dateInterval(of: .weekOfYear, for: Date())?.start ?? Date()
        let covered = Set(all.compactMap { cal.dateInterval(of: .weekOfYear, for: $0.start)?.start })
        let lastMonday = thisMonday.addingTimeInterval(Double(weeks) * 7 * 86_400)

        var targets = weekLinks(in: html, key: "lecturer", id: id)
            .filter { link in
                let m = cal.dateInterval(of: .weekOfYear, for: link.date)?.start ?? link.date
                return m >= thisMonday && m < lastMonday && !covered.contains(m)
            }
        var seenWeeks = Set<Date>()
        targets = targets.filter { seenWeeks.insert(cal.dateInterval(of: .weekOfYear, for: $0.date)?.start ?? $0.date).inserted }

        if !targets.isEmpty {
            let more = await withTaskGroup(of: [RuzEvent].self) { tg -> [RuzEvent] in
                for t in targets.prefix(weeks) {
                    tg.addTask { (try? await fetch(t.url)).map(parseLecturerPage) ?? [] }
                }
                var acc: [RuzEvent] = []
                for await p in tg { acc += p }
                return acc
            }
            all += more
        } else if !all.isEmpty {
            // вкладок нет — пробуем угадать формат ссылки на следующие недели
            for k in 1..<max(weeks, 2) {
                let monday = thisMonday.addingTimeInterval(Double(k) * 7 * 86_400)
                if covered.contains(monday) { continue }
                guard let found = await guessWeekURL(key: "lecturer", id: id, monday: monday) else { break }
                all += found.1
            }
        }

        var seen = Set<String>()
        let result = all.filter { seen.insert($0.id).inserted }.sorted { $0.start < $1.start }
        if !result.isEmpty, let raw = try? JSONEncoder().encode(result) {
            try? raw.write(to: lecturerCacheURL(id), options: .atomic)
        }
        return result
    }
}
