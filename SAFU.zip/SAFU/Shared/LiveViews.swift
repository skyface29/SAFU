import SwiftUI
import ActivityKit

// MARK: - Темы Live Activity

enum LiveTheme: String, CaseIterable, Identifiable {
    case night, glass, clear, black, kind, aurora, sunset, arctic

    var id: String { rawValue }

    var title: String {
        switch self {
        case .night: return "Ночь"
        case .glass: return "Стекло"
        case .clear: return "Прозрачная"
        case .black: return "Чёрная"
        case .kind: return "Цвет пары"
        case .aurora: return "Северное сияние"
        case .sunset: return "Закат"
        case .arctic: return "Арктика"
        }
    }

    /// Фон самой плашки (nil — системное стекло)
    var tint: Color? {
        switch self {
        case .night: return Color(red: 0.05, green: 0.10, blue: 0.25)
        case .glass: return nil
        case .clear: return Color.clear
        case .black: return Color.black
        case .kind, .aurora, .sunset, .arctic: return Color.black.opacity(0.35)
        }
    }

    /// Рисованный фон поверх (градиенты)
    func gradient(for kind: String) -> LinearGradient? {
        switch self {
        case .kind:
            let c = KindStyle.of(kind).color
            return LinearGradient(colors: [c.opacity(0.85), c.opacity(0.45)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .aurora:
            return LinearGradient(colors: [Color(red: 0.10, green: 0.55, blue: 0.50), Color(red: 0.30, green: 0.20, blue: 0.60)],
                                  startPoint: .leading, endPoint: .trailing)
        case .sunset:
            return LinearGradient(colors: [Color(red: 0.95, green: 0.45, blue: 0.25), Color(red: 0.75, green: 0.20, blue: 0.50)],
                                  startPoint: .leading, endPoint: .trailing)
        case .arctic:
            return LinearGradient(colors: [Color(red: 0.25, green: 0.55, blue: 0.85), Color(red: 0.10, green: 0.25, blue: 0.50)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        default:
            return nil
        }
    }

    /// Для системного стекла текст подстраивается под тему телефона
    var adaptiveText: Bool { self == .glass }

    var primary: Color { adaptiveText ? .primary : .white }
    var secondary: Color { adaptiveText ? .secondary : Color.white.opacity(0.68) }

    var accent: Color {
        switch self {
        case .kind, .aurora, .sunset, .arctic: return .white
        case .glass: return Color(red: 0.20, green: 0.50, blue: 1.0)
        default: return Color(red: 0.50, green: 0.78, blue: 1.0)
        }
    }

    /// Тень для текста на прозрачном фоне, чтобы читалось на любых обоях
    var needsShadow: Bool { self == .clear }
}

enum LiveLayout: String, CaseIterable, Identifiable {
    case full, medium, thin
    var id: String { rawValue }
    var title: String {
        switch self {
        case .full: return "Подробно"
        case .medium: return "Средне"
        case .thin: return "Тонко"
        }
    }
}

// MARK: - Мелочи

enum LiveFormat {
    static let hm: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "H:mm"
        return f
    }()
    static func hmText(_ d: Date) -> String { hm.string(from: d) }

    static let weekday: DateFormatter = {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.dateFormat = "EE"
        return f
    }()

    /// Пара не сегодня и нескоро — вместо таймера пишем день и время («пн 8:20»)
    static func isFar(_ d: Date) -> Bool {
        !Calendar.current.isDateInToday(d) && d.timeIntervalSinceNow > 6 * 3600
    }

    static func dayTime(_ d: Date) -> String {
        weekday.string(from: d).lowercased() + " " + hmText(d)
    }
}

/// Обратный отсчёт фиксированной ширины (иначе таймер растягивается и вылезает за край)
struct LiveTimer: View {
    let to: Date
    var width: CGFloat = 64
    var body: some View {
        let now = Date()
        if LiveFormat.isFar(to) {
            Text(LiveFormat.dayTime(to))
                .monospacedDigit()
                .multilineTextAlignment(.trailing)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
                .frame(width: width, alignment: .trailing)
        } else {
            Text(timerInterval: min(now, to)...max(now, to), countsDown: true)
                .monospacedDigit()
                .multilineTextAlignment(.trailing)
                .lineLimit(1)
                .frame(width: width, alignment: .trailing)
        }
    }
}

/// Аудитория и адрес в нормальном виде
struct LivePlace {
    let room: String
    let address: String

    init(_ s: PairActivityAttributes.ContentState) {
        if AddressFormat.isRemote(s.address) {
            room = s.room
            address = "Дистанционно"
        } else {
            let d = AddressFormat.decode(room: s.room, address: s.address, buildings: [])
            room = d.room
            address = d.address
        }
    }

    var roomText: String { room.isEmpty ? "" : "ауд. \(room)" }
    var line: String { [roomText, address].filter { !$0.isEmpty }.joined(separator: " · ") }
}

/// Цветная плашка типа пары
struct LiveKindBadge: View {
    let kind: String
    var size: CGFloat = 10
    var body: some View {
        let st = KindStyle.of(kind)
        HStack(spacing: 3) {
            Image(systemName: st.icon)
            Text(st.label.uppercased())
        }
        .font(.system(size: size, weight: .heavy))
        .foregroundStyle(.white)
        .padding(.horizontal, size * 0.6)
        .padding(.vertical, size * 0.2)
        .background(st.color, in: Capsule())
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.25), lineWidth: 0.5))
        .fixedSize()
    }
}

// MARK: - Экран блокировки

struct LiveLockScreenView: View {
    let state: PairActivityAttributes.ContentState

    private var theme: LiveTheme { LiveTheme(rawValue: state.theme) ?? .night }
    private var layout: LiveLayout { LiveLayout(rawValue: state.layout) ?? .full }

    var body: some View {
        content
            .shadow(color: theme.needsShadow ? .black.opacity(0.55) : .clear, radius: 3, y: 1)
            .padding(.horizontal, 14)
            .padding(.vertical, layout == .thin ? 7 : 10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background {
                if let g = theme.gradient(for: state.kind) {
                    ZStack {
                        g
                        // лёгкий блик сверху
                        LinearGradient(colors: [Color.white.opacity(0.16), .clear], startPoint: .top, endPoint: .center)
                    }
                }
            }
    }

    @ViewBuilder private var content: some View {
        switch layout {
        case .full: full
        case .medium: medium
        case .thin: thin
        }
    }

    private var target: Date { state.isNow ? state.end : state.start }

    private var timerBlock: some View {
        HStack(spacing: 4) {
            Text(state.isNow ? "ещё" : (LiveFormat.isFar(target) ? "в" : "через"))
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(theme.secondary)
            LiveTimer(to: target, width: 56)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(theme.accent)
        }
    }

    private var timeText: String {
        (state.pair > 0 ? "\(state.pair) пара · " : "") + "\(LiveFormat.hmText(state.start))–\(LiveFormat.hmText(state.end))"
    }

    /// Прогресс идущей пары
    @ViewBuilder private var progress: some View {
        if state.isNow {
            ProgressView(timerInterval: state.start...state.end, countsDown: false) {
                EmptyView()
            } currentValueLabel: {
                EmptyView()
            }
            .progressViewStyle(.linear)
            .tint(theme.accent)
            .scaleEffect(x: 1, y: 0.7, anchor: .center)
        }
    }

    // 3 строки + прогресс
    private var full: some View {
        let place = LivePlace(state)
        return VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 6) {
                LiveKindBadge(kind: state.kind)
                Text(timeText)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(theme.secondary)
                    .lineLimit(1)
                Spacer(minLength: 4)
                timerBlock
            }
            Text(state.subject)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(theme.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
            HStack(spacing: 6) {
                if !place.roomText.isEmpty {
                    Label(place.roomText, systemImage: "mappin.circle.fill")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(theme.primary)
                        .fixedSize()
                }
                if !place.address.isEmpty {
                    Text(place.address)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(theme.secondary)
                        .lineLimit(1)
                }
                Spacer(minLength: 4)
                if !state.teacher.isEmpty {
                    Label(state.teacher, systemImage: "person.fill")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(theme.secondary)
                        .lineLimit(1)
                        .layoutPriority(1)
                }
            }
            progress
        }
    }

    // 2 строки
    private var medium: some View {
        let place = LivePlace(state)
        return VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 6) {
                LiveKindBadge(kind: state.kind, size: 9)
                Text(state.subject)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(theme.primary)
                    .lineLimit(1)
                Spacer(minLength: 4)
                timerBlock
            }
            Text([timeText, place.line].filter { !$0.isEmpty }.joined(separator: " · "))
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(theme.secondary)
                .lineLimit(1)
        }
    }

    // 1 строка
    private var thin: some View {
        let st = KindStyle.of(state.kind)
        return HStack(spacing: 6) {
            Image(systemName: st.icon)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(theme.gradient(for: state.kind) == nil ? st.color : .white)
            Text(st.label)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(theme.primary)
                .lineLimit(1)
            let room = LivePlace(state).roomText
            if !room.isEmpty {
                Text("· \(room)")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(theme.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 4)
            timerBlock
        }
    }
}

// MARK: - Пример для превью в настройках

extension PairActivityAttributes.ContentState {
    static func sample(theme: String, layout: String) -> Self {
        let now = Date()
        return .init(subject: "Алгебра и геометрия", kind: "Лекция", room: "24",
                     address: "наб. Северной Двины, д. 2", teacher: "Кочкин С.А.",
                     start: now.addingTimeInterval(31 * 60), end: now.addingTimeInterval(126 * 60),
                     isNow: false, pair: 2, nextSubject: "", nextRoom: "", nextStart: nil,
                     theme: theme, layout: layout)
    }
}
