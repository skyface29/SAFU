import SwiftUI

/// Тип пары: единые цвета и значки для приложения, виджета и Live Activity
struct KindStyle {
    let label: String
    let color: Color
    let icon: String

    static func of(_ kind: String) -> KindStyle {
        let k = kind.lowercased()
        if k.hasPrefix("лекц") {
            return KindStyle(label: "Лекция", color: Color(red: 0.25, green: 0.52, blue: 1.0), icon: "person.wave.2.fill")
        }
        if k.hasPrefix("практ") {
            return KindStyle(label: "Практика", color: Color(red: 0.16, green: 0.75, blue: 0.42), icon: "pencil.and.ruler.fill")
        }
        if k.hasPrefix("лаб") {
            return KindStyle(label: "Лабораторная", color: Color(red: 1.0, green: 0.55, blue: 0.10), icon: "flask.fill")
        }
        if k.hasPrefix("семин") {
            return KindStyle(label: "Семинар", color: Color(red: 0.10, green: 0.72, blue: 0.78), icon: "bubble.left.and.bubble.right.fill")
        }
        if k.contains("экзам") {
            return KindStyle(label: "Экзамен", color: Color(red: 0.95, green: 0.25, blue: 0.30), icon: "graduationcap.fill")
        }
        if k.contains("зач") {
            return KindStyle(label: "Зачёт", color: Color(red: 0.93, green: 0.30, blue: 0.62), icon: "checkmark.seal.fill")
        }
        if k.contains("консул") {
            return KindStyle(label: "Консультация", color: Color(red: 0.62, green: 0.40, blue: 0.95), icon: "questionmark.bubble.fill")
        }
        return KindStyle(label: kind.isEmpty ? "Занятие" : kind, color: Color(red: 0.55, green: 0.58, blue: 0.65), icon: "book.fill")
    }
}

/// Цветная плашка типа пары
struct KindBadge: View {
    let kind: String
    var size: CGFloat = 11
    var filled = true

    var body: some View {
        let st = KindStyle.of(kind)
        HStack(spacing: 3) {
            Image(systemName: st.icon)
            Text(st.label.uppercased())
        }
        .font(.system(size: size, weight: .heavy))
        .foregroundStyle(filled ? Color.white : st.color)
        .padding(.horizontal, size * 0.6)
        .padding(.vertical, size * 0.25)
        .background(filled ? st.color : st.color.opacity(0.16), in: Capsule())
        .lineLimit(1)
        .fixedSize()
    }
}

/// Полный адрес: без сокращений и с городом
enum AddressFormat {
    private static let replacements: [(String, String)] = [
        ("наб.", "набережная"), ("ул.", "улица"), ("пр-т", "проспект"), ("просп.", "проспект"),
        ("пр.", "проспект"), ("пер.", "переулок"), ("пл.", "площадь"), ("ш.", "шоссе"),
        ("корп.", "корпус"), ("стр.", "строение"), ("д.", "дом"), ("г.", "город")
    ]

    static func full(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return "" }
        var words: [String] = []
        for token in trimmed.components(separatedBy: " ") {
            var w = token
            for (short, long) in replacements {
                if w.lowercased() == short {
                    w = long
                    break
                }
                // «д.2» → «дом 2»
                if w.lowercased().hasPrefix(short), w.count > short.count,
                   let first = w.dropFirst(short.count).first, first.isNumber {
                    w = long + " " + w.dropFirst(short.count)
                    break
                }
            }
            words.append(w)
        }
        var result = words.joined(separator: " ")
        let low = result.lowercased()
        if !low.contains("архангельск") && !low.contains("северодвинск") && !low.contains("город") {
            result = "г. Архангельск, " + result
        }
        return result
    }
}
