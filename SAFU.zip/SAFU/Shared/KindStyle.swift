import SwiftUI

/// Тип пары: единые цвета и значки для приложения, виджета и Live Activity
struct KindStyle {
    let label: String
    let color: Color
    let icon: String

    static func of(_ kind: String) -> KindStyle {
        let k = kind.lowercased()
        if k.hasPrefix("лекц") {
            return KindStyle(label: "Лекция", color: Color(red: 0.25, green: 0.52, blue: 1.0), icon: "person.wave.2.fill")
        }
        if k.hasPrefix("практ") {
            return KindStyle(label: "Практика", color: Color(red: 0.16, green: 0.75, blue: 0.42), icon: "pencil.and.ruler.fill")
        }
        if k.hasPrefix("лаб") {
            return KindStyle(label: "Лабораторная", color: Color(red: 1.0, green: 0.55, blue: 0.10), icon: "flask.fill")
        }
        if k.hasPrefix("семин") {
            return KindStyle(label: "Семинар", color: Color(red: 0.10, green: 0.72, blue: 0.78), icon: "bubble.left.and.bubble.right.fill")
        }
        if k.contains("экзам") {
            return KindStyle(label: "Экзамен", color: Color(red: 0.95, green: 0.25, blue: 0.30), icon: "graduationcap.fill")
        }
        if k.contains("зач") {
            return KindStyle(label: "Зачёт", color: Color(red: 0.93, green: 0.30, blue: 0.62), icon: "checkmark.seal.fill")
        }
        if k.contains("консул") {
            return KindStyle(label: "Консультация", color: Color(red: 0.62, green: 0.40, blue: 0.95), icon: "questionmark.bubble.fill")
        }
        return KindStyle(label: kind.isEmpty ? "Занятие" : kind, color: Color(red: 0.55, green: 0.58, blue: 0.65), icon: "book.fill")
    }
}

/// Цветная плашка типа пары
struct KindBadge: View {
    let kind: String
    var size: CGFloat = 11
    var filled = true

    var body: some View {
        let st = KindStyle.of(kind)
        HStack(spacing: 3) {
            Image(systemName: st.icon)
            Text(st.label.uppercased())
        }
        .font(.system(size: size, weight: .heavy))
        .foregroundStyle(filled ? Color.white : st.color)
        .padding(.horizontal, size * 0.6)
        .padding(.vertical, size * 0.25)
        .background(filled ? st.color : st.color.opacity(0.16), in: Capsule())
        .lineLimit(1)
        .fixedSize()
    }
}

/// Адреса из РУЗ: коды корпусов вида «А-НСД17/1405» превращаем в нормальный адрес и аудиторию
enum AddressFormat {
    /// Известные сокращения улиц в кодах корпусов САФУ.
    /// Если встретится незнакомый код — адрес можно задать вручную: «Пары» → «…» → «Коды корпусов».
    static let streets: [String: String] = [
        "НСД": "наб. Северной Двины",
        "ЛОМ": "просп. Ломоносова",
        "Л": "просп. Ломоносова",
        "СБ": "ул. Смольный Буян",
        "УР": "ул. Урицкого",
        "УРИ": "ул. Урицкого",
        "СЕВ": "ул. Северодвинская",
        "ГАГ": "ул. Гагарина",
        "ТИМ": "ул. Тимме"
    ]

    /// «в.з./д.о.», «дистанционно» и т.п. — пара не в корпусе
    static func isRemote(_ raw: String) -> Bool {
        let l = raw.lowercased().replacingOccurrences(of: " ", with: "")
        return l.contains("д.о") || l.contains("в.з") || l.contains("дистанц") || l.contains("онлайн")
            || l.contains("online") || l.contains("эиос") || l.contains("вебинар")
    }

    struct Code {
        let building: String   // «А-НСД17»
        let street: String     // «НСД»
        let house: String      // «17»
        let room: String       // «1405»
    }

    /// Разбор кода: «А-НСД17/1405», «А-НСД17-1405», «НСД 17/1405»
    static func parseCode(_ raw: String) -> Code? {
        let t = raw.trimmingCharacters(in: .whitespaces).uppercased()
            .replacingOccurrences(of: "A", with: "А")   // латинская A → русская
        let pattern = "^(?:([А-Я])\\s*-\\s*)?([А-ЯЁ]{1,5})\\s*(\\d{1,3}[А-ЯЁ]?)(?:\\s*[/\\-]\\s*([0-9А-ЯЁA-Z.\\-]+))?$"
        guard let re = try? NSRegularExpression(pattern: pattern),
              let m = re.firstMatch(in: t, range: NSRange(location: 0, length: (t as NSString).length)) else { return nil }
        let ns = t as NSString
        func g(_ i: Int) -> String {
            let r = m.range(at: i)
            return r.location == NSNotFound ? "" : ns.substring(with: r)
        }
        let city = g(1), street = g(2), house = g(3), room = g(4)
        let building = (city.isEmpty ? "" : city + "-") + street + house
        return Code(building: building, street: street, house: house, room: room)
    }

    /// Нормальные аудитория и адрес для показа (и для карт)
    static func decode(room: String, address: String, buildings: [Building]) -> (room: String, address: String) {
        guard !isRemote(address), let c = parseCode(address) else { return (room, address) }
        let finalRoom = room.isEmpty ? c.room : room
        // свой адрес для кода, если пользователь его задал
        if let b = buildings.first(where: { $0.name.uppercased() == c.building || $0.name.uppercased() == c.street + c.house }) {
            return (finalRoom, b.address)
        }
        if let street = streets[c.street] {
            return (finalRoom, "\(street), д. \(c.house)")
        }
        return (finalRoom, "корпус \(c.street)-\(c.house)")
    }

    /// Текст адреса для экрана
    static func full(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return "" }
        if isRemote(trimmed) { return "Дистанционно / вне здания" }
        if let c = parseCode(trimmed) {
            if let street = streets[c.street] { return "\(street), д. \(c.house)" }
            return "корпус \(c.street)-\(c.house)"
        }
        return trimmed
    }
}
