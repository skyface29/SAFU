import SwiftUI

/// Тип пары: единые цвета и значки для приложения, виджета и Live Activity
struct KindStyle {
    let label: String
    let color: Color
    let icon: String

    private static let enNames: [String: String] = [
        "Лекция": "Lecture", "Практика": "Practical", "Лабораторная": "Lab", "Семинар": "Seminar",
        "Экзамен": "Exam", "Зачёт": "Pass/fail test", "Консультация": "Consultation", "Занятие": "Class",
        "Физкультура": "PE", "Другое": "Other"
    ]

    /// Подпись типа пары на языке интерфейса
    static func display(_ ru: String) -> String {
        Lang.en ? (enNames[ru] ?? ru) : ru
    }

    static func of(_ kind: String) -> KindStyle {
        let k = kind.lowercased()
        if k.hasPrefix("лекц") {
            return KindStyle(label: KindStyle.display("Лекция"), color: Color(red: 0.25, green: 0.52, blue: 1.0), icon: "person.wave.2.fill")
        }
        if k.hasPrefix("практ") {
            return KindStyle(label: KindStyle.display("Практика"), color: Color(red: 0.16, green: 0.75, blue: 0.42), icon: "pencil.and.ruler.fill")
        }
        if k.hasPrefix("лаб") {
            return KindStyle(label: KindStyle.display("Лабораторная"), color: Color(red: 1.0, green: 0.55, blue: 0.10), icon: "flask.fill")
        }
        if k.hasPrefix("семин") {
            return KindStyle(label: KindStyle.display("Семинар"), color: Color(red: 0.10, green: 0.72, blue: 0.78), icon: "bubble.left.and.bubble.right.fill")
        }
        if k.contains("экзам") {
            return KindStyle(label: KindStyle.display("Экзамен"), color: Color(red: 0.95, green: 0.25, blue: 0.30), icon: "graduationcap.fill")
        }
        if k.contains("зач") {
            return KindStyle(label: KindStyle.display("Зачёт"), color: Color(red: 0.93, green: 0.30, blue: 0.62), icon: "checkmark.seal.fill")
        }
        if k.contains("консул") {
            return KindStyle(label: KindStyle.display("Консультация"), color: Color(red: 0.62, green: 0.40, blue: 0.95), icon: "questionmark.bubble.fill")
        }
        return KindStyle(label: kind.isEmpty ? KindStyle.display("Занятие") : kind, color: Color(red: 0.55, green: 0.58, blue: 0.65), icon: "book.fill")
    }
}

/// Цветная плашка типа пары
struct KindBadge: View {
    let kind: String
    var size: CGFloat = 11
    var filled = true

    var body: some View {
        let st = KindStyle.of(kind)
        HStack(spacing: 3) {
            Image(systemName: st.icon)
            Text(st.label.uppercased())
        }
        .font(.system(size: size, weight: .heavy))
        .foregroundStyle(filled ? Color.white : st.color)
        .padding(.horizontal, size * 0.6)
        .padding(.vertical, size * 0.25)
        .background(filled ? st.color : st.color.opacity(0.16), in: Capsule())
        .lineLimit(1)
        .fixedSize()
    }
}

/// Адреса из РУЗ: коды корпусов вида «А-НСД17/1405» превращаем в нормальный адрес и аудиторию
enum AddressFormat {
    /// Известные сокращения улиц в кодах корпусов САФУ.
    /// Если встретится незнакомый код — адрес можно задать вручную: «Пары» → «…» → «Коды корпусов».
    static let streets: [String: String] = [
        "НСД": L("наб. Северной Двины"),
        "ЛОМ": L("просп. Ломоносова"),
        "Л": L("просп. Ломоносова"),
        "СБ": L("ул. Смольный Буян"),
        "УР": L("ул. Урицкого"),
        "УРИ": L("ул. Урицкого"),
        "СЕВ": L("ул. Северодвинская"),
        "ГАГ": L("ул. Гагарина"),
        "ТИМ": L("ул. Тимме")
    ]

    /// Учебные корпуса по номеру (код «АУК-10» = учебный корпус № 10)
    static let corpusAddresses: [String: String] = [
        "3": L("наб. Северной Двины, д. 17"),
        "6": L("просп. Ломоносова, д. 4"),
        "10": L("просп. Ломоносова, д. 2")
    ]

    /// «в.з./д.о.», «дистанционно», «ДОТ», «онлайн» и т.п. — пара не в корпусе
    static func isRemote(_ raw: String) -> Bool {
        let l = raw.lowercased().replacingOccurrences(of: " ", with: "")
        guard !l.isEmpty else { return false }
        if l.contains("д.о") || l.contains("в.з") || l.contains("дистан") || l.contains("онлайн")
            || l.contains("online") || l.contains("эиос") || l.contains("вебинар") || l.contains("webinar")
            || l.contains("видеоконф") || l.contains("zoom") || l.contains("мтслинк") || l.contains("mts-link") {
            return true
        }
        return hasRemoteWord(raw)
    }

    /// Пометка о дистанте в примечании к паре («Дистанционно», «(ДОТ)», «онлайн»).
    /// Строже, чем для адреса: «материалы в ЭИОС» бывает и у очных пар
    static func isRemoteNote(_ raw: String) -> Bool {
        let l = raw.lowercased().replacingOccurrences(of: " ", with: "")
        guard !l.isEmpty else { return false }
        if l.contains("в.з./д.о") || l.contains("дистанц") || l.contains("онлайн") || l.contains("online")
            || l.contains("вебинар") || l.contains("webinar") || l.contains("видеоконф") {
            return true
        }
        return hasRemoteWord(raw)
    }

    /// Отдельные слова: «ДОТ», «СДО», «Teams» — только целым словом, чтобы не ловить части названий
    private static func hasRemoteWord(_ raw: String) -> Bool {
        let words = raw.lowercased().split { !$0.isLetter && !$0.isNumber }
        return words.contains { $0 == "дот" || $0 == "сдо" || $0 == "teams" || $0 == "дистант" }
    }

    /// Регулярка компилируется один раз (раньше — при каждом показе пары)
    private static let codeRegex = try? NSRegularExpression(pattern: "^(?:([А-Я])\\s*-\\s*)?([А-ЯЁ]{1,5})\\s*-?\\s*(\\d{1,3}[А-ЯЁ]?)(?:\\s*[/\\-]\\s*([0-9А-ЯЁA-Z.\\-]+))?$")

    struct Code {
        let building: String   // «А-НСД17»
        let street: String     // «НСД»
        let house: String      // «17»
        let room: String       // «1405»
    }

    /// Разбор кода: «А-НСД17/1405», «А-НСД17-1405», «НСД 17/1405»
    static func parseCode(_ raw: String) -> Code? {
        let t = raw.trimmingCharacters(in: .whitespaces).uppercased()
            .replacingOccurrences(of: "A", with: "А")   // латинская A → русская
        guard let re = codeRegex,
              let m = re.firstMatch(in: t, range: NSRange(location: 0, length: (t as NSString).length)) else { return nil }
        let ns = t as NSString
        func g(_ i: Int) -> String {
            let r = m.range(at: i)
            return r.location == NSNotFound ? "" : ns.substring(with: r)
        }
        var city = g(1), street = g(2)
        let house = g(3), room = g(4)
        // «АУК» = «А» (Архангельск) + «УК» (учебный корпус); то же для «АНСД» и т.п.
        if city.isEmpty, street.count > 1, street.hasPrefix("А") {
            let rest = String(street.dropFirst())
            if rest == "УК" || streets[rest] != nil {
                city = L("А")
                street = rest
            }
        }
        let building = (city.isEmpty ? "" : city + "-") + street + house
        return Code(building: building, street: street, house: house, room: room)
    }

    /// Адрес по коду без аудитории
    static func addressText(for c: Code) -> String {
        if c.street == "УК" {
            if let a = corpusAddresses[c.house] { return L("учебный корпус № \(c.house), \(a)") }
            return L("учебный корпус № \(c.house)")
        }
        if let street = streets[c.street] { return L("\(street), д. \(c.house)") }
        return L("корпус \(c.street)-\(c.house)")
    }

    /// Нормальные аудитория и адрес для показа (и для карт)
    static func decode(room: String, address: String, buildings: [Building]) -> (room: String, address: String) {
        guard !isRemote(address), let c = parseCode(address) else { return (room, address) }
        let finalRoom = room.isEmpty ? c.room : room
        // свой адрес для кода, если пользователь его задал
        if let b = buildings.first(where: { $0.name.uppercased() == c.building || $0.name.uppercased() == c.street + c.house }) {
            return (finalRoom, b.address)
        }
        return (finalRoom, Self.addressText(for: c))
    }

    /// Текст адреса для экрана
    static func full(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespaces)
        guard !trimmed.isEmpty else { return "" }
        if isRemote(trimmed) { return L("Дистанционно / вне здания") }
        if let c = parseCode(trimmed) { return Self.addressText(for: c) }
        return trimmed
    }
}
