import Foundation
import ActivityKit

/// Данные Live Activity (экран блокировки и Dynamic Island).
/// Передаются из приложения напрямую — общие данные (App Groups) не нужны.
struct PairActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var subject: String
        var kind: String
        var room: String
        var address: String
        var teacher: String
        var start: Date
        var end: Date
        var isNow: Bool
        var pair: Int
        var nextSubject: String
        var nextRoom: String
        var nextStart: Date?
        /// Оформление: тема и размер (выбираются в Профиле)
        var theme: String = "night"
        var layout: String = "full"
    }

    var group: String
}

// Старые активности без темы тоже читаются
extension PairActivityAttributes.ContentState {
    private enum K: String, CodingKey {
        case subject, kind, room, address, teacher, start, end, isNow, pair, nextSubject, nextRoom, nextStart, theme, layout
    }

    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        subject = try c.decodeIfPresent(String.self, forKey: .subject) ?? ""
        kind = try c.decodeIfPresent(String.self, forKey: .kind) ?? ""
        room = try c.decodeIfPresent(String.self, forKey: .room) ?? ""
        address = try c.decodeIfPresent(String.self, forKey: .address) ?? ""
        teacher = try c.decodeIfPresent(String.self, forKey: .teacher) ?? ""
        start = try c.decodeIfPresent(Date.self, forKey: .start) ?? Date()
        end = try c.decodeIfPresent(Date.self, forKey: .end) ?? Date()
        isNow = try c.decodeIfPresent(Bool.self, forKey: .isNow) ?? false
        pair = try c.decodeIfPresent(Int.self, forKey: .pair) ?? 0
        nextSubject = try c.decodeIfPresent(String.self, forKey: .nextSubject) ?? ""
        nextRoom = try c.decodeIfPresent(String.self, forKey: .nextRoom) ?? ""
        nextStart = try c.decodeIfPresent(Date.self, forKey: .nextStart)
        theme = try c.decodeIfPresent(String.self, forKey: .theme) ?? "night"
        layout = try c.decodeIfPresent(String.self, forKey: .layout) ?? "full"
    }
}
