import Foundation
import ActivityKit

/// Данные Live Activity (экран блокировки и Dynamic Island).
/// Передаются из приложения напрямую — общие данные (App Groups) не нужны.
struct PairActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var subject: String
        var kind: String
        var room: String
        var address: String
        var teacher: String
        var start: Date
        var end: Date
        var isNow: Bool
        var pair: Int
        var nextSubject: String
        var nextRoom: String
        var nextStart: Date?
        /// Оформление: тема и размер (выбираются в Профиле)
        var theme: String = "night"
        var layout: String = "full"
        /// Dynamic Island: "timer" — значок и короткий таймер, "icon" — только маленький значок
        var island: String = "timer"
    }

    var group: String
}

// Старые активности без темы тоже читаются
extension PairActivityAttributes.ContentState {
    private enum K: String, CodingKey {
        case subject, kind, room, address, teacher, start, end, isNow, pair, nextSubject, nextRoom, nextStart, theme, layout, island
    }

    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        subject = try c.decodeIfPresent(String.self, forKey: .subject) ?? ""
        kind = try c.decodeIfPresent(String.self, forKey: .kind) ?? ""
        room = try c.decodeIfPresent(String.self, forKey: .room) ?? ""
        address = try c.decodeIfPresent(String.self, forKey: .address) ?? ""
        teacher = try c.decodeIfPresent(String.self, forKey: .teacher) ?? ""
        start = try c.decodeIfPresent(Date.self, forKey: .start) ?? Date()
        end = try c.decodeIfPresent(Date.self, forKey: .end) ?? Date()
        isNow = try c.decodeIfPresent(Bool.self, forKey: .isNow) ?? false
        pair = try c.decodeIfPresent(Int.self, forKey: .pair) ?? 0
        nextSubject = try c.decodeIfPresent(String.self, forKey: .nextSubject) ?? ""
        nextRoom = try c.decodeIfPresent(String.self, forKey: .nextRoom) ?? ""
        nextStart = try c.decodeIfPresent(Date.self, forKey: .nextStart)
        theme = try c.decodeIfPresent(String.self, forKey: .theme) ?? "night"
        layout = try c.decodeIfPresent(String.self, forKey: .layout) ?? "full"
        island = try c.decodeIfPresent(String.self, forKey: .island) ?? "timer"
    }
}

// MARK: - Переключение по времени без обновления от приложения
// iOS перерисовывает Live Activity в момент staleDate (начало или конец пары). Если приложение не успело
// прислать новое состояние (в фоне это не гарантировано), считаем сами: началась пара — отсчёт до конца,
// закончилась — показываем следующую. Так таймер не зависает на «0:00».
extension PairActivityAttributes.ContentState {
    func effective(at now: Date = Date()) -> Self {
        var s = self
        if !s.isNow && now >= s.start && now < s.end {
            s.isNow = true
        }
        if now >= s.end, let next = s.nextStart, !s.nextSubject.isEmpty {
            s.subject = s.nextSubject
            s.room = s.nextRoom
            s.kind = ""
            s.teacher = ""
            s.start = next
            s.end = next.addingTimeInterval(95 * 60)
            s.isNow = now >= next
            s.pair = s.pair > 0 ? s.pair + 1 : 0
            s.nextSubject = ""
            s.nextRoom = ""
            s.nextStart = nil
        }
        return s
    }
}
