import Foundation
import ActivityKit

/// Данные Live Activity (экран блокировки и Dynamic Island).
/// Передаются из приложения напрямую — общие данные (App Groups) не нужны.
struct PairActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var subject: String
        var kind: String
        var room: String
        var address: String
        var teacher: String
        var start: Date
        var end: Date
        var isNow: Bool
        var pair: Int
        var nextSubject: String
        var nextRoom: String
        var nextStart: Date?
    }

    var group: String
}
