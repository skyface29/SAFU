import Foundation

// MARK: - Live Activity на Mac
// На Mac нет экрана блокировки и Dynamic Island, и ActivityKit там недоступен.
// Эти типы повторяют то, чем пользуется приложение, и ничего не делают — код пар и автобуса
// остаётся общим с iPhone без единой развилки. Типы своего модуля важнее импортированных,
// поэтому на Mac берутся они, а на iPhone этого файла нет вовсе.

#if targetEnvironment(macCatalyst)

protocol ActivityAttributes: Codable {
    associatedtype ContentState: Codable & Hashable
}

struct ActivityAuthorizationInfo {
    var areActivitiesEnabled: Bool { false }
}

struct ActivityContent<State> {
    var state: State
    var staleDate: Date?
    var relevanceScore: Double
    init(state: State, staleDate: Date?, relevanceScore: Double = 0) {
        self.state = state
        self.staleDate = staleDate
        self.relevanceScore = relevanceScore
    }
}

enum ActivityUIDismissalPolicy {
    case `default`, immediate
    static func after(_ date: Date) -> ActivityUIDismissalPolicy { .default }
}

struct PushType {}

struct ActivityUnavailable: Error {}

final class Activity<Attributes: ActivityAttributes> {
    let attributes: Attributes
    let content: ActivityContent<Attributes.ContentState>

    private init(attributes: Attributes, content: ActivityContent<Attributes.ContentState>) {
        self.attributes = attributes
        self.content = content
    }

    static var activities: [Activity<Attributes>] { [] }

    static func request(attributes: Attributes, content: ActivityContent<Attributes.ContentState>,
                        pushType: PushType? = nil) throws -> Activity<Attributes> {
        throw ActivityUnavailable()
    }

    func update(_ content: ActivityContent<Attributes.ContentState>) async {}

    func end(_ content: ActivityContent<Attributes.ContentState>?,
             dismissalPolicy: ActivityUIDismissalPolicy = .default) async {}
}

#endif
