import Foundation
import ActivityKit
import SwiftUI

/// Live Activity автобуса 150: отсчёт до отправления и прогресс поездки
struct BusActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var departure: Date
        var arrival: Date
        var from: String
        var to: String
        var theme: String = "night"
    }
    var route: String = "150"
}

extension BusActivityAttributes.ContentState {
    private enum K: String, CodingKey { case departure, arrival, from, to, theme }
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        departure = try c.decodeIfPresent(Date.self, forKey: .departure) ?? Date()
        arrival = try c.decodeIfPresent(Date.self, forKey: .arrival) ?? Date()
        from = try c.decodeIfPresent(String.self, forKey: .from) ?? ""
        to = try c.decodeIfPresent(String.self, forKey: .to) ?? ""
        theme = try c.decodeIfPresent(String.self, forKey: .theme) ?? "night"
    }
}

/// Экран блокировки для автобуса
struct BusLockScreenView: View {
    let state: BusActivityAttributes.ContentState

    private var theme: LiveTheme { LiveTheme(rawValue: state.theme) ?? .night }

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 6) {
                HStack(spacing: 3) {
                    Image(systemName: "bus.fill")
                    Text("150")
                }
                .font(.system(size: 11, weight: .heavy))
                .foregroundStyle(.white)
                .padding(.horizontal, 7)
                .padding(.vertical, 2)
                .background(Color(red: 0.95, green: 0.55, blue: 0.10), in: Capsule())

                Text("\(state.from) → \(state.to)")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(theme.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 4)
                Text("через")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(theme.secondary)
                LiveTimer(to: state.departure, width: 56)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundStyle(theme.accent)
            }
            HStack(spacing: 6) {
                Text(LiveFormat.hmText(state.departure))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(theme.primary)
                ProgressView(timerInterval: state.departure...state.arrival, countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .progressViewStyle(.linear)
                .tint(Color(red: 0.95, green: 0.55, blue: 0.10))
                Text("~" + LiveFormat.hmText(state.arrival))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(theme.secondary)
            }
        }
        .shadow(color: theme.needsShadow ? .black.opacity(0.55) : .clear, radius: 3, y: 1)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            if let g = theme.gradient(for: "") { g }
        }
    }
}
