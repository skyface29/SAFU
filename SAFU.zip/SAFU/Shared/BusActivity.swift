import Foundation
import ActivityKit
import SwiftUI
import AppIntents

/// Live Activity автобуса: отсчёт до отправления и прогресс поездки.
/// Номер и цвет маршрута приходят в атрибутах — так работает любой автобус, не только 150.
struct BusActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var departure: Date
        var arrival: Date
        var from: String
        var to: String
        var theme: String = "night"
    }
    var route: String = "150"
    var colorHex: String = "F28C1A"
    var direction: String = "toCampus"
}

extension BusActivityAttributes {
    private enum AK: String, CodingKey { case route, colorHex, direction }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: AK.self)
        route = try c.decodeIfPresent(String.self, forKey: .route) ?? "150"
        colorHex = try c.decodeIfPresent(String.self, forKey: .colorHex) ?? "F28C1A"
        direction = try c.decodeIfPresent(String.self, forKey: .direction) ?? "toCampus"
    }
    var color: Color { Color(hex: colorHex) ?? Color(red: 0.95, green: 0.55, blue: 0.10) }
}

extension BusActivityAttributes.ContentState {
    private enum K: String, CodingKey { case departure, arrival, from, to, theme }
    public init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: K.self)
        departure = try c.decodeIfPresent(Date.self, forKey: .departure) ?? Date()
        arrival = try c.decodeIfPresent(Date.self, forKey: .arrival) ?? Date()
        from = try c.decodeIfPresent(String.self, forKey: .from) ?? ""
        to = try c.decodeIfPresent(String.self, forKey: .to) ?? ""
        theme = try c.decodeIfPresent(String.self, forKey: .theme) ?? "night"
    }
}

extension Color {
    /// «F28C1A» или «#F28C1A»
    init?(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.hasPrefix("#") { s.removeFirst() }
        guard s.count == 6, let v = UInt32(s, radix: 16) else { return nil }
        self.init(red: Double((v >> 16) & 0xFF) / 255,
                  green: Double((v >> 8) & 0xFF) / 255,
                  blue: Double(v & 0xFF) / 255)
    }
}

// MARK: - Кнопка «Убрать» прямо на Live Activity

/// Завершает только Live Activity автобуса (пара остаётся).
/// Запоминает, что на сегодня в эту сторону автозапуск не нужен.
struct StopBusLiveIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Убрать автобус с экрана"
    static var description = IntentDescription("Закрывает Live Activity автобуса. Live Activity пары не трогает.")
    static var openAppWhenRun: Bool = false
    static var isDiscoverable: Bool = false

    func perform() async throws -> some IntentResult {
        BusLiveDismissal.markAllDismissed()
        for a in Activity<BusActivityAttributes>.activities {
            await a.end(nil, dismissalPolicy: .immediate)
        }
        return .result()
    }
}

/// Какие рейсы пользователь сам убрал — чтобы автозапуск не возвращал их обратно
enum BusLiveDismissal {
    private static let key = "busLive.dismissed"

    private static func dayKey(_ d: Date) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: d)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }

    static func markDismissed(direction: String, on day: Date = Date()) {
        var list = (UserDefaults.standard.stringArray(forKey: key) ?? []).filter { $0.hasPrefix(dayKey(day)) }
        list.append("\(dayKey(day))|\(direction)")
        UserDefaults.standard.set(list, forKey: key)
    }

    static func markAllDismissed() {
        let dirs = Activity<BusActivityAttributes>.activities.map(\.attributes.direction)
        for d in (dirs.isEmpty ? ["toCampus", "toHome"] : dirs) { markDismissed(direction: d) }
    }

    static func isDismissed(direction: String, on day: Date = Date()) -> Bool {
        (UserDefaults.standard.stringArray(forKey: key) ?? []).contains("\(dayKey(day))|\(direction)")
    }

    static func clearToday() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}

// MARK: - Экран блокировки

struct BusLockScreenView: View {
    let state: BusActivityAttributes.ContentState
    var route: String = "150"
    var color: Color = Color(red: 0.95, green: 0.55, blue: 0.10)
    var showClose: Bool = true

    private var theme: LiveTheme { LiveTheme(rawValue: state.theme) ?? .night }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                HStack(spacing: 3) {
                    Image(systemName: "bus.fill")
                    Text(route)
                }
                .font(.system(size: 11, weight: .heavy))
                .foregroundStyle(.white)
                .padding(.horizontal, 7)
                .padding(.vertical, 2)
                .background(color, in: Capsule())

                Text("\(state.from) → \(state.to)")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(theme.primary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 4)
                Text("через")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(theme.secondary)
                LiveTimer(to: state.departure, width: 56)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundStyle(theme.accent)
            }
            HStack(spacing: 6) {
                Text(LiveFormat.hmText(state.departure))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(theme.primary)
                ProgressView(timerInterval: state.departure...state.arrival, countsDown: false) {
                    EmptyView()
                } currentValueLabel: {
                    EmptyView()
                }
                .progressViewStyle(.linear)
                .tint(color)
                Text("~" + LiveFormat.hmText(state.arrival))
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(theme.secondary)
                if showClose {
                    Button(intent: StopBusLiveIntent()) {
                        Image(systemName: "xmark")
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundStyle(theme.secondary)
                            .frame(width: 22, height: 22)
                            .background(theme.secondary.opacity(0.18), in: Circle())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .shadow(color: theme.needsShadow ? .black.opacity(0.55) : .clear, radius: 3, y: 1)
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            if let g = theme.gradient(for: "") { g }
        }
    }
}
