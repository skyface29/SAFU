import Foundation

// MARK: - Язык интерфейса (русский / английский)
//
// Все фразы интерфейса в коде написаны по-русски и обёрнуты в L("…").
// В русском режиме L() возвращает ту же строку без поиска в словаре.
// В английском берёт перевод из en.json (ключ — русская фраза, вместо
// подстановок \(…) в ключе стоит %@). Если перевода нет — остаётся русский.
// Данные университета (предметы, ФИО, аудитории, ДЗ, письма) не переводятся.

enum AppLanguage: String, CaseIterable, Identifiable {
    case system, ru, en
    var id: String { rawValue }
}

enum Lang {
    static let key = "app.language"
    static let changed = Notification.Name("app.language.changed")

    private static var store: UserDefaults { UserDefaults(suiteName: "group.ru.student.safuhub") ?? .standard }

    /// Выбор пользователя: системный, русский или английский
    static var choice: AppLanguage {
        get { AppLanguage(rawValue: store.string(forKey: key) ?? "") ?? .system }
        set {
            store.set(newValue.rawValue, forKey: key)
            UserDefaults.standard.set(newValue.rawValue, forKey: key)
            resolved = resolve()
            NotificationCenter.default.post(name: changed, object: nil)
        }
    }

    /// Языки, носители которых обычно читают по-русски: им — русский по умолчанию
    private static let russianFirst: Set<String> = ["ru", "uk", "be", "kk", "ky", "uz", "tg", "tk"]

    private static func resolve() -> Bool {
        switch choice {
        case .ru: return false
        case .en: return true
        case .system:
            let code = Locale.preferredLanguages.first.map { String($0.prefix(2)).lowercased() } ?? "ru"
            return !russianFirst.contains(code)
        }
    }

    private static var resolved: Bool = resolve()

    /// true — интерфейс на английском
    static var en: Bool { resolved }

    /// Язык системы, если выбран «Как в системе»
    static var systemIsEnglish: Bool {
        let code = Locale.preferredLanguages.first.map { String($0.prefix(2)).lowercased() } ?? "ru"
        return !russianFirst.contains(code)
    }

    /// Локаль для дат и чисел. en_GB: 24-часовое время и «1 November», как привычно в Европе
    static var locale: Locale { en ? Locale(identifier: "en_GB") : Lang.locale }
    static var code: String { en ? "en" : "ru" }
}

// MARK: - Словарь

enum LocTable {
    private static let lock = NSLock()
    private static var loaded: [String: String]?

    static var en: [String: String] {
        lock.lock(); defer { lock.unlock() }
        if let t = loaded { return t }
        var t: [String: String] = [:]
        if let url = Bundle.main.url(forResource: "en", withExtension: "json"),
           let data = try? Data(contentsOf: url),
           let d = try? JSONDecoder().decode([String: String].self, from: data) {
            t = d
        }
        loaded = t
        return t
    }
}

/// Фраза интерфейса. Строковый литерал с подстановками \(…) превращается в ключ с %@ и список значений.
struct LKey: ExpressibleByStringInterpolation {
    let key: String
    let args: [String]

    init(stringLiteral value: String) {
        key = value.contains("%") ? value.replacingOccurrences(of: "%", with: "%%") : value
        args = []
    }
    init(stringInterpolation i: Interpolation) { key = i.key; args = i.args }

    struct Interpolation: StringInterpolationProtocol {
        var key = ""
        var args: [String] = []
        init(literalCapacity: Int, interpolationCount: Int) {
            key.reserveCapacity(literalCapacity + interpolationCount * 2)
        }
        mutating func appendLiteral(_ s: String) {
            // знак процента в самой фразе не должен путаться с подстановкой
            key += s.contains("%") ? s.replacingOccurrences(of: "%", with: "%%") : s
        }
        mutating func appendInterpolation<T>(_ v: T) {
            key += "%@"
            args.append(String(describing: v))
        }
        mutating func appendInterpolation(_ v: String) {
            key += "%@"
            args.append(v)
        }
    }
}

/// Перевод фразы интерфейса на текущий язык
@inline(__always)
func L(_ k: LKey) -> String {
    if Lang.en, let t = LocTable.en[k.key] { return LocFill.fill(t, k.args) }
    if k.args.isEmpty && !k.key.contains("%") { return k.key }
    return LocFill.fill(k.key, k.args)
}

extension String {
    /// Перевод готовой строки (например, rawValue или фразы из таблицы), если она есть в словаре
    var loc: String {
        guard Lang.en else { return self }
        return LocTable.en[self] ?? self
    }
}

enum LocFill {
    /// Подставляет значения: %@ — по порядку, %1$@ — по номеру, %% — знак процента
    static func fill(_ s: String, _ args: [String]) -> String {
        guard s.contains("%") else { return s }
        var out = ""
        out.reserveCapacity(s.count + args.reduce(0) { $0 + $1.count })
        var next = 0
        var i = s.startIndex
        while i < s.endIndex {
            let c = s[i]
            if c == "%" {
                let j = s.index(after: i)
                if j < s.endIndex {
                    if s[j] == "%" { out.append("%"); i = s.index(after: j); continue }
                    if s[j] == "@" {
                        if next < args.count { out += args[next] }
                        next += 1
                        i = s.index(after: j); continue
                    }
                    // %1$@
                    var k = j; var num = 0
                    while k < s.endIndex, let d = s[k].wholeNumberValue { num = num * 10 + d; k = s.index(after: k) }
                    if num > 0, k < s.endIndex, s[k] == "$" {
                        let at = s.index(after: k)
                        if at < s.endIndex, s[at] == "@" {
                            if num - 1 < args.count { out += args[num - 1] }
                            i = s.index(after: at); continue
                        }
                    }
                }
            }
            out.append(c)
            i = s.index(after: i)
        }
        return out
    }

    /// Русское число для слов: 1 задание, 2 задания, 5 заданий. По-английски — 1 task / 2 tasks.
    static func plural(_ n: Int, _ one: String, _ few: String, _ many: String) -> String {
        if Lang.en { return abs(n) == 1 ? one : many }
        let a = abs(n) % 100, b = a % 10
        if a > 10 && a < 20 { return many }
        if b == 1 { return one }
        if b >= 2 && b <= 4 { return few }
        return many
    }
}
