import Foundation
import UIKit
import SwiftUI

// MARK: - Мост «приложение → виджет» без App Groups
// После переподписи IPA общие данные (App Group) не работают, и виджет не видел ни группу, ни расписание.
// Именованный буфер обмена доступен только приложениям одного разработчика (само приложение и его виджет),
// в общий буфер ничего не попадает. Приложение кладёт туда группу и пары на 3 недели вперёд,
// виджет забирает их при обновлении и сохраняет у себя.

enum WidgetBridge {
    private static let name = UIPasteboard.Name("ru.student.safuhub.widget-bridge")
    private static let type = "ru.student.safuhub.schedule"

    /// Приложение: отдать виджету группу и ближайшие пары
    static func publish(_ data: ScheduleData) {
        guard data.usesRuz, !data.ruzGroupNumber.isEmpty else { return }
        var lite = data
        let from = Date().addingTimeInterval(-2 * 86_400)
        let to = Date().addingTimeInterval(21 * 86_400)
        lite.ruzEvents = data.ruzEvents.filter { $0.start >= from && $0.start <= to }
        lite.history = [:]
        guard let raw = try? JSONEncoder().encode(lite),
              let board = UIPasteboard(name: name, create: true) else { return }
        board.setItems([[type: raw]], options: [.localOnly: true])
    }

    /// Виджет: что оставило приложение (nil — моста нет или он пуст)
    static func read() -> ScheduleData? {
        guard let board = UIPasteboard(name: name, create: false),
              let raw = board.data(forPasteboardType: type),
              let d = try? JSONDecoder().decode(ScheduleData.self, from: raw),
              !d.ruzGroupNumber.isEmpty else { return nil }
        return d
    }
}

// MARK: - Оформление виджета (выбирается в приложении, передаётся через тот же мост)

enum WidgetTheme: String, CaseIterable, Identifiable {
    case night, aurora, graphite, bordeaux, forest, cosmos, subject
    var id: String { rawValue }

    var title: String {
        switch self {
        case .night: return "Ночь"
        case .aurora: return "Сияние"
        case .graphite: return "Графит"
        case .bordeaux: return "Бордо"
        case .forest: return "Хвоя"
        case .cosmos: return "Космос"
        case .subject: return "Цвет предмета"
        }
    }

    /// Верх и низ градиента, акцент
    func colors(subject: Color?) -> (Color, Color, Color) {
        switch self {
        case .night: return (Color(red: 0.09, green: 0.20, blue: 0.48), Color(red: 0.03, green: 0.07, blue: 0.20), Color(red: 0.50, green: 0.78, blue: 1.0))
        case .aurora: return (Color(red: 0.05, green: 0.36, blue: 0.40), Color(red: 0.16, green: 0.08, blue: 0.34), Color(red: 0.45, green: 1.0, blue: 0.78))
        case .graphite: return (Color(red: 0.20, green: 0.21, blue: 0.24), Color(red: 0.07, green: 0.07, blue: 0.09), Color(red: 0.80, green: 0.84, blue: 0.90))
        case .bordeaux: return (Color(red: 0.42, green: 0.08, blue: 0.16), Color(red: 0.14, green: 0.02, blue: 0.06), Color(red: 1.0, green: 0.62, blue: 0.66))
        case .forest: return (Color(red: 0.08, green: 0.32, blue: 0.20), Color(red: 0.02, green: 0.10, blue: 0.07), Color(red: 0.58, green: 0.95, blue: 0.66))
        case .cosmos: return (Color(red: 0.20, green: 0.06, blue: 0.36), Color(red: 0.02, green: 0.01, blue: 0.08), Color(red: 0.85, green: 0.62, blue: 1.0))
        case .subject:
            let c = subject ?? Color(red: 0.09, green: 0.20, blue: 0.48)
            return (c.opacity(0.95), Color(red: 0.04, green: 0.05, blue: 0.10), .white)
        }
    }
}

extension WidgetBridge {
    private static let lookType = "ru.student.safuhub.look"

    /// Приложение: оформление виджета
    static func publishLook(theme: String, showTeacher: Bool) {
        guard let board = UIPasteboard(name: UIPasteboard.Name("ru.student.safuhub.widget-look"), create: true) else { return }
        let raw = Data("\(theme)|\(showTeacher ? 1 : 0)".utf8)
        board.setItems([[lookType: raw]], options: [.localOnly: true])
    }

    /// Виджет: оформление (последнее полученное запоминается у виджета)
    static func look() -> (theme: WidgetTheme, showTeacher: Bool) {
        let d = UserDefaults.standard
        if let board = UIPasteboard(name: UIPasteboard.Name("ru.student.safuhub.widget-look"), create: false),
           let raw = board.data(forPasteboardType: lookType),
           let text = String(data: raw, encoding: .utf8) {
            let parts = text.split(separator: "|").map(String.init)
            if parts.count == 2 {
                d.set(parts[0], forKey: "widget.theme")
                d.set(parts[1] == "1", forKey: "widget.teacher")
            }
        }
        let theme = WidgetTheme(rawValue: d.string(forKey: "widget.theme") ?? "") ?? .night
        let teacher = d.object(forKey: "widget.teacher") as? Bool ?? true
        return (theme, teacher)
    }
}
