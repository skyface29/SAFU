import Foundation
import UIKit

// MARK: - Мост «приложение → виджет» без App Groups
// После переподписи IPA общие данные (App Group) не работают, и виджет не видел ни группу, ни расписание.
// Именованный буфер обмена доступен только приложениям одного разработчика (само приложение и его виджет),
// в общий буфер ничего не попадает. Приложение кладёт туда группу и пары на 3 недели вперёд,
// виджет забирает их при обновлении и сохраняет у себя.

enum WidgetBridge {
    private static let name = UIPasteboard.Name("ru.student.safuhub.widget-bridge")
    private static let type = "ru.student.safuhub.schedule"

    /// Приложение: отдать виджету группу и ближайшие пары
    static func publish(_ data: ScheduleData) {
        guard data.usesRuz, !data.ruzGroupNumber.isEmpty else { return }
        var lite = data
        let from = Date().addingTimeInterval(-2 * 86_400)
        let to = Date().addingTimeInterval(21 * 86_400)
        lite.ruzEvents = data.ruzEvents.filter { $0.start >= from && $0.start <= to }
        lite.history = [:]
        guard let raw = try? JSONEncoder().encode(lite),
              let board = UIPasteboard(name: name, create: true) else { return }
        board.setItems([[type: raw]], options: [.localOnly: true])
    }

    /// Виджет: что оставило приложение (nil — моста нет или он пуст)
    static func read() -> ScheduleData? {
        guard let board = UIPasteboard(name: name, create: false),
              let raw = board.data(forPasteboardType: type),
              let d = try? JSONDecoder().decode(ScheduleData.self, from: raw),
              !d.ruzGroupNumber.isEmpty else { return nil }
        return d
    }
}
