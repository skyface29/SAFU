import Foundation

// Общий код приложения и виджета

enum Academic {
    static var defaultStart: Date {
        let cal = Calendar.current
        let now = Date()
        let y = cal.component(.year, from: now)
        let m = cal.component(.month, from: now)
        var comps = DateComponents()
        if m >= 9 {
            comps.year = y; comps.month = 9; comps.day = 1
        } else if m >= 2 {
            comps.year = y; comps.month = 2; comps.day = 9
        } else {
            comps.year = y - 1; comps.month = 9; comps.day = 1
        }
        return cal.date(from: comps) ?? now
    }

    static func week(from start: Date, now: Date = Date()) -> Int? {
        var cal = Calendar(identifier: .gregorian)
        cal.firstWeekday = 2
        guard let s = cal.dateInterval(of: .weekOfYear, for: start)?.start,
              let n = cal.dateInterval(of: .weekOfYear, for: now)?.start else { return nil }
        let days = cal.dateComponents([.day], from: s, to: n).day ?? 0
        let w = days / 7 + 1
        return (w >= 1 && w <= 30) ? w : nil
    }
}

struct Lesson: Identifiable, Codable, Hashable {
    var id = UUID()
    var subject: String
    var kind: String = "Лекция"
    var weekday: Int = 1      // 1 = пн … 6 = сб
    var pair: Int = 1
    var parity: Int = 0       // 0 — каждую неделю, 1 — нечётная, 2 — чётная
    var room: String = ""
    var building: String = ""
    var teacher: String = ""

    static let kinds = ["Лекция", "Практика", "Лабораторная", "Семинар", "Физкультура", "Другое"]
    static let dayNames = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб"]
    static let dayFullNames = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
}

struct Building: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var address: String
}

struct ScheduleData: Codable {
    var lessons: [Lesson] = []
    var buildings: [Building] = ScheduleData.defaultBuildings
    var semesterStart: Date = Academic.defaultStart
    /// Архив: как выглядело расписание в прошлые недели (ключ — понедельник недели)
    var history: [String: [Lesson]] = [:]

    static let defaultBuildings = [
        Building(name: "Главный корпус", address: "Архангельск, наб. Северной Двины, 17")
    ]

    init() {}

    enum CodingKeys: String, CodingKey {
        case lessons, buildings, semesterStart, history
    }

    // Старые сохранения (без архива) тоже читаются
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        lessons = try c.decodeIfPresent([Lesson].self, forKey: .lessons) ?? []
        buildings = try c.decodeIfPresent([Building].self, forKey: .buildings) ?? ScheduleData.defaultBuildings
        semesterStart = try c.decodeIfPresent(Date.self, forKey: .semesterStart) ?? Academic.defaultStart
        history = try c.decodeIfPresent([String: [Lesson]].self, forKey: .history) ?? [:]
    }

    /// Пары, действовавшие в неделю этого дня
    func activeLessons(on day: Date) -> [Lesson] {
        let key = WeekKey.key(for: day)
        if key < WeekKey.key(for: Date()), let archived = history[key] {
            return archived
        }
        return lessons
    }

    func isArchived(_ day: Date) -> Bool {
        let key = WeekKey.key(for: day)
        return key < WeekKey.key(for: Date()) && history[key] != nil
    }
}

enum WeekKey {
    static func monday(of date: Date) -> Date {
        var cal = Calendar(identifier: .gregorian)
        cal.firstWeekday = 2
        return cal.dateInterval(of: .weekOfYear, for: date)?.start ?? Calendar.current.startOfDay(for: date)
    }

    static func key(for date: Date) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: monday(of: date))
    }
}

struct LessonSlot: Hashable {
    let lesson: Lesson
    let start: Date
    let end: Date
    let address: String

    var place: String {
        var parts: [String] = []
        if !lesson.room.isEmpty { parts.append("ауд. \(lesson.room)") }
        if !lesson.building.isEmpty { parts.append(lesson.building) }
        return parts.joined(separator: " · ")
    }
}

/// Звонки САФУ: первая пара в 8:20, пара 1 ч 30 мин, перерыв 15 мин, обед 55 мин после 3-й пары
enum Bells {
    static let times: [(Int, Int, Int, Int)] = [
        (8, 20, 9, 50),
        (10, 5, 11, 35),
        (11, 50, 13, 20),
        (14, 15, 15, 45),
        (16, 0, 17, 30),
        (17, 45, 19, 15),
        (19, 30, 21, 0)
    ]

    static func label(_ pair: Int) -> String {
        guard pair >= 1, pair <= times.count else { return "" }
        let t = times[pair - 1]
        return String(format: "%d:%02d–%d:%02d", t.0, t.1, t.2, t.3)
    }

    static func interval(pair: Int, on day: Date) -> (Date, Date)? {
        guard pair >= 1, pair <= times.count else { return nil }
        let t = times[pair - 1]
        let cal = Calendar.current
        guard let s = cal.date(bySettingHour: t.0, minute: t.1, second: 0, of: day),
              let e = cal.date(bySettingHour: t.2, minute: t.3, second: 0, of: day) else { return nil }
        return (s, e)
    }
}

enum ScheduleEngine {
    /// 1 = пн … 7 = вс
    static func weekday(of date: Date) -> Int {
        let wd = Calendar.current.component(.weekday, from: date)
        return wd == 1 ? 7 : wd - 1
    }

    static func address(for lesson: Lesson, in data: ScheduleData) -> String {
        if let b = data.buildings.first(where: { $0.name == lesson.building }) {
            return b.address
        }
        return lesson.building
    }

    static func slots(on day: Date, data: ScheduleData) -> [LessonSlot] {
        let wd = weekday(of: day)
        guard wd <= 6 else { return [] }
        let week = Academic.week(from: data.semesterStart, now: day) ?? 1
        let matching = data.activeLessons(on: day).filter { l in
            guard l.weekday == wd else { return false }
            switch l.parity {
            case 1: return week % 2 == 1
            case 2: return week % 2 == 0
            default: return true
            }
        }
        let result: [LessonSlot] = matching.compactMap { l in
            guard let iv = Bells.interval(pair: l.pair, on: day) else { return nil }
            return LessonSlot(lesson: l, start: iv.0, end: iv.1, address: address(for: l, in: data))
        }
        return result.sorted { $0.start < $1.start }
    }

    static func nowAndNext(at date: Date, data: ScheduleData) -> (current: LessonSlot?, next: LessonSlot?) {
        let cal = Calendar.current
        var current: LessonSlot?
        var next: LessonSlot?
        for offset in 0..<8 {
            guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: date)) else { continue }
            for s in slots(on: day, data: data) {
                if s.start <= date && date < s.end {
                    current = s
                } else if s.start > date && next == nil {
                    next = s
                }
            }
            if next != nil { break }
        }
        return (current, next)
    }

    /// Моменты, когда виджет должен обновиться (начала и концы пар)
    static func boundaries(after date: Date, data: ScheduleData) -> [Date] {
        let cal = Calendar.current
        var result = Set<Date>()
        for offset in 0..<2 {
            guard let day = cal.date(byAdding: .day, value: offset, to: cal.startOfDay(for: date)) else { continue }
            for s in slots(on: day, data: data) {
                if s.start > date { result.insert(s.start) }
                if s.end > date { result.insert(s.end) }
            }
        }
        if let midnight = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: date)) {
            result.insert(midnight)
        }
        return result.sorted()
    }
}

enum SharedSchedule {
    static let groupID = "group.ru.student.safuhub"
    static let key = "schedule.v1"

    static var shared: UserDefaults { UserDefaults(suiteName: groupID) ?? .standard }

    static func load() -> ScheduleData {
        for d in [shared, UserDefaults.standard] {
            if let raw = d.data(forKey: key),
               let decoded = try? JSONDecoder().decode(ScheduleData.self, from: raw) {
                return decoded
            }
        }
        return ScheduleData()
    }

    static func save(_ data: ScheduleData) {
        guard let raw = try? JSONEncoder().encode(data) else { return }
        shared.set(raw, forKey: key)
        UserDefaults.standard.set(raw, forKey: key)
    }
}
