import UIKit

// MARK: - «Прозрачный» фон виджета
// iOS не даёт сторонним виджетам настоящую прозрачность, поэтому делаем как Widgetsmith:
// приложение вырезает из скриншота пустого экрана «Домой» кусок обоев ровно под местом виджета,
// и виджет рисует его своим фоном — выглядит прозрачным.
// Картинка передаётся виджету через общую папку группы приложения, а если её нет — через общую связку ключей.

enum WidgetWallpaper {
    /// Размеры виджета: "small", "medium", "large"
    static func key(_ family: String) -> String { "wall." + family }

    private static var groupFolder: URL? {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: SharedSchedule.groupID)
    }

    /// Приложение: сохранить фон для размера виджета. Возвращает, куда удалось записать
    @discardableResult
    static func save(_ image: UIImage, family: String) -> (folder: Bool, keychain: Bool) {
        let small = downscale(image, maxSide: 700)
        guard let data = small.jpegData(compressionQuality: 0.72) else { return (false, false) }
        var folder = false
        if let dir = groupFolder {
            folder = (try? data.write(to: dir.appendingPathComponent(key(family) + ".jpg"), options: .atomic)) != nil
        }
        let keychain = SharedKeychain.write(data, account: key(family)) == errSecSuccess
        cache[family] = nil
        return (folder, keychain)
    }

    static func remove(family: String) {
        if let dir = groupFolder { try? FileManager.default.removeItem(at: dir.appendingPathComponent(key(family) + ".jpg")) }
        _ = SharedKeychain.write(Data(), account: key(family))
        cache[family] = nil
    }

    private static var cache: [String: UIImage] = [:]
    private static let lock = NSLock()

    /// Виджет и приложение: сохранённый фон (nil — не задан или недоступен)
    static func load(family: String) -> UIImage? {
        lock.lock(); defer { lock.unlock() }
        if let c = cache[family] { return c }
        var data: Data?
        if let dir = groupFolder {
            data = try? Data(contentsOf: dir.appendingPathComponent(key(family) + ".jpg"))
        }
        if data == nil || data?.isEmpty == true { data = SharedKeychain.read(account: key(family)) }
        guard let data, !data.isEmpty, let img = UIImage(data: data) else { return nil }
        cache[family] = img
        return img
    }

    private static func downscale(_ image: UIImage, maxSide: CGFloat) -> UIImage {
        let side = max(image.size.width, image.size.height)
        guard side > maxSide else { return image }
        let k = maxSide / side
        let size = CGSize(width: image.size.width * k, height: image.size.height * k)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in image.draw(in: CGRect(origin: .zero, size: size)) }
    }
}
