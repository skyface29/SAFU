import Foundation

// MARK: - Зеркало расписания arktika-app.ru/raspisanie/
// Его собирает ruz/collect.mjs из РУЗ и расписаний колледжей (ТК Петра I, ТК Северодвинска, колледж ВШРиМТ).
// Приложение берёт расписание отсюда: один лёгкий JSON на группу вместо страницы РУЗ на 200–400 КБ,
// все недели с начала семестра, колледжи, и расписание видно, даже когда РУЗ лежит.
// Не ответило зеркало — ScheduleStore идёт в РУЗ напрямую, как раньше.

enum Mirror {
    static let base = "https://arktika-app.ru/raspisanie/data/web/"

    struct Group: Codable, Hashable {
        let number: String
        let insts: [Int]
        let course: Int
        let title: String
    }

    struct School: Codable, Hashable {
        let id: Int
        let short: String
        let full: String
        let about: String
        let city: String     // "arh" | "sev"
        let kind: String     // "vuz" | "spo" | "asp"
    }

    struct Index: Codable {
        let schools: [School]
        let groups: [Group]
    }

    /// Колледж, у которого в РУЗе пар нет: расписание только из зеркала
    static func mirrorOnly(_ inst: Int) -> Bool { inst >= 1000 || inst == 23 }

    private static func get(_ path: String, timeout: TimeInterval) async throws -> (Data, Int) {
        guard let url = URL(string: base + path) else { throw URLError(.badURL) }
        var req = URLRequest(url: url)
        req.timeoutInterval = timeout
        req.cachePolicy = .reloadRevalidatingCacheData   // файл группы меняется только с расписанием — ETag
        let (data, resp) = try await URLSession.shared.data(for: req)
        return (data, (resp as? HTTPURLResponse)?.statusCode ?? 0)
    }

    static func groupPath(_ number: String) -> String {
        let n = number.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: " ", with: "_")
        return "g/" + (n.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? n) + ".json"
    }

    private struct GroupFile: Decodable {
        let base: Int
        let S: [String]
        let L: [[Int]]
    }

    /// Пары группы. nil — группы в зеркале нет (тогда — РУЗ напрямую)
    static func loadGroup(_ number: String, timeout: TimeInterval = 20) async throws -> [RuzEvent]? {
        let (data, code) = try await get(groupPath(number), timeout: timeout)
        if code == 404 { return nil }
        guard code == 200 else { throw URLError(.badServerResponse) }
        let f = try JSONDecoder().decode(GroupFile.self, from: data)
        return events(from: f)
    }

    /// Расписание группы из зеркала как результат РУЗ. nil — группы в зеркале нет или зеркало не ответило
    /// (у колледжей без РУЗа ошибку пробрасываем: идти больше некуда)
    static func load(number: String, institution: Int, timeout: TimeInterval = 20) async throws -> RuzResult? {
        guard !number.trimmingCharacters(in: .whitespaces).isEmpty else { return nil }
        do {
            guard let ev = try await loadGroup(number, timeout: timeout) else {
                return mirrorOnly(institution) ? RuzResult(events: [], method: "зеркало", notice: "Группы \(number) пока нет в расписании колледжа") : nil
            }
            return RuzResult(events: ev, method: "зеркало", notice: ev.isEmpty ? "В зеркале нет пар группы на ближайшие недели" : nil)
        } catch {
            if mirrorOnly(institution) { throw error }
            return nil
        }
    }

    private static func events(from f: GroupFile) -> [RuzEvent] {
        f.L.compactMap { r in
            guard r.count >= 9 else { return nil }
            let s = { (i: Int) -> String in r[i] >= 0 && r[i] < f.S.count ? f.S[r[i]] : "" }
            let start = Date(timeIntervalSince1970: TimeInterval((f.base + r[0]) * 60))
            // подгруппа и поток — в примечание, как их пишет РУЗ: фильтр подгрупп и потоки работают как прежде
            let note = [s(7).isEmpty ? "" : "Поток \"\(s(7))\"", s(8).isEmpty ? "" : "Подгруппа \(s(8))"]
                .filter { !$0.isEmpty }.joined(separator: " ")
            return RuzEvent(start: start, end: start.addingTimeInterval(TimeInterval(r[1] * 60)),
                            subject: s(2), kind: s(3).isEmpty ? "Занятие" : s(3), teacher: s(4),
                            room: s(5), address: s(6), note: note)
        }
    }

    // MARK: школы, колледжи и группы

    private struct Manifest: Decodable { let i: String }
    private struct RawIndex: Decodable {
        let schools: [[Value]]
        let G: [[Value]]
    }
    /// В i.json строки — массивы разных типов: [151621, [3], 1, "направление"]
    private enum Value: Decodable {
        case int(Int), str(String), ints([Int])
        init(from d: Decoder) throws {
            let c = try d.singleValueContainer()
            if let v = try? c.decode(Int.self) { self = .int(v) }
            else if let v = try? c.decode(String.self) { self = .str(v) }
            else if let v = try? c.decode([Int].self) { self = .ints(v) }
            else { self = .str("") }
        }
        var int: Int { if case .int(let v) = self { return v }; if case .str(let s) = self { return Int(s) ?? 0 }; return 0 }
        var str: String { if case .str(let v) = self { return v }; if case .int(let v) = self { return String(v) }; return "" }
        var ints: [Int] { if case .ints(let v) = self { return v }; return [] }
    }

    private static let indexKey = "mirror.index"
    private struct Box: Codable { let at: Date; let file: String; let index: Index }

    /// Школы и группы; кэш на сутки, без сети — последний сохранённый
    static func index(force: Bool = false) async throws -> Index {
        let d = UserDefaults.standard
        let box = d.data(forKey: indexKey).flatMap { try? JSONDecoder().decode(Box.self, from: $0) }
        if !force, let box, Date().timeIntervalSince(box.at) < 86_400 { return box.index }
        do {
            let (m, _) = try await get("m.json", timeout: 15)
            let file = try JSONDecoder().decode(Manifest.self, from: m).i
            if let box, box.file == file { return box.index }
            let (raw, _) = try await get(file, timeout: 20)
            let r = try JSONDecoder().decode(RawIndex.self, from: raw)
            let ix = Index(
                schools: r.schools.compactMap { s in
                    guard s.count >= 4 else { return nil }
                    return School(id: s[0].int, short: s[1].str, full: s[2].str, about: s[3].str,
                                  city: s.count > 4 ? s[4].str : "arh", kind: s.count > 5 ? s[5].str : "vuz")
                },
                groups: r.G.compactMap { g in
                    guard g.count >= 4 else { return nil }
                    return Group(number: g[0].str, insts: g[1].ints, course: g[2].int, title: g[3].str)
                })
            if let enc = try? JSONEncoder().encode(Box(at: Date(), file: file, index: ix)) { d.set(enc, forKey: indexKey) }
            return ix
        } catch {
            if let box { return box.index }
            throw error
        }
    }
}
